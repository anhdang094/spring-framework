#!/bin/bash

#[ $# -ne 1 ] && {
#   echo "Usage: $0 \$1=[start|stop|restart|status]"
#   exit
#}


## Source function library.
if [ -f /etc/rc.d/init.d/functions ];then
     . /etc/rc.d/init.d/functions
else
     echo "/etc/rc.d/init.d/functions file does not exist."
     echo "Please use yum -y install initscripts"
     exit 0
fi


export PATH=/opt/jdk1.8/bin/:$PATH
cd `dirname $0`
BIN_DIR=`pwd`
cd ..
DEPLOY_DIR=`pwd`
#应用名称
APP_NAME=GWDataCenterApp.jar
#日志目录
LOGS_DIR=$DEPLOY_DIR/logs
#日志文件
STDOUT_FILE=$LOGS_DIR/stdout.log
#nameSpace
GROUP_NAME='-DgroupId=GROUP1'

## Color Variable
GREEN_COLOR='\E[1;32m'
RED_COLOR='\E[1;31m'
RES='\E[0m'

#成功日志
_MSG_EXE_SUCCEED="${GREEN_COLOR}execution succeed${RES}"
#失败日志
_MSG_EXE_FAILED="${RED_COLOR}execution failed${RES}"

#华丽的分隔符
SPLIT_LINE="======================================================================="

start(){   
	PIDS=`ps -f | grep java | grep $APP_NAME |awk '{print $2}'`
	if [ -n "$PIDS" ]; then
		echo $SPLIT_LINE
		echo
		echo -e "${RED_COLOR}WARN: The project $APP_NAME already start!(PID: $PIDS)${RES}"
		echo -e $_MSG_EXE_FAILED
		echo
		echo $SPLIT_LINE
		exit 1
	fi

	if [ ! -d $LOGS_DIR ]; then
		mkdir $LOGS_DIR
	fi

	echo $SPLIT_LINE
	echo
	echo -e "Starting $APP_NAME...\c"
	nohup java  -jar $GROUP_NAME $APP_NAME >$STDOUT_FILE 2>&1 &

	COUNT=0
	while [ $COUNT -lt 1 ]; do    
		echo -e ".\c"
		sleep 1 
		COUNT=`ps -ef | grep java | grep $APP_NAME | awk '{print $2}' | wc -l`

		if [ $COUNT -gt 0 ]; then
			break
		fi
	done
	PIDS=`ps -f | grep java | grep $APP_NAME | awk '{print $2}'`
	action "(PID: $PIDS)" /bin/true
	echo "STDOUT: $STDOUT_FILE"
	echo -e $_MSG_EXE_SUCCEED
	echo
	echo $SPLIT_LINE
    return 0
}

stop(){	
	PIDS=`ps aux | grep java | grep $APP_NAME |awk '{print $2}'`
	if [ -z "$PIDS" ]; then
		echo $SPLIT_LINE
		echo
		echo -e "${RED_COLOR}WARN: The project $APP_NAME does not started!${RES}"
		echo -e $_MSG_EXE_FAILED
		echo
		echo $SPLIT_LINE
		exit 1
	fi

	echo $SPLIT_LINE
	echo
	echo -e "Shutdown  $APP_NAME...\c"
	for PID in $PIDS ; do
		kill $PID > /dev/null 2>&1
	done

	COUNT=0
	while [ $COUNT -lt 1 ]; do    
		echo -e ".\c"
		sleep 1
		COUNT=1
		for PID in $PIDS ; do
			PID_EXIST=`ps -f -p $PID | grep java`
			if [ -n "$PID_EXIST" ]; then
				COUNT=0
				break
			fi
		done
	done

	
	action "(PID: $PIDS)" /bin/true
	echo -e $_MSG_EXE_SUCCEED
	echo	
	echo $SPLIT_LINE
	return 0
}

status(){
    PIDS=`ps -ef | grep java | grep $APP_NAME |awk '{print $2}'`
    if [ -n "$PIDS" ]; then
		echo $SPLIT_LINE
		echo
        echo -e "${GREEN_COLOR}RUNNING${RES}: The project $APP_NAME already started!(PID:$PIDS)"
		echo -e $_MSG_EXE_SUCCEED
		echo
		ps -ef | grep java | grep $APP_NAME
		echo $SPLIT_LINE
        exit 1
    else
		echo $SPLIT_LINE
		echo
		echo -e "${RED_COLOR}SHUTDOWN${RES}: The project $APP_NAME does not started!"
		echo -e $_MSG_EXE_SUCCEED
		echo
		echo $SPLIT_LINE
        exit 1
    fi

}
 

case "$1" in
     start)
     start
     ;;

     stop)
     stop
     ;;

     restart)
     stop
     start
     ;;

     status)
     status
     ;;

     *)
	  echo "Unknown command: "$1""
      echo "Usage: $0:[start|stop|restart|status]"
      echo "commands:"
      echo "    start            	Start App"
      echo "     stop             	Stop App"
      echo "  restart           	Restart App"
      echo "   status           	Get App Status(RUNNING|SHUTDOWN)"
      exit 1    
esac
