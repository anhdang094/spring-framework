ALTER SESSION SET CURRENT_SCHEMA=DC;
-- Create table
drop table ORDERS_XJ;
create table ORDERS_XJ
(
  billno             VARCHAR2(16) not null,
  loginname          VARCHAR2(30) not null,
  agcode             VARCHAR2(18),
  top_agcode         VARCHAR2(3),
  product_id         VARCHAR2(10) not null,
  platform_id        VARCHAR2(20) not null,
  account            NUMBER(20,4),
  valid_account      NUMBER(18,2),
  cus_account        NUMBER(18,4),
  previos_amount     NUMBER,
  gmcode             VARCHAR2(14),
  billtime           DATE,
  reckontime         DATE,
  flag               NUMBER(1) default 0,
  hashcode           VARCHAR2(40),
  playtype           NUMBER(4),
  currency           VARCHAR2(6),
  tablecode          VARCHAR2(16),
  round              VARCHAR2(16),
  gametype           VARCHAR2(100),
  cur_ip             VARCHAR2(16),
  remark             VARCHAR2(124),
  result             VARCHAR2(64),
  card_list          VARCHAR2(196),
  exchangerate       NUMBER,
  resulttype         VARCHAR2(20),
  game_kind          NUMBER(2),
  orignal_billtime   DATE,
  orignal_reckontime DATE,
  orignal_timezone   VARCHAR2(10),
  creation_time      DATE default SYSDATE,
  currency_type      NUMBER(1) default 0,
  id                 NUMBER(22),
  device_type        VARCHAR2(6),
  bonus_amount       NUMBER default 0 not null,
  pro_flag           NUMBER(1) default 0,
  remain_amount      NUMBER,
  odds               NUMBER,
  oddstype           VARCHAR2(20),
  termtype           VARCHAR2(2) default -1 not null,
  is_special_game    NUMBER
)
  partition by range (billtime)
  subpartition by list (PRODUCT_ID)
  subpartition template(
  subpartition XJ_A01 values ('A01') tablespace TS_DC_YEARPUBLIC_2019,
  subpartition XJ_A05 values ('A05') tablespace TS_DC_YEARPUBLIC_2019,
  subpartition XJ_DEFAULT values (DEFAULT) tablespace TS_DC_YEARPUBLIC_2019)
(
  partition P2019  values less than (TO_DATE('2020-01-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')) tablespace TS_DC_YEARPUBLIC_2019);
?

-- Add comments to the columns
comment on column ORDERS_XJ.billno
is 'ORDERS_XJ:WagersID(注单号码)';
comment on column ORDERS_XJ.loginname
is 'ORDERS_XJ:UserName(会员账号)';
comment on column ORDERS_XJ.account
is 'ORDERS_XJ:BetAmount(下注金额)';
comment on column ORDERS_XJ.valid_account
is 'ORDERS_XJ:Commissionable(实际投注金额)';
comment on column ORDERS_XJ.cus_account
is 'ORDERS_XJ:Payoff(派彩金额)';
comment on column ORDERS_XJ.gmcode
is 'ORDERS_XJ:SerialId(局号)';
comment on column ORDERS_XJ.billtime
is 'ORDERS_XJ:WagersDate(下注时间)';
comment on column ORDERS_XJ.reckontime
is 'ORDERS_XJ:UPTIME/ModifiedDate(更新时间)';
comment on column ORDERS_XJ.currency
is 'ORDERS_XJ:Currency(币别)';
comment on column ORDERS_XJ.tablecode
is 'ORDERS_XJ:GameCode(桌号)';
comment on column ORDERS_XJ.round
is 'ORDERS_XJ:RoundNo(场次)';
comment on column ORDERS_XJ.gametype
is 'ORDERS_XJ:GameType(游戏种类)';
comment on column ORDERS_XJ.remark
is '备注';
comment on column ORDERS_XJ.result
is 'ORDERS_XJ:Result(输赢/开牌结果)';
-- Create/Recreate indexes
create index I_ORDERS_XJ_BILLTIME on ORDERS_XJ (BILLTIME)
tablespace TS_DC_YEARPUBLIC_IDX01
;
create index I_ORDERS_XJ_CUS_ACCOUNT on ORDERS_XJ (CUS_ACCOUNT)
tablespace TS_DC_YEARPUBLIC_IDX01
;
create index I_ORDERS_XJ_GMCODE on ORDERS_XJ (GMCODE)
tablespace TS_DC_YEARPUBLIC_IDX01
;
create index I_ORDERS_XJ_LOGINNAME on ORDERS_XJ (LOGINNAME)
tablespace TS_DC_YEARPUBLIC_IDX01
;
create index I_ORDERS_XJ_RECKONTIME on ORDERS_XJ (RECKONTIME)
tablespace TS_DC_YEARPUBLIC_IDX01
;
-- Create/Recreate primary, unique and foreign key constraints
alter table ORDERS_XJ
  add constraint PK_ORDXJ_BILL_PROD_PLAT_NAME primary key (BILLNO, PRODUCT_ID, PLATFORM_ID, LOGINNAME)
  using index
  tablespace TS_DC_YEARPUBLIC_IDX01;
