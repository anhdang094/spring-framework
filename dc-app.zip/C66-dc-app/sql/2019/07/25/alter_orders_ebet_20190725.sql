alter table ORDERS_EBET modify remark VARCHAR2(512);
