create sequence ORDERS_XJ_SEQ
minvalue 1
maxvalue 99999999999999999
start with 当前orders_xj最大id加1
increment by 1
cache 20;


create sequence ORDERS_AGIN_SEQ
minvalue 1
maxvalue 99999999999999999
start with 当前orders_agin最大id加1
increment by 1
cache 20;


create sequence ORDERS_AGSTAR_SEQ
minvalue 1
maxvalue 99999999999999999
start with 当前orders_agstar最大id加1
increment by 1
cache 20;


update GATHER_ORDER_SYNC t set t.step_len=2000 where t.platform_type in ('agin','agqj');