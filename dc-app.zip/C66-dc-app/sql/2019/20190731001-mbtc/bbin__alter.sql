
alter table ORDERS_BBIN modify ACCOUNT NUMBER(22,6);
alter table ORDERS_BBIN modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_BBIN modify CUS_ACCOUNT NUMBER(20,6);

alter table ORDERS_EA modify ACCOUNT NUMBER(22,6);
alter table ORDERS_EA modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_EA modify CUS_ACCOUNT NUMBER(20,6);

alter table ORDERS_HG modify ACCOUNT NUMBER(22,6);
alter table ORDERS_HG modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_HG modify CUS_ACCOUNT NUMBER(20,6);

alter table ORDERS_K8 modify CUS_ACCOUNT NUMBER(22,6);
alter table ORDERS_K8 modify ACCOUNT NUMBER(22,6);
alter table ORDERS_K8 modify VALID_ACCOUNT NUMBER(22,6);

alter table ORDERS_RGS modify ACCOUNT NUMBER(22,6);
alter table ORDERS_RGS modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_RGS modify CUS_ACCOUNT NUMBER(20,6);




