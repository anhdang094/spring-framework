alter table ORDERS_188 modify ACCOUNT NUMBER(22,6);
alter table ORDERS_188 modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_188 modify CUS_ACCOUNT NUMBER(20,6);

alter table ORDERS_TLB modify PREVIOS_AMOUNT NUMBER(22,6);
alter table ORDERS_TLB modify ACCOUNT NUMBER(22,6);
alter table ORDERS_TLB modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_TLB modify CUS_ACCOUNT NUMBER(22,6);

alter table ORDERS_AMAYA modify ACCOUNT NUMBER(22,6);
alter table ORDERS_AMAYA modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_AMAYA modify CUS_ACCOUNT NUMBER(20,6);

alter table ORDERS_AMAYA_VIP modify ACCOUNT NUMBER(22,6);
alter table ORDERS_AMAYA_VIP modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_AMAYA_VIP modify CUS_ACCOUNT NUMBER(20,6);

alter table ORDERS_AP modify ACCOUNT NUMBER(22,6);
alter table ORDERS_AP modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_AP modify CUS_ACCOUNT NUMBER(20,6);

alter table ORDERS_BO modify ACCOUNT NUMBER(22,6);
alter table ORDERS_BO modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_BO modify CUS_ACCOUNT NUMBER(20,6);

alter table ORDERS_BSG modify ACCOUNT NUMBER(22,6);
alter table ORDERS_BSG modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_BSG modify CUS_ACCOUNT NUMBER(20,6);

alter table ORDERS_BSG_VIP modify ACCOUNT NUMBER(22,6);
alter table ORDERS_BSG_VIP modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_BSG_VIP modify CUS_ACCOUNT NUMBER(20,6);

alter table ORDERS_CB modify ACCOUNT NUMBER(22,6);
alter table ORDERS_CB modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_CB modify CUS_ACCOUNT NUMBER(20,6);

alter table ORDERS_CQ modify ACCOUNT NUMBER(22,6);
alter table ORDERS_CQ modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_CQ modify CUS_ACCOUNT NUMBER(22,6);

alter table ORDERS_EBET modify ACCOUNT NUMBER(22,6);
alter table ORDERS_EBET modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_EBET modify CUS_ACCOUNT NUMBER(20,6);

alter table ORDERS_ESP modify ACCOUNT NUMBER(22,6);
alter table ORDERS_ESP modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_ESP modify CUS_ACCOUNT NUMBER(20,6);
alter table ORDERS_ESP modify PREVIOS_AMOUNT NUMBER(20,6);
alter table ORDERS_ESP modify BONUS_AMOUNT NUMBER(20,6);
alter table ORDERS_ESP modify REMAIN_AMOUNT NUMBER(20,6);

alter table ORDERS_GT1 modify ACCOUNT NUMBER(22,6);
alter table ORDERS_GT1 modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_GT1 modify CUS_ACCOUNT NUMBER(20,6);

alter table ORDERS_IND modify ACCOUNT NUMBER(22,6);
alter table ORDERS_IND modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_IND modify CUS_ACCOUNT NUMBER(20,6);

alter table ORDERS_IPM modify AMOUNT NUMBER(24,6);
alter table ORDERS_IPM modify CUS_AMOUNT NUMBER(24,6);
alter table ORDERS_IPM modify PREVIOUS_AMOUNT NUMBER(24,6);
alter table ORDERS_IPM modify VALID_AMOUNT NUMBER(24,6);

alter table ORDERS_MG modify ACCOUNT NUMBER(22,6);
alter table ORDERS_MG modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_MG modify CUS_ACCOUNT NUMBER(20,6);

alter table ORDERS_MG_VIP modify ACCOUNT NUMBER(22,6);
alter table ORDERS_MG_VIP modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_MG_VIP modify CUS_ACCOUNT NUMBER(20,6);

alter table ORDERS_NETENT modify ACCOUNT NUMBER(22,6);
alter table ORDERS_NETENT modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_NETENT modify CUS_ACCOUNT NUMBER(20,6);

alter table ORDERS_NSS modify ACCOUNT NUMBER(22,6);
alter table ORDERS_NSS modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_NSS modify CUS_ACCOUNT NUMBER(20,6);

alter table ORDERS_OPUS modify ACCOUNT NUMBER(22,6);
alter table ORDERS_OPUS modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_OPUS modify CUS_ACCOUNT NUMBER(20,6);

alter table ORDERS_PNG modify ACCOUNT NUMBER(22,6);
alter table ORDERS_PNG modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_PNG modify CUS_ACCOUNT NUMBER(20,6);

alter table ORDERS_PPG modify ACCOUNT NUMBER(22,6);
alter table ORDERS_PPG modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_PPG modify CUS_ACCOUNT NUMBER(20,6);

alter table ORDERS_PT modify ACCOUNT NUMBER(22,6);
alter table ORDERS_PT modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_PT modify CUS_ACCOUNT NUMBER(20,6);

alter table ORDERS_SBO modify ACCOUNT NUMBER(22,6);
alter table ORDERS_SBO modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_SBO modify CUS_ACCOUNT NUMBER(20,6);

alter table ORDERS_SBT modify ACCOUNT NUMBER(22,6);
alter table ORDERS_SBT modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_SBT modify CUS_ACCOUNT NUMBER(20,6);

alter table ORDERS_SHABA modify ACCOUNT NUMBER(22,6);
alter table ORDERS_SHABA modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_SHABA modify CUS_ACCOUNT NUMBER(20,6);

alter table ORDERS_TGP modify ACCOUNT NUMBER(22,6);
alter table ORDERS_TGP modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_TGP modify CUS_ACCOUNT NUMBER(20,6);

alter table ORDERS_TLB modify PREVIOS_AMOUNT NUMBER(22,6);
alter table ORDERS_TLB modify ACCOUNT NUMBER(22,6);
alter table ORDERS_TLB modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_TLB modify CUS_ACCOUNT NUMBER(22,6);

alter table ORDERS_VMG modify ACCOUNT NUMBER(22,6);
alter table ORDERS_VMG modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_VMG modify CUS_ACCOUNT NUMBER(20,6);

alter table ORDERS_W88 modify ACCOUNT NUMBER(22,6);
alter table ORDERS_W88 modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_W88 modify CUS_ACCOUNT NUMBER(20,6);

alter table ORDERS_WIN_ATTENDANCE modify BET_AMOUNT NUMBER(22,6);
alter table ORDERS_WIN_ATTENDANCE modify VALID_BETAMOUNT NUMBER(22,6);
alter table ORDERS_WIN_ATTENDANCE modify NET_AMOUNT NUMBER(20,6);

alter table ORDERS_WIN_CONSECUTIVE modify ACCOUNT NUMBER(22,6);
alter table ORDERS_WIN_CONSECUTIVE modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_WIN_CONSECUTIVE modify CUS_ACCOUNT NUMBER(20,6);
alter table ORDERS_WIN_CONSECUTIVE modify CUS_ACCOUNT_TOTAL NUMBER(20,6);
alter table ORDERS_WIN_CONSECUTIVE modify PREVIOS_AMOUNT NUMBER(20,6);

alter table ORDERS_XJ modify ACCOUNT NUMBER(22,6);
alter table ORDERS_XJ modify VALID_ACCOUNT NUMBER(22,6);
alter table ORDERS_XJ modify CUS_ACCOUNT NUMBER(20,6);



