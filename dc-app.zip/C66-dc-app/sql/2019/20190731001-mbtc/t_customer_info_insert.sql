-- Create table
create table T_CUSTOMER_INFO
(
  ID         NUMBER(22) not null,
  PRODUCT_ID VARCHAR2(5) not null,
  LOGIN_NAME VARCHAR2(20) not null,
  CURRENCY   VARCHAR2(10) not null,
  REMARK     VARCHAR2(200)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255;
-- Add comments to the columns
comment on column T_CUSTOMER_INFO.ID
  is '编号';
comment on column T_CUSTOMER_INFO.PRODUCT_ID
  is '产品ID';
comment on column T_CUSTOMER_INFO.LOGIN_NAME
  is '用户登录名';
comment on column T_CUSTOMER_INFO.CURRENCY
  is '币种,CNY,VND,USDT,MBTC,BTC,USD etc.';

  -- Create sequence
create sequence CUSTOMER_INFO_ID_SEQ
minvalue 1
maxvalue 9999999999999999999999999999
start with 1
increment by 1
cache 20;



alter table t_customer_info add constraint customer_currency_u
unique (product_id,login_name,currency);