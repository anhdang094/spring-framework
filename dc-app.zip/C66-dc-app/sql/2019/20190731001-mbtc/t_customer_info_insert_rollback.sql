
drop table T_CUSTOMER_INFO;
