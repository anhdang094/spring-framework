-- Create table
create table GATHER_ORDER_SYNC
(
  id             NUMBER(22) not null,
  platform_type  VARCHAR2(16),
  order_begin_id NUMBER(22),
  order_end_id   NUMBER(22),
  step_len       NUMBER(22),
  update_time    DATE,
  remark         VARCHAR2(128),
  is_enable      NUMBER(1)
);
-- Create/Recreate primary, unique and foreign key constraints
alter table GATHER_ORDER_SYNC  add constraint PK_ID_KEY primary key (ID);
alter table GATHER_ORDER_SYNC  add constraint PK_PLATFORM_TYPE_KEY unique (PLATFORM_TYPE);
commit;

alter table ORDERS_VMG add  BONUS_AMOUNT NUMBER;
commit;