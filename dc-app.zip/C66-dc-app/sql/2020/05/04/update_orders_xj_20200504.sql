# 升级sql
alter table ORDERS_XJ modify BILLNO VARCHAR2(32);

# 回滚sql
-- 改变column长度，不需要回滚Order4IMDJTimer