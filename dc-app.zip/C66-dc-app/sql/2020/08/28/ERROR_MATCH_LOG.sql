create table ERROR_MATCH_LOG
(
    PRODUCT_ID  VARCHAR2(8),
    PLATFORM    VARCHAR2(8),
    TASK_ID     VARCHAR2(8),
    LOGINNAME   VARCHAR2(32),
    REMARK      VARCHAR2(500),
    CREATE_TIME DATE
)
;

comment on table ERROR_MATCH_LOG is '定时任务抓取时，转换出现错误的日志记录'
;

create index CREATE_TIME_KEY
    on ERROR_MATCH_LOG (CREATE_TIME)
;

create index LOGINNAME_KEY
    on ERROR_MATCH_LOG (LOGINNAME)
;

create index PLATFORM_ID_KEY
    on ERROR_MATCH_LOG (PLATFORM)
;

create index PRODUCT_ID_KEY
    on ERROR_MATCH_LOG (PRODUCT_ID)
;

create index TASK_ID_KEY
    on ERROR_MATCH_LOG (TASK_ID)
;