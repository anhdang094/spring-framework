-- Create sequence 
create sequence ORDERS_CQ_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20
order;

-- Create table
create table ORDERS_CQ
(
  billno             VARCHAR2(36) not null,
  loginname          VARCHAR2(20),
  product_id         VARCHAR2(10) not null,
  platform_id        VARCHAR2(10),
  account            NUMBER(20,4),
  valid_account      NUMBER(20,4),
  cus_account        NUMBER(20,4),
  previos_amount     NUMBER,
  playtype           NUMBER(3),
  round              VARCHAR2(36),
  gmcode             VARCHAR2(14),
  flag               NUMBER(1) default 0,
  billtime           DATE,
  reckontime         DATE,
  currency           VARCHAR2(6),
  result             VARCHAR2(64),
  game_kind          NUMBER(1),
  is_special_game    NUMBER(1) default 0,
  id                 NUMBER(22),
  device_type        VARCHAR2(6) default 1,
  pro_flag           NUMBER default 0,
  bonus_amount       NUMBER default 0,
  remain_amount      NUMBER default 0,
  creation_time      DATE default SYSDATE,
  agcode             VARCHAR2(18),
  orignal_billtime   DATE,
  orignal_reckontime DATE,
  tablecode          VARCHAR2(40),
  hashcode           VARCHAR2(40),
  top_agcode         VARCHAR2(3),
  gametype           VARCHAR2(6),
  resulttype         VARCHAR2(20),
  exchangerate       NUMBER,
  card_list          VARCHAR2(196),
  remark             VARCHAR2(124),
  currency_type      NUMBER(1),
  orignal_timezone   VARCHAR2(10)
);

comment on column ORDERS_CQ.billno is 'WagersID(ע������)';
comment on column ORDERS_CQ.loginname is 'UserName(��Ա�˺�)';
comment on column ORDERS_CQ.account is 'BetAmount(��ע���)';
comment on column ORDERS_CQ.valid_account is 'ʵ��Ͷע���';
comment on column ORDERS_CQ.cus_account is '�ɲʽ��';
comment on column ORDERS_CQ.previos_amount is 'ǰ���';
comment on column ORDERS_CQ.round is '�ֺ�';
comment on column ORDERS_CQ.gmcode is '������ϷCODE';
comment on column ORDERS_CQ.billtime is 'WagersDate(��עʱ��)';
comment on column ORDERS_CQ.reckontime is 'UPTIME/ModifiedDate(����ʱ��)';
comment on column ORDERS_CQ.currency is 'Currency(�ұ�)';
comment on column ORDERS_CQ.result is '��Ӯ';
comment on column ORDERS_CQ.is_special_game is '0:����ϴ�� 1:������ϴ��';
comment on column ORDERS_CQ.device_type is '�豸����';

alter table ORDERS_CQ
  add constraint PK_ORDERS_CQ_BILLNO primary key (BILLNO, PRODUCT_ID)