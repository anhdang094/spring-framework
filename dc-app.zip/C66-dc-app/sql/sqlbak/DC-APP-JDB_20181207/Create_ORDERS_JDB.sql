create table ORDERS_JDB
(
	BILLNO VARCHAR2(32) not null,
	LOGINNAME VARCHAR2(20) not null,
	AGCODE VARCHAR2(18),
	TOP_AGCODE VARCHAR2(3),
	PRODUCT_ID VARCHAR2(10) not null,
	PLATFORM_ID VARCHAR2(20),
	ACCOUNT NUMBER(20,4) not null,
	VALID_ACCOUNT NUMBER(18,2) not null,
	CUS_ACCOUNT NUMBER(18,4),
	PREVIOS_AMOUNT NUMBER,
	GMCODE VARCHAR2(32),
	BILLTIME DATE,
	RECKONTIME DATE,
	FLAG NUMBER(1) default 0,
	HASHCODE VARCHAR2(40),
	PLAYTYPE NUMBER(4),
	CURRENCY VARCHAR2(6),
	TABLECODE VARCHAR2(100),
	ROUND VARCHAR2(16),
	GAMETYPE VARCHAR2(32) not null,
	CUR_IP VARCHAR2(16),
	REMARK VARCHAR2(124),
	RESULT VARCHAR2(64),
	CARD_LIST VARCHAR2(196),
	EXCHANGERATE NUMBER,
	RESULTTYPE VARCHAR2(20),
	GAME_KIND NUMBER(1),
	ORIGNAL_BILLTIME DATE,
	ORIGNAL_RECKONTIME DATE,
	ORIGNAL_TIMEZONE VARCHAR2(10),
	CREATION_TIME DATE default SYSDATE,
	CURRENCY_TYPE NUMBER(1) default 0,
	ID NUMBER(22),
	DEVICE_TYPE VARCHAR2(6) default '0',
	IS_SPECIAL_GAME NUMBER(1) default 0,
	BONUS_AMOUNT NUMBER default 0 not null,
	REMAIN_AMOUNT NUMBER not null,
	PRO_FLAG NUMBER default 0,
	TERMTYPE VARCHAR2(2) default -1,
	JACKPOT_AMOUNT NUMBER(20,4) default 0,
	constraint PK_ORDERS_JDB_BILLNO_PRD_ID
		primary key (BILLNO, PRODUCT_ID)
)
;

create index I_ORDERS_JDB_BILLTIME
	on ORDERS_JDB (BILLTIME)
;

comment on column ORDERS_JDB.BILLNO is '游戏局号(不再是流水号)'
;

comment on column ORDERS_JDB.LOGINNAME is '会员账号，不带productId'
;

comment on column ORDERS_JDB.PRODUCT_ID is '产品编号'
;

comment on column ORDERS_JDB.PLATFORM_ID is '游戏厅平台编号'
;

comment on column ORDERS_JDB.ACCOUNT is '投注金额'
;

comment on column ORDERS_JDB.VALID_ACCOUNT is '有效投注金额(投注金额-撤单金额)'
;

comment on column ORDERS_JDB.CUS_ACCOUNT is '客户输赢度:派彩金额+免费旋转奖励-投注金额'
;

comment on column ORDERS_JDB.PREVIOS_AMOUNT is '投注前金额'
;

comment on column ORDERS_JDB.GMCODE is '局号'
;

comment on column ORDERS_JDB.BILLTIME is '下注时间'
;

comment on column ORDERS_JDB.RECKONTIME is '更新时间(派奖时间)'
;

comment on column ORDERS_JDB.FLAG is '0：未撤单，1：已撤单'
;

comment on column ORDERS_JDB.CURRENCY is '币别'
;

comment on column ORDERS_JDB.TABLECODE is '桌号'
;

comment on column ORDERS_JDB.ROUND is '预留字段(以前是游戏局号)'
;

comment on column ORDERS_JDB.GAMETYPE is '游戏id'
;

comment on column ORDERS_JDB.REMARK is '备注'
;

comment on column ORDERS_JDB.RESULT is 'Result(输赢;开牌结果)'
;

comment on column ORDERS_JDB.RESULTTYPE is '投注结果，700：投注，710：派奖，720：免费旋转派奖，702：撤单'
;

comment on column ORDERS_JDB.GAME_KIND is '游戏类型（电子游戏为5）'
;

comment on column ORDERS_JDB.ORIGNAL_TIMEZONE is '预留字段'
;

comment on column ORDERS_JDB.CREATION_TIME is 'DC注单记录生成时间'
;

comment on column ORDERS_JDB.CURRENCY_TYPE is '预留字段'
;

comment on column ORDERS_JDB.ID is '主键id'
;

comment on column ORDERS_JDB.DEVICE_TYPE is '用户操作客户端：0，pc端 1，移动端'
;

comment on column ORDERS_JDB.IS_SPECIAL_GAME is '0:参与洗码 1:不参与洗码'
;

comment on column ORDERS_JDB.BONUS_AMOUNT is '红利金额'
;

comment on column ORDERS_JDB.REMAIN_AMOUNT is '洗码投注额'
;


comment on column ORDERS_JDB.PRO_FLAG is '0未被抓取，1处理中，2已处理'
;

comment on column ORDERS_JDB.TERMTYPE is '终端类型'
;

comment on column ORDERS_JDB.JACKPOT_AMOUNT is '彩池奖金'
;
