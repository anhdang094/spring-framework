﻿-- 调整抓取 SBT begin时间
update orders_log t set t.begin_time = (t.begin_time - (1/24/60/60) * 5) where (t.task_id = 826 or t.task_id = 827 or t.task_id= 837 ) and t.begin_time > to_date('2017-06-01 00:00:00', 'yyyy-mm-dd hh24:mi:ss') and t.begin_time < sysdate;
commit;

-- 重置 SBT 注单重新抓取
update orders_log t set t.flag = 0 where (t.task_id = 826 or t.task_id = 827 or t.task_id= 837 ) and t.begin_time > to_date('2017-06-01 00:00:00', 'yyyy-mm-dd hh24:mi:ss') and t.begin_time < sysdate;
commit;


--  TTG MG begin 时间调整
update orders_log t set t.begin_time = (t.begin_time - (1/24/60/60) * 5) where ( t.task_id = 637 or t.task_id = 657 or t.task_id = 111)  and t.begin_time > to_date('2017-08-01 00:00:00', 'yyyy-mm-dd hh24:mi:ss') and t.begin_time < sysdate;
commit;

-- TTG MG 注单重新抓取
update orders_log t set t.flag = 0 where ( t.task_id = 637 or t.task_id = 657 or t.task_id = 111)  and t.begin_time > to_date('2017-08-01 00:00:00', 'yyyy-mm-dd hh24:mi:ss') and t.begin_time < sysdate;
commit;