﻿-- 修正 沙巴 gametype显示
update orders_shaba t set t.gametype = '99' where t.gmcode = '29' and t.gametype = 'null' and t.billtime > to_date('2017-08-01', 'yyyy-mm-dd');
commit;