alter table orders_netent modify CURRENCY_TYPE NUMBER(1,0) DEFAULT 0;
update orders_netent set CURRENCY_TYPE = 0, GMCODE=ROUND;
