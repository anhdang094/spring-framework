update orders_bbin set billtime=billtime+1/2,reckontime=reckontime+1/2,orignal_billtime=orignal_billtime+1/2,game_kind=5  where product_id ='A01' and gametype='38001' and platform_id='006' and (game_kind=51 or game_kind=8 or game_kind=5) and billtime>=TO_DATE('2017-12-25 00:00:01','YYYY-MM-DD HH24:MI:SS')
and billtime<=TO_DATE('2018-01-03 16:59:59','YYYY-MM-DD HH24:MI:SS') ;

update orders_bbin set billtime=billtime+1/2,reckontime=reckontime+1/2,orignal_billtime=orignal_billtime+1/2,game_kind=5  where product_id ='A02' and gametype='38001' and platform_id='007' and (game_kind=51 or game_kind=8 or game_kind=5) and billtime>=TO_DATE('2017-12-25 00:00:01','YYYY-MM-DD HH24:MI:SS') 
and billtime<=TO_DATE('2018-01-03 16:59:59','YYYY-MM-DD HH24:MI:SS') ;

update orders_bbin set billtime=billtime+1/2,reckontime=reckontime+1/2,orignal_billtime=orignal_billtime+1/2,game_kind=5  where product_id ='A03' and gametype='38001' and platform_id='017' and (game_kind=51 or game_kind=8 or game_kind=5) and billtime>=TO_DATE('2017-12-25 00:00:01','YYYY-MM-DD HH24:MI:SS') 
and billtime<=TO_DATE('2018-01-03 16:59:59','YYYY-MM-DD HH24:MI:SS') ;

update orders_bbin set billtime=billtime+1/2,reckontime=reckontime+1/2,orignal_billtime=orignal_billtime+1/2,game_kind=5  where product_id ='A04' and gametype='38001' and platform_id='010' and (game_kind=51 or game_kind=8 or game_kind=5) and billtime>=TO_DATE('2017-12-25 00:00:01','YYYY-MM-DD HH24:MI:SS') 
and billtime<=TO_DATE('2018-01-03 16:59:59','YYYY-MM-DD HH24:MI:SS') ;

update orders_bbin set billtime=billtime+1/2,reckontime=reckontime+1/2,orignal_billtime=orignal_billtime+1/2,game_kind=5  where product_id ='A05' and gametype='38001' and platform_id='012' and (game_kind=51 or game_kind=8 or game_kind=5) and billtime>=TO_DATE('2017-12-25 00:00:01','YYYY-MM-DD HH24:MI:SS') 
and billtime<=TO_DATE('2018-01-03 16:59:59','YYYY-MM-DD HH24:MI:SS') ;

update orders_bbin set billtime=billtime+1/2,reckontime=reckontime+1/2,orignal_billtime=orignal_billtime+1/2,game_kind=5  where product_id ='A06' and gametype='38001' and platform_id='024' and (game_kind=51 or game_kind=8 or game_kind=5) and billtime>=TO_DATE('2017-12-25 00:00:01','YYYY-MM-DD HH24:MI:SS') 
and billtime<=TO_DATE('2018-01-03 16:59:59','YYYY-MM-DD HH24:MI:SS') ;

update orders_bbin set billtime=billtime+1/2,reckontime=reckontime+1/2,orignal_billtime=orignal_billtime+1/2,game_kind=5  where product_id ='B01' and gametype='38001' and platform_id='006' and (game_kind=51 or game_kind=8 or game_kind=5) and billtime>=TO_DATE('2017-12-25 00:00:01','YYYY-MM-DD HH24:MI:SS') 
and billtime<=TO_DATE('2018-01-03 16:59:59','YYYY-MM-DD HH24:MI:SS') ;

update orders_bbin set billtime=billtime+1/2,reckontime=reckontime+1/2,orignal_billtime=orignal_billtime+1/2,game_kind=5  where product_id ='C01' and gametype='38001' and platform_id='013' and (game_kind=51 or game_kind=8 or game_kind=5) and billtime>=TO_DATE('2017-12-25 00:00:01','YYYY-MM-DD HH24:MI:SS') 
and billtime<=TO_DATE('2018-01-03 16:59:59','YYYY-MM-DD HH24:MI:SS') ;

update orders_bbin set billtime=billtime+1/2,reckontime=reckontime+1/2,orignal_billtime=orignal_billtime+1/2,game_kind=5  where product_id ='C02' and gametype='38001' and platform_id='020' and (game_kind=51 or game_kind=8 or game_kind=5) and billtime>=TO_DATE('2017-12-25 00:00:01','YYYY-MM-DD HH24:MI:SS') 
and billtime<=TO_DATE('2018-01-03 16:59:59','YYYY-MM-DD HH24:MI:SS') ;

update orders_bbin set billtime=billtime+1/2,reckontime=reckontime+1/2,orignal_billtime=orignal_billtime+1/2,game_kind=5  where product_id ='E02' and gametype='38001' and platform_id='006' and (game_kind=51 or game_kind=8 or game_kind=5) and billtime>=TO_DATE('2017-12-25 00:00:01','YYYY-MM-DD HH24:MI:SS') 
and billtime<=TO_DATE('2018-01-03 16:59:59','YYYY-MM-DD HH24:MI:SS') ;

update orders_bbin set billtime=billtime+1/2,reckontime=reckontime+1/2,orignal_billtime=orignal_billtime+1/2,game_kind=5  where product_id ='E03' and gametype='38001' and platform_id='006' and (game_kind=51 or game_kind=8 or game_kind=5) and billtime>=TO_DATE('2017-12-25 00:00:01','YYYY-MM-DD HH24:MI:SS') 
and billtime<=TO_DATE('2018-01-03 16:59:59','YYYY-MM-DD HH24:MI:SS') ;

update orders_bbin set billtime=billtime+1/2,reckontime=reckontime+1/2,orignal_billtime=orignal_billtime+1/2,game_kind=5  where product_id ='E04' and gametype='38001' and platform_id='006' and (game_kind=51 or game_kind=8 or game_kind=5) and billtime>=TO_DATE('2017-12-25 00:00:01','YYYY-MM-DD HH24:MI:SS') 
and billtime<=TO_DATE('2018-01-03 16:59:59','YYYY-MM-DD HH24:MI:SS') ;



update orders_bbin set billtime=billtime+1/2,reckontime=reckontime+1/2,orignal_billtime=orignal_billtime+1/2,game_kind=5  where product_id ='A01' and gametype='30599' and platform_id='006' and (game_kind=51 or game_kind=8 or game_kind=5) and billtime>=TO_DATE('2017-12-25 00:00:01','YYYY-MM-DD HH24:MI:SS') 
and billtime<=TO_DATE('2018-01-03 16:59:59','YYYY-MM-DD HH24:MI:SS') ;

update orders_bbin set billtime=billtime+1/2,reckontime=reckontime+1/2,orignal_billtime=orignal_billtime+1/2,game_kind=5  where product_id ='A02' and gametype='30599' and platform_id='007' and (game_kind=51 or game_kind=8 or game_kind=5) and billtime>=TO_DATE('2017-12-25 00:00:01','YYYY-MM-DD HH24:MI:SS') 
and billtime<=TO_DATE('2018-01-03 16:59:59','YYYY-MM-DD HH24:MI:SS') ;

update orders_bbin set billtime=billtime+1/2,reckontime=reckontime+1/2,orignal_billtime=orignal_billtime+1/2,game_kind=5  where product_id ='A03' and gametype='30599' and platform_id='017' and (game_kind=51 or game_kind=8 or game_kind=5) and billtime>=TO_DATE('2017-12-25 00:00:01','YYYY-MM-DD HH24:MI:SS') 
and billtime<=TO_DATE('2018-01-03 16:59:59','YYYY-MM-DD HH24:MI:SS') ;

update orders_bbin set billtime=billtime+1/2,reckontime=reckontime+1/2,orignal_billtime=orignal_billtime+1/2,game_kind=5  where product_id ='A04' and gametype='30599' and platform_id='010' and (game_kind=51 or game_kind=8 or game_kind=5) and billtime>=TO_DATE('2017-12-25 00:00:01','YYYY-MM-DD HH24:MI:SS') 
and billtime<=TO_DATE('2018-01-03 16:59:59','YYYY-MM-DD HH24:MI:SS') ;

update orders_bbin set billtime=billtime+1/2,reckontime=reckontime+1/2,orignal_billtime=orignal_billtime+1/2,game_kind=5  where product_id ='A05' and gametype='30599' and platform_id='012' and (game_kind=51 or game_kind=8 or game_kind=5) and billtime>=TO_DATE('2017-12-25 00:00:01','YYYY-MM-DD HH24:MI:SS') 
and billtime<=TO_DATE('2018-01-03 16:59:59','YYYY-MM-DD HH24:MI:SS') ;

update orders_bbin set billtime=billtime+1/2,reckontime=reckontime+1/2,orignal_billtime=orignal_billtime+1/2,game_kind=5  where product_id ='A06' and gametype='30599' and platform_id='024' and (game_kind=51 or game_kind=8 or game_kind=5) and billtime>=TO_DATE('2017-12-25 00:00:01','YYYY-MM-DD HH24:MI:SS') 
and billtime<=TO_DATE('2018-01-03 16:59:59','YYYY-MM-DD HH24:MI:SS') ;

update orders_bbin set billtime=billtime+1/2,reckontime=reckontime+1/2,orignal_billtime=orignal_billtime+1/2,game_kind=5  where product_id ='B01' and gametype='30599' and platform_id='006' and (game_kind=51 or game_kind=8 or game_kind=5) and billtime>=TO_DATE('2017-12-25 00:00:01','YYYY-MM-DD HH24:MI:SS') 
and billtime<=TO_DATE('2018-01-03 16:59:59','YYYY-MM-DD HH24:MI:SS') ;

update orders_bbin set billtime=billtime+1/2,reckontime=reckontime+1/2,orignal_billtime=orignal_billtime+1/2,game_kind=5  where product_id ='C01' and gametype='30599' and platform_id='013' and (game_kind=51 or game_kind=8 or game_kind=5) and billtime>=TO_DATE('2017-12-25 00:00:01','YYYY-MM-DD HH24:MI:SS') 
and billtime<=TO_DATE('2018-01-03 16:59:59','YYYY-MM-DD HH24:MI:SS') ;

update orders_bbin set billtime=billtime+1/2,reckontime=reckontime+1/2,orignal_billtime=orignal_billtime+1/2,game_kind=5  where product_id ='C02' and gametype='30599' and platform_id='020' and (game_kind=51 or game_kind=8 or game_kind=5) and billtime>=TO_DATE('2017-12-25 00:00:01','YYYY-MM-DD HH24:MI:SS') 
and billtime<=TO_DATE('2018-01-03 16:59:59','YYYY-MM-DD HH24:MI:SS') ;

update orders_bbin set billtime=billtime+1/2,reckontime=reckontime+1/2,orignal_billtime=orignal_billtime+1/2,game_kind=5  where product_id ='E02' and gametype='30599' and platform_id='006' and (game_kind=51 or game_kind=8 or game_kind=5) and billtime>=TO_DATE('2017-12-25 00:00:01','YYYY-MM-DD HH24:MI:SS') 
and billtime<=TO_DATE('2018-01-03 16:59:59','YYYY-MM-DD HH24:MI:SS') ;


update orders_bbin set billtime=billtime+1/2,reckontime=reckontime+1/2,orignal_billtime=orignal_billtime+1/2,game_kind=5  where product_id ='E03' and gametype='30599' and platform_id='006' and (game_kind=51 or game_kind=8 or game_kind=5) and billtime>=TO_DATE('2017-12-25 00:00:01','YYYY-MM-DD HH24:MI:SS') 
and billtime<=TO_DATE('2018-01-03 16:59:59','YYYY-MM-DD HH24:MI:SS') ;


update orders_bbin set billtime=billtime+1/2,reckontime=reckontime+1/2,orignal_billtime=orignal_billtime+1/2,game_kind=5  where product_id ='E04' and gametype='30599' and platform_id='006' and (game_kind=51 or game_kind=8 or game_kind=5) and billtime>=TO_DATE('2017-12-25 00:00:01','YYYY-MM-DD HH24:MI:SS') 
and billtime<=TO_DATE('2018-01-03 16:59:59','YYYY-MM-DD HH24:MI:SS') ;
