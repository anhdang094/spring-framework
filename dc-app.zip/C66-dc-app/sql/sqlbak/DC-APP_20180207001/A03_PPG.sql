-- Add comments to the columns
comment on column ORDERS_LOG.flag
  is '触发次数，重跑一次加1，定时任务正常时为0';
comment on column ORDERS_LOG.log_type
  is '日志类型：0 失败，1 成功';
comment on column ORDERS_LOG.error_msg
  is '错误信息';
comment on column ORDERS_LOG.task_id
  is '关联ALLOCATION_TASKS表TASK_ID';


create sequence ORDERS_PPG_SEQ
minvalue 1
maxvalue 99999999999999999
start with 1
increment by 1
cache 20;

-- Create table
create table ORDERS_PPG
(
  billno             VARCHAR2(32) not null,
  loginname          VARCHAR2(18) not null,
  agcode             VARCHAR2(18),
  top_agcode         VARCHAR2(3),
  product_id         VARCHAR2(10) not null,
  platform_id        VARCHAR2(20),
  account            NUMBER(20,4) not null,
  valid_account      NUMBER(18,2) not null,
  cus_account        NUMBER(18,4),
  previos_amount     NUMBER,
  gmcode             VARCHAR2(32),
  billtime           DATE,
  reckontime         DATE,
  flag               NUMBER(1) default 0,
  hashcode           VARCHAR2(40),
  playtype           NUMBER(4),
  currency           VARCHAR2(6),
  tablecode          VARCHAR2(100),
  round              VARCHAR2(16),
  gametype           VARCHAR2(32) not null,
  cur_ip             VARCHAR2(16),
  remark             VARCHAR2(124),
  result             VARCHAR2(64),
  card_list          VARCHAR2(196),
  exchangerate       NUMBER,
  resulttype         VARCHAR2(20),
  game_kind          NUMBER(1),
  orignal_billtime   DATE,
  orignal_reckontime DATE,
  orignal_timezone   VARCHAR2(10),
  creation_time      DATE default SYSDATE,
  currency_type      NUMBER(1) default 0,
  id                 NUMBER(22),
  device_type        VARCHAR2(6) default '0',
  is_special_game    NUMBER(1) default 0,
  bonus_amount       NUMBER default 0 not null,
  remain_amount      NUMBER not null
);
-- Add comments to the columns
comment on column ORDERS_PPG.billno
  is '游戏局号(不再是流水号)';
comment on column ORDERS_PPG.loginname
  is '会员账号，不带productId';
comment on column ORDERS_PPG.product_id
  is '产品编号';
comment on column ORDERS_PPG.platform_id
  is '游戏厅平台编号';
comment on column ORDERS_PPG.account
  is '投注金额';
comment on column ORDERS_PPG.valid_account
  is '有效投注金额(投注金额-撤单金额)';
comment on column ORDERS_PPG.cus_account
  is '客户输赢度:派彩金额+免费旋转奖励-投注金额';
comment on column ORDERS_PPG.previos_amount
  is '投注前金额';
comment on column ORDERS_PPG.gmcode
  is '局号';
comment on column ORDERS_PPG.billtime
  is '下注时间';
comment on column ORDERS_PPG.reckontime
  is '更新时间(派奖时间)';
comment on column ORDERS_PPG.flag
  is '0：未撤单，1：已撤单';
comment on column ORDERS_PPG.currency
  is '币别';
comment on column ORDERS_PPG.tablecode
  is '桌号';
comment on column ORDERS_PPG.round
  is '预留字段(以前是游戏局号)';
comment on column ORDERS_PPG.gametype
  is '游戏id';
comment on column ORDERS_PPG.remark
  is '备注';
comment on column ORDERS_PPG.result
  is 'Result(输赢/开牌结果)';
comment on column ORDERS_PPG.resulttype
  is '投注结果，700：投注，710：派奖，720：免费旋转派奖，702：撤单';
comment on column ORDERS_PPG.game_kind
  is '游戏类型（电子游戏为5）';
comment on column ORDERS_PPG.orignal_timezone
  is '预留字段';
comment on column ORDERS_PPG.creation_time
  is 'DC注单记录生成时间';
comment on column ORDERS_PPG.currency_type
  is '预留字段';
comment on column ORDERS_PPG.id
  is '主键id';
comment on column ORDERS_PPG.device_type
  is '用户操作客户端：0，pc端 1，移动端';
comment on column ORDERS_PPG.is_special_game
  is '0:参与洗码 1:不参与洗码';
comment on column ORDERS_PPG.bonus_amount
  is '红利金额';
comment on column ORDERS_PPG.remain_amount
  is '洗码投注额';
-- Create/Recreate indexes
create index IDX_ORDERS_PPG_BT on ORDERS_PPG (BILLTIME);
-- Create/Recreate primary, unique and foreign key constraints
alter table ORDERS_PPG
  add constraint P_K_ORDERS_PPG primary key (BILLNO, PRODUCT_ID)
  using index ;




delete from allocation_tasks where task_id in(1005,1006) and PRODUCT_ID='A03' and GAME_CODE='67';

insert into ALLOCATION_TASKS (
TASK_ID, URL, INCREMENT_BEGINTIME, INCREMENT_ENDTIME, DELAY,
PERIOD, PRODUCT_ID, PLATFORM_ID, TASK_BEGINTIME, TASK_ENDTIME,
AGCODE, PAGE_SIZE, PAGE_NO, GAME_CODE, LOGIN_NAME,
BILLNO, TABLE_CODE, PLAY_TYPE, RESULT, ACTION,
PRODUCT_TYPE, ORDER_FIELD, ORDER_WAY, FLAG, REMARK,
WEBSITE, ACCOUNT_NAME, PASSWORD, MODEL, GAME_KIND,
CURRENCY_TYPE, INVOKE_CLASS, GROUP_NAME, TIME_ZONE, DATA_DELAY)
values (
1005, 'http://data-fclrc.pai9.net/BetRecord', 1000, 300000, 10,
10, 'A03', 'order_ppg', to_date('01-02-2018 12:00:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-02-2018 12:09:59', 'dd-mm-yyyy hh24:mi:ss'),
null, 3000, null, '67', null,
null, null, null, null, null,
null, null, null, '1', 'A03 PPG注单',
null, null, null, null, '5',
null, 'main.java.com.gw.common.system.timer.Order4PPGTimer', 'GROUP3', 'Etc/GMT-8', 2);

insert into allocation_tasks
  (TASK_ID,URL,INCREMENT_BEGINTIME,INCREMENT_ENDTIME,DELAY,
   PERIOD,PRODUCT_ID,PLATFORM_ID,TASK_BEGINTIME,TASK_ENDTIME,
   AGCODE,PAGE_SIZE,PAGE_NO,GAME_CODE,LOGIN_NAME,
   BILLNO,TABLE_CODE,PLAY_TYPE,RESULT,ACTION,
   PRODUCT_TYPE,ORDER_FIELD,ORDER_WAY,FLAG,REMARK,
   WEBSITE,ACCOUNT_NAME,PASSWORD,MODEL,GAME_KIND,
   CURRENCY_TYPE,INVOKE_CLASS,GROUP_NAME,TIME_ZONE,DATA_DELAY)
values(
1006,'http://data-fclrc.pai9.net/TransferRecord',1000,300000,10,
10,'A03','trans_ppg',to_date('01-02-2018 04:00:00', 'dd-mm-yyyy hh24:mi:ss'),to_date('01-02-2018 04:04:59', 'dd-mm-yyyy hh24:mi:ss'),
null,1600,null,'67',null,
null,null,null,null,null,
null,null,null,'1','A03 PPG转帐',
null,null,null,null,'5',
null,'main.java.com.gw.common.system.timer.TransferForIOMTimer','GROUP1','Etc/GMT',2);

