-- Add/modify columns
alter table ORDERS_PPG add pro_flag number default 0;
-- Add comments to the columns
comment on column ORDERS_PPG.pro_flag
  is '0未被抓取，1处理中，2已处理';
