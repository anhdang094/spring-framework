delete from allocation_tasks where task_id in(1007,1008) and PRODUCT_ID='B01' and GAME_CODE='67';
delete from allocation_tasks where task_id in(1009,1010) and PRODUCT_ID='B07' and GAME_CODE='67';

insert into ALLOCATION_TASKS (
TASK_ID, URL, INCREMENT_BEGINTIME, INCREMENT_ENDTIME, DELAY,
PERIOD, PRODUCT_ID, PLATFORM_ID, TASK_BEGINTIME, TASK_ENDTIME,
AGCODE, PAGE_SIZE, PAGE_NO, GAME_CODE, LOGIN_NAME,
BILLNO, TABLE_CODE, PLAY_TYPE, RESULT, ACTION,
PRODUCT_TYPE, ORDER_FIELD, ORDER_WAY, FLAG, REMARK,
WEBSITE, ACCOUNT_NAME, PASSWORD, MODEL, GAME_KIND,
CURRENCY_TYPE, INVOKE_CLASS, GROUP_NAME, TIME_ZONE, DATA_DELAY)
values (
1007, 'http://data-fclrc.pai9.net/BetRecord', 0, 300000, 10,
10, 'B01', 'order_ppg', to_date('08-03-2018 12:00:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-03-2018 12:09:59', 'dd-mm-yyyy hh24:mi:ss'),
null, 3000, null, '67', null,
null, null, null, null, null,
null, null, null, '0', 'B01 PPG注单',
null, null, null, null, '5',
null, 'main.java.com.gw.common.system.timer.Order4PPGTimer', 'GROUP3', 'Etc/GMT-8', 2);

insert into allocation_tasks
  (TASK_ID,URL,INCREMENT_BEGINTIME,INCREMENT_ENDTIME,DELAY,
   PERIOD,PRODUCT_ID,PLATFORM_ID,TASK_BEGINTIME,TASK_ENDTIME,
   AGCODE,PAGE_SIZE,PAGE_NO,GAME_CODE,LOGIN_NAME,
   BILLNO,TABLE_CODE,PLAY_TYPE,RESULT,ACTION,
   PRODUCT_TYPE,ORDER_FIELD,ORDER_WAY,FLAG,REMARK,
   WEBSITE,ACCOUNT_NAME,PASSWORD,MODEL,GAME_KIND,
   CURRENCY_TYPE,INVOKE_CLASS,GROUP_NAME,TIME_ZONE,DATA_DELAY)
values(
1008,'http://data-fclrc.pai9.net/TransferRecord',0,300000,10,
10,'B01','trans_ppg',to_date('08-03-2018 04:00:00', 'dd-mm-yyyy hh24:mi:ss'),to_date('08-03-2018 04:04:59', 'dd-mm-yyyy hh24:mi:ss'),
null,1600,null,'67',null,
null,null,null,null,null,
null,null,null,'0','B01 PPG转帐',
null,null,null,null,'5',
null,'main.java.com.gw.common.system.timer.TransferForIOMTimer','GROUP1','Etc/GMT',2);

insert into ALLOCATION_TASKS (
TASK_ID, URL, INCREMENT_BEGINTIME, INCREMENT_ENDTIME, DELAY,
PERIOD, PRODUCT_ID, PLATFORM_ID, TASK_BEGINTIME, TASK_ENDTIME,
AGCODE, PAGE_SIZE, PAGE_NO, GAME_CODE, LOGIN_NAME,
BILLNO, TABLE_CODE, PLAY_TYPE, RESULT, ACTION,
PRODUCT_TYPE, ORDER_FIELD, ORDER_WAY, FLAG, REMARK,
WEBSITE, ACCOUNT_NAME, PASSWORD, MODEL, GAME_KIND,
CURRENCY_TYPE, INVOKE_CLASS, GROUP_NAME, TIME_ZONE, DATA_DELAY)
values (
1009, 'http://data-fclrc.pai9.net/BetRecord', 0, 300000, 10,
10, 'B07', 'order_ppg', to_date('08-03-2018 12:00:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-03-2018 12:09:59', 'dd-mm-yyyy hh24:mi:ss'),
null, 3000, null, '67', null,
null, null, null, null, null,
null, null, null, '0', 'B07 PPG注单',
null, null, null, null, '5',
null, 'main.java.com.gw.common.system.timer.Order4PPGTimer', 'GROUP3', 'Etc/GMT-8', 2);

insert into allocation_tasks
  (TASK_ID,URL,INCREMENT_BEGINTIME,INCREMENT_ENDTIME,DELAY,
   PERIOD,PRODUCT_ID,PLATFORM_ID,TASK_BEGINTIME,TASK_ENDTIME,
   AGCODE,PAGE_SIZE,PAGE_NO,GAME_CODE,LOGIN_NAME,
   BILLNO,TABLE_CODE,PLAY_TYPE,RESULT,ACTION,
   PRODUCT_TYPE,ORDER_FIELD,ORDER_WAY,FLAG,REMARK,
   WEBSITE,ACCOUNT_NAME,PASSWORD,MODEL,GAME_KIND,
   CURRENCY_TYPE,INVOKE_CLASS,GROUP_NAME,TIME_ZONE,DATA_DELAY)
values(
1010,'http://data-fclrc.pai9.net/TransferRecord',0,300000,10,
10,'B07','trans_ppg',to_date('08-03-2018 04:00:00', 'dd-mm-yyyy hh24:mi:ss'),to_date('08-03-2018 04:04:59', 'dd-mm-yyyy hh24:mi:ss'),
null,1600,null,'67',null,
null,null,null,null,null,
null,null,null,'0','B07 PPG转帐',
null,null,null,null,'5',
null,'main.java.com.gw.common.system.timer.TransferForIOMTimer','GROUP1','Etc/GMT',2);