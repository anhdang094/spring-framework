
<!-- 执行sql --->
update allocation_tasks set url='http://ngs.telebet88.com:3388/api/QueryBets.do',product_id='A01PHP,A02PHP,A03PHP,A04PHP,A05PHP,A06PHP,C01PHP',
password='{"A01PHP":"hsS7NagMsR7seG27","A02PHP":"@p*as=U8AZdFEbxr","A03PHP":"vHxHH+YhW$kKsHVp","A04PHP":"(e)#(ZY@Bd-cT$#-","A05PHP":"K+wZ@WTa#7MYn.gw","A06PHP":"kbzq(cHS)yGB2)3R","C01PHP":"pS)QzXS))CqY7k#r"}'
where task_id=94


<!-- 回滚sql --->
update allocation_tasks set url='http://ngs.telebet88.com:3388/api/dataCenter_queryBetList.net',product_id='A01,A02,A03,A04,A05,A06,C01,A01PHP,A02PHP,A03PHP,A04PHP,A05PHP,A06PHP,C01PHP',
password='CuDBSdxRVgftZQrMv8pbA4TSn6eSPvrYy6YqxfUAaGx9nxtDMxBQKCnsaHZ2BVSf'
where task_id=94