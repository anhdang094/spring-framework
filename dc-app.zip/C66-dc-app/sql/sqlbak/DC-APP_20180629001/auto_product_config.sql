ALTER TABLE ALLOCATION_TASKS add GAME_TYPE smallint default 0 null;
COMMENT ON COLUMN ALLOCATION_TASKS.GAME_TYPE IS '0:非电子货币包 1:电子货币包';

ALTER TABLE ALLOCATION_TASKS ADD TARGET_TABLE VARCHAR2(50) DEFAULT ''  NULL;
COMMENT ON COLUMN ALLOCATION_TASKS.TARGET_TABLE IS '指定注单储存 table';

ALTER TABLE TRANSFER_ACCOUNT_LOG add GAME_TYPE smallint default 0 null;
COMMENT ON COLUMN TRANSFER_ACCOUNT_LOG.GAME_TYPE IS '0:非电子货币包 1:电子货币包';

update ALLOCATION_TASKS
set game_type=1
where PLATFORM_ID in ('trans_vmg','trans_rgs','trans_bsg','trans_bsg_vip','trans_mg_vip','trans_amayaVip_fclrc','trans_sbt','trans_png','trans_netent','trans_ppg','trans_ysb','trans_nb');

update TRANSFER_ACCOUNT_LOG
set game_type=1
where PLATFORM_ID in
(
'053', --trans_amayaVip_fclrc
'046', --trans_rgs
'051', --trans_bsg
'055', --trans_bsg_vip
'054', --trans_mg_vip
'062', --trans_sbt
'052', --trans_png
'065', --trans_netent
'067', --trnas_ppg
'068', -- trans_ysb
'069' --trans_nb
);