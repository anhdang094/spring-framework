-- Create table
create table T_LOGIN_LOG
(
  product_id       VARCHAR2(200) not null,
  loginname        VARCHAR2(500) not null,
  endpoint_type    NUMBER,
  login_date_start DATE not null,
  login_date_end   DATE,
  platform         VARCHAR2(200) not null
)

-- Add comments to the columns
comment on column T_LOGIN_LOG.product_id
  is '产品ID号';
comment on column T_LOGIN_LOG.loginname
  is '登陆姓名';
comment on column T_LOGIN_LOG.endpoint_type
  is '登陆类型';
comment on column T_LOGIN_LOG.login_date_start
  is '登陆开始时间';
comment on column T_LOGIN_LOG.login_date_end
  is '登陆结束时间';
comment on column T_LOGIN_LOG.platform
  is '登陆类型';
-- Create/Recreate primary, unique and foreign key constraints
alter table T_LOGIN_LOG
  add constraint T_LOGIN_LOG_PK primary key (PRODUCT_ID, LOGINNAME, LOGIN_DATE_START, PLATFORM)

