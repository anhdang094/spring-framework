alter table ORDERS_AP modify creation_time default SYSDATE;

DECLARE
TYPE t_id
IS
  TABLE OF VARCHAR2(100) INDEX BY BINARY_INTEGER;
  v_t_id t_id;
  CURSOR c
  IS
    SELECT a.ROWID ROW_ID FROM orders_AP a WHERE  a.creation_time is NULL and a.billtime>sysdate-1 order by a.billtime;
BEGIN
  OPEN c;
  LOOP
    FETCH c bulk collect INTO v_t_id LIMIT 10000;
    FORALL i IN 1 .. v_t_id.COUNT
    UPDATE orders_AP t set t.creation_time=t.billtime 
    WHERE ROWID           = v_t_id(i);
    --   提交
    COMMIT;
    --	 休眠30秒
    dbms_lock.sleep(30);
    --   循环退出
    EXIT
  WHEN c%NOTFOUND;
  END LOOP;
  COMMIT;
END;


 
