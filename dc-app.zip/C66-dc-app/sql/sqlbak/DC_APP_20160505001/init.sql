-- 删除  TABLE ORDERS_VMG
DECLARE
  num1 number;
BEGIN
  SELECT count(1) INTO num1 FROM all_tables WHERE TABLE_NAME = 'ORDERS_VMG';
  IF num1 > 0 then
    EXECUTE IMMEDIATE 'DROP TABLE ORDERS_VMG';
  END IF;
END;

-- 删除  sequence ORDERS_VMG_SEQ
DECLARE
  num1 number;
BEGIN
  SELECT count(1) INTO num1 FROM user_sequences WHERE sequence_name = 'ORDERS_VMG_SEQ';
  IF num1 > 0 then
    EXECUTE IMMEDIATE 'DROP sequence ORDERS_VMG_SEQ';
  END IF;
END;


DELETE from ALLOCATION_TASKS where TASK_ID in (651,652);

-- Create table
create table ORDERS_VMG
(
  billno             VARCHAR2(50) not null,
  loginname          VARCHAR2(18),
  agcode             VARCHAR2(18),
  top_agcode         VARCHAR2(3),
  product_id         VARCHAR2(10) not null,
  platform_id        VARCHAR2(20),
  account            NUMBER(20,4),
  valid_account      NUMBER(18,2),
  cus_account        NUMBER(18,4),
  previos_amount     NUMBER,
  gmcode             VARCHAR2(14),
  billtime           DATE,
  reckontime         DATE,
  flag               NUMBER(1),
  hashcode           VARCHAR2(40),
  playtype           NUMBER(4),
  currency           VARCHAR2(6),
  tablecode          VARCHAR2(100),
  round              VARCHAR2(16),
  gametype           VARCHAR2(6),
  cur_ip             VARCHAR2(16),
  remark             VARCHAR2(124),
  result             VARCHAR2(64),
  card_list          VARCHAR2(196),
  exchangerate       NUMBER,
  resulttype         VARCHAR2(20),
  game_kind          NUMBER(1),
  orignal_billtime   DATE,
  orignal_reckontime DATE,
  orignal_timezone   VARCHAR2(10),
  creation_time      DATE default SYSTIMESTAMP not null,
  currency_type      NUMBER(1),
  id                 NUMBER(22),
  device_type        VARCHAR2(6) default '0',
  is_special_game    NUMBER(1) default 0
);
-- Add comments to the columns 
comment on column ORDERS_VMG.device_type
  is '0表示是电脑下注';
comment on column ORDERS_VMG.is_special_game
  is '0:参与洗码 1:不参与洗码';

comment on column ORDERS_VMG.account
  is 'BetAmount(下注金额)';
comment on column ORDERS_VMG.valid_account
  is 'Commissionable(实际投注金额)';
comment on column ORDERS_VMG.cus_account
  is 'Payoff(派彩金额)';
-- Create/Recreate primary, unique and foreign key constraints
alter table ORDERS_VMG
  add constraint PK_ORDERS_VMG primary key (BILLNO, PRODUCT_ID);



create sequence ORDERS_VMG_SEQ
minvalue 1
maxvalue 99999999999999999
start with 61
increment by 1
cache 20
order;




-- for C04 MG
insert into ALLOCATION_TASKS (TASK_ID, URL, INCREMENT_BEGINTIME, INCREMENT_ENDTIME, DELAY, PERIOD, PRODUCT_ID, PLATFORM_ID, TASK_BEGINTIME, TASK_ENDTIME, AGCODE, PAGE_SIZE, PAGE_NO, GAME_CODE, LOGIN_NAME, BILLNO, TABLE_CODE, PLAY_TYPE, RESULT, ACTION, PRODUCT_TYPE, ORDER_FIELD, ORDER_WAY, FLAG, REMARK, WEBSITE, ACCOUNT_NAME, PASSWORD, MODEL, GAME_KIND, CURRENCY_TYPE)
values (651, 'http://data-fclrc.pai9.net/BetRecord', 1000, 600000, 9000, 3000, 'C04', 'order_vmg', to_date('22-02-2016 05:00:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('22-02-2016 05:04:59', 'dd-mm-yyyy hh24:mi:ss'), null, 800, null, null, null, null, null, null, null, null, null, null, null, '1', 'C04 VMG注单', null, null, null, '1', '5', null);

insert into ALLOCATION_TASKS (TASK_ID, URL, INCREMENT_BEGINTIME, INCREMENT_ENDTIME, DELAY, PERIOD, PRODUCT_ID, PLATFORM_ID, TASK_BEGINTIME, TASK_ENDTIME, AGCODE, PAGE_SIZE, PAGE_NO, GAME_CODE, LOGIN_NAME, BILLNO, TABLE_CODE, PLAY_TYPE, RESULT, ACTION, PRODUCT_TYPE, ORDER_FIELD, ORDER_WAY, FLAG, REMARK, WEBSITE, ACCOUNT_NAME, PASSWORD, MODEL, GAME_KIND, CURRENCY_TYPE)
values (652, 'http://data-fclrc.pai9.net/TransferRecord', 1000, 600000, 9000, 3000, 'C04', 'trans_vmg', to_date('22-02-2016 04:55:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('22-02-2016 04:59:59', 'dd-mm-yyyy hh24:mi:ss'), null, 800, null, null, null, null, null, null, null, null, null, null, null, '1', 'C04 VMG转帐', null, null, null, null, '5', null);

