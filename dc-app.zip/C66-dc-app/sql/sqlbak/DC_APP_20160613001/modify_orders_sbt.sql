-- Add/modify columns 
alter table ORDERS_SBT modify home_team VARCHAR2(50);
alter table ORDERS_SBT modify away_team VARCHAR2(50);
-- Add/modify columns 
alter table ORDERS_SBT modify billno VARCHAR2(50);
-- Add/modify columns 
alter table ORDERS_SBT modify game_kind NUMBER;

