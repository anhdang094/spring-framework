create table  ORDERS_MG_VIP as select * from orders_mg t where 1=-1;
create table  ORDERS_AMAYA_VIP as select * from ORDERS_AMAYA t where 1=-1;
alter table ORDERS_MG_VIP  add constraint PK_ORDERS_MG_VIP_BILL_PROD primary key (BILLNO, PRODUCT_ID);
alter table ORDERS_AMAYA_VIP  add constraint PK_ORDERS_AMAYA_VIP_BILL_PROD primary key (BILLNO, PRODUCT_ID);
create sequence ORDERS_AMAYA_VIP_SEQ;
create sequence ORDERS_MG_VIP_SEQ;