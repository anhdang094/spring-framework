-- Add/modify columns 
alter table ORDERS_AG modify remark VARCHAR2(500);