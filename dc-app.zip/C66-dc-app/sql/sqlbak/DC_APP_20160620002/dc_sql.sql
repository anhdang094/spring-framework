--添加w88lottery 任务定义
insert into allocation_tasks (TASK_ID, URL, INCREMENT_BEGINTIME, INCREMENT_ENDTIME, DELAY, PERIOD, PRODUCT_ID, PLATFORM_ID, TASK_BEGINTIME, TASK_ENDTIME, AGCODE, PAGE_SIZE, PAGE_NO, GAME_CODE, LOGIN_NAME, BILLNO, TABLE_CODE, PLAY_TYPE, RESULT, ACTION, PRODUCT_TYPE, ORDER_FIELD, ORDER_WAY, FLAG, REMARK, WEBSITE, ACCOUNT_NAME, PASSWORD, MODEL, GAME_KIND, CURRENCY_TYPE)
values (662, 'http://lottery.test.com/api/newBetDetail', 1000, 600000, 9000, 3000, 'ALL', 'order_w88lottery', to_date('29-05-2016 10:20:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('29-05-2016 10:29:59', 'dd-mm-yyyy hh24:mi:ss'), '', 400, null, null, null, null, null, null, 'lottery', null, null, null, null, '1', 'W88Lottery注单', '', '', '', '1', '12', null);


--修改orders_log的url字段长度
alter table ORDERS_LOG modify url VARCHAR2(300);






-- 删除  TABLE ORDERS_VMG
DECLARE
  num1 number;
BEGIN
  SELECT count(1) INTO num1 FROM all_tables WHERE TABLE_NAME = 'T_PARAMS';
  IF num1 > 0 then
    EXECUTE IMMEDIATE 'DROP TABLE T_PARAMS';
  END IF;
END;
/
-- 删除  sequence SEQ_T_PARAMS
DECLARE
  num1 number;
BEGIN
  SELECT count(1) INTO num1 FROM user_sequences WHERE sequence_name = 'SEQ_T_PARAMS';
  IF num1 > 0 then
    EXECUTE IMMEDIATE 'DROP sequence SEQ_T_PARAMS';
  END IF;
END;
/


-- Create sequence
create sequence SEQ_T_PARAMS
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;


create table T_PARAMS
(
  id         NUMBER not null,
  name       VARCHAR2(100),
  value      VARCHAR2(1000),
  enable     NUMBER,
  desctxt    VARCHAR2(1000) not null,
  p_type     VARCHAR2(200),
  task_id    NUMBER,
  dynamical  NUMBER,
  product_id VARCHAR2(10),
  key_name   VARCHAR2(200)
);
-- Add comments to the table
comment on table T_PARAMS
  is '数据抓取接口配置参数';
-- Add comments to the columns
comment on column T_PARAMS.p_type
  is 'QUERY,PROVIDED,OUT';
comment on column T_PARAMS.task_id
  is '任务ID';
comment on column T_PARAMS.dynamical
  is 'yes-1,no-0,参数是变化的，参数类型为QUERY时才可能变化';
comment on column T_PARAMS.product_id
  is '产品ID';
comment on column T_PARAMS.key_name
  is '程序中要用的变量标识名称,';

alter table T_PARAMS
  add constraint PK_PARAMS_ID primary key (ID);

alter table T_PARAMS
  add constraint UK_PARAMS unique (NAME, TASK_ID, PRODUCT_ID);


insert into T_PARAMS (ID, NAME, VALUE, ENABLE, DESCTXT, P_TYPE, TASK_ID, DYNAMICAL, PRODUCT_ID, KEY_NAME)
values (SEQ_T_PARAMS.NEXTVAL, 'page_num', '1', 1, '第几页', 'QUERY', 662, 1, 'A04', 'page');

insert into T_PARAMS (ID, NAME, VALUE, ENABLE, DESCTXT, P_TYPE, TASK_ID, DYNAMICAL, PRODUCT_ID, KEY_NAME)
values (SEQ_T_PARAMS.NEXTVAL, 'date_to', '2016-05-29 10:20:00', 1, '结束时间,格式2016-01-01 10:10:10', 'QUERY', 662, 1, 'A04', 'endtime');

insert into T_PARAMS (ID, NAME, VALUE, ENABLE, DESCTXT, P_TYPE, TASK_ID, DYNAMICAL, PRODUCT_ID, KEY_NAME)
values (SEQ_T_PARAMS.NEXTVAL, 'date_from', '2016-05-29 10:29:59', 1, '开始时间,格式2016-01-01 10:10:10', 'QUERY', 662, 1, 'A04', 'begintime');

insert into T_PARAMS (ID, NAME, VALUE, ENABLE, DESCTXT, P_TYPE, TASK_ID, DYNAMICAL, PRODUCT_ID, KEY_NAME)
values (SEQ_T_PARAMS.NEXTVAL, 'merch_id', 'D88', 1, '代理用户名', 'QUERY', 662, 0, 'A04', '');

insert into T_PARAMS (ID, NAME, VALUE, ENABLE, DESCTXT, P_TYPE, TASK_ID, DYNAMICAL, PRODUCT_ID, KEY_NAME)
values (SEQ_T_PARAMS.NEXTVAL, 'merch_pwd', '8EE3D692-6759-4D34-89CE-F10727A2FDA2', 1, '代理密码', 'QUERY', 662, 0, 'A04', '');

insert into T_PARAMS (ID, NAME, VALUE, ENABLE, DESCTXT, P_TYPE, TASK_ID, DYNAMICAL, PRODUCT_ID, KEY_NAME)
values (SEQ_T_PARAMS.NEXTVAL, 'page_size', '400', 1, '每页数据大小', 'QUERY', 662, 0, 'A04', 'num');

