
UPDATE allocation_tasks t SET t.password='iQ3xuZrS'  WHERE t.task_id IN(128,260);