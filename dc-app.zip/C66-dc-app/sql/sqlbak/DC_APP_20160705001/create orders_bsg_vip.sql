-- Create sequence
create sequence ORDERS_BSG_VPI_SEQ;
 
  -- Create table
create table ORDERS_BSG_VIP
(
  billno             VARCHAR2(32) not null,
  loginname          VARCHAR2(18),
  agcode             VARCHAR2(18),
  top_agcode         VARCHAR2(3),
  product_id         VARCHAR2(10) not null,
  platform_id        VARCHAR2(20),
  account            NUMBER(20,4),
  valid_account      NUMBER(18,2),
  cus_account        NUMBER(18,4),
  previos_amount     NUMBER,
  gmcode             VARCHAR2(14),
  billtime           DATE,
  reckontime         DATE,
  flag               NUMBER(1),
  hashcode           VARCHAR2(40),
  playtype           NUMBER(4),
  currency           VARCHAR2(6),
  tablecode          VARCHAR2(100),
  round              VARCHAR2(16),
  gametype           VARCHAR2(6),
  cur_ip             VARCHAR2(16),
  remark             VARCHAR2(124),
  result             VARCHAR2(64),
  card_list          VARCHAR2(196),
  exchangerate       NUMBER,
  resulttype         VARCHAR2(20),
  game_kind          NUMBER(1),
  orignal_billtime   DATE,
  orignal_reckontime DATE,
  orignal_timezone   VARCHAR2(10),
  creation_time      DATE default SYSDATE,
  currency_type      NUMBER(1),
  id                 NUMBER(22),
  device_type        VARCHAR2(6),
  is_special_game    NUMBER(1),
  bonus_amount       NUMBER default 0 not null
);
-- Create/Recreate primary, unique and foreign key constraints 
alter table ORDERS_BSG_VIP
  add constraint PK_ORDERS_BSG_VIP_BILL_PROD primary key (BILLNO, PRODUCT_ID);

 
