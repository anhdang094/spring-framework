   -- BSG VIP orders
insert into ALLOCATION_TASKS (TASK_ID, URL, INCREMENT_BEGINTIME, INCREMENT_ENDTIME, DELAY, PERIOD, PRODUCT_ID, PLATFORM_ID, TASK_BEGINTIME, TASK_ENDTIME, AGCODE, PAGE_SIZE, PAGE_NO, GAME_CODE, LOGIN_NAME, BILLNO, TABLE_CODE, PLAY_TYPE, RESULT, ACTION, PRODUCT_TYPE, ORDER_FIELD, ORDER_WAY, FLAG, REMARK, WEBSITE, ACCOUNT_NAME, PASSWORD, MODEL, GAME_KIND, CURRENCY_TYPE)
values (664, 'http://10.66.66.49:8081/commonwallet_datacenter/BSGBetRecord.do', 1000, 600000, 14000, 3000, 'A03,B01', 'order_bsg_vip', to_date('30-06-2016 01:15:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('30-06-2016 01:19:59', 'dd-mm-yyyy hh24:mi:ss'), '', 1600, null, '85', '', '', '', '', '', '', '', '', '', '1', 'orders bsg_vip注单', '', '', '', '', '5', null);

insert into ALLOCATION_TASKS (TASK_ID, URL, INCREMENT_BEGINTIME, INCREMENT_ENDTIME, DELAY, PERIOD, PRODUCT_ID, PLATFORM_ID, TASK_BEGINTIME, TASK_ENDTIME, AGCODE, PAGE_SIZE, PAGE_NO, GAME_CODE, LOGIN_NAME, BILLNO, TABLE_CODE, PLAY_TYPE, RESULT, ACTION, PRODUCT_TYPE, ORDER_FIELD, ORDER_WAY, FLAG, REMARK, WEBSITE, ACCOUNT_NAME, PASSWORD, MODEL, GAME_KIND, CURRENCY_TYPE)
values (665, 'http://10.66.66.49:8081/commonwallet_datacenter/BSGBetRecord.do', 1000, 600000, 14000, 3000, 'A01,A02,A04,A05,A06,C01,C02,E02,E03,E04', 'order_bsg_vip', to_date('30-06-2016 01:15:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('30-06-2016 01:19:59', 'dd-mm-yyyy hh24:mi:ss'), '', 1600, null, '85', '', '', '', '', '', '', '', '', '', '1', 'orders bsg_vip注单', '', '', '', '', '5', null);

   -- BSG VIP Transfer
insert into ALLOCATION_TASKS (TASK_ID, URL, INCREMENT_BEGINTIME, INCREMENT_ENDTIME, DELAY, PERIOD, PRODUCT_ID, PLATFORM_ID, TASK_BEGINTIME, TASK_ENDTIME, AGCODE, PAGE_SIZE, PAGE_NO, GAME_CODE, LOGIN_NAME, BILLNO, TABLE_CODE, PLAY_TYPE, RESULT, ACTION, PRODUCT_TYPE, ORDER_FIELD, ORDER_WAY, FLAG, REMARK, WEBSITE, ACCOUNT_NAME, PASSWORD, MODEL, GAME_KIND, CURRENCY_TYPE)
values (662, 'http://10.66.66.49:8081/commonwallet_datacenter/BSGTransferRecord', 1000, 600000, 9000, 3000, 'A03,B01', 'trans_bsg_vip', to_date('30-06-2016 01:40:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('30-06-2016 01:44:59', 'dd-mm-yyyy hh24:mi:ss'), '', 1600, null, '85', '', '', '', '', '', '', '', '', '', '1', 'A03,B01 BSG_VIP转帐', '', '', '', '', '5', null);

insert into ALLOCATION_TASKS (TASK_ID, URL, INCREMENT_BEGINTIME, INCREMENT_ENDTIME, DELAY, PERIOD, PRODUCT_ID, PLATFORM_ID, TASK_BEGINTIME, TASK_ENDTIME, AGCODE, PAGE_SIZE, PAGE_NO, GAME_CODE, LOGIN_NAME, BILLNO, TABLE_CODE, PLAY_TYPE, RESULT, ACTION, PRODUCT_TYPE, ORDER_FIELD, ORDER_WAY, FLAG, REMARK, WEBSITE, ACCOUNT_NAME, PASSWORD, MODEL, GAME_KIND, CURRENCY_TYPE)
values (663, 'http://10.66.66.49:8081/commonwallet_datacenter/BSGTransferRecord', 1000, 600000, 9000, 3000, 'A01,A02,A04,A05,A06,C01,C02,E02,E03,E04', 'trans_bsg_vip', to_date('30-06-2016 01:40:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('30-06-2016 01:44:59', 'dd-mm-yyyy hh24:mi:ss'), '', 1600, null, '85', '', '', '', '', '', '', '', '', '', '1', '非A03,B01 BSG_VIP转帐
', '', '', '', '', '5', null);


    -- update orders
update ALLOCATION_TASKS set PLATFORM_ID='order_bsg' where task_id in ('645','646'); 
update ALLOCATION_TASKS set GAME_CODE='5' where task_id in ('645','646','647','648'); 
