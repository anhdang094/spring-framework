

---------   PT Begin --------------------------------

update  ALLOCATION_TASKS set order_field='' where task_id = '128' or task_id = '260';

update  ALLOCATION_TASKS set agcode = 'A01_68ec1136022ff42a26af2c0e684ff9cc5be796816a029bec244df869997fb46f7cf0283b4c97328043cbbd0106fd50a5389339243426cce0dc39a3f70b9a7d10,A02_93d11310a8ea8b38cfb9177b95f8622a36b4e26898d9ba1ea37003797c7ea036d5db83b359b99787e75d8a34dd21dc272ec98630ea48f2a6ae081110510b7ba1,A03_460aea217ec9cddfd0484d35f467f0874c1ce0596db799de63cdf92640eebd6d95b4e21941a0d0bb710420504933a03c0117d41d3a35306c69d0867d1fa3a660,A04_0261bfe36f523798c0e69dc28ff3e7477962034d3b5f2220ca23659285ddab3e01e036aca1fb493edbeda8e3e8849f0b0462b7aa48849fcc311912ce619ece15,A05_2c3089c668920e96bd0759ec712c7e2c38ee8bd26da2793fb083850f43a05daf537dea09e83243eef34497059c271f1715531af8970420dee8c54dba57afc0a4,A06_400e6e6d4dfd9d9285017cf7b89430b4ef3c3c220c866f70fe3fa1eb357ab004cf87090a7f96355eeb7d5cab3a1fd131276bd2bbd837474f9f305494bafea468,B01_6bc004110e9b96036b6e2afa75415d653dd59c99425c8e47749c98d5b1dd29f607d946b52a796b04d2d6ba8cfa9a81d609ab2751872e0608b9b19b3c599c79a3,C01_9cdf10fe20ab1a37cdf3de34fc0aba830a5bee0a785fcbebeaf89e0bcc39224c4a0e1d54e38c9919053fcd395a213ea9e21a19152ba96eb851ec298d11988cf8,C02_257effa5f8981b40b7c5851b976690d3b498000ecb3a705752c80c80a715bdfced1523e9a1c30985827025aec161ec6eb9e3c28f4a732fb656ce05672c3b0eed,E02_da4833d6100de6c989beff2d6ca9d0112456eeb0c5869780f0ba6058a0a1fd940290e791a1ea4b2a0a7735a14173ad506746e0da0c8cda238c694c9056d07c4b,E03_6c4b340c5418eeee568fb21dabdc34ada986d47c6c9bfa151d4320f43019cb4a4faaf44643311da4ab43475a12dd7dc4a20e489316dd60647c5a653caa236498,E04_31bbf89ff3c31eb07ed8725cea2fa40dd87c5bb7ca8e2391cbc879474d27bcbd34092cdfaf093fc552d419d334acd7c1678df05b7015150dc3a77a2734a3f9cd' where task_id = '128' or task_id = '260';


---------   PT End --------------------------------

---------   TTG(Amaya) Begin --------------------------------

update  ALLOCATION_TASKS set product_id = 'A01,A02,A04,A05,A06,C01,C02,E02,E03,E04' where task_id = '637' or task_id = '639';

---------   TTG(Amaya) End --------------------------------

---------   MG Begin --------------------------------

update  ALLOCATION_TASKS set product_id = 'A01,A02,A04,A05,A06,C01,C02,E02,E03,E04' where task_id = '636' or task_id = '638';

---------   MG End --------------------------------