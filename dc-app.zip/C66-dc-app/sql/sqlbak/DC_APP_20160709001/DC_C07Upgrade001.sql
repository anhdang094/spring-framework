---------   PT Begin --------------------------------

update  ALLOCATION_TASKS set order_field='7nvENJPc' where task_id = '128' or task_id = '260';

update  ALLOCATION_TASKS set agcode = agcode||',C07_f651955092be3dac82c4ed2c4e31fd14000f29c5f4290c3788effc454c83f49d9dfa941ae106e4a8cad5babe7cf6161045135aac354057d0bd89b75c2146dcfb' where task_id = '128' or task_id = '260';

---------   PT End --------------------------------

---------   TTG(Amaya) Begin --------------------------------

update  ALLOCATION_TASKS set product_id = product_id||',C07' where task_id = '637' or task_id = '639';

---------   TTG(Amaya) End --------------------------------

---------   MG Begin --------------------------------

update  ALLOCATION_TASKS set product_id = product_id||',C07' where task_id = '636' or task_id = '638';

---------   MG End --------------------------------