UPDATE ALLOCATION_TASKS T
   SET T.INVOKE_CLASS = 'main.java.com.gw.common.system.timer.Order4AGINFishGameTimer',
       T.TIME_ZONE    = 'Etc/GMT-8',
       T.GROUP_NAME   = 'GROUP2'
 WHERE T.TASK_ID IN
       (114, 130, 133, 134, 135, 136, 137, 138, 158, 159, 162, 163, 653);