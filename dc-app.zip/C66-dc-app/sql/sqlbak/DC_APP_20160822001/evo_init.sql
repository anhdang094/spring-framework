insert into ALLOCATION_TASKS (TASK_ID, URL, INCREMENT_BEGINTIME, INCREMENT_ENDTIME, DELAY, PERIOD, PRODUCT_ID, PLATFORM_ID, TASK_BEGINTIME, TASK_ENDTIME, AGCODE, PAGE_SIZE, PAGE_NO, GAME_CODE, LOGIN_NAME, BILLNO, TABLE_CODE, PLAY_TYPE, RESULT, ACTION, PRODUCT_TYPE, ORDER_FIELD, ORDER_WAY, FLAG, REMARK, WEBSITE, ACCOUNT_NAME, PASSWORD, MODEL, GAME_KIND, CURRENCY_TYPE,INVOKE_CLASS, GROUP_NAME, TIME_ZONE, DATA_DELAY)
values (667, 'http://localhost:8080/cwdc/BetRecord', 1000, 600000, 60, 60, 'C04', 'order_evo', to_date('14-07-2016 05:00:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('14-07-2016 05:04:59', 'dd-mm-yyyy hh24:mi:ss'), '', 800, null, '', '', '', '', '', '', '', '', '', '', '0', 'C04 EVO 注单', '', '', '', '1', '3', null,'main.java.com.gw.common.system.timer.Order4EVOTimer', 'C04', 'Etc/GMT', 1);

insert into ALLOCATION_TASKS (TASK_ID, URL, INCREMENT_BEGINTIME, INCREMENT_ENDTIME, DELAY, PERIOD, PRODUCT_ID, PLATFORM_ID, TASK_BEGINTIME, TASK_ENDTIME, AGCODE, PAGE_SIZE, PAGE_NO, GAME_CODE, LOGIN_NAME, BILLNO, TABLE_CODE, PLAY_TYPE, RESULT, ACTION, PRODUCT_TYPE, ORDER_FIELD, ORDER_WAY, FLAG, REMARK, WEBSITE, ACCOUNT_NAME, PASSWORD, MODEL, GAME_KIND, CURRENCY_TYPE,INVOKE_CLASS, GROUP_NAME, TIME_ZONE, DATA_DELAY)
values (668, 'http://localhost:8080/cwdc/TransferRecord', 1000, 600000, 60, 60, 'C04', 'trans_evo', to_date('14-07-2016 00:00:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('14-07-2016 00:04:59', 'dd-mm-yyyy hh24:mi:ss'), '', 800, null, '', '', '', '', '', '', '', '', '', '', '0', 'C04 EVO 转帐', '', '', '', '', '3', null,'main.java.com.gw.common.system.timer.TransferForIOMTimer', 'C04', 'Etc/GMT', 1);






create sequence ORDERS_EVO_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;



insert into t_params (ID, NAME, VALUE, ENABLE, DESCTXT, P_TYPE, TASK_ID, DYNAMICAL, PRODUCT_ID, KEY_NAME)
values (ORDERS_EVO_SEQ.NEXTVAL, 'productId', 'C04', 1, '产品ID', 'QUERY', 667, 0, 'C04', '');

insert into t_params (ID, NAME, VALUE, ENABLE, DESCTXT, P_TYPE, TASK_ID, DYNAMICAL, PRODUCT_ID, KEY_NAME)
values (ORDERS_EVO_SEQ.NEXTVAL, 'starttime', '2016-07-13 00:00:00', 1, '查询开始时间', 'QUERY', 667, 1, 'C04', 'begintime');

insert into t_params (ID, NAME, VALUE, ENABLE, DESCTXT, P_TYPE, TASK_ID, DYNAMICAL, PRODUCT_ID, KEY_NAME)
values (ORDERS_EVO_SEQ.NEXTVAL, 'endtime', '2016-07-13 00:09:59', 1, '查询结束时间', 'QUERY', 667, 1, 'C04', 'endtime');

insert into t_params (ID, NAME, VALUE, ENABLE, DESCTXT, P_TYPE, TASK_ID, DYNAMICAL, PRODUCT_ID, KEY_NAME)
values (ORDERS_EVO_SEQ.NEXTVAL, 'page', '1', 1, '第几页', 'QUERY', 667, 1, 'C04', 'page');

insert into t_params (ID, NAME, VALUE, ENABLE, DESCTXT, P_TYPE, TASK_ID, DYNAMICAL, PRODUCT_ID, KEY_NAME)
values (ORDERS_EVO_SEQ.NEXTVAL, 'pagelimit', '800', 1, '分页大小', 'QUERY', 667, 0, 'C04', 'num');

insert into t_params (ID, NAME, VALUE, ENABLE, DESCTXT, P_TYPE, TASK_ID, DYNAMICAL, PRODUCT_ID, KEY_NAME)
values (ORDERS_EVO_SEQ.NEXTVAL, 'gameCode', '7', 1, '7表示是EVOlution游戏', 'QUERY', 667, 0, 'C04', '');

insert into t_params (ID, NAME, VALUE, ENABLE, DESCTXT, P_TYPE, TASK_ID, DYNAMICAL, PRODUCT_ID, KEY_NAME)
values (ORDERS_EVO_SEQ.NEXTVAL, 'key', '123456', 1, 'api  参数', 'QUERY', 667, 0, 'C04', '');
