UPDATE  ALLOCATION_TASKS T SET T.GROUP_NAME  = 'C04',T.INVOKE_CLASS ='main.java.com.gw.common.system.timer.Order4VMGTimer',T.TIME_ZONE = 'Etc/GMT',
T.DELAY = 60,T.PERIOD=60,T.DATA_DELAY  = 5,T.FLAG = 0 WHERE T.TASK_ID = 651 ;

UPDATE  ALLOCATION_TASKS T SET T.GROUP_NAME  = 'C04',T.INVOKE_CLASS ='main.java.com.gw.common.system.timer.TransferForIOMTimer',T.TIME_ZONE = 'Etc/GMT',
T.DELAY = 60,T.PERIOD=60,T.DATA_DELAY  = 5,T.FLAG = 1 WHERE T.TASK_ID = 652 ;


insert into allocation_tasks (TASK_ID, URL, INCREMENT_BEGINTIME, INCREMENT_ENDTIME, DELAY, PERIOD, PRODUCT_ID, PLATFORM_ID, TASK_BEGINTIME, TASK_ENDTIME, AGCODE, PAGE_SIZE, PAGE_NO, GAME_CODE, LOGIN_NAME, BILLNO, TABLE_CODE, PLAY_TYPE, RESULT, ACTION, PRODUCT_TYPE, ORDER_FIELD, ORDER_WAY, FLAG, REMARK, WEBSITE, ACCOUNT_NAME, PASSWORD, MODEL, GAME_KIND, CURRENCY_TYPE, INVOKE_CLASS, GROUP_NAME, TIME_ZONE, DATA_DELAY)
values (717, 'C04 VMG 错误注单处理', 651, 651, 9, 3, 'C04', 'order_vmg', to_date('22-02-2016 05:00:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('22-02-2016 05:04:59', 'dd-mm-yyyy hh24:mi:ss'), '', 800, null, '', '', '', '', '', '', '', '', '', '', '0', 'C04 VMG注单异常注单同步', '', '', '', '1', '5', null, 'main.java.com.gw.common.system.timer.ErrorLog4OrderTimer', 'C04', 'Etc/GMT', 5);

