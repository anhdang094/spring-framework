--注意用线上的地址替换，升级麻烦确认一下游戏那边的这个接口是否上线，如没有上线，请不要升级
update allocation_tasks t set t.url ='http://pb.gw688.com:3336/getbonusorders.xml' where t.task_id = 3;