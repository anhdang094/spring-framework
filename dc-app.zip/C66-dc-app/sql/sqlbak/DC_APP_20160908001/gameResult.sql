-- Add/modify columns 
alter table GAMERESULT_BAGAME modify bankerpoint NUMBER;
alter table GAMERESULT_BAGAME modify playerpoint NUMBER;
alter table GAMERESULT_BAGAME modify dragonpoint NUMBER;
alter table GAMERESULT_BAGAME modify tigerpoint NUMBER;
alter table GAMERESULT_BAGAME modify cardlist VARCHAR2(150);
alter table GAMERESULT_BAGAME modify pair NUMBER;
