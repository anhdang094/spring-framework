-- Add/modify columns 
alter table ORDERS_AG add is_special_game NUMBER(1) default 0;
comment on column ORDERS_AG.is_special_game is '0:参与洗码 1:不参与洗码';
-- Add/modify columns 
alter table ORDERS_SHABA add is_special_game NUMBER(1) default 0;
comment on column ORDERS_SHABA.is_special_game is '0:参与洗码 1:不参与洗码';
-- Add/modify columns 
alter table ORDERS_AP add is_special_game NUMBER(1) default 0;
comment on column ORDERS_AP.is_special_game is '0:参与洗码 1:不参与洗码';
-- Add/modify columns 
alter table ORDERS_EA add is_special_game NUMBER(1) default 0;
comment on column ORDERS_EA.is_special_game is '0:参与洗码 1:不参与洗码';
-- Add/modify columns 
alter table ORDERS_HG add is_special_game NUMBER(1) default 0;
comment on column ORDERS_HG.is_special_game is '0:参与洗码 1:不参与洗码';
-- Add/modify columns 
alter table ORDERS_K8 add is_special_game NUMBER(1) default 0;
comment on column ORDERS_K8.is_special_game is '0:参与洗码 1:不参与洗码';
-- Add/modify columns 
alter table ORDERS_TLB add is_special_game NUMBER(1) default 0;
comment on column ORDERS_TLB.is_special_game is '0:参与洗码 1:不参与洗码';
-- Add/modify columns 
alter table ORDERS_AG2 add is_special_game NUMBER(1) default 0;
comment on column ORDERS_AG2.is_special_game is '0:参与洗码 1:不参与洗码';
-- Add/modify columns 
alter table ORDERS_188 add is_special_game NUMBER(1) default 0;
comment on column ORDERS_188.is_special_game is '0:参与洗码 1:不参与洗码';
-- Add/modify columns 
alter table ORDERS_IND add is_special_game NUMBER(1) default 0;
comment on column ORDERS_IND.is_special_game is '0:参与洗码 1:不参与洗码';
-- Add/modify columns 
alter table ORDERS_GT1 add is_special_game NUMBER(1) default 0;
comment on column ORDERS_GT1.is_special_game is '0:参与洗码 1:不参与洗码';
-- Add/modify columns 
alter table ORDERS_BO add is_special_game NUMBER(1) default 0;
comment on column ORDERS_BO.is_special_game is '0:参与洗码 1:不参与洗码';
-- Add/modify columns 
alter table ORDERS_SBO add is_special_game NUMBER(1) default 0;
comment on column ORDERS_SBO.is_special_game is '0:参与洗码 1:不参与洗码';
-- Add/modify columns 
alter table ORDERS_RGS add is_special_game NUMBER(1) default 0;
comment on column ORDERS_RGS.is_special_game is '0:参与洗码 1:不参与洗码';
-- Add/modify columns 
alter table ORDERS_SBT add is_special_game NUMBER(1) default 0;
comment on column ORDERS_SBT.is_special_game is '0:参与洗码 1:不参与洗码';