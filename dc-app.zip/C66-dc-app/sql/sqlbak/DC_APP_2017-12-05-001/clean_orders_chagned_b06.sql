﻿
create table orders_changed_20171205 as select * from orders_changed t where t.product_id = 'B06' and t.pro_flag in(0,1);

update orders_changed t set t.pro_flag = 2 where t.product_id = 'B06' and t.pro_flag in(0,1);

