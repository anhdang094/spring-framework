update ALLOCATION_TASKS set page_size =0   where invoke_class = 'main.java.com.gw.common.system.timer.ErrorLog4OrderTimer';    
update ALLOCATION_TASKS set page_size =1   where task_id in ('718','719','720','721','722','723','724');
commit;