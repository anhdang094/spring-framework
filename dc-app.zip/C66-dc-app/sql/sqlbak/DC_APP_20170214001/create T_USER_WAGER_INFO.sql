-- Create sequence
create sequence ORDERS_WAGERINFO_SEQ;
 
-- Create table
create table T_USER_WAGER_INFO
(
  id               NUMBER,
  product_id       VARCHAR2(10) not null,
  platform_id      VARCHAR2(10) not null,
  login_name       VARCHAR2(30),
  bill_no          VARCHAR2(50) not null,
  billtime         DATE,
  last_update_time DATE,
  creation_time    DATE,
  bet_amount       NUMBER(20,4),
  bet_valid_amount NUMBER(20,4),
  net_amount       NUMBER(20,4),
  gmcode           VARCHAR2(20),
  type             NUMBER,
  remark           VARCHAR2(50),
  devince_type     VARCHAR2(16),
  currency         VARCHAR2(6)
)

 
