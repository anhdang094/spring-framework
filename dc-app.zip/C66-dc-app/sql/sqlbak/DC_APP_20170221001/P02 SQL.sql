--以下sql供P02平台执行使用   其他平台不要执行，谢谢
   delete ORDERS_LOG T
     WHERE T.task_id in ('774','3','52','68','92','93','111','128','136')
       AND T.CREATION_TIME >=TO_DATE('2017-02-21 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
       AND T.CREATION_TIME <=TO_DATE('2017-02-21 23:59:59', 'YYYY-MM-DD HH24:MI:SS');
       
       
    delete TRANSFER_ACCOUNT_LOG T
     WHERE T.task_id in ('653','203','219','229','259','775','136')
       AND T.CREATION_TIME >=TO_DATE('2017-02-21 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
       AND T.CREATION_TIME <=TO_DATE('2017-02-21 23:59:59', 'YYYY-MM-DD HH24:MI:SS');
       
       
update ORDERS_TGP set playtype=trim(remark);
update ORDERS_TGP set remark=null;      