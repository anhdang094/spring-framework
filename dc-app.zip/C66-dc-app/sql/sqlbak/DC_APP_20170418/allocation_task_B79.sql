INSERT INTO ALLOCATION_TASKS 
VALUES ('824', 'http://api.agg028.com/api/GetBetDetail', '1000', '300000', '5', '120', 'B79', 'order_shaba_fclrc3', TO_DATE('2017-04-11 20:00:00', 'SYYYY-MM-DD HH24:MI:SS'), TO_DATE('2017-04-11 20:10:00', 'SYYYY-MM-DD HH24:MI:SS'), '', '400', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', 'team_vertion,league_version;shaba_ph体育注单B79', '', '', 'UFtU0ZDVtM0', '1', NULL, NULL, 'main.java.com.gw.common.system.timer.Order4ShabaPhTimer', 'GROUP2', 'Etc/GMT+4', '2');


