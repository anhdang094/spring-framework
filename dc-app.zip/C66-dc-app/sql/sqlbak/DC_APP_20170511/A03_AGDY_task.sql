INSERT INTO ALLOCATION_TASKS
VALUES
	(
		'830',
		'http://10.66.73.112:6302/getbonusorders.xml',
		'1000',
		'600000',
		'0',
		'1',
		NULL,
		'order_agdy',
		TO_DATE (
			'2017-05-12 00:00:00',
			'SYYYY-MM-DD HH24:MI:SS'
		),
		TO_DATE (
			'2017-05-12 00:00:00',
			'SYYYY-MM-DD HH24:MI:SS'
		),
		'130',
		'1600',
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		'0',
		'AG电游注单',
		NULL,
		NULL,
		NULL,
		NULL,
		'5',
		NULL,
		'main.java.com.gw.common.system.timer.OrderTimer',
		'GROUP5',
		'Etc/GMT+4',
		'1'
	);
	
INSERT INTO ALLOCATION_TASKS
VALUES
	(
		'831',
		'http://10.66.73.112:6302/getroundsres.xml',
		'1000',
		'300000',
		'0',
		'1',
		NULL,
		'gameresult_agdy',
		TO_DATE (
			'2017-05-12 00:00:00',
			'SYYYY-MM-DD HH24:MI:SS'
		),
		TO_DATE (
			'2017-05-12 00:00:00',
			'SYYYY-MM-DD HH24:MI:SS'
		),
		'130',
		'400',
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		'0',
		'AGDY游戏结果',
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		'main.java.com.gw.common.system.timer.BaGameTimer',
		'GROUP5',
		'Etc/GMT+4',
		'1'
	);
	
	
	INSERT INTO ALLOCATION_TASKS
VALUES
	(
		'832',
		'http://10.66.73.112:6302/report_trans_info.xml',
		'1000',
		'120000',
		'0',
		'5',
		NULL,
		'trans_agdy',
		TO_DATE (
			'2017-05-12 00:00:00',
			'SYYYY-MM-DD HH24:MI:SS'
		),
		TO_DATE (
			'2017-05-12 00:00:00',
			'SYYYY-MM-DD HH24:MI:SS'
		),
		'130',
		'400',
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		'0',
		'AGDY',
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		'main.java.com.gw.common.system.timer.AccountTransferTimer',
		'GROUP5',
		'Etc/GMT+4',
		'1'
	);


	
	


	
	
	


	
	