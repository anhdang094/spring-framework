update orders_sbt set GMCODE = remark;
commit;
update orders_sbt set remark ='';
commit;