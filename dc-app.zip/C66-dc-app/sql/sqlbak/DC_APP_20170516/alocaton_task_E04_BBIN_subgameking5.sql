INSERT INTO ALLOCATION_TASKS
VALUES
	(
		'834',
		'http://linkapi.w6601.com/app/WebService/XML/display.php/BetRecord',
		'1000',
		'600000',
		'5',
		'20',
		'A03',
		'order_hwxbbin',
		TO_DATE (
			'2017-05-10 00:00:00',
			'SYYYY-MM-DD HH24:MI:SS'
		),
		TO_DATE (
			'2017-05-10 00:00:00',
			'SYYYY-MM-DD HH24:MI:SS'
		),
		NULL,
		'400',
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		'subgamekind=5',
		NULL,
		NULL,
		NULL,
		'1',
		'E04宝盈电子游艺注单subgamekind=5',
		'yingjia',
		'de04real',
		'zse456yhn',
		'1',
		'5',
		NULL,
		'main.java.com.gw.common.system.timer.Order4BBINTimer',
		'GROUP3',
		'Etc/GMT+4',
		'2'
	);

