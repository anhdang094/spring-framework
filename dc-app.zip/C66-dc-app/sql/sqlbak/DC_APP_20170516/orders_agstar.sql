drop table  orders_agdy;
create table orders_agstar as select * from orders_agqj where 1=2;