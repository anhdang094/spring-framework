--drop table t_orders_summary;
create table T_ORDERS_SUMMARY
(
  id              NUMBER(22) not null,
  product         VARCHAR2(20),
  loginname       VARCHAR2(50),
  stat_date       VARCHAR2(20),
  platform        VARCHAR2(20),
  gamekind        VARCHAR2(10),
  gametype        VARCHAR2(10),
  devicetype      VARCHAR2(6),
  playtype 		  VARCHAR2(10),
  totalbetamount  NUMBER(22,6),
  totalvalidamount  NUMBER(22,6),
  totallostamount NUMBER(22,6),
  totalwinamount  NUMBER(22,6),
  totaltieamount  NUMBER(22,6),
  totalbettimes   NUMBER(22),
  totalwintimes   NUMBER(22),
  totallosttimes  NUMBER(22),
  totaltietimes   NUMBER(22),
  maxbetamount    NUMBER(22,6),
  last_update_id  NUMBER(22)
);
alter table T_ORDERS_SUMMARY modify playtype default 'ALL';
alter table T_ORDERS_SUMMARY add primary key (ID);
alter table T_ORDERS_SUMMARY
  add constraint ind_uni unique (PRODUCT, LOGINNAME, stat_date, PLATFORM, GAMEKIND, GAMETYPE, DEVICETYPE);
  
-- Add comments to the columns 
comment on column T_ORDERS_SUMMARY.id
  is '主键id，此id是数据中心汇总的数据通过jms读取过来的';
comment on column T_ORDERS_SUMMARY.loginname
  is '用户名';
comment on column T_ORDERS_SUMMARY.product
  is '产品id';
comment on column T_ORDERS_SUMMARY.platform
  is '平台';
comment on column T_ORDERS_SUMMARY.gametype
  is '游戏类型(主要区分游戏中的各种不同玩法)';
comment on column T_ORDERS_SUMMARY.gamekind
  is '游戏种类(主要指平台中的不同游戏)';
comment on column T_ORDERS_SUMMARY.stat_date
  is '汇总时间';
comment on column T_ORDERS_SUMMARY.totalbetamount
  is '总的投注额';
comment on column T_ORDERS_SUMMARY.totallostamount
  is '总的输的金额';
comment on column T_ORDERS_SUMMARY.totalwinamount
  is '总的赢的金额';
comment on column T_ORDERS_SUMMARY.totaltieamount
  is '总的和局的金额';
comment on column T_ORDERS_SUMMARY.totalbettimes
  is '总的投注次数';
comment on column T_ORDERS_SUMMARY.totalwintimes
  is '总的赢的次数';
comment on column T_ORDERS_SUMMARY.totallosttimes
  is '总的输的次数';
comment on column T_ORDERS_SUMMARY.totaltietimes
  is '总的和的次数';
comment on column T_ORDERS_SUMMARY.devicetype
  is '来源';
comment on column T_ORDERS_SUMMARY.playtype
  is '玩法种类(主要区分每种玩法的下注种类，比如庄闲，大小)';
  
create sequence ORDERS_SUMMARY_SEQ
minvalue 1
maxvalue 999999999999999
start with 1
increment by 1
order;
