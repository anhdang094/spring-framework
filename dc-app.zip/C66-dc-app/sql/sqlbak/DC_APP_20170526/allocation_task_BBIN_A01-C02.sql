INSERT INTO ALLOCATION_TASKS
VALUES
	(
		'838',
		'http://linkapi.w6601.com/app/WebService/XML/display.php/BetRecord',
		'1000',
		'600000',
		'5',
		'20',
		'A01',
		'order_blmbbin',
		TO_DATE (
			'2017-05-20 00:00:00',
			'SYYYY-MM-DD HH24:MI:SS'
		),
		TO_DATE (
			'2017-05-20 00:00:00',
			'SYYYY-MM-DD HH24:MI:SS'
		),
		NULL,
		'400',
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		'subgamekind=5',
		NULL,
		NULL,
		NULL,
		'0',
		'A01宝盈电子游艺注单subgamekind=5',
		'gold88888',
		'da01real',
		'xdr56yhn',
		'1',
		'5',
		NULL,
		'main.java.com.gw.common.system.timer.Order4BBINTimer',
		'GROUP3',
		'Etc/GMT+4',
		'2'
	);


	
INSERT INTO ALLOCATION_TASKS
VALUES
	(
		'839',
		'http://linkapi.w6601.com/app/WebService/XML/display.php/BetRecord',
		'1000',
		'600000',
		'5',
		'20',
		'A02',
		'order_mtbbin',
		TO_DATE (
			'2017-05-20 00:00:00',
			'SYYYY-MM-DD HH24:MI:SS'
		),
		TO_DATE (
			'2017-05-20 00:00:00',
			'SYYYY-MM-DD HH24:MI:SS'
		),
		NULL,
		'400',
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		'subgamekind=5',
		NULL,
		NULL,
		NULL,
		'0',
		'A02宝盈电子游艺注单subgamekind=5',
		'keno8',
		'da02real',
		'2w3e4r5t',
		'1',
		'5',
		NULL,
		'main.java.com.gw.common.system.timer.Order4BBINTimer',
		'GROUP3',
		'Etc/GMT+4',
		'2'
	);
	
	
INSERT INTO ALLOCATION_TASKS
VALUES
	(
		'840',
		'http://linkapi.w6601.com/app/WebService/XML/display.php/BetRecord',
		'1000',
		'600000',
		'5',
		'20',
		'A04',
		'order_zlbbin',
		TO_DATE (
			'2017-05-20 00:00:00',
			'SYYYY-MM-DD HH24:MI:SS'
		),
		TO_DATE (
			'2017-05-20 00:00:00',
			'SYYYY-MM-DD HH24:MI:SS'
		),
		NULL,
		'400',
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		'subgamekind=5',
		NULL,
		NULL,
		NULL,
		'0',
		'A04宝盈电子游艺注单subgamekind=5',
		'yingjia',
		'da04re',
		'3e45t6',
		'1',
		'5',
		NULL,
		'main.java.com.gw.common.system.timer.Order4BBINTimer',
		'GROUP3',
		'Etc/GMT+4',
		'2'
	);
	
INSERT INTO ALLOCATION_TASKS
VALUES
	(
		'841',
		'http://linkapi.w6601.com/app/WebService/XML/display.php/BetRecord',
		'1000',
		'600000',
		'5',
		'20',
		'A05',
		'order_llbbin',
		TO_DATE (
			'2017-05-20 00:00:00',
			'SYYYY-MM-DD HH24:MI:SS'
		),
		TO_DATE (
			'2017-05-20 00:00:00',
			'SYYYY-MM-DD HH24:MI:SS'
		),
		NULL,
		'400',
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		'subgamekind=5',
		NULL,
		NULL,
		NULL,
		'0',
		'A05宝盈电子游艺注单subgamekind=5',
		'yingjia',
		'da05re',
		'6y7u8i',
		'1',
		'5',
		NULL,
		'main.java.com.gw.common.system.timer.Order4BBINTimer',
		'GROUP3',
		'Etc/GMT+4',
		'2'
	);
	
INSERT INTO ALLOCATION_TASKS
VALUES
	(
		'842',
		'http://linkapi.w6601.com/app/WebService/XML/display.php/BetRecord',
		'1000',
		'600000',
		'5',
		'20',
		'A06',
		'order_kbbbin',
		TO_DATE (
			'2017-05-20 00:00:00',
			'SYYYY-MM-DD HH24:MI:SS'
		),
		TO_DATE (
			'2017-05-20 00:00:00',
			'SYYYY-MM-DD HH24:MI:SS'
		),
		NULL,
		'400',
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		'subgamekind=5',
		NULL,
		NULL,
		NULL,
		'0',
		'A06宝盈电子游艺注单subgamekind=5',
		'yingjia',
		'da06real',
		'fast007',
		'1',
		'5',
		NULL,
		'main.java.com.gw.common.system.timer.Order4BBINTimer',
		'GROUP3',
		'Etc/GMT+4',
		'2'
	);
	
	
INSERT INTO ALLOCATION_TASKS
VALUES
	(
		'843',
		'http://linkapi.w6601.com/app/WebService/XML/display.php/BetRecord',
		'1000',
		'600000',
		'5',
		'20',
		'B01',
		'order_b01bbin',
		TO_DATE (
			'2017-05-20 00:00:00',
			'SYYYY-MM-DD HH24:MI:SS'
		),
		TO_DATE (
			'2017-05-20 00:00:00',
			'SYYYY-MM-DD HH24:MI:SS'
		),
		NULL,
		'400',
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		'subgamekind=5',
		NULL,
		NULL,
		NULL,
		'0',
		'B01宝盈电子游艺注单subgamekind=5',
		'yingjia',
		'db01real',
		'b01real123',
		'1',
		'5',
		NULL,
		'main.java.com.gw.common.system.timer.Order4BBINTimer',
		'GROUP3',
		'Etc/GMT+4',
		'2'
	);
	
INSERT INTO ALLOCATION_TASKS
VALUES
	(
		'844',
		'http://linkapi.w6601.com/app/WebService/XML/display.php/BetRecord',
		'1000',
		'600000',
		'5',
		'20',
		'C01',
		'order_c01bbin',
		TO_DATE (
			'2017-05-20 00:00:00',
			'SYYYY-MM-DD HH24:MI:SS'
		),
		TO_DATE (
			'2017-05-20 00:00:00',
			'SYYYY-MM-DD HH24:MI:SS'
		),
		NULL,
		'400',
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		'subgamekind=5',
		NULL,
		NULL,
		NULL,
		'0',
		'C01宝盈电子游艺注单subgamekind=5',
		'yingjia',
		'dc01real',
		'5tghjko0',
		'1',
		'5',
		NULL,
		'main.java.com.gw.common.system.timer.Order4BBINTimer',
		'GROUP3',
		'Etc/GMT+4',
		'2'
	);	

	
INSERT INTO ALLOCATION_TASKS
VALUES
	(
		'845',
		'http://linkapi.w6601.com/app/WebService/XML/display.php/BetRecord',
		'1000',
		'600000',
		'5',
		'20',
		'C02',
		'order_c02bbin',
		TO_DATE (
			'2017-05-20 00:00:00',
			'SYYYY-MM-DD HH24:MI:SS'
		),
		TO_DATE (
			'2017-05-20 00:00:00',
			'SYYYY-MM-DD HH24:MI:SS'
		),
		NULL,
		'400',
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		'subgamekind=5',
		NULL,
		NULL,
		NULL,
		'0',
		'C01宝盈电子游艺注单subgamekind=5',
		'yingjia',
		'dc02real',
		'1qw34r5',
		'1',
		'5',
		NULL,
		'main.java.com.gw.common.system.timer.Order4BBINTimer',
		'GROUP3',
		'Etc/GMT+4',
		'2'
	);	
