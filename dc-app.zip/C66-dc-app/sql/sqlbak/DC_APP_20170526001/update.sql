--ebets数据中心抓取数据中存储报错，字段长度不够，所以将此字段长度扩展
alter table  orders_ebet modify REMARK varchar2(250) ;