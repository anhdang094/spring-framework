insert into ALLOCATION_TASKS (TASK_ID, URL, INCREMENT_BEGINTIME, INCREMENT_ENDTIME, DELAY, PERIOD, PRODUCT_ID, PLATFORM_ID, TASK_BEGINTIME, TASK_ENDTIME, AGCODE, 

PAGE_SIZE, PAGE_NO, GAME_CODE, LOGIN_NAME, BILLNO, TABLE_CODE, PLAY_TYPE, RESULT, ACTION, PRODUCT_TYPE, ORDER_FIELD, ORDER_WAY, FLAG, REMARK, WEBSITE, ACCOUNT_NAME, 

PASSWORD, MODEL, GAME_KIND, CURRENCY_TYPE, INVOKE_CLASS, GROUP_NAME, TIME_ZONE, DATA_DELAY)
values (838, 'http://walletdcapi.aggaming.net/BetRecord', 1000, 600000, 120, 150, 'E03,E02,E04', 'order_amaya_fclrc', to_date('22-05-2017 12:00:00', 'dd-mm-yyyy 

hh24:mi:ss'), to_date('22-05-2017 12:00:00', 'dd-mm-yyyy hh24:mi:ss'), '', 800, null, '1', '', '', '', '', '', '', '', '', '', '1', 'E03 E02 E04 抓取PN电子钱包 

amaya_fclrc电子游艺注单', '', '', '', '1', '5', null, 'main.java.com.gw.common.system.timer.Order4AmayaAndShabaTimer', 'GROUP4', 'Etc/GMT', 2);




insert into ALLOCATION_TASKS (TASK_ID, URL, INCREMENT_BEGINTIME, INCREMENT_ENDTIME, DELAY, PERIOD, PRODUCT_ID, PLATFORM_ID, TASK_BEGINTIME, TASK_ENDTIME, AGCODE, 

PAGE_SIZE, PAGE_NO, GAME_CODE, LOGIN_NAME, BILLNO, TABLE_CODE, PLAY_TYPE, RESULT, ACTION, PRODUCT_TYPE, ORDER_FIELD, ORDER_WAY, FLAG, REMARK, WEBSITE, ACCOUNT_NAME, 

PASSWORD, MODEL, GAME_KIND, CURRENCY_TYPE, INVOKE_CLASS, GROUP_NAME, TIME_ZONE, DATA_DELAY)
values (839, 'http://walletdcapi.aggaming.net/MGBetRecord', 1000, 600000, 0, 5, 'E03,E02,E04', 'order_mg', to_date('22-05-2017 12:00:00', 'dd-mm-yyyy hh24:mi:ss'), 

to_date('22-05-2017 12:00:00', 'dd-mm-yyyy hh24:mi:ss'), '', 800, null, '2', '', '', '', '', '', '', '', '', '', '1', 'E03,E02,E04 抓取PN电子钱包 MG 注单', '', '', '', 

'1', '5', null, 'main.java.com.gw.common.system.timer.Order4MGTimer', 'GROUP4', 'Etc/GMT', 2);




insert into ALLOCATION_TASKS (TASK_ID, URL, INCREMENT_BEGINTIME, INCREMENT_ENDTIME, DELAY, PERIOD, PRODUCT_ID, PLATFORM_ID, TASK_BEGINTIME, TASK_ENDTIME, AGCODE, 

PAGE_SIZE, PAGE_NO, GAME_CODE, LOGIN_NAME, BILLNO, TABLE_CODE, PLAY_TYPE, RESULT, ACTION, PRODUCT_TYPE, ORDER_FIELD, ORDER_WAY, FLAG, REMARK, WEBSITE, ACCOUNT_NAME, 

PASSWORD, MODEL, GAME_KIND, CURRENCY_TYPE, INVOKE_CLASS, GROUP_NAME, TIME_ZONE, DATA_DELAY)
values (840, 'http://walletdcapi.aggaming.net/TransferRecord', 1000, 600000, 120, 5, 'E03,E02,E04', 'trans_amaya_fclrc', to_date('22-05-2017 12:00:00', 'dd-mm-yyyy 

hh24:mi:ss'), to_date('22-05-2017 12:00:00', 'dd-mm-yyyy hh24:mi:ss'), '', 800, null, '1', '', '', '', '', '', '', '', '', '', '1', 'E03 E02 E04 抓取PN电子钱包 

amaya_fclrc转账', '', '', '', '', '3', null, 'main.java.com.gw.common.system.timer.AccountTransferTimer', 'GROUP4', 'Etc/GMT', 2);





insert into ALLOCATION_TASKS (TASK_ID, URL, INCREMENT_BEGINTIME, INCREMENT_ENDTIME, DELAY, PERIOD, PRODUCT_ID, PLATFORM_ID, TASK_BEGINTIME, TASK_ENDTIME, AGCODE, 

PAGE_SIZE, PAGE_NO, GAME_CODE, LOGIN_NAME, BILLNO, TABLE_CODE, PLAY_TYPE, RESULT, ACTION, PRODUCT_TYPE, ORDER_FIELD, ORDER_WAY, FLAG, REMARK, WEBSITE, ACCOUNT_NAME, 

PASSWORD, MODEL, GAME_KIND, CURRENCY_TYPE, INVOKE_CLASS, GROUP_NAME, TIME_ZONE, DATA_DELAY)
values (841, 'http://walletdcapi.aggaming.net/MGTransferRecord', 1000, 600000, 120, 5, 'E03,E02,E04', 'trans_mg', to_date('22-05-2017 12:00:00', 'dd-mm-yyyy 

hh24:mi:ss'), to_date('22-05-2017 12:00:00', 'dd-mm-yyyy hh24:mi:ss'), '', 800, null, '2', '', '', '', '', '', '', '', '', '', '1', 'E03,E02,E04 抓取PN电子钱包 MG 转账

', '', '', '', '', '5', null, 'main.java.com.gw.common.system.timer.AccountTransferTimer', 'GROUP4', 'Etc/GMT', 2);

