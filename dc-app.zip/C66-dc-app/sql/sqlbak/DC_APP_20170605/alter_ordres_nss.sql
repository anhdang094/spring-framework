alter table  orders_nss modify CREATION_TIME DATE default sysdate ;

update orders_nss set CREATION_TIME = billtime where billtime>=to_date('20170605','YYYYMMDD');