INSERT INTO ALLOCATION_TASKS
VALUES
	(
		'838',
		'http://linkapi.w6601.com/app/WebService/XML/display.php/BetRecord',
		'1000',
		'600000',
		'5',
		'120',
		'E02',
		'order_e02bbin',
		TO_DATE (
			'2017-06-13 00:00:00',
			'SYYYY-MM-DD HH24:MI:SS'
		),
		TO_DATE (
			'2017-06-13 00:00:00',
			'SYYYY-MM-DD HH24:MI:SS'
		),
		NULL,
		'400',
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		'subgamekind=5',
		NULL,
		NULL,
		NULL,
		'1',
		'E02宝盈电子游艺注单subgamekind=5',
		'yingjia',
		'de02real',
		'5tgbnji9',
		'1',
		'5',
		NULL,
		'main.java.com.gw.common.system.timer.Order4BBINTimer',
		'GROUP2',
		'Etc/GMT+4',
		'2'
	);

