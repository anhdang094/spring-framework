

-- 执行更新 - 
DECLARE
  TYPE type_rid IS TABLE OF VARCHAR2(100) INDEX BY BINARY_INTEGER;
  v_rid type_rid;
  CURSOR cur IS
		select rowid
         FROM ORDERS_PT T 
				 WHERE 
				 T.product_id like '7U%';
BEGIN
  OPEN cur;
  LOOP
    FETCH cur BULK COLLECT
      INTO v_rid LIMIT 30000;
    FORALL i IN 1 .. v_rid.count
		delete from ORDERS_PT T  WHERE ROWID= v_rid(I);
    COMMIT;
    dbms_output.put_line('update rows is ' || SQL%ROWCOUNT);
    dbms_lock.sleep(5);
  EXIT WHEN cur%NOTFOUND;
  END LOOP;
  COMMIT;
  CLOSE cur;
END;
	   
	   