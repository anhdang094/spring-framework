--备份
select * from transfer_account T 
         WHERE 
         T.product_id like '7U%' and platform_id=039;

--删除

DECLARE
  TYPE type_rid IS TABLE OF VARCHAR2(100) INDEX BY BINARY_INTEGER;
  v_rid type_rid;
  CURSOR cur IS
    select rowid
         FROM transfer_account T 
         WHERE 
         T.product_id like '7U%' and platform_id=039;
BEGIN
  OPEN cur;
  LOOP
    FETCH cur BULK COLLECT
      INTO v_rid LIMIT 30000;
    FORALL i IN 1 .. v_rid.count
    delete from transfer_account T  WHERE ROWID= v_rid(I);
    COMMIT;
    dbms_output.put_line('update rows is ' || SQL%ROWCOUNT);
    dbms_lock.sleep(5);
  EXIT WHEN cur%NOTFOUND;
  END LOOP;
  COMMIT;
  CLOSE cur;
END;
