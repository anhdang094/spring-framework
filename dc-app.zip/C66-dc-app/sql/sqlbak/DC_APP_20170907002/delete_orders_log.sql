-- 备份
create table orders_log_20170907 as 
select * from orders_log where platform_id='044' and GAME_CODE IS NULL;

--删除
delete from orders_log where platform_id='044' and GAME_CODE IS NULL;