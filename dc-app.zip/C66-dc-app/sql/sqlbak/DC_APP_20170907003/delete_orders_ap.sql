-- 可以不用备份，注单从厅方都可以冲抓到
CREATE TABLE ORDERS_AP_20170907 AS 
SELECT * FROM ORDERS_AP WHERE product_id='B05' AND GMCODE='2053V5K7'
 AND LOGINNAME='ykuoway79' and billtime =to_date('2017-08-18 18:03:22','YYYY-MM-DD HH24:MI:SS')
 AND gametype is null;
 
--删除错误注单 
delete FROM ORDERS_AP WHERE product_id='B05' AND GMCODE='2053V5K7'
 AND LOGINNAME='ykuoway79' and billtime =to_date('2017-08-18 18:03:22','YYYY-MM-DD HH24:MI:SS')
 AND gametype is null;
