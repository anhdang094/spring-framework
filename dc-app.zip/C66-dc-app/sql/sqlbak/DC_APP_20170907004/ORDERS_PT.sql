﻿-- 影响数据 - 请备份导出数据
create table ORDERS_PT_2017090701 as
SELECT * FROM ORDERS_PT T 
       WHERE 
       T.GAME_KIND = 5 AND 
       T.VALID_ACCOUNT = 0 AND 
       T.VALID_ACCOUNT != T.ACCOUNT AND
       T.BILLTIME >= TO_DATE('2017-08-01 00:00:00', 'yyyy-mm-dd HH24:mi:ss') AND T.BILLTIME <= TO_DATE('2017-09-08 23:59:59', 'yyyy-mm-dd HH24:mi:ss') AND
	   T.FLAG = 1;

-- 执行更新 - 
DECLARE
  TYPE type_rid IS TABLE OF VARCHAR2(100) INDEX BY BINARY_INTEGER;
  v_rid type_rid;
  CURSOR cur IS
		select rowid
         FROM ORDERS_PT T 
				 WHERE 
				 T.GAME_KIND = 5 AND 
				 T.VALID_ACCOUNT = 0 AND 
				 T.VALID_ACCOUNT != T.ACCOUNT AND
				 T.BILLTIME >= TO_DATE('2017-08-01 00:00:00', 'yyyy-mm-dd HH24:mi:ss') AND T.BILLTIME <= TO_DATE('2017-09-08 23:59:59', 'yyyy-mm-dd HH24:mi:ss') AND
			   T.FLAG = 1;
BEGIN
  OPEN cur;
  LOOP
    FETCH cur BULK COLLECT
      INTO v_rid LIMIT 30000;
    FORALL i IN 1 .. v_rid.count
		UPDATE ORDERS_PT T SET T.VALID_ACCOUNT = T.ACCOUNT  WHERE ROWID= v_rid(I);
    COMMIT;
    dbms_output.put_line('update rows is ' || SQL%ROWCOUNT);
    dbms_lock.sleep(5);
  EXIT WHEN cur%NOTFOUND;
  END LOOP;
  COMMIT;
  CLOSE cur;
END;
	   
	   