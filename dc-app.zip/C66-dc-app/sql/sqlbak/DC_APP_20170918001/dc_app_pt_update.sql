﻿-- GI-216

-- backup
create table allocation_tasks_bak_20170918 as select * from allocation_tasks t where t.task_id in(756, 690, 691, 692, 260, 702, 703, 704);

-- update
update allocation_tasks t set t.url = REPLACE(URL,'kioskpublicapi.redhorse88.com','kioskpublicapi.luckydragon88.com') where t.task_id in(756, 690, 691, 692, 260, 702, 703, 704);