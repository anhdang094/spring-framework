﻿-- Create table
create table ORDERS_CHANGED
(
  ID            number not null,
  PRODUCT_ID    varchar2(5),
  LOGIN_NAME    varchar2(30),
  PLATFORM_ID   varchar2(5),
  BILLNO        varchar2(30),
  BEFORE_AMOUNT number,
  AFTER_AMOUNT  number,
  EFFECT_AMOUNT number,
  CHANGE_TYPE   number(2),
  CHANGE_TIME   date,
  PRO_FLAG      number(2) default 0
);

-- Add comments to the columns 
comment on column ORDERS_CHANGED.ID
  is '记录ID';
comment on column ORDERS_CHANGED.PRODUCT_ID
  is '产品ID';
comment on column ORDERS_CHANGED.PLATFORM_ID
  is '平台ID';
comment on column ORDERS_CHANGED.BEFORE_AMOUNT
  is '前额度';
comment on column ORDERS_CHANGED.AFTER_AMOUNT
  is '先额度';
comment on column ORDERS_CHANGED.CHANGE_TYPE
  is '变更类型 0 投注额变更 1 洗马投注额变更 2 盈利变更'; 
comment on column ORDERS_CHANGED.BILLNO
  is '注单号';
comment on column ORDERS_CHANGED.CHANGE_TIME
  is '变更时间';
comment on column ORDERS_CHANGED.PRO_FLAG
  is '优惠读取状态 0 初始 1处理中 2 处理完';
comment on column ORDERS_CHANGED.EFFECT_AMOUNT
  is '影响金额 正数变多, 负数减少';
  
-- ADD ORDERS CHANGED RECORD SEQ
create sequence ORDERS_CHANGED_SEQ
minvalue 1
start with 1
increment by 1
order;