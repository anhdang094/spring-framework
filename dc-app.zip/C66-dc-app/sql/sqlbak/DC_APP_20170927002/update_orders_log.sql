create table allocation_tasks_20170927 as 
select * from allocation_tasks
where platform_id like '%bbin%' and game_kind ='12';

update allocation_tasks
set agcode = agcode || ',BBGE'
where platform_id like '%bbin%' and game_kind ='12';

create table orders_log_20170927 as 
select * from orders_log 
where task_id in (select task_id from allocation_tasks where platform_id like '%bbin%' and game_kind ='12')
and end_time >= to_date('2017-09-20','yyyy-mm-dd');

update orders_log
set agent_code= agent_code || ',BBGE' ,
   log_type=0
where task_id in (select task_id from allocation_tasks where platform_id like '%bbin%' and game_kind ='12')
and end_time >= to_date('2017-09-20','yyyy-mm-dd');