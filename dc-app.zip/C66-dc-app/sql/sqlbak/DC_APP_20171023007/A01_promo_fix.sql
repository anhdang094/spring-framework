﻿
-- 修改默认值
alter table ORDERS_BSG modify (pro_flag number default 0);

-- 备份
create table as select * from orders_bsg t where t.product_id = 'A01' and t.billtime > to_date('2017-10-16 00:00:00', 'yyyy-mm-dd hh24:mi:ss') and t.pro_flag = 2;

-- 置为重跑
update orders_bsg t set pro_flag = 0 where t.product_id = 'A01' and t.billtime > to_date('2017-10-16 00:00:00', 'yyyy-mm-dd hh24:mi:ss') and t.pro_flag = 2;
