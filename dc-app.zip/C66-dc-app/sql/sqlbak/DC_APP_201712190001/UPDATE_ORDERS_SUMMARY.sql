-- Create table
create table T_ORDERS_SUMMARY
(
  id                 NUMBER(22) not null,
  product            VARCHAR2(20),
  loginname          VARCHAR2(50),
  stat_date          VARCHAR2(20),
  platform           VARCHAR2(20),
  gamekind           VARCHAR2(10),
  gametype           VARCHAR2(10),
  devicetype         VARCHAR2(6),
  totalbetamount     NUMBER(22,6),
  totalvalidamount   NUMBER(22,6),
  totalbettimes      NUMBER(22),
  maxbetamount       NUMBER(22,6),
  last_update_id     NUMBER(22),
  totalremainamount  NUMBER(22,6) default 0 not null,
  totalbonusamount   NUMBER(22,6) default 0 not null,
  totalwinlostamount NUMBER(22,6) default 0 not null
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
-- Add comments to the columns
comment on column T_ORDERS_SUMMARY.id
  is '主键id，此id是数据中心汇总的数据通过jms读取过来的';
comment on column T_ORDERS_SUMMARY.product
  is '产品id';
comment on column T_ORDERS_SUMMARY.loginname
  is '用户名';
comment on column T_ORDERS_SUMMARY.stat_date
  is '汇总时间';
comment on column T_ORDERS_SUMMARY.platform
  is '平台';
comment on column T_ORDERS_SUMMARY.gamekind
  is '游戏种类(主要指平台中的不同游戏)';
comment on column T_ORDERS_SUMMARY.gametype
  is '游戏类型(主要区分游戏中的各种不同玩法)';
comment on column T_ORDERS_SUMMARY.devicetype
  is '来源';
comment on column T_ORDERS_SUMMARY.totalbetamount
  is '总的投注额';
comment on column T_ORDERS_SUMMARY.totalvalidamount
  is '有效投注总额';
comment on column T_ORDERS_SUMMARY.totalbettimes
  is '总的投注次数';
comment on column T_ORDERS_SUMMARY.totalremainamount
  is '洗码投注总额';
comment on column T_ORDERS_SUMMARY.totalwinlostamount
  is '输赢总额';
-- Create/Recreate primary, unique and foreign key constraints
alter table T_ORDERS_SUMMARY
  add primary key (ID)
  using index
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table T_ORDERS_SUMMARY
  add constraint IND_UNI unique (PRODUCT, LOGINNAME, STAT_DATE, PLATFORM, GAMEKIND, GAMETYPE, DEVICETYPE)
  using index
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
