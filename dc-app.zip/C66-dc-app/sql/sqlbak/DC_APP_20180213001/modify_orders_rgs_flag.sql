update orders_rgs set flag=1 where loginname='mrnmsl123' and billno in('738871813912474','738871813912473') and product_id='A04' and gametype='VBL';
