alter table T_ORDERS_SUMMARY add last_update date;
alter table T_ORDERS_SUMMARY add create_date date;