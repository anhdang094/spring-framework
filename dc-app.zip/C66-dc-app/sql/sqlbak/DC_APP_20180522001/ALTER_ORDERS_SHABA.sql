-- Add/modify columns
alter table ORDERS_SHABA modify billno VARCHAR2(32);
-- Add/modify columns
alter table ORDERS_SHABA modify gmcode VARCHAR2(32);
