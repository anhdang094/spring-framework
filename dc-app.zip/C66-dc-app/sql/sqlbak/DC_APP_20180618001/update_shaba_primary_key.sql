alter table ORDERS_SHABA drop constraint PK_ORDERS_SHABA_BILLNO_PROD;

alter table ORDERS_SHABA
  add constraint PK_ORDSABA_BILL_PROD_PLAT_NAME primary key (BILLNO, PRODUCT_ID,PLATFORM_ID,LOGINNAME)
  using index;

commit;