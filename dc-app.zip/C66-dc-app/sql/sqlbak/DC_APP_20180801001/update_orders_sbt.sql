-- Add/modify columns
alter table ORDERS_SBT add odds NUMBER(18,2);
alter table ORDERS_SBT add oddstype VARCHAR2(20);
-- Add comments to the columns
comment on column ORDERS_SBT.odds
  is '赔率';
comment on column ORDERS_SBT.oddstype
  is '盘口';
