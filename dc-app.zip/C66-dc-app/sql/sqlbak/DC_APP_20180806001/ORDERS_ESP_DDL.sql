-- Create table
create table ORDERS_ESP
(
  id                 NUMBER(22),
  billno             VARCHAR2(36) not null,
  loginname          VARCHAR2(18) not null,
  agcode             VARCHAR2(18),
  top_agcode         VARCHAR2(3),
  product_id         VARCHAR2(10) not null,
  platform_id        VARCHAR2(20),
  account            NUMBER(20,4) not null,
  valid_account      NUMBER(18,2) not null,
  cus_account        NUMBER(18,4),
  previos_amount     NUMBER(18,4),
  gmcode             VARCHAR2(32),
  billtime           DATE,
  reckontime         DATE,
  flag               NUMBER(1) default 0,
  hashcode           VARCHAR2(40),
  playtype           NUMBER(4),
  currency           VARCHAR2(6),
  tablecode          VARCHAR2(100),
  round              VARCHAR2(16),
  gametype           VARCHAR2(32) not null,
  cur_ip             VARCHAR2(16),
  remark             VARCHAR2(124),
  result             VARCHAR2(64),
  card_list          VARCHAR2(196),
  exchangerate       NUMBER(18,2),
  resulttype         VARCHAR2(20),
  game_kind          NUMBER(3),
  creation_time      DATE default SYSDATE,
  currency_type      NUMBER(1) default 0,
  device_type        VARCHAR2(6) default '0',
  is_special_game    NUMBER(1) default 0,
  bonus_amount       NUMBER(18,4) default 0,
  remain_amount      NUMBER(18,4) not null,
  odds               NUMBER(8,2),
  oddstype           VARCHAR2(100),
  pro_flag           NUMBER(1) default 0
);
-- Add comments to the columns 
comment on column ORDERS_ESP.id
  is '主键id';
comment on column ORDERS_ESP.billno
  is '流水号';
comment on column ORDERS_ESP.loginname
  is '会员账号，不带productId';
comment on column ORDERS_ESP.product_id
  is '产品编号';
comment on column ORDERS_ESP.platform_id
  is '游戏厅平台编号';
comment on column ORDERS_ESP.account
  is '投注金额';
comment on column ORDERS_ESP.valid_account
  is '有效投注金额';
comment on column ORDERS_ESP.cus_account
  is '客户输赢度';
comment on column ORDERS_ESP.previos_amount
  is '投注前金额';
comment on column ORDERS_ESP.gmcode
  is '局号';
comment on column ORDERS_ESP.billtime
  is '下注时间';
comment on column ORDERS_ESP.reckontime
  is '更新时间(派奖时间)';
comment on column ORDERS_ESP.flag
  is '0：未撤单，1：已撤单';
comment on column ORDERS_ESP.currency
  is '币别';
comment on column ORDERS_ESP.tablecode
  is '桌号';
comment on column ORDERS_ESP.round
  is '预留字段(以前是游戏局号)';
comment on column ORDERS_ESP.gametype
  is '游戏id';
comment on column ORDERS_ESP.remark
  is '备注';
comment on column ORDERS_ESP.result
  is 'Result(输赢结果)';
comment on column ORDERS_ESP.resulttype
  is '投注结果，700：投注，710：派奖，702：撤单';
comment on column ORDERS_ESP.game_kind
  is '游戏类型（电竞为9）';
comment on column ORDERS_ESP.creation_time
  is 'DC注单记录生成时间';
comment on column ORDERS_ESP.currency_type
  is '预留字段';
comment on column ORDERS_ESP.device_type
  is '用户操作客户端：0，pc端 1，移动端';
comment on column ORDERS_ESP.is_special_game
  is '0:参与洗码 1:不参与洗码';
comment on column ORDERS_ESP.bonus_amount
  is '红利金额';
comment on column ORDERS_ESP.remain_amount
  is '洗码投注额';
comment on column ORDERS_ESP.pro_flag
  is '0未被抓取，1处理中，2已处理';
  
alter table ORDERS_ESP
  add constraint PK_ORDERS_ESP_BILL_PROD primary key (BILLNO, PRODUCT_ID, PLATFORM_ID, LOGINNAME)
  using index;
  
create sequence ORDERS_ESP_SEQ
minvalue 1
start with 1
increment by 1
order;
