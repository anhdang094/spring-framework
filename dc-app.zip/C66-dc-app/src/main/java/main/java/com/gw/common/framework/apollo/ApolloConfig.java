package main.java.com.gw.common.framework.apollo;

import com.ctrip.framework.apollo.spring.annotation.EnableApolloConfig;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * project: api
 * author: Walter
 * create: 2019/1/28
 **/
@Configuration
@EnableConfigurationProperties
@EnableApolloConfig
public class ApolloConfig {

}