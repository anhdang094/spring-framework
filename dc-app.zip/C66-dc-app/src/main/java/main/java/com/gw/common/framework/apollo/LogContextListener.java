package main.java.com.gw.common.framework.apollo;

import com.alibaba.fastjson.JSON;
import main.java.com.gw.common.framework.constant.UtilConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.info.GitProperties;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * project: gameInterface_code
 * author: Walter
 * create: 2019/3/14
 **/
@Component
public class LogContextListener {
    private static final Logger logger = LoggerFactory.getLogger(LogContextListener.class);

    @Value("${productId:ALL}")
    private String productId;
    @Autowired
    private GitProperties gitProperties;

    @PostConstruct
    private void startUp() {
        printProjectInfo();
    }

    private void printProjectInfo() {
        try {
            logger.info("############################ 当前产品为：" + productId + " ############################");
            logger.info("============================Print project version start.============================");
            logger.info("\n" + JSON.toJSONString(gitProperties, true));
            logger.info("============================Print project version end.==============================");
            String version = gitProperties.get("commit.id");
            UtilConstants.PROJECT_INFO.put("version", version);
        } catch (Exception e) {
            logger.error("can't read file git.properties,error msg:{}", e.getMessage(), e);
        }
    }

}