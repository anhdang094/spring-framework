package main.java.com.gw.common.framework.apollo;

import com.ctrip.framework.apollo.Config;
import com.ctrip.framework.apollo.model.ConfigChangeEvent;
import com.ctrip.framework.apollo.spring.annotation.ApolloConfig;
import com.ctrip.framework.apollo.spring.annotation.ApolloConfigChangeListener;
import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.system.props.CustomerPropertyholder;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.logging.LogLevel;
import org.springframework.boot.logging.LoggingSystem;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * default description.
 *
 * @author Damon.Q
 * @since 1.0
 */
@Slf4j
@Service
public class LoggerConfiguration {

	private static final Logger logger = LoggerFactory.getLogger(LoggerConfiguration.class);
	private static final String LOGGER_TAG = "log.level";
	public static String p12_path;
	public static String p12_path_k8s;

	@Autowired
	private LoggingSystem loggingSystem;

	@ApolloConfig
	private Config config;

	private static boolean containsIgnoreCase(String str, String searchStr) {
		if (str == null || searchStr == null) {
			return false;
		}
		int len = searchStr.length();
		int max = str.length() - len;
		for (int i = 0; i <= max; i++) {
			if (str.regionMatches(true, i, searchStr, 0, len)) {
				return true;
			}
		}
		return false;
	}

	@ApolloConfigChangeListener
	private void onChange(ConfigChangeEvent changeEvent) {
		initProperties();
		refreshLoggingLevels();
	}

	@PostConstruct
	public void initApollo() {
		initProperties();
		refreshLoggingLevels();
		checkMultiCurrencyConfig();
	}

	private void initProperties() {
		Map<String, String> properties = new HashMap<>();
		config.getPropertyNames()
				.forEach(
						name -> properties.put(name, config.getProperty(name, ""))
				);
		CustomerPropertyholder.setPropertiesMap(properties);
		p12_path = config.getProperty("p12_path", "");
		p12_path_k8s = config.getProperty("p12_path_k8s", "");
	}

	private void refreshLoggingLevels() {
		Set<String> keyNames = config.getPropertyNames();
		for (String key : keyNames) {
			if (containsIgnoreCase(key, LOGGER_TAG)) {
				String strLevel = config.getProperty(key, "info");
				LogLevel level = LogLevel.valueOf(strLevel.toUpperCase());
				loggingSystem.setLogLevel(key.replace(LOGGER_TAG, ""), level);
				logger.info("refresh {}:{}", key, strLevel);
			}
		}
	}

	private void checkMultiCurrencyConfig(){
		//AA03 多币种 配置校验 暂时去掉
		//String mbtc = StringUtils.join("multiplecurrency",".",UtilConstants.CURRENCY_MBTC.toLowerCase(),".","A03");
		//String usdt = StringUtils.join("multiplecurrency",".",UtilConstants.CURRENCY_USDT.toLowerCase(),".","A03");
		//String mbtcRate = config.getProperty(mbtc,"");
		//String usdtRate = config.getProperty(usdt,"");
//		String switchon = config.getProperty("multiplecurrency.switch.on","");
//		if("false".equalsIgnoreCase(switchon)){
//			log.info("A03 多币种开关状态："+switchon);
//		}
//
//		if (StringUtils.isBlank(mbtcRate) || StringUtils.isBlank(usdtRate)) {
//			log.error("根据key:[{}]-[{}]，value:[{}]-[{}],未取到A03配置虚拟币汇率，系统退出！", mbtc, usdt, mbtcRate, usdtRate);
//			System.exit(0);
//		}
	}
}