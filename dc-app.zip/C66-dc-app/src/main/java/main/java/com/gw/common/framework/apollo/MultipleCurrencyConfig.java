package main.java.com.gw.common.framework.apollo;

import main.java.com.gw.common.system.props.CustomerPropertyholder;

public class MultipleCurrencyConfig {



    /***
     * userCurrency : 用户本身的币种，对应于 gi-office --》产品配置管理 中 cust_currency
     * orderOrPlatformCurrency ： 订单 或 平台币种，即：代理线的币种， 对应于 gi-office --》产品配置管理 中 platform_currency
     * 常量取值 和
     * ***/
    public static String getCurrnecyRate(String productId,String userCurrency,String  orderOrPlatformCurrency){
        String key="multiplecurrency.from."+userCurrency.trim().toLowerCase()+".to."+orderOrPlatformCurrency.trim().toLowerCase()
                        +"."+productId.trim();
        return CustomerPropertyholder.getProperty(key);
    }



}
