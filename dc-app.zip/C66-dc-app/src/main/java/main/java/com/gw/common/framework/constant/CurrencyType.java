package main.java.com.gw.common.framework.constant;

import java.util.HashMap;
import java.util.Map;

/**
 * 币种枚举
 *
 * @author Ricardo.X
 */
public enum CurrencyType {

    /**
     * 所有类型
     */
    ALL(-1, "ALL", "所有"),

    /**
     * 未知类型
     */
    UNKNOW(1, "UNKNOW", "未知"),

    /**
     * 人民币
     */
    CNY(0, "CNY", "人民币"),

    /**
     * 比特币
     */
    BTC(2, "BTC", "比特币"),

    /**
     * 英镑
     */
    GBP(3, "GBP", "英镑"),

    /**
     * 越南盾
     */
    VND(4, "VND", "越南盾"),
    /**
     * 披索
     */
    PHP(5, "PHP", "披索");

    private static Map<Integer, CurrencyType> cMap = new HashMap<Integer, CurrencyType>();

    private static Map<String, CurrencyType> tMap = new HashMap<String, CurrencyType>();

    static {
        for (CurrencyType type : CurrencyType.values()) {
            cMap.put(type.getCurrencyCode(), type);
            tMap.put(type.getCurrency().toLowerCase(), type);
        }
    }

    /**
     * Currency Code 与DC WEB上之前定义的Code含义相同
     */
    private int currencyCode;

    /**
     * 币种缩写
     */
    private String currency;

    /**
     * 币种名
     */
    private String currencyName;


    private CurrencyType(int currencyCode, String currency, String currencyName) {
        this.currencyCode = currencyCode;
        this.currency = currency;
        this.currencyName = currencyName;
    }

    public int getCurrencyCode() {
        return currencyCode;
    }

    public String getCurrency() {
        return currency;
    }

    public String getCurrencyName() {
        return currencyName;
    }


    public static CurrencyType getCurrencyTypeByCode(int code) {

        CurrencyType type = cMap.get(code);

        if (type == null)
            type = CurrencyType.UNKNOW;

        return type;
    }


    public static CurrencyType getCurrency(String currency) {

        CurrencyType type = tMap.get(currency.trim().toLowerCase());

        if (type == null)
            type = CurrencyType.UNKNOW;

        return type;
    }
}
