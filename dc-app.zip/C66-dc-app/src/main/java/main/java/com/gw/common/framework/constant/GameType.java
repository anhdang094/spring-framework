package main.java.com.gw.common.framework.constant;

/**
 * Created by twBaron on 2018/6/29/029.
 */
public enum GameType {
    IOM_WALLET(1),
    NON_IOM_WALLET(0);

    private GameType(int type) {
        this.type = type;
    }

    private int type;

    public int getType() {
        return type;
    }
}
