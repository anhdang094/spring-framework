package main.java.com.gw.common.framework.constant;

import main.java.com.gw.datacenter.allocation.entity.RebateExclusiveGame;

import java.io.File;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @author alex.l
 */
public class UtilConstants {

    public static final String MD5 = "MD5";
    public static final int ONE = 1;
    public static final int ZERO = 0;
    public static final int PAGE_SIEZE = 25;
    public static final int PAGE_SIEZE_XTM = 20;
    public static final int PAGE_SIEZE_OFFICE = 50;
    public static final int BATCH_COMMIT_SIZE = 400;
    public static final BigDecimal HUNDREAD = new BigDecimal(100);
    public static final int HTTP_TIME_OUT = 30000;

    public static final String CURRENCY_MBTC = "MBTC";
    public static final String CURRENCY_USDT = "USDT";

    // special mark
    public static final String HTTP_PARM_PLUS = "%2B";
    public static final String HTTP_PLUS = "+";
    public static final String HTTP_PARM_BLANK = "%20";
    public static final String HTTP_BLANK = " ";
    public static final String BLANK = "";
    public static final String COMMA_SYMBOL = ",";
    public static final String DOT = ".";
    public static final String BLANK_SPACE = " ";
    public static final String SEMICOLON = ";";
    public static final String COLON = ":";
    public static final String QUESTION_MARK = "?";
    public static final String LOGICAL_AND = "&";
    public static final String ASSIGNMENT = "=";
    public static final String SEPARATOR = "^^^";
    public static final String ENCODING_UTF8 = "UTF-8";
    public static final String ENCODING_GBK = "GBK";
    public static final String CHARACTER_B = "b";
    public static final String RMB = "RMB";
    public static final String CNY = "CNY";
    public static final String VND = "VND";
    public static final String ONE_STR = "1";
    public static final String ZERO_STR = "0";
    public static final String FIVE_STR = "5";
    public static final String ANGLE_BRACKET_LEFT1 = "<";
    public static final String ANGLE_BRACKET_LEFT2 = "</";
    public static final String ANGLE_BRACKET_RIGHT = ">";
    public static final String XML_VERSION = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
    public static final String ANGLE_BRACKET_LEFT_CHARACTER = "&lt;";
    public static final String ANGLE_BRACKET_RIGHT_CHARACTER = "&gt;";
    public static final String LINE_BREAK = "\r\n";
    public static final String OBLIQUE_LINE = "/";
    public static final String TRANSVERSE_LINE = "-";
    public static final String UNDERLINE = "_";
    public static final String TRANSVERSE_DOT = "...";
    public static final String KEY_ERROR = "keyerr";
    public static final String VERTICAL = "|";
    public static final String BRACKET_LEFT = "[";
    public static final String BRACKET_RIGHT = "]";
    public static final String[] ARRAY_IPM = new String[2];
    // Call remote interface one time per 10 mins.
    public static final long WAITING_PERIOD = 3000l;
    public static final String PREFIX_TIME_STRING = " 00:00:00";
    public static final String SUFFIX_TIME_STRING = " 23:59:59";
    public static final String SUFFIX_MILLISECOND_START = ".000";
    public static final String SUFFIX_MILLISECOND_END = ".999";
    public static final String TIME_ZONE_US_EASTERN = "America/New_York";


    public static final String AGIN_FISHING = "FISH";
    public static final String AGIN_RAISE_FISH = "RAISEFISH";

    // Define URL parameter names for orders API
    public static final String ORDER_BASE_URL = "baseUrl"; // 访问地址
    public static final String ORDER_LOGIN_NAME = "loginname"; // 用户名
    public static final String ORDER_AG_CODE = "agcode"; // 代理编号
    public static final String ORDER_BEGIN_TIME = "begintime"; // 开始时间
    public static final String ORDER_START_TIME = "starttime"; // 开始时间
    public static final String ORDER_END_TIME = "endtime"; // 结束时间
    public static final String ORDER_RESULT = "result"; // 投注结果,win:0,failure:1
    public static final String ORDER_TABLE_CODE = "tablecode"; // 桌子编号
    public static final String ORDER_PLAY_TYPE = "playtype"; // 玩法
    public static final String ORDER_BILL_NO = "billno"; // 注单号
    public static final String ORDER_GM_CODE = "gmcode"; // 局号
    public static final String ORDER_GAME_CODE = "gameCode"; // 游戏代码
    public static final String ORDER_ORDER = "order"; // 排序字段
    public static final String ORDER_BY = "by"; // 排序方式
    public static final String ORDER_PAGE = "page"; // 页数
    public static final String ORDER_PAGE_NUMBER = "num"; // 每页显示记录数,default 20records per page.
    public static final String ORDER_KEY = "key"; // 验证码
    public static final String ORDER_COMPANY_ID = "companyId"; // 开始时间
    public static final String START_ID = "startid"; // 开始请求的记录ID  (AP 德州扑克)
    public static final String ORDER_PER_PAGE = "perpage"; //
    public static final String ORDER_PER_SEARCHALL = "searchall";
    public static final String ORDER_START_DATE = "startdate"; //
    public static final String ORDER_END_DATE = "enddate"; //
    public static final String ORDER_CAGENT = "cagent"; //
    public static final String ORDER_PAGE_NO = "pageNo"; //
    public static final String ORDER_PRODUCT_ID = "productid"; //
    public static final String ORDER_WALLET = "wallet"; //
    public static final String ORDER_EV_MODE = "ev_mode"; //

    // Define URL parameter names for BBIN orders API.
    public static final String ORDER_BBIN_WEBSITE = "website";
    public static final String ORDER_BBIN_LOGINNAME = "target";
    public static final String ORDER_BBIN_USERNAME = "username";
    public static final String ORDER_BBIN_ROUNDDATE = "rounddate";
    public static final String ORDER_BBIN_STATTIME = "starttime";
    public static final String ORDER_BBIN_ENDTIME = "endtime";
    public static final String ORDER_BBIN_GAMEKIND = "gamekind";
    public static final String ORDER_BBIN_GAMETYPE = "gametype";
    public static final String ORDER_BBIN_MODEL = "model";
    public static final String ORDER_TASK_ID = "task_id";
    public static final String ORDER_BBIN_PAGENUM = "page";
    public static final String ORDER_BBIN_PAGESIZE = "pagelimit";
    public static final String ORDER_BBIN_SORT = "sort";
    public static final String ORDER_BBIN_PASSWORD = "password";
    public static final String ORDER_BBIN_CURRENCY_TYPE = "currencyType";

    public static final String ORDER_CG_PASSWORD = "password";
    public static final String ORDER_CG_CURRENCY_TYPE = "currencyType";

    // Define URL parameter names for game results API
    public static final String GAME_RESULT_GM_CODE = "gmcode"; // 局号
    public static final String GAME_RESULT_BEGIN_TIME = "begintime";// 开始时间
    public static final String GAME_RESULT_END_TIME = "endtime"; // 结束时间
    public static final String GAME_RESULT_PAGE = "page"; // 页数
    public static final String GAME_RESULT_PAGE_NUMBER = "num"; // 每页显示记录数,默认为每页20条记录
    public static final String GAME_RESULT_KEY = "key"; // 验证码

    // Define URL parameter names for account transfer API.
    public static final String ACCOUNT_TRANSFER_WEBSITE = "website"; // 平台类型
    public static final String ACCOUNT_TRANSFER_LOGINNAME = "target"; // 账号
    public static final String ACCOUNT_TRANSFER_AGCODE = "agcode"; // 代理商号
    public static final String ACCOUNT_TRANSFER_ACTION = "action"; // 操作类型(1.transfer,2.out,3.in)
    public static final String ACCOUNT_TRANSFER_BILLNO = "transid"; // 订单号
    public static final String ACCOUNT_TRANSFER_BEGINTIME = "date_start"; // 开始时间
    public static final String ACCOUNT_TRANSFER_ROUNDDATE= "rounddate";
    public static final String ACCOUNT_TRANSFER_ENDTIME = "date_end"; // 结束时间
    public static final String ACCOUNT_TRANSFER_PRODUCTTYPE = "producttype"; // 产品类型
    public static final String ACCOUNT_TRANSFER_PAGENUM = "page"; // 第几页
    public static final String ACCOUNT_TRANSFER_PAGESIZE = "num"; // 每页记录数,默认每页20条记录
    public static final String ACCOUNT_TRANSFER_KEY = "key"; // 验证码
    public static final String ACCOUNT_TRANSFER_3CHARACTERS = "php"; // 任意3个字符
    public static final String ACCOUNT_TRANSFER_7CHARACTERS = "alexzgw"; // 任意7个字符
    public static final String ACCOUNT_TRANSFER_PLATFORMID = "platformid";// 平台ID(dsp,dyj,k8 and so
    // on)
    public static final String ACCOUNT_TRANSFER_9CHARACTERS_BTT_A = "abcdefghi";
    public static final String ACCOUNT_TRANSFER_5CHARACTERS_BTT_C = "abcde";

    public static final String ACCOUNT_TRANSFER_8CHARACTERS_LB_A = "abcdefgh";
    public static final String ACCOUNT_TRANSFER_7CHARACTERS_LB_C = "abcdefg";
    public static final String ACCOUNT_TRANSFER_3CHARACTERS_HJ_A = "abc";
    public static final String ACCOUNT_TRANSFER_6CHARACTERS_HJ_C = "abcdef";

    public static final String ACCOUNT_TRANSFER_5CHARACTERS_YJ_A = "abcde";
    public static final String ACCOUNT_TRANSFER_8CHARACTERS_YJ_C = "abcdefgh";

    public static final String ORDER_3CHARACTERS = "php"; // 任意3个字符
    public static final String ORDER_7CHARACTERS = "alexzgw"; // 任意7个字符

    public static final String ORDER_4CHARACTERS_BTT_A = "abcd";
    public static final String ORDER_2CHARACTERS_BTT_C = "ab";

    public static final String ORDER_9CHARACTERS_LB_A = "abcdefghi";
    public static final String ORDER_3CHARACTERS_LB_C = "abc";
    public static final String ORDER_2CHARACTERS_HJ_A = "ab";
    public static final String ORDER_1CHARACTERS_HJ_C = "a";

    public static final String ORDER_8CHARACTERS_YJ_A = "abcdefgh";
    public static final String ORDER_3CHARACTERS_YJ_C = "abc";
    // for BBIN
    public static final String ACCOUNT_TRANSFER_USERNAME = "username";
    public static final String ACCOUNT_TRANSFER_PASSWORD = "password";
    public static final String ACCOUNT_TRANSFER_TRANSTYPE = "TransType";
    public static final String ACCOUNT_TRANSFER_PAGESIEZE_BBIN = "pagelimit";
    public static final String ACCOUNT_TRANSFER_BEGINTIME_HHMISS = "start_hhmmss";
    public static final String ACCOUNT_TRANSFER_START_TIME= "starttime";
    public static final String ACCOUNT_TRANSFER_ENDTIME_HHMISS = "end_hhmmss";
    public static final String ACCOUNT_TRANSFER_END_TIME = "endtime";

    // Define the constants for API key
    public static final String SUFFIX = "feas!#%";
    public static final String SUFFIX_DYJ = "goldenway";
    public static final String SUFFIX_K8 = "keno8";
    // public static final String KEYB_4BLM = "af22se3";
    // public static final String KEYB_4MT = "gsjies83";
    // public static final String KEYB_4HJ = "rytrjghf";
    public static final String TRAN_KEYB_4BLM = "2rF8Q9aTu";
    public static final String TRAN_KEYB_4MT = "31P0xi9f43";
    public static final String TRAN_KEYB_4HJ = "BxWEi2j";
    public static final String TRAN_KEYB_4YJ = "2cKir";

    public static final String ORDER_KEYB_4BLM = "HkpST";
    public static final String ORDER_KEYB_4MT = "9RIZi3FIZ";
    public static final String ORDER_KEYB_4HJ = "OupA1";
    public static final String ORDER_KEYB_4YJ = "MthGX93AI";
    public static final String SUFFIX_CB = "(*&j2zoez";// (*&j2zoez

    // Define the constants for BBIN
    // for BLM
    public static final String WEBSITE_BLM = "gold88888";
    // public static final String USERNAME_BLM = "apai9";
    // public static final String PASSWORD_BLM = "poijk123";
    public static final String USERNAME_BLM = "da01real";
    public static final String PASSWORD_BLM = "xdr56yhn";

    // for MT
    public static final String WEBSITE_MT = "keno8";
    // public static final String USERNAME_MT = "bkeno8";
    // public static final String PASSWORD_MT = "147963Aa";
    public static final String USERNAME_MT = "da02real";
    public static final String PASSWORD_MT = "2w3e4r5t";

    // for ZL
    public static final String WEBSITE_ZL = "hlg6";
    public static final String USERNAME_ZL = "dzhenl";
    public static final String PASSWORD_ZL = "zhenlong99";
    // for LL
    public static final String WEBSITE_LL = "hlg6";
    public static final String USERNAME_LL = "dlil888";
    public static final String PASSWORD_LL = "8i7u6yhnmb";
    // for WH
    public static final String WEBSITE_WH = "hlg6";
    public static final String USERNAME_WH = "dzhenwh";
    public static final String PASSWORD_WH = "3efvbnji9";
    // for HG
    public static final String CASINO_ID = "newpai9egam7z01z";
    public static final String USERNAME_HG = "pai9";
    public static final String PASSWORD_HG = "pai9@live";

    // Define action name and namespace for pageloader

    // transfer
    // log
    public static final String NAMESPACE_ACCOUNTTRANSFER_LOG = "/log";

    public static final String GLOBAL_PLATFORMID_WAGER = "userWagerInfo";
    public static final String GLOBAL_GAMEID_KEY = "gameId";
    public static final String GLOBAL_PLATFORMID_KEY = "platformid";
    public static final String GLOBAL_PRODUCTID_KEY = "productId";
    public static final String TRANSFER_TYPE = "transferType";
    public static final String TRANSFER_KEY_AMOUNT = "transferAmount";
    public static final String GAME_TYPE_KEY_DSP = "gameType4Page";
    public static final String GAME_TYPE_KEY_IOM = "gameType";
    public static final String LOG_TYPE = "logType";
    public static final String LOG_TYPES = "logTypes";
    public static final String VIDEOID_KEY = "videoId";
    public static final String SHOE_NUMBER_KEY = "shoeCode";
    public static final String ORDER_STATISTIC_TYPE = "dateType";
    public static final String DATA_FLAG = "flag";
    // Define platform id for orders,game results and account transfer.
    public static final String TRANSFER = "trans";
    public static final String ACCOUNT_TRANSFER_DSP = "trans_dsp";
    public static final String ACCOUNT_TRANSFER_NEW_DYJ = "trans_newdyj";
    public static final String ACCOUNT_TRANSFER_OLD_DYJ = "trans_olddyj";
    public static final String ACCOUNT_TRANSFER_AG = "trans_ag";
    public static final String ACCOUNT_TRANSFER_AGSTAR = "trans_agstar";
    public static final String ACCOUNT_TRANSFER_AG2 = "trans_ag2";
    public static final String ACCOUNT_TRANSFER_K8 = "trans_keno8";
    public static final String ACCOUNT_TRANSFER_BBIN_BLM = "trans_blmbbin";
    public static final String ACCOUNT_TRANSFER_BBIN_MT = "trans_mtbbin";
    public static final String ACCOUNT_TRANSFER_BBIN_ZL = "trans_zlbbin";
    public static final String ACCOUNT_TRANSFER_BBIN_LL = "trans_llbbin";
    public static final String ACCOUNT_TRANSFER_BBIN_HJ = "trans_hjbbin";
    public static final String ACCOUNT_TRANSFER_BBIN_WH = "trans_whbbin";
    public static final String ACCOUNT_TRANSFER_BBIN_NEWBJH = "trans_newbjhbbin";
    public static final String ACCOUNT_TRANSFER_BBIN_HWX = "trans_hwxbbin";
    public static final String ACCOUNT_TRANSFER_BBIN_HJHA = "trans_hjhabbin";
    public static final String ACCOUNT_TRANSFER_BBIN_KB = "trans_kbbbin";
    public static final String ACCOUNT_TRANSFER_BBIN_PRO = "trans_probbin";
    public static final String ACCOUNT_TRANSFER_BBIN_E02 = "trans_e02bbin";
    public static final String ACCOUNT_TRANSFER_BBIN_E03 = "trans_e03bbin";
    public static final String ACCOUNT_TRANSFER_BBIN_E04 = "trans_e04bbin";
    public static final String ACCOUNT_TRANSFER_BBIN_B01 = "trans_b01bbin";
    public static final String ACCOUNT_TRANSFER_BBIN_B79 = "trans_b79bbin";

    public static final String ACCOUNT_TRANSFER_HG = "trans_hogame";
    public static final String ACCOUNT_TRANSFER_UK_KB = "trans_kbuk";
    public static final String ACCOUNT_TRANSFER_UK_BTT = "trans_bttuk";
    public static final String ACCOUNT_TRANSFER_UK_LB = "trans_lbuk";
    public static final String ACCOUNT_TRANSFER_UK_HWX = "trans_hwxuk";

    public static final String ACCOUNT_TRANSFER_CB = "trans_cb";
    public static final String ACCOUNT_TRANSFER_AMAYA_FCLRC = "trans_amaya_fclrc";
    public static final String ACCOUNT_TRANSFER_AMAYA_VIP_FCLRC = "trans_amayaVip_fclrc";
    public static final String ACCOUNT_TRANSFER_MG = "trans_mg";
    public static final String ACCOUNT_TRANSFER_CQ9 = "trans_cq9";
    public static final String ACCOUNT_TRANSFER_MG_VIP = "trans_mg_vip";
    public static final String ACCOUNT_TRANSFER_RGS = "trans_rgs";
    public static final String ACCOUNT_TRANSFER_VMG = "trans_vmg";
    public static final String ACCOUNT_TRANSFER_BSG = "trans_bsg";
    public static final String ACCOUNT_TRANSFER_NETENT = "trans_netent";
    public static final String ACCOUNT_TRANSFER_BSG_VIP = "trans_bsg_vip";
    public static final String ACCOUNT_TRANSFER_SHABA_UK = "trans_shaba_uk";
    public static final String ACCOUNT_TRANSFER_SHABA_FCLRC = "trans_shaba_fclrc";
    public static final String ACCOUNT_TRANSFER_SBT = "trans_sbt";
    public static final String ACCOUNT_TRANSFER_PNG = "trans_png";
    public static final String ACCOUNT_TRANSFER_PPG = "trans_ppg";
    public static final String ACCOUNT_TRANSFER_YSB = "trans_ysb";
    public static final String ACCOUNT_TRANSFER_NB = "trans_nb";//add by ziv 2018-05-19
    public static final String ACCOUNT_TRANSFER_XDJ = "trans_xdj";//add by ziv 2018-05-19
    public static final String ACCOUNT_TRANSFER_IM = "trans_im";
    public static final String ACCOUNT_TRANSFER_CS = "trans_cs";
    // begin edit by edwin at 2013-04-20
    public static final String ACCOUNT_TRANSFER_AGIN = "trans_agin";
    public static final String ACCOUNT_TRANSFER_IOM = "trans_iom";
    public static final String ACCOUNT_TRANSFER_IMDJ = "trans_imdj";
    public static final String ACCOUNT_TRANSFER_PB = "trans_pb";

    public static final String ACCOUNT_TRANSFER_LC = "096";
    // end
    //捕鱼的相关其它转帐记录
    public static final String ACCOUNT_TRANSFER_AGIN_EXT = "trans_agin_ext";
    public static final String ORDERS = "order";
    public static final String ORDERS_DSP = "order_dsp";
    public static final String ORDERS_DYJ = "order_dyj";
    public static final String ORDERS_NEW_DYJ = "order_newdyj";
    public static final String ORDERS_OLD_DYJ = "order_olddyj";
    public static final String ORDERS_AG = "order_ag";
    public static final String ORDERS_AGSTAR = "order_agstar";
    /**
     * 贵宾厅
     */
    public static final String ORDERS_AG2 = "order_ag2";
    public static final String ORDERS_K8 = "order_keno8";
    public static final String ORDERS_BLM_K8 = "order_blmkeno8";
    public static final String ORDERS_EH_K8 = "order_ehkeno8";
    public static final String ORDERS_BBIN = "order_bbin";
    public static final String ORDERS_E02_BBIN = "order_e02bbin";
    public static final String ORDERS_E03_BBIN = "order_e03bbin";
    public static final String ORDERS_E04_BBIN = "order_e04bbin";
    public static final String ORDERS_BLM_BBIN = "order_blmbbin";
    public static final String ORDERS_MT_BBIN = "order_mtbbin";
    public static final String ORDERS_ZL_BBIN = "order_zlbbin";
    public static final String ORDERS_LL_BBIN = "order_llbbin";
    public static final String ORDERS_WH_BBIN = "order_whbbin";
    public static final String ORDERS_HJ_BBIN = "order_hjbbin";
    public static final String ORDERS_BJH_NEW_BBIN = "order_newbjhbbin";
    public static final String ORDERS_HWX_BBIN = "order_hwxbbin";
    public static final String ORDERS_KB_BBIN = "order_kbbbin";
    public static final String ORDERS_HJHA_BBIN = "order_hjhabbin";
    public static final String ORDERS_B01_BBIN = "order_b01bbin";
    public static final String ORDERS_B79_BBIN = "order_b79bbin";

    // 线路注单更新标志
    public static final String ORDERS_BTT_UPDATE_BBIN = "order_bttupdatebbin";
    public static final String ORDERS_LB_UPDATE_BBIN = "order_lbupdatebbin";
    public static final String ORDERS_HJ_UPDATE_BBIN = "order_hjupdatebbin";
    public static final String ORDERS_YJ_UPDATE_BBIN = "order_yjupdatebbin";

    public static final String ORDERS_EA = "order_ea";
    public static final String ORDERS_HOGAME = "order_hogame";
    public static final String ORDERS_LB_IPM = "order_lbipm";
    public static final String ORDERS_BTT_IPM = "order_lbipm";
    public static final String ORDERS_KH_IPM = "order_lbipm";
    //public static final String ORDERS_CB = "order_cb";
    public static final String ORDERS_AGIN = "order_agin";
    public static final String ORDERS_AGQJ = "order_agqj";
    public static final String ORDERS_AGQJ_EXCEPTIONOR = "agqj_exceptionor";
    public static final String ORDERS_PT = "order_pt";
    public static final String ORDERS_188 = "order_188";
    public static final String ORDERS_AMAYA_FCLRC = "order_amaya_fclrc";
    public static final String ORDERS_AMAYA_VIP_FCLRC = "order_amayaVip_fclrc";

    public static final String ORDERS_SHABA_FCLRC = "order_shaba_fclrc";
    public static final String ORDERS_SHABA_FCLRC2 = "order_shaba_fclrc2";
    public static final String ORDERS_SHABA_FCLRC3 = "order_shaba_fclrc3";

    public static final String ORDERS_MG = "order_mg";
    public static final String ORDERS_MG_VIP = "order_mg_vip";
    public static final String ORDERS_BSG = "order_bsg";
    public static final String ORDERS_BSG_VIP = "order_bsg_vip";
    public static final String ORDERS_VMG = "order_vmg";
    public static final String ORDERS_SHABA_UK = "order_shaba_uk";
    public static final String ORDERS_OPUS = "order_opus";
    public static final String ORDERS_NETENT = "order_netent";
    public static final String ORDERS_PNG = "order_png";
    public static final String ORDERS_PPG = "order_ppg";
    public static final String ORDERS_YSB = "order_ysb";
    public static final String ORDERS_ESP = "order_esp";

    public static final String GAMERESULT = "gameresult";
    public static final String GAMERESULT_DSP = "gameresult_dsp";
    public static final String GAMERESULT_NEW_DYJ = "gameresult_newdyj";
    public static final String GAMERESULT_OLD_DYJ = "gameresult_olddyj";
    public static final String GAMERESULT_AG = "gameresult_ag";
    public static final String GAMERESULT_AGSTAR = "gameresult_agstar";
    public static final String GAMERESULT_AG2 = "gameresult_ag2";
    public static final String GAMERESULT_K8 = "gameresult_keno8";
    public static final String GAMERESULT_BBIN = "gameresult_bbin";
    public static final String GAMERESULT_BLM_BBIN = "gameresult_blmbbin";
    public static final String GAMERESULT_MT_BBIN = "gameresult_mtbbin";
    public static final String GAMERESULT_HOGAME = "gameresult_hogame";
    public static final String GAMERESULT_EA = "gameresult_ea";
    // begin edit by edwin at 2013-04-20
    public static final String GAMERESULT_AGIN = "gameresult_agin";
    // end

    // define log type
    public static final Integer LOG_TYPE_NORMAL = 1;//成功
    public static final Integer LOG_TYPE_ERROR = 0;


    // define agCode
    public static final String AGCODE_MT_EH_DEMO = "002"; // MT,EH
    public static final String AGCODE_WH_ZL_LL_DEMO = "011";// WH,ZL,LL

    public static final String AGCODE_K8_HWX = "001"; // A03 HWX
    public static final String AGCODE_K8_BTT = "005"; // A01 BTT
    public static final String AGCODE_K8_LB = "007"; // A02 LB
    public static final String AGCODE_K8_CF = "009"; // B01 CF
    public static final String AGCODE_K8_CF_SW = "010"; // B01 CF

    public static final String AGCODE_K8_E04 = "011"; // E04 HJ
    public static final String AGCODE_K8_E03 = "013"; // E03 HJ

    public static final String AGCODE_MT = "003"; // A02 MT
    public static final String AGCODE_EH = "004"; // A03 HWX
    public static final String AGCODE_ZL = "008"; // A04 ZL
    public static final String AGCODE_BLM = "012"; // A01 BLM
    public static final String AGCODE_LL = "013"; // A05 LL
    public static final String AGCODE_BET = "014"; // A05 LL
    public static final String AGCODE_WH = "021"; // C01 WH
    public static final String AGCODE_HJ = "010"; // D01HP(Hejibet)
    public static final String AGCODE_YSB = "025"; // D05
    public static final String AGCODE_BJH = "031"; // D03
    public static final String AGCODE_BJH_NEW = "035"; // D08
    public static final String AGCODE_HP = "099";
    public static final String AGCODE_CF = "100"; // B01 CF

    // define production id
    public static final String PRODUCTID_BLM = "A01"; // A01 BLM
    public static final String PRODUCTID_MT = "A02"; // A02 Monte
    public static final String PRODUCTID_EH = "A03"; // A03 EH(XWY)
    public static final String PRODUCTID_ZL = "A04"; // A04 ZL
    public static final String PRODUCTID_LL = "A05"; // A05 LL
    public static final String PRODUCTID_KB = "A06"; // A06 Kashbet
    public static final String PRODUCTID_CF = "B01"; // B01 CF

    // public static final String PRODUCTID_KB = "B03"; // B03 Kashbet
    public static final String PRODUCTID_WH = "C01"; // C01 WH(wanhao)
    public static final String PRODUCTID_HJHA = "C02"; // C02 HJHA
    public static final String PRODUCTID_HJ = "D01"; // 和计娱乐(Hejibet)

    public static final String PRODUCTID_BJH_NEW = "D08"; // 新白金会

    public static final String ORDERS_AGIN_SPORT = "070"; //AGIN SPORT

    // define platform id for DB.
    public static final String DSP = "001";
    public static final String DYJ_NEW = "002";
    // public static final String DYJ_OLD= "003";
    public static final String AGQJ = "003";
    public static final String AGSTAR = "064";
    public static final String AG2 = "032";
    public static final String K8 = "004";// for BLM or BTT
    public static final String K8_EH = "005";// for EH OR HWX
    public static final String BBIN_BLM = "006";
    public static final String BBIN_MT = "007";
    public static final String HOGAME = "008";
    public static final String UK = "025";
    public static final String AMAYA_FCLRC = "027";
    public static final String AMAYA_VIP_FCLRC = "053";
    public static final String MG = "035";
    public static final String CQ9 = "073";
    public static final String HBN = "099";
    public static final String CG = "097";
    public static final String MG_VIP = "054";
    public static final String INDEX = "042";
    public static final String GT1 = "041";
    public static final String BO = "040";
    public static final String SHABA_UK = "034";
    public static final String SHABA_FCLRC = "031";
    public static final String WsSport = "098";
    public static final String EA = "009";
    public static final String BBIN_ZL = "010";
    public static final String BBIN_HJ = "011";
    public static final String BBIN_LL = "012";
    public static final String BBIN_WH = "013";
    public static final String BBIN_BJH_NEW = "015";
    public static final String SL = "016";
    public static final String BBIN_HWX = "017";
    public static final String IPM = "018";// numeric platform ID
    public static final String BBIN_KB = "024";
    public static final String BBIN_HJHA = "020";
    // begin edit by edwin at 2013-04-20
    public static final String BET188 = "038";
    public static final String AGIN = "026";

    // end
    public static final String PT = "039";
    public static final String CB = "030";
    public static final String TLB = "036";
    public static final String OPUS = "043";
    public static final String AP = "044";
    public static final String SBO = "093";
    public static final String W88 = "047";
    public static final String W88SLOTS = "047";
    public static final String W88SPORTS = "047";
    public static final String W88LOTTERY = "056";
    public static final String RGS = "046";
    public static final String EBET = "059";
    public static final String TGP = "060";

    /**
     * NSS
     */
    public static final String NSS = "061";
    public static final String SBT = "062";
    public static final String NETENT = "065";
    public static final String PPG = "067";
    public static final String YSB = "068";
    public static final String NB = "069";//add by ziv 2018-05-19
    public static final String NAP = "072";
    public static final String ESP = "071";

    public static final String VNLOTO = "075";

    public static final String XDJ = "077";

    public static final String VR = "078";
    public static final String QG = "080";
    public static final String G1 = "088";

    public static final String CS = "087";

    public static final String XJ = "089";
    public static final String PB = "092";
    public static final String PS = "094";

    public static final String LC = "096";
    // PG platformId
    public static final String PG = "100";
    // TPG platformId
    public static final String TPG = "103";
    //开发体育游戏平台
    public static final String K8_SPORT_SBT = "066";
    public static final String K8_SHABA_FCLRC = "067";

    // IM体育平台
    public static final String IM = "086";
    // IMDJ 电竞平台
    public static final String IMDJ = "090";
    // GB体育
    public static final String GB = "091";

    /**
     * NSS NSS Param map key - productid
     */
    public static final String NSS_PARAMKEY_PRODUCTID = "productid";
    /**
     * NSS NSS PLATFORM ID key - productid
     */
    public static final String NSS_PARAMKEY_PLATFORMID = "platformid";
    /**
     * PARAMS MAP
     */
    public static final String NSS_PARAM_MAP = "PARAMSMAP";

    /**
     * order sync date_start param map key
     */
    public static final String NSS_OS_DATESTART = "OS_DATESTART";
    /**
     * order sync date_end param map key
     */
    public static final String NSS_OS_DATEEND = "OS_DATESTART";

    /**
     * order sync date_start param map key
     */
    public static final String NSS_OS_DATESTART_STR = "begintime";
//    public static final String NSS_OS_DATESTART_STR = "OS_DATESTART_STR";

    /**
     * order sync date_end param map key
     */
    public static final String NSS_OS_DATEEND_STR = "endtime";
//    public static final String NSS_OS_DATEEND_STR = "OS_DATEEND_STR";

    /**
     * order sync last end param map key
     */
    public static final String NSS_OS_LAST_END = "OS_LAST";
    /**
     * time of overlap between two task
     */
    public static final String NSS_OS_TINE_OVERLAP = "OS_OLT";
    /**
     * NSS PARAMS ALLOCATION MAP KEY
     */
    public static final String NSS_ALLOCATION = "ALLOCATION";

    public static final String NSS_TIMEZONE = "timeZone";

    public static final String NSS_CURRENCY = "CURRENCY";

    public static final String ORDERS_CANCEL = "Cancel";

    /**
     * 英国牌照 MG 050
     */
    public static final String VMG = "050";
    public static final String BSG = "051";
    public static final String BSG_VIP = "055";
    public static final String PNG = "052";

    /**
     * EVOlution游戏平台
     */
    public static final String EVO = "058";

    public static final String BBIN_BTT_UPDATE = "bttupdatebbin";
    public static final String BBIN_LB_UPDATE = "lbupdatebbin";
    public static final String BBIN_HJ_UPDATE = "hjupdatebbin";
    public static final String BBIN_YJ_UPDATE = "yjupdatebbin";

    public static final String BBIN_LOTTERY_ORDER = "bbin_lottery_order";

    public static final String AGIN_FOOT_GAME_GAMEKIND = "1";
    public static final String AGIN_SOLT_GAME_GAMEKIND = "2";

    // define game type for DSP&DYJ
    public static final String GAME_TYPE_KEY = "gameTypeKey";
    public static final String GAME_KIND = "gameKind";
    public static final String GAME_TYPE_DT = "DT";
    public static final String GAME_TYPE_BAC = "BAC";
    public static final String GAME_TYPE_CBAC = "CBAC";
    public static final String GAME_TYPE_TBAC = "TBAC";
    public static final String GAME_TYPE_LBAC = "LBAC";
    public static final String GAME_TYPE_SHB = "SHB";
    public static final String GAME_TYPE_ROU = "ROU";
    public static final String GAME_TYPE_KENO = "KENO";
    // define game type for BBIN
    public static final String GAME_TYPE_BBIN_BAC = "3001";
    public static final String GAME_TYPE_BBIN_DT = "3003";
    // define game type for EA
    public static final String GAME_TYPE_EA_BAC_TRADITINAL = "10001";
    public static final String GAME_TYPE_EA_BAC_PAIR = "10002";
    public static final String GAME_TYPE_EA_BAC_14 = "70001";
    public static final String GAME_TYPE_EA_BAC_SUPER = "90001";


    // Define time zone
    public static final String TIMEZONE_GMT_W12 = "Etc/GMT+12";
    public static final String TIMEZONE_GMT_W11 = "Etc/GMT+11";
    public static final String TIMEZONE_GMT_W10 = "Etc/GMT+10";
    public static final String TIMEZONE_GMT_W9 = "Etc/GMT+9";
    public static final String TIMEZONE_GMT_W8 = "Etc/GMT+8";
    public static final String TIMEZONE_GMT_W7 = "Etc/GMT+7";
    public static final String TIMEZONE_GMT_W6 = "Etc/GMT+6";
    public static final String TIMEZONE_GMT_W5 = "Etc/GMT+5";
    public static final String TIMEZONE_GMT_W4 = "Etc/GMT+4";
    public static final String TIMEZONE_GMT_W3 = "Etc/GMT+3";
    public static final String TIMEZONE_GMT_W2 = "Etc/GMT+2";
    public static final String TIMEZONE_GMT_W1 = "Etc/GMT+1";
    public static final String TIMEZONE_GMT = "Etc/GMT";
    public static final String TIMEZONE_GMT_E1 = "Etc/GMT-1";
    public static final String TIMEZONE_GMT_E2 = "Etc/GMT-2";
    public static final String TIMEZONE_GMT_E3 = "Etc/GMT-3";
    public static final String TIMEZONE_GMT_E4 = "Etc/GMT-4";
    public static final String TIMEZONE_GMT_E5 = "Etc/GMT-5";
    public static final String TIMEZONE_GMT_E6 = "Etc/GMT-6";
    public static final String TIMEZONE_GMT_E7 = "Etc/GMT-7";
    public static final String TIMEZONE_GMT_E8 = "Etc/GMT-8";
    public static final String TIMEZONE_GMT_E9 = "Etc/GMT-9";
    public static final String TIMEZONE_GMT_E10 = "Etc/GMT-10";
    public static final String TIMEZONE_GMT_E11 = "Etc/GMT-11";
    public static final String TIMEZONE_GMT_E12 = "Etc/GMT-12";
    public static final String TIMEZONE_GMT_E13 = "Etc/GMT-13";
    public static final String TIMEZONE_GMT_E14 = "Etc/GMT-14";

    //北京时间
    public static final String TIMEZONE_Standard_BeiJing = "Etc/GMT-8";


    //以北京时间为准偏移多少小时
    public static final Integer CO7_OFFSETTIME = -1;

    // Define FTP properties for MT EA.
    public static final String FTP_EA_LOGINNAME = "mongameinfo_02";
    public static final String FTP_EA_PASSWORD = "tuyqk6anw493";
    public static final String FTP_EA_HOST = "gameinfo.ea3-mission.com";
    public static final String FTP_EA_PORT = "21";
    public static final String FTP_EA_DIRECTORY_REMOTE = "/";
    public static final String FTP_EA_FILENAME = "gameinfolist.txt";
    public static final String FTP_EA_DIRECTORY_LOCAL = "C:" + File.separator + "xml4ea";


    // ###################allocation task Constants#####################
    public static final String ALLOCATION_WEBSITE = "webSite";

    public static final String ALLOCATION_REMARK = "remark";

    public static final String ALLOCATION_TARGET_TABLE = "targetTable";

    // ###################cache constants#####################

    public static final Long CACHE_AVAILABLE_DURATION = new Long(1000 * 60 * 30);

    public static final String CACHE_TABLE_META_COLUMNS = "targetTableMeta_Columns_";

    public static final String CACHE_UPDATE_ENTITY_FOR_AUTO_SQL = "UpdateEntity4AutoSql_";

    public static final String CACHE_INSERT_ENTITY_FOR_AUTO_SQL = "InsertEntity4AutoSql_";

    public static final String CACHE_QUERY_ENTITY_FOR_AUTO_SQL = "FindOrignalOrderEntitySql_";
    public static final String CACHE_TABLE_NOTNULL_COLUMNS = "targetTableMeta_NotNullable_Columns";


    // ######################Order by##################################


    // add by kristy 2011-10-04 -end

    public static final String YEAR = "年";
    public static final String MONTH = "月";
    public static final String DATE = "日";
    public static final String WEEK_ONE = "星期一";
    public static final String WEEK_TWO = "星期二";
    public static final String WEEK_THREE = "星期三";
    public static final String WEEK_FOUR = "星期四";
    public static final String WEEK_FIVE = "星期五";
    public static final String WEEK_SIX = "星期六";
    public static final String WEEK_SEVEN = "星期日";

    public static final String HG_BETING_XML_NODE = "GetAllBetDetailsPerTimeInterval";
    public static final String HG_TRANSFER_XML_NODE = "GetAllFundTransferDetailsPerTimeInterval";
    public static final String HG_GAMERESULT_XML_NODE = "GameResultInfo";

    // define the transfer type
    public static final String TRANSFER_TYPE_IN_CN = "存入"; // BBIN转入游戏
    public static final String TRANSFER_TYPE_OUT_CN = "提出"; // BBIN转出游戏
    public static final String TRANSFER_TYPE_IN = "IN"; // 转入游戏
    public static final String TRANSFER_TYPE_OUT = "OUT"; // 转出游戏
    public static final String TRANSFER_TYPE_BET = "BET"; // 下注
    public static final String TRANSFER_TYPE_TRANSFER = "TRANSFER"; //
    public static final String TRANSFER_TYPE_RECKON = "RECKON"; // 结算
    public static final String TRANSFER_TYPE_RECALC = "RECALC"; // 重新结算
    public static final String TRANSFER_TYPE_RECALC_ERR = "RECALC_ERR";// 重新结算失败
    public static final String TRANSFER_TYPE_DONATEFEE = "DONATEFEE"; // 小费
    public static final String TRANSFER_TYPE_CANCEL_BET = "CANCEL_BET";// 取消订单
    public static final String TRANSFER_TYPE_AGENTCUS = "AGENTCUS"; // 代理注册玩家
    public static final String TRANSFER_TYPE_REGTRYCUS = "REGTRYCUS"; // 注册试玩
    public static final String TRANSFER_TYPE_MODIFY = "MODIFY"; // 修正额度
    public static final String TRANSFER_TYPE_PRESENT = "PRESENT"; // 会员优惠
    public static final String TRANSFER_TYPE_GBED = "GBED"; // 代理商修改额度
    public static final String TRANSFER_TYPE_INTEREST = "INTEREST"; // 利息

    public static final String TRANSFER_TYPE_HG_IN = "Transfer In";
    public static final String TRANSFER_TYPE_HG_OUT = "Transfer Out";
    public static final String TRANSFER_TYPE_HG_RECKON_WIN = "Player Win";
    public static final String TRANSFER_TYPE_HG_BET = "Place Bet";
    public static final String TRANSFER_TYPE_HG_RECKON_LOS = "Player Lose";
    public static final String TRANSFER_TYPE_HG_CANCEL_BET = "Cancel Placed Bet";
    public static final String TRANSFER_TYPE_HG_DEPOSIT = "Online Deposit";
    public static final String TRANSFER_TYPE_HG_WITHFRAW = "Withdraw";
    public static final String TRANSFER_TYPE_IGAS_DEPOSIT = "Deposit";
    public static final String TRANSFER_TYPE_IGAS_WITHFRAW = "Withdraw";

    public static final String TRANSFER_TYPE_AMAYA_DEPOSIT = "Deposit";
    public static final String TRANSFER_TYPE_AMAYA_WITHFRAW = "Withdraw";

    public static final String TRANSFER_TYPE_PT_DEPOSIT = "deposit";
    public static final String TRANSFER_TYPE_PT_WITHFRAW = "withdraw";

    public static final String TRANSFER_TYPE_AP_DEPOSIT = "RECHARGE";
    public static final String TRANSFER_TYPE_AP_WITHFRAW = "WITHDRAW";
    public static final String TRANSFER_TYPE_AP_BET = "GAME";

    public static final String TRANSFER_TYPE_DEPOSIT = "deposit";
    public static final String TRANSFER_TYPE_WITHDRAW = "withdrawal";
    public static final String TRANSFER_TYPE_WIN = "won";
    public static final String TRANSFER_TYPE_PLACE_BET = "placebet";
    public static final String TRANSFER_TYPE_CANCEL = "userCanceledBet";
    public static final String TRANSFER_TYPE_CANCEL_PROPOSITION = "espCanceledProposition";

    public static final String TRANSFER_TYPE_BO_DEPOSIT = "deposit";
    public static final String TRANSFER_TYPE_BO_WITHFRAW = "withdrawal";

    public static final String LOGOUT_SUCCESS = "Logout Player Successfully!";
    public static final String LOGOUT_FAILURE = "Logout Player Failure!";
    public static final String ORDER_STATUS_KEY = "orderStatus";

    // demo account for all product
    public static final String ACCOUNT_PREFIX_DEMO_A01 = "a01";
    public static final String ACCOUNT_PREFIX_DEMO_A02 = "a02";
    public static final String ACCOUNT_PREFIX_DEMO_A03 = "a03";
    public static final String ACCOUNT_PREFIX_DEMO_A04 = "a04";
    public static final String ACCOUNT_PREFIX_DEMO_A05 = "a05";
    public static final String ACCOUNT_PREFIX_DEMO_A06 = "a06";


    public static final String B01_BBIN_PREFIX = "b";




    public static final String IGAS_BET_STATUS_UNDECIDED = "UNDECIDED";
    public static final String IGAS_BET_STATUS_LOSER = "LOSER";
    public static final String IGAS_BET_STATUS_WINNER = "WINNER";
    public static final String IGAS_BET_STATUS_CANCEL = "CANCEL";
    public static final String IGAS_BET_STATUS_REFUND = "REFUND";
    public static final String IGAS_BET_STATUS_LOSERREFUND = "LOSERREFUND";

    public static final String STR_HOGAME = "HOGAME";
    public static final String STR_MAINTENANCE = "maintenance";

    public static final String BBIN_GAMEKIND_CP = "12";
    // PDATACENTER-841 BBIN小费从注单查询转移到额度记录中 modify by walter 2018-11-2
    public static final String BBIN_GAMEKIND_DONATEFEE = "99";

    public static final String BBIN_GAMETYPE_CP = "LT,BJ3D,PL3D,BB3D,SH3D,CQSC,JXSC,TJSC,XJSC,GXSF,GDSF,TJSF,BJKN,CAKN,AUKN,BBKN,BJPK,GDE5,CQE5,JXE5,SDE5,BBRB,JSQ3,AHQ3,BBBO,BBPK,JLQ3,CQSF,RDPK";

    //SBT抓取类型
    public static final String SBT_ORDER = "GROUP_SBT_ORDER";//抓取sbt_order表
    public static final String SBT_CREDIT = "GROUP_SBT_CREDIT";//抓取sbt_credit表

    //NB抓取类型 add by ziv 2018-05-21
    public static final String NB_ORDER = "GROUP_NB_ORDER";
    public static final String NB_CREDIT = "GROUP_NB_CREDIT";

    // PB抓取类型
    public static final String PB_ORDER = "GROUP_PB_ORDER";
    public static final String PB_CREDIT = "GROUP_PB_CREDIT";

    public static String A01REALPREFIX = "g";
    public static String A02REALPREFIX = "c";
    public static String A04REALPREFIX = "m";
    public static String A05REALPREFIX = "t";
    public static String A06REALPREFIX = "c";
    public static String B01REALPREFIX = "k";
    public static String C01REALPREFIX = "r";
    public static String C02REALPREFIX = "w";
    public static String D20REALPREFIX = "k";
    public static String E02REALPREFIX = "b";
    public static String E03REALPREFIX = "v";
    public static String E04REALPREFIX = "d";
    public static String A03REALPREFIX = "f";
    public static String A03REALPREFIX_NWE = "8";

    /**
     * @Description: 用于区分A02、A06产品用户名前缀相同问题。
     * @Author: Ziv.Y
     * @Date: 2018/2/5 16:31
     */
    public static String A02_BBIN_BYDS_WEBSITE = "keno8";
    public static String A06_BBIN_BYDS_WEBSITE = "yingjia";


    /** vr体育*/
    public static final int VR_RECORD_PAGE_NUM = 0;
    public static final int VR_RECORD_COUNT_PERPAGE = 500;

    public enum PRODUCT_ENUM {
        ALL, A01, A02, A03, A04, A05, A06, B01, B04, B05, B06, C01, C02, C04, C05, C07, E01, E02, E03, E04, P02, C03, B79, B07,C31,V66,V84,AW1,AW3
    }

    public enum GAME_KIND_ENUM {
        UNKNOW(""),

        //捕鱼
        /**
         * 体育=1
         */
        BALL("1"), CALLBET("2"), VIDEO("3"), ELECTRONIC("5"), MAHJONG("6"), FIGHT("7"), FISH("8"), E_SPORT("9"), LOTTERY("12"), THREE_D("15"),CHESS("16"), NIUNIU("20");


        String code = "UNKNOW";

        GAME_KIND_ENUM(String _code) {
            this.code = _code;
        }

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }
    }

    public enum AMAYA_BET_TYPE_ENUM {
        UNKNOW(""), BET("400"), BET1("450"), CANCEL("402"), PAY_OUT("410"), PAY_OUT1("460");
        String code = "UNKNOW";

        AMAYA_BET_TYPE_ENUM(String _code) {
            this.code = _code;
        }

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }
    }

    public enum IOM_BET_TYPE_ENUM {
        UNKNOW(""), BET("700"), CANCEL("702"), PAY_OUT("710"), CASH_BONUS("730"), FREE_SPIN_BONUS("720");
        String code = "UNKNOW";

        IOM_BET_TYPE_ENUM(String _code) {
            this.code = _code;
        }

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }
    }


    public enum ORDERS_FLAG_ENUM {
        SETTLED(1),
        UNSETTLED(0),
        CANCELED(-9);

        int falg = 0;

        ORDERS_FLAG_ENUM(int _falg) {
            this.falg = _falg;
        }

        public int getFalg() {
            return falg;
        }

        public void setFalg(int falg) {
            this.falg = falg;
        }

    }

    public enum ORDERS_TYPE_ENUM {
        PAYOUT(1),
        BET(0);

        int flag = 0;

        ORDERS_TYPE_ENUM(int flag) {
            this.flag = flag;
        }

        public int getFlag() {
            return flag;
        }

        public void setFlag(int flag) {
            this.flag = flag;
        }

    }

    public enum CURRENCY {
        UNKONWN, CNY, BTC, GBP, VND, RMB,USD,THB
    }


    public enum SBT_TRANSFER_ENUM {
        //0 reserve, 1 debit, 2 commit, 3 debit, 4 credit, 5 cancel
        RESERVE(0, "SBT_RESERVE"),
        DEBITRESERVER(1, "SBT_DEBIT"),
        COMMITRESERVER(2, "SBT_COMMIT"),
        DEBITCUSTOMER(3, "SBT_CREDIT"),
        CREDITCUSTOMER(4, "SBT_CREDIT"),
        CANCELRESERVER(5, "CANCEL_BET");

        private int code;

        private String desc;

        SBT_TRANSFER_ENUM(int ordinal, String name) {
            this.code = ordinal;
            this.desc = name;
        }

        public static String getDescById(int id) {
            String str = "";
            for (SBT_TRANSFER_ENUM e : SBT_TRANSFER_ENUM.values()) {
                if (e.code == id) {
                    str = e.desc;
                    break;
                }
            }
            return str;
        }


    }

    public enum ORIGIN_DEVICE_TYPE_ENUM {

        DEVICE_P_0("P", "0"),
        DEVICE_M_1("M", "1"),
        DEVICE_MI1_1("MI1", "1"),
        DEVICE__MI2_1("MI2", "1"),
        DEVICE_MA1_1("MA1", "1"),
        DEVICE_MA2_1("MA2", "1");

        private String key;

        private String value;

        ORIGIN_DEVICE_TYPE_ENUM(String key, String value) {
            this.key = key;
            this.value = value;
        }

        public static String getValueByKey(String key) {
            String str = "0";
            for (ORIGIN_DEVICE_TYPE_ENUM e : ORIGIN_DEVICE_TYPE_ENUM.values()) {
                if (e.key.equals(key)) {
                    str = e.value;
                    break;
                }
            }
            return str;
        }

    }

    //ws sport盘口类型
    public enum WsSportOddsTypeEnum {

        MY("MY"),//马来盘
        HK("HK"),//香港盘
        ID("ID"),//印尼盘
        EU("EU"),//印尼盘

        ;

        private String oddsType;

        WsSportOddsTypeEnum(String oddsType) {
            this.oddsType = oddsType;
        }

        public static WsSportOddsTypeEnum getOddsType(String type) {
            WsSportOddsTypeEnum e = null;
            for (WsSportOddsTypeEnum ot : WsSportOddsTypeEnum.values()) {
                if (ot.oddsType.equals(type)) {
                    e = ot;
                    break;
                }
            }
            return e;
        }

        public String getOddsType() {
            return oddsType;
        }

        public void setOddsType(String oddsType) {
            this.oddsType = oddsType;
        }
    }

    //盘口类型
    public enum OddsTypeEnum {

        MALAY("1"),//马来盘
        HK("2"),//香港盘
        DECIMAL("3"),//欧洲盘
        SHABA_INDO("4"),//shaba印尼盘
        AMERICAN("5"),//美洲盘
        ENGLISH_SCORE("6"),//英式分数盘(NB新增) add by ziv 2018-05-29
        BURMA("7"),//缅甸盘(NB新增) add by ziv 2018-05-29
        MP("MP"),//混合过关
        //------------------nss--
        NSS_INDO("30"),//nss印尼盘
        NSS_MALAY("31"),//nss马来盘
        NSS_HK("32"),//nss香港盘
        NSS_DECIMAL("33"),//欧洲盘
        NSS_MP("0"),//混合过关
        ;
        private String oddsType;

        OddsTypeEnum(String ordinal) {
            this.oddsType = ordinal;
        }

        public static OddsTypeEnum getOddsType(String type) {
            OddsTypeEnum e = null;
            for (OddsTypeEnum ot : OddsTypeEnum.values()) {
                if (ot.oddsType.equals(type)) {
                    e = ot;
                    break;
                }
            }
            return e;
        }

        public String getValueStr() {
            return oddsType;
        }
    }

    public static final String COMMAND_VIEW = "view";
    public static final String CUSTOMER_MODULE = "Customer";
    public static final String POSITION_MODULE = "Positions";
    public static final String WITHDRAWAL_MODULE = "Withdrawal";
    public static final String CUSTOMERDEPOSITS_MODULE = "CustomerDeposits";
    public static final String FILTER_MINDATE = "FILTER[date][min]";
    public static final String FILTER_MAXDATE = "FILTER[date][max]";

    public static final String FILTER_SETTLE_DATE_MIN = "LFILTER[options][endDate][min]";
    public static final String FILTER_SETTLE_DATE_MAX = "LFILTER[options][endDate][max]";

    public static final String LFILTER = "LFILTER[options][product]";
    public static final String FILTER_CUSTOMERID = "FILTER[customerId]";
    public static final String FILTER_ID = "FILTER[id]";
    public static final String FILTER_LOGINNAME = "FILTER[firstName]";
    public static final String MODULE = "MODULE";
    public static final String COMMAND = "COMMAND";
    public static final String ISDEMO = "isDemo";
    public static final String DEMO_TRUE = "0";

    public static final String FILTER_REQUESTTIME_MIN = "FILTER[requestTime][min]";

    public static final String FILTER_REQUESTTIME_MAX = "FILTER[requestTime][max]";
    public static final String SPORT_GAME_KIND = "1";
    public static final String TLB_GAME_KIND = "2";
    public static final String LIVE_GAME_KIND = "3";
    public static final String ELECT_GAME_KIND = "5";
    public static final String QP_GAME_KIND = "7";
    public static final String BY_GAME_KIND = "8";
    public static final String LOTTERY_GAME_KIND = "12";

    public static final String BO_GAME_KIND_B = "61";
    public static final String BO_GAME_KIND_OB = "62";
    public static final String BO_GAME_KIND_60 = "60";
    public static final String BO_GAME_KIND_OTHER = "63";
    public static final int NORMAL_GAME = 0;
    public static final int SPECIA_GAME = 1;
    public static final BigDecimal B01_USDTCNY = new BigDecimal(6.25);

    /**
     * value从platformId修改为RebateExclusiveGame modified by ziv 2017-11-24
     * 维度增加productId modified by ziv 2017-12-12
     */
    public static Map<String, Map<String, Map<String, RebateExclusiveGame>>> rebateExclusiveGameMap = new HashMap<>();
    public static Map<String, String> accountPlatformIdMap = new HashMap<String, String>();

    static {
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_DSP, UtilConstants.DSP);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_NEW_DYJ, UtilConstants.DYJ_NEW);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_AG, UtilConstants.AGQJ);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_AGSTAR, UtilConstants.AGSTAR);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_AG2, UtilConstants.AG2);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_AGIN, UtilConstants.AGIN);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_BBIN_BLM, UtilConstants.BBIN_BLM);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_BBIN_MT, UtilConstants.BBIN_MT);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_BBIN_ZL, UtilConstants.BBIN_ZL);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_BBIN_LL, UtilConstants.BBIN_LL);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_K8, UtilConstants.K8);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_BBIN_WH, UtilConstants.BBIN_WH);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_BBIN_NEWBJH, UtilConstants.BBIN_BJH_NEW);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_BBIN_HWX, UtilConstants.BBIN_HWX);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_BBIN_KB, UtilConstants.BBIN_KB);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_BBIN_PRO, UtilConstants.BBIN_KB);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_BBIN_HJHA, UtilConstants.BBIN_HJHA);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_SHABA_UK, UtilConstants.SHABA_UK);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_SHABA_FCLRC, UtilConstants.SHABA_FCLRC);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_AMAYA_FCLRC, UtilConstants.AMAYA_FCLRC);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_AMAYA_VIP_FCLRC, UtilConstants.AMAYA_VIP_FCLRC);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_MG, UtilConstants.MG);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_MG_VIP, UtilConstants.MG_VIP);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_VMG, UtilConstants.VMG);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_RGS, UtilConstants.RGS);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_BSG, UtilConstants.BSG);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_BSG_VIP, UtilConstants.BSG_VIP);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_BBIN_E02, UtilConstants.ACCOUNT_TRANSFER_BBIN_E02);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_BBIN_E03, UtilConstants.ACCOUNT_TRANSFER_BBIN_E03);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_BBIN_E04, UtilConstants.ACCOUNT_TRANSFER_BBIN_E04);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_BBIN_B01, UtilConstants.ACCOUNT_TRANSFER_BBIN_B01);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_SBT, UtilConstants.SBT);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_PNG, UtilConstants.PNG);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_NETENT, UtilConstants.NETENT);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_PPG, UtilConstants.PPG);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_YSB, UtilConstants.YSB);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_CQ9, UtilConstants.CQ9);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_NB, UtilConstants.NB);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_PB, UtilConstants.PB);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_LC, UtilConstants.LC);

        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_XDJ, UtilConstants.XDJ);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_IM, UtilConstants.IM);
        accountPlatformIdMap.put(UtilConstants.ACCOUNT_TRANSFER_CS, UtilConstants.CS);
    }


    //A03 NewBBIN体育结果
    public static final String BBIN_ORDER_RESULT_M_1 = "-1";
    public static final String BBIN_ORDER_RESULT_0 = "0";
    public static final String BBIN_ORDER_RESULT_1 = "1";
    public static final String BBIN_ORDER_RESULT_2 = "2";
    public static final String BBIN_ORDER_RESULT_3 = "3";
    public static final String BBIN_ORDER_RESULT_4 = "4";
    public static final String BBIN_ORDER_RESULT_5 = "5";

    public static final String BBIN_ORDER_RESULT_W = "W";
    public static final String BBIN_ORDER_RESULT_C = "C";
    public static final String BBIN_ORDER_RESULT_L = "L";
    public static final String BBIN_ORDER_RESULT_X = "X";
    public static final String TAG_NAME_DATA = "data";
    public static final String TAG_NAME_CURRENCY = "Currency";

    public static final String PAYOUT_FLAG = "1";


    // EBET
    public static final String EBET_NIUNIU_GAMETYPE = "8";
    public static final Map<String, String> PROJECT_INFO = new LinkedHashMap<>();


    /**
     * IM updateBalance 操作ID清单
     */
    public enum IMRequestType {
        //
        GET_BALANCE("1000"),
        CHECK_BALANCE("1001"),
        PLACE_BET("1003"),
        PLACE_BET_REFUND("1005"),
        DANGER_REFUND("2001"),
        BT_BUY_BACK("3001"),
        BT_CANCEL_BUY_BACK("3002"),
        BT_RESTORE_BUY_BACK("3003"),
        SETTLE_HT("4001"),
        SETTLE_FT("4002"),
        SETTLE_OUTRIGHT("4003"),
        SETTLE_PARLAY("4004"),
        UNSETTLE_HT("5001"),
        UNSETTLE_FT("5002"),
        UNSETTLE_OUTRIGHT("5003"),
        UNSETTLE_PARLAY("5004"),
        CANCEL_HT("6001"),
        CANCEL_FT("6002"),
        CANCEL_OUTRIGHT("6003"),
        CANCEL_SINGLE_WAGER("6011"),
        CANCEL_PARLAY("6014"),
        UNCANCEL_HT("7001"),
        UNCANCEL_FT("7002"),
        UNCANCEL_OUTRIGHT("7003"),
        UNCANCEL_SINGLE_WAGER("7011"),
        UNCANCEL_PARLAY("7014");

        String requestType;

        IMRequestType(String requestType) {
            this.requestType = requestType;
        }

        public String getRequestType() {
            return requestType;
        }
    }
}
