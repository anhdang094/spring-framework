/**
 *
 */
package main.java.com.gw.common.framework.exception;

/**
 * @author alex.l
 */
public class GWCallRemoteApiException extends GWDataCenterException {

    private static final long serialVersionUID = -5541654256164882024L;

    /**
     * @param message
     * @param cause
     */
    public GWCallRemoteApiException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * @param message
     * @param cause
     */
    public GWCallRemoteApiException(String message) {
        super(message);
    }
}
