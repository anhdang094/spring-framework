package main.java.com.gw.common.framework.exception;


/**
 * @author Lily.Y
 * @Date 07/24/2019
 * */
public class GWCustomerCurrencyException extends GWDataCenterException{

    public  GWCustomerCurrencyException(String message) {
        super(message);
    }
}
