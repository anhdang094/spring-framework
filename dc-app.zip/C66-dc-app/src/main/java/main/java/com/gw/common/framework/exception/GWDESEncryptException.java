/**
 *
 */
package main.java.com.gw.common.framework.exception;

/**
 * @author alex.l
 */
public class GWDESEncryptException extends GWDataCenterException {

    private static final long serialVersionUID = 774253695240535360L;

    /**
     * Constructs a new exception with <code>null</code> as its
     * detail message.
     */
    public GWDESEncryptException() {
        super();
    }

    /**
     * Constructs a new exception with the specified detail message.
     *
     * @param message
     */
    public GWDESEncryptException(String message) {
        super(message);
    }
}
