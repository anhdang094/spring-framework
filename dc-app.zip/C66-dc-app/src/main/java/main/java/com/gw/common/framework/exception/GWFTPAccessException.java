/**
 *
 */
package main.java.com.gw.common.framework.exception;

/**
 * @author alex.l
 */
public class GWFTPAccessException extends GWDataCenterException {

    private static final long serialVersionUID = 6979038473442675090L;

    /**
     * @param message
     * @param cause
     */
    public GWFTPAccessException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * @param message
     */
    public GWFTPAccessException(String message) {
        super(message);
    }
}
