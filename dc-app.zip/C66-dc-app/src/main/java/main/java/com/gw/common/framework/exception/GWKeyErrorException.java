/**
 *
 */
package main.java.com.gw.common.framework.exception;

/**
 * @author alex.l
 */
public class GWKeyErrorException extends GWDataCenterException {

    private static final long serialVersionUID = -7969706113224437405L;

    /**
     * For MD5 validation
     *
     * @param message
     */
    public GWKeyErrorException(String message) {
        super(message);
    }
}
