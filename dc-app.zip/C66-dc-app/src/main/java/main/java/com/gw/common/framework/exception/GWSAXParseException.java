/**
 *
 */
package main.java.com.gw.common.framework.exception;

/**
 * @author alex.l
 */
public class GWSAXParseException extends GWDataCenterException {

    private static final long serialVersionUID = -1509967487263030172L;

    /**
     * Constructs a new exception with <code>null</code> as its
     * detail message.
     */
    public GWSAXParseException() {
        super();
    }

    /**
     * Constructs a new exception with the specified detail message.
     *
     * @param message
     */
    public GWSAXParseException(String message) {
        super(message);
    }
}
