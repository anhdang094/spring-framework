/**
 *
 */
package main.java.com.gw.common.framework.exception;

/**
 * @author alex.l
 */
public class GWServiceException extends GWDataCenterException {

    private static final long serialVersionUID = 890318760035132771L;

    public GWServiceException(String message, Throwable cause) {
        super(message, cause);
    }
}
