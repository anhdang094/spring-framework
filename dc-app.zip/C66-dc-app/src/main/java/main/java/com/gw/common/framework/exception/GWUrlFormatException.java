/**
 *
 */
package main.java.com.gw.common.framework.exception;

/**
 * @author alex.l
 */
public class GWUrlFormatException extends RuntimeException {

    private static final long serialVersionUID = -3196406348544612283L;

    /**
     * Show the URL error infos while calling remote API.
     *
     * @param errorMssage
     */
    public GWUrlFormatException(String errorMssage) {
        super(errorMssage);
    }

    public GWUrlFormatException(String errorMssage, Throwable cause) {
        super(errorMssage, cause);
    }
}
