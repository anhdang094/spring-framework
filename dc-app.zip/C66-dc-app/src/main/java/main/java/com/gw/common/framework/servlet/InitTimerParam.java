/**
 *
 */
package main.java.com.gw.common.framework.servlet;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.datacenter.accounttransferlog.entity.AccountTransferLogEntity;
import main.java.com.gw.datacenter.allocation.dao.AllocationDao;
import main.java.com.gw.datacenter.allocation.entity.AllocationEntity;
import main.java.com.gw.datacenter.gameresultlog.entity.GameResultLogEntity;
import main.java.com.gw.datacenter.orderlog.entity.OrderLogEntity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class InitTimerParam {

    private List<AllocationEntity> newAllocationList = new ArrayList<AllocationEntity>();

    private Map<Integer, AllocationEntity> allocationEntityMap = new HashMap<Integer, AllocationEntity>();

    public void init(AllocationDao dao) throws Exception {
        log.info("Run InitTimerServlet,begin to update task time...");
        try {
            /**
             * @question 这里查询 ALLOCATION_TASKS 过滤掉了 t_params表中出现的task_id
             * @answer t_params表属于历史遗留表，与业务无关，线上为空表
             */
            List<AllocationEntity> oldAllocationEntitylist = dao.getAllocationList();
            if (oldAllocationEntitylist != null && oldAllocationEntitylist.size() > 0) {
                for (AllocationEntity oldAllocationEntity : oldAllocationEntitylist) {
                    allocationEntityMap.put(oldAllocationEntity.getTaskId(), oldAllocationEntity);
                }
            }
            //for order
            updateOrder(dao);
            //for game result
            updateGameresult(dao);
            //for account transfer
            updateTransfer(dao);

            //update begintime and endtime for allocation
            if (newAllocationList.size() > 0) {
                dao.updateAllocation(newAllocationList);
            } else {
                log.info("No task need to be updated.");
            }
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
        }
        log.info("Update task time end.");
    }

    /**
     * update begin time for dsp order API.
     */
    public void updateOrder(AllocationDao dao) {
        try {
            /**
             * @question 这里是任务池是没有出现在t_params里的task，需要处理的任务来自orders_log中存在的task，获取log中该task的最晚执行之间，加上时间间隔，作为新的待执行任务？
             * @answer 是的，不同的task会计入不同的log表，所以不需要担心更新时间冲突问题
             * @question 如果一个新task从没有被执行过，也就不会出现在order_log中，这时候是怎么处理的
             * @answer 那么这个task新增时设置的默认开始和结束时间将发挥作用
             */
            List<OrderLogEntity> orderLogEntityList = dao.getTaskTimeByOrderLog();
            if (orderLogEntityList != null && orderLogEntityList.size() > 0) {
                AllocationEntity oldAllocationEntity = null;
                for (OrderLogEntity orderLogEntity : orderLogEntityList) {
                    Integer taskId = orderLogEntity.getTaskId();
                    oldAllocationEntity = allocationEntityMap.get(taskId);
                    if (null == oldAllocationEntity) {
                        log.error("Can not find taskid " + taskId + " in task list.");
                        continue;
                    }
                    oldAllocationEntity.setTaskBeginTime(ToolUtil.getNewTimeByOldEndTime(orderLogEntity.getEndTime(), oldAllocationEntity.getIncrementBegintime()));
                    oldAllocationEntity.setTaskEndTime(ToolUtil.getNewTimeByOldEndTime(orderLogEntity.getEndTime(), oldAllocationEntity.getIncrementEndtime()));
                    newAllocationList.add(oldAllocationEntity);
                }
            }
            String latestFileName = dao.getLatestFileNameByOrderLog();
            if (latestFileName != null) {
                AllocationEntity oldAllocationEntity18 = allocationEntityMap.get(18);
                oldAllocationEntity18.setUrl(latestFileName);
                newAllocationList.add(oldAllocationEntity18);
            }
            //PDATACENTER-257 棋牌抓取方式修改【平台】 AP注单是按照startID方式抓取，特殊处理
            String maxRecordId = dao.getMaxRecordIdFromOrderLog(132);
            if (maxRecordId != null) {
                AllocationEntity oldAllocationEntity132 = allocationEntityMap.get(132);
                oldAllocationEntity132.setGameCode(maxRecordId);
                newAllocationList.add(oldAllocationEntity132);
            }
            for (int taskId = 811; taskId <= 819; taskId++) {
                maxRecordId = dao.getMaxRecordIdFromOrderLog(taskId);
                if (maxRecordId != null) {
                    AllocationEntity oldAllocationEntity = allocationEntityMap.get(taskId);
                    oldAllocationEntity.setGameCode(maxRecordId);
                    newAllocationList.add(oldAllocationEntity);
                }
            }
            /**
             * @question AP 特殊处理 哪里开始的呀(#ﾟДﾟ)
             * @answer 系统中有很多类似特殊处理的代码，属于进8年来的历史遗留问题，一般不需要了解具体原因，除非明确告知需要去掉，否则不要修改
             */
            /*************************  AP 特殊处理结束  ***********************/

        } catch (Exception e) {
            log.error("Fail to update task time for order!" + e.getLocalizedMessage(), e);
        }
        log.info("Update task time for order successfully.");
    }

    /**
     * update begin time for dsp game result API.
     */
    public void updateGameresult(AllocationDao dao) {
        try {
            /**
             * @question 与gameOrders相似处理，根据特定平台最晚执行时间获取任务池，然后再次根据平台ID特殊处理？
             * @answer 是的
             * @question 本方法与updateOrder怎么保证不会更新同一个task的，导致newAllocationEntity中有重复的task？
             * @answer 不同的task会记入不同的log表，所以不需要担心一个task的log会出现在多个log表中
             * @question 这里的WHERE ll.PLATFORM_ID IN ('003','004','008','026','032') 只需要处理这几个平台吗？
             * @answer 不需要理会，写这段代码的人估计也不知道原因了
             * @question 条件判断里仅处理003和004为何？
             * @answer 同上
             * @question 游戏结果并不是所有厅方的都需要，只有公司旗下的某些平台需要？
             * @answer 2018-10-29 目前只有AGQJ厅方需要记录游戏结果
             */
            List<GameResultLogEntity> gameResultLogEntityList = dao.getTaskTimeByGameresultLog();
            if (gameResultLogEntityList != null && gameResultLogEntityList.size() > 0) {
                for (GameResultLogEntity gameResultLogEntity : gameResultLogEntityList) {
                    if (UtilConstants.AGQJ.equals(gameResultLogEntity.getPlatId())) {
                        AllocationEntity oldAllocationEntity = allocationEntityMap.get(103);
                        oldAllocationEntity.setTaskBeginTime(ToolUtil.getNewTimeByOldEndTime(gameResultLogEntity.getEndTime(), oldAllocationEntity.getIncrementBegintime()));
                        oldAllocationEntity.setTaskEndTime(ToolUtil.getNewTimeByOldEndTime(gameResultLogEntity.getEndTime(), oldAllocationEntity.getIncrementEndtime()));
                        newAllocationList.add(oldAllocationEntity);
                    } else if (UtilConstants.K8.equals(gameResultLogEntity.getPlatId())) {
                        AllocationEntity oldAllocationEntity = allocationEntityMap.get(105);
                        oldAllocationEntity.setTaskBeginTime(ToolUtil.getNewTimeByOldEndTime(gameResultLogEntity.getEndTime(), oldAllocationEntity.getIncrementBegintime()));
                        oldAllocationEntity.setTaskEndTime(ToolUtil.getNewTimeByOldEndTime(gameResultLogEntity.getEndTime(), oldAllocationEntity.getIncrementEndtime()));
                        newAllocationList.add(oldAllocationEntity);
                    }
                }
            }
            //for EA game result
            String latestFileName = dao.getLatestFileNameByGameresultLog();
            if (latestFileName != null) {
                AllocationEntity oldAllocationEntity106 = allocationEntityMap.get(106);
                if (null != oldAllocationEntity106) {
                    oldAllocationEntity106.setUrl(latestFileName);
                    newAllocationList.add(oldAllocationEntity106);
                }
            }

        } catch (Exception e) {
            log.error("Fail to update task time for game result!" + e.getLocalizedMessage(), e);
        }
        log.info("Update task time for game reslut successfully.");
    }

    /**
     * update begin time for dsp transfer order API.
     */
    public void updateTransfer(AllocationDao dao) {
        try {
            List<AccountTransferLogEntity> accountTransferLogEntityList = dao.getTaskTimeByAccountTransferLog();
            if (accountTransferLogEntityList != null && accountTransferLogEntityList.size() > 0) {
                AllocationEntity oldAllocationEntity = null;
                for (AccountTransferLogEntity accountTransferLogEntity : accountTransferLogEntityList) {
                    //Modified by Alex on 2012-11-28 -begin
                    Integer taskId = accountTransferLogEntity.getTaskId();
                    oldAllocationEntity = allocationEntityMap.get(taskId);
                    if (null == oldAllocationEntity) {
                        log.error("Can not find taskid " + taskId + " in task list.");
                        continue;
                    }
                    oldAllocationEntity.setTaskBeginTime(ToolUtil.getNewTimeByOldEndTime(accountTransferLogEntity.getEndTime(), oldAllocationEntity.getIncrementBegintime()));
                    oldAllocationEntity.setTaskEndTime(ToolUtil.getNewTimeByOldEndTime(accountTransferLogEntity.getEndTime(), oldAllocationEntity.getIncrementEndtime()));
                    newAllocationList.add(oldAllocationEntity);
                }
            }
        } catch (Exception e) {
            log.error("Fail to update task time for account transfer!" + e.getLocalizedMessage(), e);
        }
        log.info("Update task time for account transfer successfully.");
    }
}
