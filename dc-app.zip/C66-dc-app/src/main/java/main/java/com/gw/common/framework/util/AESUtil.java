package main.java.com.gw.common.framework.util;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

/**
 * @version V1.0
 * @desc AES 加密工具类
 */
public class AESUtil {

    protected static Logger log = LoggerFactory.getLogger(AESUtil.class);

    private static final String KEY_ALGORITHM = "AES";

    private static final String DEFAULT_CIPHER_ALGORITHM = "AES/ECB/PKCS5Padding";

    /**
     * AES 加密操作
     * @param content  待加密内容
     * @param secretKey 加密密码
     * @return 返回Base64转码后的加密数据
     */
    public static String encrypt(String content, String secretKey) {
        try {
            Cipher cipher = Cipher.getInstance(DEFAULT_CIPHER_ALGORITHM);
            cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(Base64.getDecoder().decode(secretKey), KEY_ALGORITHM));
            byte[] result = cipher.doFinal(content.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(result);
        } catch (Exception ex) {
            log.error("AES加密操作出现异常",ex.getMessage());
            throw new RuntimeException("AES加密操作出现异常");
        }
    }

    /**
     * AES 解密操作
     * @param content
     * @param secretKey
     * @return
     */
    public static String decrypt(String content, String secretKey) {
        if (StringUtils.isBlank(content)) {
            throw new RuntimeException("AES 解密初始数据内容不能为空");
        }
        try {
            Cipher cipher = Cipher.getInstance(DEFAULT_CIPHER_ALGORITHM);
            cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(Base64.getDecoder().decode(secretKey), KEY_ALGORITHM));
            byte[] result = cipher.doFinal(Base64.getDecoder().decode(content));
            return new String(result, StandardCharsets.UTF_8);
        } catch (Exception e) {
            log.error("AES解密操作出现异常",e.getMessage());
            throw new RuntimeException("AES解密操作出现异常");
        }
    }

    /**
     * 生成加密秘钥
     * @return
     */

    public static String generateSecretKey() throws NoSuchAlgorithmException {
        KeyGenerator keyGen = KeyGenerator.getInstance("AES");
        keyGen.init(128);
        SecretKey secretKey = keyGen.generateKey();
        byte[] key = secretKey.getEncoded();
        return Base64.getEncoder().encodeToString(key);
    }


    public static void main(String[] args )throws NoSuchAlgorithmException {
        //String secretKey="ckkYqd4OgmDTGradAe7CjQ==";
        String secretKey=generateSecretKey();
        System.out.println("输出Aes的加密秘钥信息："+secretKey);
        System.out.println("输出Aes的解密后秘钥信息："+secretKey);
        String s = "hello";
        System.out.println("s:" + s);
        String s1 = AESUtil.encrypt(s, secretKey);
        System.out.println("s1:" + s1);
        System.out.println("s2:" + AESUtil.decrypt(s1, secretKey));

    }

}