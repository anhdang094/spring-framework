package main.java.com.gw.common.framework.util;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.Key;
import java.security.spec.AlgorithmParameterSpec;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * @description: AES加解密通过key和iv向量加解密
 * @date: 2019-06-30
 * @author: EAGLE
 */
public class AesCryptUtil {

    protected static Logger log = LoggerFactory.getLogger(AesCryptUtil.class);

    private static final String KEY_ALGORITHM = "AES";

    private static final String DEFAULT_CIPHER_ALGORITHM = "AES/CBC/PKCS5Padding";

    /**
     * 通过key和IV向量进行AES加密
     * @param data
     * @param key
     * @param iv
     * @return
     */
    public static String encryptAES256(String data, String key, String iv) {

        byte[] encrypted = {};
        try {
            Cipher cipher = Cipher.getInstance(DEFAULT_CIPHER_ALGORITHM);
            cipher.init(Cipher.ENCRYPT_MODE, createKey(key), makeIv(iv));
            encrypted = cipher.doFinal(data.getBytes("UTF-8"));

        } catch (Exception e) {
            log.error("AES加密操作出现异常",e);
            throw new RuntimeException("AES加密操作出现异常");
        }
        return Base64.getEncoder().encodeToString(encrypted);

    }

    /**
     * 通过key和IV向量进行AES解密密
     * @param data
     * @param key
     * @param iv
     * @return
     */
    public static String decryptAES256(String data, String key, String iv) {
        String decrypted = "";
        try {
            Cipher cipher = Cipher.getInstance(DEFAULT_CIPHER_ALGORITHM);
            cipher.init(Cipher.DECRYPT_MODE, createKey(key), makeIv(iv));
            decrypted = new String(cipher.doFinal(Base64.getDecoder().decode(data)));

        } catch (Exception e) {
            log.error("AES解密操作出现异常参数 data={}",data,e);
            throw new RuntimeException("AES解密操作出现异常");
        }
        return decrypted;
    }

    /**
     * 生成AES加密的key
     * @param ENCRYPTION_KEY
     * @return
     */
    private static Key createKey(String ENCRYPTION_KEY) {
        try {
            byte[] key = ENCRYPTION_KEY.getBytes("UTF-8");
            return new SecretKeySpec(key, KEY_ALGORITHM);
        } catch (UnsupportedEncodingException e) {
            log.error("生成AES加密的key异常",e);
        }

        return null;
    }

    /**
     * 生成AES加密的iv
     * @param iv
     * @return
     */
    private static AlgorithmParameterSpec makeIv(String iv) {
        try {
            return new IvParameterSpec(iv.getBytes("UTF-8"));
        } catch (UnsupportedEncodingException e) {
            log.error("生成AES加密的iv异常",e);
        }
        return null;
    }

    public static void main(String[] args) {
        String key="cn!H$059X]LbDK3U)NJ205+3D}B*fcIp";
        String iv="E1ml|)0a0|8]49MP";
        String s = "hello";
        System.out.println("s:" + s);
        String s1 =AesCryptUtil.encryptAES256(s,key,iv);
        System.out.println("s1:" + s1);
        System.out.println("s2:" + AesCryptUtil.decryptAES256(s1,key,iv));
    }

}
