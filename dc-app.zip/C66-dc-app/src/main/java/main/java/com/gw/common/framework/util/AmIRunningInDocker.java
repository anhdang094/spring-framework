package main.java.com.gw.common.framework.util;

import java.io.File;

/**
 * project: GWDataCenterApp
 * author: Walter
 * create: 2019/3/20
 **/
public class AmIRunningInDocker {

    private static final String dockerSymbolFilePath = "/.dockerenv";
    public static boolean check() {
        return new File(dockerSymbolFilePath).exists();
    }

}
