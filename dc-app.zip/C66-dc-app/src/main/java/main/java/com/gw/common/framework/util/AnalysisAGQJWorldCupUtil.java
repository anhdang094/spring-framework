package main.java.com.gw.common.framework.util;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.XML;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Slf4j
public class AnalysisAGQJWorldCupUtil {

    // total records.总数
    private int totalNumber = 0;

    // error info.
    private String info = StringUtils.EMPTY;

    // 总页数
    private int totalPage = 0;

    private List<Object> betEntityList = new ArrayList<Object>();

    public int getTotalNumber() {
        return totalNumber;
    }

    public void setTotalNumber(int totalNumber) {
        this.totalNumber = totalNumber;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public List<Object> getBetEntityList() {
        return betEntityList;
    }


    public void setBetEntityList(List<Object> betEntityList) {
        this.betEntityList = betEntityList;
    }


    public static AnalysisAGQJWorldCupUtil parseAGQJWorldCupOrder(Map<String, Object> parameterMap) throws Exception {
        log.info("++++++++++AGQJ世界杯注单抓取记录+begin++parameterMap====" + parameterMap);
        AnalysisAGQJWorldCupUtil obj = new AnalysisAGQJWorldCupUtil();
        String baseUrl = (String) parameterMap.get("baseUrl");
        String platformId = (String) parameterMap.get("platformid");
        String url = UrlGeneratorUtil.generateUrlForOrderApi(parameterMap, baseUrl, platformId, UtilConstants.ENCODING_UTF8);
        String xmlStr = HttpUtil.resultHttpUrl(url);
        // String xmlStr="<result><addition><total>2</total><num_per_page>100</num_per_page></addition> <row productid=\"A01\" username=\"111111111111\" billno=\"18061405265127\" agcode=\"120\" billtime=\"2018-6-14 5:58:06\" reckontime=\"2018-6-14 5:58:06\" currency=\"CNY\" cur_ip=\"117.136.8.74\" account=\"1000000000\" cus_account=\"12.12\" valid_account=\"0\" flag=\"0\" devicetype=\"a33333\" odds=\"1.46\" optionname=\"俄罗斯\" result=\"-1\" gametype=\"11\" hometeam=\"俄罗斯\" awayteam=\"沙特阿拉伯\" groupname=\"2018世界杯小组赛\"/><row productid=\"A01\" username=\"gfweige\" billno=\"18061405265128\" agcode=\"012001001001004\" billtime=\"2018-6-14 5:58:06\" reckontime=\"2018-6-14 5:58:06\" currency=\"CNY\" cur_ip=\"117.136.8.74\" account=\"1000\" cus_account=\"12.12\" valid_account=\"0\" flag=\"0\" devicetype=\"33\" odds=\"1.36\" optionname=\"俄罗斯\" result=\"-1\" gametype=\"euro1x2\" hometeam=\"俄罗斯\" awayteam=\"沙特阿拉伯\" groupname=\"2018世界杯小组赛\"/> </result>";
        log.info("++++++++++AGQJ世界杯注单抓取记录+result+++xmlStr++====" + xmlStr);
        if (StringUtils.isBlank(xmlStr)) {
            obj.info = "empty String";
            return obj;
        }

        //利用org.json将xml转json
        JSONObject xmlJSONObj = XML.toJSONObject(xmlStr);
        JSONObject dataJSONObj = xmlJSONObj.getJSONObject("result");
        //<result><info>错误信息</info></result>
        if (!dataJSONObj.isNull("info")) {
            obj.info = (String) dataJSONObj.getString("info");
            return obj;
        }
        JSONObject additionJson = dataJSONObj.getJSONObject("addition");
        obj.totalNumber = additionJson.getInt("total");
        if (obj.totalNumber == 0) {
            return obj;
        }
        String num = (String) parameterMap.get("num");
        if ((obj.totalNumber % Integer.valueOf(num)) >= 1) {
            obj.setTotalPage((obj.totalNumber / Integer.valueOf(num)) + 1);
        } else {
            obj.setTotalPage((obj.totalNumber / Integer.valueOf(num)));
        }
        if (dataJSONObj.isNull("row")) {
            obj.setTotalPage(0);
            return obj;
        }
        Object dataObj = dataJSONObj.get("row");
        JSONArray rowArry = null;
        if (dataObj instanceof JSONObject) {
            rowArry = new JSONArray();
            rowArry.put(dataObj);
        } else {
            rowArry = dataJSONObj.getJSONArray("row");
        }
        if (rowArry != null && rowArry.length() > 0) {
            getAGQJWorldCupBetRecord(rowArry, parameterMap, obj);
            log.info("++++++++++AGQJ世界杯注单抓取记录返回" + obj.getBetEntityList().size() + "条信息++++====");
        } else {
            log.info("++++++++++AGQJ世界杯注单抓取记录返回0条信息+++++====");
        }
        return obj;
    }

    private static void getAGQJWorldCupBetRecord(JSONArray dataJsonArry, Map<String, Object> map, AnalysisAGQJWorldCupUtil obj) throws Exception {
        OrderEntity newOrderEntity = null;
        Object amountObj;
        Object resultObj;
        String platformid = (String) map.get(UtilConstants.GLOBAL_PLATFORMID_KEY);
        for (int i = 0; i < dataJsonArry.length(); i++) {
            newOrderEntity = new OrderEntity();
            JSONObject dataJSON = dataJsonArry.getJSONObject(i);
            //result结果值 类型 100 全赢 50 赢半 0 平 -50 输半  -100 全输,-1未出结果
            //flag 注单状态, 0: 未结算, 1: 已结算
            resultObj = dataJSON.get("result");
            if (resultObj != null && (resultObj instanceof Integer)) {
                newOrderEntity.setResult(String.valueOf(resultObj));
            }
            newOrderEntity.setBillNo(String.valueOf((Long) dataJSON.get("billno")));
            if ((dataJSON.get("flag")) != null && (dataJSON.get("flag") instanceof Integer)) {
                newOrderEntity.setFlag(dataJSON.getInt("flag"));
            }
            if (dataJSON.get("username") != null) {
                if ((dataJSON.get("username")) instanceof Integer) {
                    newOrderEntity.setLoginName(String.valueOf(dataJSON.getInt("username")));
                }
                if ((dataJSON.get("username")) instanceof Long) {
                    newOrderEntity.setLoginName(String.valueOf(dataJSON.getBigInteger("username")));
                } else {
                    newOrderEntity.setLoginName(dataJSON.getString("username"));
                }
            }

            newOrderEntity.setProductId(dataJSON.getString("productid"));
            newOrderEntity.setPlatId(platformid);
            newOrderEntity.setOddsType("3");//只有欧洲盘
            newOrderEntity.setGameKind("1");
            amountObj = dataJSON.get("account");
            if ((amountObj != null) && (amountObj instanceof Integer)) {
                newOrderEntity.setAccount(BigDecimal.valueOf(((Integer) amountObj).intValue()));
            }
            if ((amountObj != null) && (amountObj instanceof Double)) {
                newOrderEntity.setAccount(BigDecimal.valueOf(((Double) amountObj).doubleValue()));
            }
            amountObj = dataJSON.get("cus_account");
            if ((amountObj != null) && (amountObj instanceof Integer)) {
                newOrderEntity.setCusAccount(BigDecimal.valueOf(((Integer) amountObj).intValue()));
            }
            if ((amountObj != null) && (amountObj instanceof Double)) {
                newOrderEntity.setCusAccount(BigDecimal.valueOf(((Double) amountObj).doubleValue()));
            }
            amountObj = dataJSON.get("valid_account");
            if ((amountObj != null) && (amountObj instanceof Integer)) {
                newOrderEntity.setValidAccount(BigDecimal.valueOf(((Integer) amountObj).intValue()));
            }
            if ((amountObj != null) && (amountObj instanceof Double)) {
                newOrderEntity.setValidAccount(BigDecimal.valueOf(((Double) amountObj).doubleValue()));
            }

            if (dataJSON.get("gametype") != null) {
                if ((dataJSON.get("gametype")) instanceof Integer) {
                    newOrderEntity.setGameType(String.valueOf(dataJSON.getLong("gametype")));
                } else {
                    newOrderEntity.setGameType(dataJSON.getString("gametype"));
                }
            }

            amountObj = dataJSON.get("odds");
            if ((amountObj != null) && (amountObj instanceof Integer)) {
                newOrderEntity.setOdds(BigDecimal.valueOf(((Integer) amountObj).intValue()));
            }
            if ((amountObj != null) && (amountObj instanceof Double)) {
                newOrderEntity.setOdds(BigDecimal.valueOf(((Double) amountObj).doubleValue()));
            }
            newOrderEntity.setCurIp(dataJSON.get("cur_ip") != null ? dataJSON.getString("cur_ip") : StringUtils.EMPTY);
            if (dataJSON.get("agcode") != null) {
                if ((dataJSON.get("agcode") instanceof Integer)) {
                    newOrderEntity.setAgCode(String.valueOf(dataJSON.getInt("agcode")));
                } else if ((dataJSON.get("agcode") instanceof Long)) {
                    newOrderEntity.setAgCode(String.valueOf(dataJSON.getBigInteger("agcode")));
                } else if ((dataJSON.get("agcode") instanceof String)) {
                    newOrderEntity.setAgCode(dataJSON.getString("agcode"));
                }
            } else {
                newOrderEntity.setAgCode(StringUtils.EMPTY);
            }

            newOrderEntity.setCurrency(dataJSON.get("currency") != null ? dataJSON.getString("currency") : StringUtils.EMPTY);
            if (dataJSON.get("devicetype") != null) {
                if ((dataJSON.get("devicetype")) instanceof Integer) {
                    newOrderEntity.setDeviceType(String.valueOf(dataJSON.getInt("devicetype")));
                } else {
                    newOrderEntity.setDeviceType(dataJSON.getString("devicetype"));
                }
            }
            newOrderEntity.setBillTime(ToolUtil.transferUSEsternDateToCNEsternDate(DateUtil.formatStr2Date(dataJSON.getString("billtime"))));
            newOrderEntity.setOrignalBillTime(newOrderEntity.getBillTime());
            if (dataJSON.get("reckontime") != null && StringUtils.isNotBlank(dataJSON.getString("reckontime"))) {
                newOrderEntity.setOrignalReckonTime(ToolUtil.transferUSEsternDateToCNEsternDate(DateUtil.formatStr2Date(dataJSON.getString("reckontime"))));
                newOrderEntity.setReckonTime(newOrderEntity.getOrignalReckonTime());
            } else {
                newOrderEntity.setOrignalReckonTime(newOrderEntity.getBillTime());
                newOrderEntity.setReckonTime(newOrderEntity.getBillTime());
            }
            newOrderEntity.setTopAgCode(StringUtils.EMPTY);
            newOrderEntity.setBonusAmount(BigDecimal.ZERO);
            newOrderEntity.setCreationDate(new Date());
            obj.getBetEntityList().add(newOrderEntity);
        }
    }


    public static void main(String args[]) {
        System.out.println(100 / 100);
    }


}
