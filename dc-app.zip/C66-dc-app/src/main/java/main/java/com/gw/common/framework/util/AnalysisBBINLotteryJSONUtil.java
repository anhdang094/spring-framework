package main.java.com.gw.common.framework.util;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * BBIN彩票注单工具
 */
@Slf4j
public class AnalysisBBINLotteryJSONUtil {

    // total records.总数
    private int totalNumber = 0;

    private String code = StringUtils.EMPTY;

    // error info.
    private String info = StringUtils.EMPTY;

    // 总页数
    private int totalPage = 0;

    private List<Object> betEntityList = new ArrayList<Object>();

    public int getTotalNumber() {
        return totalNumber;
    }

    public void setTotalNumber(int totalNumber) {
        this.totalNumber = totalNumber;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public List<Object> getBetEntityList() {
        return betEntityList;
    }


    public void setBetEntityList(List<Object> betEntityList) {
        this.betEntityList = betEntityList;
    }


    public static AnalysisBBINLotteryJSONUtil parseBBINLottryOrder(Map<String, Object> parameterMap) throws Exception {
        log.info("++++++++++BBIN+注单彩票抓取记录+begin++parameterMap====" + parameterMap);
        AnalysisBBINLotteryJSONUtil lottery = new AnalysisBBINLotteryJSONUtil();
        String baseUrl = (String) parameterMap.get("baseUrl");
        String url = UrlGeneratorUtil.generateBBINBYDSUrl(parameterMap, baseUrl, UtilConstants.ENCODING_UTF8);
        /**
         * json格式 :
         *   {"result":true,"data":[],"pagination":{"Page":0,"PageLimit":300,"TotalNumber":null,"TotalPage":0}}
         *   {"result":false,"data":{"Code":"40001","Message":"The owner is not exist."}}
         *   {"result":true,"data":[{"UserName":"cautoauto","WagersID":"7356889567","WagersDate":"2018-05-31 08:10:51","GameType":"BJ3D","Result":"L","BetAmount":"32.00","Payoff":"-32.00","Currency":"RMB","ExchangeRate":"1.00000000","Commission":"0.00","IsPaid":"Y","Origin":"P","GameNum":"144"}],"pagination":{"Page":1,"PageLimit":300,"TotalNumber":"1","TotalPage":1}}
         */
        String jsonStr = HttpUtil.resultHttpUrl(url);
        if (StringUtils.isBlank(jsonStr)) {
            lottery.setInfo("empty String");
            lottery.setCode("400");
            return lottery;
        }
        JSONObject dataJSON = JSONObject.parseObject(jsonStr);
        //返回错误时候才有Code和Message
        if (!dataJSON.getBoolean("result")) {
            JSONObject statusJSON = JSONObject.parseObject(dataJSON.getString("data"));
            lottery.setInfo(statusJSON.getString("Message"));
            lottery.setCode(statusJSON.getString("Code"));
            log.info("++++++++++BBIN+注单彩票抓取记录返回错误信息+result++++====" + jsonStr);
            return lottery;
        }
        JSONObject paginationJson = JSONObject.parseObject(dataJSON.getString("pagination"));
        lottery.setTotalNumber((paginationJson.get("TotalNumber") == null || paginationJson.getInteger("TotalNumber") == 0) ? 0 : paginationJson.getInteger("TotalNumber"));
        lottery.setTotalPage((paginationJson.get("TotalPage") == null || paginationJson.getInteger("TotalPage") == 0) ? 0 : paginationJson.getInteger("TotalPage"));
        JSONArray recordArray = dataJSON.getJSONArray("data");
        if (recordArray != null && recordArray.size() > 0) {
            getBBINLotteryBetRecord(recordArray, parameterMap, lottery);
            log.info("++++++++++BBIN+注单彩票抓取记录返回" + lottery.getBetEntityList().size() + "条信息++++====");
        } else {
            log.info("++++++++++BBIN+注单彩票抓取记录返回0条信息+++++====");
        }
        return lottery;
    }

    private static void getBBINLotteryBetRecord(JSONArray dataJsonObject, Map<String, Object> map, AnalysisBBINLotteryJSONUtil lottery) throws Exception {
        OrderEntity newOrderEntity = null;
        String productId = (String) map.get(UtilConstants.ORDER_PRODUCT_ID);
        String platformid = (String) map.get(UtilConstants.ACCOUNT_TRANSFER_ACTION);//这里用这个字段存储platformId的实值
        if (dataJsonObject.size() > 0) {
            for (int i = 0; i < dataJsonObject.size(); i++) {
                newOrderEntity = new OrderEntity();
                JSONObject dataJSON = dataJsonObject.getJSONObject(i);
                //注单结果(C:注销,X:未结算,W:赢,L:输)
                String result = (dataJSON.containsKey("Result") ? dataJSON.getString("Result") : StringUtils.EMPTY);
                if (result.equalsIgnoreCase(UtilConstants.BBIN_ORDER_RESULT_W) ||
                        result.equalsIgnoreCase(UtilConstants.BBIN_ORDER_RESULT_L)) {
                    newOrderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.SETTLED.getFalg());
                } else if (result.equalsIgnoreCase(UtilConstants.BBIN_ORDER_RESULT_X)) {
                    newOrderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.UNSETTLED.getFalg());
                } else if (result.equalsIgnoreCase(UtilConstants.BBIN_ORDER_RESULT_C)) {
                    newOrderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.CANCELED.getFalg());
                }
                newOrderEntity.setResult(result);
                newOrderEntity.setLoginName(dataJSON.getString("UserName"));
                newOrderEntity.setProductId(productId);
                newOrderEntity.setPlatId(platformid);

                newOrderEntity.setGameKind((String) map.get(UtilConstants.ORDER_BBIN_GAMEKIND));
                newOrderEntity.setAccount(BigDecimal.valueOf(Double.valueOf(dataJSON.getString("BetAmount"))));
                newOrderEntity.setValidAccount(BigDecimal.valueOf(Double.valueOf(dataJSON.getString("Commission"))));
                newOrderEntity.setCusAccount(BigDecimal.valueOf(Double.valueOf(dataJSON.getString("Payoff"))));
                //洗码投资额，后面会判断是否为特惠游戏，若为特惠游戏将自动设置为0
                newOrderEntity.setRemainAmount(BigDecimal.valueOf(Double.valueOf(dataJSON.getString("Commission"))));
                if ((dataJSON.getString(UtilConstants.TAG_NAME_CURRENCY)).equalsIgnoreCase(UtilConstants.RMB)) {
                    newOrderEntity.setCurrency(UtilConstants.CURRENCY.CNY.toString());
                } else {
                    newOrderEntity.setCurrency(dataJSON.getString(UtilConstants.TAG_NAME_CURRENCY));
                }

                newOrderEntity.setAgCode(StringUtils.EMPTY);
                newOrderEntity.setTopAgCode(StringUtils.EMPTY);
                newOrderEntity.setBillNo(dataJSON.getString("WagersID"));
                newOrderEntity.setBonusAmount(BigDecimal.ZERO);
                String time = (dataJSON.containsKey("WagersDate") ? dataJSON.getString("WagersDate") : StringUtils.EMPTY);
                if (StringUtils.isNotBlank(time)) {
                    Date billTime = DateUtil.formatStr2Date(time, DateUtil.C_TIME_PATTON_DEFAULT);
                    billTime = ToolUtil.transferUSEsternDateToCNEsternDate(billTime);
                    newOrderEntity.setOrignalBillTime(billTime);
                    newOrderEntity.setCreationDate(new Date());
                    newOrderEntity.setReckonTime(billTime);
                    newOrderEntity.setOrignalReckonTime(billTime);
                    newOrderEntity.setBillTime(billTime);
                }
                newOrderEntity.setGameType((dataJSON.containsKey("GameType") ? dataJSON.getString("GameType") : StringUtils.EMPTY));
                if (StringUtils.isNotBlank(time)) {
                    Date reckonTime = DateUtil.formatStr2Date(time, DateUtil.C_TIME_PATTON_DEFAULT);
                    reckonTime = ToolUtil.transferUSEsternDateToCNEsternDate(reckonTime);
                    newOrderEntity.setReckonTime(reckonTime);
                }
                if (dataJSON.containsKey("ExchangeRate")) {
                    newOrderEntity.setExchangeRate(BigDecimal.valueOf(Double.valueOf(dataJSON.getString("ExchangeRate"))));
                }
                newOrderEntity.setGmCode((dataJSON.containsKey("GameNum") ? dataJSON.getString("GameNum") : StringUtils.EMPTY));
                newOrderEntity.setCurrency(dataJSON.getString("Currency"));
                String deviceType = (dataJSON.containsKey("Origin") ? dataJSON.getString("Origin") : StringUtils.EMPTY);
                if (deviceType.contains("P")) {
                    newOrderEntity.setDeviceType("0");
                } else {
                    newOrderEntity.setDeviceType("1");
                }
                lottery.getBetEntityList().add(newOrderEntity);
            }
        }
    }
}
