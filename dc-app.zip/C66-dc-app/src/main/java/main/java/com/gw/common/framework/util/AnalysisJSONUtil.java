package main.java.com.gw.common.framework.util;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;

/**
 * 解析json字符串 封装对象工具类
 */
public class AnalysisJSONUtil {
    // store total records.
    private int index = 0;
    private List objectList = new ArrayList();
    // total records.
    private int apiTotal = 0;
    // page size
    private int apiPageSize = 0;

    // error info.
    private String info = null;


    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public List getObjectList() {
        return objectList;
    }

    public void setObjectList(List objectList) {
        this.objectList = objectList;
    }

    public int getApiTotal() {
        return apiTotal;
    }

    public void setApiTotal(int apiTotal) {
        this.apiTotal = apiTotal;
    }

    public int getApiPageSize() {
        return apiPageSize;
    }

    public void setApiPageSize(int apiPageSize) {
        this.apiPageSize = apiPageSize;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    private static final String Code = "Code", Message = "Message", pagination = "pagination", TotalNumber = "TotalNumber", TotalPage = "TotalPage",
            Result = "Result", UserName = "UserName", ExchangeRate = "ExchangeRate", BetAmount = "BetAmount", Commissionable = "Commissionable",
            Payoff = "Payoff", WagersDate = "WagersDate", WagersID = "WagersID", GameType = "GameType", ModifiedDate = "ModifiedDate", SerialID = "SerialID";

    //New BBIN体育注单新不一样的三个增参数
    private static final String UPTIME = "UPTIME";//New BBIN体育 注单变更时间(action=ModifiedTime时，才会回传)
    private static final String OrderDate = "OrderDate";//New BBIN体育 帐务时间(action=ModifiedTime时，才会回传)
    private static final String Origin = "Origin";//New BBIN体育(0:网页、1:手机、2:ios、3:安卓)

    /**
     * 构造BBIN 捕鱼大师 捕鱼达人 注单信息返回数据对象
     * {"result":false,"data":{"Code":"44444","Message":"System is in maintenance"}}
     * {"result":true,"data":[],"pagination":{"Page":0,"PageLimit":12,"TotalNumber":"0","TotalPage":0}}
     *
     * @param jsonStr
     * @param claz
     * @param gameKind
     * @param website  修复A06捕鱼大师注单错误写入A02产品问题 add by ziv 2018-02-05
     * @return
     */
    public static AnalysisJSONUtil parseBBINBYDSOrder(String jsonStr, Class claz, String gameKind, String website) throws JSONException {
        AnalysisJSONUtil saxParseJSONUtil = new AnalysisJSONUtil();
        if (StringUtils.isBlank(jsonStr)) {
            return null;
        }
        JSONObject json = JSONObject.parseObject(jsonStr);
        JSONObject dataJSON = null;
        if (!json.getBoolean(UtilConstants.ORDER_RESULT)) {
            String errorData = json.getString(UtilConstants.TAG_NAME_DATA);
            dataJSON = JSONObject.parseObject(errorData);
            saxParseJSONUtil.setInfo(dataJSON.getString(Code).concat(UtilConstants.COMMA_SYMBOL).concat(dataJSON.getString(Message)));
            return saxParseJSONUtil;
        }
        JSONObject pageJSON = json.getJSONObject(pagination);
        //(JSONObject)JSONObject.toJSON(json.getString("pagination"));
        saxParseJSONUtil.setApiTotal(pageJSON.getInteger(TotalNumber));
        saxParseJSONUtil.setApiPageSize(pageJSON.getInteger(TotalPage));
        JSONArray array = json.getJSONArray(UtilConstants.TAG_NAME_DATA);
        if (null == array || array.size() == 0) {
            return saxParseJSONUtil;
        }
        saxParseJSONUtil.setIndex(array.size());
        for (int i = 0; i < array.size(); i++) {
            saxParseJSONUtil.getObjectList().add(setDataList(array.getJSONObject(i), gameKind, website));
        }
        return saxParseJSONUtil;
    }

    /**
     * 将json数据解析成java对象
     *
     * @param dataJSON
     * @param gameKind
     * @param website  修复A06捕鱼大师注单错误写入A02产品问题 add by ziv 2018-02-05
     * @return
     */
    private static OrderEntity setDataList(JSONObject dataJSON, String gameKind, String website) {
        OrderEntity newOrderEntity = new OrderEntity();
        //WagersRecordBy30捕鱼达人注单结果(C:注销,X:未结算,W:赢,L:输)
        String result = (dataJSON.containsKey(Result) ? dataJSON.getString(Result) : StringUtils.EMPTY);
        if (result.equalsIgnoreCase(UtilConstants.BBIN_ORDER_RESULT_W) ||
                result.equalsIgnoreCase(UtilConstants.BBIN_ORDER_RESULT_L)) {
            newOrderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.SETTLED.getFalg());
        } else if (result.equalsIgnoreCase(UtilConstants.BBIN_ORDER_RESULT_X)) {
            newOrderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.UNSETTLED.getFalg());
        } else if (result.equalsIgnoreCase(UtilConstants.BBIN_ORDER_RESULT_C)) {
            newOrderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.CANCELED.getFalg());
        }
        //WagersRecordBy31 New BB体育注单结果(0:等待结果, 1:注单异动时的中继状态, 2:平手/取消, 3:输, 4:赢, 5:无结果取消, -1:无效注单)
        else if(result.equals(UtilConstants.BBIN_ORDER_RESULT_2) ||
                result.equals(UtilConstants.BBIN_ORDER_RESULT_3) ||
                result.equals(UtilConstants.BBIN_ORDER_RESULT_4)){
            newOrderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.SETTLED.getFalg());
        } else if(result.equals(UtilConstants.BBIN_ORDER_RESULT_0) || result.equals(UtilConstants.BBIN_ORDER_RESULT_1)){
            newOrderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.UNSETTLED.getFalg());
        } else if(result.equals(UtilConstants.BBIN_ORDER_RESULT_5) || result.equals(UtilConstants.BBIN_ORDER_RESULT_M_1)){
            newOrderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.CANCELED.getFalg());
        }


        String userName;
        newOrderEntity.setResult(result);
        if (dataJSON.containsKey(UserName)) {
            userName = dataJSON.getString(UserName);
            newOrderEntity.setLoginName(userName);
            setProductIdByLoginName(newOrderEntity, userName, website);
        }
        newOrderEntity.setAccount(BigDecimal.valueOf(Double.valueOf(dataJSON.getString(BetAmount))));
        newOrderEntity.setValidAccount(BigDecimal.valueOf(Double.valueOf(dataJSON.getString(Commissionable))));
        newOrderEntity.setCusAccount(BigDecimal.valueOf(Double.valueOf(dataJSON.getString(Payoff))));
        //洗码投资额，后面会判断是否为特惠游戏，若为特惠游戏将自动设置为0
        newOrderEntity.setRemainAmount(BigDecimal.valueOf(Double.valueOf(dataJSON.getString(Commissionable))));
        if ((dataJSON.getString(UtilConstants.TAG_NAME_CURRENCY)).equalsIgnoreCase(UtilConstants.RMB)) {
            newOrderEntity.setCurrency(UtilConstants.CURRENCY.CNY.toString());
        } else {
            newOrderEntity.setCurrency(dataJSON.getString(UtilConstants.TAG_NAME_CURRENCY));
        }
        newOrderEntity.setGameKind(gameKind);
        newOrderEntity.setAgCode(StringUtils.EMPTY);
        newOrderEntity.setTopAgCode(StringUtils.EMPTY);
        newOrderEntity.setBillNo(dataJSON.getString(WagersID));
        newOrderEntity.setBonusAmount(BigDecimal.ZERO);
        String time = (dataJSON.containsKey(WagersDate) ? dataJSON.getString(WagersDate) : StringUtils.EMPTY);
        if (StringUtils.isNotBlank(time)) {
            Date billTime = DateUtil.formatStr2Date(time, DateUtil.C_TIME_PATTON_DEFAULT);

            billTime = ToolUtil.transferUSEsternDateToCNEsternDate(billTime);
            newOrderEntity.setOrignalBillTime(billTime);
            newOrderEntity.setCreationDate(new Date());
            newOrderEntity.setReckonTime(billTime);
            newOrderEntity.setOrignalReckonTime(billTime);
            newOrderEntity.setBillTime(billTime);
        }
        newOrderEntity.setGameType((dataJSON.containsKey(GameType) ? dataJSON.getString(GameType) : StringUtils.EMPTY));
        if("1".equals(gameKind)){
            //New BBIN体育注单变更时间
            time = (dataJSON.containsKey(UPTIME) ? dataJSON.getString(UPTIME) : StringUtils.EMPTY);
        }else {
            //捕鱼注单变更时间
            time = (dataJSON.containsKey(ModifiedDate) ? dataJSON.getString(ModifiedDate) : StringUtils.EMPTY);
        }
        if (StringUtils.isNotBlank(time)) {
            Date reckonTime = DateUtil.formatStr2Date(time, DateUtil.C_TIME_PATTON_DEFAULT);
            reckonTime = ToolUtil.transferUSEsternDateToCNEsternDate(reckonTime);
            newOrderEntity.setReckonTime(reckonTime);
        }
        if (dataJSON.containsKey(ExchangeRate)) {
            newOrderEntity.setExchangeRate(BigDecimal.valueOf(Double.valueOf(dataJSON.getString(ExchangeRate))));
        }
        newOrderEntity.setGmCode((dataJSON.containsKey(SerialID) ? dataJSON.getString(SerialID) : StringUtils.EMPTY));

        //New BBIN体育注单(0:网页、1:手机、2:ios、3:安卓)
        String clientType = dataJSON.containsKey(Origin) ? dataJSON.getString(Origin) : StringUtils.EMPTY;
        if("0".equals(clientType)){
            clientType = "0";
        }else{
            clientType = "1";
        }
        newOrderEntity.setDeviceType(clientType);

        //New BBIN体育注单 账务时间 目前还不知道有什么用处
        String orderDate = dataJSON.containsKey(OrderDate) ? dataJSON.getString(OrderDate) : StringUtils.EMPTY;

        return newOrderEntity;
    }

    /**
     * 从loginName里获取productId，这个接口返回的是所有平台的
     *
     * @param userName
     * @param website  修复A06捕鱼大师注单错误写入A02产品问题 add by ziv 2018-02-05
     * @return
     */
    public static void setProductIdByLoginName(OrderEntity newOrderEntity, String userName, String website) {
        String loginName_PREFIX = userName.substring(0, 1);
        if (loginName_PREFIX.endsWith(UtilConstants.A01REALPREFIX)) {
            newOrderEntity.setProductId(UtilConstants.PRODUCT_ENUM.A01.name());
            newOrderEntity.setPlatId(UtilConstants.BBIN_BLM);
        } else if (loginName_PREFIX.endsWith(UtilConstants.A02REALPREFIX) && UtilConstants.A02_BBIN_BYDS_WEBSITE.equals(website)) {
            newOrderEntity.setProductId(UtilConstants.PRODUCT_ENUM.A02.name());
            newOrderEntity.setPlatId(UtilConstants.BBIN_MT);
        } else if (loginName_PREFIX.endsWith(UtilConstants.A03REALPREFIX) || loginName_PREFIX.endsWith(UtilConstants.A03REALPREFIX_NWE)) {
            newOrderEntity.setProductId(UtilConstants.PRODUCT_ENUM.A03.name());
            newOrderEntity.setPlatId(UtilConstants.BBIN_HWX);
        } else if (loginName_PREFIX.endsWith(UtilConstants.A06REALPREFIX) && UtilConstants.A06_BBIN_BYDS_WEBSITE.equals(website)) {
            newOrderEntity.setProductId(UtilConstants.PRODUCT_ENUM.A06.name());
            newOrderEntity.setPlatId(UtilConstants.BBIN_KB);
        } else if (loginName_PREFIX.endsWith(UtilConstants.C01REALPREFIX)) {
            newOrderEntity.setProductId(UtilConstants.PRODUCT_ENUM.C01.name());
            newOrderEntity.setPlatId(UtilConstants.BBIN_WH);
        } else if (loginName_PREFIX.endsWith(UtilConstants.A04REALPREFIX)) {
            newOrderEntity.setProductId(UtilConstants.PRODUCT_ENUM.A04.name());
            newOrderEntity.setPlatId(UtilConstants.BBIN_ZL);
        } else if (loginName_PREFIX.endsWith(UtilConstants.A05REALPREFIX)) {
            newOrderEntity.setProductId(UtilConstants.PRODUCT_ENUM.A05.name());
            newOrderEntity.setPlatId(UtilConstants.BBIN_LL);
        } else if (loginName_PREFIX.endsWith(UtilConstants.C02REALPREFIX)) {
            newOrderEntity.setProductId(UtilConstants.PRODUCT_ENUM.C02.name());
            newOrderEntity.setPlatId(UtilConstants.BBIN_HJHA);
        } else if (loginName_PREFIX.endsWith(UtilConstants.E02REALPREFIX)) {
            newOrderEntity.setProductId(UtilConstants.PRODUCT_ENUM.B01.toString());
            newOrderEntity.setPlatId(UtilConstants.BBIN_BLM);
        } else if (loginName_PREFIX.endsWith(UtilConstants.E03REALPREFIX)) {
            newOrderEntity.setProductId(UtilConstants.PRODUCT_ENUM.E03.toString());
            newOrderEntity.setPlatId(UtilConstants.BBIN_BLM);
        } else if (loginName_PREFIX.endsWith(UtilConstants.E04REALPREFIX)) {
            newOrderEntity.setProductId(UtilConstants.PRODUCT_ENUM.E04.toString());
            newOrderEntity.setPlatId(UtilConstants.BBIN_BLM);
        } else if (loginName_PREFIX.endsWith(UtilConstants.B01REALPREFIX)) {
            newOrderEntity.setProductId(UtilConstants.PRODUCT_ENUM.B01.toString());
            newOrderEntity.setPlatId(UtilConstants.BBIN_BLM);
        } else {
            newOrderEntity.setProductId(userName.substring(0, 3).toUpperCase());
            newOrderEntity.setPlatId(UtilConstants.BBIN_BLM);
        }
    }

}
