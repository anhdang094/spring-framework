package main.java.com.gw.common.framework.util;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * 解析json字符串 封装对象工具类
 */
public class AnalysisTLBJSONUtil {

    // total records.
    private int totalrecord = 0;

    private String code = "";

    // error info.
    private String info = "";

    private List<OrderEntity> tlbBetEntityList = new ArrayList<OrderEntity>();


    public int getTotalrecord() {
        return totalrecord;
    }

    public void setTotalrecord(int totalrecord) {
        this.totalrecord = totalrecord;
    }


    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public List<OrderEntity> getTlbBetEntityList() {
        return tlbBetEntityList;
    }

    public void setTlbBetEntityList(List<OrderEntity> tlbBetEntityList) {
        this.tlbBetEntityList = tlbBetEntityList;
    }


    public void parseTLBSOrder(String jsonStr, String productId) throws Exception {
        JSONObject json = JSONObject.parseObject(jsonStr);
        JSONObject statusJSON = json.getJSONObject("error");
        String code = statusJSON.getString("code");
        this.code = code;
        if (!code.equals("0")) {
            this.setInfo(statusJSON.getString("msg"));
            throw new Exception("Response error："+statusJSON.getString("msg"));
        } else {
            JSONObject dataJSON = json.getJSONObject("data");
            if (dataJSON.getInteger("totalrecord") > 0) {
                this.totalrecord = dataJSON.getInteger("totalrecord");
                JSONArray recordArray = dataJSON.getJSONArray("records");
                getTLBBetRecord(recordArray, productId);
            }
        }
    }


    private static final String[] TLB_DEVICETYPE_PC = {"16", "17", "48", "49", "64", "65", "67"};

    private void getTLBBetRecord(JSONArray dataJsonObject, String productId) throws Exception {

        OrderEntity orderEntity = null;
        String tfproductId = productId;
        productId = productId.replace("PHP", StringUtils.EMPTY);
        if (dataJsonObject.size() > 0) {
            for (int i = 0; i < dataJsonObject.size(); i++) {
                orderEntity = new OrderEntity();
                JSONObject betDetailJson = dataJsonObject.getJSONObject(i);
                orderEntity.setBillNo(betDetailJson.getString("billno"));
                orderEntity.setLoginName((betDetailJson.getString("loginname")).replace(tfproductId, StringUtils.EMPTY));
                orderEntity.setProductId(productId);
                orderEntity.setPlatId(UtilConstants.TLB);
                BigDecimal rate = BigDecimal.ONE;
                if (betDetailJson.getString("rate") != null) {
                    rate = new BigDecimal(betDetailJson.getString("rate"));
                }
                orderEntity.setAccount(new BigDecimal(betDetailJson.getString("bet")).divide(rate, 2, BigDecimal.ROUND_HALF_EVEN));
                orderEntity.setValidAccount(new BigDecimal(betDetailJson.getString("profit")).divide(rate, 2, BigDecimal.ROUND_HALF_EVEN));
                orderEntity.setCusAccount(new BigDecimal(betDetailJson.getString("winlost")).divide(rate, 2, BigDecimal.ROUND_HALF_EVEN));
                if (Arrays.asList(TLB_DEVICETYPE_PC).contains((betDetailJson.getString("devicetype")))) {
                    orderEntity.setDeviceType("0");
                } else {
                    orderEntity.setDeviceType("101");
                }
                orderEntity.setFlag(1);
                orderEntity.setPlayType(Integer.parseInt(betDetailJson.getString("playtype")));
                orderEntity.setGmCode(betDetailJson.getString("gmcode"));
                orderEntity.setCurrency(UtilConstants.CURRENCY.CNY.toString());
                orderEntity.setGameType(betDetailJson.getString("gametype"));
                orderEntity.setBillTime(new Date((betDetailJson.getLong("time")) * 1000));
                orderEntity.setCreationDate(new Date());
                tlbBetEntityList.add(orderEntity);
            }
        }
    }


}
