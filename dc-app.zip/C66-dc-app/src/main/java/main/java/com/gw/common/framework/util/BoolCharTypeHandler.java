/**
 *
 */
package main.java.com.gw.common.framework.util;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.TypeHandler;

/**
 * Type handler used in mybatis converting Java boolean to JDBC Char
 *
 * @author kwan.lau
 */
public class BoolCharTypeHandler implements TypeHandler {
    private static final String TRUE_VALUE = "1";
    private static final String FALSE_VALUE = "0";

	/* (non-Javadoc)
	 * @see org.apache.ibatis.type.TypeHandler#getResult(java.sql.ResultSet, java.lang.String)
	 */

    public Object getResult(ResultSet rs, String name) throws SQLException {
        return valueOf(rs.getString(name));
    }

	/* (non-Javadoc)
	 * @see org.apache.ibatis.type.TypeHandler#getResult(java.sql.CallableStatement, int)
	 */

    public Object getResult(CallableStatement cs, int pos) throws SQLException {
        return Boolean.valueOf(cs.getString(pos));
    }

	/* (non-Javadoc)
	 * @see org.apache.ibatis.type.TypeHandler#setParameter(java.sql.PreparedStatement, int, java.lang.Object, org.apache.ibatis.type.JdbcType)
	 */

    public void setParameter(PreparedStatement ps, int pos, Object val, JdbcType jdbcType) throws SQLException {
        if (!(val instanceof Boolean)) {
            throw new SQLException("Boolean value should be pass-in");
        }
        ps.setString(pos, val == null ? null : Boolean.TRUE.equals(val) ? TRUE_VALUE : FALSE_VALUE);
    }

    @Override
    public Object getResult(ResultSet rs, int i) throws SQLException {
        return valueOf(rs.getString(i));
    }

    private Boolean valueOf(String v) {
        if (TRUE_VALUE.equals(v)) {
            return Boolean.TRUE;
        } else if (FALSE_VALUE.equals(v)) {
            return Boolean.FALSE;
        }

        return null;
    }
}
