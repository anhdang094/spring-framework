package main.java.com.gw.common.framework.util;

import java.util.Date;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 缓存池~~~~~~~~~~~~~~~~
 *
 * @author Like.K
 */
public class CachePool {
    private static CachePool instance;

    private static Map<String, Object> cacheItems;

    private CachePool() {
        cacheItems = new ConcurrentHashMap<>();
    }

    public static synchronized CachePool getInstance() {
        if (Objects.isNull(instance)) {
            instance = new CachePool();
        }
        return instance;
    }

    /**
     * 清除缓存所有的信息
     */
    public void clearAllItems() {
        cacheItems.clear();
    }

    /**
     * 是否存在key的信息
     *
     * @param key
     * @return
     */
    public boolean existsKey(String key) {
        return (cacheItems.containsKey(key));
    }


    public Object getCacheItem(String key) {
        if (!cacheItems.containsKey(key)) {
            return null;
        }
        CacheItem cacheItem = (CacheItem) cacheItems.get(key);
        if (cacheItem.isExpired()) {
            return null;
        }
        return cacheItem.getEntity();
    }


    /**
     * 存放缓存信息
     *
     * @param key
     * @param obj
     * @param expire
     */
    public void putCacheItem(String key, Object obj, long expire) {
        if (!cacheItems.containsKey(key)) {
            cacheItems.put(key, new CacheItem(obj, expire));
        }
        CacheItem cacheItem = (CacheItem) cacheItems.get(key);
        cacheItem.setCreateTime(new Date());
        cacheItem.setEntity(obj);
        cacheItem.setExpireTime(expire);
    }

    public void putCacheItem(String key, Object obj) {
        //-1：永不过期
        putCacheItem(key, obj, -1);
    }

    public void removeCacheItem(String key) {
        if (!cacheItems.containsKey(key)) {
            return;
        }
        cacheItems.remove(key);
    }

    /**
     * 获取缓存数据的数量
     *
     * @return
     */
    public int getSize() {
        return cacheItems.size();
    }


    public static class CacheItem {
        private Date createTime = new Date();
        private long expireTime = 1;
        private Object entity;

        public CacheItem(Object obj, long expire) {
            this.entity = obj;
            this.expireTime = expire;
        }

        public boolean isExpired() {
            return (expireTime != -1 && new Date().getTime() - createTime.getTime() > expireTime);
        }

        public Date getCreateTime() {
            return createTime;
        }

        public void setCreateTime(Date createTime) {
            this.createTime = createTime;
        }

        public long getExpireTime() {
            return expireTime;
        }

        public void setExpireTime(long expireTime) {
            this.expireTime = expireTime;
        }

        public Object getEntity() {
            return entity;
        }

        public void setEntity(Object entity) {
            this.entity = entity;
        }
    }

}



