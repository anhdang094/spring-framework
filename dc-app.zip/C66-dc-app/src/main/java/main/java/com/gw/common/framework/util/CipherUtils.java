package main.java.com.gw.common.framework.util;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.security.MessageDigest;

/**
 * AGQJ 新GI接口厅方加密工具类
 */
public class CipherUtils {


    /**
     * @param inStr
     * @return String
     * @Description: <字符串加密成md5密文>
     */
    public static String string2MD5CipherText(String inStr) throws Exception {
        byte[] string2md5Byte = string2MD5CipherByte(inStr);
        return parseByte2HexStr(string2md5Byte);
    }

    /**
     * @param inStr
     * @return String
     * @Description: <字符串加密成md5二进制数组>
     */
    public static byte[] string2MD5CipherByte(String inStr) throws Exception {
        if (inStr == null) {
            return null;
        }
        MessageDigest md5 = MessageDigest.getInstance("MD5");
        byte[] bytes = inStr.getBytes("utf-8");
        return md5.digest(bytes);
    }

    /**
     * @param key  加密的key
     * @param text 需要加密的字符串
     * @return String字符串密文
     * @Description: <字符串加密成AES密文>
     */
    public static String string2AESCipherText(String key, String text) throws Exception {
        byte[] cipherByte = string2AESCipherByte(key, text);
        return parseByte2HexStr(cipherByte);
    }

    /**
     * @param md5Key 编码后的AESkey
     * @param text   待加密的字符串
     * @return byte[] 加密后的byte[] 数组
     * @Description: <根据加密key加密字符串 >
     * @Time:2017年12月 26日下午1:55:13
     */
    public static byte[] string2AESCipherByte(String md5Key, String text) throws Exception {
        byte[] key = parseByte2HexStr(md5Key);

        SecretKeySpec sKeySpec = new SecretKeySpec(key, "AES");
        byte[] cipherByte = null;
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding"); //
        cipher.init(Cipher.ENCRYPT_MODE, sKeySpec);
        cipherByte = cipher.doFinal(text.getBytes("utf-8"));
        return cipherByte;
    }

    /**
     * @param hexStr
     * @return
     * @throws
     * @method parseByte2HexStr
     * @since v1.0
     */
    public static byte[] parseByte2HexStr(String hexStr) {
        if (hexStr.length() < 1)
            return null;
        byte[] result = new byte[hexStr.length() / 2];
        for (int i = 0; i < hexStr.length() / 2; i++) {
            int high = Integer.parseInt(hexStr.substring(i * 2, i * 2 + 1), 16);
            int low = Integer.parseInt(hexStr.substring(i * 2 + 1, i * 2 + 2), 16);
            result[i] = (byte) (high * 16 + low);
        }
        return result;
    }

    /**
     * 将二进制转换成16进制
     *
     * @param buf
     * @return
     * @throws
     * @method parseByte2HexStr
     * @since v1.0
     */
    public static String parseByte2HexStr(byte buf[]) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < buf.length; i++) {
            String hex = Integer.toHexString(buf[i] & 0xFF);
            if (hex.length() == 1) {
                hex = '0' + hex;
            }
            sb.append(hex.toUpperCase());
        }
        return sb.toString();
    }

}
