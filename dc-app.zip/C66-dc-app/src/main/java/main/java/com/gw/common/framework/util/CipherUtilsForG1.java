package main.java.com.gw.common.framework.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sun.misc.BASE64Decoder;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * @author Dominik.X
 * @description
 * @date 2019/6/18 15:14
 */
public class CipherUtilsForG1 {
    private static final Logger log = LoggerFactory.getLogger(CipherUtilsForG1.class);
    public static final String KEY = "LXDCKEY1";
    public static final String IV = "LXDCKEY2";

    public static String encrypt(String content)  {
        try {
            Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
            byte[] dataBytes = content.getBytes();
            SecretKeySpec keyspec = new SecretKeySpec(KEY.getBytes(), "DES");
            IvParameterSpec ivspec = new IvParameterSpec(IV.getBytes());
            cipher.init(Cipher.ENCRYPT_MODE, keyspec, ivspec);
            byte[] encrypted = cipher.doFinal(dataBytes);
            return new sun.misc.BASE64Encoder().encode(encrypted);

        } catch (Exception e) {
            log.error("g1彩票解密加密", e);
            return null;
        }
    }

    public CipherUtilsForG1() {
    }

    public static String desEncrypt(String content)  {
        try {
            //先用Base64解码
            byte[] encrypted1 = new BASE64Decoder().decodeBuffer(content);
            Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
            SecretKeySpec keyspec = new SecretKeySpec(KEY.getBytes(), "DES");
            IvParameterSpec ivspec = new IvParameterSpec(IV.getBytes());
            cipher.init(Cipher.DECRYPT_MODE, keyspec, ivspec);
            byte[] original = cipher.doFinal(encrypted1);
            String originalString = new String(original);
            return originalString;
        } catch (Exception e) {
            log.error("g1彩票解密失败", e);
            return null;
        }
    }
}
