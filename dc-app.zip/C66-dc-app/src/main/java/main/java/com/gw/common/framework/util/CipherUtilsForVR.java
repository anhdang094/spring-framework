package main.java.com.gw.common.framework.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Security;
import java.util.Base64;

/**
 * @Description: VR彩票加密工具
 * @Author: Hopkin
 * @Date: 2019/4/6 16:05
 * @Version: 1.0
 */

public class CipherUtilsForVR {

    private static final Logger log = LoggerFactory.getLogger(CipherUtilsForVR.class);

    static{
        try {
            if(Security.getProvider("BC") == null){
                Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
            }else{
                Security.removeProvider("BC");
                Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
    }

    public static String encrypt(String key, String str) {
        String encryptValue = "";
        byte[] keyByte = key.getBytes();
        byte[] plaintext = null;
        try {
            plaintext = str.getBytes("UTF-8");
        } catch (UnsupportedEncodingException ue) {
           log.error(ue.getMessage(),ue);
        }

        try {
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS7Padding", "BC");
            SecretKeySpec keySpec = new SecretKeySpec(keyByte, "AES");

            cipher.init(Cipher.ENCRYPT_MODE, keySpec);

            byte[] cipherText = cipher.doFinal(plaintext);
            encryptValue = Base64.getEncoder().encodeToString(cipherText);

            log.info("encrypt:"+encryptValue);
        } catch (InvalidKeyException e) {
            log.error(e.getMessage(),e);
        } catch (NoSuchAlgorithmException e) {
            log.error(e.getMessage(),e);
        } catch (NoSuchPaddingException e) {
            log.error(e.getMessage(),e);
        } catch (IllegalBlockSizeException e) {
            log.error(e.getMessage(),e);
        } catch (BadPaddingException e) {
            log.error(e.getMessage(),e);
        } catch (NoSuchProviderException e) {
            log.error(e.getMessage(),e);
        }
        return encryptValue;
    }

    public static String decrypt(String key, String str) {
        String encryptValue = "";
        byte[] keyByte = key.getBytes();

        byte[] plainText = null;
        try {
            plainText = str.getBytes("UTF-8");
        } catch (UnsupportedEncodingException ue) {
            log.error(ue.getMessage(),ue);
        }

        try {
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS7Padding", "BC");
            SecretKeySpec keySpec = new SecretKeySpec(keyByte, "AES");

            cipher.init(Cipher.DECRYPT_MODE, keySpec);
            byte[] bys = cipher.doFinal(Base64.getDecoder().decode(plainText));

            try {
                encryptValue = new String(bys, "UTF-8");
                log.info("decrypt:"+encryptValue);
            } catch (UnsupportedEncodingException ue) {
                log.error(ue.getMessage(),ue);
            }

        } catch (InvalidKeyException e) {
            log.error(e.getMessage(),e);
        } catch (NoSuchAlgorithmException e) {
            log.error(e.getMessage(),e);
        } catch (NoSuchPaddingException e) {
            log.error(e.getMessage(),e);
        } catch (IllegalBlockSizeException e) {
            log.error(e.getMessage(),e);
        } catch (BadPaddingException e) {
            log.error(e.getMessage(),e);
        } catch (NoSuchProviderException e) {
            log.error(e.getMessage(),e);
        }
        return encryptValue;
    }
}