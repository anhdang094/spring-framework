package main.java.com.gw.common.framework.util;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.datacenter.accounttransfer.entity.AccountTransferEntity;
import main.java.com.gw.datacenter.order.entity.OrderEntity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;


/**
 * @author Miles on 2016-8-1
 */
@Slf4j
public class CurrencyUtil {

    public static final String GAME_CURRENCY_TRANSFER = ".game.currency.transfer";

    public static final BigDecimal TRANSFER_VAL = new BigDecimal(1000);


    public static void multiplyAccountTransferVal(AccountTransferEntity transferEntity) {
        if (null == transferEntity) {
            return;
        }

        if (null != transferEntity.getCurrentAmount()) {
            transferEntity.setCurrentAmount(transferEntity.getCurrentAmount().multiply(TRANSFER_VAL));
        }

        if (null != transferEntity.getPreviousAmount()) {
            transferEntity.setPreviousAmount(transferEntity.getPreviousAmount().multiply(TRANSFER_VAL));
        }

        if (null != transferEntity.getTransferAmount()) {
            transferEntity.setTransferAmount(transferEntity.getTransferAmount().multiply(TRANSFER_VAL));
        }

    }


    public static void multiplyOrderTransferVal(OrderEntity orderEntity) {
        if (null == orderEntity) return;

        if (null != orderEntity.getAccount()) {
            orderEntity.setAccount(orderEntity.getAccount().multiply(TRANSFER_VAL));
        }

        if (null != orderEntity.getBonusAmount()) {
            orderEntity.setBonusAmount(orderEntity.getBonusAmount().multiply(TRANSFER_VAL));
        }

        if (null != orderEntity.getCusAccount()) {
            orderEntity.setCusAccount(orderEntity.getCusAccount().multiply(TRANSFER_VAL));
        }

        if (null != orderEntity.getNetAccount()) {
            orderEntity.setNetAccount(orderEntity.getNetAccount().multiply(TRANSFER_VAL));
        }

        if (null != orderEntity.getPreviosAmount()) {
            orderEntity.setPreviosAmount(orderEntity.getPreviosAmount().multiply(TRANSFER_VAL));
        }

        if (null != orderEntity.getTip()) {
            orderEntity.setTip(orderEntity.getTip().multiply(TRANSFER_VAL));
        }

        if (null != orderEntity.getValidAccount()) {
            orderEntity.setValidAccount(orderEntity.getValidAccount().multiply(TRANSFER_VAL));
        }

        if (null != orderEntity.getRemainAmount()) {//新增加了remainAmount字段，所以也要加这个
            orderEntity.setRemainAmount(orderEntity.getRemainAmount().multiply(TRANSFER_VAL));
        }

    }


    public static void main(String[] args) {
/*		BigDecimal amount = new BigDecimal("622.5541");
        BigDecimal bd = CurrencyUtil.removeDecimal("C07_OPUS", amount);
		
		System.out.println("Bd: " + bd);*/
		
/*		System.out.println("div: " + (BigDecimal.ZERO.compareTo(new BigDecimal(0.0000)) == 0));
		
		System.out.println("div: " + (BigDecimal.ZERO.compareTo(new BigDecimal(0.0000)) == 0));*/


        OrderEntity obj = new OrderEntity();
        obj.setProductId("C07");
        obj.setAccount(new BigDecimal(23.51));
        obj.setValidAccount(new BigDecimal(754.21));
        //System.out.println(multiplyTransferVal(obj));

        List<Object> list = new ArrayList<Object>();
        list.add(obj);
        //System.out.println(multiplyOrderTransferVal("C07", list));

    }

}
