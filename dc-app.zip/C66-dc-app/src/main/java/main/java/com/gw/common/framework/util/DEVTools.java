package main.java.com.gw.common.framework.util;

import lombok.extern.slf4j.Slf4j;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Ricardo.X
 */
@Slf4j
public class DEVTools {

    /**
     * DEV tool -->> read content of a text file into memory as a string object.
     *
     * @param path
     * @return
     */
    public static String readTextFile2String(String path) {

        StringBuilder sb = new StringBuilder();

        try {
            BufferedReader br = getBufferedReader(path);
            while (true) {
                String line = br.readLine();
                if (line == null)
                    break;
                sb.append(line);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        return sb.toString();
    }


    /**
     * DEV tool -->> read content of a text file into memory as a string list.
     *
     * @param path
     * @return
     */
    public static List<String> readTextFile2List(String path) {

        List<String> list = new ArrayList<String>();

        try {
            BufferedReader br = getBufferedReader(path);
            while (true) {
                String line = br.readLine();
                if (line == null)
                    break;
                list.add(line);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return list;
    }

    private static BufferedReader getBufferedReader(String path) throws Exception {
        return new BufferedReader(new InputStreamReader(new FileInputStream(new File(path))));
    }


    public void gemSQL() {

        List<String> list = DEVTools.readTextFile2List("D:/allocation_tasks.csv");

        for (String line : list) {
            String[] arr = line.split(",");

            System.out.println("update allocation_tasks set product_id='" + arr[1] + "', platform_id='" + arr[2] + "' where task_id=" + arr[0] + ";");
        }
    }
}
