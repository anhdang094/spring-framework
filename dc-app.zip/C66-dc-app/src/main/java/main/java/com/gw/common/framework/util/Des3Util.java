/**
 *
 */
package main.java.com.gw.common.framework.util;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.exception.GWDESEncryptException;
import org.apache.commons.codec.binary.Base64;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.Security;
import java.security.spec.InvalidKeySpecException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

/**
 * Utility used to encrypt/decrypt string to/from DES3
 *
 * @author kwan.lau
 */
@Slf4j
public class Des3Util {

    /**
     * Algorithm: 3DES
     */
    private static final String ALGORITHM = "DESede";
    /**
     * DES Mode: ECB
     */
    private static final String MODE = "ECB";
    /**
     * Padding: PKCS7PADDING
     */
    private static final String PADDING = "PKCS7PADDING";
    private static final String SEP = "/";
    private static final String TRANSFORMATION = ALGORITHM + SEP + MODE + SEP + PADDING;

    // Add the security provider
    static {
        Security.addProvider(new BouncyCastleProvider());
    }

    /**
     * Encrypt the value by 3DES with the key
     *
     * @param src The value to be encrypted
     * @param key The key used for encryption
     * @return String
     * @throws GWDESEncryptException
     */
    public static final String encrypt(String src, String key) throws GWDESEncryptException {
        Base64 base64 = new Base64();
        try {
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.ENCRYPT_MODE, generateKey(key));
            return base64.encodeToString(cipher.doFinal(src.getBytes("UTF-8")));
        } catch (Exception e) {
            log.error("Des3Util encrypt error:" + e.getMessage(), e);
            throw new GWDESEncryptException(e.getMessage());
        }
    }

    /**
     * Decrypt the value by 3DES with the key
     *
     * @param src The value to be decrypted
     * @param key The key used for decryption
     * @return
     * @throws InvalidKeyException
     * @throws IllegalBlockSizeException
     * @throws BadPaddingException
     * @throws NoSuchAlgorithmException
     * @throws NoSuchPaddingException
     * @throws InvalidKeySpecException
     * @throws UnsupportedEncodingException
     */
    public static final String decrypt(String src, String key) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, UnsupportedEncodingException {
        Base64 base64 = new Base64();
        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        cipher.init(Cipher.DECRYPT_MODE, generateKey(key));
        return new String(cipher.doFinal(base64.decode(src.getBytes())));
    }

    /**
     * Generate the secret key to be used for encryption / decryption
     *
     * @param key
     * @return
     * @throws NoSuchAlgorithmException
     * @throws InvalidKeyException
     * @throws InvalidKeySpecException
     * @throws UnsupportedEncodingException
     */
    private static SecretKey generateKey(String key) throws NoSuchAlgorithmException, InvalidKeyException, InvalidKeySpecException, UnsupportedEncodingException {
        DESedeKeySpec keySpec = new DESedeKeySpec(getKeyBytesByString(key));
        SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(ALGORITHM);
        /*
         * DESKeySpec keySpec = new DESKeySpec(keyBytes); SecretKeyFactory
         * keyFactory = SecretKeyFactory.getInstance(ALGORITHM);
         */
        return keyFactory.generateSecret(keySpec);
    }

    /**
     * Get the bytes to be used for generating the secret key
     *
     * @param key
     * @return
     * @throws NoSuchAlgorithmException
     * @throws UnsupportedEncodingException
     */
    private static byte[] getKeyBytesByString(String key) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(key.getBytes("UTF-8"));
        byte[] keyBytes = md.digest();
        byte[] paddedKeyBytes = new byte[24];
        for (int i = 0; i < paddedKeyBytes.length; i++) {
            paddedKeyBytes[i] = keyBytes[i % keyBytes.length];
        }
        return paddedKeyBytes;
    }

    public static void main(String[] args) throws Exception {
        Calendar currentDate = Calendar.getInstance();
        currentDate.add(Calendar.HOUR_OF_DAY, -8);
        SimpleDateFormat df = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss 'GMT'", Locale.ENGLISH);
        String src = df.format(currentDate.getTime());
        String key = "mbczsfhkpiyrwxt";
        // String src = "Sat, 28 Nov 2009 07:53:22 GMT";
        // String key = "aasdfasdfasdf";
        // String encrypted = encrypt("Wed, 18 Apr 2012 03:48:44 GMT", key);
        String encrypted = encrypt(src, key);
        System.out.println(encrypted);
        String decrypted = decrypt(encrypted, key);
        // String decrypted = decrypt("SIjSk4Y2dnB0pGTfrbUgxwluHowCuvKaPpv6BrRmosY=", key);
        // String decrypted = decrypt("cFlPia6sFM10pGTfrbUgxxPijdl/TCwU7roCi2AIDdg=", key);
        System.out.println(decrypted);
    }
}
