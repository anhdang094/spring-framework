/**
 *
 */
package main.java.com.gw.common.framework.util;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWFTPAccessException;
import sun.net.ftp.FtpClient;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;


/**
 * @author alex.l
 */
@Slf4j
public class FTPUtil {

    private String ip;
    private int port;
    private String user;
    private String pwd;
    private String remotePath;
    private String localPath;
    public FtpClient ftpClient;
    public boolean isConnection = false;

    /**
     * Connect FTP Server
     *
     * @param ip
     * @param port
     * @param user
     * @param pwd
     * @return
     * @throws Exception
     */
    public boolean connectServer(String ip, int port, String user, String pwd)
            throws Exception {
        try {
            ftpClient = FtpClient.create(ip);
            //use the default port
            //ftpClient.openServer(ip, port);
            //ftpClient.openServer(ip);
            ftpClient.login(user, pwd.toCharArray());
            this.isConnection = ftpClient.isConnected();
        } catch (Exception ex) {
            log.error("FTPUtil connectServer error:" + ex.getMessage(), ex);
            throw new Exception("Connect ftp server error:" + ex.getMessage());
        }
        return isConnection;
    }

    /**
     * get XML by TelnetInputStream
     *
     * @param remotePath
     * @param filename
     * @return String
     * @throws GWFTPAccessException
     */
    public String getXmlString(String remotePath, String filename) throws GWFTPAccessException {
        InputStream inputStream = null;
        BufferedReader bufferReader = null;
        String xmlStr = null;
        StringBuffer xmlString = new StringBuffer();
        try {
            if (!isConnection) {
                connectServer(ip, port, user, pwd);
            }
            if (remotePath.length() != 0) {
                ftpClient.changeDirectory(remotePath);
            }
            ftpClient.setBinaryType();
            inputStream = ftpClient.getFileStream(filename);
            if (inputStream != null) {
                bufferReader = new BufferedReader(new InputStreamReader(inputStream));
                while ((xmlStr = bufferReader.readLine()) != null) {
                    xmlString.append(xmlStr);
                }
            }
            return xmlString.toString();
        } catch (Exception ex) {
            isConnection = false;
            try {
                if (ftpClient != null) {
                    ftpClient.close();
                }
            } catch (IOException ioe) {
            }
            throw new GWFTPAccessException(ex.getMessage());
        } finally {
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
                if (bufferReader != null) {
                    bufferReader.close();
                }
                //after parsing all the files, and then close FTP server.
                /*if(ftpClient != null){
	        		ftpClient.closeServer();	
	        	}*/
            } catch (Exception ex) {
                throw new GWFTPAccessException(ex.getMessage());
            }
        }
    }

    /**
     * Get file and folder list
     *
     * @return List
     */
    public List<String> getFolderNameList(String remotePath) {
        List<String> list = new ArrayList<String>();
        try {
            if (!isConnection) {
                connectServer(ip, port, user, pwd);
            }
            if (remotePath.length() != 0) {
                ftpClient.changeDirectory(remotePath);
            }
            ftpClient.setBinaryType();
            InputStream inputStream = ftpClient.list(remotePath);
            BufferedReader bufferReader = null;
            String xmlStr = null;
            if (inputStream != null) {
                bufferReader = new BufferedReader(new InputStreamReader(inputStream));
                while ((xmlStr = bufferReader.readLine()) != null) {
                    xmlStr = xmlStr.substring(xmlStr.length() - 8, xmlStr.length());
                    if (xmlStr.indexOf(UtilConstants.DOT) == -1) {
                        list.add(xmlStr);
                    }
                }
            }
        } catch (Exception e) {
            try {
                if (ftpClient != null) {
                    ftpClient.close();
                }
            } catch (IOException ioe) {
            }
            isConnection = false;
            log.error(e.getMessage(), e);
        }
        return list;
    }

    /**
     * Get file name by folder name.
     *
     * @return List
     */
    public List<String> getFileNameList(String folderName) {
        List<String> list = new ArrayList<String>();
        try {
            if (!isConnection) {
                connectServer(ip, port, user, pwd);
            }
            ftpClient.setBinaryType();
            InputStream inputStream = ftpClient.nameList(folderName);
            BufferedReader bufferReader = null;
            String xmlStr = null;
            if (inputStream != null) {
                bufferReader = new BufferedReader(new InputStreamReader(inputStream));
                while ((xmlStr = bufferReader.readLine()) != null) {
                    list.add(xmlStr);
                }
            }
        } catch (Exception e) {
            try {
                if (ftpClient != null) {
                    ftpClient.close();
                }
            } catch (IOException ioe) {
            }
            isConnection = false;
            log.error(e.getMessage(), e);
        }
        return list;
    }

    /**
     * get file list from EA FTP server
     *
     * @param remotePath
     * @param filename
     * @throws GWFTPAccessException
     */
    public List<String> getFileNameList(String remotePath, String filename) throws GWFTPAccessException {
        InputStream inputStream = null;
        BufferedReader bufferReader = null;
        List<String> fileNameList = new ArrayList<String>();
        String xmlStr = null;
        try {
            if (!isConnection) {
                this.connectServer(ip, port, user, pwd);
            }
            if (remotePath.length() != 0) {
                ftpClient.changeDirectory(remotePath);
            }
            ftpClient.setBinaryType();
            inputStream = ftpClient.getFileStream(filename);
            if (inputStream != null) {
                bufferReader = new BufferedReader(new InputStreamReader(inputStream));
                while ((xmlStr = bufferReader.readLine()) != null) {
                    fileNameList.add(xmlStr.trim());
                }
            }
            return fileNameList;
        } catch (Exception ex) {
            try {
                if (ftpClient != null) {
                    ftpClient.close();
                }
            } catch (IOException ioe) {
            }
            isConnection = false;
            throw new GWFTPAccessException("Failed to download EA gameinfos xml files:" + filename, ex);
        } finally {
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
                if (bufferReader != null) {
                    bufferReader.close();
                }
                //after parsing all the files, and then close FTP server.
	        	/*if(ftpClient != null){
	        		ftpClient.closeServer();	
	        	}*/
            } catch (Exception ex) {
                throw new GWFTPAccessException("Failed to download EA gameinfos xml files:" + filename, ex);
            }
        }
    }

    /**
     * Down load file
     *
     * @param remotePath
     * @param localPath
     * @param filename
     * @throws Exception
     */
    public void downloadFile(String remotePath, String localPath, String filename) throws Exception {
        int c = 0;
        byte[] bytes = new byte[1024];
        try {
            if (connectServer(ip, port, user, pwd)) {
                if (remotePath.length() != 0) {
                    ftpClient.changeDirectory(remotePath);
                }
                ftpClient.setBinaryType();
                InputStream is = ftpClient.getFileStream(filename);
                File file_out = new File(localPath + File.separator + filename);
                FileOutputStream os = new FileOutputStream(file_out);
                while ((c = is.read(bytes)) != -1) {
                    os.write(bytes, 0, c);
                }
                is.close();
                os.close();
                ftpClient.close();
            }
        } catch (Exception ex) {
            try {
                if (ftpClient != null) {
                    ftpClient.close();
                }
            } catch (IOException ioe) {
            }
            isConnection = false;
            throw new Exception("ftp download file error:" + ex.getMessage());
        }
    }

    /**
     * Up load file
     *
     * @param remotePath
     * @param localPath
     * @param filename
     * @throws Exception
     */
    public void uploadFile(String remotePath, String localPath, String filename) throws Exception {
        int c = 0;
        byte[] bytes = new byte[1024];
        try {
            if (connectServer(ip, port, user, pwd)) {
                if (remotePath.length() != 0) {
                    ftpClient.changeDirectory(remotePath);
                }
                ftpClient.setBinaryType();
                OutputStream os = ftpClient.putFileStream(filename);
                File file_in = new File(localPath + File.separator + filename);
                FileInputStream is = new FileInputStream(file_in);
                while ((c = is.read(bytes)) != -1) {
                    os.write(bytes, 0, c);
                }
                is.close();
                os.close();
                ftpClient.close();
            }
        } catch (Exception ex) {
            try {
                if (ftpClient != null) {
                    ftpClient.close();
                }
            } catch (IOException ioe) {
            }
            isConnection = false;
            throw new Exception("ftp upload file error:" + ex.getMessage());
        }
    }

    /**
     * @return the ip
     */
    public String getIp() {
        return ip;
    }

    /**
     * @param ip the ip to set
     */
    public void setIp(String ip) {
        this.ip = ip;
    }

    /**
     * @return the port
     */
    public int getPort() {
        return port;
    }

    /**
     * @param port the port to set
     */
    public void setPort(int port) {
        this.port = port;
    }

    /**
     * @return the user
     */
    public String getUser() {
        return user;
    }

    /**
     * @param user the user to set
     */
    public void setUser(String user) {
        this.user = user;
    }

    /**
     * @return the pwd
     */
    public String getPwd() {
        return pwd;
    }

    /**
     * @param pwd the pwd to set
     */
    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    /**
     * @return the remotePath
     */
    public String getRemotePath() {
        return remotePath;
    }

    /**
     * @param remotePath the remotePath to set
     */
    public void setRemotePath(String remotePath) {
        this.remotePath = remotePath;
    }

    /**
     * @return the localPath
     */
    public String getLocalPath() {
        return localPath;
    }

    /**
     * @param localPath the localPath to set
     */
    public void setLocalPath(String localPath) {
        this.localPath = localPath;
    }

    /**
     * @return the ftpClient
     */
    public FtpClient getFtpClient() {
        return ftpClient;
    }

    /**
     * @param ftpClient the ftpClient to set
     */
    public void setFtpClient(FtpClient ftpClient) {
        this.ftpClient = ftpClient;
    }

}
