package main.java.com.gw.common.framework.util;

import java.io.*;
import java.util.ArrayList;
import java.util.Date;

/**
 * FileName:FileOperate.java Description:
 *
 * @author david.z
 * @version 1.00
 * @see
 * @since 1.00
 *
 * <pre>
 * #############################################################################
 * Date           Modified By          Description
 * #############################################################################
 *
 * may 17, 2011       david              Initial code.
 *
 *        </pre>
 */

@SuppressWarnings("unchecked")
public class FileOperate {
    private String path;
    private FileReader fr;
    private FileWriter fw;
    private BufferedReader br;
    private BufferedWriter bw;
    public static ArrayList list = new ArrayList();

    public void setPath(String f) {
        path = f;
    }

    public String getPath() {
        return path;
    }

    public String read() throws Exception {
        String s = "", ss = "";
        fr = new FileReader(path);
        br = new BufferedReader(fr);
        while ((s = br.readLine()) != null) {
            ss += s;
        }

        this.close();
        return ss;
    }

    public String read(InputStream in) throws Exception {
        String result = "";
        br = new BufferedReader(new InputStreamReader(in));
        String line = br.readLine();
        while (line != null) {
            result += line;
            line = br.readLine();
        }
        return result;
    }

    public String read(InputStream in, String charSet) throws Exception {
        String result = "";
        br = new BufferedReader(new InputStreamReader(in, charSet));
        String line = br.readLine();
        while (line != null) {
            result += line;
            line = br.readLine();
        }
        return result;
    }

    /**
     * @param content
     * @throws Exception
     */
    public void write(String content) throws Exception {
        fw = new FileWriter(path);
        bw = new BufferedWriter(fw);
        bw.write(content);

        bw.close();
    }

    public boolean delete() throws Exception {
        File f = new File(path);

        boolean flag = f.delete();
        System.out.print(flag);
        return flag;
    }

    public void close() {
        try {
            if (fr != null) {
                fr.close();
                fr = null;
            }
            if (br != null) {
                br.close();
                br = null;
            }
            if (fw != null) {
                fw.close();
                fw = null;
            }

            if (bw != null) {
                bw.close();
                bw = null;
            }
        } catch (IOException e) {

            e.printStackTrace();
        }
    }

    public String[] getFileList() {
        File f = new File(path);
        String s[] = f.list();
        for (int i = 0; i < s.length; i++) {
            if (s[i].indexOf(".") != -1)
                s[i] = s[i].substring(0, s[i].indexOf("."));
        }
        return s;
    }

    public String[] getFile() {
        File f = new File(path);
        String s[] = f.list();
        String tmp;

        for (int i = 0; i < s.length - 1; i++) {
            for (int j = i + 1; j < s.length; j++) {
                if (Integer.parseInt(s[i].substring(0, s[i].indexOf('.'))) > Integer.parseInt(s[j].substring(0, s[j].indexOf('.')))) {
                    tmp = s[i];
                    s[i] = s[j];
                    s[j] = tmp;
                }
            }

        }

        return s;
    }

    public void getList() throws Exception {
        String s;
        fr = new FileReader(path + "/list.txt");
        br = new BufferedReader(fr);
        while ((s = br.readLine()) != null) {
            list.add(s);
        }
        close();
    }

    public String getItem(int i) {

        return (String) list.get(i);
    }

    public Date getModifyTime() {
        File f = new File(path);
        Date modifydate = new Date(f.lastModified());
        return modifydate;
    }

}
