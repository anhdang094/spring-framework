/**
 *
 */
package main.java.com.gw.common.framework.util;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.datacenter.accounttransfer.entity.AccountTransferEntity;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import main.java.com.gw.datacenter.order.entity.SportsbookBetRecord;
import main.java.com.gw.datacenter.order.entity.SportsbookHorseBet;
import org.apache.commons.lang3.StringUtils;

import javax.json.JsonArray;
import javax.json.JsonNumber;
import javax.json.JsonObject;
import javax.json.JsonValue;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Call remote interface with URL and HttpURLConnection.
 *
 * @author alex.l
 */
@Slf4j
public class GetJsonByUrlUtil {
    private final static String TRANS_TYPE_BETDETAILS = "BetDetails";
    private final static String TRANS_TYPE_BETHORSEDETAILS = "BetHorseDetails";
    private final static String TRANS_TYPE_BETLIVECASINODETAILS = "BetLiveCasinoDetails";
    private final static String TRANS_TYPE_BETNUMBERDETAILS = "BetNumberDetails";
    private final static String TRANS_TYPE_BETVIRTUALSPORTDETAILS = "BetVirtualSportDetails";

    /**
     * Return string by calling remote interface.
     *
     * @param baseUrl
     * @param parameterMap
     * @param encoding
     * @return string
     * @throws GWCallRemoteApiException
     */
    public static String getXmlStream(String baseUrl, Map<String, Object> parameterMap, String encoding) throws GWCallRemoteApiException {
        // define log
        StringBuffer stringBuffer = new StringBuffer();
        HttpURLConnection conn = null;
        BufferedReader bufferReader = null;
        InputStream inutStream = null;
        String wholeRrl = null;
        String xmlStr = null;
        try {
            wholeRrl = UrlGeneratorUtil.generateUrl(parameterMap, baseUrl, encoding);
            if (wholeRrl != null) {
                URL url = new URL(wholeRrl);
                conn = (HttpURLConnection) url.openConnection();
                conn.setDoOutput(false);
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(30000);
                conn.connect();
                inutStream = conn.getInputStream();
                bufferReader = new BufferedReader(new InputStreamReader(inutStream));
                while ((xmlStr = bufferReader.readLine()) != null) {
                    stringBuffer.append(xmlStr);
                }
            }
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            log.error("Call remote interface failure with URL:" + wholeRrl);
            throw new GWCallRemoteApiException("Failed to call remote interface!" + ex.getMessage(), ex);
        } finally {
            if (bufferReader != null) {
                try {
                    bufferReader.close();
                } catch (Exception e) {
                    log.error("Close buffer stream failure!", e);
                }
            }
            if (inutStream != null) {
                try {
                    inutStream.close();
                } catch (Exception e) {
                    log.error("Close inputstream failure!", e);
                }
            }
            if (conn != null) {
                conn.disconnect();
            }
        }
        log.info("Call remote interface successfully by URL:" + wholeRrl);
        return stringBuffer.toString();
    }

    public static boolean isNotNull(JsonValue value) {
        boolean isNotNull = true;
        if (value != null) {
            if (value.toString().equals("null")) {
                isNotNull = false;
            }
        } else {
            isNotNull = false;
        }
        return isNotNull;
    }

    public static List<SportsbookBetRecord> getSportsbookBetVirtualSportDetails(JsonArray betDetailsJsonArray) {
        List<SportsbookBetRecord> sportsbookBetRecords = new ArrayList<SportsbookBetRecord>();
        int jsonArraySize = betDetailsJsonArray.size();
        for (int i = 0; i < jsonArraySize; i++) {
            JsonObject betDetailJson = betDetailsJsonArray.getJsonObject(i);
            SportsbookBetRecord betRecord = new SportsbookBetRecord();
            betRecord.setTransactionType(TRANS_TYPE_BETVIRTUALSPORTDETAILS);
            betRecord.setTransactionId(String.valueOf(betDetailJson.getJsonNumber("trans_id")));
            betRecord.setLoginname(betDetailJson.getString("vendor_member_id"));
            betRecord.setOperatorId((isNotNull(betDetailJson.get("operator_id")) ? betDetailJson.getString("operator_id") : null));
            betRecord.setLeagueId(String.valueOf((isNotNull(betDetailJson.get("league_id")) ? betDetailJson.getJsonNumber("league_id") : null)));
            betRecord.setMatchId(String.valueOf((isNotNull(betDetailJson.get("match_id")) ? betDetailJson.getJsonNumber("match_id") : null)));
            betRecord.setHomeId(String.valueOf((isNotNull(betDetailJson.get("home_id")) ? betDetailJson.getJsonNumber("home_id") : null)));
            betRecord.setAwayId(String.valueOf((isNotNull(betDetailJson.get("away_id")) ? betDetailJson.getJsonNumber("away_id") : null)));
            betRecord.setSportsType(String.valueOf((isNotNull(betDetailJson.get("sport_type")) ? betDetailJson.getJsonNumber("sport_type") : null)));
            betRecord.setBetType(String.valueOf((isNotNull(betDetailJson.get("bet_type")) ? betDetailJson.getJsonNumber("bet_type") : null)));
            betRecord.setOdds(new BigDecimal((isNotNull(betDetailJson.get("odds")) ? betDetailJson.getJsonNumber("odds").doubleValue() : null)));
            betRecord.setStake(new BigDecimal((isNotNull(betDetailJson.get("stake")) ? betDetailJson.getJsonNumber("stake").doubleValue() : null)));
            betRecord.setTransactionDate((isNotNull(betDetailJson.get("transaction_time")) ? betDetailJson.getString("transaction_time").replace("T",
                    " ") : null));
            betRecord.setTicketStatus((isNotNull(betDetailJson.get("ticket_status")) ? betDetailJson.getString("ticket_status") : null));
            betRecord.setWinLostAmount(new BigDecimal((isNotNull(betDetailJson.get("winlost_amount")) ? betDetailJson.getJsonNumber("winlost_amount")
                    .doubleValue() : null)));
            betRecord.setAfterAmount(new BigDecimal((isNotNull(betDetailJson.get("after_amount")) ? betDetailJson.getJsonNumber("after_amount")
                    .doubleValue() : null)));
            betRecord
                    .setCurrency(getCurrency((isNotNull(betDetailJson.get("currency")) ? betDetailJson.getJsonNumber("currency").intValue() : null)));
            betRecord.setWinLostDate((isNotNull(betDetailJson.get("winlost_datetime")) ? betDetailJson.getString("winlost_datetime")
                    .replace("T", " ") : null));
            betRecord.setOddsType(String.valueOf((isNotNull(betDetailJson.get("odds_type")) ? betDetailJson.getJsonNumber("odds_type") : null)));
            betRecord.setBetTeam((isNotNull(betDetailJson.get("bet_team")) ? betDetailJson.getString("bet_team") : null));
            betRecord.setHomeHandicap(String.valueOf((isNotNull(betDetailJson.get("home_hdp")) ? betDetailJson.getJsonNumber("home_hdp") : null)));
            betRecord.setAwayHandicap(String.valueOf((isNotNull(betDetailJson.get("away_hdp")) ? betDetailJson.getJsonNumber("away_hdp") : null)));
            betRecord.setHandicap(String.valueOf((isNotNull(betDetailJson.get("hdp")) ? betDetailJson.getJsonNumber("hdp") : null)));
            betRecord.setBetFrom((isNotNull(betDetailJson.get("betfrom")) ? betDetailJson.getString("betfrom") : null));
            betRecord.setCustomerInfo1((isNotNull(betDetailJson.get("customInfo1")) ? betDetailJson.getString("customInfo1") : null));
            betRecord.setCustomerInfo2((isNotNull(betDetailJson.get("customInfo2")) ? betDetailJson.getString("customInfo2") : null));
            betRecord.setCustomerInfo3((isNotNull(betDetailJson.get("customInfo3")) ? betDetailJson.getString("customInfo3") : null));
            betRecord.setCustomerInfo4((isNotNull(betDetailJson.get("customInfo4")) ? betDetailJson.getString("customInfo4") : null));
            betRecord.setCustomerInfo5((isNotNull(betDetailJson.get("customInfo5")) ? betDetailJson.getString("customInfo5") : null));
            betRecord.setBaStatus((isNotNull(betDetailJson.get("ba_status")) ? betDetailJson.getString("ba_status") : null));
            betRecord
                    .setVersionKey(String.valueOf((isNotNull(betDetailJson.get("version_key")) ? betDetailJson.getJsonNumber("version_key") : null)));
            sportsbookBetRecords.add(betRecord);
        }

        return sportsbookBetRecords;
    }

    public static List<SportsbookBetRecord> getSportsbookBetNumberDetails(JsonArray betDetailsJsonArray) {
        List<SportsbookBetRecord> sportsbookBetRecords = new ArrayList<SportsbookBetRecord>();
        int jsonArraySize = betDetailsJsonArray.size();
        for (int i = 0; i < jsonArraySize; i++) {
            JsonObject betDetailJson = betDetailsJsonArray.getJsonObject(i);
            SportsbookBetRecord betRecord = new SportsbookBetRecord();
            betRecord.setTransactionType(TRANS_TYPE_BETNUMBERDETAILS);
            betRecord.setTransactionId(String.valueOf(betDetailJson.getJsonNumber("trans_id")));
            betRecord.setLoginname(betDetailJson.getString("vendor_member_id"));
            betRecord.setOperatorId((isNotNull(betDetailJson.get("operator_id")) ? betDetailJson.getString("operator_id") : null));
            betRecord.setMatchId(String.valueOf((isNotNull(betDetailJson.get("match_id")) ? betDetailJson.getJsonNumber("match_id") : null)));
            betRecord.setTransactionDate((isNotNull(betDetailJson.get("transaction_time")) ? betDetailJson.getString("transaction_time").replace("T",
                    " ") : null));
            betRecord.setOdds(new BigDecimal((isNotNull(betDetailJson.get("odds")) ? betDetailJson.getJsonNumber("odds").doubleValue() : null)));
            betRecord.setStake(new BigDecimal((isNotNull(betDetailJson.get("stake")) ? betDetailJson.getJsonNumber("stake").doubleValue() : null)));
            betRecord.setTicketStatus((isNotNull(betDetailJson.get("ticket_status")) ? betDetailJson.getString("ticket_status") : null));
            betRecord.setBetFrom((isNotNull(betDetailJson.get("betfrom")) ? betDetailJson.getString("betfrom") : null));
            betRecord.setIsLive((isNotNull(betDetailJson.get("islive")) ? betDetailJson.getString("islive") : null));
            betRecord
                    .setLastBallNo(String.valueOf((isNotNull(betDetailJson.get("last_ball_no")) ? betDetailJson.getJsonNumber("last_ball_no") : null)));
            betRecord.setBetTeam((isNotNull(betDetailJson.get("bet_team")) ? betDetailJson.getString("bet_team") : null));
            betRecord.setWinLostDate((isNotNull(betDetailJson.get("winlost_datetime")) ? betDetailJson.getString("winlost_datetime")
                    .replace("T", " ") : null));
            betRecord.setSportsType(String.valueOf((isNotNull(betDetailJson.get("sport_type")) ? betDetailJson.getJsonNumber("sport_type") : null)));
            betRecord.setBetType(String.valueOf((isNotNull(betDetailJson.get("bet_type")) ? betDetailJson.getJsonNumber("bet_type") : null)));
            betRecord
                    .setCurrency(getCurrency((isNotNull(betDetailJson.get("currency")) ? betDetailJson.getJsonNumber("currency").intValue() : null)));
            betRecord.setOddsType(String.valueOf((isNotNull(betDetailJson.get("odds_type")) ? betDetailJson.getJsonNumber("odds_type") : null)));
            betRecord.setWinLostAmount(new BigDecimal((isNotNull(betDetailJson.get("winlost_amount")) ? betDetailJson.getJsonNumber("winlost_amount")
                    .doubleValue() : null)));
            betRecord.setAfterAmount(new BigDecimal((isNotNull(betDetailJson.get("after_amount")) ? betDetailJson.getJsonNumber("after_amount")
                    .doubleValue() : null)));
            betRecord.setCustomerInfo1((isNotNull(betDetailJson.get("customInfo1")) ? betDetailJson.getString("customInfo1") : null));
            betRecord.setCustomerInfo2((isNotNull(betDetailJson.get("customInfo2")) ? betDetailJson.getString("customInfo2") : null));
            betRecord.setCustomerInfo3((isNotNull(betDetailJson.get("customInfo3")) ? betDetailJson.getString("customInfo3") : null));
            betRecord.setCustomerInfo4((isNotNull(betDetailJson.get("customInfo4")) ? betDetailJson.getString("customInfo4") : null));
            betRecord.setCustomerInfo5((isNotNull(betDetailJson.get("customInfo5")) ? betDetailJson.getString("customInfo5") : null));
            betRecord.setBaStatus((isNotNull(betDetailJson.get("ba_status")) ? betDetailJson.getString("ba_status") : null));
            betRecord
                    .setVersionKey(String.valueOf((isNotNull(betDetailJson.get("version_key")) ? betDetailJson.getJsonNumber("version_key") : null)));
            sportsbookBetRecords.add(betRecord);
        }
        return sportsbookBetRecords;
    }

    public static List<SportsbookBetRecord> getSportsbookBetLiveCasinoDetails(JsonArray betDetailsJsonArray) {
        List<SportsbookBetRecord> sportsbookBetRecords = new ArrayList<SportsbookBetRecord>();
        int jsonArraySize = betDetailsJsonArray.size();
        for (int i = 0; i < jsonArraySize; i++) {
            JsonObject betDetailJson = betDetailsJsonArray.getJsonObject(i);
            SportsbookBetRecord betRecord = new SportsbookBetRecord();
            betRecord.setTransactionType(TRANS_TYPE_BETLIVECASINODETAILS);
            betRecord.setTransactionId(String.valueOf(betDetailJson.getJsonNumber("trans_id")));
            betRecord.setLoginname(betDetailJson.getString("vendor_member_id"));
            betRecord.setOperatorId((isNotNull(betDetailJson.get("operator_id")) ? betDetailJson.getString("operator_id") : null));
            betRecord.setMatchId(String.valueOf((isNotNull(betDetailJson.get("match_id")) ? betDetailJson.getJsonNumber("match_id") : null)));
            betRecord.setSportsType(String.valueOf((isNotNull(betDetailJson.get("sport_type")) ? betDetailJson.getJsonNumber("sport_type") : null)));
            betRecord.setTableNo(String.valueOf((isNotNull(betDetailJson.get("table_no")) ? betDetailJson.getJsonNumber("table_no") : null)));
            betRecord.setHandNo(String.valueOf((isNotNull(betDetailJson.get("hand_no")) ? betDetailJson.getJsonNumber("hand_no") : null)));
            betRecord.setShoeNo(String.valueOf((isNotNull(betDetailJson.get("shoe_no")) ? betDetailJson.getJsonNumber("shoe_no") : null)));
            betRecord.setBetType(String.valueOf((isNotNull(betDetailJson.get("bet_type")) ? betDetailJson.getJsonNumber("bet_type") : null)));
            betRecord.setOdds(new BigDecimal((isNotNull(betDetailJson.get("odds")) ? betDetailJson.getJsonNumber("odds").doubleValue() : null)));
            betRecord.setStake(new BigDecimal((isNotNull(betDetailJson.get("stake")) ? betDetailJson.getJsonNumber("stake").doubleValue() : null)));
            betRecord.setTransactionDate((isNotNull(betDetailJson.get("transaction_time")) ? betDetailJson.getString("transaction_time").replace("T",
                    " ") : null));
            betRecord.setTicketStatus((isNotNull(betDetailJson.get("ticket_status")) ? betDetailJson.getString("ticket_status") : null));
            betRecord.setWinLostAmount(new BigDecimal((isNotNull(betDetailJson.get("winlost_amount")) ? betDetailJson.getJsonNumber("winlost_amount")
                    .doubleValue() : null)));
            betRecord.setAfterAmount(new BigDecimal((isNotNull(betDetailJson.get("after_amount")) ? betDetailJson.getJsonNumber("after_amount")
                    .doubleValue() : null)));
            betRecord
                    .setCurrency(getCurrency((isNotNull(betDetailJson.get("currency")) ? betDetailJson.getJsonNumber("currency").intValue() : null)));
            betRecord.setWinLostDate((isNotNull(betDetailJson.get("winlost_datetime")) ? betDetailJson.getString("winlost_datetime")
                    .replace("T", " ") : null));
            betRecord.setOddsType(String.valueOf((isNotNull(betDetailJson.get("odds_type")) ? betDetailJson.getJsonNumber("odds_type") : null)));
            betRecord.setBetTeam((isNotNull(betDetailJson.get("bet_team")) ? betDetailJson.getString("bet_team") : null));
            betRecord.setCustomerInfo1((isNotNull(betDetailJson.get("customInfo1")) ? betDetailJson.getString("customInfo1") : null));
            betRecord.setCustomerInfo2((isNotNull(betDetailJson.get("customInfo2")) ? betDetailJson.getString("customInfo2") : null));
            betRecord.setCustomerInfo3((isNotNull(betDetailJson.get("customInfo3")) ? betDetailJson.getString("customInfo3") : null));
            betRecord.setCustomerInfo4((isNotNull(betDetailJson.get("customInfo4")) ? betDetailJson.getString("customInfo4") : null));
            betRecord.setCustomerInfo5((isNotNull(betDetailJson.get("customInfo5")) ? betDetailJson.getString("customInfo5") : null));
            betRecord.setBaStatus((isNotNull(betDetailJson.get("ba_status")) ? betDetailJson.getString("ba_status") : null));
            betRecord
                    .setVersionKey(String.valueOf((isNotNull(betDetailJson.get("version_key")) ? betDetailJson.getJsonNumber("version_key") : null)));
            sportsbookBetRecords.add(betRecord);
        }

        return sportsbookBetRecords;
    }

    public static List<SportsbookBetRecord> getSportsbookBetHorseDetails(JsonArray betDetailsJsonArray) {
        List<SportsbookBetRecord> sportsbookBetRecords = new ArrayList<SportsbookBetRecord>();
        List<SportsbookHorseBet> sportsbookBetHorseRecords = new ArrayList<SportsbookHorseBet>();
        int jsonArraySize = betDetailsJsonArray.size();
        for (int i = 0; i < jsonArraySize; i++) {
            JsonObject betDetailJson = betDetailsJsonArray.getJsonObject(i);
            SportsbookBetRecord betRecord = new SportsbookBetRecord();
            betRecord.setTransactionType(TRANS_TYPE_BETHORSEDETAILS);
            betRecord.setTransactionId(String.valueOf(betDetailJson.getJsonNumber("trans_id")));
            betRecord.setLoginname(betDetailJson.getString("vendor_member_id"));
            betRecord.setOperatorId((isNotNull(betDetailJson.get("operator_id")) ? betDetailJson.getString("operator_id") : null));
            betRecord.setLeagueId(String.valueOf((isNotNull(betDetailJson.get("league_id")) ? betDetailJson.getJsonNumber("league_id") : null)));
            betRecord.setProgramId(isNotNull(betDetailJson.get("program_id")) ? betDetailJson.getString("program_id") : null);
            betRecord.setMatchDate((isNotNull(betDetailJson.get("match_datetime")) ? betDetailJson.getString("match_datetime").replace("T", " ")
                    : null));
            betRecord.setSportsType(String.valueOf((isNotNull(betDetailJson.get("sport_type")) ? betDetailJson.getJsonNumber("sport_type") : null)));
            betRecord.setBetType(String.valueOf((isNotNull(betDetailJson.get("bet_type")) ? betDetailJson.getJsonNumber("bet_type") : null)));
            betRecord.setOdds(new BigDecimal((isNotNull(betDetailJson.get("odds")) ? betDetailJson.getJsonNumber("odds").doubleValue() : null)));
            betRecord.setStake(new BigDecimal((isNotNull(betDetailJson.get("stake")) ? betDetailJson.getJsonNumber("stake").doubleValue() : null)));
            betRecord.setTransactionDate((isNotNull(betDetailJson.get("transaction_time")) ? betDetailJson.getString("transaction_time").replace("T",
                    " ") : null));
            betRecord.setTicketStatus((isNotNull(betDetailJson.get("ticket_status")) ? betDetailJson.getString("ticket_status") : null));
            betRecord.setWinLostAmount(new BigDecimal((isNotNull(betDetailJson.get("winlost_amount")) ? betDetailJson.getJsonNumber("winlost_amount")
                    .doubleValue() : null)));
            betRecord.setAfterAmount(new BigDecimal((isNotNull(betDetailJson.get("after_amount")) ? betDetailJson.getJsonNumber("after_amount")
                    .doubleValue() : null)));
            betRecord
                    .setCurrency(getCurrency((isNotNull(betDetailJson.get("currency")) ? betDetailJson.getJsonNumber("currency").intValue() : null)));
            betRecord.setWinLostDate((isNotNull(betDetailJson.get("winlost_datetime")) ? betDetailJson.getString("winlost_datetime")
                    .replace("T", " ") : null));
            betRecord.setRaceNumber((isNotNull(betDetailJson.get("racenumber")) ? betDetailJson.getString("racenumber") : null));
            betRecord.setRaceLane((isNotNull(betDetailJson.get("racelane")) ? betDetailJson.getString("racelane") : null));
            betRecord.setBetTeam((isNotNull(betDetailJson.get("bet_team")) ? betDetailJson.getString("bet_team") : null));
            betRecord.setBetFrom((isNotNull(betDetailJson.get("betfrom")) ? betDetailJson.getString("betfrom") : null));
            betRecord.setComm(String.valueOf((isNotNull(betDetailJson.get("comm")) ? betDetailJson.getJsonNumber("comm") : null)));
            betRecord.setCustomerInfo1((isNotNull(betDetailJson.get("customInfo1")) ? betDetailJson.getString("customInfo1") : null));
            betRecord.setCustomerInfo2((isNotNull(betDetailJson.get("customInfo2")) ? betDetailJson.getString("customInfo2") : null));
            betRecord.setCustomerInfo3((isNotNull(betDetailJson.get("customInfo3")) ? betDetailJson.getString("customInfo3") : null));
            betRecord.setCustomerInfo4((isNotNull(betDetailJson.get("customInfo4")) ? betDetailJson.getString("customInfo4") : null));
            betRecord.setCustomerInfo5((isNotNull(betDetailJson.get("customInfo5")) ? betDetailJson.getString("customInfo5") : null));
            betRecord.setBaStatus((isNotNull(betDetailJson.get("ba_status")) ? betDetailJson.getString("ba_status") : null));
            betRecord
                    .setVersionKey(String.valueOf((isNotNull(betDetailJson.get("version_key")) ? betDetailJson.getJsonNumber("version_key") : null)));
            sportsbookBetRecords.add(betRecord);
            if (isNotNull(betDetailJson.get("WinPlaceData"))) {
                JsonArray horseBetJsonArray = betDetailJson.getJsonArray("WinPlaceData");
                int jsonArrayHorseSize = horseBetJsonArray.size();
                for (int j = 0; j < jsonArrayHorseSize; j++) {
                    JsonObject horseBetJson = horseBetJsonArray.getJsonObject(j);
                    SportsbookHorseBet horseBet = new SportsbookHorseBet();
                    horseBet.setTransactionType(betRecord.getTransactionId());
                    horseBet.setOdds(new BigDecimal((isNotNull(horseBetJson.get("odds")) ? horseBetJson.getJsonNumber("odds").doubleValue() : null)));
                    horseBet.setBetType(String.valueOf((isNotNull(horseBetJson.get("bet_type")) ? horseBetJson.getJsonNumber("bet_type") : null)));
                    horseBet.setBetTeam((isNotNull(horseBetJson.get("bet_team")) ? horseBetJson.getString("bet_team") : null));
                    horseBet.setStake(new BigDecimal(
                            (isNotNull(horseBetJson.get("stake")) ? horseBetJson.getJsonNumber("stake").doubleValue() : null)));
                    sportsbookBetHorseRecords.add(horseBet);
                }
            }
        }
        // insertSportsbookHorseBetRecords(sportsbookBetHorseRecords);
        return sportsbookBetRecords;
    }


    public static List<SportsbookBetRecord> getSportsbookBet4GBRecord(com.google.gson.JsonArray betDetailsJsonArray) {
        /*List<SportsbookBet4GBRecord> sportsbookBet4GBRecord = new ArrayList<SportsbookBet4GBRecord>();*/
        List<SportsbookBetRecord> sportsbookBetRecords = new ArrayList<SportsbookBetRecord>();
        int jsonArraySize = betDetailsJsonArray.size();
        for (int i = 0; i < jsonArraySize; i++) {
            SportsbookBetRecord betRecord = new SportsbookBetRecord();
            com.google.gson.JsonObject betDetailJson = betDetailsJsonArray.get(i).getAsJsonObject();
            betRecord.setTransactionId(betDetailJson.get("BetID").getAsString());
            betRecord.setLoginname(betDetailJson.get("MemberID").getAsString());
            betRecord.setSportsType("Combo");
            betRecord.setCurrency(betDetailJson.get("CurCode").getAsString());
            betRecord.setBetType(betDetailJson.get("BetType").getAsString());
            betRecord.setTransactionDate(betDetailJson.get("BetDT").getAsString()==null?null:betDetailJson.get("BetDT").getAsString().replace("T"," "));
            betRecord.setWinLostDate((isNotNull((JsonValue) betDetailJson.get("SettleDT"))) ? betDetailJson.get("SettleDT").getAsString(): null);
            betRecord.setMatchId(betDetailJson.get("TPCode").getAsString());
            betRecord.setProductId(betDetailJson.get("TPCode").getAsString());
            betRecord.setStake(betDetailJson.get("RealBetAmt").getAsBigDecimal().divide(new BigDecimal("100")));
            betRecord.setVersionKey(betDetailJson.get("BetID").getAsString());
            betRecord.setOdds(betDetailJson.get("RealBetRate").getAsBigDecimal().divide(new BigDecimal("100")));
            betRecord.setWinLostAmount(null);
            betRecord.setOddsType("2");
            betRecord.setBetFrom(null);
            betRecord.setTicketStatus("lose");
            betRecord.setAfterAmount(BigDecimal.valueOf(Long.parseLong("0")));


            sportsbookBetRecords.add(betRecord);


            /*JSONObject betDetailJson = betDetailsJsonArray.getJSONObject(i);
            betRecord.setSettleId(betDetailJson.getString("SettleID"));
            betRecord.setBetId(betDetailJson.getString("BetID"));
            betRecord.setBetGrpNo(betDetailJson.getString("BetGrpNO"));
            betRecord.setTpCode(betDetailJson.getString("TPCode"));
            betRecord.setGbsn(betDetailJson.getString("GBSN"));
            betRecord.setMemberId(betDetailJson.getString("MemberID"));
            betRecord.setCurCode(betDetailJson.getString("CurCode"));
            betRecord.setBetDt(betDetailJson.getString("BetDT"));
            betRecord.setBetType(betDetailJson.getString("BetType"));
            betRecord.setBetTypeParam1(betDetailJson.getString("BetTypeParam1"));
            betRecord.setBetTypeParam2(betDetailJson.getString("BetTypeParam2"));
            betRecord.setWinType(betDetailJson.getString("Wintype"));
            betRecord.setHxmGuid(betDetailJson.getString("HxMGUID"));
            betRecord.setInitBetAmt(betDetailJson.getLongValue("InitBetAmt"));
            betRecord.setRealBetAmt(betDetailJson.getLongValue("RealBetAmt"));
            betRecord.setHoldingAmt(betDetailJson.getLongValue("HoldingAmt"));
            betRecord.setInitBetRate(betDetailJson.getLongValue("InitBetRate"));
            betRecord.setRealBetRate(betDetailJson.getLongValue("RealBetRate"));
            betRecord.setPreWinAmt(betDetailJson.getLongValue("PreWinAmt"));
            betRecord.setBetResult(betDetailJson.getString("BetResult"));
            betRecord.setWlAmt(betDetailJson.getLongValue("WLAmt"));
            betRecord.setRefundAmt(betDetailJson.getLongValue("RefundAmt"));
            betRecord.setTicketBetAmt(betDetailJson.getLongValue("TicketBetAmt"));
            betRecord.setTicketResult(betDetailJson.getString("TicketResult"));
            betRecord.setTicketwlAmt(betDetailJson.getLongValue("TicketWLAmt"));
            betRecord.setSettleDt(betDetailJson.getString("SettleDT"));

            sportsbookBet4GBRecord.add(betRecord);*/
        }
        return sportsbookBetRecords;
    }


    public static List<SportsbookBetRecord> getSportsbookBetRecord(JsonArray betDetailsJsonArray) {
        List<SportsbookBetRecord> sportsbookBetRecords = new ArrayList<SportsbookBetRecord>();
        int jsonArraySize = betDetailsJsonArray.size();
        for (int i = 0; i < jsonArraySize; i++) {
            JsonObject betDetailJson = betDetailsJsonArray.getJsonObject(i);
            SportsbookBetRecord betRecord = new SportsbookBetRecord();
            betRecord.setTransactionType(TRANS_TYPE_BETDETAILS);
            betRecord.setTransactionId(String.valueOf(betDetailJson.getJsonNumber("trans_id")));
            betRecord.setLoginname(betDetailJson.getString("vendor_member_id"));
            betRecord.setOperatorId((isNotNull(betDetailJson.get("operator_id")) ? betDetailJson.getString("operator_id") : null));
            betRecord.setLeagueId(String.valueOf((isNotNull(betDetailJson.get("league_id")) ? betDetailJson.getJsonNumber("league_id") : null)));
            betRecord.setMatchId(String.valueOf((isNotNull(betDetailJson.get("match_id")) ? betDetailJson.getJsonNumber("match_id") : null)));
            betRecord.setHomeId(String.valueOf((isNotNull(betDetailJson.get("home_id")) ? betDetailJson.getJsonNumber("home_id") : null)));
            betRecord.setAwayId(String.valueOf((isNotNull(betDetailJson.get("away_id")) ? betDetailJson.getJsonNumber("away_id") : null)));
            betRecord.setMatchDate((isNotNull(betDetailJson.get("match_datetime")) ? betDetailJson.getString("match_datetime").replace("T", " ") : null));
            betRecord.setSportsType(String.valueOf((isNotNull(betDetailJson.get("sport_type")) ? betDetailJson.getJsonNumber("sport_type") : null)));
            betRecord.setBetType(String.valueOf((isNotNull(betDetailJson.get("bet_type")) ? betDetailJson.getJsonNumber("bet_type") : null)));
            betRecord.setParlayRefNo(String.valueOf((isNotNull(betDetailJson.get("parlay_ref_no")) ? betDetailJson.getJsonNumber("parlay_ref_no") : null)));
            betRecord.setOdds(new BigDecimal((isNotNull(betDetailJson.get("odds")) ? betDetailJson.getJsonNumber("odds").doubleValue() : null)));
            betRecord.setStake(new BigDecimal((isNotNull(betDetailJson.get("stake")) ? betDetailJson.getJsonNumber("stake").doubleValue() : null)));
            betRecord.setTransactionDate((isNotNull(betDetailJson.get("transaction_time")) ? betDetailJson.getString("transaction_time").replace("T", " ") : null));
            betRecord.setTicketStatus((isNotNull(betDetailJson.get("ticket_status")) ? betDetailJson.getString("ticket_status") : null));
            betRecord.setWinLostAmount(new BigDecimal((isNotNull(betDetailJson.get("winlost_amount")) ? betDetailJson.getJsonNumber("winlost_amount").doubleValue() : null)));
            betRecord.setAfterAmount(isNotNull(betDetailJson.get("after_amount"))?new BigDecimal(betDetailJson.getJsonNumber("after_amount").doubleValue()):null);
            betRecord.setCurrency(getCurrency((isNotNull(betDetailJson.get("currency")) ? betDetailJson.getJsonNumber("currency").intValue() : null)));
            betRecord.setWinLostDate((isNotNull(betDetailJson.get("settlement_time")) ? betDetailJson.getString("settlement_time").replace("T", " ") : null));
            betRecord.setOddsType(String.valueOf((isNotNull(betDetailJson.get("odds_type")) ? betDetailJson.getJsonNumber("odds_type") : null)));
            betRecord.setBetTeam((isNotNull(betDetailJson.get("bet_team")) ? betDetailJson.getString("bet_team") : null));
            betRecord.setHomeHandicap(String.valueOf((isNotNull(betDetailJson.get("home_hdp")) ? betDetailJson.getJsonNumber("home_hdp") : null)));
            betRecord.setAwayHandicap(String.valueOf((isNotNull(betDetailJson.get("away_hdp")) ? betDetailJson.getJsonNumber("away_hdp") : null)));
            betRecord.setHandicap(String.valueOf((isNotNull(betDetailJson.get("hdp")) ? betDetailJson.getJsonNumber("hdp") : null)));
            betRecord.setBetFrom((isNotNull(betDetailJson.get("betfrom")) ? betDetailJson.getString("betfrom") : null));
            betRecord.setIsLive((isNotNull(betDetailJson.get("islive")) ? betDetailJson.getString("islive") : null));
            betRecord.setHomeScore(String.valueOf((isNotNull(betDetailJson.get("home_score")) ? betDetailJson.getJsonNumber("home_score") : null)));
            betRecord.setAwayScore(String.valueOf((isNotNull(betDetailJson.get("away_score")) ? betDetailJson.getJsonNumber("away_score") : null)));
            betRecord.setCustomerInfo1((isNotNull(betDetailJson.get("customInfo1")) ? betDetailJson.getString("customInfo1") : null));
            betRecord.setCustomerInfo2((isNotNull(betDetailJson.get("customInfo2")) ? betDetailJson.getString("customInfo2") : null));
            betRecord.setCustomerInfo3((isNotNull(betDetailJson.get("customInfo3")) ? betDetailJson.getString("customInfo3") : null));
            betRecord.setCustomerInfo4((isNotNull(betDetailJson.get("customInfo4")) ? betDetailJson.getString("customInfo4") : null));
            betRecord.setCustomerInfo5((isNotNull(betDetailJson.get("customInfo5")) ? betDetailJson.getString("customInfo5") : null));
            betRecord.setParlayType((isNotNull(betDetailJson.get("parlay_type")) ? betDetailJson.getString("parlay_type") : null));

            betRecord.setBaStatus((isNotNull(betDetailJson.get("ba_status")) ? betDetailJson.getString("ba_status") : null));
            betRecord.setVersionKey(String.valueOf((isNotNull(betDetailJson.get("version_key")) ? betDetailJson.getJsonNumber("version_key") : null)));
            betRecord.setProgramId("");
            betRecord.setRaceNumber("");
            betRecord.setRaceLane("");
            betRecord.setTableNo("");
            betRecord.setHandNo("");
            betRecord.setShoeNo("");
            betRecord.setComm("");
            betRecord.setLastBallNo("");

            if (betRecord.getOdds() == null || StringUtils.isBlank(betRecord.getOddsType())) {
                log.info("billno:[" + betRecord.getTransactionId() + "], odds is null[" + (betRecord.getOdds() == null) + "], oddstype is null[" + StringUtils.isBlank(betRecord.getOddsType()) + "]");
            }

            if (isNotNull(betDetailJson.get("ParlayData"))) {
                JsonArray parlayRecordJsonArray = betDetailJson.getJsonArray("ParlayData");
                int jsonArrayParlaySize = parlayRecordJsonArray.size();
                if (jsonArrayParlaySize > 0) {
                    if (StringUtils.equals(betRecord.getBetType(), "29")) {
                        // 当为混合玩法时，默认盘口类型为MP  同时设置最低赔率,因为计算洗码投注额的时候要用
                        betRecord.setOddsType("MP");
                        for (int j = 0; j < parlayRecordJsonArray.size(); j++) {
                            JsonObject d = parlayRecordJsonArray.getJsonObject(j);
                            BigDecimal odds = betRecord.getOdds();
                            JsonNumber o = isNotNull(d.get("odds")) ? d.getJsonNumber("odds") : null;
                            if (o == null) {
                                continue;
                            }
                            BigDecimal newOdds = new BigDecimal(o.doubleValue());
                            if (odds == null || (new BigDecimal("0").compareTo(odds) == 0 && "System Parlay".equals(betRecord.getParlayType()))) { //MixParlay赔率为null 或者 System parlay的赔率为0
                                betRecord.setOdds(newOdds.setScale(2, RoundingMode.HALF_UP));
                            } else if (newOdds.compareTo(odds) < 0) {
                                betRecord.setOdds(newOdds.setScale(2, RoundingMode.HALF_UP));
                            }
                        }
                    } else {
                        JsonObject parlayJson = parlayRecordJsonArray.getJsonObject(0);
                        betRecord.setSportsType(String.valueOf((isNotNull(parlayJson.get("sport_type")) ? parlayJson.getJsonNumber("sport_type") : null)));
                    }
                }
            }

            sportsbookBetRecords.add(betRecord);
        }
        // insertSportsbookParleyRecords(sportsbookParlayRecords);
        return sportsbookBetRecords;
    }

    // private void insertSportsbookbetRecords(List<SportsbookBetRecord> sportsbookBetRecords){
    // for (SportsbookBetRecord bet : sportsbookBetRecords) {
    // Object[] params = new Object[46];
    // params[0] = bet.getTransactionType();
    // params[1] = bet.getTransactionId();
    // params[2] = bet.getLoginname();
    // params[3] = bet.getOperatorId();
    // params[4] = bet.getLeagueId();
    // params[5] = bet.getMatchId();
    // params[6] = bet.getHomeId();
    // params[7] = bet.getAwayId();
    // params[8] = bet.getMatchDate();
    // params[9] = bet.getSportsType();
    // params[10] = bet.getBetType();
    // params[11] = bet.getParlayRefNo();
    // params[12] = bet.getOdds();
    // params[13] = bet.getStake();
    // params[14] = bet.getTransactionDate();
    // params[15] = bet.getTicketStatus();
    // params[16] = bet.getWinLostAmount();
    // params[17] = bet.getAfterAmount();
    // params[18] = bet.getCurrency();
    // params[19] = bet.getWinLostDate();
    // params[20] = bet.getOddsType();
    // params[21] = bet.getBetTeam();
    // params[22] = bet.getHomeHandicap();
    // params[23] = bet.getAwayHandicap();
    // params[24] = bet.getHandicap();
    // params[25] = bet.getBetFrom();
    // params[26] = bet.getIsLive();
    // params[27] = bet.getHomeScore();
    // params[28] = bet.getAwayScore();
    // params[29] = bet.getCustomerInfo1();
    // params[30] = bet.getCustomerInfo2();
    // params[31] = bet.getCustomerInfo3();
    // params[32] = bet.getCustomerInfo4();
    // params[33] = bet.getCustomerInfo5();
    // params[34] = bet.getBaStatus();
    // params[35] = bet.getVersionKey();
    // params[36] = bet.getProgramId();
    // params[37] = bet.getRaceNumber();
    // params[38] = bet.getRaceLane();
    // params[39] = bet.getTableNo();
    // params[40] = bet.getHandNo();
    // params[41] = bet.getShoeNo();
    // params[42] = bet.getComm();
    // params[43] = bet.getLastBallNo();
    // params[44] = new Date();
    // params[45] = "";
    //
    //
    // log.info("CALL SP["+SP_INSERT_SPORTSBOOK_BET+"] Params["+Arrays.toString(params)+"]");
    // String result = universalDao.callProcedure(SP_INSERT_SPORTSBOOK_BET, params);
    // log.info("SP["+SP_INSERT_SPORTSBOOK_BET+"] Result["+result+"]");
    // }
    // }

    // private void insertSportsbookParleyRecords(List<SportsbookParlayRecord> sportsbookParlayRecords){
    // for (SportsbookParlayRecord parlay : sportsbookParlayRecords) {
    // Object[] params = new Object[19];
    // params[0] = parlay.getParlayRefNo();
    // params[1] = parlay.getLeagueId();
    // params[2] = parlay.getMatchId();
    // params[3] = parlay.getHomeId();
    // params[4] = parlay.getAwayId();
    // params[5] = parlay.getMatchDate();
    // params[6] = parlay.getOdds();
    // params[7] = parlay.getBetType();
    // params[8] = parlay.getBetTeam();
    // params[9] = parlay.getSportsType();
    // params[10] = parlay.getHomeHandicap();
    // params[11] = parlay.getAwayHandicap();
    // params[12] = parlay.getHandicap();
    // params[13] = parlay.getIsLive();
    // params[14] = parlay.getHomeScore();
    // params[15] = parlay.getAwayScore();
    // params[16] = parlay.getWinLost();
    // params[17] = parlay.getWinLostDate();
    // params[18] = "";
    //
    // log.info("CALL SP["+SP_INSERT_SPORTSBOOK_PARLAY+"] Params["+Arrays.toString(params)+"]");
    // String result = universalDao.callProcedure(SP_INSERT_SPORTSBOOK_PARLAY, params);
    // log.info("SP["+SP_INSERT_SPORTSBOOK_PARLAY+"] Result["+result+"]");
    // }
    // }

    private static String getCurrency(int currencyNum) {
        String currency = "";
        switch (currencyNum) {
            case 1:
                currency = "SGD";
                break;
            case 2:
                currency = "MYR";
                break;
            case 3:
                currency = "USD";
                break;
            case 4:
                currency = "THB";
                break;
            case 5:
                currency = "HKD";
                break;
            case 6:
                currency = "EUR";
                break;
            case 9:
                currency = "AUD";
                break;
            case 12:
                currency = "GBP";
                break;
            case 13:
                currency = "CNY";
                break;
            case 15:
                currency = "IDR";
                break;
            case 20:
                currency = "UUS";
                break;
            case 32:
                currency = "JAP";
                break;
            case 41:
                currency = "CHF";
                break;
            case 45:
                currency = "WON";
                break;
            case 46:
                currency = "BND";
                break;
            case 49:
                currency = "MXN";
                break;
            case 50:
                currency = "CAN";
                break;
            case 51:
                currency = "VND";
                break;
            case 52:
                currency = "DKK";
                break;
            case 53:
                currency = "SEK";
                break;
            case 54:
                currency = "NOK";
                break;
            case 55:
                currency = "RUB";
                break;
            case 56:
                currency = "PLN";
                break;
            case 57:
                currency = "CZK";
                break;
            case 58:
                currency = "RON";
                break;
            case 61:
                currency = "INR";
                break;
        }
        return currency;
    }

    public static List getTLBBetRecord(JsonArray dataJsonObject) {
        List<OrderEntity> orderEntityList = null;
        OrderEntity orderEntity = null;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        int jsonArraySize = dataJsonObject.size();
        if (jsonArraySize > 0)
            orderEntityList = new ArrayList<OrderEntity>();
        try {
            for (int i = 0; i < jsonArraySize; i++) {
                orderEntity = new OrderEntity();

                JsonObject betDetailJson = dataJsonObject.getJsonObject(i);
                orderEntity.setBillNo(betDetailJson.getString("proposalId"));
                orderEntity.setLoginName(betDetailJson.getString("loginname"));
                orderEntity.setProductId(betDetailJson.getString("productId"));
                orderEntity.setPlatId("036");
                BigDecimal rate = BigDecimal.ONE;
                if (betDetailJson.getString("rate") != null) {
                    rate = new BigDecimal(betDetailJson.getString("rate"));
                }
                orderEntity.setAccount(new BigDecimal(betDetailJson.getString("accounts")).divide(rate, 2, BigDecimal.ROUND_HALF_EVEN));
                orderEntity.setValidAccount(new BigDecimal(betDetailJson.getString("valid_accounts")).divide(rate, 2, BigDecimal.ROUND_HALF_EVEN));
                orderEntity.setCusAccount(new BigDecimal(betDetailJson.getString("profit")).divide(rate, 2, BigDecimal.ROUND_HALF_EVEN));
                orderEntity.setFlag(1);
                orderEntity.setPlayType(Integer.parseInt(betDetailJson.getString("proposalType")));
                if (betDetailJson.containsKey("tip")) {
                    String tipStr = betDetailJson.getString("tip");
                    if (tipStr.matches("\\-?[0-9]+(\\.[0-9]+)?")) {
                        orderEntity.setTip(new BigDecimal(tipStr).divide(rate, 2, BigDecimal.ROUND_HALF_EVEN));
                    }
                }

                orderEntity.setCurrency("CNY");
                orderEntity.setGameType("BAC");
                orderEntity.setBillTime(sdf.parse(betDetailJson.getString("createTime")));
                orderEntity.setCreationDate(sdf.parse(betDetailJson.getString("accountTime")));
                orderEntityList.add(orderEntity);
            }
        } catch (ParseException e) {
            log.error("JsonArray - createTime Parse Exception", e);
        }
//        catch(Exception ex){
//        	log.error("JsonArray - createTime Exception:" + ex.getMessage());
//        }
        return orderEntityList;
    }

    public static List<AccountTransferEntity> getTLBTransferRecord(JsonArray dataJsonObject, String productId) throws Exception {
        List<AccountTransferEntity> accountTransferEntityList = null;
        AccountTransferEntity accountTransferEntity = null;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        if (dataJsonObject == null || dataJsonObject.size() == 0) {
            return accountTransferEntityList;
        }

        accountTransferEntityList = new ArrayList<AccountTransferEntity>();
        int jsonArraySize = dataJsonObject.size();
        for (int i = 0; i < jsonArraySize; i++) {
            JsonObject betDetailJson = dataJsonObject.getJsonObject(i);
            accountTransferEntity = new AccountTransferEntity();
            accountTransferEntity.setTransId(betDetailJson.getString("tradeno"));
            accountTransferEntity.setUserName((betDetailJson.getString("loginname")).replace(productId, StringUtils.EMPTY));
            accountTransferEntity.setProductId(productId.replace("PHP", StringUtils.EMPTY));
            accountTransferEntity.setPlatformId(UtilConstants.TLB);
            accountTransferEntity.setPreviousAmount(new BigDecimal(String.valueOf(betDetailJson.getJsonNumber("before"))));
            accountTransferEntity.setCurrentAmount(new BigDecimal(String.valueOf(betDetailJson.getJsonNumber("after"))));
            accountTransferEntity.setTransferAmount(new BigDecimal(String.valueOf(betDetailJson.getJsonNumber("amount"))));
            accountTransferEntity.setTransferAmount(accountTransferEntity.getTransferAmount());
            //accountTransferEntity.setFlag(1);
            accountTransferEntity.setTradeNo(betDetailJson.getString("tradeno"));
            accountTransferEntity.setCurrency(UtilConstants.CNY);
            String d = sdf.format(Long.parseLong(String.valueOf(betDetailJson.getJsonNumber("time"))) * 1000);
            accountTransferEntity.setCreationTime(sdf.parse(d));
            accountTransferEntity.setOrignalCreationTime(accountTransferEntity.getCreationTime());//tlb和北京时间是一样的
            String transferType = betDetailJson.getString("code");
            transferType = transferType.replace("DEPOSIT", "IN");
            transferType = transferType.replace("TAKEOUT", "OUT");
            accountTransferEntity.setTransferType(transferType);
            accountTransferEntityList.add(accountTransferEntity);
        }
        return accountTransferEntityList;
    }


    public static List<AccountTransferEntity> getAGQJTransferRecord(JsonArray dataJsonObject, String productId) throws Exception {
        List<AccountTransferEntity> accountTransferEntityList = null;
        AccountTransferEntity accountTransferEntity = null;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        if (dataJsonObject == null || dataJsonObject.size() == 0) {
            return accountTransferEntityList;
        }
        accountTransferEntityList = new ArrayList<>();
        int jsonArraySize = dataJsonObject.size();
        for (int i = 0; i < jsonArraySize; i++) {
            JsonObject betDetailJson = dataJsonObject.getJsonObject(i);
            accountTransferEntity = new AccountTransferEntity();
            accountTransferEntity.setTransId(betDetailJson.getString("tradeno"));
            accountTransferEntity.setUserName((betDetailJson.getString("loginname")).replace(productId, StringUtils.EMPTY));
            accountTransferEntity.setProductId(productId.replace("PHP", StringUtils.EMPTY));
            accountTransferEntity.setPlatformId(UtilConstants.TLB);
            accountTransferEntity.setPreviousAmount(new BigDecimal(String.valueOf(betDetailJson.getJsonNumber("before"))));
            accountTransferEntity.setCurrentAmount(new BigDecimal(String.valueOf(betDetailJson.getJsonNumber("after"))));
            accountTransferEntity.setTransferAmount(new BigDecimal(String.valueOf(betDetailJson.getJsonNumber("amount"))));
            accountTransferEntity.setTransferAmount(accountTransferEntity.getTransferAmount());
            accountTransferEntity.setFlag(1);
            accountTransferEntity.setTradeNo(betDetailJson.getString("tradeno"));
            accountTransferEntity.setCurrency(UtilConstants.CNY);
            String d = sdf.format(Long.parseLong(String.valueOf(betDetailJson.getJsonNumber("time"))) * 1000);
            accountTransferEntity.setCreationTime(sdf.parse(d));
            accountTransferEntity.setOrignalCreationTime(accountTransferEntity.getCreationTime());
            String transferType = betDetailJson.getString("code");
            transferType = transferType.replace("DEPOSIT", "IN");
            transferType = transferType.replace("TAKEOUT", "OUT");
            accountTransferEntity.setTransferType(transferType);
            accountTransferEntityList.add(accountTransferEntity);
        }
        return accountTransferEntityList;
    }

    /**
     * Return string by calling remote interface.
     *
     * @param wholeRrl
     * @param encoding
     * @return string
     * @throws GWCallRemoteApiException
     */
    public static String httpGetClient(String wholeRrl, String encoding) throws GWCallRemoteApiException {
        // define log
        StringBuffer stringBuffer = new StringBuffer();
        HttpURLConnection conn = null;
        BufferedReader bufferReader = null;
        InputStream inutStream = null;
        String xmlStr = null;
        try {

            if (wholeRrl != null) {
                URL url = new URL(wholeRrl);
                conn = (HttpURLConnection) url.openConnection();
                conn.setDoOutput(false);
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(30000);
                conn.connect();
                inutStream = conn.getInputStream();
                bufferReader = new BufferedReader(new InputStreamReader(inutStream));
                while ((xmlStr = bufferReader.readLine()) != null) {
                    stringBuffer.append(xmlStr);
                }
            }
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            log.error("Call remote interface failure with URL:" + wholeRrl);
            throw new GWCallRemoteApiException("Failed to call remote interface!" + ex.getMessage(), ex);
        } finally {
            if (bufferReader != null) {
                try {
                    bufferReader.close();
                } catch (Exception e) {
                    log.error("Close buffer stream failure!", e);
                }
            }
            if (inutStream != null) {
                try {
                    inutStream.close();
                } catch (Exception e) {
                    log.error("Close inputstream failure!", e);
                }
            }
            if (conn != null) {
                conn.disconnect();
            }
        }
        log.info("Call remote interface successfully by URL:" + wholeRrl);
        return stringBuffer.toString();
    }

    public static void main(String[] args) throws Exception {
        BigDecimal b = new BigDecimal(-1900);
        System.out.println(b.abs());


    }
}
