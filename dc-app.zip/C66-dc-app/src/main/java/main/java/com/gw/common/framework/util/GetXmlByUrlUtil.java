/**
 *
 */
package main.java.com.gw.common.framework.util;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.params.HttpClientParams;
import org.apache.commons.lang3.StringUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Call remote interface with URL and HttpURLConnection.
 *
 * @author alex.l
 */
@Slf4j
public class GetXmlByUrlUtil {

    /**
     * Return string by calling remote interface.
     *
     * @param baseUrl
     * @param parameterMap
     * @param encoding
     * @return string
     * @throws GWCallRemoteApiException
     */
//    public static String getXmlStream(String baseUrl, Map<String, Object> parameterMap, String encoding) throws GWCallRemoteApiException {
//        // define log
//        StringBuffer stringBuffer = new StringBuffer();
//        HttpURLConnection conn = null;
//        BufferedReader bufferReader = null;
//        InputStream inutStream = null;
//        String wholeRrl = null;
//        try {
//            wholeRrl = UrlGeneratorUtil.generateUrl(parameterMap, baseUrl, encoding);
////            wholeRrl = "http://10.66.73.113:6501/getordersresult.xml?productid=002&key=689dfff20af9ef02efa4916314c55628&num=10&gmcode=GP00118C270EE&endtime=2018-12-31%2012:00:00&begintime=2018-12-01%2012:00:00";
//            log.info("call wholeRrl: " + wholeRrl);
//            if (wholeRrl != null) {
//                URL url = new URL(wholeRrl);
//                conn = (HttpURLConnection) url.openConnection();
//                conn.setDoOutput(false);
//                conn.setConnectTimeout(30000);
//                conn.setReadTimeout(120000);
//                conn.connect();
//                inutStream = conn.getInputStream();
//                bufferReader = new BufferedReader(new InputStreamReader(inutStream));
//                String xmlStr;
//                while ((xmlStr = bufferReader.readLine()) != null) {
//                    stringBuffer.append(xmlStr);
//                }
//            }
//        } catch (Exception ex) {
//            log.error(ex.getMessage(), ex);
//            log.error("Call remote interface failure with URL:" + wholeRrl);
//            throw new GWCallRemoteApiException("Failed to call remote interface!" + ex.getMessage(), ex);
//        } finally {
//            if (bufferReader != null) {
//                try {
//                    bufferReader.close();
//                } catch (Exception e) {
//                    log.error("Close buffer stream failure!", e);
//                }
//            }
//            if (inutStream != null) {
//                try {
//                    inutStream.close();
//                } catch (Exception e) {
//                    log.error("Close inputstream failure!", e);
//                }
//            }
//            if (conn != null) {
//                conn.disconnect();
//            }
//        }
//        log.info("Call remote interface successfully by URL:" + wholeRrl);
//        return stringBuffer.toString();
//    }

    /**
     * @Description: zipkin集成，将原来的URL类改为HttpClient
     * @Author: Ziv.Y
     * @Date: 2019/7/19 11:33
     */
    public static String getXmlStream(String baseUrl, Map<String, Object> parameterMap, String encoding) throws GWCallRemoteApiException {
        String result = null;
        String wholeRrl = null;
        try {
            wholeRrl = UrlGeneratorUtil.generateUrl(parameterMap, baseUrl, encoding);
            log.info("call wholeRrl: " + wholeRrl);
            if (wholeRrl != null) {
                result = new HttpUtil().doGet(wholeRrl);
            }
        } catch (Exception ex) {
            log.error("remote interface failure", ex);
            log.error("Call remote interface failure with URL:" + wholeRrl);
            throw new GWCallRemoteApiException("Failed to call remote interface!" + ex.getMessage(), ex);
        }
        log.info("Call remote interface successfully by URL:" + wholeRrl);
        return result;
    }

    public static String getXmlStreamFoPost(String baseUrl, Map<String, Object> parameterMap, String encoding) throws GWCallRemoteApiException {
        String result = null;
        try {
            baseUrl = UrlGeneratorUtil.generateUrl(parameterMap, baseUrl, encoding);
            Map<String, Object> postParams = new HashMap<>();
            if (baseUrl.contains("gamerecord.php")){
                postParams.put("agent",parameterMap.get("agent"));
                postParams.put("ev_mode",parameterMap.get("ev_mode"));
                Date startTime =  DateUtil.formatStr2Date((String)parameterMap.get(UtilConstants.ORDER_BEGIN_TIME), DateUtil.C_TIME_PATTON_DEFAULT);
                Date endTime =  DateUtil.formatStr2Date((String)parameterMap.get(UtilConstants.ORDER_END_TIME), DateUtil.C_TIME_PATTON_DEFAULT);
                postParams.put(UtilConstants.ORDER_START_TIME,(startTime.getTime() + "").substring(0,10));
                postParams.put(UtilConstants.ORDER_END_TIME,(endTime.getTime() + "").substring(0,10));
                postParams.put("currency",parameterMap.get("currency"));
                postParams.put("wallet",parameterMap.get("wallet"));
            }
            log.info("call-baseUrl:{}-postParams-{}",baseUrl,postParams);
            if (baseUrl != null) {
                result = new HttpUtil().doPost(baseUrl,postParams);
            }
        } catch (Exception ex) {
            log.error("remote interface failure", ex);
            log.error("Call remote interface failure with URL:" + baseUrl);
            throw new GWCallRemoteApiException("Failed to call remote interface {}", ex);
        }
        log.info("Call remote interface successfully by URL:" + baseUrl);
        return result;
    }

    /**
     * getXmlComputerGameStream
     * Return string by calling remote interface.
     *
     * @param baseUrl
     * @param parameterMap
     * @param encoding
     * @return string
     * @throws GWCallRemoteApiException
     */
    public static String getXmlComputerGameStream(String baseUrl, Map<String, Object> parameterMap, String encoding) throws GWCallRemoteApiException {
        // define log
        StringBuffer stringBuffer = new StringBuffer();
        HttpURLConnection conn = null;
        BufferedReader bufferReader = null;
        InputStream inutStream = null;
        String wholeRrl = null;
        String xmlStr = null;
        try {
            wholeRrl = UrlGeneratorUtil.generateComputerGameUrl(parameterMap, baseUrl, encoding);
            log.info("getXmlComputerGameStream获取URL地址=" + wholeRrl + "<<<<<<");
            if (wholeRrl != null) {
                URL url = new URL(wholeRrl);
                conn = (HttpURLConnection) url.openConnection();
                conn.setDoOutput(false);
                conn.setConnectTimeout(30000);
                conn.setReadTimeout(120000);
                conn.connect();
                inutStream = conn.getInputStream();
                bufferReader = new BufferedReader(new InputStreamReader(inutStream));
                while ((xmlStr = bufferReader.readLine()) != null) {
                    stringBuffer.append(xmlStr);
                }
            }
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            log.error("Call remote interface failure with URL:" + wholeRrl);
            throw new GWCallRemoteApiException("Failed to call remote interface!" + ex.getMessage(), ex);
        } finally {
            if (bufferReader != null) {
                try {
                    bufferReader.close();
                } catch (IOException e) {
                    log.error("Close buffer stream failure!");
                    e.printStackTrace();
                }
            }
            if (inutStream != null) {
                try {
                    inutStream.close();
                } catch (IOException e) {
                    log.error("Close inputstream failure!");
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                conn.disconnect();
            }
        }
        log.info("Call remote interface successfully by URL:" + wholeRrl);
        return stringBuffer.toString();
    }

    /**
     * Return string by calling remote interface.
     *
     * @param baseUrl
     * @param parameterMap
     * @return string
     * @throws GWCallRemoteApiException
     */
    @SuppressWarnings("deprecation")
    public static String getXmlStream4HoGaming(String baseUrl, Map<String, Object> parameterMap, String firstNodeName)
            throws GWCallRemoteApiException {
        if (parameterMap.get("flag") != null) {
            if (parameterMap.get("flag").equals("0")) {
                return UtilConstants.STR_MAINTENANCE;
            }
        }
        String xmlStr = null;
        PostMethod httpPost = new PostMethod(baseUrl);
        StringBuffer xmlresponse = new StringBuffer(UtilConstants.XML_VERSION);
        xmlresponse.append(UtilConstants.ANGLE_BRACKET_LEFT1);
        xmlresponse.append(firstNodeName);
        xmlresponse.append(UtilConstants.ANGLE_BRACKET_RIGHT);
        xmlresponse.append("<Username>");
        xmlresponse.append(parameterMap.get("username"));
        xmlresponse.append("</Username>");
        xmlresponse.append("<Password>");
        xmlresponse.append(parameterMap.get("password"));
        xmlresponse.append("</Password>");
        xmlresponse.append("<CasinoId>");
        xmlresponse.append(parameterMap.get("website"));
        xmlresponse.append("</CasinoId>");
        xmlresponse.append("<UserId>");
        xmlresponse.append(parameterMap.get("UserId"));
        xmlresponse.append("</UserId>");
        xmlresponse.append("<startTime>");
        xmlresponse.append(parameterMap.get("begintime"));
        xmlresponse.append(UtilConstants.SUFFIX_MILLISECOND_START);
        xmlresponse.append("</startTime>");
        xmlresponse.append("<EndTime>");
        xmlresponse.append(parameterMap.get("endtime"));
        xmlresponse.append(UtilConstants.SUFFIX_MILLISECOND_END);
        xmlresponse.append("</EndTime>");
        xmlresponse.append("<PageSize>");
        xmlresponse.append(parameterMap.get("num"));
        xmlresponse.append("</PageSize>");
        xmlresponse.append("<PageNumber>");
        xmlresponse.append(parameterMap.get("page"));
        xmlresponse.append("</PageNumber>");
        xmlresponse.append(UtilConstants.ANGLE_BRACKET_LEFT2);
        xmlresponse.append(firstNodeName);
        xmlresponse.append(UtilConstants.ANGLE_BRACKET_RIGHT);

        try {
            HttpClient httpclient = new HttpClient();
            httpPost.addRequestHeader("Content-Type", "text/xml");
            httpPost.setRequestBody(xmlresponse.toString());
            // add by edwin
            HttpClientParams hcParams = new HttpClientParams();
            hcParams.setSoTimeout(30000);
            httpclient.setParams(hcParams);
            // end
            httpclient.executeMethod(httpPost);
            xmlStr = httpPost.getResponseBodyAsString();
            // xmlStr = xmlStr.replaceAll("\\s*|\t|\r|\n",UtilConstants.BLANK);
            if (xmlStr.indexOf(UtilConstants.LINE_BREAK) != -1) {
                xmlStr = StringUtils.replace(xmlStr, UtilConstants.LINE_BREAK, UtilConstants.BLANK);
            }
            if (xmlStr.indexOf(UtilConstants.ANGLE_BRACKET_LEFT_CHARACTER) != -1) {
                xmlStr = StringUtils.replace(xmlStr, UtilConstants.ANGLE_BRACKET_LEFT_CHARACTER, UtilConstants.ANGLE_BRACKET_LEFT1);
                xmlStr = StringUtils.replace(xmlStr, UtilConstants.ANGLE_BRACKET_RIGHT_CHARACTER, UtilConstants.ANGLE_BRACKET_RIGHT);
            }

            log.info("Call remote interface successfully with URL hogaming Post baseUrl:" + baseUrl);
            log.info("Call remote interface successfully with URL hogaming Post value:" + xmlresponse.toString());
            return xmlStr;
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new GWCallRemoteApiException("Failed to call hogaming webservice!" + ex.getMessage(), ex);
        } finally {
            httpPost.releaseConnection();

        }
    }

    /**
     * Just for test calling remote interface.
     *
     * @param args
     * @throws GWCallRemoteApiException
     */
    public static void main(String[] args) throws GWCallRemoteApiException {
        String baseUrl_game = "http://webapi-asia.hointeractive.com/betapi.asmx/GetAllBetDetailsPerTimeInterval";
        // String baseUrl_game =
        // "http://webapi-asia.hointeractive.com/betapi.asmx/GetAllFundTransferDetailsTimeInterval";
        // String baseUrl_game =
        // "http://webapi-asia.hointeractive.com/betapi.asmx/GetGameResultInfo";
        String firstNodeName = "GetAllBetDetailsPerTimeInterval";
        Map<String, Object> parameterMap = new HashMap<String, Object>();
        parameterMap.put("username", "topone");
        parameterMap.put("password", "top@one@");
        parameterMap.put("website", "sw54aru29pa8thin");
        parameterMap.put("UserId", "");
        parameterMap.put("begintime", "2011-11-19 09:33:00");
        parameterMap.put("endtime", "2011-11-19 09:34:59");
        parameterMap.put("num", "400");
        parameterMap.put("page", "1");

        String xmlStr = GetXmlByUrlUtil.getXmlStream4HoGaming(baseUrl_game, parameterMap, firstNodeName);
        System.out.println(xmlStr);
    }
}
