package main.java.com.gw.common.framework.util;

import io.netty.util.internal.StringUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.httpclient.params.HttpConnectionParams;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.HttpResponseException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.conn.ssl.X509HostnameVerifier;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpProtocolParams;
import org.apache.http.util.EntityUtils;
import org.springframework.util.StopWatch;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Map;


/**
 * Copy from : gameinterface:com.gw.util.HttpClientUtils
 *
 * @author Ricardo.X
 */
@Slf4j
public class HttpClientUtils {

    /**
     * 常用User-Agent
     */

    /**
     * Chrome User-Agent
     */
    public static final String CHROME = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.94 Safari/537.36";

    /**
     * FireFox User-Agent
     */
    public static final String FIREFOX = "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:35.0) Gecko/20100101 Firefox/35.0";

    /**
     * IE11 Win8 User-Agent
     */
    public static final String IE11W8 = "Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; rv:11.0) like Gecko";

    /**
     * IE10 Win7 User-Agent
     */
    public static final String IE10W7 = "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)";

    /**
     * HTTPCLIENT CONNECTION TIMEOUT
     */
    public static final int HTTP_CONNECTION_TIMEOUT = 10;
    /**
     * HTTPCLIENT SOCKET MAX WAIT
     */
    public static final int HTTP_SOCKET_TIMEOUT = 30;


    /**
     * Map to URLEncoded string
     *
     * @param paramMap
     * @return
     */
    public static String mapURLEncoder(Map<String, String> paramMap) {

        String paramURLEncodeStr = null;

        try {
            paramURLEncodeStr = EntityUtils.toString(map2HttpEntity(paramMap));
        } catch (Exception e) {
            log.error("HTTP参数异常!", e);
        }

        return paramURLEncodeStr;
    }


    /**
     * Map Params to HttpEntity
     *
     * @param paramMap
     * @return
     */
    public static HttpEntity map2HttpEntity(Map<String, String> paramMap) {

        HttpEntity entity = null;

        java.util.List<BasicNameValuePair> paramList = new java.util.ArrayList<BasicNameValuePair>();

        for (Map.Entry<String, String> entry : paramMap.entrySet()) {
            paramList.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
        }

        try {
            entity = new UrlEncodedFormEntity(paramList, "UTF-8");
        } catch (Exception e) {
            log.error("HTTP参数异常!", e);
        }

        return entity;
    }


    /**
     * 取得一个默认Client <br/>
     * (Warning : The return instance is not ThreadSafe)
     *
     * @return
     */
    public static HttpClient getDefaultClient() {
        return new DefaultHttpClient();
    }


    /**
     * 取得一个支持SSL的Client, (这里其实可以用连接池的, 由于整体结构太老, 既然大家都new, 那么我就不好意思不new了)<br/>
     * (Warning : The return instance is not ThreadSafe and this client trust any SSL server.)
     *
     * @return
     */
    public static HttpClient getSSLSupportClient() {

        HttpClient client = new DefaultHttpClient();

        ClientConnectionManager ccm = client.getConnectionManager();

        try {

            SSLContext sslContext = SSLContext.getInstance("SSL");

            sslContext.init(null, new TrustManager[]{

                    new X509TrustManager() {

                        @Override
                        public X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }

                        @Override
                        public void checkServerTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
                        }

                        @Override
                        public void checkClientTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
                        }
                    }
            }, new SecureRandom());

            SSLSocketFactory sf = new SSLSocketFactory(sslContext);

            sf.setHostnameVerifier(new X509HostnameVerifier() {

                @Override
                public boolean verify(String arg0, SSLSession arg1) {
                    // Trust any https hosts
                    return true;
                }

                @Override
                public void verify(String arg0, String[] arg1, String[] arg2) throws SSLException {
                }

                @Override
                public void verify(String arg0, X509Certificate arg1) throws SSLException {
                }

                @Override
                public void verify(String arg0, SSLSocket arg1) throws IOException {
                }
            });

            SchemeRegistry sr = ccm.getSchemeRegistry();

            sr.register(new Scheme("https", sf, 443));

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        return client;
    }


    /**
     * 执行 POST 请求
     *
     * @param url
     * @return
     * @throws ClientProtocolException (input params reason)
     *                                 IOException (connection reason)
     *                                 HttpResponseException (response reason)
     */
    public static String execPost(String url, Map<String, String> params)
            throws HttpResponseException, ClientProtocolException, IOException {

        if (url == null) throw new IllegalArgumentException("request URL can not be null");

        HttpPost post = new HttpPost(url);

        if (null != params) {
            post.setEntity(map2HttpEntity(params));
        }

        return executeRequest(post);
    }


    /**
     * 执行  GET 请求, 若传MAP类型的参数, 则URL中不要带参数
     *
     * @param url
     * @return
     * @throws ClientProtocolException (input params reason)
     *                                 IOException (connection reason)
     *                                 HttpResponseException (response reason)
     */
    public static String execGet(String url, Map<String, String> params)
            throws HttpResponseException, ClientProtocolException, IOException {

        if (url == null) throw new IllegalArgumentException("request URL can not be null");

        if (params != null) {
            url += "?" + mapURLEncoder(params);
        }

        HttpGet get = new HttpGet(url);

        return executeRequest(get);
    }

    public static String execGetWithHeader(String url, Map<String, String> params,Map<String, String> headers) throws IOException {
        if (url == null) {
            throw new IllegalArgumentException("request URL can not be null");
        }
        if(MapUtils.isNotEmpty(params)){
            if(url.endsWith("?")){
                url += mapURLEncoder(params);
            }else {
                url += "?" + mapURLEncoder(params);
            }

        }
        HttpGet get = new HttpGet(url);
        if(MapUtils.isNotEmpty(headers)){
            for (Map.Entry<String, String> entry : headers.entrySet()) {
                get.setHeader(entry.getKey(),entry.getValue());
            }
        }
        return executeRequest(get);
    }


    /**
     * 执行 HttpClient 请求
     *
     * @param request
     * @return
     * @throws HttpResponseException
     * @throws ClientProtocolException
     * @throws IOException
     */
    private static String executeRequest(HttpRequestBase request)
            throws
            HttpResponseException, ClientProtocolException, IOException { HttpClient client = null;

        if (request.getURI().getScheme().trim().toLowerCase().equals("https")) {
            client = getSSLSupportClient();
        } else {
            client = getDefaultClient();
        }

        // setting httclient connection and max socket wait timeout
        request.getParams().setParameter(HttpConnectionParams.CONNECTION_TIMEOUT, HTTP_CONNECTION_TIMEOUT * 6000);
        request.getParams().setParameter(HttpConnectionParams.SO_TIMEOUT, HTTP_SOCKET_TIMEOUT * 6000);

        client.getParams().setParameter(HttpProtocolParams.USER_AGENT, CHROME);

        HttpResponse httpResponse = null;
        String responseEntityStr = null;

        // The reason of when any exception occur during executing http request, it's can force shutdown connection manager.
        try {
            httpResponse = client.execute(request);
            int responseCode = httpResponse.getStatusLine().getStatusCode();
            responseEntityStr = EntityUtils.toString(httpResponse.getEntity());
            if (!isNormalResponse(responseCode)) {
                log.info("发起[" + request.getMethod() + "]请求时未能正确获得响应, 请求URL [" + request.getURI().toString() + "] , 响应内容 [" + responseEntityStr + "]");
                throw new HttpResponseException(responseCode, "服务器没有正确响应!,request url : [" + request.getURI().toString() + "]");
            }
        } catch (ClientProtocolException e) {
            throw e;
        } catch (IOException e) {
            throw e;
        } catch (Exception e) {
            throw e;
        } finally {
            // Force shutdown manager if not auto release all connections.
            client.getConnectionManager().shutdown();
        }

        return responseEntityStr;
    }

    /**
     * httpClient post请求 json/xml提交
     * @param url 请求url
     * @param header 头部信息
     * @param json 请求实体 json/xml提交适用
     * @return 可能为空 需要处理
     * @throws Exception
     *
     */
    public static String postJson(String  url, Map<String, String> header, String json) throws Exception {
        log.info(" http post json 请求url:"+url+ "  请求参数："+json);
        HttpPost httpPost = new HttpPost(url);
        // 设置头信息
        if (MapUtils.isNotEmpty(header)) {
            for (Map.Entry<String, String> entry : header.entrySet()) {
                httpPost.setHeader(entry.getKey(), entry.getValue());
            }
        }
        httpPost.setHeader("Content-Type", "application/json");
        // 设置json实体 优先级高
        if (StringUtils.isNotEmpty(json)) {
            StringEntity entity = new StringEntity(json,"UTF-8");//解决中文乱码问题
            httpPost.setEntity(entity);
        }
        return executeRequest(httpPost);
    }

    /**
     * httpClient post请求 text提交
     * @param url 请求url
     * @param header 头部信息
     * @param text 请求实体 text提交适用
     * @return 可能为空 需要处理
     * @throws Exception
     *
     */
    public static String postText(String  url, Map<String, String> header, String text) throws Exception {
        log.info(" http post json 请求url:{},  请求参数：{}",url,text);
        HttpPost httpPost = new HttpPost(url);
        // 设置头信息
        if (MapUtils.isNotEmpty(header)) {
            for (Map.Entry<String, String> entry : header.entrySet()) {
                httpPost.setHeader(entry.getKey(), entry.getValue());
            }
        }
        httpPost.setHeader("Content-Type", "text/plain");
        // 设置json实体 优先级高
        if (!StringUtil.isNullOrEmpty(text)) {
            StringEntity entity = new StringEntity(text,"UTF-8");//解决中文乱码问题
            httpPost.setEntity(entity);
        }
        return executeRequest(httpPost);
    }

    private static boolean isNormalResponse(int code) {
        switch (code) {
            case HttpStatus.SC_OK:
                return true;
            case HttpStatus.SC_CREATED:
                return true;
            case HttpStatus.SC_ACCEPTED:
                return true;
        }
        return false;
    }

    public static String postSSL(String urlStr, String content) {
        SSLUtilities.trustAllHostnames();
        SSLUtilities.trustAllHttpsCertificates();
        StringBuilder reply = new StringBuilder(org.apache.commons.lang3.StringUtils.EMPTY);
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        HttpURLConnection connection = null;
        BufferedReader reader = null;
        try {
            // Post请求的url，与get不同的是不需要带参数
            URL postUrl = new URL(urlStr);
            // 打开连接
            connection = (HttpURLConnection) postUrl.openConnection();
            // 设置是否向connection输出，因为这个是post请求，参数要放在
            // http正文内，因此需要设为true
            connection.setDoOutput(true);
            // Read from the connection. Default is true.
            connection.setDoInput(true);
            connection.setRequestMethod("POST");
            // post 请求不能使用缓存
            connection.setUseCaches(false);
            connection.setConnectTimeout(HTTP_CONNECTION_TIMEOUT * 1000);
            connection.setReadTimeout(HTTP_SOCKET_TIMEOUT * 1000);
            //设置本次连接是否自动重定向
            connection.setInstanceFollowRedirects(true);
            connection.setRequestProperty("Content-Type", "application/xml;charset=UTF-8");
            // 连接，从postUrl.openConnection()至此的配置必须要在connect之前完成，
            connection.connect();
            DataOutputStream out = new DataOutputStream(connection.getOutputStream());
            out.writeBytes(content);
            //流用完记得关
            out.flush();
            out.close();
            //获取响应
            reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                reply.append(line);
            }
        } catch (Exception e) {
            log.error("call Url:{} encounter error." ,urlStr, e);
        } finally {
            stopWatch.stop();
            log.info("all Url:{},total cost:{}.",urlStr,stopWatch.getTotalTimeMillis());
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException e) {
                log.error("getHttpResponse方法关闭流失败！", e);
            }
            if (connection != null) {
                connection.disconnect();
            }
        }
        return reply.toString();
    }
}
