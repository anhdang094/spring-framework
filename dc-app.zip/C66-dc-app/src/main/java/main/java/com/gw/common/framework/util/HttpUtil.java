package main.java.com.gw.common.framework.util;

import brave.http.HttpTracing;
import brave.httpclient.IntechTracingHttpClientBuilder;
import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.*;
import java.util.Map.Entry;

@Slf4j
public class HttpUtil {
    private final static int CONNECTION_TIMEOUT = 50000;
    private static final String URL_PARAM_CONNECT_FLAG = "&";
    private HttpClient httpclient;

    public HttpUtil() {
//        HttpParams httpParams = new BasicHttpParams();
//        HttpConnectionParams.setConnectionTimeout(httpParams, CONNECTION_TIMEOUT);
//        HttpConnectionParams.setSoTimeout(httpParams, CONNECTION_TIMEOUT);
//        httpParams.setParameter(ClientPNames.COOKIE_POLICY, CookiePolicy.BROWSER_COMPATIBILITY);
//        httpclient = new DefaultHttpClient(httpParams);

        /*--- start ------ zipkin集成 modified by ziv 2019-07-12-------*/
        HttpTracing httpTracing = null;
        try {
            httpTracing = SpringContext.getBean(HttpTracing.class);
        } catch (Exception e) {
        }
        // 构建 HttpClientBuilder
        HttpClientBuilder httpClientBuilder = Objects.isNull(httpTracing) ? HttpClientBuilder.create() : IntechTracingHttpClientBuilder.create(httpTracing);
        // 构建 HttpClient 对象
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(CONNECTION_TIMEOUT)
                .setSocketTimeout(CONNECTION_TIMEOUT).build();
        httpclient = httpClientBuilder.setDefaultRequestConfig(requestConfig).build();
        /*--- end ---------*/
    }

    /**
     * get http request
     *
     * @param url
     * @param parameterMap
     * @return String Response content
     * @throws ClientProtocolException
     * @throws IOException
     */
    public String httpGet(String url, Map<String, Object> parameterMap) throws Exception {
        String content = "";
        try {
            Iterator<?> iter = parameterMap.entrySet().iterator();
            while (iter.hasNext()) {
                Entry<?, ?> entry = (Entry<?, ?>) iter.next();
                String parmName = entry.getKey().toString();
                String parmValue = "";
                if (entry.getValue() != null) {
                    parmValue = entry.getValue().toString();
                }
                if (!url.contains("?")) {
                    url = url + "?" + parmName + "=" + parmValue;
                } else {
                    url = url + "&" + parmName + "=" + parmValue;
                }
            }
            url = url.replace(UtilConstants.HTTP_BLANK, UtilConstants.HTTP_PARM_BLANK);
            log.info("url=" + url);
            // 创建httpget
//            System.out.println("url=" + url);
            HttpGet httpGet = new HttpGet(url);

            HttpResponse response = httpclient.execute(httpGet);
            // 获取响应实体
            HttpEntity entity = response.getEntity();
            // 打印响应状态
            if (entity != null) {
                content = EntityUtils.toString(entity, HTTP.UTF_8).toString();
            }
//            log.info("response content:" + content);
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw ex;
        } finally {
            // 关闭连接,释放资源
            httpclient.getConnectionManager().shutdown();
        }
        return content;
    }

    public String doGet(String url) throws IOException {
        String returnMsg = "";
        HttpGet httpget = new HttpGet(url);
        HttpResponse response = httpclient.execute(httpget);
        if (HttpStatus.SC_OK == response.getStatusLine().getStatusCode()) {
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                returnMsg = EntityUtils.toString(entity);
                entity.consumeContent();
            }
        }
        return returnMsg;
    }

    public String doGet(String url, String token) throws IOException {
        String returnMsg = "";
        HttpGet httpget = new HttpGet(url);
        httpget.addHeader("Authorization", "Bearer " + token);// 添加头部的令牌校验
        HttpResponse response = httpclient.execute(httpget);
        if (HttpStatus.SC_OK == response.getStatusLine().getStatusCode()) {
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                //returnMsg = EntityUtils.toString(entity);
                returnMsg = EntityUtils.toString(entity, HTTP.UTF_8);
                entity.consumeContent();
            }
        }
        return returnMsg;
    }

    public String doGetWithHeader(String url, Map<String, String> headers,String taskId) throws IOException {
        String returnMsg = "";
        HttpGet httpget = new HttpGet(url);
        if (MapUtils.isNotEmpty(headers)) {
            for (Map.Entry<String, String> entry : headers.entrySet()) {
                httpget.setHeader(entry.getKey(), entry.getValue());
            }
        }
        log.info(taskId + " get cq9 orders url: "+url);
        HttpResponse response = httpclient.execute(httpget);
        if (HttpStatus.SC_OK == response.getStatusLine().getStatusCode()) {
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                //returnMsg = EntityUtils.toString(entity);
                returnMsg = EntityUtils.toString(entity, HTTP.UTF_8);
                entity.consumeContent();
            }
        } else {
            log.error(taskId+" "+url + " response status is :" + response.getStatusLine().getStatusCode() + "");
        }
        return returnMsg;
    }

    public String doPost(String url, Map<String, Object> map) throws IOException {
        StringBuffer returnMsg = new StringBuffer("");
        List<NameValuePair> nvps = new ArrayList<NameValuePair>();
        log.info(url + " post url param=" + map);
        if (map != null && !map.isEmpty()) {
            Iterator<Entry<String, Object>> itr = map.entrySet().iterator();
            while (itr.hasNext()) {
                Map.Entry<String, Object> entry = itr.next();
                if (entry.getValue() != null) {
                    NameValuePair nvp = new BasicNameValuePair(entry.getKey(), (entry.getValue()).toString());
                    nvps.add(nvp);
                }

            }
        }
        HttpPost httpost = new HttpPost(url);
        UrlEncodedFormEntity encodedFormEntity = new UrlEncodedFormEntity(nvps, "UTF-8");
        encodedFormEntity.setContentType("application/x-www-form-urlencoded");
        httpost.setEntity(encodedFormEntity);
        returnMsg = getPostResponse(url, returnMsg, httpost);
        return returnMsg.toString();
    }

    private StringBuffer getPostResponse(String url, StringBuffer returnMsg, HttpPost httpost) throws IOException {
        HttpResponse response = httpclient.execute(httpost);
        if (HttpStatus.SC_OK == response.getStatusLine().getStatusCode()) {
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                // returnMsg = EntityUtils.toString(entity);
                BufferedReader reader = new BufferedReader(new InputStreamReader(entity.getContent(), "UTF-8"));
                String line = null;
                while ((line = reader.readLine()) != null) {
                    returnMsg = returnMsg.append(line);
                }
                entity.consumeContent();

            }
        } else {
            log.error(url + " response status is :" + response.getStatusLine().getStatusCode() + "");
        }
        return returnMsg;
    }

    public static void redirect(HttpServletResponse response, HttpServletRequest request, String url) {
        response.setStatus(301);
        response.setHeader("Location", url);
        response.setHeader("Connection", "close");
    }

    /**
     * @param url
     * @param method GET / POST
     * @param map
     * @return
     * @throws IOException
     * @throws URISyntaxException
     */
    public String getXMLResponse(String url, String method, Map<String, String> map) throws IOException, URISyntaxException {


        String returnMsg = "";

        //HttpRequestBase requestBase = null;

        HttpUriRequest requestBase = null;

        if (StringUtils.isBlank(method)) {
            method = org.apache.http.client.methods.HttpGet.METHOD_NAME;
        }
        StringBuilder actionUrl = new StringBuilder(url);
        if (method.equalsIgnoreCase(org.apache.http.client.methods.HttpGet.METHOD_NAME)) {

            if (map != null && !map.isEmpty()) {
                for (Map.Entry<String, String> entry : map.entrySet()) {
                    if (actionUrl.indexOf("?") > -1) {
                        actionUrl.append("&").append(entry.getKey()).append("=").append(entry.getValue());
                    } else {
                        actionUrl.append("?").append(entry.getKey()).append("=").append(entry.getValue());
                    }
                }
            }

            String dourl = actionUrl.toString().replace(UtilConstants.HTTP_BLANK, UtilConstants.HTTP_PARM_BLANK);
            requestBase = new org.apache.http.client.methods.HttpGet(dourl);

            log.info(" 请求信息：" + requestBase.getRequestLine());
        } else {
            requestBase = new org.apache.http.client.methods.HttpPost(actionUrl.toString());
            List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(3);
            //List<NameValuePair>  nameValuePairs = URLEncodedUtils.parse(requestBase.getURI(),"UTF-8");
            NameValuePair nvp = null;
            //HttpParams params = requestBase.getParams();
            if (map != null && !map.isEmpty()) {
                for (Map.Entry<String, String> entry : map.entrySet()) {
                    nvp = new BasicNameValuePair(entry.getKey(), entry.getValue());
                    nameValuePairs.add(nvp);
                    //params.setParameter(entry.getKey(), entry.getValue());
                }
            }
            HttpEntity httpEntity = new UrlEncodedFormEntity(nameValuePairs, "UTF-8");
            ((HttpPost) requestBase).setEntity(httpEntity);
            //log.info("url ="+actionUrl.toString());
            log.info(" 请求信息：" + requestBase.getRequestLine());


        }
        requestBase.setHeader("Accept", "text/html,application/xhtml+xml,application/xml");

        //requestBase.setURI(new URI(actionUrl.toString()));


        HttpResponse httpResponse = httpclient.execute(requestBase);
        log.info(" 响应信息：" + httpResponse.getStatusLine());

        if (HttpStatus.SC_OK == httpResponse.getStatusLine().getStatusCode()) {
            HttpEntity entity = httpResponse.getEntity();
            if (entity != null) {
                returnMsg = EntityUtils.toString(entity);
                entity.consumeContent();
            }
        } else {
            log.error("====response status:" + httpResponse.getStatusLine().getStatusCode() + "========");
        }
        return returnMsg;
    }


    /**
     * POST METHOD
     *
     * @param strUrl String
     *               Map
     * @return List
     * @throws IOException
     */
    public static String URLPost(String strUrl, Map map) throws Exception {
        String content = "";
        StringBuffer result = new StringBuffer();
        content = getUrl(map);
        String totalURL = null;
        if (strUrl.indexOf("?") == -1) {
            totalURL = strUrl + "?" + content;
        } else {
            totalURL = strUrl + "&" + content;
        }
        log.info("url:" + totalURL);
        URL url = new URL(strUrl);
        HttpURLConnection con = null;
        try {
            con = (HttpURLConnection) url.openConnection();
        } catch (Exception e) {
            if (con == null) {
                con = (HttpURLConnection) url.openConnection();
                log.debug("URL POST 请求!");
            }
        }
        con.setConnectTimeout(30000);
        con.setReadTimeout(50000);
        con.setDoInput(true);
        con.setDoOutput(true);
        con.setAllowUserInteraction(false);
        con.setUseCaches(false);
        con.setRequestMethod("POST");
        con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
        BufferedWriter bout = new BufferedWriter(new OutputStreamWriter(con.getOutputStream()));
        bout.write(content);
        bout.flush();
        bout.close();
        BufferedReader bin = new BufferedReader(new InputStreamReader(con.getInputStream()));
        // List result = new ArrayList();
        while (true) {
            String line = bin.readLine();
            if (line == null) {
                break;
            } else {
                result.append(line);
            }
        }
        bin.close();
        con.disconnect();
        return (result.toString());

    }

    /**
     * @param map
     * @return String
     */
    private static String getUrl(Map map) {
        if (null == map || map.keySet().size() == 0) {
            return ("");
        }
        StringBuffer url = new StringBuffer();
        Set keys = map.keySet();
        for (Iterator i = keys.iterator(); i.hasNext(); ) {
            String key = String.valueOf(i.next());
            if (map.containsKey(key)) {
                url.append(key).append("=").append(String.valueOf(map.get(key))).append(URL_PARAM_CONNECT_FLAG);
            }
        }
        String strURL = "";
        strURL = url.toString();
        if (URL_PARAM_CONNECT_FLAG.equals("" + strURL.charAt(strURL.length() - 1))) {
            strURL = strURL.substring(0, strURL.length() - 1);
        }
        return (strURL);
    }

    public static String resultHttpUrl(String url) throws Exception {
        HttpURLConnection conn = null;
        BufferedReader bufferReader = null;
        InputStream inutStream = null;
        StringBuffer stringBuffer = new StringBuffer();
        String read;
        try {
            if (url != null) {
                URL urlhttp = new URL(url);
                conn = (HttpURLConnection) urlhttp.openConnection();
                conn.setDoOutput(false);
                conn.setConnectTimeout(30000);
                conn.setReadTimeout(120000);
                conn.connect();
                inutStream = conn.getInputStream();
                bufferReader = new BufferedReader(new InputStreamReader(inutStream));
                while ((read = bufferReader.readLine()) != null) {
                    stringBuffer.append(read);
                }
            }

        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            log.error("Call remote interface failure with URL:" + url);
            throw new Exception(ex);
        } finally {
            if (bufferReader != null) {
                try {
                    bufferReader.close();
                } catch (IOException e) {
                    log.error("Close buffer stream failure!");
                }
            }
            if (inutStream != null) {
                try {
                    inutStream.close();
                } catch (IOException e) {
                    log.error("Close inputstream failure!");
                }
            }
            if (conn != null) {
                conn.disconnect();
            }
        }
        log.info("Call remote interface successfully by URL:" + url);
        return stringBuffer.toString();
    }

    public String doPost(String url, String params, String token, String finalToken) {
        StringBuilder result = new StringBuilder();
        OutputStream out = null;
        BufferedReader in = null;
        try {
            URL httpUrl = new URL(url);
            HttpURLConnection httpConn = (HttpURLConnection) httpUrl.openConnection();
            httpConn.setDoOutput(true);
            httpConn.setDoInput(true);
            httpConn.setUseCaches(false);
            httpConn.setRequestProperty("Content-Type", "application/json");
            httpConn.setRequestProperty("Authorization", "Bearer " + token);
            httpConn.setRequestProperty("Authorization-Final", "Bearer " + finalToken);
            httpConn.setRequestProperty("Cache-Control", "no-cache");
            httpConn.setRequestMethod("POST");
            out = httpConn.getOutputStream();
            out.write(params.getBytes());
            out.flush();

            in = new BufferedReader(new InputStreamReader(httpConn.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            result = new StringBuilder("error");
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
                if (out != null) {
                    out.close();
                }
            } catch (IOException e) {
                log.error(e.getMessage(), e);
            }
        }
        return result.toString();
    }

    public String execPostWithHeader(String url, Map<String, String> params, Map<String, String> headers ) throws Exception {
        StringBuffer returnMsg = new StringBuffer();
        if (url == null) {
            throw new IllegalArgumentException("request URL can not be null");
        }
        log.info(" ,url:{},params:{}", url, params);
        HttpPost post = new HttpPost(url);
        if (null != params) {
            post.setEntity(map2HttpEntity(params));
        }
        if (MapUtils.isNotEmpty(headers)) {
            for (Map.Entry<String, String> entry : headers.entrySet()) {
                post.setHeader(entry.getKey(), entry.getValue());
            }
        }
        try {
            returnMsg = getPostResponse(url, returnMsg, post);
        } catch (Exception e) {
            log.error("调用url-{}-异常detail-{}" , url,e);
            throw new GWCallRemoteApiException("HTTP请求异常",e);
        }
        return returnMsg.toString();
    }

    public HttpEntity map2HttpEntity(Map<String, String> paramMap) {

        HttpEntity entity = null;

        java.util.List<BasicNameValuePair> paramList = new java.util.ArrayList<BasicNameValuePair>();

        for (Map.Entry<String, String> entry : paramMap.entrySet()) {
            paramList.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
        }

        try {
            entity = new UrlEncodedFormEntity(paramList, "UTF-8");
        } catch (Exception e) {
            log.error("HTTP参数异常!", e);
        }

        return entity;
    }
}
