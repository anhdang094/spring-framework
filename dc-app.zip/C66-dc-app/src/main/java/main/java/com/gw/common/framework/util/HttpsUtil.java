package main.java.com.gw.common.framework.util;
import org.apache.http.*;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.params.ClientPNames;
import org.apache.http.client.params.CookiePolicy;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * @description: HTTP工具类支持https跳过验证请求
 * @date: 2019-06-03
 * @author: EAGLE
 */
public class HttpsUtil {
    private final static int CONNECTION_TIMEOUT = 30*6000;
    private static DefaultHttpClient httpclient;
    public static final String UTF_8 = "UTF-8";
    protected static Logger log = LoggerFactory.getLogger(HttpsUtil.class);

    public HttpsUtil() {
        HttpParams httpParams = new BasicHttpParams();
        HttpConnectionParams.setConnectionTimeout(httpParams, CONNECTION_TIMEOUT);
        HttpConnectionParams.setSoTimeout(httpParams, CONNECTION_TIMEOUT);
        httpParams.setParameter(ClientPNames.COOKIE_POLICY, CookiePolicy.BROWSER_COMPATIBILITY);
        httpclient = new DefaultHttpClient(httpParams);
        allowSSL(httpclient);
    }


    public  String doGet(String url) throws IOException {
        String returnMsg = "";
        HttpGet httpget = new HttpGet(url);
        httpget.addHeader(new BasicHeader("Accept", "*/*"));
        HttpResponse response = httpclient.execute(httpget);
        if (HttpStatus.SC_OK == response.getStatusLine().getStatusCode()) {
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                returnMsg = EntityUtils.toString(entity);
                entity.consumeContent();
            }
        }else {
            throw new RuntimeException(response.getStatusLine().toString());
        }
        return returnMsg;
    }

    /**
     * httpclient忽略证书验证允许https请求
     * @param httpclient
     */
    public static void allowSSL(DefaultHttpClient httpclient) {
        // 调用ssl
        try {
            SSLContext sslcontext = createIgnoreVerifySSL();
            @SuppressWarnings("deprecation")
            SSLSocketFactory sf = new SSLSocketFactory(sslcontext);
            sf.setHostnameVerifier(SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
            Scheme https = new Scheme("https", sf, 443);
            httpclient.getConnectionManager().getSchemeRegistry()
                    .register(https);

        } catch (Exception e) {
            throw new RuntimeException(e.toString());

        }
    }

    /**
     * 绕过验证
     * @return
     * @throws NoSuchAlgorithmException
     * @throws KeyManagementException
     */
    public static SSLContext createIgnoreVerifySSL() throws NoSuchAlgorithmException, KeyManagementException {
        SSLContext sc = SSLContext.getInstance("SSLv3");
        // 实现一个X509TrustManager接口，用于绕过验证，不用修改里面的方法
        X509TrustManager trustManager = new X509TrustManager() {
            @Override
            public void checkClientTrusted(
                    java.security.cert.X509Certificate[] paramArrayOfX509Certificate,
                    String paramString) throws CertificateException {
            }
            @Override
            public void checkServerTrusted(
                    java.security.cert.X509Certificate[] paramArrayOfX509Certificate,
                    String paramString) throws CertificateException {
            }
            @Override
            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                return null;
            }
        };
        sc.init(null, new TrustManager[] { trustManager }, null);
        return sc;
    }


    public String doPost(String url, Map<String, Object> map) throws IOException {
        String returnMsg = "";
        String params= JsonUtil.toJSONString(map);
        try {
            log.info("发送httpPost请求 url={},param={}",url,params);
            HttpPost httpost = new HttpPost(url);
            httpost.setHeader("Content-Type", "application/json");
            //传入请求参数
            httpost.setEntity(new StringEntity(params,"UTF-8"));
            StringEntity stringEntity = new StringEntity(params);
            stringEntity.setContentEncoding(HTTP.UTF_8);
            stringEntity.setContentType("application/json");
            httpost.setEntity(stringEntity);
            HttpResponse response = httpclient.execute(httpost);
            if(response.getStatusLine().getStatusCode() == HttpStatus.SC_OK){
                HttpEntity entity = response.getEntity();
                if (entity != null) {
                    InputStream in = entity.getContent();
                    try {
                        returnMsg = new FileOperate().read(in, "utf-8");
                    } catch (Exception e) {
                        log.error("Reading data Error! post url:" + url, e);
                    }
                }
            }else{
                throw new RuntimeException(response.getStatusLine().toString());
            }
        } catch (Exception e) {
             log.error("发送httpPost请求出现异常 url={},param={}",url,params,e);
             throw new RuntimeException(e.toString());
        }finally {
            httpclient.getConnectionManager().closeExpiredConnections();
            httpclient.getConnectionManager().closeIdleConnections(0, TimeUnit.NANOSECONDS);
        }
        log.info("返回response content:" + returnMsg);
        return returnMsg;
    }
}

