package main.java.com.gw.common.framework.util;

import lombok.extern.slf4j.Slf4j;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.lang3.StringUtils;

import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Slf4j
@SuppressWarnings("unchecked")
public class JsonUtil {

    public static JSONObject message(String message, boolean success) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("success", success);
        map.put("message", message);
        return JSONObject.fromObject(map);
    }

    public static JSONObject generate(List list) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("totalProperty", list.size());
        map.put("root", list);
        return JSONObject.fromObject(map);
    }

    public static JSONObject javabean2json(Object object, String message, boolean success) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("success", success);
        map.put("message", message);
        map.put("data", object);
        return JSONObject.fromObject(map);
    }

    public static JSONObject objectcollect2json(List list, String total) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("totalProperty", total);
        map.put("root", list);
        return JSONObject.fromObject(map);
    }

    public static JSONArray getJSONArrayFormString(String str) {
        if (str == null || str.trim().length() == 0) {
            return null;
        }
        JSONArray jsonArray = null;
        try {
            jsonArray = JSONArray.fromObject(str);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return jsonArray;
    }

    public static JSONObject StringToJSONOBject(String str) {
        if (str == null || str.trim().length() == 0) {
            return null;
        }
        JSONObject jsonObject = null;
        try {
            jsonObject = JSONObject.fromObject(str);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return jsonObject;
    }

    /**
     * @param object 任意对象
     * @return java.lang.String
     */
    public static String objectToJson(Object object) {
        StringBuilder json = new StringBuilder();
        if (object == null) {
            json.append("\"\"");
        } else if (object instanceof String || object instanceof Integer) {
            json.append("\"").append((String) object).append("\"");
        } else {
            json.append(beanToJson(object));
        }
        return json.toString();
    }

    /**
     * 功能描述:传入任意一个 javabean 对象生成一个指定规格的字符串
     *
     * @param bean对象
     * @return String
     */
    public static String beanToJson(Object bean) {
        StringBuilder json = new StringBuilder();
        json.append("{");
        PropertyDescriptor[] props = null;
        try {
            props = Introspector.getBeanInfo(bean.getClass(), Object.class).getPropertyDescriptors();
        } catch (IntrospectionException e) {
            log.error("JsonUtil beanToJson IntrospectionException error" + e.getMessage(), e);
        }
        if (props != null) {
            for (int i = 0; i < props.length; i++) {
                try {
                    String name = objectToJson(props[i].getName());
                    String value = objectToJson(props[i].getReadMethod().invoke(bean));
                    json.append(name);
                    json.append(":");
                    json.append(value);
                    json.append(",");
                } catch (Exception e) {
                    log.error("JsonUtil beanToJson Exception error" + e.getMessage(), e);
                }
            }
            json.setCharAt(json.length() - 1, '}');
        } else {
            json.append("}");
        }
        return json.toString();
    }

    /**
     * 功能描述:通过传入一个列表对象,调用指定方法将列表中的数据生成一个JSON规格指定字符串
     *
     * @param list列表对象
     * @return java.lang.String
     */
    public static String listToJson(List<?> list) {
        StringBuilder json = new StringBuilder();
        json.append("[");
        if (list != null && list.size() > 0) {
            for (Object obj : list) {
                json.append(objectToJson(obj));
                json.append(",");
            }
            json.setCharAt(json.length() - 1, ']');
        } else {
            json.append("]");
        }
        return json.toString();
    }

    /**
     * @param <T>
     * @param json
     * @param clazz
     * @param subClasses map<String(return‚msgDate), Class(msgDate)>
     * @return
     * @throws Exception
     * @Data Apr 19, 2013 1:29:44 PM
     */
    public static <T> T jsonToBean_nest(String json, Class<T> clazz, Map<String, Class> subClasses) throws Exception {
        JSONObject jsonObj = StringToJSONOBject(json);

        if (jsonObj == null)
            return null;

        T o = (T) Class.forName(clazz.getName()).newInstance();

        Field[] fields = clazz.getDeclaredFields();
        for (Field field : fields) {
            String fieldName = field.getName();
            Object fieldValue = null;
            Method m = null;
            try {
                String methodName = "set" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1, fieldName.length());
                m = clazz.getMethod(methodName, field.getType());
            } catch (Exception e) {
                // e.printStackTrace();
                continue;
            }
            if (field.getType() == Integer.class) {
                if (StringUtils.isEmpty(jsonObj.getString(fieldName))) {
                    fieldValue = 0;
                } else {
                    fieldValue = jsonObj.getInt(fieldName);
                }
            } else if (field.getType() == Float.class) {
                fieldValue = jsonObj.getDouble(fieldName);
            } else if (field.getType() == Double.class) {
                fieldValue = jsonObj.getDouble(fieldName);
            } else if (field.getType() == Short.class) {
                fieldValue = jsonObj.getInt(fieldName);
            } else if (field.getType() == String.class) {
                fieldValue = jsonObj.getString(fieldName);
            } else if (field.getType() == Character.class) {
                fieldValue = jsonObj.getString(fieldName);
            } else if (field.getType() == Long.class) {
                fieldValue = jsonObj.getLong(fieldName);
            } else if (field.getType() == Boolean.class) {
                fieldValue = jsonObj.getBoolean(fieldName);
            } else if (field.getType() == Byte.class) {
                fieldValue = jsonObj.getString(fieldName);
            } else if (field.getType().isArray()) {
                fieldValue = getJsonArray(jsonObj.getJSONArray(fieldName), subClasses.get(fieldName), subClasses);
            } else {
                fieldValue = jsonToBean_nest(jsonObj.getString(fieldName), subClasses.get(fieldName), subClasses);
            }
            m.invoke(o, fieldValue);
        }
        return o;

    }

    /**
     * 待扩展
     *
     * @param jsonArray
     * @param clazz
     * @return
     * @throws Exception
     */
    private static Object getJsonArray(JSONArray jsonArray, Class<?> clazz, Map<String, Class> subClasses) throws Exception {
        if (jsonArray == null)
            return null;
        Object o = Class.forName(clazz.getName());

        if (o instanceof List) {
            List list = (List) o;
            /*
             * for(Iterator ite = jsonArray.iterator();ite.hasNext();){ JSONObject jsonObj1 =
             * (JSONObject) ite.next(); }
             */
        } else if (o instanceof Set) {

        } else if (o instanceof HashMap) {

        } else if (o instanceof LinkedHashMap) {

        } else if (o instanceof Object[]) {

        }
        return o;
    }


    /**
     * Bean 2 JSON String
     *
     * @param obj
     * @return
     */
    public static String toJSONString(Object obj) {
        return JSONObject.fromObject(obj).toString();
    }
}
