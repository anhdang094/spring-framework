package main.java.com.gw.common.framework.util;

import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sun.misc.BASE64Encoder;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

public class LCSignature {

    private static final Logger logger = LoggerFactory.getLogger(LCSignature.class);
    private static final String INIT_VECTOR = "RandomInitVector";
    private static final String ALGORITHM = "AES";

    /** 以下都是需要替换的参数 */
    private static final String AGENT_CODE = "SU107"; // AgentCode was provided
    private static final String TIMESTAMP = "2019-07-23T06:27:21";
    private static final String AGENT_KEY = "b4dc8714-5d67-4798-a4eb-9478227c72ad"; // Agent key was provided
    private static final String AES_KEY = "rlpc3VsNcxXmrBXZ"; // AESkey was provided
    // `Timestamp` get from request body.
    // Signature that you need generated.
    // [We created it from our system. You need to create the samesignature for comparison.]
    private static final String SIGNATURE_VERIFY = "B9Bp7loOzhvgHLLYg71A0v5yXKXTik87AjKCD8ZQSSVobuVHBkAVk8gxfwmWRglLCHm+CNaxnCa1neINbhRYMQ==";

    public static void main(String[] args) {
        String token = encode(AGENT_CODE, TIMESTAMP, AGENT_KEY, AES_KEY);
        if (SIGNATURE_VERIFY.equals(token)) {
            System.out.println("Your signature was verified.");
            String tokenDecode = decode(token, AES_KEY);
            System.out.println(tokenDecode);
            String[] tmp = tokenDecode.split("\\|");
            System.out.println("UserCode: " + tmp[0]);
            System.out.println("Timestamp: " + tmp[1]);
        } else {
            logger.info("This is not your signature.");
        }
    }

    public static String encode(String agentCode, String timestamp, String agentKey, String aesKey) {
        String hashToken = DigestUtils.md5Hex(agentCode + timestamp + agentKey);
        String token = String.format("%s|%s|%s", agentCode, timestamp, hashToken);
        return encryptAES(token, aesKey);
    }

    public static String decode(String token, String aesKey) {
        return decryptAES(token, aesKey);
    }

    /**
     * encrypt AES
     */
    private static String encryptAES(String token, String aesKey) {
        try {
            SecretKeySpec secretKeySpec = new SecretKeySpec(aesKey.getBytes(), ALGORITHM);
            IvParameterSpec iv = new IvParameterSpec(INIT_VECTOR.getBytes("UTF-8"));
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
            cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec, iv);
            byte[] encrypted = cipher.doFinal(token.getBytes());
            return Base64.getEncoder().encodeToString(encrypted);
        } catch (UnsupportedEncodingException |
                InvalidAlgorithmParameterException |
                InvalidKeyException | NoSuchAlgorithmException |
                BadPaddingException |
                IllegalBlockSizeException | NoSuchPaddingException ex) {
            logger.error("An exception occurred when encrypt key: {}, plain text: {}, exception {}", aesKey, token, ex);
        }
        return null;
    }

    private static String decryptAES(String encryptedText, String aesKey) {
        try {
            SecretKeySpec secretKeySpec = new SecretKeySpec(aesKey.getBytes(), ALGORITHM);
            IvParameterSpec iv = new IvParameterSpec(INIT_VECTOR.getBytes("UTF-8"));
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
            cipher.init(Cipher.DECRYPT_MODE, secretKeySpec, iv);
            byte[] original = cipher.doFinal(Base64.getDecoder().decode(encryptedText));
            return new String(original);
        } catch (UnsupportedEncodingException |
                InvalidAlgorithmParameterException | InvalidKeyException | NoSuchAlgorithmException | BadPaddingException |
                IllegalBlockSizeException | NoSuchPaddingException ex) {
            logger.error("An exception occurred when decrypt key: {}, encryptedText:{}, exception {}", aesKey, encryptedText, ex);
        }
        return null;
    }


    /**
     * AES加密
     * @param
     * @return
     * @throws Exception
     */
    public static String AESEncrypt(String value,String key) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        byte[] raw = key.getBytes("UTF-8");
        SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
        cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
        byte[] encrypted = cipher.doFinal(value.getBytes("UTF-8"));
        String base64 = new BASE64Encoder().encode(encrypted);// 此处使用BASE64做转码
        return URLEncoder.encode(base64, "UTF-8");//URL加密
    }

    /**
     * MD5 32位加密
     * @param sourceStr
     * @return
     */
    public static String MD5(String sourceStr) {
        String result = "";
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(sourceStr.getBytes("UTF-8"));
            byte b[] = md.digest();
            int i;
            StringBuffer buf = new StringBuffer("");
            for (int offset = 0; offset < b.length; offset++) {
                i = b[offset];
                if (i < 0)
                    i += 256;
                if (i < 16)
                    buf.append("0");
                buf.append(Integer.toHexString(i));
            }
            result = buf.toString();

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return result;
    }



}
