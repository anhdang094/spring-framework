package main.java.com.gw.common.framework.util;

import java.time.*;
import java.util.Date;

/**
 * LocalDate与Date的转换（支持UTC国际时间）
 * @author eagle
 */
public class LocalDateUtil {
    /**
     * LocalDate转Date
     * @param localDate
     * @return
     */
    public static Date localDate2Date(LocalDate localDate) {
        if (null == localDate) {
            return null;
        }
        ZonedDateTime zonedDateTime = localDate.atStartOfDay(ZoneId.systemDefault());
        return Date.from(zonedDateTime.toInstant());

    }

    /**
     * LocalDate转Date
     * @param localDate
     * @param zoneId
     * @return
     */
    public static Date localDate2Date(LocalDate localDate,ZoneId zoneId) {
        if (null == localDate) {
            return null;
        }
        ZonedDateTime zonedDateTime = localDate.atStartOfDay(zoneId);
        return Date.from(zonedDateTime.toInstant());

    }

    /**
     * Date转LocalDate
     * @param date
     */
    public static LocalDate date2LocalDate(Date date) {
        if (null == date) {
            return null;
        }
        return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

    }

    /**
     * Date转LocalDate
     * @param date
     * @param zoneId
     * @return
     */
    public static LocalDate date2LocalDate(Date date,ZoneId zoneId) {
        if (null == date) {
            return null;
        }
        return date.toInstant().atZone(zoneId).toLocalDate();
    }

    /**
     * @param date
     * @return
     */
    public static LocalDateTime date2LocalDateTime(Date date){
        Instant instant = date.toInstant();
        ZoneId zoneId = ZoneId.systemDefault();
        LocalDateTime localDateTime = instant.atZone(zoneId).toLocalDateTime();
        return localDateTime;
    }

    /**
     * ZoneId zoneId
     * @param date
     * @param zoneId
     * @return
     */
    public static LocalDateTime date2LocalDateTime(Date date,ZoneId zoneId){
        Instant instant = date.toInstant();
        LocalDateTime localDateTime = instant.atZone(zoneId).toLocalDateTime();
        return localDateTime;
    }

    /**
     * LocalDateTime转换为Date
     * @param localDateTime
     */
    public static Date localDateTime2Date( LocalDateTime localDateTime){
        ZoneId zoneId = ZoneId.systemDefault();
        ZonedDateTime zdt = localDateTime.atZone(zoneId);
        Date date = Date.from(zdt.toInstant());
        return date;
    }

    /**
     * LocalDateTime转换为Date
     * @param localDateTime
     * @param zoneId
     * @return
     */
    public static Date localDateTime2Date( LocalDateTime localDateTime,ZoneId zoneId){
        ZonedDateTime zdt = localDateTime.atZone(zoneId);
        Date date = Date.from(zdt.toInstant());
        return date;
    }

}
