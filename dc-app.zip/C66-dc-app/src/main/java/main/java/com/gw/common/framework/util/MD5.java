package main.java.com.gw.common.framework.util;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;

import java.math.BigInteger;
import java.security.MessageDigest;

//import org.springframework.security.providers.encoding.Md5PasswordEncoder;

/**
 * @author alex.l
 */
@Slf4j
public class MD5 {

    /**
     * Verify string with MD5
     *
     * @param srcStr
     * @param targetStr
     * @return boolean
     */
    public static boolean doVerify(String srcStr, String targetStr) {
        try {
            MessageDigest MD5 = MessageDigest.getInstance(UtilConstants.MD5);
            MD5.update(srcStr.getBytes());
            String MD5Str = new BigInteger(1, MD5.digest()).toString(16);
            if (MD5Str.equals(targetStr)) {
                return true;
            }

        } catch (Exception e) {
            log.error("MD5 doVerify error:" + e.getMessage(), e);
        }
        return false;

    }

    /**
     * Encrypt string with MD5.
     *
     * @param srcStr
     * @return string
     * @throws Exception
     */
    public static String getEncrypt(String srcStr) throws Exception {
        try {
            MessageDigest MD5 = MessageDigest.getInstance(UtilConstants.MD5);
            MD5.update(srcStr.getBytes());
            String MD5Str = new BigInteger(1, MD5.digest()).toString(16);
            return MD5Str;
        } catch (Exception e) {
            log.error("MD5 getEncrypt error:" + e.getMessage(), e);
            throw new Exception("Encryption password failure!");
        }
    }

    private final static String[] hexDigits = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f"};

    /**
     * 转换字节数组为16进制字串
     *
     * @param b 字节数组
     * @return 16进制字串
     */
    public static String byteArrayToHexString(byte[] b) {
        StringBuffer resultSb = new StringBuffer();
        for (int i = 0; i < b.length; i++) {
            resultSb.append(byteToHexString(b[i]));
        }
        return resultSb.toString();
    }

    private static String byteToHexString(byte b) {
        int n = b;
        if (n < 0)
            n = 256 + n;
        int d1 = n / 16;
        int d2 = n % 16;
        return hexDigits[d1] + hexDigits[d2];
    }

    public static String MD5Encode(String origin) {
        String resultString = null;
        try {
            resultString = new String(origin);
            MessageDigest md = MessageDigest.getInstance("MD5");
            resultString = byteArrayToHexString(md.digest(resultString.getBytes()));
        } catch (Exception ex) {
            log.error("MD5 MD5Encode error:" + ex.getMessage(), ex);
        }
        return resultString;
    }

    public static String md5Encoding(String origin) {
        String resultString = null;
        try {
            resultString = new String(origin);
            MessageDigest md = MessageDigest.getInstance("MD5");
            resultString = byteArrayToHexString(md.digest(resultString.getBytes("UTF-8")));
        } catch (Exception ex) {
            log.error("MD5 MD5Encode error:" + ex.getMessage(), ex);
        }
        return resultString;
    }

    public static String SHA1Encode(String origin) {
        String resultString = null;
        try {
            resultString = new String(origin);
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            resultString = byteArrayToHexString(md.digest(resultString.getBytes()));
        } catch (Exception ex) {
            log.error("MD5 SHA1Encode error:" + ex.getMessage(), ex);
        }
        return resultString;
    }

    // for test
    public static void main(String args[]) {
        try {
            String loginname = "dlil888", website = "hlg6", KeyB = "OupA1", md5str = "20130620";
            String result = MD5Encode("123");
            System.out.println("Result=" + result);

            String result2 = md5Encoding("123");
            System.out.println("Result=" + result2);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
