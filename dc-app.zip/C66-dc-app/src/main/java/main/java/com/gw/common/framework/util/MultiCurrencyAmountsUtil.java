package main.java.com.gw.common.framework.util;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.apollo.MultipleCurrencyConfig;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWCustomerCurrencyException;
import main.java.com.gw.common.system.entity.SBTCreditEntity;
import main.java.com.gw.common.system.entity.SBTOrderEntity;
import main.java.com.gw.common.system.props.CustomerPropertyholder;
import main.java.com.gw.datacenter.accounttransfer.entity.AccountTransferEntity;
import main.java.com.gw.datacenter.allocation.entity.ErrorMatchLogEntity;
import main.java.com.gw.datacenter.customerInfo.dao.CustomerInfoDao;
import main.java.com.gw.datacenter.customerInfo.entity.CustomerInfoEntity;
import main.java.com.gw.datacenter.order.entity.OrderAGQJExceptionor;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.collections.map.LRUMap;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
public class MultiCurrencyAmountsUtil {


    public static ConcurrentHashMap custInfoMap = new ConcurrentHashMap(10000);

    private static CustomerInfoDao customerInfoDao = (CustomerInfoDao) SpringContext.getApplicationContext().getBean("customerInfoDao");


    /**
     * 注单表 金额转换方法
     * 判断该产品是否支持多币种，支持的话 再判断是否配置了汇率，没有配置汇率则默认CNY
     * 检查会员币种类型，若是MBTC，则要做金额转换
     * */
    public static void resetOrderAmounts(OrderEntity entity, Object taskId)throws  Exception{
            try{
                // 判断该产品是否支持多币种，支持的话 再判断是否配置了汇率，没有配置汇率则默认CNY
                if(null==entity){
                    log.info("注单  多币种金额转换error, orderEntity为空");
                    return;
                }

                String multiCurrencySwith = CustomerPropertyholder.getProperty("multiplecurrency.switch.on");
                if("false".equalsIgnoreCase(multiCurrencySwith)){
                    log.info(" 多币种转换开关未开启！");
                    return;
                }
                //判断厅是否能参与转换
                String multiplecurrencyPlatform = CustomerPropertyholder.getProperty("multiplecurrency.platform");
                if(!"all".equals(multiplecurrencyPlatform)) {
                    if(!ToolUtil.isContains(multiplecurrencyPlatform,entity.getPlatId())) {
                        log.info("注单平台不参与多币种转换！");
                        return;
                    }
                }
                //如果是USD的注单 一定是usdt的账户下单的,转化完事
                /*if(StringUtils.equalsIgnoreCase("USD",entity.getCurrency())) {
                    entity.setCurrency(UtilConstants.CURRENCY_USDT);
                }*/
                CustomerInfoEntity customerInfo = checkCustInfoCache(entity.getProductId(),entity.getLoginName());
                if(null==customerInfo){
                    log.error("{}，{}，注单 {} 多币种金额转换error,未找到用户的币种信息",entity.getLoginName(),entity.getProductId(),entity.getBillNo());
//                    throw  new GWCustomerCurrencyException(entity.getLoginName() + ", " + entity.getProductId() + ",注单" + entity.getBillNo() +" 未找到用户的币种信息 ");
                    return;
                }
                String customerCurrency  = customerInfo.getCurrency();
                if(StringUtils.isAnyBlank(customerCurrency)){
                    log.error("{}，{}，注单 {} 多币种金额转换error,用户的币种currency为空",entity.getLoginName(),entity.getProductId(),entity.getBillNo());
                    throw new GWCustomerCurrencyException(entity.getLoginName()+" 用户的币种currency为空");
                }
                if(customerCurrency.equals(entity.getCurrency())) {
                    log.info("用户币种与注单币种一致，无需参与转换:{}->{}",entity.getLoginName(),customerCurrency);
                    return;
                }
                //如果用户币种和注单币种不一致
                /*if(!customerCurrency.equalsIgnoreCase(entity.getCurrency()) && !UtilConstants.CNY.equalsIgnoreCase(entity.getCurrency())) {
                    throw new GWCustomerCurrencyException("用户币种和注单币种不一致,且用户币种不为CNY,"+entity.getLoginName()+"用户币种"
                            +customerCurrency+"注单币种"+entity.getCurrency()+",billno: "+entity.getBillNo());
                }*/


                if(StringUtils.isAnyBlank(entity.getProductId(),entity.getLoginName())){
                    log.info("注单  多币种金额转换error,产品{} loginname {} 参数异常",entity.getProductId(),entity.getLoginName());
                    return;
                }


                String loadCurrencyRate= MultipleCurrencyConfig.getCurrnecyRate(entity.getProductId(),customerCurrency,entity.getCurrency());
                // 验证是否有汇率配置 没有汇率配置不进行任何处理  汇率必须大于0
                //确定要转换金额  设置注单的currency为新的currency
                if(StringUtils.isNotBlank(loadCurrencyRate) && new BigDecimal(loadCurrencyRate).compareTo(new BigDecimal(0))>0){
                    entity.setCurrency(customerCurrency);
                    BigDecimal rate = new BigDecimal(loadCurrencyRate);
                    if(null != entity.getPreviosAmount()){
                        entity.setPreviosAmount(entity.getPreviosAmount().divide(rate,6,BigDecimal.ROUND_DOWN));
                    }
                    if(null != entity.getAccount()){
                        entity.setAccount(entity.getAccount().divide(rate,6,BigDecimal.ROUND_DOWN));
                    }
                    if(null != entity.getValidAccount()){
                        entity.setValidAccount(entity.getValidAccount().divide(rate,6,BigDecimal.ROUND_DOWN));
                    }
                    if(null != entity.getCusAccount()){
                        entity.setCusAccount(entity.getCusAccount().divide(rate,6,BigDecimal.ROUND_DOWN));
                    }
                    if(null != entity.getBonusAmount()){
                        entity.setBonusAmount(entity.getBonusAmount().divide(rate,6,BigDecimal.ROUND_DOWN));
                    }
                    if(null != entity.getRemainAmount()){
                        entity.setRemainAmount(entity.getRemainAmount().divide(rate,6,BigDecimal.ROUND_DOWN));
                    }
                }else {
                    log.error("-产品-{}-币种-{}-to-{}-的汇率未配置", entity.getProductId(),customerCurrency,entity.getCurrency() );
                }
                //验证用户币种和注单币种是否一致
                if(!customerCurrency.equalsIgnoreCase(entity.getCurrency())) {
                    throw new GWCustomerCurrencyException(entity.getLoginName()+"用户币种不统一,用户币种"+customerCurrency+"注单币种"+entity.getCurrency()+",billno: "+entity.getBillNo());
                }
            }catch (Exception e){
                if (Objects.equals(entity.getPlatId(), "031")){
                    insertErrorOrderMatchLog(entity, taskId.toString(), e);
                    return;
                }
                log.error(" {}，{}，注单 {} 多币种金额转换出现异常",entity.getLoginName(),entity.getProductId(),entity.getBillNo(),e);
                throw e;
            }

    }

    private static void insertErrorOrderMatchLog (OrderEntity entity, String taskId, Exception e){
        ErrorMatchLogEntity errorMatchLogEntity = new ErrorMatchLogEntity();
        errorMatchLogEntity.setProductId(entity.getProductId());
        errorMatchLogEntity.setPlatform(entity.getPlatId());
        errorMatchLogEntity.setLoginName(entity.getLoginName());
        errorMatchLogEntity.setTaskId(taskId);
        errorMatchLogEntity.setRemark(e.getMessage());
        errorMatchLogEntity.setCreateTime(new Date());
        customerInfoDao.insertErrorMatchLog(errorMatchLogEntity);
    }

    /**
     * AGQJ注单篡改记录表 金额转换方法
     * 判断该产品是否支持多币种，支持的话 再判断是否配置了汇率，没有配置汇率则默认CNY
     * 检查会员币种类型，若是MBTC，则要做金额转换
     * 后续增加对A02  C07 的币种判断
     * 目前只过滤A03产品
     * ### 国际站 废弃的代码
     * ### 国际站 废弃的代码
     * */
    public static void resetAGQJExceptionorAmounts(OrderAGQJExceptionor entity)throws  Exception{

        try{
            String multiCurrencySwith = CustomerPropertyholder.getProperty("multiplecurrency.switch.on");
            if("false".equalsIgnoreCase(multiCurrencySwith)){
                log.info(" A03多币种转换开关未开启！");
                return;
            }
            // 判断该产品是否支持多币种，支持的话 再判断是否配置了汇率，没有配置汇率则默认CNY
            if(null==entity){
                return;
            }
            if(StringUtils.isAnyBlank(entity.getProductId(),entity.getLoginName())){
                return;
            }
            // 目前限定A03产品 ，其他产品不进行任何处理   edited by lily.y  07/24/2019
            if("A03".equalsIgnoreCase(entity.getProductId())){
            // 检查会员币种类型，若是多币种，则要做金额转换   放在缓存map里
//                if(!isMultipleCurrencyUser(entity.getLoginName())){
//                    log.info("{}，{}，注单 {} 多币种金额不做转换,根据用户名称判断用户币种默认CNY",entity.getLoginName(),entity.getProductId(),entity.getBillNo());
//                    return;
//                }
//                CustomerInfoEntity customerInfo = checkCustInfoCache(entity.getProductId(),entity.getLoginName());
//                if(null==customerInfo){
//                    log.error("{}，{}，注单 {} 多币种金额转换error,未找到用户的币种信息",entity.getLoginName(),entity.getProductId(),entity.getBillNo());
////                    throw  new GWCustomerCurrencyException(entity.getLoginName()+" 未找到用户的币种信息 ");
//                    return;
//                }
//                if(StringUtils.isNotBlank(customerInfo.getRemark()) && "0".equals(customerInfo.getRemark().trim())){//试玩账户没有多币种，直接return
//                    log.info("{}，{}，注单 {} 多币种金额不做转换,用户类型{}，试玩用户不处理",entity.getLoginName(),entity.getProductId(),entity.getBillNo(),customerInfo.getRemark());
//                    return;
//                }
//                String customerCurrency  = customerInfo.getCurrency();
//                if(StringUtils.isAnyBlank(customerCurrency)){
//                    log.error("{}，{}，注单 {} 多币种金额转换error,用户的币种currency为空",entity.getLoginName(),entity.getProductId(),entity.getBillNo());
//                    throw new GWCustomerCurrencyException(entity.getLoginName()+" 用户的币种currency为空");
//                }
//
//
//                String loadCurrnecyRate=MultipleCurrencyConfig.getCurrnecyRate(entity.getProductId(),customerCurrency,entity.);
//                // 验证是否有汇率配置 没有汇率配置不进行任何处理
//                //确定要转换金额  设置注单的currency为新的currency
//                if(StringUtils.isNotBlank(loadCurrnecyRate) ){ //判断各金额原来是否有值
//
//                    BigDecimal rate = new BigDecimal(loadCurrnecyRate);
//                    if(null != entity.getOrigAccout()){
//                        entity.setOrigAccout(entity.getOrigAccout().divide(rate,6,BigDecimal.ROUND_DOWN));
//                    }
//                    if(null != entity.getRecAccount()){
//                        entity.setRecAccount(entity.getRecAccount().divide(rate,6,BigDecimal.ROUND_DOWN));
//                    }
//                }else {
//
//                }
            }
        }catch (Exception e){
            log.error(" {}，{}，注单 {} 多币种金额转换出现异常",entity.getLoginName(),entity.getProductId(),entity.getBillNo(),e);
            throw e;
        }
    }


    /**
     * for SBTCreditEntity   TRANSFER_ACCOUNT_SBT
     * SBT额度记录表 金额转换方法   不能抛异常 因为不能影响主业务
     * 判断该产品是否支持多币种，支持的话 再判断是否配置了汇率，没有配置汇率则默认CNY
     * 检查会员币种类型，若是MBTC，则要做金额转换
     * 后续增加对A02  C07 的币种判断
     * 目前只过滤A03产品
     * */
    public static void resetSBTCreditAmounts(SBTCreditEntity entity){
        try{

                // 判断该产品是否支持多币种，支持的话 再判断是否配置了汇率，没有配置汇率则默认CNY
                if(null==entity){
                    return;
                }
                String multiCurrencySwith = CustomerPropertyholder.getProperty("multiplecurrency.switch.on");
                if("false".equalsIgnoreCase(multiCurrencySwith)){
                    log.info(" A03多币种转换开关未开启！");
                    return;
                }
                if(StringUtils.isAnyBlank(entity.getProductId(),entity.getLoginName())){
                    return;
                }

                if(checkTryUser(entity.getLoginName())){
                    log.info("试玩账户不做转化！");
                    return;
                }
                //如果是USD的注单 一定是usdt的账户下单的,转化完事
                //if(StringUtils.equalsIgnoreCase("USD",entity.getCurrency())) {
                //    entity.setCurrency(UtilConstants.CURRENCY_USDT);
                //}

                // 检查会员币种类型，若是多币种，则要做金额转换   放在缓存map里
                CustomerInfoEntity customerInfo = checkCustInfoCache(entity.getProductId(),entity.getLoginName());
                if(null==customerInfo){
                    log.error("{}，{}，sbt额度记录 {} 多币种金额转换error,未找到用户的币种信息",entity.getLoginName(),entity.getProductId(),entity.getTransId());
//                    throw  new GWCustomerCurrencyException(entity.getLoginName()+" 未找到用户的币种信息 ");
                    return;
                }

                String customerCurrency  = customerInfo.getCurrency();
                if(StringUtils.isAnyBlank(customerCurrency)){
                    log.error("{}，{}，sbt额度记录 {} 多币种金额转换error,用户的币种currency为空",entity.getLoginName(),entity.getProductId(),entity.getTransId());
                    throw new GWCustomerCurrencyException(entity.getLoginName()+" 用户的币种currency为空");
                }
                if(customerCurrency.equals(entity.getCurrency())) {
                    log.info("用户币种与注单币种一致，无需参与转换:{}->{}",entity.getLoginName(),customerCurrency);
                    return;
                }
                //如果用户币种和注单币种不一致
                //if(!customerCurrency.equalsIgnoreCase(entity.getCurrency()) && !UtilConstants.CNY.equalsIgnoreCase(entity.getCurrency())) {
                //    throw new GWCustomerCurrencyException("用户币种和注单币种不一致,且用户币种不为CNY "+entity.getLoginName()
                //            +"用户币种"+customerCurrency+"注单币种"+entity.getCurrency()+",TransId:"+entity.getTransId());
                //}


                String loadCurrencyRate=MultipleCurrencyConfig.getCurrnecyRate(entity.getProductId(),customerCurrency,entity.getCurrency());
                // 验证是否有汇率配置 没有汇率配置不进行任何处理
                //确定要转换金额  设置注单的currency为新的currency
                if(StringUtils.isNotBlank(loadCurrencyRate)   && new BigDecimal(loadCurrencyRate).compareTo(new BigDecimal(0))>0){
                    entity.setCurrency(customerCurrency);
                    BigDecimal rate = new BigDecimal(loadCurrencyRate);
                    if(null != entity.getCurrentBalance()){
                        entity.setCurrentBalance(entity.getCurrentBalance().divide(rate,6,BigDecimal.ROUND_DOWN));
                    }
                    if(null != entity.getPreviousBalance()){
                        entity.setPreviousBalance(entity.getPreviousBalance().divide(rate,6,BigDecimal.ROUND_DOWN));
                    }
                    if(null != entity.getTransferAmount()){
                        entity.setTransferAmount(entity.getTransferAmount().divide(rate,6,BigDecimal.ROUND_DOWN));
                    }

                }else {
                    log.error("-产品-{}-币种-{}-to-{}-的汇率未配置", entity.getProductId(),customerCurrency,entity.getCurrency() );
                }
                //验证用户币种和注单币种是否一致
                if(!customerCurrency.equalsIgnoreCase(entity.getCurrency())) {
                    throw new GWCustomerCurrencyException(entity.getLoginName()+"用户币种不统一,用户币种"+customerCurrency+"注单币种"+entity.getCurrency()+",TransId:"+entity.getTransId());
                }

        }catch (Exception e){
            log.error("resetOrderSummaryAmounts  {}，{}，平台 {} 多币种金额转换出现异常",entity.getLoginName(),entity.getProductId(),entity.getPlatformId(),e);
        }
    }

    /**
     * for SBTOrderEntity   ORDER_SBT
     * SBT注单记录表 金额转换方法   不能抛异常 因为不能影响主业务
     * 判断该产品是否支持多币种，支持的话 再判断是否配置了汇率，没有配置汇率则默认CNY
     * 检查会员币种类型，若是MBTC，则要做金额转换
     * 后续增加对A02  C07 的币种判断
     * 目前只过滤A03产品
     * */
    public static void resetSBTOrderAmounts(SBTOrderEntity entity){

        try{
                if(null==entity){
                    log.info("注单多币种金额转换error, orderEntity为空");
                    return;
                }

                String multiCurrencySwith = CustomerPropertyholder.getProperty("multiplecurrency.switch.on");
                if("false".equalsIgnoreCase(multiCurrencySwith)){
                    log.info("多币种转换开关未开启！");
                    return;
                }
                //判断厅是否能参与转换
                String multiplecurrencyPlatform = CustomerPropertyholder.getProperty("multiplecurrency.platform");
                log.info("multiplecurrencyPlatform value {}",multiplecurrencyPlatform);
                if(!"all".equals(multiplecurrencyPlatform)) {
                    if(!ToolUtil.isContains(multiplecurrencyPlatform,entity.getPlatformId())) {
                        log.info("注单平台不参与多币种转换！");
                        return;
                    }
                }

                //if(StringUtils.equalsIgnoreCase("USD",entity.getCurrency())) {
                 //   entity.setCurrency("USDT");
                //}


                if(StringUtils.isAnyBlank(entity.getProductId(),entity.getLoginName())){
                    log.info("注单多币种金额转换error,产品{} loginname {} 参数异常",entity.getProductId(),entity.getLoginName());
                    return;
                }


                // 检查会员币种类型，若是多币种，则要做金额转换   放在缓存map里
                CustomerInfoEntity customerInfo = checkCustInfoCache(entity.getProductId(),entity.getLoginName());
                if(null==customerInfo){
                    log.error("{}，{}，注单 {} 多币种金额转换error,未找到用户的币种信息",entity.getLoginName(),entity.getProductId(),entity.getBetId());
//                    throw  new GWCustomerCurrencyException(entity.getLoginName()+" 未找到用户的币种信息 ");
                    return;
                }

                String customerCurrency  = customerInfo.getCurrency();
                if(StringUtils.isAnyBlank(customerCurrency)){
                    log.error("{}，{}，注单 {} 多币种金额转换error,用户的币种currency为空",entity.getLoginName(),entity.getProductId(),entity.getBetId());
                    throw new GWCustomerCurrencyException(entity.getLoginName()+" 用户的币种currency为空");
                }
                if(customerCurrency.equals(entity.getCurrency())) {
                    log.info("用户币种与注单币种一致，无需参与转换:{}->{}",entity.getLoginName(),customerCurrency);
                    return;
                }
                //如果用户币种和注单币种不一致
                //if(!customerCurrency.equalsIgnoreCase(entity.getCurrency()) && !UtilConstants.CNY.equalsIgnoreCase(entity.getCurrency())) {
                //    throw new GWCustomerCurrencyException("用户币种和注单币种不一致,且用户币种不为CNY "+entity.getLoginName()
                //            +"用户币种"+customerCurrency+"注单币种"+entity.getCurrency()+",BetId: "+entity.getBetId());
                //}

                String loadCurrnecyRate=MultipleCurrencyConfig.getCurrnecyRate(entity.getProductId(),customerCurrency,entity.getCurrency());
                // 验证是否有汇率配置 没有汇率配置不进行任何处理
                //确定要转换金额  设置注单的currency为新的currency
                if(StringUtils.isNotBlank(loadCurrnecyRate)    && new BigDecimal(loadCurrnecyRate).compareTo(new BigDecimal(0))>0){
                    entity.setCurrency(customerCurrency);
                    BigDecimal rate = new BigDecimal(loadCurrnecyRate);
                    if(null != entity.getPreviousBalance()){
                        entity.setPreviousBalance(entity.getPreviousBalance().divide(rate,6,BigDecimal.ROUND_DOWN));
                    }
                    if(null != entity.getAmount()){
                        entity.setAmount(entity.getAmount().divide(rate,6,BigDecimal.ROUND_DOWN));
                    }
                    if(null != entity.getValidAmount()){
                        entity.setValidAmount(entity.getValidAmount().divide(rate,6,BigDecimal.ROUND_DOWN));
                    }
                    if(null != entity.getRemainAmount()){
                        entity.setRemainAmount(entity.getRemainAmount().divide(rate,6,BigDecimal.ROUND_DOWN));
                    }
                    if(null != entity.getWinAmount()){
                        entity.setWinAmount(entity.getWinAmount().divide(rate,6,BigDecimal.ROUND_DOWN));
                    }
                    if(null!=entity.getPayOffAmount()){
                        entity.setPayOffAmount(entity.getPayOffAmount().divide(rate,6,BigDecimal.ROUND_DOWN));
                    }
                }else {
                    log.error("-产品-{}-币种-{}-to-{}-的汇率未配置", entity.getProductId(),customerCurrency,entity.getCurrency() );
                }
                //验证用户币种和注单币种是否一致
                if(!customerCurrency.equals(entity.getCurrency())) {
                    throw new GWCustomerCurrencyException(entity.getLoginName()+"用户币种不统一,用户币种"+customerCurrency+"注单币种"+entity.getCurrency()+",BetId: "+entity.getBetId());
                }

        }catch (Exception e){
            log.error("resetSBTOrderAmounts  {}，{}，平台 {} 多币种金额转换出现异常",entity.getLoginName(),entity.getProductId(),entity.getPlatformId(),e);
        }
    }

    /**
     * 转账表 金额转换方法
     * 判断该产品是否支持多币种，支持的话 再判断是否配置了汇率，没有配置汇率则默认CNY
     * 检查会员币种类型，若是MBTC，则要做金额转换
     * 后续增加对A02  C07 的币种判断
     * */
    public static void resetTransferOrderAmounts(AccountTransferEntity entity)throws  Exception{

        try{
                // 判断该产品是否支持多币种，支持的话 再判断是否配置了汇率，没有配置汇率则默认CNY
                if(null==entity){
                    return;
                }
                String multiCurrencySwith = CustomerPropertyholder.getProperty("multiplecurrency.switch.on");
                if("false".equalsIgnoreCase(multiCurrencySwith)){
                    log.info("多币种转换开关未开启！");
                    return;
                }

                if(checkTryUser(entity.getUserName())){
                    log.info("试玩账户不做转化！");
                    return;
                }


                //if(StringUtils.equalsIgnoreCase("USD",entity.getCurrency())) {
                //    entity.setCurrency("USDT");
                //}


                if(StringUtils.isAnyBlank(entity.getPlatformId(),entity.getProductId(),entity.getUserName())){
                    log.error("转账用户参数不全 {},{},{}",entity.getPlatformId(),entity.getProductId(),entity.getUserName());
                    return;
                }

                // 检查会员币种类型，若是多币种，则要做金额转换   放在缓存map里
                CustomerInfoEntity customerInfo = checkCustInfoCache(entity.getProductId(),entity.getUserName());
                if(null==customerInfo){
                    log.error("{}，{}，转账记录 {} 多币种金额转换error,未找到用户的币种信息",entity.getUserName(),entity.getProductId(),entity.getTransId());
//                    throw  new GWCustomerCurrencyException(entity.getUserName()+" 未找到用户的币种信息 ");
                    return;
                }

                String customerCurrency  = customerInfo.getCurrency();
                if(StringUtils.isAnyBlank(customerCurrency)){
                    log.error("{}，{}，转账记录 {} 多币种金额转换error,用户的币种currency为空",entity.getUserName(),entity.getProductId(),entity.getTransId());
                    throw new GWCustomerCurrencyException(entity.getUserName()+" 用户的币种currency为空");
                }
                if(customerCurrency.equals(entity.getCurrency())) {
                    log.info("用户币种与注单币种一致，无需参与转换:{}->{}",entity.getUserName(),customerCurrency);
                    return;
                }
                //如果用户币种和注单币种不一致
                //if(!customerCurrency.equalsIgnoreCase(entity.getCurrency()) && !UtilConstants.CNY.equalsIgnoreCase(entity.getCurrency())) {
                //    throw new GWCustomerCurrencyException("用户币种和注单币种不一致,且用户币种不为CNY "+entity.getUserName()
                //            +"用户币种"+customerCurrency+"注单币种"+entity.getCurrency()+",TransId: "+entity.getTransId());
                //}


                String loadCurrencyRate= MultipleCurrencyConfig.getCurrnecyRate(entity.getProductId(),customerCurrency,entity.getCurrency());
                // 验证是否有汇率配置 没有汇率配置不进行任何处理
                //确定要转换金额  设置注单的currency为新的currency
                if(StringUtils.isNotBlank(loadCurrencyRate)   && new BigDecimal(loadCurrencyRate).compareTo(new BigDecimal(0))>0){
                    entity.setCurrency(customerCurrency);
                    BigDecimal rate = new BigDecimal(loadCurrencyRate);
                    if(null != entity.getTransferAmount()){
                        entity.setTransferAmount(entity.getTransferAmount().divide(rate,6,BigDecimal.ROUND_DOWN));
                    }
                    if(null != entity.getCurrentAmount()){
                        entity.setCurrentAmount(entity.getCurrentAmount().divide(rate,6,BigDecimal.ROUND_DOWN));
                    }
                    if(null != entity.getPreviousAmount()){
                        entity.setPreviousAmount(entity.getPreviousAmount().divide(rate,6,BigDecimal.ROUND_DOWN));
                    }
                }else {
                    log.error("-产品-{}-币种-{}-to-{}-的汇率未配置", entity.getProductId(),customerCurrency,entity.getCurrency() );
                }
                //验证用户币种和注单币种是否一致
                if(!customerCurrency.equals(entity.getCurrency())) {
                    throw new GWCustomerCurrencyException(entity.getUserName()+"用户币种不统一,用户币种"+customerCurrency+"注单币种"+entity.getCurrency()+",TransId: "+entity.getTransId());
                }
        }catch (Exception e){
            log.error(" {}，{}，转账记录 {} 多币种金额转换出现异常",entity.getUserName(),entity.getProductId(),entity.getTransId(),e);
            throw e;
        }
    }

    private static boolean checkTryUser(String  userName) {
        String tryUserPirfex = CustomerPropertyholder.getProperty("try.user.prifex");

        if(!StringUtils.isBlank(tryUserPirfex)) {
            String[] pirfex = tryUserPirfex.split(",");
            for(String p : pirfex) {
                if(userName.startsWith(p)) {
                   return true;
                }
            }
        }
        return false;
    }

    private static CustomerInfoEntity checkCustInfoCache(String product,String loginName) {
        //check ele in cache;
        Object currency =  custInfoMap.get(product+"_"+loginName);
        //if exist ; return
        CustomerInfoEntity entity ;
        if(null!=currency){
            entity = new CustomerInfoEntity();
            entity.setProductId(product);
            entity.setLoginName(loginName);
            entity.setCurrency((String)currency);
            return entity;
        }else{  //query db
            entity =  new CustomerInfoEntity();
            entity.setProductId(product);
            entity.setLoginName(loginName);
            entity = customerInfoDao.queryCustomerInfo(entity);
            if(null!=entity){
                custInfoMap.put(entity.getProductId()+"_"+entity.getLoginName(),entity.getCurrency());  //玩家的币种是否会在ws修改 是否需要更新
            }
        }
        return entity;
    }

    protected  static boolean isMultipleCurrencyUser(String loginname){
        boolean isMCU = false;
        String mcsuffix =  CustomerPropertyholder.getProperty("multiplecurrency.loginname.suffix");
        if(StringUtils.isNotBlank(mcsuffix)){
            String[] mcs = mcsuffix.split(",");
            for(String s:mcs){
                if(loginname.endsWith(s)){
                    isMCU=true;
                    break;
                }
            }
        }
        return isMCU;
    }


}
