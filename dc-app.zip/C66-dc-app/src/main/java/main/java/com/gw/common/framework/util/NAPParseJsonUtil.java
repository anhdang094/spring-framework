package main.java.com.gw.common.framework.util;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.datacenter.accounttransfer.entity.AccountTransferEntity;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 解析NAP 注单，额度记录数据
 */
@Slf4j
public class NAPParseJsonUtil {

    // total records.总数
    private int totalNumber = 0;

    // error info.
    private String info = StringUtils.EMPTY;

    // 总页数
    private int totalPage = 0;

    private List<Object> list = new ArrayList<Object>();

    public int getTotalNumber() {
        return totalNumber;
    }

    public void setTotalNumber(int totalNumber) {
        this.totalNumber = totalNumber;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public List<Object> getList() {
        return list;
    }

    public void setList(List<Object> list) {
        this.list = list;
    }

    /**
     * NAP 抓取注单记录
     *
     * @param parameterMap
     * @return
     * @throws Exception
     */
    public static NAPParseJsonUtil parseNapOrder(Map<String, Object> parameterMap) throws Exception {
        log.info("+++++++_NAP,注单抓取+begin++parameterMap====" + parameterMap);
        NAPParseJsonUtil obj = new NAPParseJsonUtil();
        String url = (String) parameterMap.get(UtilConstants.ORDER_BASE_URL);
        String platformId = (String) parameterMap.get(UtilConstants.GLOBAL_PLATFORMID_KEY);
        String pid = (String) parameterMap.get(UtilConstants.ORDER_PRODUCT_ID);
        StringBuilder keyparams = new StringBuilder();
        StringBuilder params = new StringBuilder();
        keyparams.append("begintime").append("=").append((String) parameterMap.get(UtilConstants.GAME_RESULT_BEGIN_TIME)).append("&");
        keyparams.append("endtime").append("=").append((String) parameterMap.get(UtilConstants.GAME_RESULT_END_TIME)).append("&");
        keyparams.append("gameid=0").append("&");
        keyparams.append("gplatform").append("=").append((String) parameterMap.get("accountName")).append("&");
        keyparams.append("page").append("=").append((String) parameterMap.get(UtilConstants.ORDER_BBIN_PAGENUM)).append("&");
        keyparams.append("productid").append("=").append(pid).append("&");
        keyparams.append("size").append("=").append((String) parameterMap.get(UtilConstants.GAME_RESULT_PAGE_NUMBER)).append("&");

        params.append("begintime").append("=").append(URLEncoder.encode((String) parameterMap.get(UtilConstants.GAME_RESULT_BEGIN_TIME), "UTF-8")).append("&");
        params.append("endtime").append("=").append(URLEncoder.encode((String) parameterMap.get(UtilConstants.GAME_RESULT_END_TIME), "UTF-8")).append("&");
        params.append("gameid=0").append("&");
        params.append("gplatform").append("=").append((String) parameterMap.get("accountName")).append("&");
        params.append("page").append("=").append((String) parameterMap.get(UtilConstants.ORDER_BBIN_PAGENUM)).append("&");
        params.append("productid").append("=").append(pid).append("&");
        params.append("size").append("=").append((String) parameterMap.get(UtilConstants.GAME_RESULT_PAGE_NUMBER)).append("&");

        url = url + params.toString() + "key=" + DigestUtils.md5Hex((keyparams.toString() + "secretkey=" + ((String) parameterMap.get(UtilConstants.ORDER_BBIN_PASSWORD))));
        //    String result="{ \"responseaction\": \"GetGameOrders\", \"Results\": [ { \"username\": \"test5177\", \"creattime\": \"2018-08-09 19:24:58\", \"bet\": 100, \"result\": 95, \"tax\": 5, \"taxrate\": 0.05, \"gametype\": 1, \"round\": 133324, \"amountbefore\": 2100, \"amountaflter\": 2195, \"tradeno\": \"432323123\" } ], \"totalrecords\": 100, \"pagenum\": 10, \"status\": 1, \"errdesc\": null }";
        //     url= URLEncoder.encode(url,"UTF-8");

        String result = HttpUtil.resultHttpUrl(url);
        //"{\"responseaction\":\"GetGameOrders\",\"Results\":[{\"username\":\"y764581211\",\"creattime\":\"2018-09-20 11:57:03\",\"bet\":2.00,\"result\":-8.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1007519,\"amountbefore\":934.54,\"amountaflter\":926.54,\"tradeno\":\"931733_1007519\"},{\"username\":\"y17384972128\",\"creattime\":\"2018-09-20 11:56:55\",\"bet\":0.00,\"result\":0.19,\"tax\":0.01,\"taxrate\":0.05,\"gametype\":3,\"round\":1006661,\"amountbefore\":40.59,\"amountaflter\":40.78,\"tradeno\":\"931723_1006661\"},{\"username\":\"y462687646\",\"creattime\":\"2018-09-20 11:56:55\",\"bet\":2.10,\"result\":2.09,\"tax\":0.11,\"taxrate\":0.05,\"gametype\":1,\"round\":1118967,\"amountbefore\":44.97,\"amountaflter\":47.06,\"tradeno\":\"931721_1118967\"},{\"username\":\"ylxs2265\",\"creattime\":\"2018-09-20 11:56:50\",\"bet\":0.00,\"result\":-161.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":8,\"round\":1006597,\"amountbefore\":318.25,\"amountaflter\":157.25,\"tradeno\":\"931722_1006597\"},{\"username\":\"y764581211\",\"creattime\":\"2018-09-20 11:56:44\",\"bet\":4.00,\"result\":3.80,\"tax\":0.20,\"taxrate\":0.05,\"gametype\":3,\"round\":1007519,\"amountbefore\":930.74,\"amountaflter\":934.54,\"tradeno\":\"931715_1007519\"},{\"username\":\"yywx1992\",\"creattime\":\"2018-09-20 11:56:41\",\"bet\":1.00,\"result\":-8.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1010807,\"amountbefore\":148.23,\"amountaflter\":140.23,\"tradeno\":\"931716_1010807\"},{\"username\":\"ygta325011\",\"creattime\":\"2018-09-20 11:56:31\",\"bet\":1.00,\"result\":-0.20,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":7,\"round\":1008819,\"amountbefore\":12.98,\"amountaflter\":12.78,\"tradeno\":\"931624_1008819\"},{\"username\":\"y17384972128\",\"creattime\":\"2018-09-20 11:56:30\",\"bet\":0.40,\"result\":4.56,\"tax\":0.24,\"taxrate\":0.05,\"gametype\":3,\"round\":1006661,\"amountbefore\":36.03,\"amountaflter\":40.59,\"tradeno\":\"931709_1006661\"},{\"username\":\"y462687646\",\"creattime\":\"2018-09-20 11:56:30\",\"bet\":5.10,\"result\":5.41,\"tax\":0.29,\"taxrate\":0.05,\"gametype\":1,\"round\":1118967,\"amountbefore\":39.56,\"amountaflter\":44.97,\"tradeno\":\"931669_1118967\"},{\"username\":\"ylxs2265\",\"creattime\":\"2018-09-20 11:56:29\",\"bet\":0.00,\"result\":38.00,\"tax\":2.00,\"taxrate\":0.05,\"gametype\":8,\"round\":1006597,\"amountbefore\":280.25,\"amountaflter\":318.25,\"tradeno\":\"931707_1006597\"},{\"username\":\"yest11ymob07164\",\"creattime\":\"2018-09-20 11:56:25\",\"bet\":1.00,\"result\":-0.15,\"tax\":0.03,\"taxrate\":0.05,\"gametype\":7,\"round\":1010407,\"amountbefore\":55.29,\"amountaflter\":55.14,\"tradeno\":\"931598_1010407\"},{\"username\":\"yywx1992\",\"creattime\":\"2018-09-20 11:56:21\",\"bet\":1.00,\"result\":-4.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1010807,\"amountbefore\":152.23,\"amountaflter\":148.23,\"tradeno\":\"931697_1010807\"},{\"username\":\"yican567\",\"creattime\":\"2018-09-20 11:56:18\",\"bet\":0.00,\"result\":5.70,\"tax\":0.30,\"taxrate\":0.05,\"gametype\":3,\"round\":1006255,\"amountbefore\":513.65,\"amountaflter\":519.35,\"tradeno\":\"931700_1006255\"},{\"username\":\"y764581211\",\"creattime\":\"2018-09-20 11:56:18\",\"bet\":2.00,\"result\":-6.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1007519,\"amountbefore\":936.74,\"amountaflter\":930.74,\"tradeno\":\"931700_1007519\"},{\"username\":\"y17384972128\",\"creattime\":\"2018-09-20 11:56:12\",\"bet\":0.00,\"result\":1.14,\"tax\":0.06,\"taxrate\":0.05,\"gametype\":3,\"round\":1006661,\"amountbefore\":34.89,\"amountaflter\":36.03,\"tradeno\":\"931680_1006661\"},{\"username\":\"ylxs2265\",\"creattime\":\"2018-09-20 11:56:08\",\"bet\":0.00,\"result\":-142.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":8,\"round\":1006597,\"amountbefore\":422.25,\"amountaflter\":280.25,\"tradeno\":\"931681_1006597\"},{\"username\":\"yican567\",\"creattime\":\"2018-09-20 11:56:02\",\"bet\":0.00,\"result\":68.40,\"tax\":3.60,\"taxrate\":0.05,\"gametype\":3,\"round\":1006255,\"amountbefore\":445.25,\"amountaflter\":513.65,\"tradeno\":\"931671_1006255\"},{\"username\":\"yyjg32334717\",\"creattime\":\"2018-09-20 11:56:02\",\"bet\":2.00,\"result\":-24.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1119215,\"amountbefore\":3176.14,\"amountaflter\":3152.14,\"tradeno\":\"931671_1119215\"},{\"username\":\"y764581211\",\"creattime\":\"2018-09-20 11:56:02\",\"bet\":2.00,\"result\":-24.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1007519,\"amountbefore\":960.74,\"amountaflter\":936.74,\"tradeno\":\"931671_1007519\"},{\"username\":\"yywx1992\",\"creattime\":\"2018-09-20 11:56:00\",\"bet\":0.00,\"result\":-3.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1010807,\"amountbefore\":155.23,\"amountaflter\":152.23,\"tradeno\":\"931672_1010807\"},{\"username\":\"y17384972128\",\"creattime\":\"2018-09-20 11:55:48\",\"bet\":0.20,\"result\":0.19,\"tax\":0.01,\"taxrate\":0.05,\"gametype\":3,\"round\":1006661,\"amountbefore\":34.70,\"amountaflter\":34.89,\"tradeno\":\"931658_1006661\"},{\"username\":\"ylxs2265\",\"creattime\":\"2018-09-20 11:55:47\",\"bet\":0.00,\"result\":-213.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":8,\"round\":1006597,\"amountbefore\":635.25,\"amountaflter\":422.25,\"tradeno\":\"931662_1006597\"},{\"username\":\"yywx1992\",\"creattime\":\"2018-09-20 11:55:42\",\"bet\":4.00,\"result\":60.80,\"tax\":3.20,\"taxrate\":0.05,\"gametype\":3,\"round\":1010807,\"amountbefore\":94.43,\"amountaflter\":155.23,\"tradeno\":\"931652_1010807\"},{\"username\":\"yican567\",\"creattime\":\"2018-09-20 11:55:40\",\"bet\":2.00,\"result\":7.60,\"tax\":0.40,\"taxrate\":0.05,\"gametype\":3,\"round\":1006255,\"amountbefore\":437.65,\"amountaflter\":445.25,\"tradeno\":\"931655_1006255\"},{\"username\":\"yyjg32334717\",\"creattime\":\"2018-09-20 11:55:40\",\"bet\":0.00,\"result\":-8.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1119215,\"amountbefore\":3184.14,\"amountaflter\":3176.14,\"tradeno\":\"931655_1119215\"},{\"username\":\"y764581211\",\"creattime\":\"2018-09-20 11:55:40\",\"bet\":2.00,\"result\":-8.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1007519,\"amountbefore\":968.74,\"amountaflter\":960.74,\"tradeno\":\"931655_1007519\"},{\"username\":\"y462687646\",\"creattime\":\"2018-09-20 11:55:38\",\"bet\":0.50,\"result\":0.19,\"tax\":0.01,\"taxrate\":0.05,\"gametype\":1,\"round\":1118967,\"amountbefore\":39.37,\"amountaflter\":39.56,\"tradeno\":\"931656_1118967\"},{\"username\":\"y17384972128\",\"creattime\":\"2018-09-20 11:55:27\",\"bet\":0.20,\"result\":0.76,\"tax\":0.04,\"taxrate\":0.05,\"gametype\":3,\"round\":1006661,\"amountbefore\":33.94,\"amountaflter\":34.70,\"tradeno\":\"931649_1006661\"},{\"username\":\"ylxs2265\",\"creattime\":\"2018-09-20 11:55:26\",\"bet\":0.00,\"result\":-155.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":8,\"round\":1006597,\"amountbefore\":790.25,\"amountaflter\":635.25,\"tradeno\":\"931645_1006597\"},{\"username\":\"yican567\",\"creattime\":\"2018-09-20 11:55:21\",\"bet\":2.00,\"result\":-16.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1006255,\"amountbefore\":453.65,\"amountaflter\":437.65,\"tradeno\":\"931640_1006255\"},{\"username\":\"yyjg32334717\",\"creattime\":\"2018-09-20 11:55:21\",\"bet\":2.00,\"result\":-16.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1119215,\"amountbefore\":3200.14,\"amountaflter\":3184.14,\"tradeno\":\"931640_1119215\"},{\"username\":\"y764581211\",\"creattime\":\"2018-09-20 11:55:21\",\"bet\":2.00,\"result\":-16.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1007519,\"amountbefore\":984.74,\"amountaflter\":968.74,\"tradeno\":\"931640_1007519\"},{\"username\":\"y462687646\",\"creattime\":\"2018-09-20 11:55:19\",\"bet\":6.00,\"result\":-6.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":1,\"round\":1118967,\"amountbefore\":45.37,\"amountaflter\":39.37,\"tradeno\":\"931634_1118967\"},{\"username\":\"yywx1992\",\"creattime\":\"2018-09-20 11:55:17\",\"bet\":1.00,\"result\":-8.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1010807,\"amountbefore\":102.43,\"amountaflter\":94.43,\"tradeno\":\"931636_1010807\"},{\"username\":\"y17384972128\",\"creattime\":\"2018-09-20 11:55:11\",\"bet\":0.00,\"result\":-1.60,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1006661,\"amountbefore\":35.54,\"amountaflter\":33.94,\"tradeno\":\"931629_1006661\"},{\"username\":\"ylxs2265\",\"creattime\":\"2018-09-20 11:55:05\",\"bet\":0.00,\"result\":113.05,\"tax\":5.95,\"taxrate\":0.05,\"gametype\":8,\"round\":1006597,\"amountbefore\":677.20,\"amountaflter\":790.25,\"tradeno\":\"931628_1006597\"},{\"username\":\"yican567\",\"creattime\":\"2018-09-20 11:55:01\",\"bet\":0.00,\"result\":91.20,\"tax\":4.80,\"taxrate\":0.05,\"gametype\":3,\"round\":1006255,\"amountbefore\":362.45,\"amountaflter\":453.65,\"tradeno\":\"931622_1006255\"},{\"username\":\"yyjg32334717\",\"creattime\":\"2018-09-20 11:55:01\",\"bet\":2.00,\"result\":-32.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1119215,\"amountbefore\":3232.14,\"amountaflter\":3200.14,\"tradeno\":\"931622_1119215\"},{\"username\":\"y764581211\",\"creattime\":\"2018-09-20 11:55:01\",\"bet\":2.00,\"result\":-32.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1007519,\"amountbefore\":1016.74,\"amountaflter\":984.74,\"tradeno\":\"931622_1007519\"},{\"username\":\"yywx1992\",\"creattime\":\"2018-09-20 11:54:57\",\"bet\":1.00,\"result\":-16.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1010807,\"amountbefore\":118.43,\"amountaflter\":102.43,\"tradeno\":\"931620_1010807\"},{\"username\":\"y462687646\",\"creattime\":\"2018-09-20 11:54:52\",\"bet\":15.00,\"result\":-15.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":1,\"round\":1118967,\"amountbefore\":60.37,\"amountaflter\":45.37,\"tradeno\":\"931600_1118967\"},{\"username\":\"y17384972128\",\"creattime\":\"2018-09-20 11:54:47\",\"bet\":0.00,\"result\":0.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1006661,\"amountbefore\":35.54,\"amountaflter\":35.54,\"tradeno\":\"931606_1006661\"},{\"username\":\"ylxs2265\",\"creattime\":\"2018-09-20 11:54:44\",\"bet\":40.00,\"result\":19.00,\"tax\":1.00,\"taxrate\":0.05,\"gametype\":8,\"round\":1006597,\"amountbefore\":658.20,\"amountaflter\":677.20,\"tradeno\":\"931609_1006597\"},{\"username\":\"ygta325011\",\"creattime\":\"2018-09-20 11:54:41\",\"bet\":2.00,\"result\":3.04,\"tax\":0.16,\"taxrate\":0.05,\"gametype\":7,\"round\":1008819,\"amountbefore\":9.94,\"amountaflter\":12.98,\"tradeno\":\"931597_1008819\"},{\"username\":\"yican567\",\"creattime\":\"2018-09-20 11:54:39\",\"bet\":2.00,\"result\":22.80,\"tax\":1.20,\"taxrate\":0.05,\"gametype\":3,\"round\":1006255,\"amountbefore\":339.65,\"amountaflter\":362.45,\"tradeno\":\"931604_1006255\"},{\"username\":\"yyjg32334717\",\"creattime\":\"2018-09-20 11:54:39\",\"bet\":2.00,\"result\":-8.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1119215,\"amountbefore\":3240.14,\"amountaflter\":3232.14,\"tradeno\":\"931604_1119215\"},{\"username\":\"y764581211\",\"creattime\":\"2018-09-20 11:54:39\",\"bet\":2.00,\"result\":-8.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1007519,\"amountbefore\":1024.74,\"amountaflter\":1016.74,\"tradeno\":\"931604_1007519\"},{\"username\":\"yywx1992\",\"creattime\":\"2018-09-20 11:54:36\",\"bet\":2.00,\"result\":30.40,\"tax\":1.60,\"taxrate\":0.05,\"gametype\":3,\"round\":1010807,\"amountbefore\":88.03,\"amountaflter\":118.43,\"tradeno\":\"931602_1010807\"},{\"username\":\"y17384972128\",\"creattime\":\"2018-09-20 11:54:22\",\"bet\":0.20,\"result\":-0.80,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1006661,\"amountbefore\":36.34,\"amountaflter\":35.54,\"tradeno\":\"931579_1006661\"},{\"username\":\"yyjg32334717\",\"creattime\":\"2018-09-20 11:54:21\",\"bet\":0.00,\"result\":-16.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1119215,\"amountbefore\":3256.14,\"amountaflter\":3240.14,\"tradeno\":\"931580_1119215\"},{\"username\":\"y764581211\",\"creattime\":\"2018-09-20 11:54:21\",\"bet\":2.00,\"result\":7.60,\"tax\":0.40,\"taxrate\":0.05,\"gametype\":3,\"round\":1007519,\"amountbefore\":1017.14,\"amountaflter\":1024.74,\"tradeno\":\"931580_1007519\"},{\"username\":\"yican567\",\"creattime\":\"2018-09-20 11:54:21\",\"bet\":2.00,\"result\":7.60,\"tax\":0.40,\"taxrate\":0.05,\"gametype\":3,\"round\":1006255,\"amountbefore\":332.05,\"amountaflter\":339.65,\"tradeno\":\"931580_1006255\"},{\"username\":\"yywx1992\",\"creattime\":\"2018-09-20 11:54:19\",\"bet\":4.00,\"result\":-32.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1010807,\"amountbefore\":120.03,\"amountaflter\":88.03,\"tradeno\":\"931578_1010807\"},{\"username\":\"y462687646\",\"creattime\":\"2018-09-20 11:54:15\",\"bet\":1.00,\"result\":-1.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":1,\"round\":1118967,\"amountbefore\":61.37,\"amountaflter\":60.37,\"tradeno\":\"931570_1118967\"},{\"username\":\"yest11ymob07164\",\"creattime\":\"2018-09-20 11:54:09\",\"bet\":1.00,\"result\":0.57,\"tax\":0.03,\"taxrate\":0.05,\"gametype\":7,\"round\":1010407,\"amountbefore\":54.50,\"amountaflter\":55.07,\"tradeno\":\"931487_1010407\"},{\"username\":\"yican567\",\"creattime\":\"2018-09-20 11:54:03\",\"bet\":2.00,\"result\":-2.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1006255,\"amountbefore\":334.05,\"amountaflter\":332.05,\"tradeno\":\"931573_1006255\"},{\"username\":\"y764581211\",\"creattime\":\"2018-09-20 11:54:03\",\"bet\":0.00,\"result\":1.90,\"tax\":0.10,\"taxrate\":0.05,\"gametype\":3,\"round\":1007519,\"amountbefore\":1015.24,\"amountaflter\":1017.14,\"tradeno\":\"931573_1007519\"},{\"username\":\"y17384972128\",\"creattime\":\"2018-09-20 11:54:03\",\"bet\":0.20,\"result\":-0.80,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1006661,\"amountbefore\":37.14,\"amountaflter\":36.34,\"tradeno\":\"931568_1006661\"},{\"username\":\"yywx1992\",\"creattime\":\"2018-09-20 11:54:00\",\"bet\":1.00,\"result\":-4.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1010807,\"amountbefore\":124.03,\"amountaflter\":120.03,\"tradeno\":\"931564_1010807\"},{\"username\":\"yican567\",\"creattime\":\"2018-09-20 11:53:50\",\"bet\":2.00,\"result\":30.40,\"tax\":1.60,\"taxrate\":0.05,\"gametype\":3,\"round\":1006255,\"amountbefore\":303.65,\"amountaflter\":334.05,\"tradeno\":\"931558_1006255\"},{\"username\":\"y764581211\",\"creattime\":\"2018-09-20 11:53:50\",\"bet\":0.00,\"result\":-32.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1007519,\"amountbefore\":1047.24,\"amountaflter\":1015.24,\"tradeno\":\"931558_1007519\"},{\"username\":\"y17384972128\",\"creattime\":\"2018-09-20 11:53:47\",\"bet\":0.20,\"result\":0.76,\"tax\":0.04,\"taxrate\":0.05,\"gametype\":3,\"round\":1006661,\"amountbefore\":36.38,\"amountaflter\":37.14,\"tradeno\":\"931539_1006661\"},{\"username\":\"y462687646\",\"creattime\":\"2018-09-20 11:53:46\",\"bet\":4.00,\"result\":-4.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":1,\"round\":1118967,\"amountbefore\":65.37,\"amountaflter\":61.37,\"tradeno\":\"931544_1118967\"},{\"username\":\"yywx1992\",\"creattime\":\"2018-09-20 11:53:45\",\"bet\":1.00,\"result\":3.80,\"tax\":0.20,\"taxrate\":0.05,\"gametype\":3,\"round\":1010807,\"amountbefore\":120.23,\"amountaflter\":124.03,\"tradeno\":\"931554_1010807\"},{\"username\":\"ylxs2265\",\"creattime\":\"2018-09-20 11:53:43\",\"bet\":0.00,\"result\":-137.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":8,\"round\":1006597,\"amountbefore\":1477.20,\"amountaflter\":1340.20,\"tradeno\":\"931543_1006597\"},{\"username\":\"yican567\",\"creattime\":\"2018-09-20 11:53:37\",\"bet\":0.00,\"result\":15.20,\"tax\":0.80,\"taxrate\":0.05,\"gametype\":3,\"round\":1006255,\"amountbefore\":288.45,\"amountaflter\":303.65,\"tradeno\":\"931540_1006255\"},{\"username\":\"y764581211\",\"creattime\":\"2018-09-20 11:53:37\",\"bet\":2.00,\"result\":-16.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1007519,\"amountbefore\":1063.24,\"amountaflter\":1047.24,\"tradeno\":\"931540_1007519\"},{\"username\":\"yywx1992\",\"creattime\":\"2018-09-20 11:53:31\",\"bet\":4.00,\"result\":-64.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1010807,\"amountbefore\":184.23,\"amountaflter\":120.23,\"tradeno\":\"931535_1010807\"},{\"username\":\"y462687646\",\"creattime\":\"2018-09-20 11:53:23\",\"bet\":25.00,\"result\":22.80,\"tax\":1.20,\"taxrate\":0.05,\"gametype\":1,\"round\":1118967,\"amountbefore\":42.57,\"amountaflter\":65.37,\"tradeno\":\"931512_1118967\"},{\"username\":\"ylxs2265\",\"creattime\":\"2018-09-20 11:53:22\",\"bet\":0.00,\"result\":718.20,\"tax\":37.80,\"taxrate\":0.05,\"gametype\":8,\"round\":1006597,\"amountbefore\":759.00,\"amountaflter\":1477.20,\"tradeno\":\"931523_1006597\"},{\"username\":\"y17384972128\",\"creattime\":\"2018-09-20 11:53:21\",\"bet\":0.20,\"result\":0.76,\"tax\":0.04,\"taxrate\":0.05,\"gametype\":3,\"round\":1006661,\"amountbefore\":35.62,\"amountaflter\":36.38,\"tradeno\":\"931522_1006661\"},{\"username\":\"yican567\",\"creattime\":\"2018-09-20 11:53:20\",\"bet\":2.00,\"result\":-32.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1006255,\"amountbefore\":320.45,\"amountaflter\":288.45,\"tradeno\":\"931529_1006255\"},{\"username\":\"y764581211\",\"creattime\":\"2018-09-20 11:53:20\",\"bet\":0.00,\"result\":30.40,\"tax\":1.60,\"taxrate\":0.05,\"gametype\":3,\"round\":1007519,\"amountbefore\":1032.84,\"amountaflter\":1063.24,\"tradeno\":\"931529_1007519\"},{\"username\":\"yywx1992\",\"creattime\":\"2018-09-20 11:53:13\",\"bet\":0.00,\"result\":53.20,\"tax\":2.80,\"taxrate\":0.05,\"gametype\":3,\"round\":1010807,\"amountbefore\":131.03,\"amountaflter\":184.23,\"tradeno\":\"931517_1010807\"},{\"username\":\"yican567\",\"creattime\":\"2018-09-20 11:53:08\",\"bet\":2.00,\"result\":-16.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1006255,\"amountbefore\":336.45,\"amountaflter\":320.45,\"tradeno\":\"931515_1006255\"},{\"username\":\"y764581211\",\"creattime\":\"2018-09-20 11:53:08\",\"bet\":0.00,\"result\":15.20,\"tax\":0.80,\"taxrate\":0.05,\"gametype\":3,\"round\":1007519,\"amountbefore\":1017.64,\"amountaflter\":1032.84,\"tradeno\":\"931515_1007519\"},{\"username\":\"ylxs2265\",\"creattime\":\"2018-09-20 11:53:01\",\"bet\":40.00,\"result\":57.00,\"tax\":3.00,\"taxrate\":0.05,\"gametype\":8,\"round\":1006597,\"amountbefore\":702.00,\"amountaflter\":759.00,\"tradeno\":\"931498_1006597\"},{\"username\":\"y17384972128\",\"creattime\":\"2018-09-20 11:53:00\",\"bet\":0.80,\"result\":-12.80,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1006661,\"amountbefore\":48.42,\"amountaflter\":35.62,\"tradeno\":\"931491_1006661\"},{\"username\":\"yican567\",\"creattime\":\"2018-09-20 11:52:56\",\"bet\":0.00,\"result\":1.90,\"tax\":0.10,\"taxrate\":0.05,\"gametype\":3,\"round\":1006255,\"amountbefore\":334.55,\"amountaflter\":336.45,\"tradeno\":\"931497_1006255\"},{\"username\":\"y764581211\",\"creattime\":\"2018-09-20 11:52:56\",\"bet\":2.00,\"result\":-2.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1007519,\"amountbefore\":1019.64,\"amountaflter\":1017.64,\"tradeno\":\"931497_1007519\"},{\"username\":\"y462687646\",\"creattime\":\"2018-09-20 11:52:49\",\"bet\":1.00,\"result\":-1.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":1,\"round\":1118967,\"amountbefore\":43.57,\"amountaflter\":42.57,\"tradeno\":\"931479_1118967\"},{\"username\":\"yican567\",\"creattime\":\"2018-09-20 11:52:41\",\"bet\":2.00,\"result\":15.20,\"tax\":0.80,\"taxrate\":0.05,\"gametype\":3,\"round\":1006255,\"amountbefore\":319.35,\"amountaflter\":334.55,\"tradeno\":\"931470_1006255\"},{\"username\":\"y764581211\",\"creattime\":\"2018-09-20 11:52:41\",\"bet\":0.00,\"result\":-8.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1007519,\"amountbefore\":1027.64,\"amountaflter\":1019.64,\"tradeno\":\"931470_1007519\"},{\"username\":\"yywx1992\",\"creattime\":\"2018-09-20 11:52:41\",\"bet\":2.00,\"result\":-8.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1010807,\"amountbefore\":139.03,\"amountaflter\":131.03,\"tradeno\":\"931470_1010807\"},{\"username\":\"ylxs2265\",\"creattime\":\"2018-09-20 11:52:40\",\"bet\":40.00,\"result\":38.00,\"tax\":2.00,\"taxrate\":0.05,\"gametype\":8,\"round\":1006597,\"amountbefore\":664.00,\"amountaflter\":702.00,\"tradeno\":\"931478_1006597\"},{\"username\":\"y17384972128\",\"creattime\":\"2018-09-20 11:52:33\",\"bet\":0.20,\"result\":-4.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1006661,\"amountbefore\":52.42,\"amountaflter\":48.42,\"tradeno\":\"931467_1006661\"},{\"username\":\"yest11ymob07164\",\"creattime\":\"2018-09-20 11:52:25\",\"bet\":1.00,\"result\":-0.35,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":7,\"round\":1010407,\"amountbefore\":54.85,\"amountaflter\":54.50,\"tradeno\":\"931397_1010407\"},{\"username\":\"ylxs2265\",\"creattime\":\"2018-09-20 11:52:19\",\"bet\":40.00,\"result\":19.00,\"tax\":1.00,\"taxrate\":0.05,\"gametype\":8,\"round\":1006597,\"amountbefore\":645.00,\"amountaflter\":664.00,\"tradeno\":\"931456_1006597\"},{\"username\":\"y462687646\",\"creattime\":\"2018-09-20 11:52:19\",\"bet\":6.00,\"result\":1.90,\"tax\":0.10,\"taxrate\":0.05,\"gametype\":1,\"round\":1118967,\"amountbefore\":41.67,\"amountaflter\":43.57,\"tradeno\":\"931460_1118967\"},{\"username\":\"y764581211\",\"creattime\":\"2018-09-20 11:52:13\",\"bet\":4.00,\"result\":-16.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1007519,\"amountbefore\":1043.64,\"amountaflter\":1027.64,\"tradeno\":\"931446_1007519\"},{\"username\":\"yywx1992\",\"creattime\":\"2018-09-20 11:52:13\",\"bet\":0.00,\"result\":22.80,\"tax\":1.20,\"taxrate\":0.05,\"gametype\":3,\"round\":1010807,\"amountbefore\":116.23,\"amountaflter\":139.03,\"tradeno\":\"931446_1010807\"},{\"username\":\"yican567\",\"creattime\":\"2018-09-20 11:52:13\",\"bet\":2.00,\"result\":-8.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1006255,\"amountbefore\":327.35,\"amountaflter\":319.35,\"tradeno\":\"931446_1006255\"},{\"username\":\"y17384972128\",\"creattime\":\"2018-09-20 11:52:11\",\"bet\":0.00,\"result\":0.00,\"tax\":0.00,\"taxrate\":0.05,\"gametype\":3,\"round\":1006661,\"amountbefore\":52.42,\"amountaflter\":52.42,\"tradeno\":\"931441_1006661\"}],\"status\":1,\"totalrecords\":93,\"pagenum\":1,\"errdesc\":\"查询游戏记录成功\"}";
        log.info("++++++++++" + pid + "_NAP,注单抓取url==" + result);
        if (StringUtils.isBlank(result)) {
            obj.info = "empty String";
            log.info("++++++++++" + pid + "_NAP,注单抓取失败,厅方返回result==" + result);
            return obj;
        }
        JSONObject dataJSONObj = JSONObject.parseObject(result);
        if (dataJSONObj.getInteger("status") != 1) {
            log.info("++++++++++" + pid + "_NAP,注单抓取返回0条记录,厅方返回result==" + result);
            return obj;
        }
        int totalrecords = dataJSONObj.get("totalrecords") == null ? 0 : dataJSONObj.getInteger("totalrecords");
        int pagenum = dataJSONObj.get("pagenum") == null ? 0 : dataJSONObj.getInteger("pagenum");
        obj.setTotalNumber(totalrecords);
        obj.setTotalPage(pagenum);
        log.info("++++++++++" + pid + "_NAP,注单抓取返回" + obj.getTotalNumber() + "条记录");
        JSONArray array = dataJSONObj.get("Results") == null ? null : dataJSONObj.getJSONArray("Results");
        if (array == null || array.size() == 0) {
            return obj;
        }
        JSONObject json;
        for (int i = 0; i < array.size(); i++) {
            json = array.getJSONObject(i);
            OrderEntity order = new OrderEntity();
            order.setProductId(pid.toUpperCase());
            order.setPlatId(platformId);
            order.setLoginName(json.getString("username"));
            order.setBillTime(DateUtil.formatStr2Date(json.getString("creattime")));
            order.setGmCode(json.getString("round"));
            order.setAccount(json.getBigDecimal("bet"));
            order.setValidAccount(order.getAccount());
            order.setCusAccount(json.getBigDecimal("result"));
            order.setPreviosAmount(json.getBigDecimal("amountbefore"));
            order.setCurrentAmount(json.getBigDecimal("amountaflter"));
            order.setBillNo(json.getString("tradeno"));
            String gameType = json.getString("gametype");
            order.setGameType(gameType);
            order.setGameKind("7");
            order.setRemainAmount(json.getBigDecimal("tax"));
            // RESULT抽水
            order.setResult(json.getString("tax"));

            order.setFlag(1);
            order.setDeviceType("0");
            obj.list.add(order);
        }
        return obj;
    }

    /**
     * 抓取 NAP 转账记录
     *
     * @param parameterMap
     * @return
     * @throws Exception
     */
    public static NAPParseJsonUtil parseNapTransfer(Map<String, Object> parameterMap) throws Exception {
        log.info("+++++++_NAP,额度记录抓取+begin++parameterMap====" + parameterMap);
        NAPParseJsonUtil obj = new NAPParseJsonUtil();
        String url = (String) parameterMap.get(UtilConstants.ORDER_BASE_URL);
        String platformId = (String) parameterMap.get(UtilConstants.GLOBAL_PLATFORMID_KEY);
        String pid = (String) parameterMap.get(UtilConstants.ORDER_PRODUCT_ID);
        StringBuilder keyparams = new StringBuilder();

        keyparams.append("begintime").append("=").append((String) parameterMap.get(UtilConstants.GAME_RESULT_BEGIN_TIME)).append("&");
        keyparams.append("endtime").append("=").append((String) parameterMap.get(UtilConstants.GAME_RESULT_END_TIME)).append("&");
        keyparams.append("gplatform").append("=").append((String) parameterMap.get("accountName")).append("&");
        keyparams.append("page").append("=").append((String) parameterMap.get(UtilConstants.ORDER_BBIN_PAGENUM)).append("&");
        keyparams.append("productid").append("=").append(pid).append("&");
        keyparams.append("size").append("=").append((String) parameterMap.get(UtilConstants.GAME_RESULT_PAGE_NUMBER)).append("&");

        StringBuilder params = new StringBuilder();
        params.append("begintime").append("=").append(URLEncoder.encode((String) parameterMap.get(UtilConstants.GAME_RESULT_BEGIN_TIME), "UTF-8")).append("&");
        params.append("endtime").append("=").append(URLEncoder.encode((String) parameterMap.get(UtilConstants.GAME_RESULT_END_TIME), "UTF-8")).append("&");
        params.append("gplatform").append("=").append((String) parameterMap.get("accountName")).append("&");
        params.append("page").append("=").append((String) parameterMap.get(UtilConstants.ORDER_BBIN_PAGENUM)).append("&");
        params.append("productid").append("=").append(pid).append("&");
        params.append("size").append("=").append((String) parameterMap.get(UtilConstants.GAME_RESULT_PAGE_NUMBER)).append("&");
        url = url + params.toString() + "key=" + DigestUtils.md5Hex((keyparams.toString() + "secretkey=" + ((String) parameterMap.get(UtilConstants.ORDER_BBIN_PASSWORD))));
        // String result="{ \"responseaction\": \"GetCoinOrders\", \"totalrecords\": 100, \"pagenum\": 10, \"Results\": [ { \"username\": \"test5177\", \"tradetime\": \"2018-08-09 19:24:58\", \"tradeno\": 342343323, \"tradesrcamount\": 100, \"tradeamount\": 10, \"tradedstamount\": 110, \"tradeaction\": 1 } ], \"status\": 1, \"errdesc\": null }";
        //  url= URLEncoder.encode(url,"UTF-8");
        String result = HttpUtil.resultHttpUrl(url);
        log.info("++++++++++" + pid + "_NAP,额度记录抓取url==" + result);
        if (StringUtils.isBlank(result)) {
            obj.info = "empty String";
            log.info("++++++++++" + pid + "_NAP,额度记录抓取失败,厅方返回result==" + result);
            return obj;
        }
        JSONObject dataJSONObj = JSONObject.parseObject(result);
        if (dataJSONObj.getInteger("status") != 1) {
            log.info("++++++++++" + pid + "_NAP,额度记录抓取返回0条记录,厅方返回result==" + result);
            return obj;
        }
        int totalrecords = dataJSONObj.get("totalrecords") == null ? 0 : dataJSONObj.getInteger("totalrecords");
        int pagenum = dataJSONObj.get("pagenum") == null ? 0 : dataJSONObj.getInteger("pagenum");
        obj.setTotalNumber(totalrecords);
        obj.setTotalPage(pagenum);
        log.info("++++++++++" + pid + "_NAP,额度记录抓取返回" + obj.getTotalNumber() + "条记录");
        JSONArray array = dataJSONObj.getJSONArray("Results");
        if (array == null || array.size() == 0) {
            return obj;
        }
        JSONObject trans_obj;
        for (int i = 0; i < array.size(); i++) {
            trans_obj = array.getJSONObject(i);
            AccountTransferEntity trans = new AccountTransferEntity();
            trans.setUserName(trans_obj.getString("username"));
            trans.setProductId(pid);
            trans.setPlatformId(platformId);
            String transferTime = trans_obj.getString("tradetime");
            trans.setTime(transferTime);
            trans.setTransferAmount(trans_obj.getBigDecimal("tradeamount"));
            trans.setPreviousAmount(trans_obj.getBigDecimal("tradesrcamount"));
            trans.setCurrentAmount(trans_obj.getBigDecimal("tradedstamount"));
            // 需要在转换
            String transferType = trans_obj.getString("tradeaction");
            //14=9198转账
            if ("14".equals(transferType)) {
                if (trans.getTransferAmount().compareTo(new BigDecimal(0)) >= 0) {
                    trans.setTransferType("IN");
                } else {
                    trans.setTransferType("OUT");
                }
            } else if ("1".equals(transferType)) {
                trans.setTransferType("RECKON");
            } else {
                trans.setTransferType(transferType);
            }

            trans.setTransId(trans_obj.getString("tradeno"));
            obj.list.add(trans);
        }
        return obj;
    }

    public static void main(String args[]) {
        System.out.println(100 / 100);
    }


}
