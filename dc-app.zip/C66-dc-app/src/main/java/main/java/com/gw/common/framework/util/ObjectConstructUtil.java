/**
 *
 */
package main.java.com.gw.common.framework.util;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.system.entity.BetAmtLimitEntity;
import main.java.com.gw.common.system.entity.PlayerEntity;
import main.java.com.gw.common.system.props.CustomerPropertyholder;
import main.java.com.gw.datacenter.accounttransfer.entity.AccountTransfer4HgEntity;
import main.java.com.gw.datacenter.accounttransfer.entity.AccountTransferEntity;
import main.java.com.gw.datacenter.constans.enums.AGQJOrdersExceptionorEnum;
import main.java.com.gw.datacenter.constans.enums.AccountTransfer4A06Enum;
import main.java.com.gw.datacenter.constans.enums.AccountTransferEnum;
import main.java.com.gw.datacenter.constans.enums.BBINOrdersEnum;
import main.java.com.gw.datacenter.constans.enums.BaGameEnum;
import main.java.com.gw.datacenter.constans.enums.BetAmtLimitEnum;
import main.java.com.gw.datacenter.constans.enums.EAOrdersEnum;
import main.java.com.gw.datacenter.constans.enums.HGAccountTransferEnum;
import main.java.com.gw.datacenter.constans.enums.HGGameResultEnum;
import main.java.com.gw.datacenter.constans.enums.HGOrdersEnum;
import main.java.com.gw.datacenter.constans.enums.K8GameEnum;
import main.java.com.gw.datacenter.constans.enums.OrdersEnum;
import main.java.com.gw.datacenter.constans.enums.PlayerEnum;
import main.java.com.gw.datacenter.gameresult.entity.BaGameEntity;
import main.java.com.gw.datacenter.gameresult.entity.K8GameEntity;
import main.java.com.gw.datacenter.order.entity.OrderAGQJExceptionor;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.StringUtils;
import org.xml.sax.Attributes;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;

/**
 * @author alex.l
 */
@Slf4j
public class ObjectConstructUtil {
    /**
     * Construt Object instance by loop XML attributes.
     *
     * @param attrs
     * @param claz
     * @return obj
     */
    public static Object readAttributes(Attributes attrs, String platformId, Class<Object> claz) {
        Object obj = null;
        try {
            if ((claz.newInstance()) instanceof OrderEntity) {
                // for orders
                obj = constructOrders(attrs, platformId, claz);
                /*
                 * if(!UtilConstants.K8.equals(platformId) && !UtilConstants.K8_EH.equals(platformId)){ obj = constructOrders(attrs, platformId,
                 * claz); }else{ obj = constructOrdersForEaseHawaiiK8(attrs, platformId, claz); }
                 */
            } else if ((claz.newInstance()) instanceof BaGameEntity) {
                // for game result
                obj = constructBaGame(attrs, platformId, claz);
            } else if ((claz.newInstance()) instanceof AccountTransferEntity) {
                // for account transfer
                obj = constructAccountTransfer(attrs, platformId, claz);
            } else if ((claz.newInstance()) instanceof K8GameEntity) {
                // for k8 game result
                obj = constructK8Game(attrs, platformId, claz);
            } else if ((claz.newInstance()) instanceof PlayerEntity) {
                obj = constructPlayerEntity(attrs, platformId, claz);
            } else if (claz.newInstance() instanceof BetAmtLimitEntity) {
                obj = constructBetAmtLimitEntity(attrs, platformId, claz);
            } else if (claz.newInstance() instanceof AccountTransfer4HgEntity) {
                obj = constructAccountTransfer4Hogaming(attrs, platformId, claz);
            } else if (claz.newInstance() instanceof OrderAGQJExceptionor) {
                obj = constructAGQJExceptionorOrders(attrs, platformId, claz);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return obj;
    }

    /**
     * Construct OrdersEntity for DSP and DYJ.
     *
     * @param platformId
     * @throws IllegalArgumentException
     */
    public static OrderEntity constructOrders(Attributes attrs, String platformId, Class<Object> claz) throws IllegalArgumentException {
        int attrCount = attrs.getLength();
        OrderEntity objInstance = new OrderEntity();
        String attrName = null;
        OrdersEnum attrNameEnum = null;
        objInstance.setPlatId(platformId);
        for (int i = 0; i < attrCount; i++) {
            attrName = attrs.getQName(i);
            try {
                attrNameEnum = Enum.valueOf(OrdersEnum.class, attrName);
            } catch (Exception e) {
//                log.error("ObjectConstructUtil constructOrders error:" + e.getMessage(), e);
                continue;
            }
            switch (attrNameEnum) {
                case billno:
                    objInstance.setBillNo(attrs.getValue(i));
                    break;
                case billNo:
                    objInstance.setBillNo(attrs.getValue(i));
                    break;
                case gameType:
                    objInstance.setGameType(attrs.getValue(i));
                    break;
                case loginname:
                    if (objInstance.getLoginName() != null) {
                        break;
                    }
                    if (!UtilConstants.K8.equals(platformId)) {
                        String loginName = attrs.getValue(i);
                        if (objInstance.getProductId() != null && loginName.contains(objInstance.getProductId())) {
                            objInstance.setLoginName(loginName.substring(objInstance.getProductId().length()));
                        } else {
                            objInstance.setLoginName(loginName);
                        }
                    }
                    break;
                case agcode:
                    objInstance.setAgCode(attrs.getValue(i));
                    objInstance.setTopAgCode((objInstance.getAgCode()).substring(0, 3));
                    // only for k8
//                if (UtilConstants.AGCODE_K8_BTT.equals(objInstance.getTopAgCode())) {
//                    objInstance.setProductId(UtilConstants.PRODUCTID_BLM);
//                } else if (UtilConstants.AGCODE_K8_HWX.equals(objInstance.getTopAgCode())) {
//                    objInstance.setProductId(UtilConstants.PRODUCTID_EH);
//                } else if (UtilConstants.AGCODE_K8_LB.equals(objInstance.getTopAgCode())) {
//                    objInstance.setProductId(UtilConstants.PRODUCTID_MT);
//                } else if (UtilConstants.AGCODE_K8_CF.equals(objInstance.getTopAgCode())
//                        || UtilConstants.AGCODE_K8_CF_SW.equals(objInstance.getTopAgCode())) {
//                    objInstance.setProductId(UtilConstants.PRODUCTID_CF);
//                } else if (UtilConstants.AGCODE_K8_E04.equals(objInstance.getTopAgCode())) {
//                    objInstance.setProductId(UtilConstants.PRODUCTID_E04HJ);
//                } else if (UtilConstants.AGCODE_K8_E03.equals(objInstance.getTopAgCode())) {
//                    if (UtilConstants.K8.equals(platformId)) {
//                        objInstance.setProductId(UtilConstants.PRODUCT_ENUM.E03.toString());
//                    }
//                }
                    break;
                case gmcode:
                    objInstance.setGmCode(attrs.getValue(i));
                    break;
                case gameCode:
                    objInstance.setGmCode(attrs.getValue(i));
                    break;
                case cus_account:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setCusAccount(BigDecimal.valueOf(Double.valueOf(attrs.getValue(i))));
                    }
                    break;
                case beforeCredit:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setPreviosAmount(BigDecimal.valueOf(Double.valueOf(attrs.getValue(i))));
                    }
                    break;
                case netAmount:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        BigDecimal netAccot = BigDecimal.valueOf(Double.valueOf(attrs.getValue(i)));
                        objInstance.setNetAccount(netAccot);
                        objInstance.setCusAccount(netAccot);
                    }
                    break;
                case billtime:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        if (UtilConstants.K8.equals(platformId)) {
                            objInstance.setBillTime(DateUtil.formatStr2Date(attrs.getValue(i)));
                        } else if (UtilConstants.HOGAME.equals(platformId)) {
                            objInstance.setBillTime(ToolUtil.transferGMTDateToCNEsternDate(DateUtil.formatStr2Date(attrs.getValue(i))));
                        } else {
                            objInstance.setBillTime(ToolUtil.transferUSEsternDateToCNEsternDate(DateUtil.formatStr2Date(attrs.getValue(i))));
                        }
                        objInstance.setOrignalBillTime(DateUtil.formatStr2Date(attrs.getValue(i)));
                        // 由于派彩时间有可能为空，则初始时将billtime设置为派彩时间,add by moses
                        if (UtilConstants.AGIN.equals(platformId) || UtilConstants.ORDERS_AGIN_SPORT.equals(platformId)) {
                            if (objInstance.getReckonTime() == null) {
                                objInstance.setReckonTime(objInstance.getBillTime());
                            }
                            if (objInstance.getOrignalReckonTime() == null) {
                                objInstance.setOrignalReckonTime(objInstance.getOrignalBillTime());
                            }
                        }
                    }
                    break;
                case betTime:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setBillTime(ToolUtil.transferUSEsternDateToCNEsternDate(DateUtil.formatStr2Date(attrs.getValue(i))));
                        objInstance.setOrignalBillTime(DateUtil.formatStr2Date(attrs.getValue(i)));
                        // 由于派彩时间有可能为空，则初始时将billtime设置为派彩时间,add by moses
                        if (UtilConstants.AGIN.equals(platformId) || UtilConstants.ORDERS_AGIN_SPORT.equals(platformId)) {
                            objInstance.setAgCode(" ");
                            if (objInstance.getReckonTime() == null) {
                                objInstance.setReckonTime(objInstance.getBillTime());
                            }
                            if (objInstance.getOrignalReckonTime() == null) {
                                objInstance.setOrignalReckonTime(objInstance.getOrignalBillTime());
                            }
                        }
                    }
                    break;
                case tableCode:
                    objInstance.setTableCode(attrs.getValue(i));
                    break;
                case flag:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setFlag(Integer.parseInt(attrs.getValue(i)));
                    }
                    if (platformId.equals(UtilConstants.ORDERS_AGIN_SPORT)) {
                        if (objInstance.getFlag() == 0) {//0=未派彩，1=已派彩，-8=取消
                            objInstance.setResult("700");
                            objInstance.setResultType("700");
                        } else if (objInstance.getFlag() == -8) {//厅方返回 -8为取消，但是为了和平台统一使用-9
                            objInstance.setResult("C: Cancel");
                            objInstance.setResultType("Cancel");
                            objInstance.setFlag(UtilConstants.ORDERS_FLAG_ENUM.CANCELED.getFalg());
                        }
                    }
                    break;
                case hascode:
                    objInstance.setHashCode(attrs.getValue(i));
                    break;
                case remark:
                    objInstance.setRemark(attrs.getValue(i));
                    break;
                case playtype:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setPlayType(Integer.parseInt(attrs.getValue(i)));
                    }
                    break;
                case playType:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setPlayType(Integer.parseInt(attrs.getValue(i)));
                    }
                    break;
                case currency:
                    if (attrs.getValue(i) != null) {
                        objInstance.setCurrency(attrs.getValue(i).toUpperCase());
                    }
                    break;
                case tablecode:
                    objInstance.setTableCode(attrs.getValue(i));
                    break;
                case round:
                    objInstance.setRound(attrs.getValue(i));
                    break;
                case gametype:
                    objInstance.setGameType(attrs.getValue(i));
                    break;
                case account:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setAccount(BigDecimal.valueOf(Double.valueOf(attrs.getValue(i))));
                    }
                    break;
                case betAmount:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setAccount(BigDecimal.valueOf(Double.valueOf(attrs.getValue(i))));
                    }
                    break;
                case valid_account:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setValidAccount(BigDecimal.valueOf(Double.valueOf(attrs.getValue(i))));
                    }
                    break;
                case validBetAmount:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setValidAccount(BigDecimal.valueOf(Double.valueOf(attrs.getValue(i))));
                    }
                    break;
                case cur_ip:
                    objInstance.setCurIp(attrs.getValue(i));
                    break;
                case betIP:
                    objInstance.setCurIp(attrs.getValue(i));
                    break;
                case reckontime:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        if (UtilConstants.K8.equals(platformId)) {
                            objInstance.setReckonTime(DateUtil.formatStr2Date(attrs.getValue(i)));
                        } else if (UtilConstants.HOGAME.equals(platformId)) {
                            objInstance.setReckonTime(ToolUtil.transferGMTDateToCNEsternDate(DateUtil.formatStr2Date(attrs.getValue(i))));
                        } else {
                            objInstance.setReckonTime(ToolUtil.transferUSEsternDateToCNEsternDate(DateUtil.formatStr2Date(attrs.getValue(i))));
                        }
                        objInstance.setOrignalReckonTime(DateUtil.formatStr2Date(attrs.getValue(i)));
                    } else {
                        log.info("current parse xml get reckontime is null,platform==>" + platformId);
                        objInstance.setReckonTime(objInstance.getBillTime() == null ? new Date() : objInstance.getBillTime());
                        objInstance.setOrignalReckonTime(objInstance.getOrignalBillTime() == null ? new Date() : objInstance.getOrignalBillTime());
                    }
                    break;
                case recalcuTime:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setReckonTime(ToolUtil.transferUSEsternDateToCNEsternDate(DateUtil.formatStr2Date(attrs.getValue(i))));
                        objInstance.setOrignalReckonTime(DateUtil.formatStr2Date(attrs.getValue(i)));
                    } else {
                        log.info("current parse xml get reckontime is null,platform==>" + platformId);
                        objInstance.setReckonTime(objInstance.getBillTime() == null ? new Date() : objInstance.getBillTime());
                        objInstance.setOrignalReckonTime(objInstance.getOrignalBillTime() == null ? new Date() : objInstance.getOrignalBillTime());
                    }
                    break;
                case playName:
                    objInstance.setLoginName(attrs.getValue(i));
                    break;
                case BASEPOINT:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setPreviosAmount(BigDecimal.valueOf(Double.valueOf(attrs.getValue(i))));
                    }
                    break;
                case username:
                    objInstance.setLoginName(attrs.getValue(i));
                    break;
                case productid:
                    objInstance.setProductId(attrs.getValue(i));
                    break;

                // extensional fields for player logout model
                case LOGINNAME:
                    objInstance.setLoginName(attrs.getValue(i));
                    break;
                case USERNAME:
                    objInstance.setLoginName(attrs.getValue(i));
                    break;
                case ACCOUNT:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setAccount(BigDecimal.valueOf(Double.valueOf(attrs.getValue(i))));
                    }
                    break;
                case VALID:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setValidAccount(BigDecimal.valueOf(Double.valueOf(attrs.getValue(i))));
                    }
                    break;
                case CUS_ACCOUNT:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setCusAccount(BigDecimal.valueOf(Double.valueOf(attrs.getValue(i))));
                    }
                    break;
                case devicetype:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setDeviceType(attrs.getValue(i));
                        if (UtilConstants.AGQJ.equals(platformId) || UtilConstants.AG2.equals(platformId)) {//AGQJ 只解析0-pc 1-AGQJ新版 32-Android
                            if (attrs.getValue(i).equals("1")) {
                                objInstance.setDeviceType("9");
                            }
                        } else if (UtilConstants.AGIN.equals(platformId)) {
                            //0=电脑，1=手机
                            objInstance.setDeviceType(attrs.getValue(i));
                        }
                    }
                    break;
                case device:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        if ("0".equals(attrs.getValue(i)) || "1".equals(attrs.getValue(i))) {
                            objInstance.setDeviceType("0");
                        } else {
                            objInstance.setDeviceType(attrs.getValue(i));
                        }
                    }
                    break;
                case deviceType:
                    objInstance.setDeviceType(attrs.getValue(i));
                    break;
                case bonus:
                    if (StringUtils.isNotBlank(attrs.getValue(i))) {
                        try {
                            BigDecimal bd = new BigDecimal(attrs.getValue(i));
                            objInstance.setBonusAmount(bd);
                        } catch (Exception ex) {
                            log.error("agqj连赢额度转化数字异常:" + attrs.getValue(i), ex);
                            objInstance.setBonusAmount(BigDecimal.ZERO);
                        }
                    }
                    break;
                case account_bonus:
                    if (StringUtils.isNotBlank(attrs.getValue(i))) {
                        try {
                            BigDecimal bd = new BigDecimal(attrs.getValue(i));
                            objInstance.setBonusAmount(bd);
                        } catch (Exception ex) {
                            log.error("agqj连赢额度转化数字异常:" + attrs.getValue(i), ex);
                            objInstance.setBonusAmount(BigDecimal.ZERO);
                        }
                    }
                    break;
                case srcbillno:
                    if (StringUtils.isNotBlank(attrs.getValue(i))) {
                        objInstance.setRemark(attrs.getValue(i));
                    }
                    break;
                case CREDIT:
                    if (StringUtils.isNotBlank(attrs.getValue(i))) {
                        objInstance.setBonusAmount(new BigDecimal(attrs.getValue(i)));
                    }
                    break;
                case PRODUCTID:
                    objInstance.setProductId(attrs.getValue(i));
                    break;
                case FLAG:
                    objInstance.setFlag(new Integer(attrs.getValue(i)));
                    break;
                case odds:
                    if (platformId.equals(UtilConstants.ORDERS_AGIN_SPORT)) {
                        // String odds="1499154989,3.46|1499154990,2.4|1499154991,3.85";
                        if (!StringUtils.isBlank(attrs.getValue(i))) {
                            String odds = attrs.getValue(i);
                            String[] oddsarray = odds.split("\\|");
                            //取最小赔率
                            BigDecimal o = new BigDecimal((oddsarray[0].split(","))[1]);
                            String[] oddDecimaArr = null;
                            for (String _t : oddsarray) {
                                oddDecimaArr = _t.split(",");
                                if (o.compareTo(new BigDecimal(oddDecimaArr[1])) > 0) {
                                    o = new BigDecimal(oddDecimaArr[1]);
                                }
                            }
                            objInstance.setOdds(o);
                        }
                        break;
                    }
                case simplified_result:
                    if (platformId.equals(UtilConstants.ORDERS_AGIN_SPORT)) {
                        if (objInstance.getFlag() == 1) {
                            String result = attrs.getValue(i);
                            result = result.toUpperCase();
                            if (result.contains("WIN")) {
                                objInstance.setResult("W: Win");
                                objInstance.setResultType("Win");
                            } else if (result.contains("LOSE")) {
                                objInstance.setResult("L: Lose");
                                objInstance.setResultType("Lose");
                            }
                        }
                    }
                    break;
                case RECKONTIME:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        if (UtilConstants.K8.equals(platformId)) {
                            objInstance.setReckonTime(DateUtil.formatStr2Date(attrs.getValue(i)));
                        } else if (UtilConstants.HOGAME.equals(platformId)) {
                            objInstance.setReckonTime(ToolUtil.transferGMTDateToCNEsternDate(DateUtil.formatStr2Date(attrs.getValue(i))));
                        } else {
                            objInstance.setReckonTime(ToolUtil.transferUSEsternDateToCNEsternDate(DateUtil.formatStr2Date(attrs.getValue(i))));
                        }
                        objInstance.setOrignalReckonTime(DateUtil.formatStr2Date(attrs.getValue(i)));
                    } else {
                        log.info("current parse xml get reckontime is null,platform==>" + platformId);
                        objInstance.setReckonTime(objInstance.getBillTime() == null ? new Date() : objInstance.getBillTime());
                        objInstance.setOrignalReckonTime(objInstance.getOrignalBillTime() == null ? new Date() : objInstance.getOrignalBillTime());
                    }
                    break;

                case src_amount: {
                    if (!StringUtils.isEmpty(attrs.getValue(i))) {
                        objInstance.setPreviosAmount(new BigDecimal(attrs.getValue(i)));
                    }
                    break;
                }

                case dst_amount: {
                    if (!StringUtils.isEmpty(attrs.getValue(i))) {
                        objInstance.setCurrentAmount(new BigDecimal(attrs.getValue(i)));
                    }
                    break;
                }
                case slottype: {
                    objInstance.setSlottype(attrs.getValue(i));
                    break;
                }
                default:
                    break;
            }
        }

//        if (UtilConstants.K8.equals(platformId)) {
//            if (new BigDecimal(0.0).doubleValue() == (objInstance.getCusAccount()).doubleValue()) {
//                objInstance.setValidAccount(BigDecimal.ZERO);
//            } else {
//                objInstance.setValidAccount(objInstance.getAccount());
//            }
//        }
        //KENO 经常出现longinName没有和productID分割开的情况，例如：	A05tniat998,需要将前面的A05去掉
        if (objInstance.getLoginName() != null && objInstance.getProductId() != null && objInstance.getLoginName().substring(0, 3).equals(objInstance.getProductId())) {
            objInstance.setLoginName(objInstance.getLoginName().substring(3));
        }
        return objInstance;
    }

    /**
     * Construct OrdersEntity for k8.
     *
     * @param attrs
     * @param claz
     * @param platformId
     * @throws IllegalArgumentException
     */
    public static OrderEntity constructOrdersForEaseHawaiiK8(Attributes attrs, String platformId, Class<Object> claz) throws IllegalArgumentException {
        int attrCount = attrs.getLength();
        OrderEntity objInstance = new OrderEntity();
        String attrName = null;
        OrdersEnum attrNameEnum = null;
        objInstance.setGameType(UtilConstants.GAME_TYPE_KENO);
        // remove by Alex on 2011-12-06 -begin
        /*
         * objInstance.setPlatId(platformId); if(platformId.equalsIgnoreCase(UtilConstants.K8)){
         * objInstance.setProductId(UtilConstants.PRODUCTID_BLM); }else{ objInstance.setProductId(UtilConstants.PRODUCTID_EH); }
         */
        // remove by Alex on 2011-12-06 -end
        for (int i = 0; i < attrCount; i++) {
            attrName = attrs.getQName(i);
            attrNameEnum = Enum.valueOf(OrdersEnum.class, attrName);
            switch (attrNameEnum) {
                case billno:
                    objInstance.setBillNo(attrs.getValue(i));
                    break;
                case loginname:
                    objInstance.setLoginName(attrs.getValue(i));
                    break;
                case agcode:
                    objInstance.setAgCode(attrs.getValue(i));
                    if (!StringUtils.isBlank(objInstance.getAgCode())) {
                        objInstance.setTopAgCode((objInstance.getAgCode()).substring(0, 3));
                        // add by Alex on 2011-12-06 -begin
                        if (UtilConstants.AGCODE_K8_BTT.equals(objInstance.getTopAgCode())) {
                            objInstance.setPlatId(UtilConstants.K8);
                            objInstance.setProductId(UtilConstants.PRODUCTID_BLM);
                        } else if (UtilConstants.AGCODE_K8_HWX.equals(objInstance.getTopAgCode())) {
                            objInstance.setPlatId(UtilConstants.K8_EH);
                            objInstance.setProductId(UtilConstants.PRODUCTID_EH);
                        }
                        // add by Alex on 2011-12-06 -end
                    }
                    break;
                case gmcode:
                    objInstance.setGmCode(attrs.getValue(i));
                    break;
                case cus_account:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setCusAccount(BigDecimal.valueOf(Double.valueOf(attrs.getValue(i))));
                    }
                    break;
                case billtime:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setBillTime(DateUtil.formatStr2Date(attrs.getValue(i)));
                    }
                    break;
                case flag:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setFlag(Integer.parseInt(attrs.getValue(i)));
                    }
                    break;
                case hascode:
                    objInstance.setHashCode(attrs.getValue(i));
                    break;
                case remark:
                    objInstance.setRemark(attrs.getValue(i));
                    break;
                case playtype:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setPlayType(Integer.parseInt(attrs.getValue(i)));
                    }
                    break;
                case currency:
                    if (attrs.getValue(i) != null) {
                        objInstance.setCurrency(attrs.getValue(i));
                    }
                    break;
                case tablecode:
                    objInstance.setTableCode(attrs.getValue(i));
                    break;
                case round:
                    objInstance.setRound(attrs.getValue(i));
                    break;
                case gametype:
                    objInstance.setGameType(attrs.getValue(i));
                    break;
                case account:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setAccount(BigDecimal.valueOf(Double.valueOf(attrs.getValue(i))));
                    }
                    break;
                case valid_account:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setValidAccount(BigDecimal.valueOf(Double.valueOf(attrs.getValue(i))));
                    }
                    break;
                case cur_ip:
                    objInstance.setCurIp(attrs.getValue(i));
                    break;
                case reckontime:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setReckonTime(DateUtil.formatStr2Date(attrs.getValue(i)));
                    }
                    break;
                default:
                    break;
            }
        }
        return objInstance;
    }

    /**
     * Construct OrdersEntity for hogame.
     *
     * @param orderEntity
     * @param tagName
     * @param cotent
     * @param platformId
     * @throws IllegalArgumentException
     */
    public static void constructOrdersForHoGame(OrderEntity orderEntity, String tagName, String cotent, String platformId)
            throws IllegalArgumentException {
        orderEntity.setPlatId(platformId);
        orderEntity.setFlag(1);
        HGOrdersEnum tagNameEnum = null;
        try {
            tagNameEnum = Enum.valueOf(HGOrdersEnum.class, tagName);
        } catch (Exception e) {
            log.error("ObjectConstructUtil constructOrdersForHoGame error:" + e.getMessage(), e);
            return;
        }

        switch (tagNameEnum) {
            case BetStartDate:
                String timeString = cotent.replaceAll(UtilConstants.OBLIQUE_LINE, UtilConstants.TRANSVERSE_LINE);
                orderEntity.setBillTime(ToolUtil.transferGMTDateToCNEsternDate(DateUtil.formatStr2Date(timeString)));
                orderEntity.setOrignalBillTime(DateUtil.formatStr2Date(timeString));
                orderEntity.setReckonTime(orderEntity.getBillTime());
                break;
            case BetEndDate:
                break;
            case AccountId:
                orderEntity.setLoginName(cotent);
                break;
            case TableId:
                // orderEntity.setTableCode(cotent);
                break;
            case GameId:
                orderEntity.setGmCode(cotent);
                break;
            case BetId:
                orderEntity.setBillNo(cotent);
                break;
            case BetAmount:
                orderEntity.setAccount(BigDecimal.valueOf(Double.valueOf(cotent)));
                orderEntity.setValidAccount(BigDecimal.valueOf(Double.valueOf(cotent)));
                break;
            case Payout:
                orderEntity.setCusAccount(BigDecimal.valueOf(Double.valueOf(cotent)));
                break;
            case Currency:
                if (UtilConstants.RMB.equalsIgnoreCase(cotent)) {
                    orderEntity.setCurrency(UtilConstants.CNY);
                } else {
                    orderEntity.setCurrency(cotent);
                }
                break;
            case GameType:
                orderEntity.setGameType(cotent);
                break;
            case BetSpot:
                // orderEntity.setPlayType(cotent);
                break;
            case BetNo:
                orderEntity.setBillNo(cotent);
                break;
            case TableName:
                orderEntity.setTableCode(cotent);
                break;
            default:
                break;
        }
    }

    /**
     * Construct BaGameEntity
     *
     * @param attrs
     * @param claz
     * @return
     * @throws IllegalArgumentException
     */
    public static BaGameEntity constructBaGame(Attributes attrs, String platformId, Class<Object> claz) throws IllegalArgumentException {
        int attrCount = attrs.getLength();
        BaGameEntity objInstance = new BaGameEntity();
        String attrName = null;
        BaGameEnum attrNameEnum = null;
        objInstance.setPlatId(platformId);
        objInstance.setLoginName(UtilConstants.ZERO_STR);
        for (int i = 0; i < attrCount; i++) {
            attrName = attrs.getQName(i);
            if (EnumUtils.isValidEnum(BaGameEnum.class, attrName)) {
                attrNameEnum = Enum.valueOf(BaGameEnum.class, attrName);
            } else {
                continue;
            }

            switch (attrNameEnum) {
                case gmcode:
                    objInstance.setGmCode(attrs.getValue(i));
                    break;
                case begintime:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        if (!UtilConstants.K8.equals(platformId)) {
                            objInstance.setBeginTime(ToolUtil.transferUSEsternDateToCNEsternDate(DateUtil.formatStr2Date(attrs.getValue(i))));
                            objInstance.setOrignalBeginTime(DateUtil.formatStr2Date(attrs.getValue(i)));
                        } else {
                            objInstance.setBeginTime(DateUtil.formatStr2Date(attrs.getValue(i)));
                            objInstance.setOrignalBeginTime(DateUtil.formatStr2Date(attrs.getValue(i)));
                        }
                    }
                    break;
                case closetime:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        if (!UtilConstants.K8.equals(platformId)) {
                            objInstance.setCloseTime(ToolUtil.transferUSEsternDateToCNEsternDate(DateUtil.formatStr2Date(attrs.getValue(i))));
                            objInstance.setOrignalBeginTime(DateUtil.formatStr2Date(attrs.getValue(i)));
                        } else {
                            objInstance.setBeginTime(DateUtil.formatStr2Date(attrs.getValue(i)));
                            objInstance.setOrignalBeginTime(DateUtil.formatStr2Date(attrs.getValue(i)));
                        }
                    }
                    break;
                case endtime:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        if (!UtilConstants.K8.equals(platformId)) {
                            objInstance.setCloseTime(ToolUtil.transferUSEsternDateToCNEsternDate(DateUtil.formatStr2Date(attrs.getValue(i))));
                            objInstance.setOrignalCloseTime(DateUtil.formatStr2Date(attrs.getValue(i)));
                        } else {
                            objInstance.setCloseTime(DateUtil.formatStr2Date(attrs.getValue(i)));
                            objInstance.setOrignalCloseTime(DateUtil.formatStr2Date(attrs.getValue(i)));
                        }
                    }
                    break;
                case dealer:
                    objInstance.setDealer(attrs.getValue(i));
                    break;
                case gametype:
                    objInstance.setGameType(attrs.getValue(i));
                    break;
                case bankerpoint:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setBankerPoint(attrs.getValue(i));
                    }
                    break;
                case playerpoint:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setPlayerPoint(attrs.getValue(i));
                    }
                    break;
                case cardnum:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setCardNum(Integer.parseInt(attrs.getValue(i)));
                    }
                    break;
                case pair:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setPair(Integer.parseInt(attrs.getValue(i)));
                    }
                    break;
                case dragonpoint:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setDragonPoint(attrs.getValue(i));
                    }
                    break;
                case tigerpoint:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setTigerPoint(attrs.getValue(i));
                    }
                    break;
                case cardlist:
                    objInstance.setCardList(attrs.getValue(i));
                    break;
                case vid:
                    objInstance.setVideoId(attrs.getValue(i));
                    break;
                case shoecode:
                    objInstance.setShoeCode(attrs.getValue(i));
                    break;
                case flag:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setFlag(Integer.parseInt(attrs.getValue(i)));
                    }
                    break;
                default:
                    break;
            }
        }
        return objInstance;
    }

    public static OrderAGQJExceptionor constructAGQJExceptionorOrders(Attributes attrs, String platformId, Class<Object> claz) throws IllegalArgumentException {
        int attrCount = attrs.getLength();
        OrderAGQJExceptionor objInstance = new OrderAGQJExceptionor();
        objInstance.setPlatformId(platformId);
        AGQJOrdersExceptionorEnum attrNameEnum;
        for (int i = 0; i < attrCount; i++) {
            String attrName = attrs.getQName(i);
            if (EnumUtils.isValidEnum(AGQJOrdersExceptionorEnum.class, attrName)) {
                attrNameEnum = Enum.valueOf(AGQJOrdersExceptionorEnum.class, attrName);
            } else {
                continue;
            }
            switch (attrNameEnum) {
                case billno:
                    objInstance.setBillNo(attrs.getValue(i));
                    break;
                case loginname:
                    objInstance.setLoginName(attrs.getValue(i));
                    break;
                case productid:
                    objInstance.setProductId(attrs.getValue(i));
                    break;
                case gmcode:
                    if (StringUtils.isNotBlank(attrs.getValue(i))) {
                        objInstance.setGmCode(attrs.getValue(i));
                    }
                    break;
                case orig_playtype:
                    if (StringUtils.isNotBlank(attrs.getValue(i))) {
                        objInstance.setOrigPlaytype(attrs.getValue(i));
                    }
                    break;
                case rec_playtype:
                    if (StringUtils.isNotBlank(attrs.getValue(i))) {
                        objInstance.setRecPlaytype(attrs.getValue(i));
                    }
                    break;
                case orig_remark:
                    if (StringUtils.isNotBlank(attrs.getValue(i))) {
                        objInstance.setOrigRemark(attrs.getValue(i));
                    }
                    break;
                case rec_remark:
                    if (StringUtils.isNotBlank(attrs.getValue(i))) {
                        objInstance.setRecRemark(attrs.getValue(i));
                    }
                    break;
                case orig_accout:
                    if (StringUtils.isNotBlank(attrs.getValue(i))) {
                        objInstance.setOrigAccout(new BigDecimal(attrs.getValue(i)));
                    }
                    break;
                case rec_account:
                    if (StringUtils.isNotBlank(attrs.getValue(i))) {
                        objInstance.setRecAccount(new BigDecimal(attrs.getValue(i)));
                    }
                    break;
                case jointime:
                    if (StringUtils.isNotBlank(attrs.getValue(i))) {
                        objInstance.setJoinTime(ToolUtil.transferUSEsternDateToCNEsternDate(DateUtil.formatStr2Date(attrs.getValue(i))));
                    }
                    break;
                case errcode:
                    if (StringUtils.isNotBlank(attrs.getValue(i))) {
                        objInstance.setErrcode(Integer.parseInt(attrs.getValue(i)));
                    }
                    break;
                case gametype:
                    if (StringUtils.isNotBlank(attrs.getValue(i))) {
                        objInstance.setGameType(attrs.getValue(i));
                    }
                    break;
                default:
                    break;
            }
        }
        return objInstance;
    }

    /**
     * Construct K8GameEntity
     *
     * @param attrs
     * @param claz
     * @return
     * @throws IllegalArgumentException
     */
    public static K8GameEntity constructK8Game(Attributes attrs, String platformId, Class<Object> claz) throws IllegalArgumentException {
        int attrCount = attrs.getLength();
        K8GameEntity objInstance = new K8GameEntity();
        String attrName = null;
        K8GameEnum attrNameEnum = null;
        objInstance.setPlatId(platformId);
        for (int i = 0; i < attrCount; i++) {
            attrName = attrs.getQName(i);
            attrNameEnum = Enum.valueOf(K8GameEnum.class, attrName);
            switch (attrNameEnum) {
                case gmcode:
                    objInstance.setGmCode(attrs.getValue(i));
                    break;
                case begintime:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setBeginTime(DateUtil.formatStr2Date(attrs.getValue(i)));
                    }
                    break;
                case endtime:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setEndTime(DateUtil.formatStr2Date(attrs.getValue(i)));
                    }
                    break;
                case round:
                    objInstance.setRound(attrs.getValue(i));
                    break;
                case total_sum:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setTotalSum(Integer.parseInt(attrs.getValue(i)));
                    }
                    break;
                case total_odd:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setTotalOdd(Integer.parseInt(attrs.getValue(i)));
                    }
                    break;
                case total_down:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setTotalDown(Integer.parseInt(attrs.getValue(i)));
                    }
                    break;
                case result:
                    objInstance.setResult(attrs.getValue(i));
                    break;
                default:
                    break;
            }
        }
        return objInstance;
    }

    /**
     * Construct K8GameEntity
     *
     * @param attrs
     * @param claz
     * @return
     * @throws IllegalArgumentException
     */
    public static PlayerEntity constructPlayerEntity(Attributes attrs, String platformId, Class<Object> claz) throws IllegalArgumentException {
        int attrCount = attrs.getLength();
        PlayerEntity objInstance = new PlayerEntity();
        String attrName = null;
        PlayerEnum attrNameEnum = null;
        for (int i = 0; i < attrCount; i++) {
            attrName = attrs.getQName(i);
            // add by edwin on 2013-05-31
            for (PlayerEnum pe : PlayerEnum.values()) {
                if (pe.toString().equalsIgnoreCase(attrName)) {
                    attrNameEnum = Enum.valueOf(PlayerEnum.class, attrName);
                    switch (attrNameEnum) {
                        case AGCODE:
                            objInstance.setAgentCode(attrs.getValue(i));
                            break;
                        case LOGINNAME:
                            objInstance.setPlayerName(attrs.getValue(i));
                            break;
                        case REALNAME:
                            objInstance.setRealName(attrs.getValue(i));
                            break;
                        case ALIASNAME:
                            objInstance.setAliasName(attrs.getValue(i));
                            break;
                        case CREDIT:
                            objInstance.setCurrentAmount(attrs.getValue(i));
                            break;
                        case FLAG:
                            objInstance.setIsValid(attrs.getValue(i));
                            break;
                        case JOINTIME:
                            objInstance.setRegisterTime(attrs.getValue(i));
                            break;
                        case BEFORELOGINTIME:
                            objInstance.setBeforeLoginTime(attrs.getValue(i));
                            break;
                        case BEFORELOGINIP:
                            objInstance.setBeforeLoginIp(attrs.getValue(i));
                            break;
                        case LASTLOGINTIME:
                            objInstance.setLastLoginTime(attrs.getValue(i));
                            break;
                        case LASTLOGINIP:
                            objInstance.setLastLiginIp(attrs.getValue(i));
                            break;
                        case LOGINTIMES:
                            objInstance.setLoginTimes(attrs.getValue(i));
                            break;
                        case E_PER:
                            break;
                        case E_DIS:
                            break;
                        case D_PER:
                            break;
                        case D_DIS:
                            break;
                        case C_PER:
                            break;
                        case C_DIS:
                            break;
                        case B_PER:
                            break;
                        case B_DIS:
                            break;
                        case A_PER:
                            break;
                        case A_DIS:
                            break;
                        case AGNAME:
                            objInstance.setAgentName(attrs.getValue(i));
                            break;
                        case USERNAME:
                            objInstance.setPlayerName(attrs.getValue(i));
                            break;
                        case PRODUCTID:
                            objInstance.setProductId(attrs.getValue(i));
                            break;
                        default:
                            break;

                    }
                }
            }
        }
        return objInstance;
    }

    /**
     * Construct {@link BaGameEntity} for hogame.
     *
     * @param baGameEntity
     * @param tagName
     * @param cotent
     * @param platformId
     * @throws IllegalArgumentException
     */
    public static void constructGameResultForHoGame(BaGameEntity baGameEntity, String tagName, String cotent, String platformId)
            throws IllegalArgumentException {
        baGameEntity.setPlatId(platformId);
        // baGameEntity.setProductId(UtilConstants.PRODUCTID_MT);
        for (HGGameResultEnum pe : HGGameResultEnum.values()) {
            if (pe.toString().equalsIgnoreCase(tagName)) {
                HGGameResultEnum tagNameEnum = Enum.valueOf(HGGameResultEnum.class, tagName);
                switch (tagNameEnum) {
                    case Game_Id:
                        baGameEntity.setGmCode(cotent);
                        break;
                    case StartTime:
                        baGameEntity
                                .setBeginTime(ToolUtil.transferGMTDateToCNEsternDate(DateUtil.formatStr2Date(cotent, DateUtil.A_TIME_PATTON_DEFAULT2)));
                        baGameEntity.setOrignalBeginTime(DateUtil.formatStr2Date(cotent, DateUtil.A_TIME_PATTON_DEFAULT2));
                        break;
                    case EndTime:
                        baGameEntity
                                .setCloseTime(ToolUtil.transferGMTDateToCNEsternDate(DateUtil.formatStr2Date(cotent, DateUtil.A_TIME_PATTON_DEFAULT2)));
                        baGameEntity.setOrignalCloseTime(DateUtil.formatStr2Date(cotent, DateUtil.A_TIME_PATTON_DEFAULT2));
                        break;
                    case AccountID:
                        baGameEntity.setLoginName(cotent);
                        break;
                    case Result:
                        baGameEntity.setCardList(cotent);
                        break;
                    case GameType_Id:
                        // baGameEntity.setGameType(cotent);
                        break;
                    case Dealer:
                        baGameEntity.setDealer(cotent);
                        break;
                    case BankerPoint:
                        baGameEntity.setBankerPoint(cotent);
                        break;
                    case PlayerPoint:
                        baGameEntity.setPlayerPoint(cotent);
                        break;
                    case Tie:
                        break;
                    case DragonPoint:
                        baGameEntity.setDragonPoint(cotent);
                        break;
                    case TigerPoint:
                        baGameEntity.setTigerPoint(cotent);
                        break;
                    default:
                        break;
                }
            }
        }
    }

    /**
     * Construct AccountTransferEntity.
     *
     * @param claz
     * @param platformId
     * @throws IllegalArgumentException
     */
    public static AccountTransferEntity constructAccountTransfer(Attributes attrs, String platformId, Class<Object> claz)
            throws IllegalArgumentException {
        int attrCount = attrs.getLength();
        AccountTransferEntity objInstance = new AccountTransferEntity();
        String attrName = null;
        AccountTransferEnum attrNameEnum = null;
        objInstance.setPlatformId(platformId);
        for (int i = 0; i < attrCount; i++) {
            attrName = attrs.getQName(i);
            attrNameEnum = Enum.valueOf(AccountTransferEnum.class, attrName);
            switch (attrNameEnum) {
                case TradeNo:
                    break;
                case UserName:
                    objInstance.setUserName(attrs.getValue(i));
                case CreateTime:
                    if (!UtilConstants.K8.equals(platformId) && !UtilConstants.K8_EH.equals(platformId)) {
                        objInstance.setCreationTime(ToolUtil.transferUSEsternDateToCNEsternDate(DateUtil.formatStr2Date(attrs.getValue(i))));
                        objInstance.setOrignalCreationTime(DateUtil.formatStr2Date(attrs.getValue(i)));
                    } else {
                        objInstance.setCreationTime(DateUtil.formatStr2Date(attrs.getValue(i), DateUtil.A_TIME_PATTON_DEFAULT1));
                    }
                    break;
                case TransType:
                    objInstance.setTransferType(attrs.getValue(i));
                    break;
                case Name:
                    objInstance.setName(attrs.getValue(i));
                    break;
                case Amount:
                    objInstance.setTransferAmount(BigDecimal.valueOf(Double.valueOf(attrs.getValue(i))));
                    break;
                case Src_Amount:
                    objInstance.setPreviousAmount(BigDecimal.valueOf(Double.valueOf(attrs.getValue(i))));
                    break;
                case Balance:
                    objInstance.setCurrentAmount(BigDecimal.valueOf(Double.valueOf(attrs.getValue(i))));
                    break;
                case WagersID:
                    objInstance.setWagerId(attrs.getValue(i));
                    break;
                case BalanceType:
                    objInstance.setBalanceType(Integer.parseInt(attrs.getValue(i)));
                    break;
                case IP:
                    objInstance.setIP(attrs.getValue(i));
                    break;
                case Currency:
                    objInstance.setCurrency(attrs.getValue(i));
                    break;
                case ExchangeRate:
                    objInstance.setExchangeRate(BigDecimal.valueOf(Double.valueOf(attrs.getValue(i))));
                    break;
                case TransID:
                    objInstance.setTransId(attrs.getValue(i));
                    break;
                case Flag:
                    objInstance.setFlag(Integer.parseInt(attrs.getValue(i)));
                    break;
                default:
                    break;
            }
        }
        return objInstance;
    }

    /**
     * Construct AccountTransfer4HgEntity for A06 HG.
     *
     * @param claz
     * @param platformId
     * @throws IllegalArgumentException
     */
    public static AccountTransfer4HgEntity constructAccountTransfer4Hogaming(Attributes attrs, String platformId, Class<Object> claz) {
        String nodeValue = null;
        String attrName = null;
        AccountTransfer4A06Enum attrNameEnum = null;
        int attrCount = attrs.getLength();
        AccountTransfer4HgEntity objInstance = new AccountTransfer4HgEntity();
        objInstance.setPlatformId(platformId);
        objInstance.setFlag(1);
        try {
            for (int i = 0; i < attrCount; i++) {
                nodeValue = attrs.getValue(i);
                attrName = attrs.getQName(i);
                attrNameEnum = Enum.valueOf(AccountTransfer4A06Enum.class, attrName);
                switch (attrNameEnum) {
                    case currency:
                        objInstance.setCurrency(nodeValue);
                        break;
                    case afteramount:
                        objInstance.setAfterAmount(BigDecimal.valueOf(Double.valueOf(nodeValue)));
                        break;
                    case transferamount:
                        objInstance.setTransferAmount(BigDecimal.valueOf(Double.valueOf(nodeValue)));
                        break;
                    case previousamount:
                        objInstance.setPreviousAmount(BigDecimal.valueOf(Double.valueOf(nodeValue)));
                        break;
                    case transfertype:
                        // only for special logic
                        /*
                         * objInstance.setRemark(nodeValue); if(UtilConstants.TRANSFER_TYPE_HG_IN.equalsIgnoreCase(nodeValue)){
                         * objInstance.setTransferType(UtilConstants.TRANSFER_TYPE_IN); }else
                         * if(UtilConstants.TRANSFER_TYPE_HG_OUT.equalsIgnoreCase(nodeValue) ||
                         * UtilConstants.TRANSFER_TYPE_HG_WITHFRAW.equalsIgnoreCase(nodeValue)){
                         * objInstance.setTransferType(UtilConstants.TRANSFER_TYPE_OUT); }else
                         * if(UtilConstants.TRANSFER_TYPE_HG_BET.equalsIgnoreCase(nodeValue)){
                         * objInstance.setTransferType(UtilConstants.TRANSFER_TYPE_BET); }else
                         * if(UtilConstants.TRANSFER_TYPE_HG_RECKON_WIN.equalsIgnoreCase(nodeValue)){
                         * objInstance.setTransferType(UtilConstants.TRANSFER_TYPE_RECKON); }else
                         * if(UtilConstants.TRANSFER_TYPE_HG_RECKON_LOS.equalsIgnoreCase(nodeValue)){
                         * objInstance.setTransferType(UtilConstants.TRANSFER_TYPE_RECKON); }else
                         * if(UtilConstants.TRANSFER_TYPE_HG_CANCEL_BET.equalsIgnoreCase(nodeValue)){
                         * objInstance.setTransferType(UtilConstants.TRANSFER_TYPE_CANCEL_BET); objInstance.setFlag(0); }else{
                         * objInstance.setTransferType(nodeValue); }
                         */
                        if (UtilConstants.TRANSFER_TYPE_HG_CANCEL_BET.equalsIgnoreCase(nodeValue)) {
                            objInstance.setFlag(0);
                        }
                        objInstance.setTransferType(nodeValue);
                        break;
                    case creationdate:
                        // It is GMT time zone for A06 HG
                        objInstance.setCreationTime(ToolUtil.transferGMTDateToCNEsternDate(DateUtil.formatStr2Date(nodeValue)));
                        break;
                    case gameid:
                        objInstance.setGameId(nodeValue);
                        break;
                    case gametype:
                        objInstance.setGameType(nodeValue);
                        break;
                    case target:
                        objInstance.setTarget(nodeValue);
                        break;
                    case source:
                        objInstance.setSource(nodeValue);
                        break;
                    case tradeno:
                        objInstance.setTradeNo(nodeValue);
                        break;
                    case transactionid:
                        objInstance.setTransactionId(nodeValue);
                        break;
                    case loginname:
                        objInstance.setLoginName(nodeValue);
                        break;
                    case platformid:
                        // objInstance.setPlatformId(nodeValue);
                        break;
                    case productid:
                        objInstance.setProductId(nodeValue);
                        break;
                    default:
                        break;
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return objInstance;
    }

    /**
     * Construct Object instance by loop XML node.
     *
     * @param accountTransferEntity
     * @param tagName
     * @param platformId
     * @param claz
     * @return Object
     */
    public static void readNodesForAccountTransfer(AccountTransferEntity accountTransferEntity, String tagName, String cotent, String platformId,
                                                   Class<Object> claz) {
        try {
            accountTransferEntity.setPlatformId(platformId);
            if (platformId.equalsIgnoreCase(UtilConstants.BBIN_BLM)) {
                accountTransferEntity.setProductId(UtilConstants.PRODUCT_ENUM.A01.toString());
            } else if (platformId.equalsIgnoreCase(UtilConstants.BBIN_MT)) {
                accountTransferEntity.setProductId(UtilConstants.PRODUCT_ENUM.A02.toString());
            } else if (platformId.equalsIgnoreCase(UtilConstants.BBIN_ZL)) {
                accountTransferEntity.setProductId(UtilConstants.PRODUCT_ENUM.A04.toString());
            } else if (platformId.equalsIgnoreCase(UtilConstants.BBIN_LL)) {
                accountTransferEntity.setProductId(UtilConstants.PRODUCT_ENUM.A05.toString());
            } else if (platformId.equalsIgnoreCase(UtilConstants.BBIN_HJ)) {
                accountTransferEntity.setProductId(UtilConstants.PRODUCTID_HJ);
            } else if (platformId.equalsIgnoreCase(UtilConstants.BBIN_WH)) {
                accountTransferEntity.setProductId(UtilConstants.PRODUCT_ENUM.C01.toString());
            } else if (platformId.equalsIgnoreCase(UtilConstants.BBIN_BJH_NEW)) {
                accountTransferEntity.setProductId(UtilConstants.PRODUCTID_BJH_NEW);
            } else if (platformId.equalsIgnoreCase(UtilConstants.BBIN_HWX)) {
                accountTransferEntity.setProductId(UtilConstants.PRODUCT_ENUM.A03.toString());
            } else if (platformId.equalsIgnoreCase(UtilConstants.BBIN_KB)) {
                accountTransferEntity.setProductId(UtilConstants.PRODUCT_ENUM.A06.toString());
            } else if (platformId.equalsIgnoreCase(UtilConstants.BBIN_HJHA)) {
                accountTransferEntity.setProductId(UtilConstants.PRODUCT_ENUM.C02.toString());
                accountTransferEntity.setPlatformId(UtilConstants.BBIN_HJHA);
            } else if (platformId.equalsIgnoreCase(UtilConstants.ACCOUNT_TRANSFER_BBIN_E02)) {
                accountTransferEntity.setProductId(UtilConstants.PRODUCT_ENUM.E02.toString());
                accountTransferEntity.setPlatformId(UtilConstants.BBIN_BLM);
            } else if (platformId.equalsIgnoreCase(UtilConstants.ACCOUNT_TRANSFER_BBIN_E03)) {
                accountTransferEntity.setProductId(UtilConstants.PRODUCT_ENUM.E03.toString());
                accountTransferEntity.setPlatformId(UtilConstants.BBIN_BLM);
            } else if (platformId.equalsIgnoreCase(UtilConstants.ACCOUNT_TRANSFER_BBIN_E04)) {
                accountTransferEntity.setProductId(UtilConstants.PRODUCT_ENUM.E04.toString());
                accountTransferEntity.setPlatformId(UtilConstants.BBIN_BLM);
            } else if (platformId.equalsIgnoreCase(UtilConstants.ACCOUNT_TRANSFER_BBIN_B01)) {
                accountTransferEntity.setProductId(UtilConstants.PRODUCT_ENUM.B01.toString());
                accountTransferEntity.setPlatformId(UtilConstants.BBIN_BLM);
            } else if (platformId.equalsIgnoreCase(UtilConstants.ACCOUNT_TRANSFER_BBIN_B79)) {
                accountTransferEntity.setProductId(UtilConstants.PRODUCT_ENUM.B79.toString());
                accountTransferEntity.setPlatformId(UtilConstants.BBIN_BLM);
            } else if (platformId.equalsIgnoreCase(UtilConstants.ACCOUNT_TRANSFER_AG)) {
                accountTransferEntity.setPlatformId(UtilConstants.AGQJ);
            }

            AccountTransferEnum tagNameEnum = null;
            if (EnumUtils.isValidEnum(AccountTransferEnum.class, tagName)) {
                tagNameEnum = Enum.valueOf(AccountTransferEnum.class, tagName);
            }

            switch (tagNameEnum) {
                case TradeNo:
                    accountTransferEntity.setTradeNo(cotent);
                    break;
                case UserName:
                    accountTransferEntity.setUserName(cotent);
                    break;
                case username:
                    accountTransferEntity.setUserName(cotent);
                    break;
                case CreateTime:
                    if (cotent.length() == 10) {
                        cotent += UtilConstants.PREFIX_TIME_STRING;
                    }
                    if (UtilConstants.K8.equals(platformId) || UtilConstants.K8_EH.equals(platformId)) {
                        Date creationTime = DateUtil.formatStr2Date(cotent, DateUtil.A_TIME_PATTON_DEFAULT1);
                        if (creationTime == null) {
                            creationTime = DateUtil.formatStr2Date(cotent);
                        }
                        accountTransferEntity.setCreationTime(creationTime);
                        accountTransferEntity.setOrignalCreationTime(creationTime);
                    } else if (platformId.equalsIgnoreCase(UtilConstants.SHABA_UK) || platformId.equalsIgnoreCase(UtilConstants.AMAYA_FCLRC)
                            || platformId.equalsIgnoreCase(UtilConstants.MG)
                            || platformId.equalsIgnoreCase(UtilConstants.BSG)
                            || platformId.equalsIgnoreCase(UtilConstants.BSG_VIP)
                            || platformId.equalsIgnoreCase(UtilConstants.RGS)
                            || platformId.equalsIgnoreCase(UtilConstants.VMG)
                            || platformId.equalsIgnoreCase(UtilConstants.MG_VIP)
                            || platformId.equalsIgnoreCase(UtilConstants.SBT)
                            || platformId.equalsIgnoreCase(UtilConstants.AMAYA_VIP_FCLRC)
                            || platformId.equalsIgnoreCase(UtilConstants.NETENT)
                            || platformId.equalsIgnoreCase(UtilConstants.PNG)
                            || platformId.equalsIgnoreCase(UtilConstants.PPG)
                            || platformId.equalsIgnoreCase(UtilConstants.CQ9)
                            || platformId.equalsIgnoreCase(UtilConstants.YSB)
                            || platformId.equalsIgnoreCase(UtilConstants.NB)
                            || platformId.equalsIgnoreCase(UtilConstants.PB)
                            ) {
                        // Change GMT time to GMT-8 time
                        accountTransferEntity.setCreationTime(ToolUtil.transferGMTDateToCNEsternDate(DateUtil.formatStr2Date(cotent)));
                        accountTransferEntity.setOrignalCreationTime(ToolUtil.transferGMTDateToCNEsternDate(DateUtil.formatStr2Date(cotent)));
                    } else {
                        accountTransferEntity.setCreationTime(ToolUtil.transferUSEsternDateToCNEsternDate(DateUtil.formatStr2Date(cotent)));
                        accountTransferEntity.setOrignalCreationTime(DateUtil.formatStr2Date(cotent));
                    }
                    break;
                case TransType:
                    if (UtilConstants.TRANSFER_TYPE_OUT_CN.equals(cotent)) {
                        accountTransferEntity.setTransferType(UtilConstants.TRANSFER_TYPE_OUT);
                    } else if (UtilConstants.TRANSFER_TYPE_IN_CN.equals(cotent)) {
                        accountTransferEntity.setTransferType(UtilConstants.TRANSFER_TYPE_IN);
                    } else if (UtilConstants.TRANSFER_TYPE_AMAYA_WITHFRAW.equals(cotent)) {
                        accountTransferEntity.setTransferType(UtilConstants.TRANSFER_TYPE_OUT);
                    } else if (UtilConstants.TRANSFER_TYPE_AMAYA_DEPOSIT.equals(cotent)) {
                        accountTransferEntity.setTransferType(UtilConstants.TRANSFER_TYPE_IN);
                    } else {
                        accountTransferEntity.setTransferType(cotent);
                    }
                    break;
                case Name:
                    accountTransferEntity.setName(cotent);
                    break;
                case Amount:
                    if (cotent != null) {
                        accountTransferEntity.setTransferAmount(BigDecimal.valueOf(Double.valueOf(cotent)));
                    }
                    break;
                case Src_Amount:
                    if (cotent != null) {
                        accountTransferEntity.setPreviousAmount(BigDecimal.valueOf(Double.valueOf(cotent)));
                    }
                    break;
                case Balance:
                    if (cotent != null) {
                        accountTransferEntity.setCurrentAmount(BigDecimal.valueOf(Double.valueOf(cotent)));
                    }
                    break;
                case WagersID:
                    accountTransferEntity.setWagerId(cotent);
                    break;
                case BalanceType:
                    accountTransferEntity.setBalanceType(Integer.parseInt(cotent));
                    break;
                case IP:
                    accountTransferEntity.setIP(cotent);
                    break;
                case Currency:
                    if (cotent != null) {
                        if (UtilConstants.RMB.equalsIgnoreCase(cotent)) {
                            accountTransferEntity.setCurrency(UtilConstants.CNY);
                        } else {
                            accountTransferEntity.setCurrency(cotent.toUpperCase());
                        }
                    }
                    break;
                case ExchangeRate:
                    if (cotent != null) {
                        accountTransferEntity.setExchangeRate(BigDecimal.valueOf(Double.valueOf(cotent)));
                    }
                    break;
                case TransID:
                    if (cotent != null && cotent.indexOf(UtilConstants.SEMICOLON) != -1) {
                        accountTransferEntity.setRemark((cotent.split(UtilConstants.SEMICOLON))[1]);
                    } else if (cotent != null && cotent.indexOf(UtilConstants.COLON) != -1) { // for
                        // recalculating
                        // failure
                        // only.
                        accountTransferEntity.setRemark(cotent);
                    } else {
                        accountTransferEntity.setTransId(cotent);
                    }
                    break;
                case Flag:
                    accountTransferEntity.setFlag(Integer.parseInt(cotent));
                    break;
                case agcode:
                    accountTransferEntity.setAgCode(cotent);
                    accountTransferEntity.setTopAgCode(cotent.substring(0, 3));
                    break;
                case ProductID:
                    accountTransferEntity.setProductId(cotent);
                    break;
                case Remark:
                    accountTransferEntity.setRemark(cotent);
                    break;
                default:
                    break;
            }
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
        }
    }

    /**
     * Construct {@link BaGameEntity} for hogame.
     *
     * @param accountTransferEntity
     * @param tagName
     * @param cotent
     * @param platformId
     * @throws IllegalArgumentException
     */
    public static void constructAccountTransferForHoGame(AccountTransferEntity accountTransferEntity, String tagName, String cotent, String platformId)
            throws IllegalArgumentException {
        try {
            accountTransferEntity.setPlatformId(platformId);
            // accountTransferEntity.setProductId(UtilConstants.PRODUCTID_MT);
            HGAccountTransferEnum tagNameEnum = Enum.valueOf(HGAccountTransferEnum.class, tagName);
            switch (tagNameEnum) {
                case Accountid:
                    accountTransferEntity.setUserName(cotent);
                    break;
                case email_address:
                    break;
                case transact_id:
                    accountTransferEntity.setTransId(cotent);
                    break;
                case transacttype_code:
                    accountTransferEntity.setTransferType(cotent);
                    break;
                case TransactionType:
                    // accountTransferEntity.setTransferType(cotent);
                    break;
                case transact_time:
                    String beginTime = cotent.replaceAll(UtilConstants.OBLIQUE_LINE, UtilConstants.TRANSVERSE_LINE);
                    accountTransferEntity.setCreationTime(ToolUtil.transferGMTDateToCNEsternDate(DateUtil.formatStr2Date(beginTime)));
                    accountTransferEntity.setOrignalCreationTime(DateUtil.formatStr2Date(beginTime));
                    break;
                case notes:
                    break;
                case amount:
                    if (!StringUtils.isBlank(cotent)) {
                        BigDecimal transferAmount = BigDecimal.valueOf(Double.valueOf(cotent));
                        if (cotent.indexOf(UtilConstants.DOT) != -1) {
                            accountTransferEntity.setTransferAmount(transferAmount.setScale(4, RoundingMode.HALF_UP));
                        } else {
                            accountTransferEntity.setTransferAmount(transferAmount);
                        }
                    }
                    break;
                case currency_code:
                    if (UtilConstants.RMB.equalsIgnoreCase(cotent)) {
                        accountTransferEntity.setCurrency(UtilConstants.CNY);
                    } else {
                        accountTransferEntity.setCurrency(cotent);
                    }
                    break;
                case Column1:
                    break;
                case reference_no:
                    // accountTransferEntity.setRemark(cotent);
                    break;
                default:
                    break;
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * Construct Object instance for BBIN order by loop XML node.
     *
     * @param orderEntity
     * @param tagName
     * @param platformId
     * @param claz
     * @return Object
     */
    public static void readNodesForBBINOrder(OrderEntity orderEntity, String tagName, String cotent, String platformId, Class<Object> claz) {
        try {
            orderEntity.setPlatId(platformId);
            orderEntity.setFlag(1);
            // use BetRecordByModifiedDate3 api set ProductId and platformId in updateOrder method of dao
            if (platformId.equals(UtilConstants.BBIN_BLM)) {
                orderEntity.setProductId(UtilConstants.PRODUCT_ENUM.A01.toString());
            } else if (platformId.equals(UtilConstants.BBIN_MT)) {
                orderEntity.setProductId(UtilConstants.PRODUCT_ENUM.A02.toString());
            } else if (platformId.equalsIgnoreCase(UtilConstants.BBIN_ZL)) {
                orderEntity.setProductId(UtilConstants.PRODUCT_ENUM.A04.toString());
            } else if (platformId.equalsIgnoreCase(UtilConstants.BBIN_LL)) {
                orderEntity.setProductId(UtilConstants.PRODUCT_ENUM.A05.toString());
            } else if (platformId.equalsIgnoreCase(UtilConstants.BBIN_HJ)) {
                orderEntity.setProductId(UtilConstants.PRODUCTID_HJ);
            } else if (platformId.equalsIgnoreCase(UtilConstants.BBIN_WH)) {
                orderEntity.setProductId(UtilConstants.PRODUCT_ENUM.C01.toString());
            } else if (platformId.equalsIgnoreCase(UtilConstants.BBIN_BJH_NEW)) {
                orderEntity.setProductId(UtilConstants.PRODUCTID_BJH_NEW);
            } else if (platformId.equalsIgnoreCase(UtilConstants.BBIN_HWX)) {
                orderEntity.setProductId(UtilConstants.PRODUCT_ENUM.A03.toString());
            } else if (platformId.equalsIgnoreCase(UtilConstants.BBIN_KB)) {
                orderEntity.setProductId(UtilConstants.PRODUCT_ENUM.A06.toString());
            } else if (platformId.equalsIgnoreCase(UtilConstants.BBIN_HJHA)) {
                orderEntity.setProductId(UtilConstants.PRODUCTID_HJHA);
            } else if (UtilConstants.ORDERS_E02_BBIN.equalsIgnoreCase(platformId)) {
                orderEntity.setProductId(UtilConstants.PRODUCT_ENUM.E02.toString());
                orderEntity.setPlatId(UtilConstants.BBIN_BLM);
            } else if (UtilConstants.ORDERS_E03_BBIN.equalsIgnoreCase(platformId)) {
                orderEntity.setProductId(UtilConstants.PRODUCT_ENUM.E03.toString());
                orderEntity.setPlatId(UtilConstants.BBIN_BLM);
            } else if (UtilConstants.ORDERS_E04_BBIN.equalsIgnoreCase(platformId)) {
                orderEntity.setProductId(UtilConstants.PRODUCT_ENUM.E04.toString());
                orderEntity.setPlatId(UtilConstants.BBIN_BLM);
            } else if (UtilConstants.ORDERS_B01_BBIN.equalsIgnoreCase(platformId)) {
                orderEntity.setProductId(UtilConstants.PRODUCT_ENUM.B01.toString());
                orderEntity.setPlatId(UtilConstants.BBIN_BLM);
            } else if (UtilConstants.ORDERS_B79_BBIN.equalsIgnoreCase(platformId)) {
                orderEntity.setProductId(UtilConstants.PRODUCT_ENUM.B79.toString());
                orderEntity.setPlatId(UtilConstants.BBIN_BLM);
            }
            if (EnumUtils.isValidEnum(BBINOrdersEnum.class, tagName)) {
                BBINOrdersEnum tagNameEnum = Enum.valueOf(BBINOrdersEnum.class, tagName);
                switch (tagNameEnum) {
                    case UserName:
                        orderEntity.setLoginName(cotent);
                        break;
                    case WagersID:
                        orderEntity.setBillNo(cotent);
                        break;
                    case WagersDate:
                        if (cotent != null) {
                            // default timezone is GMT+4
                            if (platformId.equals(UtilConstants.SHABA_UK)
                                    || platformId.equals(UtilConstants.AMAYA_FCLRC)
                                    || platformId.equals(UtilConstants.MG)
                                    || platformId.equals(UtilConstants.MG_VIP)
                                    || platformId.equals(UtilConstants.AMAYA_VIP_FCLRC)) {
                                // orderEntity.setBillTime(DateUtil.formatStr2Date(cotent));
                                // GMT0
                                orderEntity.setBillTime(ToolUtil.transferGMTDateToCNEsternDate(DateUtil.formatStr2Date(cotent)));
                            } else if (platformId.equals(UtilConstants.VMG) || platformId.equals(UtilConstants.PNG) || platformId.equals(UtilConstants.NETENT)
                                    || platformId.equals(UtilConstants.BSG) || platformId.equals(UtilConstants.BSG_VIP) || platformId.equals(UtilConstants.CQ9)) {
                                orderEntity.setBillTime(DateUtil.formatStr2Date(cotent));
                            } else {
                                orderEntity.setBillTime(ToolUtil.transferUSEsternDateToCNEsternDate(DateUtil.formatStr2Date(cotent)));
                            }
                            orderEntity.setOrignalBillTime(DateUtil.formatStr2Date(cotent));
                            orderEntity.setReckonTime(orderEntity.getBillTime());
                        }
                        break;
                    case SerialID:
                        orderEntity.setGmCode(cotent);
                        break;
                    case RoundNo:
                        orderEntity.setRound(cotent);
                        break;
                    case GameType:
                        orderEntity.setGameType(cotent);
                        break;
                    case GameNum:
                        orderEntity.setGmCode(cotent);
                        break;
            /*case PlayType:
                if (cotent != null) {
                    orderEntity.setPlayType(Integer.valueOf(cotent));
                }
                break;*/
                    case WagerDetail:
                        if (StringUtils.isNotBlank(cotent)) {//原格式“玩法,賠率,下注,派彩”
                            orderEntity.setPlayType(Integer.valueOf(cotent.split(",")[0]));
                        }
                        break;
                    case GameCode:
                        if (platformId.equals(UtilConstants.SHABA_UK) || platformId.equals(UtilConstants.AMAYA_FCLRC) || platformId.equals(UtilConstants.CQ9)) {
                            orderEntity.setGmCode(cotent);
                        } else {
                            orderEntity.setTableCode(cotent);
                        }
                        break;
                    case Result:
                        orderEntity.setResult(cotent);
                        break;
                    case Card:
                        orderEntity.setCardList(cotent);
                        break;
                    case BetAmount:
                        if (!StringUtils.isBlank(cotent)) {
                            orderEntity.setAccount(BigDecimal.valueOf(Double.valueOf(cotent)));
                        }
                        break;
                    case Payoff:
                        if (!StringUtils.isBlank(cotent)) {
                            orderEntity.setCusAccount(BigDecimal.valueOf(Double.valueOf(cotent)));
                        }
                        break;
                    case Currency:
                        if (UtilConstants.RMB.equalsIgnoreCase(cotent)) {
                            orderEntity.setCurrency(UtilConstants.CNY);
                        } else {
                            orderEntity.setCurrency(cotent);
                        }
                        break;
                    case ExchangeRate:
                        if (!StringUtils.isBlank(cotent)) {
                            orderEntity.setExchangeRate(BigDecimal.valueOf(Double.valueOf(cotent)));
                        }
                        break;
                    case ModifiedDate:
                        if (cotent != null) {
                            // default timezone is GMT-8
                            orderEntity.setReckonTime(DateUtil.formatStr2Date(cotent));
                            if (platformId.equals(UtilConstants.CQ9)) {
                                orderEntity.setOrignalReckonTime(orderEntity.getReckonTime());
                            } else {
                                orderEntity.setOrignalReckonTime(ToolUtil.transferCNEsternDateToUSEscernDate(DateUtil.formatStr2Date(cotent)));
                            }
                        }
                        break;
                    case Comissionable:
                        if (!StringUtils.isBlank(cotent)) {
                            orderEntity.setValidAccount(BigDecimal.valueOf(Double.valueOf(cotent)));
                        }
                        break;
                    case Commissionable:
                        if (!StringUtils.isBlank(cotent) && !platformId.equals(UtilConstants.CQ9)) {
                            orderEntity.setValidAccount(BigDecimal.valueOf(Double.valueOf(cotent)));
                        }
                        break;
                    case UPTIME:
                        if (cotent != null) {
                            // default timezone is GMT-8
                            orderEntity.setReckonTime(DateUtil.formatStr2Date(cotent));
                            orderEntity.setOrignalReckonTime(ToolUtil.transferCNEsternDateToUSEscernDate(DateUtil.formatStr2Date(cotent)));
                        }
                        break;
                    case ResultType:
                        if (cotent != null) {
                            orderEntity.setResultType(cotent);
                        }
                        break;
                    case BeforeBalance:
                        if (!StringUtils.isBlank(cotent)) {
                            orderEntity.setPreviosAmount(BigDecimal.valueOf(Double.valueOf(cotent)));
                        }
                        break;
                    case ProductID:
                        if (!StringUtils.isBlank(cotent)) {
                            orderEntity.setProductId(cotent);
                        }
                        break;
                    case GameKind:
                        if (!StringUtils.isBlank(cotent) && platformId.equals(UtilConstants.MG)) {
                            orderEntity.setGameKind(cotent);
                        }
                        break;
                    case BonusAmount:
                        if (!StringUtils.isBlank(cotent)) {
                            orderEntity.setBonusAmount(BigDecimal.valueOf(Double.valueOf(cotent)));
                        }
                        break;
                    case Origin:
                        if (!StringUtils.isBlank(cotent)) {
                            orderEntity.setDeviceType(UtilConstants.ORIGIN_DEVICE_TYPE_ENUM.getValueByKey(cotent.toUpperCase()));
                        }
                        break;
                    case ValidAmount:
                        if (!StringUtils.isBlank(cotent) && platformId.equals(UtilConstants.CQ9)) {
                            orderEntity.setValidAccount(BigDecimal.valueOf(Double.valueOf(cotent)));
                        }
                    case DeviceType:
                        if (!StringUtils.isBlank(cotent)) {
                            if (UtilConstants.MG.equals(platformId) || UtilConstants.MG_VIP.equals(platformId) || UtilConstants.NETENT.equals(platformId) || UtilConstants.PNG.equals(platformId)) {//AGQJ 只解析0-pc 1-AGQJ新版 32-Android
                                if (cotent.equals("web") || cotent.equals("download")) {
                                    orderEntity.setDeviceType("0");
                                } else if (cotent.equals("android") || cotent.equals("html5")) {
                                    orderEntity.setDeviceType("1");
                                } else if (cotent.equals("null")) {
                                    orderEntity.setDeviceType(null);
                                } else {
                                    orderEntity.setDeviceType(cotent);
                                }
                            } else {
                                orderEntity.setDeviceType(cotent);
                            }
                        }
                        break;
                    default:
                        break;
                }
            }
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
        }
    }

    /**
     * Construct Object instance for EA order by loop XML node.
     *
     * @param orderEntity
     * @param attrs
     * @param platformId
     * @return Object
     */
    public static void readAttributesForEAOrder(Attributes attrs, OrderEntity orderEntity, String platformId) {
        orderEntity.setPlatId(platformId);
        orderEntity.setProductId(UtilConstants.PRODUCTID_MT);
        orderEntity.setFlag(1);
        int attrCount = attrs.getLength();
        String attrName = null;
        String attrValue = null;
        for (int i = 0; i < attrCount; i++) {
            attrName = attrs.getQName(i);
            attrValue = attrs.getValue(i);
            EAOrdersEnum tagNameEnum = Enum.valueOf(EAOrdersEnum.class, attrName);
            switch (tagNameEnum) {
                // 局号
                case id:
                    orderEntity.setGmCode(attrValue);
                    break;
                // 会员账号
                case login:
                    orderEntity.setLoginName(attrValue);
                    break;
                // 游戏类型
                case code:
                    break;
                // 有效投注金额
                case bet_amount:
                    if (!StringUtils.isBlank(attrValue)) {
                        orderEntity.setAccount(BigDecimal.valueOf(Double.valueOf(attrValue)).divide(UtilConstants.HUNDREAD));
                        // orderEntity.setValidAccount(BigDecimal.valueOf(Double.valueOf(attrValue)).divide(UtilConstants.HUNDREAD));
                    }
                    break;
                // 派彩金额
                case payout_amount:
                    /*
                     * if(!StringUtils.isBlank(attrValue)){ orderEntity.setCusAccount(BigDecimal.valueOf(
                     * Double.valueOf(attrValue)).divide(UtilConstants.HUNDREAD)); }
                     */
                    break;
                // 投注金额
                case handle:
                    if (!StringUtils.isBlank(attrValue)) {
                        // orderEntity.setAccount(BigDecimal.valueOf(Double.valueOf(attrValue)).divide(UtilConstants.HUNDREAD));
                        orderEntity.setValidAccount(BigDecimal.valueOf(Double.valueOf(attrValue)).divide(UtilConstants.HUNDREAD));
                    }
                    break;
                // 纯输纯赢
                case hold:
                    if (!StringUtils.isBlank(attrValue)) {
                        // orderEntity.setNetAccount(BigDecimal.valueOf(Double.valueOf(attrValue)).divide(UtilConstants.HUNDREAD));
                        orderEntity.setCusAccount(BigDecimal.valueOf(Double.valueOf(attrValue)).divide(UtilConstants.HUNDREAD));
                    }
                    break;
                default:
                    break;
            }
        }
    }

    /**
     * Construct Object instance for EA Game Result by loop XML node.
     *
     * @param orderEntity
     * @param tagName
     * @param content
     * @return Object
     */
    public static void readNodesForEAOrder(OrderEntity orderEntity, String tagName, String content) {
        EAOrdersEnum tagNameEnum = Enum.valueOf(EAOrdersEnum.class, tagName);
        BigDecimal betAmont = BigDecimal.valueOf((Double.valueOf(content))).divide(UtilConstants.HUNDREAD);
        switch (tagNameEnum) {
            // 庄
            case bank:
                orderEntity.setPlayType(1);
                if (orderEntity.getRemark() != null) {
                    orderEntity.setRemark(orderEntity.getRemark() + UtilConstants.VERTICAL + "押庄" + betAmont);
                } else {
                    orderEntity.setRemark("押庄" + betAmont);
                }
                break;
            // 闲
            case player:
                orderEntity.setPlayType(2);
                if (orderEntity.getRemark() != null) {
                    orderEntity.setRemark(orderEntity.getRemark() + UtilConstants.VERTICAL + "押闲" + betAmont);
                } else {
                    orderEntity.setRemark("押闲" + betAmont);
                }
                break;
            // 和
            case tie:
                orderEntity.setPlayType(3);
                if (orderEntity.getRemark() != null) {
                    orderEntity.setRemark(orderEntity.getRemark() + UtilConstants.VERTICAL + "押和" + betAmont);
                } else {
                    orderEntity.setRemark("押和" + betAmont);
                }
                break;
            // 庄对
            case bankdp:
                orderEntity.setPlayType(4);
                if (orderEntity.getRemark() != null) {
                    orderEntity.setRemark(orderEntity.getRemark() + UtilConstants.VERTICAL + "押庄对" + betAmont);
                } else {
                    orderEntity.setRemark("押庄对" + betAmont);
                }
                break;
            // 闲对
            case playerdp:
                orderEntity.setPlayType(5);
                if (orderEntity.getRemark() != null) {
                    orderEntity.setRemark(orderEntity.getRemark() + UtilConstants.VERTICAL + "押闲对" + betAmont);
                } else {
                    orderEntity.setRemark("押闲对" + betAmont);
                }
                break;
            // 庄单
            case bankodd:
                orderEntity.setPlayType(17);
                if (orderEntity.getRemark() != null) {
                    orderEntity.setRemark(orderEntity.getRemark() + UtilConstants.VERTICAL + "押庄单" + betAmont);
                } else {
                    orderEntity.setRemark("押庄单" + betAmont);
                }
                break;
            // 庄双
            case bankeven:
                orderEntity.setPlayType(18);
                if (orderEntity.getRemark() != null) {
                    orderEntity.setRemark(orderEntity.getRemark() + UtilConstants.VERTICAL + "押庄双" + betAmont);
                } else {
                    orderEntity.setRemark("押庄双" + betAmont);
                }
                break;
            // 闲单
            case playerodd:
                orderEntity.setPlayType(19);
                if (orderEntity.getRemark() != null) {
                    orderEntity.setRemark(orderEntity.getRemark() + UtilConstants.VERTICAL + "押闲单" + betAmont);
                } else {
                    orderEntity.setRemark("押闲单" + betAmont);
                }
                break;
            // 闲双
            case playereven:
                orderEntity.setPlayType(20);
                if (orderEntity.getRemark() != null) {
                    orderEntity.setRemark(orderEntity.getRemark() + UtilConstants.VERTICAL + "押闲双" + betAmont);
                } else {
                    orderEntity.setRemark("押闲双" + betAmont);
                }
                break;
            // 大
            case big:
                orderEntity.setPlayType(6);
                if (orderEntity.getRemark() != null) {
                    orderEntity.setRemark(orderEntity.getRemark() + UtilConstants.VERTICAL + "押大" + betAmont);
                } else {
                    orderEntity.setRemark("押大" + betAmont);
                }
                break;
            // 小
            case small:
                orderEntity.setPlayType(7);
                if (orderEntity.getRemark() != null) {
                    orderEntity.setRemark(orderEntity.getRemark() + UtilConstants.VERTICAL + "押小" + betAmont);
                } else {
                    orderEntity.setRemark("押小" + betAmont);
                }
                break;
            default:
                break;
        }
    }


    /**
     * Construct BetAmtLimitEntity
     *
     * @param attrs
     * @param claz
     * @return
     * @throws IllegalArgumentException
     */
    public static BetAmtLimitEntity constructBetAmtLimitEntity(Attributes attrs, String platformId, Class<Object> claz)
            throws IllegalArgumentException {
        int attrCount = attrs.getLength();
        BetAmtLimitEntity objInstance = new BetAmtLimitEntity();
        String attrName = null;
        BetAmtLimitEnum attrNameEnum = null;
        for (int i = 0; i < attrCount; i++) {
            attrName = attrs.getQName(i);
            if (EnumUtils.isValidEnum(BetAmtLimitEnum.class, attrName)) {
                attrNameEnum = Enum.valueOf(BetAmtLimitEnum.class, attrName);
            } else {
                continue;
            }
            switch (attrNameEnum) {
                case loginname:
                    objInstance.setLoginName(attrs.getValue(i));
                    break;
                case oddtype:
                    objInstance.setOddType(attrs.getValue(i));
                    break;
                case maxcount:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setOrdersTotal(new BigDecimal(attrs.getValue(i)));
                    }
                    break;
                case percount:
                    if (!StringUtils.isBlank(attrs.getValue(i))) {
                        objInstance.setLimitOrdersTotal(new BigDecimal(attrs.getValue(i)));
                    }
                    break;
                default:
                    break;
            }
        }
        return objInstance;
    }

    /**
     * 计算shaba和NSS的有效投注额跟洗码投注额
     * 投注额 赔率低于欧洲盘1.5，香港盘0.5，马来盘0.5，美式盘-200，印尼盘-2.00的投注，洗码投注额显示为0；
     * 混合过关投注里面，只要其中有一场比赛的赔率低于0.5，整个混合过关的投注额
     * 对于NSS体育，状态为void,draw,postponed的注单，以及Saba体育，状态为refund,draw,void,reject的注单，洗码投注额显示为0
     * 对于赢半或者输半的投注，有效投注额和洗码投注额的统计，需要按照投注额的一半进行处理
     *
     * @param orderEntity
     */
    public static void calculateValidAndRemainAmount(OrderEntity orderEntity) {

        if (orderEntity.getOdds() == null || StringUtils.isEmpty(orderEntity.getOddsType())) {
            log.error("获取shaba或nss赔率时发现为空！odds is null:[" + orderEntity.getOdds() + "],oddstype is null:[" + StringUtils.isEmpty(orderEntity.getOddsType()) + "]");
            return;
        }

        //如果没有结算的注单，有效投注额跟洗码投注额为0
        if (orderEntity.getFlag() == UtilConstants.ORDERS_FLAG_ENUM.UNSETTLED.getFalg()
                || orderEntity.getFlag() == UtilConstants.ORDERS_FLAG_ENUM.CANCELED.getFalg()) {
            orderEntity.setValidAccount(BigDecimal.ZERO);
            orderEntity.setRemainAmount(BigDecimal.ZERO);
            return;
        }

        //印尼盘马来盘：投注100元-0.94水，客户全赢100，有效投注额为100，赢半为50，客户全输，有效投注额为94，输半为47
        //投注100元1.10水，客户全赢100，赢半50，客户全输110，输半55

        UtilConstants.OddsTypeEnum oddsType = UtilConstants.OddsTypeEnum.getOddsType(orderEntity.getOddsType());
        String tempResult = orderEntity.getResult();

    	/*  暂时不对有效投注额度进行处理 
    	if(OddsTypeEnum.MALAY.equals(oddsType) || OddsTypeEnum.NSS_MALAY.equals(oddsType) || OddsTypeEnum.NSS_INDO.equals(oddsType) || OddsTypeEnum.SHABA_INDO.equals(oddsType)){
    		//全赢
    		if(tempResult.equalsIgnoreCase("win") || tempResult.equalsIgnoreCase("W: Win")){
    			orderEntity.setValidAccount(orderEntity.getAccount().setScale(2, RoundingMode.HALF_UP));
    		}else if(tempResult.equalsIgnoreCase("win_half") || tempResult.equalsIgnoreCase("Half Win")){
    			orderEntity.setValidAccount(orderEntity.getAccount().multiply(new BigDecimal(0.5)).setScale(2, RoundingMode.HALF_UP));
    		}else if(tempResult.equalsIgnoreCase("lost") || tempResult.equalsIgnoreCase("L: Lose")){
    			BigDecimal v = orderEntity.getOdds().multiply(orderEntity.getAccount()).abs();
    			orderEntity.setValidAccount(v.setScale(2,RoundingMode.HALF_UP));
    		}else if(tempResult.equalsIgnoreCase("lost_half") || tempResult.equalsIgnoreCase("Half Lose")){
    			BigDecimal v = orderEntity.getOdds().multiply(orderEntity.getAccount()).abs();
    			orderEntity.setValidAccount(v.multiply(new BigDecimal(0.5)).setScale(2, RoundingMode.HALF_UP));
    		}else if(tempResult.equalsIgnoreCase("S: Waiting")){
    			orderEntity.setValidAccount(BigDecimal.ZERO);
    		}
    		orderEntity.setRemainAmount(orderEntity.getValidAccount().setScale(2, RoundingMode.HALF_UP));
    	}*/
        if (StringUtils.isNotBlank(tempResult)) {
            //refund，reject，void draw ,postponed Shaba和局，D:NSS和局,不计算有效投注额
            if (tempResult.equalsIgnoreCase("refund") || tempResult.equalsIgnoreCase("draw") || tempResult.equalsIgnoreCase("0: Draw")
                    || tempResult.equalsIgnoreCase("void") || tempResult.equalsIgnoreCase("reject")
                    || tempResult.equalsIgnoreCase("postponed")
                    || tempResult.equalsIgnoreCase("D")) {
                orderEntity.setValidAccount(BigDecimal.ZERO);
                orderEntity.setRemainAmount(BigDecimal.ZERO);
                return;
            }
        }
        String lowerLimit = CustomerPropertyholder.getProperty(oddsType + ".oddsType");
        if (StringUtils.isEmpty(lowerLimit)) {
            log.error("计算SHABA洗码投注额，无法找到目标注单赔率下限，盘口类型：" + oddsType + ".oddsType");
            orderEntity.setRemainAmount(orderEntity.getValidAccount().setScale(6, RoundingMode.DOWN));
        } else {
            switch (oddsType) {
                case MALAY:
                    washMalay(orderEntity, lowerLimit);
                    break;
                case NSS_MALAY:
                    //NSS马来盘口洗码计算 modified by Ziv.Y 2017-11-11
                    washMalayNSS(orderEntity, lowerLimit);
                    break;
                case HK:
                    washHK(orderEntity, lowerLimit);
                    break;
                case NSS_HK:
                    washHKNSS(orderEntity, lowerLimit);
                    break;
                case DECIMAL:
                    washEuropean(orderEntity, lowerLimit);
                    break;
                case NSS_DECIMAL:
                    washEuropeanNSS(orderEntity, lowerLimit);
                    break;
                case SHABA_INDO:
                    washIndonesia(orderEntity, lowerLimit);
                    break;
                case NSS_INDO:
                    washIndonesiaNSS(orderEntity, lowerLimit);
                    break;
                case AMERICAN:
                    washAmerican(orderEntity, lowerLimit);
                    break;
                default:
                    if (orderEntity.getOdds().compareTo(new BigDecimal(lowerLimit)) < 0) {
                        orderEntity.setRemainAmount(BigDecimal.ZERO);
                    } else {
                        orderEntity.setRemainAmount(orderEntity.getValidAccount().setScale(6, RoundingMode.DOWN));
                    }
                    break;
            }
        }
    }

    /**
     * Malay Wash Code Rules
     * 赔率<-0.36, 赢：本金 输: 本金*(-赔率); 赔率>0.5, 赢：本金*赔率 输：本金
     * -0.36≤赔率＜0.5  洗码投注额为0
     *
     * @param orderEntity
     * @param limit
     */
    private static void washMalay(OrderEntity orderEntity, String limit) {
        try {
            log.info("Wash rate for Malay:" + limit);

            UtilConstants.OddsTypeEnum oddsType = UtilConstants.OddsTypeEnum.getOddsType(orderEntity.getOddsType());

            String[] limits = limit.split(",");
            if (limits.length < 2) {
                log.error("计算马来洗码投注额，赔率配置必须是英文逗号分隔的两个数字：" + oddsType + ".oddsType");
                return;
            }

            BigDecimal negativeBottom = new BigDecimal(limits[0]); // 负数下限
            BigDecimal positiveTop = new BigDecimal(limits[1]); // 正数上限

            if (negativeBottom.compareTo(BigDecimal.ZERO) > 0 || positiveTop.compareTo(BigDecimal.ZERO) < 0) {
                log.error("计算马来洗码投注额，赔率配置错误，格式示例：'-0.36,0.5'：" + oddsType + ".oddsType");
                return;
            }

            String result = orderEntity.getResult();
            BigDecimal odds = orderEntity.getOdds();
            if (odds.compareTo(negativeBottom) < 0) {
                // 赔率<-0.36, 赢：本金 输: 本金*(-赔率)
                if (result.equalsIgnoreCase("Half Win") || result.equalsIgnoreCase("W: Win")) {
                    // win
                    BigDecimal amount = orderEntity.getValidAccount().setScale(6, RoundingMode.DOWN);
                    orderEntity.setRemainAmount(amount);
                } else if (result.equalsIgnoreCase("Half Lose") || result.equalsIgnoreCase("L: Lose")) {
                    // lose
                    BigDecimal amount = odds.abs().multiply(orderEntity.getValidAccount()).setScale(6, RoundingMode.DOWN);
                    orderEntity.setRemainAmount(amount);
                } else {
                    orderEntity.setRemainAmount(BigDecimal.ZERO);
                }
            } else if (odds.compareTo(positiveTop) >= 0) {
                // 赔率>0.5, 赢：本金*赔率 输：本金
                if (result.equalsIgnoreCase("Half Win") || result.equalsIgnoreCase("W: Win")) {
                    // win
                    BigDecimal amount = odds.multiply(orderEntity.getValidAccount()).setScale(6, RoundingMode.DOWN);
                    orderEntity.setRemainAmount(amount);
                } else if (result.equalsIgnoreCase("Half Lose") || result.equalsIgnoreCase("L: Lose")) {
                    // lose
                    BigDecimal amount = orderEntity.getValidAccount().setScale(6, RoundingMode.DOWN);
                    orderEntity.setRemainAmount(amount);
                } else {
                    orderEntity.setRemainAmount(BigDecimal.ZERO);
                }
            } else {
                // -0.36≤赔率＜0.5，洗码投注额为0
                orderEntity.setRemainAmount(BigDecimal.ZERO);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * Shaba HonKong Wash Code Rules
     * Odds of HonKong is positive
     * while odds<0.5 or odds>2.75, wash code is 0.
     * otherwise
     * win: wash = amount * odds
     * lose: wash = amount
     *
     * @param orderEntity
     * @param limit
     */
    private static void washHK(OrderEntity orderEntity, String limit) {
        try {
            log.info("Wash rate for SHABA HK:" + limit);

            UtilConstants.OddsTypeEnum oddsType = UtilConstants.OddsTypeEnum.getOddsType(orderEntity.getOddsType());

            String[] limits = limit.split(",");
            if (limits.length < 2) {
                log.error("odds of SHABA HK must be two numbers split by ,:" + oddsType + ".oddsType");
                return;
            }

            BigDecimal bottom = new BigDecimal(limits[0]);
            BigDecimal top = new BigDecimal(limits[1]);

            if (bottom.compareTo(BigDecimal.ZERO) == -1 || top.compareTo(BigDecimal.ZERO) == -1) {
                log.error("odds of SHABA HK is wrong, e.g.:'0.5,2.75'：" + oddsType + ".oddsType");
                return;
            }

            String result = orderEntity.getResult();
            BigDecimal odds = orderEntity.getOdds();
            // odds < 0.5 || odds > 2.75
            if (odds.compareTo(bottom) < 0 || odds.compareTo(top) > 0) {
                orderEntity.setRemainAmount(BigDecimal.ZERO);
            } else {
                if (result.equalsIgnoreCase("Half Win") || result.equalsIgnoreCase("W: Win")) {
                    // win: wash = amount * odds
                    BigDecimal amount = odds.multiply(orderEntity.getValidAccount()).setScale(6, RoundingMode.DOWN);
                    orderEntity.setRemainAmount(amount);

                } else if (result.equalsIgnoreCase("Half Lose") || result.equalsIgnoreCase("L: Lose")) {
                    // lose: wash = amount
                    orderEntity.setRemainAmount(orderEntity.getValidAccount());
                } else {
                    orderEntity.setRemainAmount(BigDecimal.ZERO);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * European Wash Code Rules
     * Odds of European is positive
     * while odds<1.5 or odds>3.75, wash code is 0.
     * otherwise
     * win: wash = amount * odds
     * lose: wash = amount
     *
     * @param orderEntity
     * @param limit
     */
    private static void washEuropean(OrderEntity orderEntity, String limit) {
        try {
            log.info("Wash rate for European:" + limit);

            UtilConstants.OddsTypeEnum oddsType = UtilConstants.OddsTypeEnum.getOddsType(orderEntity.getOddsType());

            String[] limits = limit.split(",");
            if (limits.length < 2) {
                log.error("odds of SHABA European must be two numbers split by ,:" + oddsType + ".oddsType");
                return;
            }

            BigDecimal bottom = new BigDecimal(limits[0]);
            BigDecimal top = new BigDecimal(limits[1]);

            if (bottom.compareTo(BigDecimal.ZERO) == -1 || top.compareTo(BigDecimal.ZERO) == -1) {
                log.error("odds of SHABA European is wrong, e.g.:'1.5,3.75'：" + oddsType + ".oddsType");
                return;
            }

            String result = orderEntity.getResult();
            BigDecimal odds = orderEntity.getOdds();
            // odds < 1.5 || odds > 3.75
            if (odds.compareTo(bottom) < 0 || odds.compareTo(top) > 0) {
                orderEntity.setRemainAmount(BigDecimal.ZERO);
            } else {
                if (result.equalsIgnoreCase("Half Win") || result.equalsIgnoreCase("W: Win")) {
                    // win: wash = amount * odds
                    BigDecimal amount = odds.subtract(BigDecimal.ONE).multiply(orderEntity.getValidAccount()).setScale(6, RoundingMode.DOWN);
                    orderEntity.setRemainAmount(amount);
                } else if (result.equalsIgnoreCase("Half Lose") || result.equalsIgnoreCase("L: Lose")) {
                    // lose: wash = amount
                    orderEntity.setRemainAmount(orderEntity.getValidAccount());
                } else {
                    orderEntity.setRemainAmount(BigDecimal.ZERO);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * SHABA Indonesia Wash Code Rules
     * while odds<-2.00 or odds>2.75, wash code is 0.
     * otherwise
     * -2.00<=odds<=0: win: wash = amount, lose: wash = amount * abs(odds)
     * 0<odds<=2.75: win: wash = amount * abs(odds), lose: wash = amount
     *
     * @param orderEntity
     * @param limit
     */
    private static void washIndonesia(OrderEntity orderEntity, String limit) {
        try {
            log.info("Wash rate for Indonesia:" + limit);

            UtilConstants.OddsTypeEnum oddsType = UtilConstants.OddsTypeEnum.getOddsType(orderEntity.getOddsType());

            String[] limits = limit.split(",");
            if (limits.length < 2) {
                log.error("odds of SHABA Indonesia must be two numbers split by ,:" + oddsType + ".oddsType");
                return;
            }

            BigDecimal bottom = new BigDecimal(limits[0]);
            BigDecimal top = new BigDecimal(limits[1]);

            if (bottom.compareTo(BigDecimal.ZERO) == -1 || top.compareTo(BigDecimal.ZERO) == -1) {
                log.error("odds of SHABA Indonesia is wrong, e.g.:'-2.00,2.75'：" + oddsType + ".oddsType");
                return;
            }

            String result = orderEntity.getResult();
            BigDecimal odds = orderEntity.getOdds();
            // odds < -2.00 || odds > 2.75
            if (odds.compareTo(bottom) < 0 || odds.compareTo(top) > 0) {
                orderEntity.setRemainAmount(BigDecimal.ZERO);
            } else if (odds.compareTo(bottom) > -1 && odds.compareTo(BigDecimal.ZERO) < 1) {
                // -2.00<=odds<=0
                if (result.equalsIgnoreCase("Half Win") || result.equalsIgnoreCase("W: Win")) {
                    // win: wash = amount
                    orderEntity.setRemainAmount(orderEntity.getValidAccount());
                } else if (result.equalsIgnoreCase("Half Lose") || result.equalsIgnoreCase("L: Lose")) {
                    // lose: wash = amount * odds
                    BigDecimal amount = odds.abs().multiply(orderEntity.getValidAccount()).setScale(6, RoundingMode.DOWN);
                    orderEntity.setRemainAmount(amount);
                } else {
                    orderEntity.setRemainAmount(BigDecimal.ZERO);
                }
            } else if (odds.compareTo(BigDecimal.ZERO) > 0 && odds.compareTo(top) < 1) {
                // 0<odds<=2.75
                if (result.equalsIgnoreCase("Half Win") || result.equalsIgnoreCase("W: Win")) {
                    // win: wash = amount * odds
                    BigDecimal amount = odds.abs().multiply(orderEntity.getValidAccount()).setScale(6, RoundingMode.DOWN);
                    orderEntity.setRemainAmount(amount);
                } else if (result.equalsIgnoreCase("Half Lose") || result.equalsIgnoreCase("L: Lose")) {
                    // lose: wash = amount
                    orderEntity.setRemainAmount(orderEntity.getValidAccount());
                } else {
                    orderEntity.setRemainAmount(BigDecimal.ZERO);
                }
            } else {
                orderEntity.setRemainAmount(BigDecimal.ZERO);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * SHABA American Wash Code Rules
     * while odds<-200 or odds>2.75, wash code is 0.
     * otherwise
     * -200<=odds<=0: win: wash = amount, lose: wash = amount * abs(odds)
     * 0<odds<=2.75: win: wash = amount * abs(odds), lose: wash = amount
     *
     * @param orderEntity
     * @param limit
     */
    private static void washAmerican(OrderEntity orderEntity, String limit) {
        try {
            log.info("Wash rate for American:" + limit);

            UtilConstants.OddsTypeEnum oddsType = UtilConstants.OddsTypeEnum.getOddsType(orderEntity.getOddsType());

            String[] limits = limit.split(",");
            if (limits.length < 2) {
                log.error("odds of SHABA American must be two numbers split by ,:" + oddsType + ".oddsType");
                return;
            }

            BigDecimal bottom = new BigDecimal(limits[0]);
            BigDecimal top = new BigDecimal(limits[1]);

            if (bottom.compareTo(BigDecimal.ZERO) == -1 || top.compareTo(BigDecimal.ZERO) == -1) {
                log.error("odds of SHABA American is wrong, e.g.:'-200,2.75'：" + oddsType + ".oddsType");
                return;
            }

            String result = orderEntity.getResult();
            BigDecimal odds = orderEntity.getOdds();
            // odds < -200 || odds > 2.75
            if (odds.compareTo(bottom) < 0 || odds.compareTo(top) > 0) {
                orderEntity.setRemainAmount(BigDecimal.ZERO);
            } else if (odds.compareTo(bottom) > -1 && odds.compareTo(BigDecimal.ZERO) < 1) {
                // -200<=odds<=0
                if (result.equalsIgnoreCase("Half Win") || result.equalsIgnoreCase("W: Win")) {
                    // win: wash = amount
                    orderEntity.setRemainAmount(orderEntity.getValidAccount());
                } else if (result.equalsIgnoreCase("Half Lose") || result.equalsIgnoreCase("L: Lose")) {
                    // lose: wash = amount * odds
                    BigDecimal amount = odds.abs().multiply(orderEntity.getValidAccount()).divide(new BigDecimal(100)).setScale(6, RoundingMode.DOWN);
                    orderEntity.setRemainAmount(amount);
                } else {
                    orderEntity.setRemainAmount(BigDecimal.ZERO);
                }
            } else if (odds.compareTo(BigDecimal.ZERO) > 0 && odds.compareTo(top) < 1) {
                // 0<odds<=2.75
                if (result.equalsIgnoreCase("Half Win") || result.equalsIgnoreCase("W: Win")) {
                    // win: wash = amount * odds
                    BigDecimal amount = odds.abs().multiply(orderEntity.getValidAccount()).setScale(6, RoundingMode.DOWN);
                    orderEntity.setRemainAmount(amount);
                } else if (result.equalsIgnoreCase("Half Lose") || result.equalsIgnoreCase("L: Lose")) {
                    // lose: wash = amount
                    orderEntity.setRemainAmount(orderEntity.getValidAccount());
                } else {
                    orderEntity.setRemainAmount(BigDecimal.ZERO);
                }
            } else {
                orderEntity.setRemainAmount(BigDecimal.ZERO);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * @Description: NSS厅方马来盘口洗码计算
     * @Author: Ziv.Y
     * @Date: 2017/11/11 14:40
     */
    private static void washMalayNSS(OrderEntity orderEntity, String limit) {
        try {
            log.info("Wash rate for NSS Malay:" + limit);

            UtilConstants.OddsTypeEnum oddsType = UtilConstants.OddsTypeEnum.getOddsType(orderEntity.getOddsType());

            String[] limits = limit.split(",");
            if (limits.length < 2) {
                log.error("计算NSS马来洗码投注额，赔率配置必须是英文逗号分隔的两个数字：" + oddsType + ".oddsType");
                return;
            }

            BigDecimal negativeBottom = new BigDecimal(limits[0]); // 负数下限
            BigDecimal positiveTop = new BigDecimal(limits[1]); // 正数上限

            if (negativeBottom.compareTo(BigDecimal.ZERO) > 0 || positiveTop.compareTo(BigDecimal.ZERO) < 0) {
                log.error("计算NSS马来洗码投注额，赔率配置错误，格式示例：'-0.36,0.5'：" + oddsType + ".oddsType");
                return;
            }

            String result = orderEntity.getResultNSS();//NSS输赢结果 modified by Ziv.Y 2017-11-1
            BigDecimal odds = orderEntity.getOdds();
            if (odds.compareTo(negativeBottom) < 0) { // 赔率<-0.36, 赢：本金 输: 本金*(-赔率)
                //马来盘口洗码逻辑未生效问题修改，输赢结果判断改为使用<winlost_status>标签中的值 modified by Ziv.Y 2017-11-11
                if (result.equalsIgnoreCase("W") || result.equalsIgnoreCase("WH")) { // win
                    BigDecimal amount = orderEntity.getValidAccount().setScale(2, RoundingMode.HALF_UP);
                    orderEntity.setRemainAmount(amount);
                } else if (result.equalsIgnoreCase("L") || result.equalsIgnoreCase("LH")) { // lose
                    BigDecimal amount = odds.abs().multiply(orderEntity.getValidAccount()).setScale(2, RoundingMode.HALF_UP);
                    orderEntity.setRemainAmount(amount);
                } else {
                    orderEntity.setRemainAmount(BigDecimal.ZERO);
                }
            } else if (odds.compareTo(positiveTop) >= 0) { // 赔率>0.5, 赢：本金*赔率 输：本金
                //马来盘口洗码逻辑未生效问题修改，输赢结果判断改为使用<winlost_status>标签中的值 modified by Ziv.Y 2017-11-11
                if (result.equalsIgnoreCase("W") || result.equalsIgnoreCase("WH")) { // win
                    BigDecimal amount = odds.multiply(orderEntity.getValidAccount()).setScale(2, RoundingMode.HALF_UP);
                    orderEntity.setRemainAmount(amount);
                } else if (result.equalsIgnoreCase("L") || result.equalsIgnoreCase("LH")) { // lose
                    BigDecimal amount = orderEntity.getValidAccount().setScale(2, RoundingMode.HALF_UP);
                    orderEntity.setRemainAmount(amount);
                } else {
                    orderEntity.setRemainAmount(BigDecimal.ZERO);
                }
            } else { // -0.36≤赔率＜0.5，洗码投注额为0
                orderEntity.setRemainAmount(BigDecimal.ZERO);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * NSS HonKong Wash Code Rules
     * Odds of HonKong is positive
     * while odds<0.5 or odds>2.75, wash code is 0.
     * otherwise
     * win: wash = amount * odds
     * lose: wash = amount
     *
     * @param orderEntity
     * @param limit
     */
    private static void washHKNSS(OrderEntity orderEntity, String limit) {
        try {
            log.info("Wash rate for NSS HK:" + limit);

            UtilConstants.OddsTypeEnum oddsType = UtilConstants.OddsTypeEnum.getOddsType(orderEntity.getOddsType());

            String[] limits = limit.split(",");
            if (limits.length < 2) {
                log.error("odds of NSS HK must be two numbers split by ,:" + oddsType + ".oddsType");
                return;
            }

            BigDecimal bottom = new BigDecimal(limits[0]);
            BigDecimal top = new BigDecimal(limits[1]);

            if (bottom.compareTo(BigDecimal.ZERO) == -1 || top.compareTo(BigDecimal.ZERO) == -1) {
                log.error("odds of NSS HK is wrong, e.g.:'0.5,2.75'：" + oddsType + ".oddsType");
                return;
            }

            String result = orderEntity.getResultNSS();
            BigDecimal odds = orderEntity.getOdds();
            // odds < 0.5 || odds > 2.75
            if (odds.compareTo(bottom) < 0 || odds.compareTo(top) > 0) {
                orderEntity.setRemainAmount(BigDecimal.ZERO);
            } else {
                if (result.equalsIgnoreCase("W") || result.equalsIgnoreCase("WH")) {
                    // win: wash = amount * odds
                    BigDecimal amount = odds.multiply(orderEntity.getValidAccount()).setScale(2, RoundingMode.HALF_UP);
                    orderEntity.setRemainAmount(amount);

                } else if (result.equalsIgnoreCase("L") || result.equalsIgnoreCase("LH")) {
                    // lose: wash = amount
                    orderEntity.setRemainAmount(orderEntity.getValidAccount());
                } else {
                    orderEntity.setRemainAmount(BigDecimal.ZERO);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * NSS European Wash Code Rules
     * Odds of European is positive
     * while odds<1.5 or odds>3.75, wash code is 0.
     * otherwise
     * win: wash = amount * odds
     * lose: wash = amount
     *
     * @param orderEntity
     * @param limit
     */
    private static void washEuropeanNSS(OrderEntity orderEntity, String limit) {
        try {
            log.info("Wash rate for European:" + limit);

            UtilConstants.OddsTypeEnum oddsType = UtilConstants.OddsTypeEnum.getOddsType(orderEntity.getOddsType());

            String[] limits = limit.split(",");
            if (limits.length < 2) {
                log.error("odds of SHABA European must be two numbers split by ,:" + oddsType + ".oddsType");
                return;
            }

            BigDecimal bottom = new BigDecimal(limits[0]);
            BigDecimal top = new BigDecimal(limits[1]);

            if (bottom.compareTo(BigDecimal.ZERO) == -1 || top.compareTo(BigDecimal.ZERO) == -1) {
                log.error("odds of SHABA European is wrong, e.g.:'1.5,3.75'：" + oddsType + ".oddsType");
                return;
            }

            String result = orderEntity.getResultNSS();
            BigDecimal odds = orderEntity.getOdds();
            // odds < 1.5 || odds > 3.75
            if (odds.compareTo(bottom) < 0 || odds.compareTo(top) > 0) {
                orderEntity.setRemainAmount(BigDecimal.ZERO);
            } else {
                if (result.equalsIgnoreCase("W") || result.equalsIgnoreCase("WH")) {
                    // win: wash = amount * odds
                    BigDecimal amount = odds.subtract(BigDecimal.ONE).multiply(orderEntity.getValidAccount()).setScale(2, RoundingMode.HALF_UP);
                    orderEntity.setRemainAmount(amount);
                } else if (result.equalsIgnoreCase("L") || result.equalsIgnoreCase("LH")) {
                    // lose: wash = amount
                    orderEntity.setRemainAmount(orderEntity.getValidAccount());
                } else {
                    orderEntity.setRemainAmount(BigDecimal.ZERO);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * NSS Indonesia Wash Code Rules
     * while odds<-2.00 or odds>2.75, wash code is 0.
     * otherwise
     * -2.00<=odds<=0: win: wash = amount, lose: wash = amount * abs(odds)
     * 0<odds<=2.75: win: wash = amount * abs(odds), lose: wash = amount
     *
     * @param orderEntity
     * @param limit
     */
    private static void washIndonesiaNSS(OrderEntity orderEntity, String limit) {
        try {
            log.info("Wash rate for Indonesia:" + limit);

            UtilConstants.OddsTypeEnum oddsType = UtilConstants.OddsTypeEnum.getOddsType(orderEntity.getOddsType());

            String[] limits = limit.split(",");
            if (limits.length < 2) {
                log.error("odds of NSS Indonesia must be two numbers split by ,:" + oddsType + ".oddsType");
                return;
            }

            BigDecimal bottom = new BigDecimal(limits[0]);
            BigDecimal top = new BigDecimal(limits[1]);

            if (bottom.compareTo(BigDecimal.ZERO) == -1 || top.compareTo(BigDecimal.ZERO) == -1) {
                log.error("odds of NSS Indonesia is wrong, e.g.:'-2.00,2.75'：" + oddsType + ".oddsType");
                return;
            }

            String result = orderEntity.getResultNSS();
            BigDecimal odds = orderEntity.getOdds();
            // odds < -2.00 || odds > 2.75
            if (odds.compareTo(bottom) < 0 || odds.compareTo(top) > 0) {
                orderEntity.setRemainAmount(BigDecimal.ZERO);
            } else if (odds.compareTo(bottom) > -1 && odds.compareTo(BigDecimal.ZERO) < 1) {
                // -2.00<=odds<=0
                if (result.equalsIgnoreCase("W") || result.equalsIgnoreCase("WH")) {
                    // win: wash = amount
                    orderEntity.setRemainAmount(orderEntity.getValidAccount());
                } else if (result.equalsIgnoreCase("L") || result.equalsIgnoreCase("LH")) {
                    // lose: wash = amount * odds
                    BigDecimal amount = odds.abs().multiply(orderEntity.getValidAccount()).setScale(2, RoundingMode.HALF_UP);
                    orderEntity.setRemainAmount(amount);
                } else {
                    orderEntity.setRemainAmount(BigDecimal.ZERO);
                }
            } else if (odds.compareTo(BigDecimal.ZERO) > 0 && odds.compareTo(top) < 1) {
                // 0<odds<=2.75
                if (result.equalsIgnoreCase("W") || result.equalsIgnoreCase("HW")) {
                    // win: wash = amount * odds
                    BigDecimal amount = odds.abs().multiply(orderEntity.getValidAccount()).setScale(2, RoundingMode.HALF_UP);
                    orderEntity.setRemainAmount(amount);
                } else if (result.equalsIgnoreCase("L") || result.equalsIgnoreCase("LH")) {
                    // lose: wash = amount
                    orderEntity.setRemainAmount(orderEntity.getValidAccount());
                } else {
                    orderEntity.setRemainAmount(BigDecimal.ZERO);
                }
            } else {
                orderEntity.setRemainAmount(BigDecimal.ZERO);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }


    /**
     * 计算洗码投注额 for Ws Sport
     *  计算规则Rule：有效投注仅计算欧盘1.5（或香港盘0.5）以上的盘口投注;
     *                所有平局、无效、被取消或对赌注单，投注额不被计算在返水投注额内
     */
    public static void calculateValidAndRemainAmountForWsSport(OrderEntity orderEntity) {

        if (orderEntity.getOdds() == null || StringUtils.isBlank(orderEntity.getOddsType())) {
            orderEntity.setRemainAmount(BigDecimal.ZERO);//(洗码)返水投注额
            log.info("{}-WsSport-洗码额度计算-getOdds==0-洗码投注额为0",orderEntity.getLoginName() );
            return;
        }

        UtilConstants.WsSportOddsTypeEnum oddsType = UtilConstants.WsSportOddsTypeEnum.getOddsType(orderEntity.getOddsType());

        //如果没有结算的注单，有效投注额跟洗码投注额为0
        //取消的注單不计算有效投注额
        //未知的oddstype 無法计算有效投注额
        //和局的注单(输赢度为0)，洗码投注额为0。 add by ziv 2018-05-29
        if (orderEntity.getFlag() == UtilConstants.ORDERS_FLAG_ENUM.UNSETTLED.getFalg()
                || orderEntity.getFlag() == UtilConstants.ORDERS_FLAG_ENUM.CANCELED.getFalg()
                || "Cancel".equalsIgnoreCase(orderEntity.getResult())
                || orderEntity.getCusAccount() == null
                || orderEntity.getCusAccount().compareTo(BigDecimal.ZERO) == 0
                || oddsType == null) {
            orderEntity.setValidAccount(BigDecimal.ZERO);//有效投注额
            orderEntity.setRemainAmount(BigDecimal.ZERO);//(洗码)返水投注额
            log.info("{}-WsSport-洗码额度计算-flag!=1-洗码投注额为0",orderEntity.getLoginName() );
            return;
        }
        BigDecimal odds = orderEntity.getOdds();
        switch (oddsType) {//盘口
            case HK://香港盘

                if (odds.compareTo(new BigDecimal("0.5")) < 0) {
                    orderEntity.setRemainAmount(BigDecimal.ZERO);
                    log.info("{}-WsSport-洗码额度计算-HK-odds<0.5-洗码投注额为0",orderEntity.getLoginName() );
                } else {
                    // 洗码投注额的计算，由原来的“输”、“赢”、“半输”、“半赢”、“平”改为用客户输赢度计算 modified by ziv 2018-06-04
                    if (orderEntity.getCusAccount() != null && !orderEntity.getCusAccount().equals(BigDecimal.ZERO)) {
                        orderEntity.setRemainAmount(orderEntity.getValidAccount());
                        log.info("{}-WsSport-洗码额度计算-HK-洗码投注额==ValidAccount",orderEntity.getLoginName() );
                    } else {
                        orderEntity.setRemainAmount(BigDecimal.ZERO);
                        log.info("{}-WsSport-洗码额度计算-HK-盈亏值=0-洗码投注额为0",orderEntity.getLoginName() );
                    }
                }
                break;
            case EU://欧洲盘

                if (odds.compareTo(new BigDecimal("1.5")) < 0) {
                    orderEntity.setRemainAmount(BigDecimal.ZERO);
                    log.info("{}-WsSport-洗码额度计算-EU-odds<1.5-洗码投注额为0",orderEntity.getLoginName() );
                } else {
                    // 洗码投注额的计算，由原来的“输”、“赢”、“半输”、“半赢”、“平”改为用客户输赢度计算
                    if (orderEntity.getCusAccount() != null && !orderEntity.getCusAccount().equals(BigDecimal.ZERO)) {
                        orderEntity.setRemainAmount(orderEntity.getValidAccount());
                    } else {
                        orderEntity.setRemainAmount(BigDecimal.ZERO);
                        log.info("{}-WsSport-洗码额度计算-客户输赢为0-洗码投注额为0",orderEntity.getLoginName() );
                    }
                }
                break;
            default:
                //如果盘口查不到
                orderEntity.setRemainAmount(BigDecimal.ZERO);//(洗码)返水投注额
                log.info("{}-WsSport-洗码额度计算-盘口查不到-洗码投注额为0",orderEntity.getLoginName() );
                break;
        }

        if (orderEntity.getRemainAmount() == null) {
            orderEntity.setRemainAmount(BigDecimal.ZERO);
        }
    }

    /**
     * 计算洗码投注额 for 体育类
     *
     * @param orderEntity
     */
    public static void calculateValidAndRemainAmountForSportGame(OrderEntity orderEntity) {

        if (orderEntity.getOdds() == null || StringUtils.isBlank(orderEntity.getOddsType())) {
            log.error("获取赔率时发现为空！odds is null:[" + orderEntity.getOdds() + "],oddstype is null:[" + StringUtils.isEmpty(orderEntity.getOddsType()) + "]");
            return;
        }

        //NSS要先把盘口转成统一盘口 add by ziv 2018-06-09
        if (UtilConstants.NSS.equals(orderEntity.getPlatId())) {
            orderEntity.setOddsType(convertOddType(orderEntity));
        }

        UtilConstants.OddsTypeEnum oddsType = UtilConstants.OddsTypeEnum.getOddsType(orderEntity.getOddsType());

        //如果没有结算的注单，有效投注额跟洗码投注额为0
        //取消的注單不计算有效投注额
        //未知的oddstype 無法计算有效投注额
        //和局的注单(输赢度为0)，洗码投注额为0。 add by ziv 2018-05-29
        log.info("orderEntity.getFlag()=[" + orderEntity.getFlag() + "], orderEntity.getResult()=[" + orderEntity.getResult() + "], oddsType=[" + orderEntity.getOddsType() + "]");
        if (orderEntity.getFlag() == UtilConstants.ORDERS_FLAG_ENUM.UNSETTLED.getFalg()
                || orderEntity.getFlag() == UtilConstants.ORDERS_FLAG_ENUM.CANCELED.getFalg()
                || "Cancel".equalsIgnoreCase(orderEntity.getResult())
                || "SettleInAdvance".equalsIgnoreCase(orderEntity.getResult())
                || orderEntity.getCusAccount() == null
                || orderEntity.getCusAccount().compareTo(BigDecimal.ZERO) == 0
                || oddsType == null) {
            log.error("order is cenceled or SettleInAdvance or unsettled or oddstype is not defined, can not calculatevalid amount remain amount");
            orderEntity.setValidAccount(BigDecimal.ZERO);//有效投注额
            orderEntity.setRemainAmount(BigDecimal.ZERO);//(洗码)返水投注额
            return;
        }
        switch (oddsType) {//盘口
            case HK://香港盘
                washHKForSportGame(orderEntity);
                break;
            case DECIMAL://欧洲盘
                washEuropeanForSportGame(orderEntity);
                break;
            case MALAY://马来盘
                washMalayForSportGame(orderEntity);
                break;
            case SHABA_INDO://shaba印尼盘
                washIndonesiaForSportGame(orderEntity);
                break;
            case AMERICAN://美洲盘
                washAmericanForSportGame(orderEntity);
                break;
            default:
                //如果盘口查不到，洗码投注额等于有效投注额。 modified by ziv 2018-05-29
                orderEntity.setRemainAmount(orderEntity.getValidAccount().setScale(6, RoundingMode.DOWN));
                break;
        }

        //added by peter. modify the remain amount on cashout situations
        if(UtilConstants.SBT.equals(orderEntity.getPlatId())){
            if("Cashout".equalsIgnoreCase(orderEntity.getStatus())){
                orderEntity.setRemainAmount(orderEntity.getCusAccount().compareTo(BigDecimal.ZERO) < 0 ?
                        orderEntity.getCusAccount().setScale(6, RoundingMode.DOWN).abs() : orderEntity.getValidAccount().setScale(6, RoundingMode.DOWN));
            }
        }
        if(UtilConstants.YSB.equals(orderEntity.getPlatId())){
            if("720".equalsIgnoreCase(orderEntity.getTxnSubtypeId())){ //cashout
                orderEntity.setRemainAmount(orderEntity.getCusAccount().compareTo(BigDecimal.ZERO) < 0 ?
                        orderEntity.getCusAccount().setScale(6, RoundingMode.DOWN).abs() : orderEntity.getValidAccount().setScale(6, RoundingMode.DOWN));
            }
        }
        //TODO GB 体育有提前结算，所以此处要对提前结算做新的处理
        if(UtilConstants.GB.equals(orderEntity.getPlatId())){
            if("Cashout".equalsIgnoreCase(orderEntity.getStatus())){
                orderEntity.setRemainAmount(orderEntity.getCusAccount().compareTo(BigDecimal.ZERO) < 0 ?
                        orderEntity.getCusAccount().setScale(6, RoundingMode.DOWN).abs() : orderEntity.getValidAccount().setScale(6, RoundingMode.DOWN));
            }
        }

        if (orderEntity.getRemainAmount() == null) {
            orderEntity.setRemainAmount(BigDecimal.ZERO);
        }
    }

    /**
     * 计算洗码投注额 : 有效投注额等于洗码投注额
     *
     * @param orderEntity
     */
    public static void calculateValidAndRemainAmountForNoneSportGame(OrderEntity orderEntity) {

        //如果没有结算的注单，有效投注额跟洗码投注额为0
        //取消的注單不计算有效投注额
        //未知的oddstype 無法计算有效投注额
        //和局的注单(输赢度为0)，洗码投注额为0。
        log.info("orderEntity.getFlag()=[" + orderEntity.getFlag() + "], orderEntity.getResult()=[" + orderEntity.getResult() + "], oddsType=[" + orderEntity.getOddsType() + "]");
        if (orderEntity.getFlag() == UtilConstants.ORDERS_FLAG_ENUM.UNSETTLED.getFalg()
                || orderEntity.getFlag() == UtilConstants.ORDERS_FLAG_ENUM.CANCELED.getFalg()
                || "Cancel".equalsIgnoreCase(orderEntity.getResult())
                || "SettleInAdvance".equalsIgnoreCase(orderEntity.getResult())
                || orderEntity.getCusAccount() == null
                || orderEntity.getCusAccount().equals(BigDecimal.ZERO)
                ) {
            log.error("order is cenceled or SettleInAdvance or unsettled or oddstype is not defined, can not calculatevalid amount remain amount");
            orderEntity.setValidAccount(BigDecimal.ZERO);
            orderEntity.setRemainAmount(BigDecimal.ZERO);
            return;
        }

        orderEntity.setRemainAmount(orderEntity.getValidAccount().setScale(6, RoundingMode.DOWN));

        if (orderEntity.getRemainAmount() == null) {
            orderEntity.setRemainAmount(BigDecimal.ZERO);
        }
    }

    /**
     * 轉換NB的盤口代碼為DC的盤口代碼，for DC-API(ObjectConstructUtil.washIndonesiaForSportGame)的洗碼公用API判斷
     * <p>
     * NSS_INDO("30"),//nss印尼盘
     * NSS_MALAY("31"),//nss马来盘
     * NSS_HK("32"),//nss香港盘
     * NSS_DECIMAL("33"),//欧洲盘
     * NSS_MP("0"),//混合过关
     *
     * @param orderEntity
     * @return
     */
    private static String convertOddType(OrderEntity orderEntity) {
        String platFormId = orderEntity.getPlatId();
        UtilConstants.OddsTypeEnum oddsType = UtilConstants.OddsTypeEnum.getOddsType(orderEntity.getOddsType());
        switch (platFormId) {
            case UtilConstants.NSS:
                switch (oddsType) {
                    case NSS_INDO:
                        return UtilConstants.OddsTypeEnum.SHABA_INDO.getValueStr();
                    case NSS_MALAY:
                        return UtilConstants.OddsTypeEnum.MALAY.getValueStr();
                    case NSS_HK:
                        return UtilConstants.OddsTypeEnum.HK.getValueStr();
                    case NSS_DECIMAL:
                        return UtilConstants.OddsTypeEnum.DECIMAL.getValueStr();
                    case NSS_MP:
                        return UtilConstants.OddsTypeEnum.MP.getValueStr();
                }
        }
        return orderEntity.getOddsType();
    }

    private static void washHKForSportGame(OrderEntity orderEntity) {
        try {
            BigDecimal odds = orderEntity.getOdds();

            log.info("Wash  for HK, odds=" + odds);

            if (odds.compareTo(new BigDecimal("0.5")) < 0) {
                //0.5<= odds
                orderEntity.setRemainAmount(BigDecimal.ZERO);
            } else {
                //0.5<= odds
                // 赢/赢一半：本金
                // 输/输一半：本金
                // 洗码投注额的计算，由原来的“输”、“赢”、“半输”、“半赢”、“平”改为用客户输赢度计算 modified by ziv 2018-06-04
                if (orderEntity.getCusAccount() != null && !orderEntity.getCusAccount().equals(BigDecimal.ZERO)) {
                    orderEntity.setRemainAmount(orderEntity.getValidAccount());
                } else {
                    orderEntity.setRemainAmount(BigDecimal.ZERO);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static void washEuropeanForSportGame(OrderEntity orderEntity) {
        try {
            String result = orderEntity.getResult();

            BigDecimal odds = orderEntity.getOdds();

            log.info("Wash  for European, odds=" + odds);

            if (odds.compareTo(new BigDecimal("1.5")) < 0) {
                //odds < 1.5
                orderEntity.setRemainAmount(BigDecimal.ZERO);
            } else {
                //1.5 <=  odds
                // 赢/赢一半：本金
                // 输/输一半：本金
                // 洗码投注额的计算，由原来的“输”、“赢”、“半输”、“半赢”、“平”改为用客户输赢度计算 modified by ziv 2018-06-04
                if (orderEntity.getCusAccount() != null && !orderEntity.getCusAccount().equals(BigDecimal.ZERO)) {
                    orderEntity.setRemainAmount(orderEntity.getValidAccount());
                } else {
                    orderEntity.setRemainAmount(BigDecimal.ZERO);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 马来盘
     *
     * @param orderEntity
     */
    private static void washMalayForSportGame(OrderEntity orderEntity) {
        try {
            BigDecimal odds = orderEntity.getOdds();

            log.info("Wash  for Malay, odds=" + odds);

            if (odds.compareTo(new BigDecimal("0")) < 0) {
                // odds < 0 by wythe 2018-10-08 修改
                orderEntity.setRemainAmount(orderEntity.getValidAccount());
            } else if (odds.compareTo(new BigDecimal("0")) > 0 && odds.compareTo(new BigDecimal("0.5")) < 0) {
                //0< odds<0.5 by wythe 2018-10-08 修改
                orderEntity.setRemainAmount(BigDecimal.ZERO);
            } else if (odds.compareTo(new BigDecimal("0.5")) >= 0) {
                //0.5<=odds by wythe 2018-10-08 修改
                orderEntity.setRemainAmount(orderEntity.getValidAccount());
            } else {
                //1 < odds
                //0（无此赔率）
                orderEntity.setRemainAmount(BigDecimal.ZERO);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

    }


    /**
     * 印尼盘
     *
     * @param orderEntity
     */
    private static void washIndonesiaForSportGame(OrderEntity orderEntity) {
        try {
            BigDecimal odds = orderEntity.getOdds();

            log.info("Wash  for Indonesia,odds=" + odds);

            if (odds.compareTo(new BigDecimal("-2")) < 0) {
                //odds < -2.00
                orderEntity.setRemainAmount(BigDecimal.ZERO);
            } else if (odds.compareTo(new BigDecimal(-2)) >= 0) {
                //-2.00 <= odds  by wythe 2018-10-08 修改
                orderEntity.setRemainAmount(orderEntity.getValidAccount());
            } else {
                //2.75< odds
                orderEntity.setRemainAmount(BigDecimal.ZERO);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 美洲盘
     *
     * @param orderEntity
     */
    private static void washAmericanForSportGame(OrderEntity orderEntity) {
        try {
            BigDecimal odds = orderEntity.getOdds();//赔率

            log.info("Wash  for American,odds=" + odds);

            if (odds.compareTo(new BigDecimal("-200")) < 0) {
                //odds < -200
                orderEntity.setRemainAmount(BigDecimal.ZERO);
            } else if (odds.compareTo(new BigDecimal("-200")) >= 0) {
                //-200 <= odds  by wythe 2018-10-08 修改
                orderEntity.setRemainAmount(orderEntity.getValidAccount());
            } else {
                //275< odds
                orderEntity.setRemainAmount(BigDecimal.ZERO);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}