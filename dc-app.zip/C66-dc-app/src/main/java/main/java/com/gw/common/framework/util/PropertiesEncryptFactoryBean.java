package main.java.com.gw.common.framework.util;


import com.intech.dbcryptor.Cryptor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.FactoryBean;
import java.util.Properties;

@Slf4j
public class PropertiesEncryptFactoryBean implements FactoryBean {

    private Properties properties;

    public Object getObject() throws Exception {
        return getProperties();
    }

    @SuppressWarnings("unchecked")
    public Class getObjectType() {
        return java.util.Properties.class;
    }

    public boolean isSingleton() {
        return true;
    }

    public Properties getProperties() {
        return properties;
    }

    public void setProperties(Properties inProperties) {
        this.properties = inProperties;
        String originalUsername = properties.getProperty("user");
        String originalPassword = properties.getProperty("password");
        log.debug("解密前用户名:" + originalUsername);
        log.debug("解密前密码:" + originalPassword);
        // PHPDESEncrypt db = new PHPDESEncrypt("DBA", "");
        if (originalUsername != null) {
            String newUsername = null;
            try {
                newUsername = Cryptor.decryptContent(originalUsername); //db.decrypt(originalUsername);
            } catch (Exception e) {
                log.error("数据库用户名解密失败" + e.getMessage(), e);
            }
            properties.put("user", newUsername);
        }
        if (originalPassword != null) {
            String newPassword = null;
            try {
                newPassword = Cryptor.decryptContent(originalPassword); //db.decrypt(originalPassword);
            } catch (Exception e) {
                log.error("数据库密码解密失败" + e.getMessage(), e);
            }
            properties.put("password", newPassword);
        }
    }


}

