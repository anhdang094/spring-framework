package main.java.com.gw.common.framework.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.Cipher;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

public class RSAUtil {

    protected static Logger log = LoggerFactory.getLogger(RSAUtil.class);
    /**
     * RSA密钥长度和加解密数据块长度有关联，以下是计算公式
     */
    private static final int KEY_SIZE          = 2048;
    private static final int MAX_DECRYPT_BLOCK = KEY_SIZE / 8;
    private static final int MAX_ENCRYPT_BLOCK = MAX_DECRYPT_BLOCK - 11;


    /**
     * RSA 加密操作
     * @param data
     * @param publicKey
     * @return
     */
    public static String encryptRSA(String data, String publicKey) {
        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(Cipher.ENCRYPT_MODE, getPublicKey(publicKey));
            byte[] dataBytes = data.getBytes(StandardCharsets.UTF_8);
            int inputLen = dataBytes.length;
            int offSet = 0;
            byte[] buf;
            // 对数据分段加密
            while (inputLen - offSet > 0) {
                if (inputLen - offSet > MAX_ENCRYPT_BLOCK) {
                    buf = cipher.doFinal(dataBytes, offSet, MAX_ENCRYPT_BLOCK);
                } else {
                    buf = cipher.doFinal(dataBytes, offSet, inputLen - offSet);
                }
                out.write(buf, 0, buf.length);
                offSet += MAX_ENCRYPT_BLOCK;
            }
            return Base64.getEncoder().encodeToString(out.toByteArray());
        } catch (Exception e) {
            log.error("RSA加密操作出现异常:params={}",data,e.getMessage());
            throw new RuntimeException("RSA加密操作出现异常");
        }
    }

    /**
     * RSA 解密密操作
     * @param data
     * @param publicKey
     * @return
     */
    public static String decryptRSA(String data, String publicKey) {
        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Cipher cipher = Cipher.getInstance("RSA");
            cipher.init(Cipher.DECRYPT_MODE, getPublicKey(publicKey));
            byte[] dataBytes = Base64.getDecoder().decode(data);
            int inputLen = dataBytes.length;
            int offSet = 0;
            byte[] buf;
            while (inputLen - offSet > 0) {
                if (inputLen - offSet > MAX_DECRYPT_BLOCK) {
                    buf = cipher.doFinal(dataBytes, offSet, MAX_DECRYPT_BLOCK);
                } else {
                    buf = cipher.doFinal(dataBytes, offSet, inputLen - offSet);
                }
                out.write(buf, 0, buf.length);
                offSet += MAX_DECRYPT_BLOCK;
            }
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        } catch (Exception e) {
            log.error("RSA加密操作出现异常params={}",data,e.getMessage());
        }
        return null;
    }

    private static Key getPublicKey(String publicKey) {
        try {
            X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(publicKey));
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            return keyFactory.generatePublic(keySpec);
        } catch (Exception e) {
            log.error("RSA生成Key出现异常",e.getMessage());
        }
        return null;
    }


    public static void main(String[] args) {
        try {
            String publicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCGsHrZ3b+jMwSXvPMKwTK3c79/Hf+UKj5rWFyluYCMoqB2/3CVVAqEgsLETA4/iHstOgYoMEWo5pKdvXDAyIYoio5aHBwk0ZBnubRdb2hZsjF37opyxzsLVstGVM6A5fNE077Il6iSuq3GO0QPuG+TnCkkb6K47s2NNjpXhDv4qwIDAQAB";
            String secretKey=AESUtil.generateSecretKey();
            String encryptedSecretKey = encryptRSA(secretKey, publicKey);
            log.info("RAS 加密后的内容：{}",encryptedSecretKey);
            log.info("RAS 解密密后的内容：{}",encryptedSecretKey);

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
    }
}
