package main.java.com.gw.common.framework.util;

import lombok.extern.slf4j.Slf4j;

import java.lang.reflect.Field;

/**
 * Created by Ricardo.X on 2017/9/23.
 */
@Slf4j
public class ReflactionUtils {

    public static <T> T takeValueFromField(Object obj, String fieldName, Class<T> valueType) {

        if (obj == null || fieldName == null)
            return null;
        try {
            Class<?> c = obj.getClass();
            Field field = c.getDeclaredField(fieldName);
            return takeValueFromField(obj, field, valueType);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    public static <T> T takeValueFromField(Object obj, String fieldName, Class<?> objType, Class<T> valueType) {

        if (obj == null || fieldName == null)
            return null;
        try {
            Field field = objType.getDeclaredField(fieldName);
            return takeValueFromField(obj, field, valueType);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    public static <T> T takeValueFromField(Object obj, Field field, Class<T> valueType) {

        if (obj == null || field == null)
            return null;

        try {

            if (!field.isAccessible())
                field.setAccessible(Boolean.TRUE);
            Object value = field.get(obj);
            if (value != null)
                return valueType.cast(value);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        return null;
    }


}
