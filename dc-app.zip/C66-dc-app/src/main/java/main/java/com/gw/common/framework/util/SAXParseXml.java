/**
 *
 */
package main.java.com.gw.common.framework.util;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.exception.GWPersistenceException;
import main.java.com.gw.common.framework.exception.GWSAXParseException;
import main.java.com.gw.datacenter.allocation.dao.AllocationDao;
import main.java.com.gw.datacenter.order.dao.OrderDao;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

/**
 * @author alex.l
 */

@Slf4j
@SuppressWarnings("rawtypes")
public class SAXParseXml extends DefaultHandler {

    //store total records.
    private int index = 0;

    //store the error or warning infos.
    private Locator locator;

    //store all the tag with Stack.
    Stack<String> tags = new Stack<String>();

    private Class<Object> claz = null;

    private String platformId = null;

    private List<Object> objectList = new ArrayList<Object>();

    //total records.
    private int apiTotal = 0;

    //error info.
    private String info = null;

    // Constructor
    public SAXParseXml() {
        super();
    }

    @SuppressWarnings("unchecked")
    public SAXParseXml(String platformId, Class claz) {
        this.claz = claz;
        this.platformId = platformId;
    }

    // Response the startDocument event
    public void startDocument() {
        log.info("platformId:" + platformId + " Call startDocument(),开始解析xml...");
    }

    /**
     * Response the startElement event
     *
     * @param uri
     * @param localName
     * @param qName
     * @param attrs
     */
    public void startElement(String uri, String localName, String qName, Attributes attrs) {
        tags.push(qName);
        Object obj = null;
        if (qName.equalsIgnoreCase("row")||qName.equalsIgnoreCase("record")) {
            index++;
            obj = ObjectConstructUtil.readAttributes(attrs, platformId, claz);
            this.objectList.add(obj);
        }
    }

    /**
     * 返回节点开始和结束之间的字符.如<element>12345</element>,返回12345
     *
     * @param start
     * @param length
     */
    public void characters(char ch[], int start, int length) throws SAXException {
        String tag = tags.peek();
        if (tag.equalsIgnoreCase("total") && apiTotal == 0) {
            this.apiTotal = Integer.valueOf(new String(ch, start, length));
        }
        if (tag.equalsIgnoreCase("info")) {
            this.info = new String(ch, start, length).trim();
        }
        //log.debug("----------Call characters()----------");
    }

    /**
     * Response the endElement event
     *
     * @param uri
     * @param localName
     * @param qName
     */
    public void endElement(String uri, String localName, String qName) {
        // add your codes if neccessary ...
        //log.debug("-------endElement()---------:"+localName);
    }

    // Response the endDocument event
    public void endDocument() {
        log.info(String.format("platformId:%s totalRecord:%s   Call endDocument(),解析xml结束！共解析" + index + "条数据！", platformId, apiTotal));
    }

    // Print the fata error information
    public void fatalError(SAXParseException e) {
        log.error("XML解析发生严重错误：" + e.getMessage());
        log.error("At line " + locator.getLineNumber() + ",column " + locator.getColumnNumber());
        //e.printStackTrace();
    }

    // Print the usual error information
    public void error(SAXParseException e) {
        log.error("XML解析报错信息：" + e.getMessage());
        log.error("At line " + locator.getLineNumber() + ",column " + locator.getColumnNumber());
        //e.printStackTrace();
    }

    // Print the warning information
    public void warning(SAXParseException e) {
        log.info("XML解析警告信息：" + e.getMessage());
        log.info("At line " + locator.getLineNumber() + ",column " + locator.getColumnNumber());
        //e.printStackTrace();
    }

    // Store the error locator object
    public void setDocumentLocator(Locator lct) {
        locator = lct;
    }

    /**
     * Begin to parse XML.
     *
     * @param xmlStr
     * @param claz
     * @return saxParseXml
     * @throws GWSAXParseException
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     */
    public static SAXParseXml parse(String xmlStr, String platformId, Class claz) throws GWSAXParseException {
        SAXParseXml saxParseXml = new SAXParseXml(platformId, claz);
        InputSource inputsource = new InputSource(new StringReader(xmlStr));
        SAXParserFactory saxfactory = SAXParserFactory.newInstance();
        SAXParser saxparser = null;
        try {
            saxparser = saxfactory.newSAXParser();
            saxparser.parse(inputsource, saxParseXml);
        } catch (Exception e) {
            log.error("Fail to call SAXParseXmlByNode.parse(),Exception:" + e.getMessage(), e);
            throw new GWSAXParseException(e.getMessage());
        }
        return saxParseXml;
    }

    /**
     * @return the objectList
     */
    public List<Object> getObjectList() {
        return objectList;
    }

    /**
     * @return the apiTotal
     */
    public int getApiTotal() {
        return apiTotal;
    }

    /**
     * @return the info
     */
    public String getInfo() {
        return info;
    }

    /**
     * @return the index
     */
    public int getIndex() {
        return index;
    }

    public static void main(String[] args) throws GWSAXParseException, GWPersistenceException {
        //String xml="<result><info>0</info> <row SESSION_ID=\"2314\" PRODUCTID=\"TST\" USERNAME=\"test41099\" RECKONTIME=\"2017-01-24 01:53:43\" CREDIT=\"686.9\" RMB_CREDIT=\"686.9\" CURRENCY=\"CNY\" FLAG=\"1\" /><row SESSION_ID=\"2315\" PRODUCTID=\"TST\" USERNAME=\"test41099\" RECKONTIME=\"2017-01-24 01:56:27\" CREDIT=\"618.4\" RMB_CREDIT=\"618.4\" CURRENCY=\"CNY\" FLAG=\"1\" /><row SESSION_ID=\"2316\" PRODUCTID=\"TST\" USERNAME=\"test41099\" RECKONTIME=\"2017-01-24 01:59:10\" CREDIT=\"658.4\" RMB_CREDIT=\"658.4\" CURRENCY=\"CNY\" FLAG=\"1\" /><row SESSION_ID=\"2317\" PRODUCTID=\"TST\" USERNAME=\"test41099\" RECKONTIME=\"2017-01-24 02:01:54\" CREDIT=\"694.7\" RMB_CREDIT=\"694.7\" CURRENCY=\"CNY\" FLAG=\"1\" /> <addition> <total>4</total> <num_per_page>100</num_per_page> <currentpage>1</currentpage> <totalpages>1</totalpages> <perpage>4</perpage> </addition> </result> ";
        //String xml="<result><addition><total>572</total><num_per_page>400</num_per_page></addition><row billno=\"170909053351838\" mainbillno=\"\" productid=\"A01\" username=\"gwmf1991\" agcode=\"038001001001001\" billtime=\"2017-09-09 05:05:37\" reckontime=\"2017-09-09 05:05:40\" slottype=\"1\" currency=\"CNY\" gametype=\"PKBJ\" cur_ip=\"117.136.44.199\" account=\"1\" cus_account=\"0.100000\" valid_account=\"1\" account_base=\"1\" account_bonus=\"0\" cus_account_base=\"0.100000\" cus_account_bonus=\"0\" BASEPOINT=\"30.700000\" flag=\"1\" remark=\"\" platformtype=\"SLOT\" result=\"\" /><row billno=\"170909053343750\" mainbillno=\"\" productid=\"A01\" username=\"gwmf1991\" agcode=\"038001001001001\" billtime=\"2017-09-09 05:05:27\" reckontime=\"2017-09-09 05:05:31\" slottype=\"1\" currency=\"CNY\" gametype=\"PKBJ\" cur_ip=\"117.136.44.199\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" account_base=\"1\" account_bonus=\"0\" cus_account_base=\"-1\" cus_account_bonus=\"0\" BASEPOINT=\"30.600000\" flag=\"1\" remark=\"\" platformtype=\"SLOT\" result=\"\" /><row billno=\"170909053329920\" mainbillno=\"170909053329920\" productid=\"A01\" username=\"ggyy0435\" agcode=\"038001001001001\" billtime=\"2017-09-09 05:05:11\" reckontime=\"2017-09-09 05:05:12\" slottype=\"1\" currency=\"CNY\" gametype=\"SB37\" cur_ip=\"221.236.137.52\" account=\"0.800000\" cus_account=\"-0.800000\" valid_account=\"0.800000\" account_base=\"0.800000\" account_bonus=\"0\" cus_account_base=\"-0.800000\" cus_account_bonus=\"0\" BASEPOINT=\"10.180000\" flag=\"1\" remark=\"\" platformtype=\"SLOT\" result=\"9,3,11,1,9,7,8,101,1,101,4,5,11,1,7,6,11,8,1,2\" /></result>";
        String xml = "<result><addition><total>208</total><num_per_page>1600</num_per_page></addition><row billno=\"1709291813982506\" productid=\"A03\" username=\"f1111515\" loginname=\"A03f1111515\" agcode=\"005001001001001\" gmcode=\"13\" billtime=\"2017-09-29 18:57:46\" reckontime=\"2017-09-29 22:53:54\" playtype=\"769\" currency=\"CNY\" round=\"2017265\" remark=\"0, 0, 4, 0, 0\" account=\"3015\" cus_account=\"2864.25\" BASEPOINT=\"3015.2400000000002\" flag=\"1\" valid_account=\"3015\" device=\"19\"/></result>";
        SAXParseXml XX = new SAXParseXml();
        SAXParseXml sax = SAXParseXml.parse(xml, "004", OrderEntity.class);
        System.err.println(sax.getObjectList());
        String confDir = File.separator + System.getProperty("user.dir") + File.separator + "conf";
        FileSystemXmlApplicationContext factory = new FileSystemXmlApplicationContext(confDir + "/spring/applicationContext.xml");
        OrderDao orderDao = (OrderDao) factory.getBean("orderDao");
        AllocationDao allocationDao = (AllocationDao) factory.getBean("allocationDao");
        SqlSessionFactory myBatisSessionFactory = (SqlSessionFactory) factory.getBean("myBatisSessionFactory");
        SqlSession session = myBatisSessionFactory.openSession();
//		ToolUtil.initSpecialGames("TST", "004", allocationDao);
        List<Object> orderLit = sax.getObjectList();
        for (int i = 0; i < orderLit.size(); i++) {
            OrderEntity _order = (OrderEntity) orderLit.get(i);
            _order.setGameKind("12");
            _order.setGmCode("0");
            _order.setBillTime(_order.getReckonTime());
            _order.setOrignalBillTime(_order.getBillTime());
            _order.setOrignalReckonTime(_order.getBillTime());
            _order.setBonusAmount(new BigDecimal(0));
        }

        orderDao.insertOrder4K8(orderLit, session, false);
    }
}