/**
 *
 */
package main.java.com.gw.common.framework.util;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.exception.GWPersistenceException;
import main.java.com.gw.common.framework.exception.GWSAXParseException;
import main.java.com.gw.datacenter.accounttransfer.entity.AccountTransferEntity;
import main.java.com.gw.datacenter.order.dao.OrderDao;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

/**
 * @author alex.l
 */

@Slf4j
@SuppressWarnings("unchecked")
public class SAXParseXmlByNode extends DefaultHandler {

    // store total records.
    private int index = 0;

    // store the error or warning infos.
    private Locator locator;

    // store all the tag with Stack.
    Stack<String> tags = new Stack<String>();

    private Class<Object> claz = null;

    private String platformId = null;

    private List objectList = new ArrayList();

    // total records.
    private int apiTotal = 0;
    // page size
    private int apiPageSize = 0;

    // error info.
    private String info = null;

    private AccountTransferEntity accountTransferEntity = null;

    private OrderEntity orderEntity = null;

    private String preTag = null;

    // Constructor
    public SAXParseXmlByNode() {
        super();
    }

    public SAXParseXmlByNode(String platformId, Class claz) {
        this.claz = claz;
        this.platformId = platformId;
    }

    // Response the startDocument event
    public void startDocument() {
        log.info(String.format("platformId:%s Call startDocument(),开始解析xml...", platformId));
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public void setPlatformId(String platformId) {
        this.platformId = platformId;
    }

    public void setObjectList(List objectList) {
        this.objectList = objectList;
    }

    public void setApiTotal(int apiTotal) {
        this.apiTotal = apiTotal;
    }

    public void setApiPageSize(int apiPageSize) {
        this.apiPageSize = apiPageSize;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    /**
     * Response the startElement event
     *
     * @param uri
     * @param localName
     * @param qName
     * @param attrs
     */
    public void startElement(String uri, String localName, String qName, Attributes attrs) {
        tags.push(qName);
        try {
            if (this.claz.newInstance() instanceof OrderEntity) {
                if ("Data".equalsIgnoreCase(qName)) {
                    int attrCount = attrs.getLength();
                    if (attrCount > 0) {
                        if (!StringUtils.isBlank(attrs.getValue("TotalPage"))) {
                            this.apiPageSize = Integer.valueOf(attrs.getValue("TotalPage"));
                        }
                        if (!StringUtils.isBlank(attrs.getValue("TotalNumber"))) {
                            this.apiTotal = Integer.valueOf(attrs.getValue("TotalNumber"));
                        }
                    }
                }
                if ("Record".equalsIgnoreCase(qName)) {
                    index++;
                    orderEntity = new OrderEntity();
                }
            } else if (this.claz.newInstance() instanceof AccountTransferEntity) {
                if ("Data".equalsIgnoreCase(qName)) {
                    int attrCount = attrs.getLength();
                    if (attrCount > 0) {
                        if (!StringUtils.isBlank(attrs.getValue("TotalPage"))) {
                            this.apiPageSize = Integer.valueOf(attrs.getValue("TotalPage"));
                        }
                        if (!StringUtils.isBlank(attrs.getValue("TotalNumber"))) {
                            this.apiTotal = Integer.valueOf(attrs.getValue("TotalNumber"));
                        }
                    }
                }
                if ("row".equalsIgnoreCase(qName) || "Record".equalsIgnoreCase(qName)) {
                    index++;
                    accountTransferEntity = new AccountTransferEntity();
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        preTag = qName;
    }

    /**
     * 返回节点开始和结束之间的字符.如<element>12345</element>,返回12345
     *
     * @param ch
     * @param start
     * @param length
     */
    public void characters(char ch[], int start, int length) throws SAXException {
        String tag = tags.peek();

        if (tag.equalsIgnoreCase("info") || tag.equalsIgnoreCase("Message") || tag.equalsIgnoreCase("Code")) {
            this.info = new String(ch, start, length).trim();
        } else if (tag.equalsIgnoreCase("total") && apiTotal == 0) {
            this.apiTotal = Integer.valueOf(new String(ch, start, length));
        }

        if (preTag != null && accountTransferEntity != null && !preTag.equalsIgnoreCase("record") && !preTag.equalsIgnoreCase("row")) {
            String cotent = new String(ch, start, length);
            //add by edwin
            if (tag.equalsIgnoreCase("info") || tag.equalsIgnoreCase("Message") || tag.equalsIgnoreCase("Code")) {
                this.info = new String(ch, start, length).trim();
            } else {
                ObjectConstructUtil.readNodesForAccountTransfer(accountTransferEntity, preTag, cotent, platformId, claz);
            }

        } else if (preTag != null && !preTag.equalsIgnoreCase("record") && orderEntity != null) {
            String cotent = new String(ch, start, length);
            //add by edwin
            if (tag.equalsIgnoreCase("info") || tag.equalsIgnoreCase("Message") || tag.equalsIgnoreCase("Code")) {
                this.info = new String(ch, start, length).trim();
            } else {
                ObjectConstructUtil.readNodesForBBINOrder(orderEntity, preTag, cotent, platformId, claz);
            }

        }

        // log.debug("----------Call characters()----------");
    }

    /**
     * Response the endElement event
     *
     * @param uri
     * @param localName
     * @param qName
     */
    public void endElement(String uri, String localName, String qName) {
        // log.debug("-------endElement()---------:"+localName);
        if (("row".equalsIgnoreCase(qName) || "Record".equalsIgnoreCase(qName)) && accountTransferEntity != null) {
            this.objectList.add(accountTransferEntity);
        } else if ("Record".equalsIgnoreCase(qName) && orderEntity != null) {
            this.objectList.add(orderEntity);
        }
        preTag = null;
    }

    // Response the endDocument event
    public void endDocument() {
        // TODO: 2016/8/27 AGQJ 注单活动处理
        if (accountTransferEntity != null) {
            //连赢
            String transferType = accountTransferEntity.getTransferType();
            if (StringUtils.isNotBlank(transferType) && StringUtils.isNotBlank(accountTransferEntity.getName())) {
                if ("ACTIVITY".equals(transferType.trim()) && "#EVENWIN_REWARD#".equals(accountTransferEntity.getName().trim())) {
                    String name = accountTransferEntity.getName();//#EVENWIN_REWARD#
                    accountTransferEntity.setTransferType(name.replaceAll("#", ""));
                }
            }
        }
        log.info(String.format("platformId:%s totalRecord:%s   Call endDocument(),解析xml结束！共解析" + index + "条数据！", platformId, apiTotal));
    }

    // Print the fata error information
    public void fatalError(SAXParseException e) {
        log.error("XML解析发生严重错误：" + e.getMessage());
        log.error("At line " + locator.getLineNumber() + ",column " + locator.getColumnNumber());
        // e.printStackTrace();
    }

    // Print the usual error information
    public void error(SAXParseException e) {
        log.error("XML解析报错信息：" + e.getMessage());
        log.error("At line " + locator.getLineNumber() + ",column " + locator.getColumnNumber());
        // e.printStackTrace();
    }

    // Print the warning information
    public void warning(SAXParseException e) {
        log.info("XML解析警告信息：" + e.getMessage());
        log.info("At line " + locator.getLineNumber() + ",column " + locator.getColumnNumber());
        // e.printStackTrace();
    }

    // Store the error locator object
    public void setDocumentLocator(Locator lct) {
        locator = lct;
    }

    /**
     * Begin to parse XML.
     *
     * @param xmlStr
     * @param claz
     * @return saxParseXml
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     */
    public static SAXParseXmlByNode parse(String xmlStr, String platformId, Class claz) throws GWSAXParseException {
        SAXParseXmlByNode saxParseXml = new SAXParseXmlByNode(platformId, claz);
        InputSource inputsource = new InputSource(new StringReader(xmlStr));
        SAXParserFactory saxfactory = SAXParserFactory.newInstance();
        SAXParser saxparser = null;
        try {
            saxparser = saxfactory.newSAXParser();
            saxparser.parse(inputsource, saxParseXml);
        } catch (Exception e) {
            log.error("Fail to call SAXParseXmlByNode.parse(),Exception:" + e.getMessage(), e);
            throw new GWSAXParseException(e.getMessage());
        }
        return saxParseXml;
    }

    /**
     * @return the objectList
     */
    public List getObjectList() {
        return objectList;
    }

    /**
     * @return the apiTotal
     */
    public int getApiTotal() {
        return apiTotal;
    }

    /**
     * @return the info
     */
    public String getInfo() {
        return info;
    }

    /**
     * @return the index
     */
    public int getIndex() {
        return index;
    }

    /**
     * @return the apiPageSize
     */
    public int getApiPageSize() {
        return apiPageSize;
    }

    public static void main(String[] args) throws GWSAXParseException, GWPersistenceException {
        //	String xml="<result><addition><total>51</total><num_per_page>400</num_per_page></addition><row billno=\"1704121309808340\" productid=\"E04\" username=\"dhaomeile\" loginname=\"E04dhaomeile\" agcode=\"009001001001001\" gmcode=\"09\" billtime=\"2017-04-12 13:24:18\" reckontime=\"2017-04-12 13:25:17\" playtype=\"1\" currency=\"CNY\" round=\"1704120725\" remark=\" \" account=\"10\" cus_account=\"9.6\" BASEPOINT=\"179.64000000000001\" flag=\"1\" valid_account=\"10\" device=\"1\"/><row billno=\"1704121309808311\" productid=\"A01\" username=\"gbaynihmjy\" loginname=\"A01gbaynihmjy\" agcode=\"003001001001001\" gmcode=\"09\" billtime=\"2017-04-12 13:22:03\" reckontime=\"2017-04-12 13:25:17\" playtype=\"20\" currency=\"CNY\" round=\"1704120725\" remark=\" \" account=\"25\" cus_account=\"90\" BASEPOINT=\"825.89\" flag=\"1\" valid_account=\"25\" device=\"33\"/><row billno=\"1704121309808315\" productid=\"A01\" username=\"gydrh\" loginname=\"A01gydrh\" agcode=\"003001001001001\" gmcode=\"09\" billtime=\"2017-04-12 13:22:16\" reckontime=\"2017-04-12 13:25:17\" playtype=\"3\" currency=\"CNY\" round=\"1704120725\" remark=\" \" account=\"500\" cus_account=\"-500\" BASEPOINT=\"11580.2\" flag=\"1\" valid_account=\"500\" device=\"1\"/><row billno=\"1704121309808333\" productid=\"E04\" username=\"dfxl12345\" loginname=\"E04dfxl12345\" agcode=\"009001001001001\" gmcode=\"09\" billtime=\"2017-04-12 13:23:35\" reckontime=\"2017-04-12 13:25:17\" playtype=\"3\" currency=\"CNY\" round=\"1704120725\" remark=\" \" account=\"10\" cus_account=\"-10\" BASEPOINT=\"90.16\" flag=\"1\" valid_account=\"10\" device=\"33\"/><row billno=\"1704121309808314\" productid=\"A01\" username=\"gf11912\" loginname=\"A01gf11912\" agcode=\"003001001001001\" gmcode=\"09\" billtime=\"2017-04-12 13:22:15\" reckontime=\"2017-04-12 13:25:17\" playtype=\"3\" currency=\"CNY\" round=\"1704120725\" remark=\" \" account=\"31\" cus_account=\"-31\" BASEPOINT=\"68.92\" flag=\"1\" valid_account=\"31\" device=\"33\"/><row billno=\"1704121309808324\" productid=\"A01\" username=\"gf5686\" loginname=\"A01gf5686\" agcode=\"003001001001001\" gmcode=\"09\" billtime=\"2017-04-12 13:22:34\" reckontime=\"2017-04-12 13:25:17\" playtype=\"5\" currency=\"CNY\" round=\"1704120725\" remark=\" \" account=\"100\" cus_account=\"-100\" BASEPOINT=\"8698.48\" flag=\"1\" valid_account=\"100\" device=\"33\"/><row billno=\"1704121309808322\" productid=\"A01\" username=\"gf5686\" loginname=\"A01gf5686\" agcode=\"003001001001001\" gmcode=\"09\" billtime=\"2017-04-12 13:22:31\" reckontime=\"2017-04-12 13:25:17\" playtype=\"3\" currency=\"CNY\" round=\"1704120725\" remark=\" \" account=\"100\" cus_account=\"-100\" BASEPOINT=\"8798.48\" flag=\"1\" valid_account=\"100\" device=\"33\"/><row billno=\"1704121307808305\" productid=\"A01\" username=\"gflaura\" loginname=\"A01gflaura\" agcode=\"003001001001001\" gmcode=\"07\" billtime=\"2017-04-12 13:21:47\" reckontime=\"2017-04-12 13:25:22\" playtype=\"1\" currency=\"CNY\" round=\"160929\" remark=\" \" account=\"611\" cus_account=\"-611\" BASEPOINT=\"611.24\" flag=\"1\" valid_account=\"611\" device=\"19\"/><row billno=\"1704121307808295\" productid=\"A01\" username=\"gwxiaojiu\" loginname=\"A01gwxiaojiu\" agcode=\"003001001001001\" gmcode=\"07\" billtime=\"2017-04-12 13:21:22\" reckontime=\"2017-04-12 13:25:22\" playtype=\"1\" currency=\"CNY\" round=\"160929\" remark=\" \" account=\"10\" cus_account=\"-10\" BASEPOINT=\"399.6\" flag=\"1\" valid_account=\"10\" device=\"19\"/><row billno=\"1704121307808307\" productid=\"A01\" username=\"gf11912\" loginname=\"A01gf11912\" agcode=\"003001001001001\" gmcode=\"07\" billtime=\"2017-04-12 13:22:00\" reckontime=\"2017-04-12 13:25:22\" playtype=\"3\" currency=\"CNY\" round=\"160929\" remark=\" \" account=\"15\" cus_account=\"14.4\" BASEPOINT=\"83.92\" flag=\"1\" valid_account=\"15\" device=\"33\"/><row billno=\"1704121307808313\" productid=\"A01\" username=\"gydrh\" loginname=\"A01gydrh\" agcode=\"003001001001001\" gmcode=\"07\" billtime=\"2017-04-12 13:22:10\" reckontime=\"2017-04-12 13:25:22\" playtype=\"3\" currency=\"CNY\" round=\"160929\" remark=\" \" account=\"500\" cus_account=\"480\" BASEPOINT=\"12080.2\" flag=\"1\" valid_account=\"500\" device=\"1\"/><row billno=\"1704121301808289\" productid=\"C01\" username=\"rshenme1\" loginname=\"C01rshenme1\" agcode=\"021001001001001\" gmcode=\"01\" billtime=\"2017-04-12 13:21:00\" reckontime=\"2017-04-12 13:25:45\" playtype=\"1\" currency=\"CNY\" round=\"817449\" remark=\" \" account=\"500\" cus_account=\"480\" BASEPOINT=\"4792.99\" flag=\"1\" valid_account=\"500\" device=\"33\"/><row billno=\"1704121301808290\" productid=\"A01\" username=\"gflaura\" loginname=\"A01gflaura\" agcode=\"003001001001001\" gmcode=\"01\" billtime=\"2017-04-12 13:21:07\" reckontime=\"2017-04-12 13:25:45\" playtype=\"1\" currency=\"CNY\" round=\"817449\" remark=\" \" account=\"200\" cus_account=\"192\" BASEPOINT=\"2211.2400000000002\" flag=\"1\" valid_account=\"200\" device=\"19\"/><row billno=\"1704121301808334\" productid=\"E04\" username=\"dhaomeile\" loginname=\"E04dhaomeile\" agcode=\"009001001001001\" gmcode=\"01\" billtime=\"2017-04-12 13:23:36\" reckontime=\"2017-04-12 13:25:45\" playtype=\"1\" currency=\"CNY\" round=\"817449\" remark=\" \" account=\"10\" cus_account=\"9.6\" BASEPOINT=\"189.64000000000001\" flag=\"1\" valid_account=\"10\" device=\"1\"/><row billno=\"1704121301808304\" productid=\"A01\" username=\"gf11912\" loginname=\"A01gf11912\" agcode=\"003001001001001\" gmcode=\"01\" billtime=\"2017-04-12 13:21:36\" reckontime=\"2017-04-12 13:25:45\" playtype=\"1\" currency=\"CNY\" round=\"817449\" remark=\" \" account=\"20\" cus_account=\"19.2\" BASEPOINT=\"103.92\" flag=\"1\" valid_account=\"20\" device=\"33\"/><row billno=\"1704121301808328\" productid=\"A05\" username=\"tniat998\" loginname=\"A05tniat998\" agcode=\"017001001001001\" gmcode=\"01\" billtime=\"2017-04-12 13:23:01\" reckontime=\"2017-04-12 13:25:45\" playtype=\"4\" currency=\"CNY\" round=\"817449\" remark=\" \" account=\"10\" cus_account=\"-10\" BASEPOINT=\"301.57\" flag=\"1\" valid_account=\"10\" device=\"33\"/><row billno=\"1704121301808308\" productid=\"A01\" username=\"gzhang05\" loginname=\"A01gzhang05\" agcode=\"003001001001001\" gmcode=\"01\" billtime=\"2017-04-12 13:22:00\" reckontime=\"2017-04-12 13:25:45\" playtype=\"3\" currency=\"CNY\" round=\"817449\" remark=\" \" account=\"20\" cus_account=\"-20\" BASEPOINT=\"114.76\" flag=\"1\" valid_account=\"20\" device=\"33\"/><row billno=\"1704121301808327\" productid=\"E04\" username=\"dfxl12345\" loginname=\"E04dfxl12345\" agcode=\"009001001001001\" gmcode=\"01\" billtime=\"2017-04-12 13:22:47\" reckontime=\"2017-04-12 13:25:45\" playtype=\"3\" currency=\"CNY\" round=\"817449\" remark=\" \" account=\"20\" cus_account=\"-20\" BASEPOINT=\"125.16\" flag=\"1\" valid_account=\"20\" device=\"33\"/><row billno=\"1704121301808326\" productid=\"A01\" username=\"gf5686\" loginname=\"A01gf5686\" agcode=\"003001001001001\" gmcode=\"01\" billtime=\"2017-04-12 13:22:42\" reckontime=\"2017-04-12 13:25:45\" playtype=\"3\" currency=\"CNY\" round=\"817449\" remark=\" \" account=\"110\" cus_account=\"-110\" BASEPOINT=\"8598.48\" flag=\"1\" valid_account=\"110\" device=\"33\"/><row billno=\"1704121301808336\" productid=\"A03\" username=\"f6613526\" loginname=\"A03f6613526\" agcode=\"005001001001001\" gmcode=\"01\" billtime=\"2017-04-12 13:24:01\" reckontime=\"2017-04-12 13:25:45\" playtype=\"17\" currency=\"CNY\" round=\"817449\" remark=\" \" account=\"600\" cus_account=\"-600\" BASEPOINT=\"9000.62\" flag=\"1\" valid_account=\"600\" device=\"19\"/><row billno=\"1704121301808338\" productid=\"E03\" username=\"vsunzhang\" loginname=\"E03vsunzhang\" agcode=\"007001001001001\" gmcode=\"01\" billtime=\"2017-04-12 13:24:10\" reckontime=\"2017-04-12 13:25:45\" playtype=\"20\" currency=\"CNY\" round=\"817449\" remark=\" \" account=\"150\" cus_account=\"-150\" BASEPOINT=\"11300.82\" flag=\"1\" valid_account=\"150\" device=\"33\"/><row billno=\"1704121301808339\" productid=\"E03\" username=\"vsunzhang\" loginname=\"E03vsunzhang\" agcode=\"007001001001001\" gmcode=\"01\" billtime=\"2017-04-12 13:24:14\" reckontime=\"2017-04-12 13:25:45\" playtype=\"20\" currency=\"CNY\" round=\"817449\" remark=\" \" account=\"25\" cus_account=\"-25\" BASEPOINT=\"11150.82\" flag=\"1\" valid_account=\"25\" device=\"33\"/><row billno=\"1704121301808316\" productid=\"A01\" username=\"ghuxuhao\" loginname=\"A01ghuxuhao\" agcode=\"003001001001001\" gmcode=\"01\" billtime=\"2017-04-12 13:22:18\" reckontime=\"2017-04-12 13:25:45\" playtype=\"3\" currency=\"CNY\" round=\"817449\" remark=\" \" account=\"70\" cus_account=\"-70\" BASEPOINT=\"1970.3600000000001\" flag=\"1\" valid_account=\"70\" device=\"19\"/><row billno=\"1704121301808329\" productid=\"E04\" username=\"dfxl12345\" loginname=\"E04dfxl12345\" agcode=\"009001001001001\" gmcode=\"01\" billtime=\"2017-04-12 13:23:06\" reckontime=\"2017-04-12 13:25:45\" playtype=\"5\" currency=\"CNY\" round=\"817449\" remark=\" \" account=\"15\" cus_account=\"14.4\" BASEPOINT=\"105.16\" flag=\"1\" valid_account=\"15\" device=\"33\"/><row billno=\"1704121301808342\" productid=\"A01\" username=\"gffate\" loginname=\"A01gffate\" agcode=\"003001001001001\" gmcode=\"01\" billtime=\"2017-04-12 13:24:19\" reckontime=\"2017-04-12 13:25:45\" playtype=\"3\" currency=\"CNY\" round=\"817449\" remark=\" \" account=\"1000\" cus_account=\"-1000\" BASEPOINT=\"6800.32\" flag=\"1\" valid_account=\"1000\" device=\"19\"/><row billno=\"1704121301808291\" productid=\"A01\" username=\"gflaura\" loginname=\"A01gflaura\" agcode=\"003001001001001\" gmcode=\"01\" billtime=\"2017-04-12 13:21:11\" reckontime=\"2017-04-12 13:25:45\" playtype=\"4\" currency=\"CNY\" round=\"817449\" remark=\" \" account=\"600\" cus_account=\"-600\" BASEPOINT=\"2011.24\" flag=\"1\" valid_account=\"600\" device=\"19\"/><row billno=\"1704121301808302\" productid=\"A03\" username=\"f1988216\" loginname=\"A03f1988216\" agcode=\"005001001001001\" gmcode=\"01\" billtime=\"2017-04-12 13:21:33\" reckontime=\"2017-04-12 13:25:45\" playtype=\"3\" currency=\"CNY\" round=\"817449\" remark=\" \" account=\"2735\" cus_account=\"-2735\" BASEPOINT=\"6737.24\" flag=\"1\" valid_account=\"2735\" device=\"19\"/><row billno=\"1704121301808341\" productid=\"E03\" username=\"vsunzhang\" loginname=\"E03vsunzhang\" agcode=\"007001001001001\" gmcode=\"01\" billtime=\"2017-04-12 13:24:18\" reckontime=\"2017-04-12 13:25:45\" playtype=\"18\" currency=\"CNY\" round=\"817449\" remark=\" \" account=\"15\" cus_account=\"-15\" BASEPOINT=\"11125.82\" flag=\"1\" valid_account=\"15\" device=\"33\"/><row billno=\"1704121301808298\" productid=\"A01\" username=\"gwxiaojiu\" loginname=\"A01gwxiaojiu\" agcode=\"003001001001001\" gmcode=\"01\" billtime=\"2017-04-12 13:21:28\" reckontime=\"2017-04-12 13:25:45\" playtype=\"3\" currency=\"CNY\" round=\"817449\" remark=\" \" account=\"10\" cus_account=\"-10\" BASEPOINT=\"389.6\" flag=\"1\" valid_account=\"10\" device=\"19\"/><row billno=\"1704121301808337\" productid=\"A03\" username=\"f6613526\" loginname=\"A03f6613526\" agcode=\"005001001001001\" gmcode=\"01\" billtime=\"2017-04-12 13:24:05\" reckontime=\"2017-04-12 13:25:45\" playtype=\"23\" currency=\"CNY\" round=\"817449\" remark=\" \" account=\"600\" cus_account=\"-600\" BASEPOINT=\"8400.62\" flag=\"1\" valid_account=\"600\" device=\"19\"/><row billno=\"1704121301808317\" productid=\"A01\" username=\"gydrh\" loginname=\"A01gydrh\" agcode=\"003001001001001\" gmcode=\"01\" billtime=\"2017-04-12 13:22:21\" reckontime=\"2017-04-12 13:25:45\" playtype=\"3\" currency=\"CNY\" round=\"817449\" remark=\" \" account=\"500\" cus_account=\"-500\" BASEPOINT=\"11080.2\" flag=\"1\" valid_account=\"500\" device=\"1\"/><row billno=\"1704121301808321\" productid=\"A05\" username=\"tniat998\" loginname=\"A05tniat998\" agcode=\"017001001001001\" gmcode=\"01\" billtime=\"2017-04-12 13:22:30\" reckontime=\"2017-04-12 13:25:45\" playtype=\"3\" currency=\"CNY\" round=\"817449\" remark=\" \" account=\"10\" cus_account=\"-10\" BASEPOINT=\"311.57\" flag=\"1\" valid_account=\"10\" device=\"33\"/><row billno=\"1704121301808330\" productid=\"E03\" username=\"vsunzhang\" loginname=\"E03vsunzhang\" agcode=\"007001001001001\" gmcode=\"01\" billtime=\"2017-04-12 13:23:26\" reckontime=\"2017-04-12 13:25:45\" playtype=\"19\" currency=\"CNY\" round=\"817449\" remark=\" \" account=\"250\" cus_account=\"350\" BASEPOINT=\"11720.82\" flag=\"1\" valid_account=\"250\" device=\"33\"/><row billno=\"1704121301808332\" productid=\"E03\" username=\"vsunzhang\" loginname=\"E03vsunzhang\" agcode=\"007001001001001\" gmcode=\"01\" billtime=\"2017-04-12 13:23:35\" reckontime=\"2017-04-12 13:25:45\" playtype=\"18\" currency=\"CNY\" round=\"817449\" remark=\" \" account=\"170\" cus_account=\"-170\" BASEPOINT=\"11470.82\" flag=\"1\" valid_account=\"170\" device=\"33\"/><row billno=\"1704121322808331\" productid=\"A01\" username=\"gf11912\" loginname=\"A01gf11912\" agcode=\"003001001001001\" gmcode=\"22\" billtime=\"2017-04-12 13:23:30\" reckontime=\"2017-04-12 13:27:11\" playtype=\"3\" currency=\"CNY\" round=\"2586620\" remark=\" \" account=\"15\" cus_account=\"-15\" BASEPOINT=\"83\" flag=\"1\" valid_account=\"15\" device=\"33\"/><row billno=\"1704121322808344\" productid=\"A05\" username=\"tniat998\" loginname=\"A05tniat998\" agcode=\"017001001001001\" gmcode=\"22\" billtime=\"2017-04-12 13:24:57\" reckontime=\"2017-04-12 13:27:11\" playtype=\"5\" currency=\"CNY\" round=\"2586620\" remark=\" \" account=\"10\" cus_account=\"9.6\" BASEPOINT=\"311.17\" flag=\"1\" valid_account=\"10\" device=\"33\"/><row billno=\"1704121322808354\" productid=\"A03\" username=\"fwin1986\" loginname=\"A03fwin1986\" agcode=\"005001001001001\" gmcode=\"22\" billtime=\"2017-04-12 13:25:38\" reckontime=\"2017-04-12 13:27:11\" playtype=\"1\" currency=\"CNY\" round=\"2586620\" remark=\" \" account=\"500\" cus_account=\"480\" BASEPOINT=\"500.36\" flag=\"1\" valid_account=\"500\" device=\"33\"/><row billno=\"1704121322808355\" productid=\"A01\" username=\"gflaura\" loginname=\"A01gflaura\" agcode=\"003001001001001\" gmcode=\"22\" billtime=\"2017-04-12 13:25:39\" reckontime=\"2017-04-12 13:27:11\" playtype=\"1\" currency=\"CNY\" round=\"2586620\" remark=\" \" account=\"600\" cus_account=\"576\" BASEPOINT=\"1176.24\" flag=\"1\" valid_account=\"600\" device=\"19\"/><row billno=\"1704121322808348\" productid=\"A05\" username=\"tniat998\" loginname=\"A05tniat998\" agcode=\"017001001001001\" gmcode=\"22\" billtime=\"2017-04-12 13:25:12\" reckontime=\"2017-04-12 13:27:11\" playtype=\"1\" currency=\"CNY\" round=\"2586620\" remark=\" \" account=\"10\" cus_account=\"9.6\" BASEPOINT=\"301.17\" flag=\"1\" valid_account=\"10\" device=\"33\"/><row billno=\"1704121322808335\" productid=\"A02\" username=\"cttxs111\" loginname=\"A02cttxs111\" agcode=\"011001001001001\" gmcode=\"22\" billtime=\"2017-04-12 13:23:59\" reckontime=\"2017-04-12 13:27:11\" playtype=\"3\" currency=\"CNY\" round=\"2586620\" remark=\" \" account=\"14\" cus_account=\"-14\" BASEPOINT=\"5144.16\" flag=\"1\" valid_account=\"14\" device=\"1\"/><row billno=\"1704121322808349\" productid=\"A03\" username=\"fwin1986\" loginname=\"A03fwin1986\" agcode=\"005001001001001\" gmcode=\"22\" billtime=\"2017-04-12 13:25:28\" reckontime=\"2017-04-12 13:27:11\" playtype=\"19\" currency=\"CNY\" round=\"2586620\" remark=\" \" account=\"400\" cus_account=\"560\" BASEPOINT=\"1000.36\" flag=\"1\" valid_account=\"400\" device=\"33\"/><row billno=\"1704121322808352\" productid=\"A03\" username=\"fwin1986\" loginname=\"A03fwin1986\" agcode=\"005001001001001\" gmcode=\"22\" billtime=\"2017-04-12 13:25:32\" reckontime=\"2017-04-12 13:27:11\" playtype=\"18\" currency=\"CNY\" round=\"2586620\" remark=\" \" account=\"100\" cus_account=\"-100\" BASEPOINT=\"600.36\" flag=\"1\" valid_account=\"100\" device=\"33\"/><row billno=\"1704121304808360\" productid=\"A01\" username=\"gflaura\" loginname=\"A01gflaura\" agcode=\"003001001001001\" gmcode=\"04\" billtime=\"2017-04-12 13:26:06\" reckontime=\"2017-04-12 13:27:47\" playtype=\"3\" currency=\"CNY\" round=\"2127473\" remark=\" \" account=\"600\" cus_account=\"-600\" BASEPOINT=\"968.24\" flag=\"1\" valid_account=\"600\" device=\"19\"/><row billno=\"1704121304808364\" productid=\"E04\" username=\"dhaomeile\" loginname=\"E04dhaomeile\" agcode=\"009001001001001\" gmcode=\"04\" billtime=\"2017-04-12 13:26:16\" reckontime=\"2017-04-12 13:27:47\" playtype=\"5\" currency=\"CNY\" round=\"2127473\" remark=\" \" account=\"10\" cus_account=\"-10\" BASEPOINT=\"208.84\" flag=\"1\" valid_account=\"10\" device=\"1\"/><row billno=\"1704121304808359\" productid=\"A01\" username=\"gffate\" loginname=\"A01gffate\" agcode=\"003001001001001\" gmcode=\"04\" billtime=\"2017-04-12 13:26:02\" reckontime=\"2017-04-12 13:27:47\" playtype=\"1\" currency=\"CNY\" round=\"2127473\" remark=\" \" account=\"2000\" cus_account=\"1920\" BASEPOINT=\"5800.32\" flag=\"1\" valid_account=\"2000\" device=\"19\"/><row billno=\"1704121304808345\" productid=\"A01\" username=\"gf5686\" loginname=\"A01gf5686\" agcode=\"003001001001001\" gmcode=\"04\" billtime=\"2017-04-12 13:25:05\" reckontime=\"2017-04-12 13:27:47\" playtype=\"1\" currency=\"CNY\" round=\"2127473\" remark=\" \" account=\"110\" cus_account=\"105.60000000000001\" BASEPOINT=\"8684.48\" flag=\"1\" valid_account=\"110\" device=\"33\"/><row billno=\"1704121304808346\" productid=\"A01\" username=\"gf5686\" loginname=\"A01gf5686\" agcode=\"003001001001001\" gmcode=\"04\" billtime=\"2017-04-12 13:25:09\" reckontime=\"2017-04-12 13:27:47\" playtype=\"5\" currency=\"CNY\" round=\"2127473\" remark=\" \" account=\"100\" cus_account=\"-100\" BASEPOINT=\"8574.48\" flag=\"1\" valid_account=\"100\" device=\"33\"/><row billno=\"1704121304808343\" productid=\"A01\" username=\"gf11912\" loginname=\"A01gf11912\" agcode=\"003001001001001\" gmcode=\"04\" billtime=\"2017-04-12 13:24:39\" reckontime=\"2017-04-12 13:27:47\" playtype=\"3\" currency=\"CNY\" round=\"2127473\" remark=\" \" account=\"25\" cus_account=\"-25\" BASEPOINT=\"68\" flag=\"1\" valid_account=\"25\" device=\"33\"/><row billno=\"1704121304808353\" productid=\"C01\" username=\"rtifen88\" loginname=\"C01rtifen88\" agcode=\"021001001001001\" gmcode=\"04\" billtime=\"2017-04-12 13:25:38\" reckontime=\"2017-04-12 13:27:47\" playtype=\"20\" currency=\"CNY\" round=\"2127473\" remark=\" \" account=\"50\" cus_account=\"-50\" BASEPOINT=\"50\" flag=\"1\" valid_account=\"50\" device=\"19\"/><row billno=\"1704121304808347\" productid=\"A01\" username=\"ghuxuhao\" loginname=\"A01ghuxuhao\" agcode=\"003001001001001\" gmcode=\"04\" billtime=\"2017-04-12 13:25:09\" reckontime=\"2017-04-12 13:27:47\" playtype=\"1\" currency=\"CNY\" round=\"2127473\" remark=\" \" account=\"600\" cus_account=\"576\" BASEPOINT=\"2019.92\" flag=\"1\" valid_account=\"600\" device=\"19\"/><row billno=\"1704121304808351\" productid=\"C01\" username=\"rtifen88\" loginname=\"C01rtifen88\" agcode=\"021001001001001\" gmcode=\"04\" billtime=\"2017-04-12 13:25:30\" reckontime=\"2017-04-12 13:27:47\" playtype=\"24\" currency=\"CNY\" round=\"2127473\" remark=\" \" account=\"50\" cus_account=\"-50\" BASEPOINT=\"100\" flag=\"1\" valid_account=\"50\" device=\"19\"/></result>";
//        String xml = "<Data><Record><Code>44000</Code><Message>Keyerror</Message></Record></Data>";
//        SAXParseXmlByNode sax = SAXParseXmlByNode.parse(xml, "006", OrderEntity.class);
//        String confDir = File.separator + System.getProperty("user.dir") + File.separator + "conf";
//        FileSystemXmlApplicationContext factory = new FileSystemXmlApplicationContext(confDir + "/spring/applicationContext.xml");
//        OrderDao orderDao = (OrderDao) factory.getBean("orderDao");
//        SqlSessionFactory myBatisSessionFactory = (SqlSessionFactory) factory.getBean("myBatisSessionFactory");
//        SqlSession session = myBatisSessionFactory.openSession();
//        orderDao.insertOrder4BBIN(sax.getObjectList(), session, false);

        String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\" ?><Data Page=\"1\" PageLimit=\"1200\" TotalNumber=\"1\" TotalPage=\"1\" ><Record><UserName>tjohnsogood</UserName><CreateTime>2020-02-19 08:30:42.0</CreateTime><TransType>Deposit</TransType><Amount>50</Amount><Balance>2058</Balance><Currency>CNY</Currency><TransID>200219042922248</TransID><ProductID>A04</ProductID></Record></Data>";
        SAXParseXmlByNode saxParseXml = SAXParseXmlByNode.parse(xml, "092", AccountTransferEntity.class);
        System.out.println(saxParseXml.getObjectList());
    }

}
