/**
 *
 */
package main.java.com.gw.common.framework.util;

/**
 * @author alex.l
 */

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWSAXParseException;
import main.java.com.gw.datacenter.accounttransfer.entity.AccountTransferEntity;
import main.java.com.gw.datacenter.gameresult.entity.BaGameEntity;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.IOException;
import java.io.StringReader;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

@Slf4j
@SuppressWarnings("unchecked")
public class SAXParseXmlByNode4Hogame extends DefaultHandler {

    //store total records.
    private int index = 0;

    //store the error or warning infos.
    private Locator locator;

    //store all the tag with Stack.
    Stack<String> tags = new Stack<String>();

    private Class<Object> claz = null;

    private String productId;

    private String platformId = null;

    private List objectList = new ArrayList();

    //total records.
    private int apiTotal = 0;
    //page size
    private int apiPageSize = 0;

    //status code.
    private String statusCode = null;
    //status description.
    private String statusDesc = null;

    private AccountTransferEntity accountTransferEntity = null;

    private OrderEntity orderEntity = null;

    private BaGameEntity baGameEntity = null;

    private String preTag = null;

    private boolean valid = true;

    // Constructor
    public SAXParseXmlByNode4Hogame() {
        super();
    }

    public SAXParseXmlByNode4Hogame(String productId, String platformId, Class claz) {
        this.productId = productId;
        this.claz = claz;
        this.platformId = platformId;
    }

    // Response the startDocument event
    public void startDocument() {
        log.info("Call startDocument(),开始解析xml...");
    }

    /**
     * Response the startElement event
     *
     * @param uri
     * @param localName
     * @param qName
     * @param attrs
     */
    public void startElement(String uri, String localName, String qName, Attributes attrs) {
        tags.push(qName);
        try {
            if (this.claz.newInstance() instanceof OrderEntity) {
                if ("Betinfo".equalsIgnoreCase(qName)) {
                    index++;
                    orderEntity = new OrderEntity();
                }
            } else if (this.claz.newInstance() instanceof AccountTransferEntity) {
                if ("GetAllAccountTransferDetails".equalsIgnoreCase(qName)) {
                    index++;
                    accountTransferEntity = new AccountTransferEntity();
                }
            } else if (this.claz.newInstance() instanceof BaGameEntity) {
                if ("Baccarat".equalsIgnoreCase(qName)
                        || "DragonTiger".equalsIgnoreCase(qName)
                        || "Roulette".equalsIgnoreCase(qName)
                        || "BlackJack".equalsIgnoreCase(qName)
                        || "Sicbo".equalsIgnoreCase(qName)) {
                    index++;
                    baGameEntity = new BaGameEntity();
                    baGameEntity.setGameType(qName);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        preTag = qName;
    }


    /**
     * 返回节点开始和结束之间的字符.如<element>12345</element>,返回12345
     * @param ch
     * @param start
     * @param length
     * @throws SAXException
     */
    public void characters(char ch[], int start, int length) throws SAXException {
        String tag = tags.peek();

        if (tag.equalsIgnoreCase("ErrorInfo")) {
            this.valid = false;
        }
        if (tag.equalsIgnoreCase("STATUS_CODE")) {
            this.statusCode = new String(ch, start, length).trim();
        }
        if (tag.equalsIgnoreCase("STATUS_DESC")) {
            this.statusDesc = new String(ch, start, length).trim();
        }
        if (tag.equalsIgnoreCase("TotalRecords") && apiTotal == 0) {
            this.apiTotal = Integer.valueOf(new String(ch, start, length));
        }
        if (preTag != null && orderEntity != null) {
            String cotent = new String(ch, start, length);
            if (!UtilConstants.BLANK.equals(cotent.trim())) {
                orderEntity.setProductId(productId);
                ObjectConstructUtil.constructOrdersForHoGame(orderEntity, preTag, cotent, platformId);
            }
        } else if (preTag != null && baGameEntity != null) {
            String cotent = new String(ch, start, length);
            if (!UtilConstants.BLANK.equals(cotent.trim())) {
                baGameEntity.setProductId(productId);
                ObjectConstructUtil.constructGameResultForHoGame(baGameEntity, preTag, cotent, platformId);
            }
        } else if (preTag != null && accountTransferEntity != null) {
            String cotent = new String(ch, start, length);
            if (!UtilConstants.BLANK.equals(cotent.trim())) {
                accountTransferEntity.setProductId(productId);
                ObjectConstructUtil.constructAccountTransferForHoGame(accountTransferEntity, preTag, cotent, platformId);
            }
        }
        //log.debug("----------Call characters()----------");
    }

    /**
     * Response the endElement event
     *
     * @param uri
     * @param localName
     * @param qName
     */
    public void endElement(String uri, String localName, String qName) {
        //log.debug("-------endElement()---------:"+localName);
        if (("Betinfo".equalsIgnoreCase(qName) && orderEntity != null)) {
            if (BigDecimal.ZERO.compareTo(orderEntity.getCusAccount()) == 0) {
                orderEntity.setValidAccount(BigDecimal.ZERO);
            }
            this.objectList.add(orderEntity);
        } else if ("GetAllAccountTransferDetails".equalsIgnoreCase(qName) && accountTransferEntity != null) {
            this.objectList.add(accountTransferEntity);
        } else if (("Baccarat".equalsIgnoreCase(qName)
                || "DragonTiger".equalsIgnoreCase(qName)
                || "Roulette".equalsIgnoreCase(qName)
                || "Sicbo".equalsIgnoreCase(qName)) && baGameEntity != null) {
            if (!ToolUtil.isExistObject(baGameEntity, objectList)) {
                this.objectList.add(baGameEntity);
            }
        } else if ("BlackJack".equalsIgnoreCase(qName)) {
            this.objectList.add(baGameEntity);
        } else if ("ErrorInfo".equalsIgnoreCase(qName)) {
            this.valid = false;
        }
        preTag = null;
    }

    // Response the endDocument event
    public void endDocument() {
        log.info("Call endDocument(),解析xml结束！共解析" + index + "条数据！");
    }

    // Print the fata error information
    public void fatalError(SAXParseException e) {
        log.error("XML解析发生严重错误：" + e.getMessage());
        log.error("At line " + locator.getLineNumber() + ",column " + locator.getColumnNumber());
        //e.printStackTrace();
    }

    // Print the usual error information
    public void error(SAXParseException e) {
        log.error("XML解析报错信息：" + e.getMessage());
        log.error("At line " + locator.getLineNumber() + ",column " + locator.getColumnNumber());
        //e.printStackTrace();
    }

    // Print the warning information
    public void warning(SAXParseException e) {
        log.info("XML解析警告信息：" + e.getMessage());
        log.info("At line " + locator.getLineNumber() + ",column " + locator.getColumnNumber());
        //e.printStackTrace();
    }

    // Store the error locator object
    public void setDocumentLocator(Locator lct) {
        locator = lct;
    }

    /**
     * Begin to parse XML.
     *
     * @param xmlStr
     * @param claz
     * @return saxParseXml
     * @throws GWSAXParseException
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     */
    public static SAXParseXmlByNode4Hogame parse(String xmlStr, String productId, String platformId, Class claz) throws GWSAXParseException {
        SAXParseXmlByNode4Hogame saxParseXml = new SAXParseXmlByNode4Hogame(productId, platformId, claz);
        InputSource inputsource = new InputSource(new StringReader(xmlStr));
        SAXParserFactory saxfactory = SAXParserFactory.newInstance();
        SAXParser saxparser = null;
        try {
            saxparser = saxfactory.newSAXParser();
            saxparser.parse(inputsource, saxParseXml);
        } catch (Exception e) {
            log.error("Fail to call SAXParseXmlByNode4Hogame.parse(),Exception:" + e.getMessage(), e);
            throw new GWSAXParseException(e.getMessage());
        }
        return saxParseXml;
    }

    /**
     * @return the objectList
     */
    public List getObjectList() {
        return objectList;
    }

    /**
     * @return the apiTotal
     */
    public int getApiTotal() {
        return apiTotal;
    }

    /**
     * @return the index
     */
    public int getIndex() {
        return index;
    }

    /**
     * @return the apiPageSize
     */
    public int getApiPageSize() {
        return apiPageSize;
    }

    /**
     * @return the statusCode
     */
    public String getStatusCode() {
        return statusCode;
    }

    /**
     * @return the statusDesc
     */
    public String getStatusDesc() {
        return statusDesc;
    }

    public boolean isValid() {
        return valid;
    }

    public void setValid(boolean valid) {
        this.valid = valid;
    }

}