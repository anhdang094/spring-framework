/**
 *
 */
package main.java.com.gw.common.framework.util;

/**
 * @author alex.l
 */

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWSAXParseException;
import main.java.com.gw.datacenter.gameresult.entity.BaGameEntity;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.lang3.StringUtils;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Stack;

@Slf4j
@SuppressWarnings("unchecked")
public class SAXParseXmlByNodeAndAttribute extends DefaultHandler {


    //store total records.
    private int index = 0;

    //store the error or warning infos.
    private Locator locator;

    //store all the tag with Stack.
    Stack<String> tags = new Stack<String>();

    private Class<Object> claz = null;

    private String platformId = null;

    private String fileName = null;

    private List objectList = new ArrayList();

    //total records.
    private int apiTotal = 0;
    //page size
    private int apiPageSize = 0;

    //error info.
    private String info = null;

    private OrderEntity orderEntity = null;

    private BaGameEntity gameRsultEntity = null;

    private String preTag = null;

    String gameType = null;

    StringBuffer cardListBuffer = null;

    int bankerPoint = 0;

    int playerPoint = 0;

    String bankerPlayerSide = null;

    Integer cardType = null;

    Integer cardValue = null;

    int cardNumer = 0;

    String result = null;

    String gameCode = null;
    String id = null;

    Date billTime = null;

    Date orignalBillTime = null;

    public static final Map<String, String> tagMap = new HashMap<String, String>();

    static {
        tagMap.put("bank", "");
        tagMap.put("player", "");
        tagMap.put("tie", "");
        tagMap.put("bankdp", "");
        tagMap.put("playerdp", "");
        tagMap.put("bankodd", "");
        tagMap.put("bankeven", "");
        tagMap.put("playerodd", "");
        tagMap.put("playereven", "");
        tagMap.put("big", "");
        tagMap.put("small", "");
    }

    // Constructor
    public SAXParseXmlByNodeAndAttribute() {
        super();
    }

    public SAXParseXmlByNodeAndAttribute(String platformId, Class claz, String fileName) {
        this.claz = claz;
        this.platformId = platformId;
        this.fileName = fileName;
    }

    // Response the startDocument event
    public void startDocument() {
        log.info("Call startDocument(),开始解析xml...");
    }

    /**
     * Response the startElement event
     *
     * @param uri
     * @param localName
     * @param qName
     * @param attrs
     */
    public void startElement(String uri, String localName, String qName, Attributes attrs) {
        tags.push(qName);
        try {
            if ("game".equalsIgnoreCase(qName)) {
                gameType = attrs.getValue("code");
            }
            if (this.claz.newInstance() instanceof OrderEntity) {
                if ("deal".equalsIgnoreCase(qName)) {
                    //modified by alex on 2012-01-23 -begin
                    /*index++;
					orderEntity = new OrderEntity();
					orderEntity.setGameType(gameType);*/
                    //modified by alex on 2012-01-23 -end
                    int attrCount = attrs.getLength();
                    if (attrCount > 0) {
                        //get game code by game node.
                        gameCode = attrs.getValue("code");
                        id = attrs.getValue("id");
                        billTime = DateUtil.formatStr2Date(attrs.getValue("startdate"));
                        orignalBillTime = DateUtil.formatStr2Date(attrs.getValue("startdate"));
                    }
                }
                if ("clientbet".equals(qName)) {
                    //add by alex on 2012-01-23 -begin
                    index++;
                    orderEntity = new OrderEntity();
                    orderEntity.setGameType(gameType);
                    int attrCount = attrs.getLength();
                    if (attrCount > 0) {
                        //get game code by game node.
                        orderEntity.setBillNo(id);
                        orderEntity.setGmCode(gameCode);
                        orderEntity.setBillTime(billTime);
                        orderEntity.setOrignalBillTime(orignalBillTime);
                        orderEntity.setReckonTime(billTime);
                    }
                    //add by alex on 2012-01-23 -end
                    ObjectConstructUtil.readAttributesForEAOrder(attrs, orderEntity, platformId);
                }
            } else if (this.claz.newInstance() instanceof BaGameEntity) {
                if ("deal".equalsIgnoreCase(qName)) {
                    index++;
                    gameRsultEntity = new BaGameEntity();
                    gameRsultEntity.setLoginName(UtilConstants.ZERO_STR);
                    gameRsultEntity.setPlatId(platformId);
                    gameRsultEntity.setProductId(UtilConstants.PRODUCTID_MT);
                    gameRsultEntity.setGameType(gameType);
                    int attrCount = attrs.getLength();
                    if (attrCount > 0) {
                        //get game code by game node.
                        gameRsultEntity.setGmCode(attrs.getValue("code"));
                        gameRsultEntity.setBeginTime(DateUtil.formatStr2Date(attrs.getValue("startdate")));
                        gameRsultEntity.setOrignalBeginTime(DateUtil.formatStr2Date(attrs.getValue("startdate")));
                        gameRsultEntity.setCloseTime(DateUtil.formatStr2Date(attrs.getValue("enddate")));
                        gameRsultEntity.setOrignalCloseTime(DateUtil.formatStr2Date(attrs.getValue("enddate")));
                        if (!StringUtils.isBlank(attrs.getValue("status"))) {
                            gameRsultEntity.setFlag(Integer.valueOf(attrs.getValue("status")));
                        }
                    }
                }
                if ("dealdetails".equalsIgnoreCase(qName)) {
                    cardListBuffer = new StringBuffer();
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        preTag = qName;
    }

    /**
     * 返回节点开始和结束之间的字符.如<element>12345</element>,返回12345
     *
     * @param ch
     * @param start
     * @param length
     */
    public void characters(char ch[], int start, int length) throws SAXException {
        String tag = tags.peek();
        //String cotent = new String(ch, start, length);
        if (preTag != null && orderEntity != null) {
            String content = new String(ch, start, length);
            //for Baccarat
            if (tagMap.containsKey(tag) && !StringUtils.isBlank(content) && !UtilConstants.ZERO_STR.equals(content)) {
                ObjectConstructUtil.readNodesForEAOrder(orderEntity, preTag, content);
            }
            //for Blackjack
            if ("bet_type".equals(tag)) {
                if (UtilConstants.ONE_STR.equals(content)) {
                    if (orderEntity.getRemark() != null) {
                        orderEntity.setRemark(orderEntity.getRemark() + UtilConstants.SEMICOLON + "在座玩家");
                    } else {
                        orderEntity.setRemark("在座玩家");
                    }
                } else {
                    if (orderEntity.getRemark() != null) {
                        orderEntity.setRemark(orderEntity.getRemark() + UtilConstants.SEMICOLON + "搭注玩家");
                    } else {
                        orderEntity.setRemark("搭注玩家");
                    }
                }
            } else if ("init_bet".equals(tag) && !UtilConstants.ZERO_STR.equals(content)) {
                orderEntity.setRemark(orderEntity.getRemark() + UtilConstants.VERTICAL + "初始投注" + ToolUtil.transferDecimalToStr(content));
            } else if ("double_bet".equals(tag) && !UtilConstants.ZERO_STR.equals(content)) {
                orderEntity.setRemark(orderEntity.getRemark() + UtilConstants.VERTICAL + "加注投注" + ToolUtil.transferDecimalToStr(content));
            } else if ("pair_bet".equals(tag) && !UtilConstants.ZERO_STR.equals(content)) {
                orderEntity.setRemark(orderEntity.getRemark() + UtilConstants.VERTICAL + "对子投注" + ToolUtil.transferDecimalToStr(content));
            } else if ("insure_bet".equals(tag) && !UtilConstants.ZERO_STR.equals(content)) {
                orderEntity.setRemark(orderEntity.getRemark() + UtilConstants.VERTICAL + "保险投注" + ToolUtil.transferDecimalToStr(content));
            }
        } else if (preTag != null && gameRsultEntity != null) {
            String cotent = new String(ch, start, length);
            //construct card list.
            if ("side".equalsIgnoreCase(tag) && cardListBuffer != null) {
                this.bankerPlayerSide = cotent;
            } else if ("type".equalsIgnoreCase(tag) && bankerPlayerSide != null) {
                this.cardType = Integer.valueOf(cotent);
            } else if ("value".equalsIgnoreCase(tag) && bankerPlayerSide != null) {
                this.cardValue = Integer.valueOf(cotent);
            } else if ("result".equalsIgnoreCase(tag) && bankerPlayerSide != null) {
                this.result = cotent;
            }
        }
        //log.debug("----------Call characters()----------");
    }

    /**
     * Response the endElement event
     *
     * @param uri
     * @param localName
     * @param qName
     */
    public void endElement(String uri, String localName, String qName) {
        //log.debug("-------endElement()---------:"+localName);
        if ("clientbet".equalsIgnoreCase(qName) && orderEntity != null) {
            this.objectList.add(orderEntity);
            this.orderEntity = null;
        } else if ("dealdetail".equalsIgnoreCase(qName) && gameRsultEntity != null) {
            if (gameType.equals("90001")) {
                if ("Bank1".equalsIgnoreCase(bankerPlayerSide)) {
                    cardNumer++;
                    if (cardValue < 10) {
                        this.bankerPoint += cardValue;
                    }
                    if (cardType == 1) {
                        cardListBuffer.append(cardValue + 32);
                    } else if (cardType == 2) {
                        cardListBuffer.append(cardValue + 48);
                    } else if (cardType == 3) {
                        cardListBuffer.append(cardValue);
                    } else if (cardType == 4) {
                        cardListBuffer.append(cardValue + 16);
                    }
                } else if ("Bank2".equalsIgnoreCase(bankerPlayerSide)) {
                    cardNumer++;
                    cardListBuffer.append(UtilConstants.BLANK_SPACE);
                    if (cardValue < 10) {
                        this.bankerPoint += cardValue;
                    }
                    if (cardType == 1) {
                        cardListBuffer.append(cardValue + 32);
                    } else if (cardType == 2) {
                        cardListBuffer.append(cardValue + 48);
                    } else if (cardType == 3) {
                        cardListBuffer.append(cardValue);
                    } else if (cardType == 4) {
                        cardListBuffer.append(cardValue + 16);
                    }
                } else if ("Bank3".equalsIgnoreCase(bankerPlayerSide)) {
                    cardNumer++;
                    cardListBuffer.append(UtilConstants.BLANK_SPACE);
                    if (cardValue < 10) {
                        this.bankerPoint += cardValue;
                    }
                    if (cardType == 1) {
                        cardListBuffer.append(cardValue + 32);
                    } else if (cardType == 2) {
                        cardListBuffer.append(cardValue + 48);
                    } else if (cardType == 3) {
                        cardListBuffer.append(cardValue);
                    } else if (cardType == 4) {
                        cardListBuffer.append(cardValue + 16);
                    }
                } else if ("Player1".equalsIgnoreCase(bankerPlayerSide)) {
                    cardNumer++;
                    cardListBuffer.append(UtilConstants.SEMICOLON);
                    if (cardValue < 10) {
                        this.playerPoint += cardValue;
                    }
                    if (cardType == 1) {
                        cardListBuffer.append(cardValue + 32);
                    } else if (cardType == 2) {
                        cardListBuffer.append(cardValue + 48);
                    } else if (cardType == 3) {
                        cardListBuffer.append(cardValue);
                    } else if (cardType == 4) {
                        cardListBuffer.append(cardValue + 16);
                    }
                } else if ("Player2".equalsIgnoreCase(bankerPlayerSide)) {
                    cardNumer++;
                    cardListBuffer.append(UtilConstants.BLANK_SPACE);
                    if (cardValue < 10) {
                        this.playerPoint += cardValue;
                    }
                    if (cardType == 1) {
                        cardListBuffer.append(cardValue + 32);
                    } else if (cardType == 2) {
                        cardListBuffer.append(cardValue + 48);
                    } else if (cardType == 3) {
                        cardListBuffer.append(cardValue);
                    } else if (cardType == 4) {
                        cardListBuffer.append(cardValue + 16);
                    }
                } else if ("Player3".equalsIgnoreCase(bankerPlayerSide)) {
                    cardNumer++;
                    cardListBuffer.append(UtilConstants.BLANK_SPACE);
                    if (cardValue < 10) {
                        this.playerPoint += cardValue;
                    }
                    if (cardType == 1) {
                        cardListBuffer.append(cardValue + 32);
                    } else if (cardType == 2) {
                        cardListBuffer.append(cardValue + 48);
                    } else if (cardType == 3) {
                        cardListBuffer.append(cardValue);
                    } else if (cardType == 4) {
                        cardListBuffer.append(cardValue + 16);
                    }
                }
            } else if (gameType.equals("10001") || gameType.equals("10002") || gameType.equals("70001") || gameType.equals("80001") || gameType.equals("100001")) {
                if ("Bank1".equalsIgnoreCase(bankerPlayerSide)) {
                    cardNumer++;
                    if (cardType < 10) {
                        this.bankerPoint += cardType;
                    }
                    if (cardValue == 1) {
                        cardListBuffer.append(cardType + 32);
                    } else if (cardValue == 2) {
                        cardListBuffer.append(cardType + 48);
                    } else if (cardValue == 3) {
                        cardListBuffer.append(cardType);
                    } else if (cardValue == 4) {
                        cardListBuffer.append(cardType + 16);
                    }
                } else if ("Bank2".equalsIgnoreCase(bankerPlayerSide)) {
                    cardNumer++;
                    cardListBuffer.append(UtilConstants.BLANK_SPACE);
                    if (cardType < 10) {
                        this.bankerPoint += cardType;
                    }
                    if (cardValue == 1) {
                        cardListBuffer.append(cardType + 32);
                    } else if (cardValue == 2) {
                        cardListBuffer.append(cardType + 48);
                    } else if (cardValue == 3) {
                        cardListBuffer.append(cardType);
                    } else if (cardValue == 4) {
                        cardListBuffer.append(cardType + 16);
                    }
                } else if ("Bank3".equalsIgnoreCase(bankerPlayerSide)) {
                    cardNumer++;
                    cardListBuffer.append(UtilConstants.BLANK_SPACE);
                    if (cardType < 10) {
                        this.bankerPoint += cardType;
                    }
                    if (cardValue == 1) {
                        cardListBuffer.append(cardType + 32);
                    } else if (cardValue == 2) {
                        cardListBuffer.append(cardType + 48);
                    } else if (cardValue == 3) {
                        cardListBuffer.append(cardType);
                    } else if (cardValue == 4) {
                        cardListBuffer.append(cardType + 16);
                    }
                } else if ("Player1".equalsIgnoreCase(bankerPlayerSide)) {
                    cardNumer++;
                    cardListBuffer.append(UtilConstants.SEMICOLON);
                    if (cardType < 10) {
                        this.playerPoint += cardType;
                    }
                    if (cardValue == 1) {
                        cardListBuffer.append(cardType + 32);
                    } else if (cardValue == 2) {
                        cardListBuffer.append(cardType + 48);
                    } else if (cardValue == 3) {
                        cardListBuffer.append(cardType);
                    } else if (cardValue == 4) {
                        cardListBuffer.append(cardType + 16);
                    }
                } else if ("Player2".equalsIgnoreCase(bankerPlayerSide)) {
                    cardNumer++;
                    cardListBuffer.append(UtilConstants.BLANK_SPACE);
                    if (cardType < 10) {
                        this.playerPoint += cardType;
                    }
                    if (cardValue == 1) {
                        cardListBuffer.append(cardType + 32);
                    } else if (cardValue == 2) {
                        cardListBuffer.append(cardType + 48);
                    } else if (cardValue == 3) {
                        cardListBuffer.append(cardType);
                    } else if (cardValue == 4) {
                        cardListBuffer.append(cardType + 16);
                    }
                } else if ("Player3".equalsIgnoreCase(bankerPlayerSide)) {
                    cardNumer++;
                    cardListBuffer.append(UtilConstants.BLANK_SPACE);
                    if (cardType < 10) {
                        this.playerPoint += cardType;
                    }
                    if (cardValue == 1) {
                        cardListBuffer.append(cardType + 32);
                    } else if (cardValue == 2) {
                        cardListBuffer.append(cardType + 48);
                    } else if (cardValue == 3) {
                        cardListBuffer.append(cardType);
                    } else if (cardValue == 4) {
                        cardListBuffer.append(cardType + 16);
                    }
                }
            } else if (gameType.equals("50001") || gameType.equals("50002") || gameType.equals("50003")) {
                cardListBuffer.append(cardValue);
                cardListBuffer.append(UtilConstants.BLANK_SPACE);
                this.gameRsultEntity.setRouletteColor(cardType);//轮盘投注区颜色
            } else if (gameType.equals("60001")) {
                cardListBuffer.append(cardValue);
                cardListBuffer.append(UtilConstants.BLANK_SPACE);
            }
        } else if ("deal".equalsIgnoreCase(qName) && gameRsultEntity != null) {
            this.gameRsultEntity.setCardNum(cardNumer);
            this.gameRsultEntity.setCardList(cardListBuffer.toString());
            this.gameRsultEntity.setBankerPoint(String.valueOf(bankerPoint % 10));//满10就去掉十位数,取个位数字
            this.gameRsultEntity.setPlayerPoint(String.valueOf(playerPoint % 10));
            this.objectList.add(gameRsultEntity);

            //Remove the old object for creating new gameRsultEntity.
            this.cardListBuffer = null;
            this.gameRsultEntity = null;
            this.bankerPoint = 0;
            this.playerPoint = 0;
            this.bankerPlayerSide = null;
            this.cardType = null;
            this.cardValue = null;
            this.result = null;
            this.cardNumer = 0;
        }
        preTag = null;
    }

    // Response the endDocument event
    public void endDocument() {
        log.info("Call endDocument(),解析xml:" + fileName + " 结束！共解析" + index + "条数据！");
    }

    // Print the fata error information
    public void fatalError(SAXParseException e) {
        log.error("XML解析发生严重错误：" + e.getMessage());
        log.error("At line " + locator.getLineNumber() + ",column " + locator.getColumnNumber());
        //e.printStackTrace();
    }

    // Print the usual error information
    public void error(SAXParseException e) {
        log.error("XML解析报错信息：" + e.getMessage());
        log.error("At line " + locator.getLineNumber() + ",column " + locator.getColumnNumber());
        //e.printStackTrace();
    }

    // Print the warning information
    public void warning(SAXParseException e) {
        log.info("XML解析警告信息：" + e.getMessage());
        log.info("At line " + locator.getLineNumber() + ",column " + locator.getColumnNumber());
        //e.printStackTrace();
    }

    // Store the error locator object
    public void setDocumentLocator(Locator lct) {
        locator = lct;
    }

    /**
     * Begin to parse XML.
     *
     * @param xmlStr
     * @param claz
     * @return saxParseXml
     * @throws GWSAXParseException
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     */
    public static SAXParseXmlByNodeAndAttribute parse(String xmlStr, String platformId, Class claz, String fileName) throws GWSAXParseException {
        SAXParseXmlByNodeAndAttribute saxParseXml = new SAXParseXmlByNodeAndAttribute(platformId, claz, fileName);
        InputSource inputsource = new InputSource(new StringReader(xmlStr));
        SAXParserFactory saxfactory = SAXParserFactory.newInstance();
        SAXParser saxparser = null;
        try {
            saxparser = saxfactory.newSAXParser();
            saxparser.parse(inputsource, saxParseXml);
        } catch (Exception e) {
            log.error("Fail to call SAXParseXmlByNode.parse(),Exception:" + e.getMessage(), e);
            throw new GWSAXParseException(e.getMessage());
        }
        return saxParseXml;
    }

    /**
     * @return the objectList
     */
    public List getObjectList() {
        return objectList;
    }

    /**
     * @return the apiTotal
     */
    public int getApiTotal() {
        return apiTotal;
    }

    /**
     * @return the info
     */
    public String getInfo() {
        return info;
    }

    /**
     * @return the index
     */
    public int getIndex() {
        return index;
    }

    /**
     * @return the apiPageSize
     */
    public int getApiPageSize() {
        return apiPageSize;
    }
}