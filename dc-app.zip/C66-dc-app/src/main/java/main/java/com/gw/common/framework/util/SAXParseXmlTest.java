package main.java.com.gw.common.framework.util;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.xml.sax.InputSource;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class SAXParseXmlTest {

    private String filePath = "E:/myproject/GWDataCenter/src/main/java/com/gw/common/framework/util/test.xml";
    private String baseUrl = "http://10.252.252.22:3333/getorders.xml";
    private String gameUrl = "http://10.252.252.22:3333/getroundsres.xml";
    // for bbin
    private String bbinUrl_MT_ORDER = "http://888.mon99.com/app/api/mem_bet_record.php";
    private String bbinUrl_BLM_ORDER = "http://888.hlg6.com/app/WebService/XML/display.php/BetRecord";

    private String bbinUrl_MT_TRANSFER = "http://888.mon99.com/app/api/report_trans.php";
    private String bbinUrl_BLM_TRANSFER = "http://888.bailm88.com/app/api/report_trans.php";

    public SAXParseXmlTest(SAXParseXml SAXParseXml) throws UnsupportedEncodingException, GWCallRemoteApiException {
        Map<String, Object> parameterMap = new HashMap<String, Object>();
        String encoding = "UTF-8";
        // parameterMap.put("billno", "12345");
        // parameterMap.put("loginname", "alex");
        // parameterMap.put("agcode", "1");
        // parameterMap.put("agcode", "1");
        // parameterMap.put("result", "1");
        // parameterMap.put("tablecode", "1");
        // parameterMap.put("playtype", "1");
        // parameterMap.put("by", "1");
        // parameterMap.put("page", "1");
        // parameterMap.put("num","1");
        /*
         * parameterMap.put("begintime","2011-7-7 17:30:00");
         * parameterMap.put("endtime","2011-7-7 17:34:18");
         */
        // parameterMap.put("begintime","2011-7-13 2:40:54");
        // parameterMap.put("endtime","2011-7-13 2:45:54");

        // for test BB_IN order
        parameterMap.put(UtilConstants.GLOBAL_PLATFORMID_KEY, "order_blmbbin");
        parameterMap.put("website", "hlg6");// HJ
        parameterMap.put("target", null); // nullable:会员
        parameterMap.put("rounddate", "2013-06-25");
        parameterMap.put("starttime", "14:10:00");
        parameterMap.put("endtime", "14:14:59");
        parameterMap.put("gamekind", "1"); // nullable starttime
        parameterMap.put("gametype", null); // nullable
        parameterMap.put("model", "1"); // nullable
        parameterMap.put("page", "1"); // nullable
        parameterMap.put("pagelimit", "400"); // nullable
        parameterMap.put("sort", null); // nullable
        //
        // http://888.hlg6.com/app/api/mem_bet_record.php?username=dkbreal&rounddate=2013-07-01&starttime=00:40:00&endtime=00:44:59&gamekind=3&model=1&page=1&pagelimit=400&password=987oiu&website=hlg6&key=phpb685a4ddcb8f50e9e9bdf5610949e2ealexzgw
        // blm
        parameterMap.put("username", "dzhenwh");
        parameterMap.put("password", "3efvbnji9");

        String xmlStr = GetXmlByUrlUtil.getXmlStream(bbinUrl_BLM_ORDER, parameterMap, encoding);
        InputSource inputsource = new InputSource(new StringReader(xmlStr));
        SAXParserFactory saxfac = SAXParserFactory.newInstance();

        // xmlStr = GetXmlByUrlUtil.getXmlStream(baseUrl, parameterMap,UtilConstants.ENCODING_UTF8);
        // saxParseXml = SAXParseXmlByNode.parse(xmlStr, platFormId, OrderEntity.class, gameKind);
        // apiTotal = saxParseXml.getApiTotal();
        // localTotal = localTotal + saxParseXml.getIndex();
        try {
            SAXParser saxparser = saxfac.newSAXParser();
            try {
                saxparser.parse(inputsource, SAXParseXml);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void main(String[] args) throws UnsupportedEncodingException, GWCallRemoteApiException {
        // SAXParseXml SAXParseXml = new SAXParseXml(OrderEntity.class);
        // SAXParseXml SAXParseXml = new SAXParseXml(null,BaGameEntity.class);
        SAXParseXml sAXParseXml = new SAXParseXml(null, OrderEntity.class);
        new SAXParseXmlTest(sAXParseXml);
        System.out.println(sAXParseXml);
        List<Object> list = sAXParseXml.getObjectList();
        System.out.println("SAXParseXml.getInfo() = " + sAXParseXml.getInfo());
        System.out.println("SAXParseXml.getTotal() = " + sAXParseXml.getApiTotal());
        /*
         * if(list!= null && list.size() >0){ for(int i = 0;i<list.size();i++){ OrderEntity
         * orderEntity = (OrderEntity)list.get(0); System.out.println(orderEntity.getBillNo());
         * System.out.println(orderEntity.getCurIp()); } }
         */
    }
}
