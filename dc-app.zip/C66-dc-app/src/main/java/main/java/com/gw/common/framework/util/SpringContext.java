package main.java.com.gw.common.framework.util;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.boot.web.servlet.context.AnnotationConfigServletWebServerApplicationContext;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;

@Component
public class SpringContext implements ApplicationContextAware {

    private static BeanFactory beanFactory = null;
    public static Map<String, String> versions = new HashMap<String, String>();

    @Override
    public void setApplicationContext(ApplicationContext arg0) throws BeansException {
        SpringContext.beanFactory = arg0;
        loadVersions();

    }

    public static <T> T getBean(String beanId, Class<T> clazz) {

        if (beanFactory == null) {
            return null;
        } else {
            return (T) beanFactory.getBean(beanId);
        }
    }

    public static <T> T getBean(Class<T> clazz) {
        return getApplicationContext().getBean(clazz);
    }

    public static AnnotationConfigServletWebServerApplicationContext getApplicationContext() {
        return (AnnotationConfigServletWebServerApplicationContext) beanFactory;
    }

    private void loadVersions() {
        try {
            String file = "version.txt";
            FileReader fr = new FileReader(getWebRootAbsolutePath() + file);
            BufferedReader br = new BufferedReader(fr);
            try {
                String valueStr = null;
                while ((valueStr = br.readLine()) != null) {
                    String[] vArr = valueStr.split(":");
                    if (vArr.length >= 2) {
                        versions.put(vArr[0].trim(), vArr[1].trim());
                    }
                }
            } finally {
                if (fr != null)
                    fr.close();
                if (br != null)
                    br.close();
            }
        } catch (Exception e) {

        }
    }

    /**
     * @return WebRoot目录的绝对路径
     */
    private String getWebRootAbsolutePath() {
        String path = null;
        String folderPath = this.getClass().getResource("/").getPath();
        if (folderPath.indexOf("WEB-INF") > 0) {
            path = folderPath.substring(0, folderPath
                    .indexOf("WEB-INF/classes"));
        }
        return path;
    }


}
