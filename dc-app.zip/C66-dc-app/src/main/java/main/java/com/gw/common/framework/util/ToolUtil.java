/**
 *
 */
package main.java.com.gw.common.framework.util;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.Main;
import main.java.com.gw.common.framework.constant.AllProductOldcustomerConstants;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWCustomerCurrencyException;
import main.java.com.gw.common.framework.exception.GWPersistenceException;
import main.java.com.gw.common.system.entity.SBTCreditEntity;
import main.java.com.gw.common.system.entity.SBTOrderEntity;
import main.java.com.gw.common.system.parse.vo.Result;
import main.java.com.gw.common.system.props.CustomerPropertyholder;
import main.java.com.gw.datacenter.accounttransfer.entity.AccountTransferEntity;
import main.java.com.gw.datacenter.allocation.dao.AllocationDao;
import main.java.com.gw.datacenter.allocation.entity.RebateExclusiveGame;
import main.java.com.gw.datacenter.gameresult.entity.BaGameEntity;
import main.java.com.gw.datacenter.order.dao.OrderDao;
import main.java.com.gw.datacenter.order.entity.DictionaryEntity;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author alex.l
 */
@Slf4j
public class ToolUtil {
    private static String taskIds = "921";

    /**
     * Get the new begin time of timer.
     *
     * @param oldEndTime
     * @param timeIncreament
     * @return
     */
    public static String getNewBeginTimeByOldEndTime(String oldEndTime, long timeIncreament) {
        String newBeginTime = null;
        Date oldEndDate = DateUtil.formatStr2Date(oldEndTime, DateUtil.C_TIME_PATTON_DEFAULT);
        long old = oldEndDate.getTime();
        long newBeginSeconds = old + timeIncreament;
        Date newDate = new Date(newBeginSeconds);
        newBeginTime = DateUtil.formatDate2Str(newDate, DateUtil.C_TIME_PATTON_DEFAULT);
        return newBeginTime;
    }

    /**
     * Get the new end time of timer.
     *
     * @param oldEndTime
     * @param timeIncreament
     * @return newEndTime
     */
    public static String getNewEndTimeByOldEndTime(String oldEndTime, long timeIncreament) {
        String newEndTime = null;
        Date oldEndDate = DateUtil.formatStr2Date(oldEndTime, DateUtil.C_TIME_PATTON_DEFAULT);
        long old = oldEndDate.getTime();
        long newEndSeconds = old + timeIncreament;
        Date newDate = new Date(newEndSeconds);
        newEndTime = DateUtil.formatDate2Str(newDate, DateUtil.C_TIME_PATTON_DEFAULT);
        return newEndTime;
    }

    /**
     * Get the new end time of timer.
     *
     * @param oldEndTime
     * @param timeIncreament
     * @return newEndTime
     */
    public static String getNewEndTimeByOldEndTime_bbinAndAmayaOrder(String oldEndTime, long timeIncreament) {
        String newEndTime = null;
        Date oldEndDate = DateUtil.formatStr2Date(oldEndTime, DateUtil.C_TIME_PATTON_DEFAULT);
        long old = oldEndDate.getTime();

        long newEndSeconds = old + timeIncreament;
        Date newDate = new Date(newEndSeconds);
        if (new Date(old + 1000).getDate() != newDate.getDate()) {
            newEndTime = oldEndTime.substring(0, 10) + " 23:59:59";
        } else {
            newEndTime = DateUtil.formatDate2Str(newDate, DateUtil.C_TIME_PATTON_DEFAULT);
        }
        return newEndTime;
    }

    /**
     * Update parameterMap for Timers input parameters.
     *
     * @param parameterMap
     * @param beginSeconds
     * @param endSeconds
     * @return parameterMap
     */
    public static Map<String, Object> updateTimeForParameterMap(Map<String, Object> parameterMap, long beginSeconds, long endSeconds) {
        String beginTime = null;
        String endTime = null;
        if (parameterMap.containsKey(UtilConstants.ORDER_END_DATE)) {
            String entTimeStr = (String) parameterMap.get(UtilConstants.ORDER_END_DATE);
            beginTime = getNewBeginTimeByOldEndTime(entTimeStr, beginSeconds, DateUtil.C_TIME_PATTON_DEFAULT10);
            endTime = getNewEndTimeByOldEndTime(entTimeStr, endSeconds, DateUtil.C_TIME_PATTON_DEFAULT10);
            parameterMap.put(UtilConstants.ORDER_START_DATE, beginTime);
            parameterMap.put(UtilConstants.ORDER_END_DATE, endTime);
        } else {
            String entTimeStr = (String) parameterMap.get(UtilConstants.ORDER_END_TIME);//结束时间
            beginTime = getNewBeginTimeByOldEndTime(entTimeStr, beginSeconds);
            endTime = getNewEndTimeByOldEndTime(entTimeStr, endSeconds);//对结束时间进行处理
            parameterMap.put(UtilConstants.ORDER_BEGIN_TIME, beginTime);
            parameterMap.put(UtilConstants.ORDER_END_TIME, endTime);
        }
        return parameterMap;
    }

    public static Map<String, Object> updateTimeForParameterMap(Map<String, Object> parameterMap, long beginSeconds, long endSeconds, String format) {
        String beginTime = getNewBeginTimeByOldEndTime((String) parameterMap.get(UtilConstants.ORDER_END_TIME), beginSeconds, format);
        String endTime = getNewEndTimeByOldEndTime((String) parameterMap.get(UtilConstants.ORDER_END_TIME), endSeconds, format);
        parameterMap.put(UtilConstants.ORDER_BEGIN_TIME, beginTime);
        parameterMap.put(UtilConstants.ORDER_END_TIME, endTime);
        return parameterMap;
    }

    public static Map<String, Object> updateTimeForParameterMap_(Map<String, Object> parameterMap, long beginSeconds, long endSeconds) {
        String beginTime = getNewBeginTimeByOldEndTime_((String) parameterMap.get(UtilConstants.ORDER_END_TIME), beginSeconds);
        String endTime = getNewEndTimeByOldEndTime_((String) parameterMap.get(UtilConstants.ORDER_END_TIME), endSeconds);
        parameterMap.put(UtilConstants.ORDER_BEGIN_TIME, beginTime);
        parameterMap.put(UtilConstants.ORDER_END_TIME, endTime);
        return parameterMap;
    }

    /**
     * Update parameterMap for Timers input parameters.
     *
     * @param parameterMap
     * @param beginSeconds
     * @param endSeconds
     * @return parameterMap
     */
    public static Map<String, Object> updateTimeForBBINParameterMap(Map<String, Object> parameterMap, long beginSeconds, long endSeconds) {

        String beginTime = getNewBeginTimeByOldEndTime((String) parameterMap.get(UtilConstants.ORDER_END_TIME), beginSeconds);
        String endTime = getNewEndTimeByOldEndTime_bbinAndAmayaOrder((String) parameterMap.get(UtilConstants.ORDER_END_TIME), endSeconds);
        parameterMap.put(UtilConstants.ORDER_BEGIN_TIME, beginTime);
        parameterMap.put(UtilConstants.ORDER_END_TIME, endTime);
        return parameterMap;
    }



    public static Map<String, Object> updateTimeForSBTParameterMap(Map<String, Object> parameterMap, long beginSeconds, long endSeconds) {
        Date now = new Date();
        Date yestoday = DateUtils.addDays(now, -20);
        String beginTime = DateUtil.formatDate2Str(yestoday, DateUtil.C_DATE_PATTON_DDMMYYYY);
        String endTime = DateUtil.formatDate2Str(now, DateUtil.C_DATE_PATTON_DDMMYYYY);
        parameterMap.put("begintime", beginTime);
        parameterMap.put("endtime", endTime);
        return parameterMap;
    }

    /**
     * Generate string with MD5.
     *
     * @param parameterMap
     * @param baseUrl
     * @param encoding
     * @return
     */
    public static String generateKeyWithMD5(Map<String, Object> parameterMap, String baseUrl, String encoding) {
        String md5String = null;
        StringBuffer sb = new StringBuffer();
        String sbStr = null;
        for (Object str : parameterMap.keySet()) {
            sb.append(str.toString());
        }
        if (!StringUtils.isBlank(sbStr = sb.toString())) {
            md5String = MD5.MD5Encode(sbStr);
        }
        return md5String;
    }

    /**
     * Wait 10 mins if the endTime >= current time.
     *
     * @param parameterMap
     * @return boolean
     */
    public static boolean isWait10Mins4BeiJingTimeZone(Map<String, Object> parameterMap) {
        boolean isWait = false;
        if (parameterMap.get(UtilConstants.ORDER_END_TIME) instanceof Date) {
            Date endDate = (Date) parameterMap.get(UtilConstants.ORDER_END_TIME);
            long endTimeMilliseconds = endDate.getTime();
            long currentTimeMilliseconds = new Date().getTime();
            if (currentTimeMilliseconds < endTimeMilliseconds + 600000) {
                isWait = true;
            }
        } else {
            String endTime = (String) parameterMap.get(UtilConstants.ORDER_END_TIME);
            if (endTime != null) {
                Date endDate = DateUtil.formatStr2Date(endTime, DateUtil.C_TIME_PATTON_DEFAULT);
                long endTimeMilliseconds = endDate.getTime();
                long currentTimeMilliseconds = new Date().getTime();
                if (currentTimeMilliseconds < endTimeMilliseconds + 600000) {
                    isWait = true;
                }
            }
        }
        return isWait;
    }

    /**
     * Wait 2 mins if the endTime >= current time.
     *
     * @param parameterMap
     * @return boolean
     */
    public static boolean isWait2Mins4BeiJingTimeZone(Map<String, Object> parameterMap) {
        boolean isWait = false;
        if (parameterMap.get(UtilConstants.ORDER_END_TIME) instanceof Date) {
            Date endDate = (Date) parameterMap.get(UtilConstants.ORDER_END_TIME);
            long endTimeMilliseconds = endDate.getTime();
            long currentTimeMilliseconds = new Date().getTime();
            if (currentTimeMilliseconds < endTimeMilliseconds + 120000) {
                isWait = true;
            }
        } else {
            String endTime = (String) parameterMap.get(UtilConstants.ORDER_END_TIME);
            if (endTime != null) {
                Date endDate = DateUtil.formatStr2Date(endTime, DateUtil.C_TIME_PATTON_DEFAULT);
                long endTimeMilliseconds = endDate.getTime();
                long currentTimeMilliseconds = new Date().getTime();
                if (currentTimeMilliseconds < endTimeMilliseconds + 120000) {
                    isWait = true;
                }
            }
        }
        return isWait;
    }

    /**
     * Wait 10 mins if the endTime >= current time.
     *
     * @param parameterMap
     * @return boolean
     */
    public static boolean isWait10Mins(Map<String, Object> parameterMap) {
        boolean isWait = false;
        Date currentDate = DateUtil.formatStr2Date(ToolUtil.getTimeByTimeZoneId(new Date(), DateUtil.C_TIME_PATTON_DEFAULT,
                UtilConstants.TIMEZONE_GMT_W4));

        if (parameterMap.get(UtilConstants.ORDER_END_TIME) instanceof Date) {
            Date endDate = (Date) parameterMap.get(UtilConstants.ORDER_END_TIME);
            long endTimeMilliseconds = endDate.getTime();
            long currentTimeMilliseconds = currentDate.getTime();
            if (currentTimeMilliseconds < endTimeMilliseconds + 600000) {
                isWait = true;
            }
        } else {
            String endTime = (String) parameterMap.get(UtilConstants.ORDER_END_TIME);
            if (endTime != null) {
                Date endDate = DateUtil.formatStr2Date(endTime, DateUtil.C_TIME_PATTON_DEFAULT);
                long endTimeMilliseconds = endDate.getTime();
                long currentTimeMilliseconds = currentDate.getTime();
                if (currentTimeMilliseconds < endTimeMilliseconds + 600000) {
                    isWait = true;
                }
            }
        }
        return isWait;
    }

    public static void main(String[] args) throws ParseException {
        /*Date parse = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse("2014-06-2 23:59:59");
    	Date date = new Date();
    	String parse1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
    	Map<String, Object> parameterMap = new HashMap<String, Object>();
    	parameterMap.put(UtilConstants.ORDER_END_TIME, new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse("2014-06-2 23:59:59"));
    	boolean isWait = ToolUtil.isWaitXMins(parameterMap, UtilConstants.TIMEZONE_GMT, 8);
    	System.out.println(isWait);*/

//    	convertOrdersTimeZome(null,0);
        System.out.println(StringUtils.equalsIgnoreCase(null,"B01"));
        long beginSeconds = 1000;
        String entTimeStr = "2018-07-02 23:59:59";
        long endSeconds = 86400000;
        String beginTime = getNewBeginTimeByOldEndTime(entTimeStr, beginSeconds);
        System.out.println(beginTime + "开始时间");
        String endTime = getNewEndTimeByOldEndTime(entTimeStr, endSeconds);//对结束时间进行处理
        System.out.println(endTime + "结束时间");
    }


    /**
     * 订单时区处理  For Result {@link Result}
     *
     * @param orders
     * @param timeZoneId offset in hour, may be a negative number.
     * @return
     */
    public static List<Object> convertOrderTimeZome(List<Object> orders, String timeZoneId) {

        if (orders == null) return orders;

        for (int i = 0, j = orders.size(); i < j; i++) {
            OrderEntity order = (OrderEntity) orders.get(i);
            orders.set(i, convertOrderTimeZome(order, timeZoneId));
        }
        return orders;
    }

    /**
     * C07 SB7 额度数据出来要乘以1000
     *
     * @param creditEntityList
     */
    public static List<SBTCreditEntity> verifyC07SBTCreditTimeZone(List<SBTCreditEntity> creditEntityList, String platformId) {
        for (Object obj : creditEntityList) {
            SBTCreditEntity creditEntity = (SBTCreditEntity) obj;
            creditEntity.setPlatformId(platformId);
            String productId = creditEntity.getProductId();
            if (StringUtils.isNotBlank(productId)) {
                if (productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.C07.toString())) {
                    Date creationTime = creditEntity.getCreateDate();
                    if (needTransferTimzeZone(creditEntity.getPlatformId())) {
                        Date storageTime = ToolUtil.convertTimeByTimeDifference(creationTime, UtilConstants.CO7_OFFSETTIME);
                        creditEntity.setCreateDate(storageTime);
                    }
                    creditEntity.setCurrency(UtilConstants.CURRENCY.VND.toString());
                    //C07 数据出来要乘以1000
                    if (null != creditEntity.getCurrentBalance()) {
                        creditEntity.setCurrentBalance(creditEntity.getCurrentBalance().multiply(CurrencyUtil.TRANSFER_VAL));
                    }
                    if (null != creditEntity.getPreviousBalance()) {
                        creditEntity.setPreviousBalance(creditEntity.getPreviousBalance().multiply(CurrencyUtil.TRANSFER_VAL));
                    }

                    if (null != creditEntity.getTransferAmount()) {
                        creditEntity.setTransferAmount(creditEntity.getTransferAmount().multiply(CurrencyUtil.TRANSFER_VAL));
                    }
                }else{
                    //A03多币种判断
                    MultiCurrencyAmountsUtil.resetSBTCreditAmounts(creditEntity);
                }

            }
        }
        return creditEntityList;
    }

    /**
     * C07 SB7 注单数据出来要乘以1000
     *
     * @param orderEntityList
     */
    public static List<SBTOrderEntity> verifyC07SBTOrderTimeZone(List<SBTOrderEntity> orderEntityList, String platformId) {
        for (Object obj : orderEntityList) {
            SBTOrderEntity newOrderEntity = (SBTOrderEntity) obj;
            String productId = newOrderEntity.getProductId();
            Date billTime = newOrderEntity.getCreateDate();
            newOrderEntity.setPlatformId(platformId);
            if (StringUtils.isNotBlank(productId)) {
                if (productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.C07.toString())) {
                    if (needTransferTimzeZone(newOrderEntity.getPlatformId())) {
                        Date storageTime = ToolUtil.convertTimeByTimeDifference(billTime, UtilConstants.CO7_OFFSETTIME);
                        newOrderEntity.setCreateDate(storageTime);
                    }
                    newOrderEntity.setCurrency(UtilConstants.CURRENCY.VND.toString());

                    //C07 数据出来要乘以1000
                    if (needTransferOfPlat(newOrderEntity.getPlatformId(), billTime)) {
                        if (null != newOrderEntity.getAmount()) {
                            newOrderEntity.setAmount(newOrderEntity.getAmount().multiply(CurrencyUtil.TRANSFER_VAL));
                        }
                        if (null != newOrderEntity.getValidAmount()) {
                            newOrderEntity.setValidAmount(newOrderEntity.getValidAmount().multiply(CurrencyUtil.TRANSFER_VAL));
                        }

                        if (null != newOrderEntity.getRemainAmount()) {
                            newOrderEntity.setRemainAmount(newOrderEntity.getRemainAmount().multiply(CurrencyUtil.TRANSFER_VAL));
                        }

                        if (null != newOrderEntity.getPayOffAmount()) {
                            newOrderEntity.setPayOffAmount(newOrderEntity.getPayOffAmount().multiply(CurrencyUtil.TRANSFER_VAL));
                        }
                        if (null != newOrderEntity.getPreviousBalance()) {
                            newOrderEntity.setPreviousBalance(newOrderEntity.getPreviousBalance().multiply(CurrencyUtil.TRANSFER_VAL));
                        }
                        if (null != newOrderEntity.getWinAmount()) {
                            newOrderEntity.setWinAmount(newOrderEntity.getWinAmount().multiply(CurrencyUtil.TRANSFER_VAL));
                        }
                    }
                }else {

                    MultiCurrencyAmountsUtil.resetSBTOrderAmounts(newOrderEntity);
                }
            }
        }
        return orderEntityList;
    }


    /**
     * 订单时区处理 For Common OrderEntity {@link OrderEntity}
     *
     * @param order
     * @param timeZoneId
     * @return
     */
    public static OrderEntity convertOrderTimeZome(OrderEntity order, String timeZoneId) {
        if (order == null) return order;
        Date d1 = order.getBillTime();
        order.setBillTime(convertTimeZone(d1, timeZoneId));
        Date d2 = order.getCreationDate();
        order.setCreationDate(convertTimeZone(d2, timeZoneId));
        return order;
    }


    /**
     * TimeZone Converter
     *
     * @param date
     * @param timeZoneId
     * @return
     */
    public static Date convertTimeZone(Date date, String timeZoneId) {
        TimeZone timezone = TimeZone.getTimeZone(timeZoneId);
        DateTime dt = new DateTime(date);
        DateTimeZone zone = DateTimeZone.forTimeZone(timezone);
        return dt.withZone(zone).toLocalDateTime().toDate();
    }


    /**
     * 订单比例转换   For Result {@link Result}
     *
     * @param orders
     * @param ratio
     * @return
     */
    public static List<Object> convertCurrencyRatio(List<Object> orders, BigDecimal ratio) {

        for (int i = 0, j = orders.size(); i < j; i++) {
            OrderEntity order = (OrderEntity) orders.get(i);
            orders.set(i, convertCurrencyRatio(order, ratio));
        }
        return orders;
    }


    /**
     * 订单比例转换
     *
     * @param order
     * @param ratio
     * @return
     */
    public static OrderEntity convertCurrencyRatio(OrderEntity order, BigDecimal ratio) {
        order.setAccount(order.getAccount().multiply(ratio));
        order.setBonusAmount(order.getBonusAmount().multiply(ratio));
        order.setValidAccount(order.getValidAccount().multiply(ratio));
        order.setCusAccount(order.getCusAccount().multiply(ratio));

        return order;
    }


    /**
     * Wait X mins if the endTime >= current time.
     *
     * @param parameterMap
     * @return boolean
     */
    public static boolean isWaitXMins(Map<String, Object> parameterMap, String timeZoneId, int xMins) {
        Object e = parameterMap.get(UtilConstants.ORDER_END_TIME);
        Date endDate = null;
        if (e instanceof Date) {
            endDate = (Date) e;
        } else if (e instanceof String) {
            String endTime = (String) e;
            endDate = DateUtil.formatStr2Date(endTime);
        } else {
            return false;
        }
        return isWaitXMins(endDate, timeZoneId, xMins);
    }

    public static boolean isWaitXMins(String endTime, String timeZoneId, int xMins) {
        Date _endDate = DateUtil.formatStr2Date(endTime, DateUtil.C_TIME_PATTON_DEFAULT);
        return isWaitXMins(_endDate, timeZoneId, xMins);
    }

    private static boolean isWaitXMins(Date endDate, String timeZoneId, int xMins) {
        long endTimeMilliseconds = endDate.getTime();
        Date currentDate = DateUtil.formatStr2Date(ToolUtil.getTimeByTimeZoneId(new Date(), DateUtil.C_TIME_PATTON_DEFAULT, timeZoneId));
        long currentTimeMilliseconds = currentDate.getTime();
        return currentTimeMilliseconds < endTimeMilliseconds + xMins * 60 * 1000;
    }

    /* 注单最新时间和扫描最后时间相差比较*/
    public static boolean isWaitXMins(Date endDate, Date newDate, String timeZoneId, int xMins) {
        long endTimeMilliseconds = endDate.getTime();
        Date newCurrentDate = DateUtil.formatStr2Date(ToolUtil.getTimeByTimeZoneId(newDate, DateUtil.C_TIME_PATTON_DEFAULT, timeZoneId));
        long newTimeMilliseconds = newCurrentDate.getTime();
        return newTimeMilliseconds < endTimeMilliseconds + xMins * 60 * 1000;
    }

    /**
     * Wait 2 mins if the endTime >= current time.
     *
     * @param parameterMap
     * @param timeZoneId
     * @return boolean
     */
    public static boolean isWait2Mins(Map<String, Object> parameterMap, String timeZoneId) {
        return isWaitXMins(parameterMap, timeZoneId, 2);
    }

    /**
     * Wait 5 mins if the endTime >= current time.
     *
     * @param parameterMap
     * @param timeZoneId
     * @return boolean
     */
    public static boolean isWaitMins_bbin(Map<String, Object> parameterMap, String timeZoneId, Integer mins) {
        boolean isWait = false;
        Date currentDate = DateUtil.formatStr2Date(ToolUtil.getTimeByTimeZoneId(new Date(), DateUtil.C_TIME_PATTON_DEFAULT, timeZoneId));

        if (parameterMap.get(UtilConstants.ORDER_END_TIME) instanceof Date) {
            Date endDate = (Date) parameterMap.get(UtilConstants.ORDER_END_TIME);
            long endTimeMilliseconds = endDate.getTime();
            long currentTimeMilliseconds = currentDate.getTime();
            if (currentTimeMilliseconds < endTimeMilliseconds + 60000 * mins) {
                isWait = true;
            }
        } else {
            String endTime = (String) parameterMap.get(UtilConstants.ORDER_END_TIME);
            if (endTime != null) {
                Date endDate = DateUtil.formatStr2Date(endTime, DateUtil.C_TIME_PATTON_DEFAULT);
                long endTimeMilliseconds = endDate.getTime();
                long currentTimeMilliseconds = currentDate.getTime();
                if (currentTimeMilliseconds < endTimeMilliseconds + 60000 * mins) {
                    isWait = true;
                }
            }
        }
        return isWait;
    }

    /**
     * Whether ignore the struts2's filter.
     *
     * @param URI
     * @return boolean
     */
    public static boolean isIgnoreFilter(String URI) {
        boolean isIgnore = false;
        // Pattern pattern1 = Pattern.compile(".*/GWDataCenterService/GWDataCenterService");
        Pattern pattern2 = Pattern.compile(".*/javascript/My97DatePicker/My97DatePicker.htm");
        // Matcher matcher1 = pattern1.matcher(URI);
        Matcher matcher2 = pattern2.matcher(URI);
        /*
         * if(matcher1.find()){ return true; }
         */
        if (matcher2.find()) {
            return true;
        }
        return isIgnore;
    }

    /**
     * Get the new time for timer tasks.
     *
     * @param oldEndTime
     * @param timeIncreament
     * @return
     */
    public static Date getNewTimeByOldEndTime(Date oldEndTime, long timeIncreament) {
        long newBeginSeconds = oldEndTime.getTime() + timeIncreament;
        return new Date(newBeginSeconds);
    }

    /**
     * Get poker URL by cardtype and cardnum.
     *
     * @param pokerValue
     * @return String
     */
    public static String getPokerUrl(String pokerValue) {
        int cardvalue = Integer.parseInt(pokerValue);
        int cardtype = cardvalue / 16;
        int cardnum = cardvalue % 16;
        StringBuffer pic_name = new StringBuffer();
        switch (cardtype) {
            case 0:
                pic_name.append("hua_");
                break;
            case 1:
                pic_name.append("box_");
                break;
            case 2:
                pic_name.append("black_");
                break;
            case 3:
                pic_name.append("red_");
                break;
            default:
                break;
        }
        if (cardnum < 10) {
            pic_name.append("0" + cardnum);
        } else {
            pic_name.append("" + cardnum);
        }
        pic_name.append(".gif");
        return pic_name.toString();
    }

    /**
     * Check if any of the parameters(Object) is null
     *
     * @param pObj , the object to test
     * @return boolean
     */
    public static boolean isThereNull(Object... pObj) {
        for (Object obj : pObj) {
            if (obj == null || (obj instanceof String && StringUtils.isEmpty(obj.toString()))) {
                return true;
            }
        }

        return false;
    }

    /**
     * Check if the outerEasternUsTime is match localEasternTime.
     *
     * @param outerEasternUsTime
     * @return boolean
     * @throws Exception
     */
    public static boolean isDateMatch(String outerEasternUsTime) {
        boolean isMatch = false;
        String localEasternTime = null;
        TimeZone USEasternTimeZone = TimeZone.getTimeZone(UtilConstants.TIMEZONE_GMT_W4);
        SimpleDateFormat sdf = new SimpleDateFormat(DateUtil.C_TIME_PATTON_DEFAULT);
        sdf.setTimeZone(USEasternTimeZone);
        localEasternTime = sdf.format(new Date());

        long outerDateSeconds = (DateUtil.formatStr2Date(outerEasternUsTime)).getTime();
        long localDateSeconds = (DateUtil.formatStr2Date(localEasternTime)).getTime();
        if (outerDateSeconds >= localDateSeconds - 600000 && outerDateSeconds <= localDateSeconds + 600000) {
            isMatch = true;
        }
        return isMatch;
    }

    /**
     * Get US Eastern time.
     *
     * @param date
     * @param format
     * @return String
     */
    public static String getUsEasternTime(Date date, String format) {
        TimeZone USEasternTimeZone = TimeZone.getTimeZone(UtilConstants.TIMEZONE_GMT_W4);
        SimpleDateFormat sdf = null;
        if (format != null) {
            sdf = new SimpleDateFormat(format);
        } else {
            sdf = new SimpleDateFormat(DateUtil.C_TIME_PATTON_DEFAULT);
        }
        sdf.setTimeZone(USEasternTimeZone);
        return sdf.format(date);
    }

    /**
     * Get US Eastern time.
     *
     * @param date
     * @param format
     * @return String
     */
    public static String getTimeByTimeZoneId(Date date, String format, String timeZoneId) {
        TimeZone USEasternTimeZone = TimeZone.getTimeZone(timeZoneId);
        SimpleDateFormat sdf = null;
        if (format != null) {
            sdf = new SimpleDateFormat(format);
        } else {
            sdf = new SimpleDateFormat(DateUtil.C_TIME_PATTON_DEFAULT);
        }
        sdf.setTimeZone(USEasternTimeZone);
        return sdf.format(date);
    }

    /**
     * Format number precision
     *
     * @param target
     * @param scale
     * @param roundingMode
     * @return BigDecimal
     */
    public static BigDecimal formatNumberPrecision(BigDecimal target, Integer scale, RoundingMode roundingMode) {
        if (target != null) {
            if (scale == null) {
                scale = Integer.valueOf(2);
            }
            if (roundingMode == null) {
                roundingMode = RoundingMode.HALF_UP;
            }
            return target.setScale(scale, roundingMode);
        } else {
            return null;
        }
    }

    /**
     * Change GMT+4 time to GMT-8 time.
     *
     * @param usEsternDate
     * @return Date
     */
    public static Date transferUSEsternDateToCNEsternDate(Date usEsternDate) {
        Date newDate = null;
        if (usEsternDate != null) {
            long usSeconds = usEsternDate.getTime();
            long dateIncrement = 12 * 60 * 60 * 1000;
            newDate = new Date(usSeconds + dateIncrement);
        }
        return newDate;
    }

    public static Date transferCNEsternDateToUSEsternDate(Date usEsternDate) {
        Date newDate = null;
        if (usEsternDate != null) {
            long usSeconds = usEsternDate.getTime();
            long dateIncrement = -12 * 60 * 60 * 1000;
            newDate = new Date(usSeconds + dateIncrement);
        }
        return newDate;
    }

    /**
     * Change GMT time to GMT-8 time.
     *
     * @param gmtDateTime
     * @return Date
     */
    public static Date transferGMTDateToCNEsternDate(Date gmtDateTime) {
        Date newDate = null;
        if (gmtDateTime != null) {
            long usSeconds = gmtDateTime.getTime();
            long dateIncrement = 8 * 60 * 60 * 1000;
            newDate = new Date(usSeconds + dateIncrement);
        }
        return newDate;
    }

    /**
     * Change GMT time to GMT-8 time in Daylight Saving Time.
     *
     * @param targetDate
     * @return Date
     */
    public static Date convertTimeByTimeDifference(Date targetDate, int xHours) {
        Date newDate = null;
        if (targetDate != null) {
            long usSeconds = targetDate.getTime();
            long dateIncrement = xHours * 60 * 60 * 1000;
            newDate = new Date(usSeconds + dateIncrement);
        }
        return newDate;
    }

    /***
     *  计算 两个时区之间的 时间差
     *  由当前的时区 timeZoneCurrent  转为 timeZoneStandard 时区，所需的时间（小时）变化值
     *   timeZoneStandard：时间格式 ：Etc/GMT+10
     * ***/
    public static int  caculateTheHourGapBetweenTwoTimeZone(String timeZoneStandard,String timeZoneCurrent) {
        String standard  = timeZoneStandard.replace(UtilConstants.TIMEZONE_GMT,"").replace("+","").trim();
        String current  = timeZoneCurrent.replace(UtilConstants.TIMEZONE_GMT,"").replace("+","").trim();
        if(StringUtils.isEmpty(standard)){
            standard="0";
        }
        if(StringUtils.isEmpty(current)){
            current="0";
        }
        return Integer.parseInt(standard)-Integer.parseInt(current);
    }

    /**
     * @param cnEsternDate
     * @return Date
     */
    public static Date transferCNEsternDateToUSEscernDate(Date cnEsternDate) {
        Date newDate = null;
        if (cnEsternDate != null) {
            long cnSeconds = cnEsternDate.getTime();
            long dateIncrement = 12 * 60 * 60 * 1000;
            newDate = new Date(cnSeconds - dateIncrement);
        }
        return newDate;
    }

    /**
     * @param orignTimeZoneID
     * @param targetTimeZoneID
     * @return Date
     */
    public static Date transferToTargetTimeZoneDate(String orignTimeZoneID, String targetTimeZoneID, Date targetDate) {
        if (StringUtils.isBlank(orignTimeZoneID) || targetDate == null) {
            return targetDate;
        }
        Date transferDate = null;
        long orginalSeconds = targetDate.getTime();
        long dateIncrement = 0;
        if (UtilConstants.TIMEZONE_GMT_W4.equalsIgnoreCase(orignTimeZoneID)) {
            dateIncrement = 12 * 60 * 60 * 1000;
            transferDate = new Date(orginalSeconds + dateIncrement);
        } else if (UtilConstants.TIMEZONE_GMT.equalsIgnoreCase(orignTimeZoneID)) {
            dateIncrement = 8 * 60 * 60 * 1000;
            transferDate = new Date(orginalSeconds + dateIncrement);
        } else if (false) {
            // else time zone
        } else {
            // default Etc/GMT-8
            transferDate = targetDate;
        }
        return transferDate;
    }

    /**
     * remove prefix for BLM DSP login name.
     *
     * @param loginName
     * @return String
     */
    public static String removePrefix(String loginName) {
        char prefix = loginName.charAt(0);
        if (UtilConstants.CHARACTER_B.equalsIgnoreCase(String.valueOf(prefix))) {
            return loginName.substring(1, loginName.length());
        }
        return loginName;
    }

    /**
     * Show system time
     *
     * @return String
     */
    public static String showTimeForServer() {
        StringBuffer dateStr = new StringBuffer();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        dateStr.append(calendar.get(Calendar.YEAR));
        dateStr.append(UtilConstants.YEAR);
        dateStr.append(calendar.get(Calendar.MONTH) + 1);
        dateStr.append(UtilConstants.MONTH);
        dateStr.append(calendar.get(Calendar.DATE));
        dateStr.append(UtilConstants.DATE);
        dateStr.append(UtilConstants.BLANK_SPACE);
        int week = calendar.get(Calendar.DAY_OF_WEEK);
        switch (week) {
            case 1:
                dateStr.append(UtilConstants.WEEK_SEVEN);
                break;
            case 2:
                dateStr.append(UtilConstants.WEEK_ONE);
                break;
            case 3:
                dateStr.append(UtilConstants.WEEK_TWO);
                break;
            case 4:
                dateStr.append(UtilConstants.WEEK_THREE);
                break;
            case 5:
                dateStr.append(UtilConstants.WEEK_FOUR);
                break;
            case 6:
                dateStr.append(UtilConstants.WEEK_FIVE);
                break;
            case 7:
                dateStr.append(UtilConstants.WEEK_SIX);
                break;
        }
        dateStr.append(UtilConstants.BLANK_SPACE);
        if (calendar.get(Calendar.HOUR) < 10) {
            dateStr.append(UtilConstants.ZERO_STR + calendar.get(Calendar.HOUR));
        } else {
            dateStr.append(calendar.get(Calendar.HOUR));
        }
        dateStr.append(UtilConstants.COLON);
        if (calendar.get(Calendar.MINUTE) < 10) {
            dateStr.append(UtilConstants.ZERO_STR + calendar.get(Calendar.MINUTE));
        } else {
            dateStr.append(calendar.get(Calendar.MINUTE));
        }
        dateStr.append(UtilConstants.COLON);
        if (calendar.get(Calendar.SECOND) < 10) {
            dateStr.append(UtilConstants.ZERO_STR + calendar.get(Calendar.SECOND));
        } else {
            dateStr.append(calendar.get(Calendar.SECOND));
        }
        return dateStr.toString();
    }

    /**
     * format MM/DD/YYYY HH:MM:SS to YYYY-MM-DD HH:MM:SS
     *
     * @param hgDateTime
     */
    public static String formatDate4Hogame(String hgDateTime) {
        if (hgDateTime == null || hgDateTime.length() < 17) {
            return null;
        } else {
            StringBuffer sb = new StringBuffer();
            String[] dateArray = hgDateTime.split(UtilConstants.OBLIQUE_LINE);
            sb.append(dateArray[2].subSequence(0, 4));
            sb.append(UtilConstants.TRANSVERSE_LINE);
            sb.append(dateArray[0]);
            sb.append(UtilConstants.TRANSVERSE_LINE);
            sb.append(dateArray[1]);
            sb.append(dateArray[2].substring(4));
            return sb.toString();
        }
    }

    /**
     * remove duplicate object from list
     *
     * @param baGameEntity
     * @param targetList
     */
    public static boolean isExistObject(BaGameEntity baGameEntity, List<BaGameEntity> targetList) {
        String gameCode = baGameEntity.getGmCode();
        String gameType = baGameEntity.getGameType();
        if (gameCode != null && gameType != null) {
            for (BaGameEntity entity : targetList) {
                if (gameCode.equals(entity.getGmCode()) && gameType.equals(entity.getGameType())) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * transfer scientific notation to normal number
     *
     * @param numberStr
     * @return BigDecimal
     */
    public static BigDecimal transferScientificNotationToNumber(String numberStr) {
        BigDecimal targetBigDecimal = null;
        if (StringUtils.isBlank(numberStr)) {
            return targetBigDecimal;
        }
        DecimalFormat df = new DecimalFormat("#.##");
        targetBigDecimal = BigDecimal.valueOf(Double.valueOf(df.format(numberStr)));
        return targetBigDecimal;
    }

    /**
     * return amount string
     *
     * @param content
     * @return
     */
    public static String transferDecimalToStr(String content) {
        if (content == null) {
            return UtilConstants.BLANK;
        }
        BigDecimal amountBigDecimal = BigDecimal.valueOf((Double.valueOf(content))).divide(UtilConstants.HUNDREAD);
        return amountBigDecimal.toString();
    }

    /**
     * return time stamp
     *
     * @param dateStr
     * @param format
     */
    public static long getTimeStamp(String dateStr, String format) {
        long timestamp = DateUtil.formatStr2Date(dateStr, format).getTime() + 8 * 60 * 60 * 1000;
        return timestamp;
    }

    public static Date getCurrentTimeInGmt() {
        Calendar calendar = Calendar.getInstance();
        long timezoneOffset = TimeZone.getDefault().getOffset(calendar.getTimeInMillis());
        calendar.add(Calendar.MILLISECOND, (int) timezoneOffset * -1);
        return calendar.getTime();
    }

    public static String getCurrentGmtString() {
        SimpleDateFormat sdf = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss 'GMT'", Locale.ENGLISH);
        return sdf.format(getCurrentTimeInGmt());
    }

    /**
     * Get GMT time with Eglish format.
     *
     * @param date
     * @param format
     * @return String
     */
    public static String getGmtTimeWithEnglishFormat(Date date, String format, String timeZoneId) {
        TimeZone USEasternTimeZone = TimeZone.getTimeZone(timeZoneId);
        SimpleDateFormat sdf = null;
        if (format != null) {
            sdf = new SimpleDateFormat(format, Locale.ENGLISH);
        } else {
            sdf = new SimpleDateFormat(DateUtil.C_TIME_PATTON_DEFAULT, Locale.ENGLISH);
        }
        sdf.setTimeZone(USEasternTimeZone);
        return sdf.format(date);
    }

    public static String getNewBeginTimeByOldEndTime(String oldEndTime, long timeIncreament, String format) {
        String newBeginTime = null;
        Date oldEndDate = DateUtil.formatStr2Date(oldEndTime, format);
        long old = oldEndDate.getTime();
        long newBeginSeconds = old + timeIncreament;
        Date newDate = new Date(newBeginSeconds);
        newBeginTime = DateUtil.formatDate2Str(newDate, format);
        return newBeginTime;
    }

    public static String getNewEndTimeByOldEndTime(String oldEndTime, long timeIncreament, String format) {
        String newEndTime = null;
        Date oldEndDate = DateUtil.formatStr2Date(oldEndTime, format);
        long old = oldEndDate.getTime();
        long newEndSeconds = old + timeIncreament;
        Date newDate = new Date(newEndSeconds);
        newEndTime = DateUtil.formatDate2Str(newDate, format);
        return newEndTime;
    }


    public static String getNewBeginTimeByOldEndTime_(String oldEndTime, long timeIncreament) {
        String newBeginTime = null;
        Date oldEndDate = DateUtil.formatStr2Date(oldEndTime, DateUtil.C_TIME_PATTON_DEFAULT8);
        long old = oldEndDate.getTime();
        long newBeginSeconds = old + timeIncreament;
        Date newDate = new Date(newBeginSeconds);
        newBeginTime = DateUtil.formatDate2Str(newDate, DateUtil.C_TIME_PATTON_DEFAULT8);
        return newBeginTime;
    }


    public static String getNewEndTimeByOldEndTime_(String oldEndTime, long timeIncreament) {
        String newEndTime = null;
        Date oldEndDate = DateUtil.formatStr2Date(oldEndTime, DateUtil.C_TIME_PATTON_DEFAULT8);
        long old = oldEndDate.getTime();
        long newEndSeconds = old + timeIncreament;
        Date newDate = new Date(newEndSeconds);
        newEndTime = DateUtil.formatDate2Str(newDate, DateUtil.C_TIME_PATTON_DEFAULT8);
        return newEndTime;
    }


    public static boolean isWaitXMins_(Map<String, Object> parameterMap, String timeZoneId, int xMins) {
        Object e = parameterMap.get(UtilConstants.ORDER_END_TIME);
        Date endDate = null;
        if (e instanceof Date) {
            endDate = (Date) e;
        } else if (e instanceof String) {
            String endTime = (String) e;
            endDate = DateUtil.formatStr2Date(endTime, DateUtil.C_TIME_PATTON_DEFAULT8);
        } else {
            return false;
        }
        return isWaitXMins(endDate, timeZoneId, xMins);
    }

    public static boolean isWaitXMins_(Map<String, Object> parameterMap, String timeZoneId, int xMins, String format) {
        Object e = parameterMap.get(UtilConstants.ORDER_END_TIME);
        Date endDate = null;
        if (e instanceof Date) {
            endDate = (Date) e;
        } else if (e instanceof String) {
            String endTime = (String) e;
            endDate = DateUtil.formatStr2Date(endTime, format);
        } else {
            return false;
        }
        return isWaitXMins(endDate, timeZoneId, xMins);
    }

    private static boolean isSpecial(String productId, String platformId, String gameId, String gameKind) {
        if (StringUtils.isBlank(productId) || StringUtils.isBlank(platformId) || StringUtils.isBlank(gameId)) {
            log.info("method isSpecial return,productId=[" + productId + "],platformId=[" + platformId + "],gameId=[" + gameId + "]");
            return false;
        }
        if (!Objects.equals(UtilConstants.GAME_KIND_ENUM.ELECTRONIC.getCode(), gameKind) && !Objects.equals(UtilConstants.GAME_KIND_ENUM.LOTTERY.getCode(), gameKind)) {
            return false;
        }
        Map<String, Map<String, RebateExclusiveGame>> platformRebateExclusiveGameMap = UtilConstants.rebateExclusiveGameMap.get(productId);
        if (null == platformRebateExclusiveGameMap || platformRebateExclusiveGameMap.size() <= 0) {
            return false;
        }
        Map<String, RebateExclusiveGame> rebateExclusiveGameMap = platformRebateExclusiveGameMap.get(platformId);
        if (null == rebateExclusiveGameMap || rebateExclusiveGameMap.size() <= 0) {
            return false;
        }

        boolean bValid = false;
        try {
            RebateExclusiveGame rebateExclusiveGame = null;//rebateExclusiveGameMap.get(gameId);
            //循环本平台所有的游戏，按照“结尾匹配”、“开头匹配”、“精确匹配”的顺序（顺序在初始化map时已经在数据库中order by），定位匹配的特惠游戏记录。 add by ziv 2017-12-13
            for (Map.Entry<String, RebateExclusiveGame> entry : rebateExclusiveGameMap.entrySet()) {
                RebateExclusiveGame rebateExclusiveGameTemp = entry.getValue();
                String sGameIdCondition = rebateExclusiveGameTemp.getGameIdCondition();
                String sGameId = rebateExclusiveGameTemp.getGameId();
                if ("3".equals(sGameIdCondition)) {
                    if (gameId.endsWith(sGameId)) {
                        rebateExclusiveGame = rebateExclusiveGameTemp;
                    }
                } else if ("2".equals(sGameIdCondition)) {
                    if (gameId.startsWith(sGameId)) {
                        rebateExclusiveGame = rebateExclusiveGameTemp;
                    }
                } else if ("1".equals(sGameIdCondition)) {
                    if (gameId.equals(sGameId)) {
                        rebateExclusiveGame = rebateExclusiveGameTemp;
                    }
                } else {
                    continue;
                }
                //匹配到就跳出匹配循环
                if (rebateExclusiveGame != null) {
                    break;
                }
            }
            if (rebateExclusiveGame == null) {
                return false;
            }
            //是否特惠游戏增加生效时间、停止时间判断   add  by ziv 2017-11-24
            String sStartTime = rebateExclusiveGame.getStartTime();
            String sEndTime = rebateExclusiveGame.getEndTime();
            if (StringUtils.isNotBlank(sStartTime) && StringUtils.isNotBlank(sEndTime)) {
                Date startTime = DateUtil.formatStr2Date(sStartTime);
                Date endTime = DateUtil.formatStr2Date(sEndTime);
                Date nowTime = new Date();
                bValid = startTime.compareTo(nowTime) <= 0 && endTime.compareTo(nowTime) >= 0;
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        return bValid;
    }

    public static void validateIsSpecial(String platformId, OrderEntity newOrderEntity) {
        if (ToolUtil.isSpecial(newOrderEntity.getProductId(), platformId, newOrderEntity.getGameType(), newOrderEntity.getGameKind())) {
            newOrderEntity.setIsSpecia(UtilConstants.SPECIA_GAME);
            //newOrderEntity.setValidAccount(BigDecimal.ZERO);
            newOrderEntity.setRemainAmount(BigDecimal.ZERO);
            newOrderEntity.setValidAccount(newOrderEntity.getAccount());
        } else {
            newOrderEntity.setIsSpecia(UtilConstants.NORMAL_GAME);
        }
    }

    /**
     * @Description: 抽取出QuartzTaskLoader.java和本类initSpecialGames()中公共方法
     * @Author: Ziv.Y
     * @Date: 2017/12/12 20:54
     */
    public static void initSpecialGamesAll(String productId, String platformId, AllocationDao allocationDao) throws GWPersistenceException {
        List<RebateExclusiveGame> rebateExclusiveGameList = allocationDao.getRebateExclusiveGameList(productId, platformId);
        if (null == rebateExclusiveGameList || rebateExclusiveGameList.size() <= 0) {
            return;
        }
        //LinkedHashMap保证gameIdCondition顺序大到小
        /**
         * @question：游戏列表需要严格按照game_id_condition排序,说明这个字段业务含义
         * @answer：目前看与具体业务无关，主要为了页面上固定顺序展示数据
         */
        Map<String, RebateExclusiveGame> m = new LinkedHashMap<>();
        for (Iterator<RebateExclusiveGame> iterator = rebateExclusiveGameList.iterator(); iterator.hasNext(); ) {
            RebateExclusiveGame rebateExclusiveGame = iterator.next();
            m.put(rebateExclusiveGame.getGameId().trim(), rebateExclusiveGame);
        }
        if (UtilConstants.rebateExclusiveGameMap.containsKey(productId)) {
            UtilConstants.rebateExclusiveGameMap.get(productId).put(platformId, m);
        } else {
            Map<String, Map<String, RebateExclusiveGame>> mInit = new HashMap<>(1);
            mInit.put(platformId, m);
            UtilConstants.rebateExclusiveGameMap.put(productId, mInit);
        }
    }

    /**
     * 根据不同的产品将注单时间进行修改,C07 AG,KENO,OPUS,SHABA数据出来要乘以1000
     * MG新方式抓注单使用
     *
     * @param orderEntityList
     */
    public static List<Object> verifyOrderTimeZone(List<Object> orderEntityList, String platformId) throws Exception{
        for (Object obj : orderEntityList) {
            OrderEntity newOrderEntity = (OrderEntity) obj;
            String productId = newOrderEntity.getProductId();
            Date billTime = newOrderEntity.getBillTime();
            if(StringUtils.isBlank(productId)) {
                setProductId(newOrderEntity);
            }
            //处理b01的用户名问题
            handlerB01LoginName(newOrderEntity);

            productId = newOrderEntity.getProductId();
            if (StringUtils.isNotBlank(productId)) {
                if (productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.C07.toString())) {
                    if (needTransferTimzeZone(platformId)) {
                        Date storageTime = ToolUtil.convertTimeByTimeDifference(billTime, UtilConstants.CO7_OFFSETTIME);
                        newOrderEntity.setBillTime(storageTime);
                    }
                    newOrderEntity.setCurrency(UtilConstants.CURRENCY.VND.toString());

                    //add by Miles on 2016-8-26 C07 AG,KENO,OPUS,SHABA数据出来要乘以1000
                    if (needTransferOfPlat(platformId, billTime)) {
                        CurrencyUtil.multiplyOrderTransferVal(newOrderEntity);
                    }
                } else if (productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.V84.toString())) {
                    if (UtilConstants.SBO.equals(newOrderEntity.getPlatId())) {
                        // SHABA数据出来要乘以1000
                        CurrencyUtil.multiplyOrderTransferVal(newOrderEntity);
                    }
                } else if(!productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.C07.toString())){
                    //A03多币种判断
                    changeProductId(newOrderEntity);
                    MultiCurrencyAmountsUtil.resetOrderAmounts(newOrderEntity, null);
                }

            }

            // Transform deviceType
            String deviceType = newOrderEntity.getDeviceType();
            if (!StringUtils.isBlank(deviceType)) {
                if (UtilConstants.MG.equals(platformId) || UtilConstants.MG_VIP.equals(platformId) || UtilConstants.NETENT.equals(platformId) || UtilConstants.PNG.equals(platformId)) {
                    if (deviceType.equals("web") || deviceType.equals("download")) {
                        newOrderEntity.setDeviceType("0");
                    } else if (deviceType.equals("android") || deviceType.equals("html5")) {
                        newOrderEntity.setDeviceType("1");
                    } else if (deviceType.equals("null")) {
                        newOrderEntity.setDeviceType(null);
                    } else {
                        newOrderEntity.setDeviceType(deviceType);
                    }
                }
            }

            // Transform reckon flag
            Integer playType = newOrderEntity.getPlayType();
            if (playType != null) {
                String requestType = playType.toString();
                if (requestType.equals(UtilConstants.IOM_BET_TYPE_ENUM.BET.getCode())
                        || requestType.equals(UtilConstants.AMAYA_BET_TYPE_ENUM.BET.getCode())
                        || requestType.equals(UtilConstants.AMAYA_BET_TYPE_ENUM.BET1.getCode())) {
                    if (UtilConstants.MG.equals(platformId) || UtilConstants.MG_VIP.equals(platformId)) {
                        newOrderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.SETTLED.getFalg());
                    } else {
                        newOrderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.UNSETTLED.getFalg());
                    }
                }
                if (requestType.equals(UtilConstants.IOM_BET_TYPE_ENUM.PAY_OUT.getCode())
                        || requestType.equals(UtilConstants.AMAYA_BET_TYPE_ENUM.PAY_OUT.getCode())
                        || requestType.equals(UtilConstants.AMAYA_BET_TYPE_ENUM.PAY_OUT1.getCode())) {
                    newOrderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.SETTLED.getFalg());
                }
                if (requestType.equals(UtilConstants.IOM_BET_TYPE_ENUM.CANCEL.getCode())
                        || requestType.equals(UtilConstants.AMAYA_BET_TYPE_ENUM.CANCEL.getCode())) {
                    newOrderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.CANCELED.getFalg());
                }
            }
        }
        return orderEntityList;
    }

    private static void handlerB01LoginName(OrderEntity newOrderEntity) {
        if(UtilConstants.GAME_KIND_ENUM.ELECTRONIC.getCode().equalsIgnoreCase(newOrderEntity.getGameKind()) ||  UtilConstants.GAME_KIND_ENUM.LOTTERY.getCode().equalsIgnoreCase(newOrderEntity.getGameKind()))
        {
            if(StringUtils.equalsIgnoreCase(newOrderEntity.getProductId(),"B01")) {
                String loginName = newOrderEntity.getLoginName();
                String prefixForSlotGameAccount = UtilConstants.B01_BBIN_PREFIX;
                if (StringUtils.isNotBlank(loginName) && loginName.startsWith(prefixForSlotGameAccount)) {
                    newOrderEntity.setLoginName(loginName.substring(prefixForSlotGameAccount.length(), loginName.length()));
                }
            }
        }
    }

    private static void setProductId(OrderEntity newOrderEntity) {
        String loginName_PREFIX = newOrderEntity.getLoginName().substring(0, 1);
        String platFormId = newOrderEntity.getPlatId();
        if (platFormId.endsWith(UtilConstants.BBIN_BTT_UPDATE)) {
            if (loginName_PREFIX.endsWith(UtilConstants.A01REALPREFIX)) {
                newOrderEntity.setPlatId(UtilConstants.BBIN_BLM);
                newOrderEntity.setProductId(UtilConstants.PRODUCT_ENUM.A01.name());
            }
        } else if (platFormId.endsWith(UtilConstants.BBIN_LB_UPDATE)) {
            if (loginName_PREFIX.endsWith(UtilConstants.A02REALPREFIX)) {
                newOrderEntity.setPlatId(UtilConstants.BBIN_MT);
                newOrderEntity.setProductId(UtilConstants.PRODUCT_ENUM.A02.name());
            }
        } else if (platFormId.endsWith(UtilConstants.BBIN_HJ_UPDATE)) {
            if (loginName_PREFIX.endsWith(UtilConstants.A03REALPREFIX) || loginName_PREFIX.endsWith(UtilConstants.A03REALPREFIX_NWE)) {
                newOrderEntity.setPlatId(UtilConstants.BBIN_HWX);
                newOrderEntity.setProductId(UtilConstants.PRODUCT_ENUM.A03.name());
            } else if (loginName_PREFIX.endsWith(UtilConstants.A06REALPREFIX)) {
                newOrderEntity.setPlatId(UtilConstants.BBIN_KB);
                newOrderEntity.setProductId(UtilConstants.PRODUCT_ENUM.A06.name());
            } else if (loginName_PREFIX.endsWith(UtilConstants.C01REALPREFIX)) {
                newOrderEntity.setPlatId(UtilConstants.BBIN_WH);
                newOrderEntity.setProductId(UtilConstants.PRODUCT_ENUM.C01.name());
            } else if (loginName_PREFIX.endsWith(UtilConstants.A04REALPREFIX)) {
                newOrderEntity.setPlatId(UtilConstants.BBIN_ZL);
                newOrderEntity.setProductId(UtilConstants.PRODUCT_ENUM.A04.name());
            } else if (loginName_PREFIX.endsWith(UtilConstants.A05REALPREFIX)) {
                newOrderEntity.setPlatId(UtilConstants.BBIN_LL);
                newOrderEntity.setProductId(UtilConstants.PRODUCT_ENUM.A05.name());
            }
        } else if (platFormId.endsWith(UtilConstants.BBIN_YJ_UPDATE)) {

            if (loginName_PREFIX.endsWith(UtilConstants.A03REALPREFIX)
                    || AllProductOldcustomerConstants.A03OLDCUSTOMERLIST.contains(newOrderEntity.getLoginName())) {
                newOrderEntity.setPlatId(UtilConstants.BBIN_HWX);
                newOrderEntity.setProductId(UtilConstants.PRODUCT_ENUM.A03.name());
            } else if (loginName_PREFIX.endsWith(UtilConstants.A06REALPREFIX)
                    || AllProductOldcustomerConstants.A06OLDCUSTOMERLIST.contains(newOrderEntity.getLoginName())) {
                newOrderEntity.setPlatId(UtilConstants.BBIN_KB);
                newOrderEntity.setProductId(UtilConstants.PRODUCT_ENUM.A06.name());
            } else if (loginName_PREFIX.endsWith(UtilConstants.C01REALPREFIX)
                    || AllProductOldcustomerConstants.C01OLDCUSTOMERLIST.contains(newOrderEntity.getLoginName())) {
                newOrderEntity.setPlatId(UtilConstants.BBIN_WH);
                newOrderEntity.setProductId(UtilConstants.PRODUCT_ENUM.C01.name());
            } else if (loginName_PREFIX.endsWith(UtilConstants.A04REALPREFIX)
                    || AllProductOldcustomerConstants.A04OLDCUSTOMERLIST.contains(newOrderEntity.getLoginName())) {
                newOrderEntity.setPlatId(UtilConstants.BBIN_ZL);
                newOrderEntity.setProductId(UtilConstants.PRODUCT_ENUM.A04.name());
            } else if (loginName_PREFIX.endsWith(UtilConstants.A05REALPREFIX)
                    || AllProductOldcustomerConstants.A05OLDCUSTOMERLIST.contains(newOrderEntity.getLoginName())) {
                newOrderEntity.setPlatId(UtilConstants.BBIN_LL);
                newOrderEntity.setProductId(UtilConstants.PRODUCT_ENUM.A05.name());
            } else if (loginName_PREFIX.endsWith(UtilConstants.C02REALPREFIX)
                    || AllProductOldcustomerConstants.C02OLDCUSTOMERLIST.contains(newOrderEntity.getLoginName())) {
                newOrderEntity.setPlatId(UtilConstants.BBIN_HJHA);
                newOrderEntity.setProductId(UtilConstants.PRODUCT_ENUM.C02.name());
            } else if (loginName_PREFIX.endsWith(UtilConstants.B01REALPREFIX) || loginName_PREFIX.endsWith(UtilConstants.B01_BBIN_PREFIX)
                    || AllProductOldcustomerConstants.B01OLDCUSTOMERLIST.contains(newOrderEntity.getLoginName())) {
                newOrderEntity.setPlatId(UtilConstants.BBIN_BLM);
                newOrderEntity.setProductId(UtilConstants.PRODUCT_ENUM.B01.toString());
            }
        }
    }

    /**
     * 根据不同的产品将注单时间进行修改,C07 AG,KENO,OPUS,SHABA数据出来要乘以1000
     *
     * @param orderEntityList
     */
    public static List<Object> verifyOrderTimeZoneWithTaskId(List<Object> orderEntityList, Object taskId) throws Exception{
        for (Object obj : orderEntityList) {
            OrderEntity newOrderEntity = (OrderEntity) obj;
            String productId = newOrderEntity.getProductId();
            Date billTime = newOrderEntity.getBillTime();
            Date reckonTime = newOrderEntity.getReckonTime();//结算时间 add by ziv 2018-09-10
            if(StringUtils.isBlank(productId)) {
                setProductId(newOrderEntity);
            }
            //处理b01的用户名问题
            handlerB01LoginName(newOrderEntity);
            productId = newOrderEntity.getProductId();
            if (StringUtils.isNotBlank(productId)) {
                if (productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.C07.toString())) {
                    if (needTransferTimzeZone(newOrderEntity.getPlatId())) {
                        Date storageTime = ToolUtil.convertTimeByTimeDifference(billTime, UtilConstants.CO7_OFFSETTIME);
                        newOrderEntity.setBillTime(storageTime);
                        Date storageReckonTime = ToolUtil.convertTimeByTimeDifference(reckonTime, UtilConstants.CO7_OFFSETTIME);
                        newOrderEntity.setReckonTime(storageReckonTime);//结算时间 add by ziv 2018-09-10
                    }
                    newOrderEntity.setCurrency(UtilConstants.CURRENCY.VND.toString());

                    //add by Miles on 2016-8-26 C07 AG,KENO,OPUS,SHABA数据出来要乘以1000
                    if (needTransferOfPlat(newOrderEntity.getPlatId(), billTime)) {
                        CurrencyUtil.multiplyOrderTransferVal(newOrderEntity);
                    }
                }else if (productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.C31.toString())) {
                    //C31 币种需改为USD
                    newOrderEntity.setCurrency(UtilConstants.CURRENCY.USD.toString());
                }else if (productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.V84.toString())) {
                    if (UtilConstants.SHABA_FCLRC.equals(newOrderEntity.getPlatId())) {
                        // SHABA数据出来要乘以1000
                        CurrencyUtil.multiplyOrderTransferVal(newOrderEntity);
                    }
                }else {
                    changeProductId(newOrderEntity);
                    MultiCurrencyAmountsUtil.resetOrderAmounts(newOrderEntity, taskId);
                }

            }else{
                throw new GWCustomerCurrencyException(newOrderEntity.getLoginName()+"产品ID为空，注单号:"+newOrderEntity.getBillNo());
            }
        }
        return orderEntityList;
    }

    /**
     * 根据不同的产品将注单时间进行修改,C07 AG,KENO,OPUS,SHABA数据出来要乘以1000
     *
     * @param orderEntityList
     */
    public static List<Object> verifyOrderTimeZone(List<Object> orderEntityList) throws Exception{
        for (Object obj : orderEntityList) {
            OrderEntity newOrderEntity = (OrderEntity) obj;
            String productId = newOrderEntity.getProductId();
            Date billTime = newOrderEntity.getBillTime();
            Date reckonTime = newOrderEntity.getReckonTime();//结算时间 add by ziv 2018-09-10
            if(StringUtils.isBlank(productId)) {
                setProductId(newOrderEntity);
            }
            //处理b01的用户名问题
            handlerB01LoginName(newOrderEntity);
            productId = newOrderEntity.getProductId();
            if (StringUtils.isNotBlank(productId)) {
                if (productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.C07.toString())) {
                    if (needTransferTimzeZone(newOrderEntity.getPlatId())) {
                        Date storageTime = ToolUtil.convertTimeByTimeDifference(billTime, UtilConstants.CO7_OFFSETTIME);
                        newOrderEntity.setBillTime(storageTime);
                        Date storageReckonTime = ToolUtil.convertTimeByTimeDifference(reckonTime, UtilConstants.CO7_OFFSETTIME);
                        newOrderEntity.setReckonTime(storageReckonTime);//结算时间 add by ziv 2018-09-10
                    }
                    newOrderEntity.setCurrency(UtilConstants.CURRENCY.VND.toString());

                    //add by Miles on 2016-8-26 C07 AG,KENO,OPUS,SHABA数据出来要乘以1000
                    if (needTransferOfPlat(newOrderEntity.getPlatId(), billTime)) {
                        CurrencyUtil.multiplyOrderTransferVal(newOrderEntity);
                    }
                } else if (productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.V84.toString()) || productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.AW1.toString())
                        || productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.AW3.toString())){
                    changeProductId(newOrderEntity);
                    newOrderEntity.setCurrency(UtilConstants.CURRENCY.VND.toString());
                    if (needTransferOfPlat(newOrderEntity.getPlatId())) {
                        CurrencyUtil.multiplyOrderTransferVal(newOrderEntity);
                    }
                } else if (productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.C31.toString())) {
                    //C31 币种需改为USD
                    newOrderEntity.setCurrency(UtilConstants.CURRENCY.USD.toString());
                } else {
                    changeProductId(newOrderEntity);
                    MultiCurrencyAmountsUtil.resetOrderAmounts(newOrderEntity, null);
                }

            }
        }
        return orderEntityList;
    }

    public static void changeTranProductId(AccountTransferEntity entity) {
        try{
            OrderDao orderDao = (OrderDao) Main.factory.getBean("orderDao");
            Map<String, Object> paramMap = new HashMap<>();
            paramMap.put("dictName", "TRANS_PRODUCTID");
            List<DictionaryEntity> dictList = orderDao.getDictionaryListByParamMap(paramMap);
            DictionaryEntity dic =  dictList.stream().filter(a -> a.getDictValueZH().equals(entity.getPlatformId()) && a.getDictValueEN().equals(entity.getProductId())).findFirst().orElse(null);
            if(null != dic) {
                entity.setProductId(dic.getDictDesc());
            }
        }catch (Exception e) {
            return;
        }

    }

    public static void changeProductId(OrderEntity orderEntity) {
        try{
            OrderDao orderDao = (OrderDao) Main.factory.getBean("orderDao");
            Map<String, Object> paramMap = new HashMap<>();
            paramMap.put("dictName", "TRANS_PRODUCTID");
            List<DictionaryEntity> dictList = orderDao.getDictionaryListByParamMap(paramMap);
            DictionaryEntity dic =  dictList.stream()
                    .filter(a -> a.getDictValueZH().equals(orderEntity.getPlatId()) && a.getDictValueEN().equals(orderEntity.getProductId()))
                    .findFirst()
                    .orElse(null);
            if(null != dic) {
                orderEntity.setProductId(dic.getDictDesc());
            }
        }catch (Exception e) {
            return;
        }

    }

    public static List<OrderEntity> verifyOrderTimeZoneOrderEntity(List<OrderEntity> orderEntityList) throws Exception{
        for (OrderEntity obj : orderEntityList) {
            OrderEntity newOrderEntity = obj;
            String productId = newOrderEntity.getProductId();
            Date billTime = newOrderEntity.getBillTime();
            Date reckonTime = newOrderEntity.getReckonTime();//结算时间 add by ziv 2018-09-10
            if(StringUtils.isBlank(productId)) {
                setProductId(newOrderEntity);
            }
            //处理b01的用户名问题
            handlerB01LoginName(newOrderEntity);
            productId = newOrderEntity.getProductId();
            if (StringUtils.isNotBlank(productId)) {
                if (productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.C07.toString())) {
                    if (needTransferTimzeZone(newOrderEntity.getPlatId())) {
                        Date storageTime = ToolUtil.convertTimeByTimeDifference(billTime, UtilConstants.CO7_OFFSETTIME);
                        newOrderEntity.setBillTime(storageTime);
                        Date storageReckonTime = ToolUtil.convertTimeByTimeDifference(reckonTime, UtilConstants.CO7_OFFSETTIME);
                        newOrderEntity.setReckonTime(storageReckonTime);//结算时间 add by ziv 2018-09-10
                    }
                    newOrderEntity.setCurrency(UtilConstants.CURRENCY.VND.toString());

                    //add by Miles on 2016-8-26 C07 AG,KENO,OPUS,SHABA数据出来要乘以1000
                    if (needTransferOfPlat(newOrderEntity.getPlatId(), billTime)) {
                        CurrencyUtil.multiplyOrderTransferVal(newOrderEntity);
                    }
                } else if (productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.V84.toString()) || productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.AW1.toString())
                        || productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.AW3.toString())){
                    changeProductId(newOrderEntity);
                    newOrderEntity.setCurrency(UtilConstants.CURRENCY.VND.toString());
                    if (needTransferOfPlat(newOrderEntity.getPlatId())) {
                        CurrencyUtil.multiplyOrderTransferVal(newOrderEntity);
                    }

                } else if (productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.C31.toString())) {
                    //C31 币种需改为USD
                    newOrderEntity.setCurrency(UtilConstants.CURRENCY.USD.toString());
                }else {
                    changeProductId(newOrderEntity);
                    MultiCurrencyAmountsUtil.resetOrderAmounts(newOrderEntity, null);
                }

            }
        }
        return orderEntityList;
    }
    /**
     * 根据不同的产品将注单时间进行修改, OPUS没有使用平台ID，所以做特殊处理.C07 AG,KENO,OPUS,SHABA数据出来要乘以1000
     *
     * @param orderEntityList
     */
    public static List<Object> verifyOrderTimeZone(String productId, List<Object> orderEntityList, boolean isOpus) throws Exception{
        for (Object obj : orderEntityList) {
            OrderEntity newOrderEntity = (OrderEntity) obj;
            if ((UtilConstants.PRODUCT_ENUM.C07.toString()).equalsIgnoreCase(productId)) {
                Date billTime = newOrderEntity.getBillTime();
                if (needTransferTimzeZone(newOrderEntity.getPlatId())) {
                    Date storageTime = ToolUtil.convertTimeByTimeDifference(billTime, UtilConstants.CO7_OFFSETTIME);
                    newOrderEntity.setBillTime(storageTime);
                }
                newOrderEntity.setCurrency(UtilConstants.CURRENCY.VND.toString());

                //add by Miles on 2016-8-26 C07 AG,KENO,OPUS,SHABA数据出来要乘以1000
                if (isOpus || needTransferOfPlat(newOrderEntity.getPlatId(), billTime)) {
                    CurrencyUtil.multiplyOrderTransferVal(newOrderEntity);
                }

            } else if (productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.V84.toString()) || productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.AW1.toString())
                    || productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.AW3.toString())){
                changeProductId(newOrderEntity);
                newOrderEntity.setCurrency(UtilConstants.CURRENCY.VND.toString());
                if (needTransferOfPlat(newOrderEntity.getPlatId())) {
                    CurrencyUtil.multiplyOrderTransferVal(newOrderEntity);
                }
            }else if(!productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.C07.toString())){
                //A03多币种判断
                changeProductId(newOrderEntity);
                MultiCurrencyAmountsUtil.resetOrderAmounts(newOrderEntity, null);
            }

        }

        return orderEntityList;
    }



    /**
     * 根据不同的产品将转账时间进行修改,C07 SBT,AG,KENO,OPUS,SHABA数据出来要乘以1000
     *
     * @param accountTransferEntityList
     */
    public static List<AccountTransferEntity> verifyTransTimeZone(List<AccountTransferEntity> accountTransferEntityList) throws Exception{
        for (Object obj : accountTransferEntityList) {
            AccountTransferEntity accountTransEntity = (AccountTransferEntity) obj;
            String productId = accountTransEntity.getProductId();
            Date creationTime = accountTransEntity.getCreationTime();
            if (StringUtils.isNotBlank(productId)) {
                if (productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.C07.toString())) {
                    if (needTransferTimzeZone(accountTransEntity.getPlatformId())) {
                        Date storageTime = ToolUtil.convertTimeByTimeDifference(creationTime, UtilConstants.CO7_OFFSETTIME);
                        accountTransEntity.setCreationTime(storageTime);
                    }

                    //add by Miles on 2016-8-26 C07 AG,KENO,OPUS,SHABA数据出来要乘以1000
                    if (needTransferOfPlat(accountTransEntity.getPlatformId(), creationTime)) {
                        CurrencyUtil.multiplyAccountTransferVal(accountTransEntity);
                    }
                    if(UtilConstants.AGQJ.equalsIgnoreCase(accountTransEntity.getPlatformId())) {
                        accountTransEntity.setCurrency(UtilConstants.VND);
                    }
                } else if (productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.V84.toString()) || productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.AW1.toString())
                        || productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.AW3.toString())){
                    changeTranProductId(accountTransEntity);
                    if (needTransferOfPlat(accountTransEntity.getPlatformId())) {
                        CurrencyUtil.multiplyAccountTransferVal(accountTransEntity);
                    }
                    accountTransEntity.setCurrency(UtilConstants.VND);

                }else if(productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.C31.toString())){
                    //C31 币种需改为USD
                    accountTransEntity.setCurrency(UtilConstants.CURRENCY.USD.toString());
                } else {
                    //A03多币种判断
                    changeTranProductId(accountTransEntity);
                    MultiCurrencyAmountsUtil.resetTransferOrderAmounts(accountTransEntity);
                }
            }
        }
        return accountTransferEntityList;
    }

    public static List<Object> verifyTransObjectTimeZone(List<Object> accountTransferEntityList) throws Exception{
        for (Object obj : accountTransferEntityList) {
            AccountTransferEntity accountTransEntity = (AccountTransferEntity) obj;
            String productId = accountTransEntity.getProductId();
            Date creationTime = accountTransEntity.getCreationTime();
            if (StringUtils.isNotBlank(productId)) {
                if (productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.C07.toString())) {
                    if (needTransferTimzeZone(accountTransEntity.getPlatformId())) {
                        Date storageTime = ToolUtil.convertTimeByTimeDifference(creationTime, UtilConstants.CO7_OFFSETTIME);
                        accountTransEntity.setCreationTime(storageTime);
                    }

                    //add by Miles on 2016-8-26 C07 AG,KENO,OPUS,SHABA数据出来要乘以1000
                    if (needTransferOfPlat(accountTransEntity.getPlatformId(), creationTime)) {
                        CurrencyUtil.multiplyAccountTransferVal(accountTransEntity);
                    }
                    if(UtilConstants.AGQJ.equalsIgnoreCase(accountTransEntity.getPlatformId())) {
                        accountTransEntity.setCurrency(UtilConstants.VND);
                    }
                } else if (productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.V84.toString()) || productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.AW1.toString())
                        || productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.AW3.toString())){
                    changeTranProductId(accountTransEntity);
                    if (needTransferOfPlat(accountTransEntity.getPlatformId())) {
                        CurrencyUtil.multiplyAccountTransferVal(accountTransEntity);
                    }
                    accountTransEntity.setCurrency(UtilConstants.VND);

                }else {
                    //A03多币种判断
                    changeTranProductId(accountTransEntity);
                    MultiCurrencyAmountsUtil.resetTransferOrderAmounts(accountTransEntity);
                }
            }
        }
        return accountTransferEntityList;
    }

    private static boolean needTransferOfPlat(String platId, Date billTime) {
        String beginTimeStr = CustomerPropertyholder.getProperty("C07.agin.starttime");
        Date beginTime = DateUtil.formatStr2Date(beginTimeStr);

        return UtilConstants.AGQJ.equals(platId) || UtilConstants.MG.equals(platId) || UtilConstants.AG2.equals(platId) || UtilConstants.K8.equals(platId)
                || UtilConstants.SHABA_FCLRC.equals(platId) || UtilConstants.OPUS.equals(platId) || UtilConstants.NSS.equals(platId) || UtilConstants.CQ9.equals(platId) || UtilConstants.EBET.equals(platId)
                || (UtilConstants.AGIN.equals(platId) || UtilConstants.SBT.equals(platId) && beginTime != null && billTime.after(beginTime)
                || (UtilConstants.IM.equals(platId)) || (UtilConstants.IMDJ.equals(platId)) || (UtilConstants.SBO.equals(platId)) || (UtilConstants.PS.equals(platId)));
    }

    private static boolean needTransferOfPlat(String platId) {


        return UtilConstants.AGQJ.equals(platId) || UtilConstants.AG2.equals(platId) || UtilConstants.K8.equals(platId)
                || UtilConstants.SHABA_FCLRC.equals(platId) || UtilConstants.OPUS.equals(platId) || UtilConstants.NSS.equals(platId) || UtilConstants.CQ9.equals(platId) || UtilConstants.EBET.equals(platId)
                || (UtilConstants.AGIN.equals(platId) || UtilConstants.SBT.equals(platId)
                || (UtilConstants.IM.equals(platId)) || (UtilConstants.IMDJ.equals(platId)) || (UtilConstants.SBO.equals(platId)));
    }

    private static boolean needTransferTimzeZone(String platId) {
        return !(UtilConstants.AMAYA_FCLRC.equals(platId) || UtilConstants.MG.equals(platId));
    }

    public static Map<String, Object> updateTimeForK8SbtParameterMap(
            Map<String, Object> parameterMap, long beginSeconds, long endSeconds) {
        String beginTime = getNewBeginTimeByOldEndTime((String) parameterMap.get(UtilConstants.ORDER_END_TIME), beginSeconds);
        String endTime = getNewEndTimeByOldEndTime((String) parameterMap.get(UtilConstants.ORDER_END_TIME), endSeconds);
        parameterMap.put(UtilConstants.ORDER_BEGIN_TIME, beginTime);
        parameterMap.put(UtilConstants.ORDER_END_TIME, endTime);
        return parameterMap;
    }

    /**
     * TTG 设置devicetype之前，需要确定是否为历史数据，历史数据不能更改devicetype值
     *
     * @param billTime
     * @return
     */
    public static boolean canDoTTGDeviceType(Date billTime) {
        String pointTimeStr = CustomerPropertyholder.getProperty("TTG.new.devicetype.time");
        Date pointTime = DateUtil.formatStr2Date(pointTimeStr);
        if ((billTime.getTime() - pointTime.getTime()) > 0) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * tableMap.key
     * 整理所有游戏的deviceType统一化
     * (历史数据不能更改devicetype值)
     * 0=电脑网页版（老版本是0和9）
     * 1=手机网页版/手机网站APP 我们自己的移动端(不区分原生还是h5嵌套)
     * 101=电脑厅方app（厅方的exe安装文件 即旗舰厅APP）
     * 64=手机厅方app（厅方的APP 网站APP和手机WEB ）
     *
     * @param String
     * @return
     */

    private static final String[] AGArrStr = {"003", "032", "064"};//003=AGQJ,032=AGGB,064=AGSTAR

    public static String unifyAllDeviceType(String deviceType, Date billTime, String platformId) {

        String pointTimeStr = CustomerPropertyholder.getProperty("ALL.new.devicetype.definition.time");
        Date pointTime = DateUtil.formatStr2Date(pointTimeStr);

        if ((billTime.getTime() - pointTime.getTime()) <= 0) {
            return deviceType;
        }
        //可以进行按统一规划处理deviceType的值 （这一步必须放在if第一位）
        if (StringUtils.isBlank(deviceType) || deviceType.equals("9") || deviceType.equals("0")) {
            return "0";
        }
        if (deviceType.equals("1")) {
            return deviceType;
        }
        int deviceTypeInt = 0;
        try {
            //是否为AGQJ,AGGB,AGSTAR
            if (Arrays.asList(AGArrStr).contains(platformId)) {
                deviceTypeInt = Integer.parseInt(deviceType);
                //0,1,2,3,4,70
                if (deviceTypeInt < 5 || deviceTypeInt == 70) {
                    return "0";
                    //64,65,66,67,68,69
                } else if (deviceTypeInt >= 64) {
                    return "1";
                } else {
                    //厅方手机APP
                    return "101";
                }
            } else if (platformId.equals(UtilConstants.TLB)) {
                //这一句不能少
                if (deviceTypeInt == 101) {
                    return "101";
                }
            }
        } catch (Exception e) {
            return "0";
        }
        return "0";
    }

    public static List<Object> correctBillNoForMG(List<Object> orderEntityList, String platformId) {
        if (UtilConstants.MG.equals(platformId)) {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            for (Object obj : orderEntityList) {
                OrderEntity newOrderEntity = (OrderEntity) obj;
                String productId = newOrderEntity.getProductId();
                try {
                    Date C07Time = format.parse("2017-11-22 13:20:00"); //2017-11-22 05:20:00 +8
                    Date B06Time = format.parse("2017-11-16 14:30:00"); //2017-11-16 06:30:00 +8
                    Date A03Time = format.parse("2017-11-24 11:00:00"); //2017-11-24 03:00:00 +8
                    Date A01Time = format.parse("2018-01-25 11:00:00"); //2018-01-24 03:00:00 +8

                    if (StringUtils.isNotBlank(productId)) {
                        if (productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.C07.toString())) {
                            if (newOrderEntity.getBillTime().after(C07Time)) {
                                newOrderEntity.setBillNo(newOrderEntity.getTableCode());
                            }
                        } else if (productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.B06.toString())) {
                            if (newOrderEntity.getBillTime().after(B06Time)) {
                                newOrderEntity.setBillNo(newOrderEntity.getTableCode());
                            }
                        } else if (productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.A03.toString())
                                || productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.B01.toString())
                                || productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.B07.toString())) {
                            if (newOrderEntity.getBillTime().after(A03Time)) {
                                newOrderEntity.setBillNo(newOrderEntity.getTableCode());
                            }
                            //A01,A02,A04,A05,A06,C01,C02,E02,E03,E04
                        } else if (productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.A01.toString())
                                || productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.A02.toString())
                                || productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.A04.toString())
                                || productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.A05.toString())
                                || productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.A06.toString())
                                || productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.C01.toString())
                                || productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.C02.toString())
                                || productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.E02.toString())
                                || productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.E03.toString())
                                || productId.equalsIgnoreCase(UtilConstants.PRODUCT_ENUM.E04.toString())) {
                            if (newOrderEntity.getBillTime().after(A01Time)) {
                                newOrderEntity.setBillNo(newOrderEntity.getTableCode());
                            }
                        }
                    }
                } catch (ParseException e) {
                    log.error("Format Time Error", e);
                }
            }
        }
        return orderEntityList;
    }

    /**
     * According to the configuration to judge if need intercept response datagram
     *
     * @return
     */
    public static boolean isNeedInterceptResponse() {
        try {
            String beginTimeStr = CustomerPropertyholder.getProperty("intercept.response.begin");
            if (beginTimeStr == null || beginTimeStr.trim().equals("")) {
                return false;
            }

            String endTimeStr = CustomerPropertyholder.getProperty("intercept.response.end");
            if (endTimeStr == null || endTimeStr.trim().equals("")) {
                return false;
            }

            Date beginTime = DateUtil.formatStr2Date(beginTimeStr);
            Date endTime = DateUtil.formatStr2Date(endTimeStr);
            Date currentTime = new Date();
            return currentTime.after(beginTime) && currentTime.before(endTime);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return false;
        }
    }

    /**
     * @Description: 用dc_office字典中配置的开关来切换日志打印，SYS_CONFIG DCAPP_LOG_SWITCH（0：关，1：开）
     * @Author: Ziv.Y
     * @Date: 2018/8/16 10:29
     */
    public static boolean isNeedInterceptResponseByDictionary(String taskId) {
        boolean flag = false;
        try {
            OrderDao orderDao = (OrderDao) Main.factory.getBean("orderDao");
            Map<String, Object> paramMap = new HashMap<>();
            paramMap.put("dictName", "SYS_CONFIG");
            paramMap.put("dictZhValue", "DCAPP_LOG_IDS");
            List<DictionaryEntity> dictList = orderDao.getDictionaryListByParamMap(paramMap);
            if (dictList != null && dictList.size() > 0) {
                DictionaryEntity dictionaryEntity = dictList.get(0);
                if (StringUtils.isNotBlank(dictionaryEntity.getDictValueEN())
                        && Arrays.asList(dictionaryEntity.getDictValueEN().split(",")).contains(taskId)) {
                    flag = true;
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        return flag;
    }

    /**
     * According to the configuration to judge if need intercept response datagram
     *
     * @param taskId
     * @return
     */
    public static boolean isNeedInterceptResponse(String taskId) {
        if (taskIds.equals(taskId)) {
            return true;
        }

//        return isNeedInterceptResponse();
        return isNeedInterceptResponseByDictionary(taskId);//modified by ziv 2018-08-16
    }

    /**
     * 检查玩家的币种 for MBTC customer
     * MBTC玩家的注单数据 如果是厅方是CNY的 需要将数据除以MBTC/CNY的汇率
     * */
    //TODO
    public  static void verifyCustomerCurrencyInfo(){

    }

    public static boolean isContains(String list,String gameType) {
        if (StringUtils.isBlank(list)) {
            return false;
        }
        if (StringUtils.isBlank(gameType)) {
            return false;
        }
        return Arrays.stream(list.split(",")).anyMatch(i->i.equals(gameType));
    }



}
