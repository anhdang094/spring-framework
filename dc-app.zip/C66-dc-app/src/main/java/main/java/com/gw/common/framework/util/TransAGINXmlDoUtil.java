package main.java.com.gw.common.framework.util;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.datacenter.accounttransfer.entity.AccountTransferEntity;
import org.apache.commons.lang.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * pacy.g
 * dom4j 解析最新 AGIN 转账额度查询接口返回的xml数据
 */
@Slf4j
public class TransAGINXmlDoUtil {

    public static SAXParseXmlByNode createAGINResponXml(String xmlStr, Class claz, String platformId, String productId) throws DocumentException {

        xmlStr = xmlStr.replace("standalone=\"true\"?>", "standalone=\"yes\"?>");
        SAXParseXmlByNode saxParseXml = new SAXParseXmlByNode(platformId, claz);
        Document doc = xmlStrToDocument(xmlStr);
        Element rootElt = doc.getRootElement(); // 获取根节点
        Iterator iterCode = rootElt.elementIterator("Code"); // 获取根节点下的子节点Code
        // 遍历code节点
        String code = StringUtils.EMPTY;
        while (iterCode.hasNext()) {
            Element codeEle = (Element) iterCode.next();
            code = codeEle.getText();
        }
        saxParseXml.setInfo(code);
        if (code.equals("0")) {
            Iterator iterAddition = rootElt.elementIterator("addition"); // 获取根节点下的子节点addition
            while (iterAddition.hasNext()) {
                Element additionEle = (Element) iterAddition.next();
                String total = additionEle.elementTextTrim("total");
                String num_per_page = additionEle.elementTextTrim("num_per_page");
                String currentpage = additionEle.elementTextTrim("currentpage");
//                String totalpages = additionEle.elementTextTrim("totalpages");
                String perpage = additionEle.elementTextTrim("perpage");
                saxParseXml.setPlatformId(platformId);
//                saxParseXml.setApiPageSize(Integer.valueOf(totalpages));
                saxParseXml.setApiTotal(Integer.valueOf(total));
                saxParseXml.setIndex(Integer.valueOf(num_per_page));
            }
            // 获取根节点下的子节点row
            Iterator iter = rootElt.elementIterator("row");

            List<AccountTransferEntity> accountTransferEntityList = new ArrayList<AccountTransferEntity>(saxParseXml.getIndex());
            // 遍历row节点
            AccountTransferEntity entity = null;
            String transferRemark = StringUtils.EMPTY;
            String[] remarkArr = null;
            while (iter.hasNext()) {
                entity = new AccountTransferEntity();
                Element recordEle = (Element) iter.next();
                String tradeNo = recordEle.elementTextTrim("tradeNo");
                entity.setTradeNo(tradeNo);
                entity.setUserName(recordEle.elementTextTrim("playName"));
                entity.setTime__0to12(recordEle.elementTextTrim("creationTime"));
                entity.setTransferType(recordEle.elementTextTrim("transferType"));
                entity.setTransferAmount(BigDecimal.valueOf(Double.valueOf(recordEle.elementTextTrim("transferAmount"))));
                entity.setPreviousAmount(BigDecimal.valueOf(Double.valueOf(recordEle.elementTextTrim("previousAmount"))));
                entity.setCurrentAmount(BigDecimal.valueOf(Double.valueOf(recordEle.elementTextTrim("currentAmount"))));
                entity.setCurrency(recordEle.elementTextTrim("currency"));
                entity.setExchangeRate(BigDecimal.valueOf(Double.valueOf(recordEle.elementTextTrim("exchangeRate"))));
                transferRemark = recordEle.elementTextTrim("transferRemark");
                /**
                 * 如果  transferType 等于IN或者OUT的化，transferRemark的值为 traderId
                 * 如果  transferType 不等于IN和OUT的化，transferRemark的值包含局号
                 */
                if (entity.getTransferType().equalsIgnoreCase("IN") ||
                        entity.getTransferType().equalsIgnoreCase("OUT")) {
                    entity.setTransId(transferRemark);
                    entity.setRemark(transferRemark);
                } else {
                    //此transid字段数据库设置为非空,所以这里需要处理下，才能插入纪录到数据库
                    entity.setTransId(" ");
                    remarkArr = transferRemark.split(";");
                    if (remarkArr != null) {
                        if (remarkArr.length >= 3) {
                            entity.setRemark(transferRemark.substring(transferRemark.indexOf(";") + 1));
                        } else {
                            entity.setRemark(transferRemark);
                        }
                    } else {
                        entity.setRemark(StringUtils.EMPTY);
                    }
                }

                //entity.
                entity.setFlag(Integer.valueOf(recordEle.elementTextTrim("flag")));
                entity.setProductId(productId);
                entity.setPlatformId(platformId);

                entity.setAgCode(platformId);
                accountTransferEntityList.add(entity);
            }
            saxParseXml.setObjectList(accountTransferEntityList);
        } else {
            return saxParseXml;
        }
        return saxParseXml;
    }

    public static Document xmlStrToDocument(String xml) throws DocumentException {
        Document doc = DocumentHelper.parseText(xml);
        return doc;
    }


    public static void main(String args[]) {
        String xmlStr = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Data>" +
                "<row>" +
                "<tradeNo>171120975274817</tradeNo>" +
                "<platformType>AGIN</platformType>" +
                "<playName>flixiao55</playName>" +
                "<creationTime>2017-11-20 11:10:11</creationTime>" +
                "<transferType>IN</transferType><transferAmount>1</transferAmount>" +
                "<previousAmount>0.070000</previousAmount><currentAmount>1.070000</currentAmount><currency>CNY</currency>" +
                "<exchangeRate>1</exchangeRate><transferRemark>5032171120231056005</transferRemark><flag>0</flag>" +
                "</row>" +
                "<row>" +
                "<tradeNo>171120975274324</tradeNo>" +
                "<platformType>AGIN</platformType>" +
                "<playName>flixiao55</playName>" +
                "<creationTime>2017-11-20 11:10:11</creationTime>" +
                "<transferType>IN</transferType><transferAmount>1</transferAmount>" +
                "<previousAmount>0.070000</previousAmount><currentAmount>1.070000</currentAmount><currency>CNY</currency>" +
                "<exchangeRate>1</exchangeRate><transferRemark>5032171120231056005</transferRemark><flag>0</flag>" +
                "</row>" +
                "<row>" +
                "<tradeNo>171120975274819</tradeNo>" +
                "<platformType>AGIN</platformType>" +
                "<playName>flixiao55</playName>" +
                "<creationTime>2017-11-20 11:10:11</creationTime>" +
                "<transferType>IN</transferType><transferAmount>1</transferAmount>" +
                "<previousAmount>0.070000</previousAmount><currentAmount>1.070000</currentAmount><currency>CNY</currency>" +
                "<exchangeRate>1</exchangeRate><transferRemark>5032171120231056005</transferRemark><flag>0</flag>" +
                "</row>" +
                "<addition><total>55</total><num_per_page>20</num_per_page><currentpage>1</currentpage><totalpages>3</totalpages><perpage>20</perpage></addition>" +
                "<Code>0</Code>" +
                "</Data>";
        try {
            SAXParseXmlByNode node = createAGINResponXml(xmlStr, AccountTransferEntity.class, "agin", "A01");
            System.out.println(node.getInfo());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}