/**
 *
 */
package main.java.com.gw.common.framework.util;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.GameType;
import main.java.com.gw.common.framework.constant.UtilConstants;
import org.apache.commons.lang3.StringUtils;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static main.java.com.gw.common.framework.constant.UtilConstants.GAME_TYPE_KEY_IOM;

/**
 * @author alex.l
 */
@Slf4j
@SuppressWarnings("unused")
public class UrlGeneratorUtil {

    /**
     * Function disparcher.
     *
     * @param parameterMap
     * @param baseUrl
     * @param encoding
     * @return
     * @throws UnsupportedEncodingException
     */
    public static String generateUrl(Map<String, Object> parameterMap, String baseUrl, String encoding) {
        String platformId = (String) parameterMap.get(UtilConstants.GLOBAL_PLATFORMID_KEY);
        Integer gameType = (Integer) parameterMap.get(UtilConstants.GAME_TYPE_KEY_IOM);
        String[] array = StringUtils.split(platformId, UtilConstants.UNDERLINE);
        // for order
        //update by pacy.g ---- begin
        if (UtilConstants.ACCOUNT_TRANSFER_AGIN.equalsIgnoreCase(platformId)) {
            return generateUrlAGINForOrderApi(parameterMap, baseUrl, encoding);
            //update by pacy.g ---- end
        } else if (UtilConstants.ORDERS_AGIN.equalsIgnoreCase(platformId)) {
            //AGIN 注单纪录
            return generateUrlAGINForOrderApi(parameterMap, baseUrl, encoding);
        } else if (UtilConstants.ORDERS_AGIN_SPORT.equalsIgnoreCase(platformId)) {
            //AGIN SPROT 注单纪录
            return generateUrlAGINForOrderApi(parameterMap, baseUrl, encoding);
        } else if (UtilConstants.CQ9.equalsIgnoreCase(platformId)) {
            //CQ9注单纪录
            return generateUrlForCQ9OrderApi(parameterMap, baseUrl, encoding);
        }  else if (UtilConstants.CG.equalsIgnoreCase(platformId)) {
            //CG注单纪录
            return generateUrlForCGOrderApi(parameterMap, baseUrl, encoding);
        }else if (UtilConstants.ORDERS.equalsIgnoreCase(array[0])) {
            if (!UtilConstants.ORDERS_BLM_BBIN.equalsIgnoreCase(platformId) && !UtilConstants.ORDERS_MT_BBIN.equalsIgnoreCase(platformId)
                    && !UtilConstants.ORDERS_ZL_BBIN.equalsIgnoreCase(platformId) && !UtilConstants.ORDERS_LL_BBIN.equalsIgnoreCase(platformId)
                    && !UtilConstants.ORDERS_HJ_BBIN.equalsIgnoreCase(platformId) && !UtilConstants.ORDERS_WH_BBIN.equalsIgnoreCase(platformId)
                    && !UtilConstants.ORDERS_BJH_NEW_BBIN.equalsIgnoreCase(platformId) && !UtilConstants.ORDERS_KB_BBIN.equalsIgnoreCase(platformId)
                    && !UtilConstants.ORDERS_HJHA_BBIN.equalsIgnoreCase(platformId)
                    && !UtilConstants.ORDERS_HWX_BBIN.equalsIgnoreCase(platformId)
                    && !UtilConstants.ORDERS_E02_BBIN.equalsIgnoreCase(platformId)
                    && !UtilConstants.ORDERS_E03_BBIN.equalsIgnoreCase(platformId)
                    && !UtilConstants.ORDERS_E04_BBIN.equalsIgnoreCase(platformId)
                    && !UtilConstants.ORDERS_B01_BBIN.equalsIgnoreCase(platformId)
                    && !UtilConstants.ORDERS_B79_BBIN.equalsIgnoreCase(platformId)
                    && !UtilConstants.ORDERS_SHABA_UK.equalsIgnoreCase(platformId)
                    && !UtilConstants.ORDERS_SHABA_FCLRC2.equalsIgnoreCase(platformId)
                    && !UtilConstants.ORDERS_SHABA_FCLRC.equalsIgnoreCase(platformId)
                    && !UtilConstants.ORDERS_SHABA_FCLRC3.equalsIgnoreCase(platformId)
                    && !UtilConstants.ORDERS_AMAYA_FCLRC.equalsIgnoreCase(platformId)
                    && !UtilConstants.ORDERS_MG.equalsIgnoreCase(platformId)
                    && !UtilConstants.ORDERS_PNG.equalsIgnoreCase(platformId)
                    // bbin注单更新情况
                    && !UtilConstants.ORDERS_BTT_UPDATE_BBIN.equalsIgnoreCase(platformId)
                    && !UtilConstants.ORDERS_LB_UPDATE_BBIN.equalsIgnoreCase(platformId)
                    && !UtilConstants.ORDERS_HJ_UPDATE_BBIN.equalsIgnoreCase(platformId)
                    && !UtilConstants.ORDERS_YJ_UPDATE_BBIN.equalsIgnoreCase(platformId)

                    && !UtilConstants.ORDERS_AMAYA_VIP_FCLRC.equalsIgnoreCase(platformId)
                    && !UtilConstants.ORDERS_MG_VIP.equalsIgnoreCase(platformId)) {
                return generateUrlForOrderApi(parameterMap, baseUrl, platformId, encoding);
            } else {
                return generateUrlForBBINOrderApi(parameterMap, baseUrl, platformId, encoding);
            }
            // for game result
        } else if (UtilConstants.GAMERESULT.equalsIgnoreCase(array[0])) {
            return generateUrlForBaGameResultApi(parameterMap, baseUrl, platformId, encoding);
            // for account transfer
        } else if (UtilConstants.TRANSFER.equalsIgnoreCase(array[0])) {
            if (UtilConstants.ACCOUNT_TRANSFER_BBIN_BLM.equalsIgnoreCase(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_BBIN_MT.equalsIgnoreCase(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_BBIN_ZL.equalsIgnoreCase(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_BBIN_LL.equalsIgnoreCase(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_BBIN_HJ.equalsIgnoreCase(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_BBIN_WH.equalsIgnoreCase(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_BBIN_NEWBJH.equalsIgnoreCase(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_BBIN_KB.equalsIgnoreCase(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_BBIN_HWX.equalsIgnoreCase(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_SHABA_UK.equalsIgnoreCase(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_SHABA_FCLRC.equalsIgnoreCase(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_AMAYA_FCLRC.equalsIgnoreCase(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_MG.equalsIgnoreCase(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_BBIN_HJHA.equalsIgnoreCase(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_BBIN_E02.equalsIgnoreCase(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_BBIN_E03.equalsIgnoreCase(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_BBIN_E04.equalsIgnoreCase(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_BBIN_B01.equalsIgnoreCase(platformId)
                    || gameType.intValue() == GameType.IOM_WALLET.getType()
                    || UtilConstants.ACCOUNT_TRANSFER_SBT.equalsIgnoreCase(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_PNG.equalsIgnoreCase(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_NETENT.equalsIgnoreCase(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_PPG.equalsIgnoreCase(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_CQ9.equalsIgnoreCase(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_BBIN_B79.equalsIgnoreCase(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_YSB.equalsIgnoreCase(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_NB.equalsIgnoreCase(platformId)
//                    || UtilConstants.ACCOUNT_TRANSFER_AG.equalsIgnoreCase(platformId)
            ) {
                return generateUrlForAccountTransferBBINApi(parameterMap, baseUrl, platformId, encoding);
            } else if (UtilConstants.ACCOUNT_TRANSFER_UK_KB.equalsIgnoreCase(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_UK_BTT.equalsIgnoreCase(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_UK_LB.equalsIgnoreCase(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_UK_HWX.equalsIgnoreCase(platformId)) {
                return generateUrlForA06Hogaming(parameterMap, baseUrl, encoding);
            } else if(UtilConstants.ACCOUNT_TRANSFER_BBIN_PRO.equalsIgnoreCase(platformId)){

            } else {
                return generateUrlForAccountTransferDspApi(parameterMap, baseUrl, platformId, encoding);
            }
        }else if (UtilConstants.ORDERS_AGQJ_EXCEPTIONOR.equalsIgnoreCase(platformId)){//CAP-2480 AGQJ篡改注单 20190108
            return generateUrlForAGQJExceptionor(parameterMap, baseUrl, encoding);
        } else if (UtilConstants.AGQJ.equalsIgnoreCase(array[0]) && gameType == GameType.IOM_WALLET.getType()) {//处理AGQJ电子钱包模式的额度记录的错误日志
            return generateUrlForAccountTransferBBINApi(parameterMap, baseUrl, platformId, encoding);
        }
        return null;
    }

    /**
     * Agin游戏注单数据拼装URL
     *
     * @param parameterMap
     * @param baseUrl
     * @param encoding
     * @return
     */
    public static String generateComputerGameUrl(Map<String, Object> parameterMap, String baseUrl, String encoding) {
        String platformId = (String) parameterMap.get(UtilConstants.GLOBAL_PLATFORMID_KEY);
        String[] array = StringUtils.split(platformId, UtilConstants.UNDERLINE);
        return generateComputerGameOrderApi(parameterMap, baseUrl, encoding);
    }


    /**
     * (ORDERS)Construct key and URL,and then return whole URL string.
     *
     * @param parameterMap
     * @param baseUrl
     * @param encoding
     * @return String
     * @throws UnsupportedEncodingException
     */
    public static String generateUrlForOrderApi(Map<String, Object> parameterMap, String baseUrl, String platformId, String encoding) {
        String MD5KeyStr = null;
        String object = null;
        // construct key
        StringBuffer sbKey = new StringBuffer();
        // construct URL
        StringBuffer wholeUrl = new StringBuffer(baseUrl);
        // according to baseUrl,add prefix for URL
        if (baseUrl.indexOf(UtilConstants.QUESTION_MARK) == -1) {
            wholeUrl.append(UtilConstants.QUESTION_MARK);
        } else {
            wholeUrl.append(UtilConstants.LOGICAL_AND);
        }
        try {
            // loginName
            object = (String) parameterMap.get(UtilConstants.ORDER_LOGIN_NAME);
            if (!StringUtils.isBlank(object)) {
                sbKey.append(object);
                wholeUrl.append(UtilConstants.ORDER_LOGIN_NAME);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            // agCode
            object = (String) parameterMap.get(UtilConstants.ORDER_AG_CODE);
            if (!StringUtils.isBlank(object)) {
                sbKey.append(object);
                wholeUrl.append(UtilConstants.ORDER_AG_CODE);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            // beginTime
            object = (String) parameterMap.get(UtilConstants.ORDER_BEGIN_TIME);
            if (!StringUtils.isBlank(object)) {
                sbKey.append(object);
                wholeUrl.append(UtilConstants.ORDER_BEGIN_TIME);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            // endTime
            object = (String) parameterMap.get(UtilConstants.ORDER_END_TIME);
            if (!StringUtils.isBlank(object)) {
                sbKey.append(object);
                wholeUrl.append(UtilConstants.ORDER_END_TIME);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            // result
            object = (String) parameterMap.get(UtilConstants.ORDER_RESULT);
            if (!StringUtils.isBlank(object)) {
                sbKey.append(object);
                wholeUrl.append(UtilConstants.ORDER_RESULT);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            // tableCode
            object = (String) parameterMap.get(UtilConstants.ORDER_TABLE_CODE);
            if (!StringUtils.isBlank(object)) {
                sbKey.append(object);
                wholeUrl.append(UtilConstants.ORDER_TABLE_CODE);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            // playType
            object = (String) parameterMap.get(UtilConstants.ORDER_PLAY_TYPE);
            if (!StringUtils.isBlank(object)) {
                sbKey.append(object);
                wholeUrl.append(UtilConstants.ORDER_PLAY_TYPE);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            // billno
            object = (String) parameterMap.get(UtilConstants.ORDER_BILL_NO);
            if (!StringUtils.isBlank(object)) {
                sbKey.append(object);
                wholeUrl.append(UtilConstants.ORDER_BILL_NO);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            // gmcode
            object = (String) parameterMap.get(UtilConstants.ORDER_GM_CODE);
            if (!StringUtils.isBlank(object)) {
                sbKey.append(object);
                wholeUrl.append(UtilConstants.ORDER_GM_CODE);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            // order
            object = (String) parameterMap.get(UtilConstants.ORDER_ORDER);
            if (!StringUtils.isBlank(object)) {
                sbKey.append(object);
                wholeUrl.append(UtilConstants.ORDER_ORDER);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            // by
            object = (String) parameterMap.get(UtilConstants.ORDER_BY);
            if (!StringUtils.isBlank(object)) {
                sbKey.append(object);
                wholeUrl.append(UtilConstants.ORDER_BY);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            // page
            object = (String) parameterMap.get(UtilConstants.ORDER_PAGE);
            if (!StringUtils.isBlank(object)) {
                sbKey.append(object);
                wholeUrl.append(UtilConstants.ORDER_PAGE);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            // num
            object = (String) parameterMap.get(UtilConstants.ORDER_PAGE_NUMBER);
            if (!StringUtils.isBlank(object)) {
                sbKey.append(object);
                wholeUrl.append(UtilConstants.ORDER_PAGE_NUMBER);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get(UtilConstants.ORDER_PRODUCT_ID);
            if (!StringUtils.isBlank(object)) {
                sbKey.append(object);
                wholeUrl.append(UtilConstants.ORDER_PRODUCT_ID);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get(UtilConstants.ORDER_START_DATE);
            if (!StringUtils.isBlank(object)) {
                sbKey.append(object);
                wholeUrl.append(UtilConstants.ORDER_START_DATE);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get(UtilConstants.ORDER_END_DATE);
            if (!StringUtils.isBlank(object)) {
                sbKey.append(object);
                wholeUrl.append(UtilConstants.ORDER_END_DATE);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get(UtilConstants.ORDER_PAGE_NO);
            if (!StringUtils.isBlank(object)) {
                sbKey.append(object);
                wholeUrl.append(UtilConstants.ORDER_PAGE);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }

            object = (String) parameterMap.get(UtilConstants.ORDER_PER_PAGE);
            if (!StringUtils.isBlank(object)) {
                sbKey.append(object);
                wholeUrl.append(UtilConstants.ORDER_PER_PAGE);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }

            //added by hopkin 2019-07-12 true or false 是否搜索未派彩注单 默认不搜索
            object = (String) parameterMap.get(UtilConstants.ORDER_PER_SEARCHALL);
            if(StringUtils.isNotBlank(object)){
                sbKey.append(object);
                wholeUrl.append(UtilConstants.ORDER_PER_SEARCHALL);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }

            // Add by Alex on 2012-03-19 -begin
            /*
             * if(UtilConstants.ORDERS_DSP.equalsIgnoreCase(platformId)){ sbKey.append(UtilConstants.SUFFIX); }else
             * if(UtilConstants.ORDERS_K8.equalsIgnoreCase(platformId)){ sbKey.append(UtilConstants.SUFFIX_K8); }else{
             * sbKey.append(UtilConstants.SUFFIX_DYJ); }
             */
            if (!UtilConstants.ORDERS_K8.equalsIgnoreCase(platformId)) {
                sbKey.append(UtilConstants.SUFFIX);
            } else {
                sbKey.append(UtilConstants.SUFFIX_K8);
            }
            // Add by Alex on 2012-03-19 -end

            wholeUrl.append(UtilConstants.ORDER_KEY);
            wholeUrl.append(UtilConstants.ASSIGNMENT);
            // Get key by MD5
            MD5KeyStr = MD5.MD5Encode(sbKey.toString());
            wholeUrl.append(URLEncoder.encode(MD5KeyStr, encoding));
        } catch (UnsupportedEncodingException ex) {
            log.error("UrlGeneratorUtil generateUrlForOrderApi error:" + ex.getMessage(), ex);
        }
        return wholeUrl.toString();
    }

    /**
     * (ORDERS)Construct remote URL for BBIN order API. key = A+B+C A = 3 freewill characters. B = MD5(target + username + gamekind + KeyB + password
     * + website + YYYYMMDD) C = 7 freewill characters.
     *
     * @param parameterMap
     * @param baseUrl
     * @param encoding
     * @return String
     * @throws
     */
    public static String generateUrlForBBINOrderApi(Map<String, Object> parameterMap, String baseUrl, String platformId, String encoding) {
        String MD5KeyStr = null;
        String object = null;
        // construct key
        StringBuffer sbKey = new StringBuffer();
        // construct URL
        StringBuffer wholeUrl = new StringBuffer(baseUrl);
        // according to baseUrl,add prefix for URL
        if (baseUrl.indexOf(UtilConstants.QUESTION_MARK) == -1) {
            wholeUrl.append(UtilConstants.QUESTION_MARK);
        } else {
            wholeUrl.append(UtilConstants.LOGICAL_AND);
        }

        try {
            object = (String) parameterMap.get("target");// target
            if (!StringUtils.isBlank(object)) {
                // target
                // sbKey.append(object);//edit by edwin on 20130629
                wholeUrl.append("target");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get("website");
            if (!StringUtils.isBlank(object)) {
                // website
                sbKey.append(object);
                wholeUrl.append("website");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }

            object = (String) parameterMap.get("username");
            if (!StringUtils.isBlank(object)) {
                // username
                sbKey.append("");// sbKey.append(object)
                // wholeUrl.append("username");
                // wholeUrl.append(UtilConstants.ASSIGNMENT);
                // wholeUrl.append("");
                // wholeUrl.append(UtilConstants.LOGICAL_AND);
                wholeUrl.append("uppername");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get("begintime");// date format must be

            if (!StringUtils.isBlank(object)) {
                if (platformId.contains("updatebbin")) {
                    wholeUrl.append("start_date");
                    wholeUrl.append(UtilConstants.ASSIGNMENT);
                    wholeUrl.append(object.substring(0, 10));
                    wholeUrl.append(UtilConstants.LOGICAL_AND);
                    wholeUrl.append("end_date");
                    wholeUrl.append(UtilConstants.ASSIGNMENT);
                    wholeUrl.append(object.substring(0, 10));
                    wholeUrl.append(UtilConstants.LOGICAL_AND);
                } else {
                    wholeUrl.append("rounddate");
                    wholeUrl.append(UtilConstants.ASSIGNMENT);
                    wholeUrl.append(object.substring(0, 10));
                    wholeUrl.append(UtilConstants.LOGICAL_AND);
                }
            }

            //added by Span 2016-03-21
            String gameCode = (String) parameterMap.get("gameCode"); // TTG ，MG ，RGS ，BETSOFT，VMG 此参数标识
            if (StringUtils.isNotBlank(gameCode)) {
                wholeUrl.append("gameCode");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(gameCode);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }

            object = (String) parameterMap.get("begintime");// date format must be
            // "yyyy-MM-dd HH:mm:ss"
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("starttime");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object.substring(11, 19));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get("endtime");// date format must be
            // "yyyy-MM-dd HH:mm:ss"
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("endtime");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object.substring(11, 19));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get("gamekind");
            if (!StringUtils.isBlank(object)) {
                // gamekind
                // sbKey.append(object);//edit by edwin on 20130629
                wholeUrl.append("gamekind");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get("subgamekind");
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("subgamekind");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            } else {
                wholeUrl.append("subgamekind");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append("1");
                wholeUrl.append(UtilConstants.LOGICAL_AND);

            }
            object = (String) parameterMap.get("productId");
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("productId");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }

            // KeyB
            if (UtilConstants.ORDERS_BLM_BBIN.equals(platformId) || UtilConstants.ORDERS_BTT_UPDATE_BBIN.equals(platformId)) {
                // BLM KeyB
                sbKey.append(UtilConstants.ORDER_KEYB_4BLM);
            } else if (UtilConstants.ORDERS_MT_BBIN.equals(platformId) || UtilConstants.ORDERS_LB_UPDATE_BBIN.equals(platformId)) {
                // MT KeyB
                sbKey.append(UtilConstants.ORDER_KEYB_4MT);
            } else if (UtilConstants.ORDERS_ZL_BBIN.equals(platformId)
                    || UtilConstants.ORDERS_LL_BBIN.equals(platformId)
                    || UtilConstants.ORDERS_HJHA_BBIN.equals(platformId)
                    || UtilConstants.ORDERS_YJ_UPDATE_BBIN.equals(platformId)
                    || UtilConstants.ORDERS_WH_BBIN.equals(platformId)
                    || UtilConstants.ORDERS_E02_BBIN.equals(platformId)
                    || UtilConstants.ORDERS_E03_BBIN.equals(platformId)
                    || UtilConstants.ORDERS_E04_BBIN.equals(platformId)
                    || UtilConstants.ORDERS_B01_BBIN.equals(platformId)
                    || UtilConstants.ORDERS_HWX_BBIN.equals(platformId)
                    || UtilConstants.ORDERS_KB_BBIN.equals(platformId)
                    || UtilConstants.ORDERS_B79_BBIN.equals(platformId)) {
                // YJ KeyB
                sbKey.append(UtilConstants.ORDER_KEYB_4YJ);
            } else {
                // HJ KeyB
                sbKey.append(UtilConstants.ORDER_KEYB_4HJ);
            }
            // sbKey.append("gsjies83"); //MT
            object = (String) parameterMap.get("gametype");
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("gametype");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get("model");
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("model");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get("page");
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("page");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get("num");
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("pagelimit");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get("sort");
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("sort");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get("password");
            if (!StringUtils.isBlank(object)) {
                // password
                // sbKey.append(object);//edit by edwin on 20130629
                wholeUrl.append("password");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }

            // YYYYMMDD
            sbKey.append(ToolUtil.getUsEasternTime(new Date(), DateUtil.C_DATE_PATTON_YYYYMMDD));
            // MD5(target + username + gamekind + KeyB + password + website + YYYYMMDD)
            // MD5(website + username + KeyB + YYYYMMDD) edit by edwin on 20130629
            MD5KeyStr = MD5.MD5Encode(sbKey.toString());
            // append key
            wholeUrl.append(UtilConstants.ORDER_KEY);
            wholeUrl.append(UtilConstants.ASSIGNMENT);
            if (UtilConstants.ORDERS_BLM_BBIN.equals(platformId) || UtilConstants.ORDERS_BTT_UPDATE_BBIN.equals(platformId)) {
                // BLM KeyB
                wholeUrl.append(UtilConstants.ORDER_4CHARACTERS_BTT_A + MD5KeyStr + UtilConstants.ORDER_2CHARACTERS_BTT_C);
            } else if (UtilConstants.ORDERS_MT_BBIN.equals(platformId) || UtilConstants.ORDERS_LB_UPDATE_BBIN.equals(platformId)) {
                // MT KeyB
                wholeUrl.append(UtilConstants.ORDER_9CHARACTERS_LB_A + MD5KeyStr + UtilConstants.ORDER_3CHARACTERS_LB_C);
            } else if (UtilConstants.ORDERS_ZL_BBIN.equals(platformId)
                    || UtilConstants.ORDERS_LL_BBIN.equals(platformId)
                    || UtilConstants.ORDERS_HJHA_BBIN.equals(platformId)
                    || UtilConstants.ORDERS_YJ_UPDATE_BBIN.equals(platformId)
                    || UtilConstants.ORDERS_E02_BBIN.equals(platformId)
                    || UtilConstants.ORDERS_E03_BBIN.equals(platformId)
                    || UtilConstants.ORDERS_E04_BBIN.equals(platformId)
                    || UtilConstants.ORDERS_B01_BBIN.equals(platformId)
                    || UtilConstants.ORDERS_WH_BBIN.equals(platformId)
                    || UtilConstants.ORDERS_HWX_BBIN.equals(platformId)
                    || UtilConstants.ORDERS_KB_BBIN.equals(platformId)
                    || UtilConstants.ORDERS_B79_BBIN.equals(platformId)) {
                // YJ KeyB
                wholeUrl.append(UtilConstants.ORDER_8CHARACTERS_YJ_A + MD5KeyStr + UtilConstants.ORDER_3CHARACTERS_YJ_C);
            } else {
                // HJ KeyB
                wholeUrl.append(UtilConstants.ORDER_2CHARACTERS_HJ_A + MD5KeyStr + UtilConstants.ORDER_1CHARACTERS_HJ_C);
            }

        } catch (Exception ex) {
            log.error("UrlGeneratorUtil generateUrlForBBINOrderApi error:" + ex.getMessage(), ex);
        }
        log.info("platform=" + platformId + ",URL= " + wholeUrl);
        return wholeUrl.toString();
    }


    /**
     * @param parameterMap
     * @param baseUrl
     * @param encoding
     * @return String
     * @throws
     */
    public static String generateUrlForCQ9OrderApi(Map<String, Object> parameterMap, String baseUrl, String encoding) {
        String MD5KeyStr = null;
        String object = null;
        // construct URL
        StringBuffer wholeUrl = new StringBuffer(baseUrl);
        // according to baseUrl,add prefix for URL
        if (baseUrl.indexOf(UtilConstants.QUESTION_MARK) == -1) {
            wholeUrl.append(UtilConstants.QUESTION_MARK);
        } else {
            wholeUrl.append(UtilConstants.LOGICAL_AND);
        }
        try {
            object = (String) parameterMap.get(UtilConstants.ORDER_BEGIN_TIME);
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append(UtilConstants.ORDER_BBIN_STATTIME);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            // endTime
            object = (String) parameterMap.get(UtilConstants.ORDER_END_TIME);
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append(UtilConstants.ORDER_BBIN_ENDTIME);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            //added by Span 2016-03-21
            String gameCode = (String) parameterMap.get(UtilConstants.ORDER_GAME_CODE); // TTG ，MG ，RGS ，BETSOFT，VMG 此参数标识
            if (StringUtils.isNotBlank(gameCode)) {
                wholeUrl.append(UtilConstants.ORDER_GAME_CODE);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(gameCode);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }

            object = (String) parameterMap.get(UtilConstants.GLOBAL_PRODUCTID_KEY);
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append(UtilConstants.GLOBAL_PRODUCTID_KEY);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get(UtilConstants.ORDER_PAGE);
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append(UtilConstants.ORDER_PAGE);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get(UtilConstants.ORDER_PAGE_NUMBER);
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("pagelimit");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            // append key
            wholeUrl.append(UtilConstants.ORDER_KEY);
            wholeUrl.append(UtilConstants.ASSIGNMENT);
            wholeUrl.append((String) parameterMap.get(UtilConstants.ORDER_BBIN_PASSWORD));

        } catch (Exception ex) {
            log.error("UrlGeneratorUtil generateUrlForCQ9OrderApi error:" + ex.getMessage(), ex);
        }
        log.info("==CQ9+ORDER++URL= " + wholeUrl);
        return wholeUrl.toString();
    }

    /**
     * @param parameterMap
     * @param baseUrl
     * @param encoding
     * @return String
     * @throws
     */
    public static String generateUrlForCGOrderApi(Map<String, Object> parameterMap, String baseUrl,String encoding) {
        try {
            String strAllParam = null;
            String[] arrSplit = null;
            baseUrl = baseUrl.trim();
            arrSplit = baseUrl.split("[?]");
            String url = arrSplit[0];
            String params = arrSplit[1];
            String[] strings = params.split("&");
            for (String s : strings){
                String[] str = s.split("=");
                parameterMap.put(str[0],str[1]);
            }
            baseUrl = url;
        } catch (Exception ex) {
            log.error("UrlGeneratorUtil generateUrlForCGOrderApi baseUrl-{},parameterMap-{},error:{}",baseUrl,parameterMap,ex);
        }
        log.info("==CG+ORDER+URL-{},parameterMap-{}",baseUrl,parameterMap);
        return baseUrl;
    }

    /**
     * @param parameterMap
     * @param baseUrl
     * @param encoding
     * @return String
     * @throws
     */
    public static String generateUrlForCOrderApi(Map<String, Object> parameterMap, String baseUrl, String encoding) {
        String MD5KeyStr = null;
        String object = null;
        // construct URL
        StringBuffer wholeUrl = new StringBuffer(baseUrl);
        // according to baseUrl,add prefix for URL
        if (baseUrl.indexOf(UtilConstants.QUESTION_MARK) == -1) {
            wholeUrl.append(UtilConstants.QUESTION_MARK);
        } else {
            wholeUrl.append(UtilConstants.LOGICAL_AND);
        }
        try {
            object = (String) parameterMap.get(UtilConstants.ORDER_START_TIME);
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append(UtilConstants.ORDER_START_TIME);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            // endTime
            object = (String) parameterMap.get(UtilConstants.ORDER_END_TIME);
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append(UtilConstants.ORDER_END_TIME);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            //added by Span 2016-03-21
            String gameCode = (String) parameterMap.get(UtilConstants.ORDER_GAME_CODE); // TTG ，MG ，RGS ，BETSOFT，VMG 此参数标识
            if (StringUtils.isNotBlank(gameCode)) {
                wholeUrl.append(UtilConstants.ORDER_GAME_CODE);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(gameCode);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }

            object = (String) parameterMap.get(UtilConstants.GLOBAL_PRODUCTID_KEY);
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append(UtilConstants.GLOBAL_PRODUCTID_KEY);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get(UtilConstants.ORDER_PAGE);
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append(UtilConstants.ORDER_PAGE);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get(UtilConstants.ORDER_PAGE_NUMBER);
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("pagelimit");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get(UtilConstants.ORDER_WALLET);
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("pagelimit");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get(UtilConstants.ORDER_EV_MODE);
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("pagelimit");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            // append key
            wholeUrl.append(UtilConstants.ORDER_KEY);
            wholeUrl.append(UtilConstants.ASSIGNMENT);
            wholeUrl.append((String) parameterMap.get(UtilConstants.ORDER_CG_PASSWORD));

        } catch (Exception ex) {
            log.error("UrlGeneratorUtil generateUrlForCGOrderApi error:" + ex.getMessage(), ex);
        }
        log.info("==CG+ORDER++URL= " + wholeUrl);
        return wholeUrl.toString();
    }

    /**
     * (BaGame Result)Construct key and URL,and then return whole URL string.
     *
     * @param parameterMap
     * @param baseUrl
     * @param encoding
     * @return
     * @throws UnsupportedEncodingException
     */
    public static String generateUrlForBaGameResultApi(Map<String, Object> parameterMap, String baseUrl, String platformId, String encoding) {
        StringBuffer sbKey = new StringBuffer();
        StringBuffer wholeUrl = new StringBuffer(baseUrl);
        String object = null;
        // according to baseUrl,add prefix for URL
        if (baseUrl.indexOf(UtilConstants.QUESTION_MARK) == -1) {
            wholeUrl.append(UtilConstants.QUESTION_MARK);
        } else {
            wholeUrl.append(UtilConstants.LOGICAL_AND);
        }
        try {
            // gmcode
            object = (String) parameterMap.get(UtilConstants.GAME_RESULT_GM_CODE);
            if (!StringUtils.isBlank(object)) {
                sbKey.append(object);
                wholeUrl.append(UtilConstants.GAME_RESULT_GM_CODE);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            // beginTime
            object = (String) parameterMap.get(UtilConstants.GAME_RESULT_BEGIN_TIME);
            if (!StringUtils.isBlank(object)) {
                sbKey.append(object);
                wholeUrl.append(UtilConstants.GAME_RESULT_BEGIN_TIME);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            // endTime
            object = (String) parameterMap.get(UtilConstants.GAME_RESULT_END_TIME);
            if (!StringUtils.isBlank(object)) {
                sbKey.append(object);
                wholeUrl.append(UtilConstants.GAME_RESULT_END_TIME);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            // page
            object = (String) parameterMap.get(UtilConstants.GAME_RESULT_PAGE);
            if (!StringUtils.isBlank(object)) {
                sbKey.append(object);
                wholeUrl.append(UtilConstants.GAME_RESULT_PAGE);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            // num
            object = (String) parameterMap.get(UtilConstants.GAME_RESULT_PAGE_NUMBER);
            if (!StringUtils.isBlank(object)) {
                sbKey.append(object);
                wholeUrl.append(UtilConstants.GAME_RESULT_PAGE_NUMBER);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            // Add by Alex on 2012-03-19 -begin
            /*
             * if(UtilConstants.GAMERESULT_DSP.equalsIgnoreCase(platformId)){ sbKey.append(UtilConstants.SUFFIX); }else
             * if(UtilConstants.GAMERESULT_K8.equalsIgnoreCase(platformId)){ sbKey.append(UtilConstants.SUFFIX_K8); }else{
             * sbKey.append(UtilConstants.SUFFIX_DYJ); }
             */
            if (!UtilConstants.GAMERESULT_K8.equalsIgnoreCase(platformId)) {
                sbKey.append(UtilConstants.SUFFIX);
            } else {
                sbKey.append(UtilConstants.SUFFIX_K8);
            }
            // Add by Alex on 2012-03-19 -end

            wholeUrl.append(UtilConstants.GAME_RESULT_KEY);
            wholeUrl.append(UtilConstants.ASSIGNMENT);
            // Get key by MD5
            String MD5KeyStr = MD5.MD5Encode(sbKey.toString());
            wholeUrl.append(URLEncoder.encode(MD5KeyStr, encoding));
        } catch (UnsupportedEncodingException ex) {
            log.error("UrlGeneratorUtil generateUrlForBaGameResultApi error:" + ex.getMessage(), ex);
        }
        return wholeUrl.toString();
    }

    /**
     * (Account Transfer)Construct key and URL,and then return whole URL string. key = A+B+C A = 3 freewill characters. B = MD5(target + feas!#% +
     * agcode +website +action + YYYYMMDD) C = 7 freewill characters.
     *
     * @param parameterMap
     * @param baseUrl
     * @param encoding
     * @return String
     * @throws UnsupportedEncodingException
     */
    public static String generateUrlForAccountTransferDspApi(Map<String, Object> parameterMap, String baseUrl, String platformId, String encoding) {
        String object = null;
        // construct key
        StringBuffer bKey = new StringBuffer();
        // construct URL
        StringBuffer wholeUrl = new StringBuffer(baseUrl);
        String website = null;
        // according to baseUrl,add prefix for URL
        if (baseUrl.indexOf(UtilConstants.QUESTION_MARK) == -1) {
            wholeUrl.append(UtilConstants.QUESTION_MARK);
        } else {
            wholeUrl.append(UtilConstants.LOGICAL_AND);
        }
        website = (String) parameterMap.get(UtilConstants.ACCOUNT_TRANSFER_PLATFORMID);

        try {
            if (!StringUtils.isBlank(website)) {
                wholeUrl.append(UtilConstants.ACCOUNT_TRANSFER_WEBSITE);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(website, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get(UtilConstants.ACCOUNT_TRANSFER_LOGINNAME);
            if (!StringUtils.isBlank(object)) {
                bKey.append(object);
                wholeUrl.append(UtilConstants.ACCOUNT_TRANSFER_LOGINNAME);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            // Add by Alex on 2012-03-19 -begin
            /*
             * if(UtilConstants.ACCOUNT_TRANSFER_DSP.equalsIgnoreCase(platformId)){ bKey.append(UtilConstants.SUFFIX); }else
             * if(UtilConstants.ACCOUNT_TRANSFER_K8.equalsIgnoreCase(platformId)){ bKey.append(UtilConstants.SUFFIX_K8); }else{
             * bKey.append(UtilConstants.SUFFIX_DYJ); }
             */
            if (!UtilConstants.ACCOUNT_TRANSFER_K8.equalsIgnoreCase(platformId)) {
                bKey.append(UtilConstants.SUFFIX);
            } else {
                bKey.append(UtilConstants.SUFFIX_K8);
            }
            // Add by Alex on 2012-03-19 -end

            object = (String) parameterMap.get(UtilConstants.ACCOUNT_TRANSFER_AGCODE);
            if (!StringUtils.isBlank(object)) {
                bKey.append(object);
                wholeUrl.append(UtilConstants.ACCOUNT_TRANSFER_AGCODE);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            // Add the platform id(dsp,dsp_new,old_dyj and keno8 so on)
            bKey.append(website);

            object = (String) parameterMap.get(UtilConstants.ACCOUNT_TRANSFER_ACTION);
            if (!StringUtils.isBlank(object)) {
                bKey.append(object);
                wholeUrl.append(UtilConstants.ACCOUNT_TRANSFER_ACTION);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get(UtilConstants.ACCOUNT_TRANSFER_BILLNO);
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append(UtilConstants.ACCOUNT_TRANSFER_BILLNO);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get(UtilConstants.ORDER_BEGIN_TIME);
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append(UtilConstants.ACCOUNT_TRANSFER_BEGINTIME);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get(UtilConstants.ORDER_END_TIME);
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append(UtilConstants.ACCOUNT_TRANSFER_ENDTIME);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get(UtilConstants.ACCOUNT_TRANSFER_PRODUCTTYPE);
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append(UtilConstants.ACCOUNT_TRANSFER_PRODUCTTYPE);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get(UtilConstants.ACCOUNT_TRANSFER_PAGESIZE);
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append(UtilConstants.ACCOUNT_TRANSFER_PAGESIZE);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get(UtilConstants.ACCOUNT_TRANSFER_PAGENUM);
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append(UtilConstants.ACCOUNT_TRANSFER_PAGENUM);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            // US/Eastern time.
            // String mgt5 = DateUtil.formatDate2Str(new Date(), DateUtil.C_DATE_PATTON_YYYYMMDD);
            // String mgt5 = ToolUtil.getUsEasternTime(new Date(), DateUtil.C_DATE_PATTON_YYYYMMDD);
            String mgt5 = null;
            if (!UtilConstants.ACCOUNT_TRANSFER_K8.equalsIgnoreCase(platformId)) {
                mgt5 = ToolUtil.getUsEasternTime(new Date(), DateUtil.C_DATE_PATTON_YYYYMMDD);
            } else {
                mgt5 = DateUtil.formatDate2Str(new Date(), DateUtil.C_DATE_PATTON_YYYYMMDD);
            }
            bKey.append(mgt5);

            wholeUrl.append(UtilConstants.ORDER_KEY);
            wholeUrl.append(UtilConstants.ASSIGNMENT);
            // Get key by MD5
            String md5bKey = MD5.MD5Encode(bKey.toString());
            String abcKey = UtilConstants.ACCOUNT_TRANSFER_3CHARACTERS + md5bKey + UtilConstants.ACCOUNT_TRANSFER_7CHARACTERS;
            wholeUrl.append(URLEncoder.encode(abcKey, encoding));
        } catch (UnsupportedEncodingException ex) {
            log.error("UrlGeneratorUtil generateUrlForAccountTransferDspApi error:" + ex.getMessage(), ex);
        }
        return wholeUrl.toString();
    }

    /**
     * (Account Transfer)Construct key and URL,and then return whole URL string. key = A+B+C A = 3 freewill characters. B = MD5(target + username+
     * gsjies83 + password + website+ YYYYMMDD) C = 7 freewill characters.
     *
     * @param parameterMap
     * @param baseUrl
     * @param encoding
     * @return String
     * @throws UnsupportedEncodingException
     */
    public static String generateUrlForAccountTransferBBINApi(Map<String, Object> parameterMap, String baseUrl, String platformId, String encoding) {
        String object = null;
        // construct key
        StringBuffer bKey = new StringBuffer();
        // construct URL
        StringBuffer wholeUrl = new StringBuffer(baseUrl);
        // according to baseUrl,add prefix for URL
        if (baseUrl.indexOf(UtilConstants.QUESTION_MARK) == -1) {
            wholeUrl.append(UtilConstants.QUESTION_MARK);
        } else {
            wholeUrl.append(UtilConstants.LOGICAL_AND);
        }
        try {
            object = (String) parameterMap.get(UtilConstants.ACCOUNT_TRANSFER_LOGINNAME);
            if (!StringUtils.isBlank(object)) {
                // bKey.append(object);//edit by edwin on 20130629
                wholeUrl.append(UtilConstants.ACCOUNT_TRANSFER_LOGINNAME);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get(UtilConstants.ACCOUNT_TRANSFER_WEBSITE);
            if (!StringUtils.isBlank(object)) {
                bKey.append(object);
                wholeUrl.append(UtilConstants.ACCOUNT_TRANSFER_WEBSITE);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get(UtilConstants.ACCOUNT_TRANSFER_USERNAME);
            if (!StringUtils.isBlank(object)) {
                bKey.append("");
                wholeUrl.append("uppername");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            //gmcode
            if (isIOMGame(parameterMap)
                    || platformId.equals(UtilConstants.ACCOUNT_TRANSFER_VMG)
                    || platformId.equals(UtilConstants.ACCOUNT_TRANSFER_RGS)
                    || platformId.equals(UtilConstants.ACCOUNT_TRANSFER_MG_VIP)
                    || platformId.equals(UtilConstants.ACCOUNT_TRANSFER_AMAYA_VIP_FCLRC)
                    || platformId.equals(UtilConstants.ACCOUNT_TRANSFER_SBT)
                    || platformId.equals(UtilConstants.ACCOUNT_TRANSFER_PNG)
                    || platformId.equals(UtilConstants.ACCOUNT_TRANSFER_NETENT)
                    || platformId.equals(UtilConstants.ACCOUNT_TRANSFER_PPG)
                    || platformId.equals(UtilConstants.ACCOUNT_TRANSFER_CQ9)
                    || platformId.equals(UtilConstants.ACCOUNT_TRANSFER_BSG_VIP)
                    || platformId.equals(UtilConstants.ACCOUNT_TRANSFER_YSB)
                    || platformId.equals(UtilConstants.ACCOUNT_TRANSFER_NB)) {
                String gameCode = (String) parameterMap.get("gameCode");
                if (StringUtils.isNotBlank(gameCode)) {
                    wholeUrl.append(UtilConstants.ORDER_GAME_CODE);
                    wholeUrl.append(UtilConstants.ASSIGNMENT);
                    wholeUrl.append(gameCode);
                    wholeUrl.append(UtilConstants.LOGICAL_AND);
                }
            }


            // use in accountTransfer paltformId=027(amaya_fclrc) 033(amaya_uk) 031(onewprks_fclrc) 034(onewprks_uk)
            if (platformId.equals(UtilConstants.ACCOUNT_TRANSFER_MG)
                    || platformId.equals(UtilConstants.ACCOUNT_TRANSFER_RGS)
                    || platformId.equals(UtilConstants.ACCOUNT_TRANSFER_SHABA_UK)
                    || platformId.equals(UtilConstants.ACCOUNT_TRANSFER_SHABA_FCLRC)
                    || isIOMGame(parameterMap)
                    || platformId.equals(UtilConstants.ACCOUNT_TRANSFER_AMAYA_VIP_FCLRC)
                    || platformId.equals(UtilConstants.ACCOUNT_TRANSFER_SBT)
                    || platformId.equals(UtilConstants.ACCOUNT_TRANSFER_PNG)
                    || platformId.equals(UtilConstants.ACCOUNT_TRANSFER_NETENT)
                    || platformId.equals(UtilConstants.ACCOUNT_TRANSFER_PPG)
                    || platformId.equals(UtilConstants.ACCOUNT_TRANSFER_CQ9)
                    || platformId.equals(UtilConstants.ACCOUNT_TRANSFER_MG_VIP)
                    || platformId.equals(UtilConstants.ACCOUNT_TRANSFER_YSB)
                    || platformId.equals(UtilConstants.ACCOUNT_TRANSFER_NB)) {
                wholeUrl.append("gamekind");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                String gameKind = "";
                if (platformId.equals(UtilConstants.ACCOUNT_TRANSFER_AMAYA_FCLRC)
                        || platformId.equals(UtilConstants.ACCOUNT_TRANSFER_MG)
                        || platformId.equals(UtilConstants.ACCOUNT_TRANSFER_AMAYA_VIP_FCLRC)
                        || platformId.equals(UtilConstants.ACCOUNT_TRANSFER_MG_VIP)) {
                    gameKind = "3";
                } else if (platformId.equals(UtilConstants.ACCOUNT_TRANSFER_SHABA_UK)) {
                    gameKind = "2";
                } else if (platformId.equals(UtilConstants.ACCOUNT_TRANSFER_SHABA_FCLRC)) {
                    gameKind = "1";
                }
                wholeUrl.append(gameKind);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
                object = (String) parameterMap.get("productId");
                if (!StringUtils.isBlank(object)) {
                    wholeUrl.append("productId");
                    wholeUrl.append(UtilConstants.ASSIGNMENT);
                    wholeUrl.append(object);
                    wholeUrl.append(UtilConstants.LOGICAL_AND);
                }
            }
            // KeyB
            if (UtilConstants.ACCOUNT_TRANSFER_BBIN_BLM.equals(platformId)) {
                // BLM KeyB
                bKey.append(UtilConstants.TRAN_KEYB_4BLM);
            } else if (UtilConstants.ACCOUNT_TRANSFER_BBIN_MT.equals(platformId)) {
                // MT KeyB
                bKey.append(UtilConstants.TRAN_KEYB_4MT);
            } else if (UtilConstants.ACCOUNT_TRANSFER_BBIN_ZL.equals(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_BBIN_LL.equals(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_BBIN_HJHA.equals(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_BBIN_E02.equals(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_BBIN_E03.equals(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_BBIN_E04.equals(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_BBIN_B01.equals(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_BBIN_WH.equals(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_BBIN_HWX.equals(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_BBIN_KB.equals(platformId)
                    ) {
                // YJ KeyB
                bKey.append(UtilConstants.TRAN_KEYB_4YJ);
            } else {
                // HJ KeyB
                bKey.append(UtilConstants.TRAN_KEYB_4HJ);
            }
            object = (String) parameterMap.get(UtilConstants.ACCOUNT_TRANSFER_PASSWORD);
            if (!StringUtils.isBlank(object)) {
                // bKey.append(object);//edit by edwin on 20130629
                wholeUrl.append(UtilConstants.ACCOUNT_TRANSFER_PASSWORD);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }

            object = (String) parameterMap.get(UtilConstants.ACCOUNT_TRANSFER_BILLNO);
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append(UtilConstants.ACCOUNT_TRANSFER_BILLNO);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get(UtilConstants.ACCOUNT_TRANSFER_TRANSTYPE);
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append(UtilConstants.ACCOUNT_TRANSFER_TRANSTYPE);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get(UtilConstants.ACCOUNT_TRANSFER_PAGESIZE);
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append(UtilConstants.ACCOUNT_TRANSFER_PAGESIEZE_BBIN);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get(UtilConstants.ACCOUNT_TRANSFER_PAGENUM);
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append(UtilConstants.ACCOUNT_TRANSFER_PAGENUM);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }

            object = (String) parameterMap.get(UtilConstants.ORDER_BEGIN_TIME);// date format must
            // be
            // "yyyy-MM-dd HH:mm:ss"
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append(UtilConstants.ACCOUNT_TRANSFER_BEGINTIME);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object.substring(0, 10));
                wholeUrl.append(UtilConstants.LOGICAL_AND);

                wholeUrl.append(UtilConstants.ACCOUNT_TRANSFER_BEGINTIME_HHMISS);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object.substring(11, 19));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get(UtilConstants.ORDER_END_TIME);// date format must be
            // "yyyy-MM-dd HH:mm:ss"
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append(UtilConstants.ACCOUNT_TRANSFER_ENDTIME);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object.substring(0, 10));
                wholeUrl.append(UtilConstants.LOGICAL_AND);

                wholeUrl.append(UtilConstants.ACCOUNT_TRANSFER_ENDTIME_HHMISS);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object.substring(11, 19));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }


            // US/Eastern time.
            // String mgt5 = DateUtil.formatDate2Str(new Date(), DateUtil.C_DATE_PATTON_YYYYMMDD);
            String mgt5 = ToolUtil.getUsEasternTime(new Date(), DateUtil.C_DATE_PATTON_YYYYMMDD);
            bKey.append(mgt5);

            wholeUrl.append(UtilConstants.ORDER_KEY);
            wholeUrl.append(UtilConstants.ASSIGNMENT);
            // Get key by MD5
            String md5bKey = MD5.MD5Encode(bKey.toString());
            if (UtilConstants.ACCOUNT_TRANSFER_BBIN_BLM.equals(platformId)) {
                // BLM KeyB
                wholeUrl.append(UtilConstants.ACCOUNT_TRANSFER_9CHARACTERS_BTT_A + md5bKey + UtilConstants.ACCOUNT_TRANSFER_5CHARACTERS_BTT_C);
            } else if (UtilConstants.ACCOUNT_TRANSFER_BBIN_MT.equals(platformId)) {
                // MT KeyB
                wholeUrl.append(UtilConstants.ACCOUNT_TRANSFER_8CHARACTERS_LB_A + md5bKey + UtilConstants.ACCOUNT_TRANSFER_7CHARACTERS_LB_C);
            } else if (UtilConstants.ACCOUNT_TRANSFER_BBIN_ZL.equals(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_BBIN_LL.equals(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_BBIN_HJHA.equals(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_BBIN_E02.equals(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_BBIN_E03.equals(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_BBIN_E04.equals(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_BBIN_B01.equals(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_BBIN_WH.equals(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_BBIN_HWX.equals(platformId)
                    || UtilConstants.ACCOUNT_TRANSFER_BBIN_KB.equals(platformId)) {
                // YJ KeyB
                wholeUrl.append(UtilConstants.ACCOUNT_TRANSFER_5CHARACTERS_YJ_A + md5bKey + UtilConstants.ACCOUNT_TRANSFER_8CHARACTERS_YJ_C);
            } else {

                // HJ KeyB
                wholeUrl.append(UtilConstants.ACCOUNT_TRANSFER_3CHARACTERS_HJ_A + md5bKey + UtilConstants.ACCOUNT_TRANSFER_6CHARACTERS_HJ_C);
            }

        } catch (Exception ex) {
            log.error("UrlGeneratorUtil generateUrlForAccountTransferBBINApi error:" + ex.getMessage(), ex);
        }
        return wholeUrl.toString();
    }

    public static String generateUrlForTransferBBINPro(Map<String, Object> parameterMap, String baseUrl, String platformId){
        String object = null;
        StringBuffer bKey = new StringBuffer();
        StringBuffer wholeUrl = new StringBuffer(baseUrl);

        if (baseUrl.indexOf(UtilConstants.QUESTION_MARK) == -1) {
            wholeUrl.append(UtilConstants.QUESTION_MARK);
        } else {
            wholeUrl.append(UtilConstants.LOGICAL_AND);
        }

        try {
            object = (String) parameterMap.get(UtilConstants.ACCOUNT_TRANSFER_WEBSITE);
            if (!StringUtils.isBlank(object)) {
                bKey.append(object);
                wholeUrl.append(UtilConstants.ACCOUNT_TRANSFER_WEBSITE);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }

            if(UtilConstants.ACCOUNT_TRANSFER_BBIN_PRO.equals(platformId)){
                bKey.append(UtilConstants.TRAN_KEYB_4YJ);
            }

            object = (String) parameterMap.get(UtilConstants.ORDER_BEGIN_TIME);

            if (!StringUtils.isBlank(object)) {
                wholeUrl.append(UtilConstants.ACCOUNT_TRANSFER_ROUNDDATE);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object.substring(0, 10));
                wholeUrl.append(UtilConstants.LOGICAL_AND);

                wholeUrl.append(UtilConstants.ACCOUNT_TRANSFER_START_TIME);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object.substring(11, 19));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }

            object = (String) parameterMap.get(UtilConstants.ORDER_END_TIME);

            if (!StringUtils.isBlank(object)) {
                wholeUrl.append(UtilConstants.ACCOUNT_TRANSFER_END_TIME);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object.substring(11, 19));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }

            String mgt5 = ToolUtil.getUsEasternTime(new Date(), DateUtil.C_DATE_PATTON_YYYYMMDD);
            bKey.append(mgt5);

            wholeUrl.append(UtilConstants.ORDER_KEY);
            wholeUrl.append(UtilConstants.ASSIGNMENT);

            String md5bKey = MD5.MD5Encode(bKey.toString());

            wholeUrl.append(UtilConstants.ACCOUNT_TRANSFER_5CHARACTERS_YJ_A + md5bKey + UtilConstants.ACCOUNT_TRANSFER_8CHARACTERS_YJ_C);

        }catch (Exception ex) {
            log.error("UrlGeneratorUtil generateUrlForAccountTransferBBINApi error:{}",ex.getMessage(), ex);
        }

        return wholeUrl.toString();
    }
    /**
     * Generate URL for A06 HG credit logs key = MD5( begintime + endtime + order + page + num + feas!#%)
     *
     * @param parameterMap
     * @param baseUrl
     * @param encoding
     * @return String
     */
    public static String generateUrlForA06Hogaming(Map<String, Object> parameterMap, String baseUrl, String encoding) {
        StringBuffer sbKey = new StringBuffer();
        // construct URL
        StringBuffer wholeUrl = new StringBuffer(baseUrl);
        // according to baseUrl,add prefix for URL
        if (baseUrl.indexOf(UtilConstants.QUESTION_MARK) == -1) {
            wholeUrl.append(UtilConstants.QUESTION_MARK);
        } else {
            wholeUrl.append(UtilConstants.LOGICAL_AND);
        }
        try {
            // productid
            String object = (String) parameterMap.get("productId");
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("productId");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
                sbKey.append(object.trim());
            }
            // begintime
            object = (String) parameterMap.get("begintime");
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("startDate");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
                sbKey.append(object.trim());
            }
            // endtime
            object = (String) parameterMap.get("endtime");
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("endDate");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
                sbKey.append(object);
            }
            // page
            object = (String) parameterMap.get("page");
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("pageNum");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
                sbKey.append(object.trim());
            }
            // num
            object = (String) parameterMap.get("num");
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("pageSize");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
                sbKey.append(object.trim());
            }
            sbKey.append(UtilConstants.SUFFIX);
        } catch (Exception e) {
            log.error("UrlGeneratorUtil generateUrlForA06Hogaming error:" + e.getMessage(), e);
        }
        String keyString = MD5.MD5Encode(sbKey.toString());
        wholeUrl.append("key");
        wholeUrl.append(UtilConstants.ASSIGNMENT);
        wholeUrl.append(keyString);
        return wholeUrl.toString();
    }

    /**
     * AGIN url params
     *
     * @param parameterMap
     * @param baseUrl
     * @param encoding
     * @return
     * @author pacy.g
     */
    public static String generateUrlAGINForOrderApi(Map<String, Object> parameterMap, String baseUrl, String encoding) {
        StringBuffer sbKey = new StringBuffer();
        // construct URL
        StringBuffer wholeUrl = new StringBuffer(baseUrl);
        // according to baseUrl,add prefix for URL
        if (baseUrl.indexOf(UtilConstants.QUESTION_MARK) == -1) {
            wholeUrl.append(UtilConstants.QUESTION_MARK);
        } else {
            wholeUrl.append(UtilConstants.LOGICAL_AND);
        }
        String platformId = (String) parameterMap.get(UtilConstants.GLOBAL_PLATFORMID_KEY);
        //?startdate=2015-04-16%2000:00:00&enddate=2015-04-16%2023:59:59&cagent=N67&page=1&perpage=1&transferType=IN,OUT,DONATEFEE
        try {
            // productid
            String object = (String) parameterMap.get("cagent");
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("cagent");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
                sbKey.append(object.trim());
            }
            object = (String) parameterMap.get("begintime");
            if (UtilConstants.ORDERS_AGIN_SPORT.equalsIgnoreCase(platformId)) {
                object = DateUtil.formatDate2Str(ToolUtil.transferCNEsternDateToUSEsternDate(DateUtil.formatStr2Date(object)));
            }
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("startdate");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                sbKey.append(object.trim());
                object = object.replaceAll(" ", "%20");
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            // endtime
            object = (String) parameterMap.get("endtime");
            if (UtilConstants.ORDERS_AGIN_SPORT.equalsIgnoreCase(platformId)) {
                object = DateUtil.formatDate2Str(ToolUtil.transferCNEsternDateToUSEsternDate(DateUtil.formatStr2Date(object)));
            }
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("enddate");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                sbKey.append(object);
                object = object.replaceAll(" ", "%20");
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);

            }
            // transferType 值取map中的action
            object = (String) parameterMap.get("action");
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("transferType");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
                sbKey.append(object);
            }
            int page = 1;//第一页
            // page
            object = (String) parameterMap.get("page");
            if (!StringUtils.isBlank(object)) {
                page = Integer.parseInt(object);
            }
            wholeUrl.append("page");
            wholeUrl.append(UtilConstants.ASSIGNMENT);
            wholeUrl.append(String.valueOf(page));
            wholeUrl.append(UtilConstants.LOGICAL_AND);
            sbKey.append(page);
            // num
            object = (String) parameterMap.get("num");
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("perpage");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
                sbKey.append(object.trim());
            }
        } catch (Exception e) {
            log.error("UrlGeneratorUtil generateUrlAGINForOrderApi error:" + e.getMessage(), e);
        }
        sbKey.append((String) parameterMap.get("mingmakey"));

        String keyString = MD5.MD5Encode(sbKey.toString());
        wholeUrl.append("key");
        wholeUrl.append(UtilConstants.ASSIGNMENT);
        wholeUrl.append(keyString);
        return wholeUrl.toString();
    }


    /**
     * AGIN游戏类型URL
     * AGIN url params
     *
     * @param parameterMap
     * @param baseUrl
     * @param encoding
     * @return
     * @author pacy.g
     */
    public static String generateComputerGameOrderApi(Map<String, Object> parameterMap, String baseUrl, String encoding) {
        StringBuffer sbKey = new StringBuffer();
        // construct URL
        StringBuffer wholeUrl = new StringBuffer(baseUrl);
        // according to baseUrl,add prefix for URL
        if (baseUrl.indexOf(UtilConstants.QUESTION_MARK) == -1) {
            wholeUrl.append(UtilConstants.QUESTION_MARK);
        } else {
            wholeUrl.append(UtilConstants.LOGICAL_AND);
        }
        String platformId = (String) parameterMap.get(UtilConstants.GLOBAL_PLATFORMID_KEY);
        //?startdate=2015-04-16%2000:00:00&enddate=2015-04-16%2023:59:59&cagent=N67&page=1&perpage=1&transferType=IN,OUT,DONATEFEE
        try {
            // productid
            String object = (String) parameterMap.get("cagent");
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("cagent");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
                sbKey.append(object.trim());
            }
            //开始时间
            object = (String) parameterMap.get("begintime");
            if (UtilConstants.ORDERS_AGIN_SPORT.equalsIgnoreCase(platformId)) {
                object = DateUtil.formatDate2Str(ToolUtil.transferCNEsternDateToUSEsternDate(DateUtil.formatStr2Date(object)));
            }
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("startdate");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                sbKey.append(object.trim());
                object = object.replaceAll(" ", "%20");
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            // 结束时间endtime
            object = (String) parameterMap.get("endtime");
            if (UtilConstants.ORDERS_AGIN_SPORT.equalsIgnoreCase(platformId)) {
                object = DateUtil.formatDate2Str(ToolUtil.transferCNEsternDateToUSEsternDate(DateUtil.formatStr2Date(object)));
            }
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("enddate");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                sbKey.append(object);
                object = object.replaceAll(" ", "%20");
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);

            }

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        sbKey.append((String) parameterMap.get("mingmakey"));

        String keyString = MD5.MD5Encode(sbKey.toString());
        wholeUrl.append("key");
        wholeUrl.append(UtilConstants.ASSIGNMENT);
        wholeUrl.append(keyString);
        return wholeUrl.toString();
    }

    /**
     * 构造BBIN捕鱼大师 BBIN捕鱼达人 BBIN彩票 注单数据请求URL
     * 这里aciton按BetTime 方式获取数据，跨天的，修改endTime为当天最后时分秒
     *
     * @param parameterMap
     * @param baseUrl
     * @param encoding
     * @return
     */
    public static String generateBBINBYDSUrl(Map<String, Object> parameterMap, String baseUrl, String encoding) {
        String MD5KeyStr = null;
        String object = null;
        String platformStr = (String) parameterMap.get(UtilConstants.GLOBAL_PLATFORMID_KEY);
        // construct key
        StringBuffer sbKey = new StringBuffer();
        // construct URL
        StringBuffer wholeUrl = new StringBuffer(baseUrl);
        // according to baseUrl,add prefix for URL
        if (baseUrl.indexOf(UtilConstants.QUESTION_MARK) == -1) {
            wholeUrl.append(UtilConstants.QUESTION_MARK);
        } else {
            wholeUrl.append(UtilConstants.LOGICAL_AND);
        }
        String beginDate = null, endDate = null, beginTime = null, endTime = null;
        try {
            object = (String) parameterMap.get("website");
            if (!StringUtils.isBlank(object)) {
                sbKey.append(object);
                wholeUrl.append("website");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get("action");
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("action");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get("username");
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("username");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            //上层帐号(action=BetTime时，需强制带入)
            object = (String) parameterMap.get("uppername");
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("uppername");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            /**
             * action为BetTime情况，处理时间跨天问题
             */
            // SimpleDateFormat simpleDate = new SimpleDateFormat(DateUtil.C_TIME_PATTON_DEFAULT);
            beginTime = (String) parameterMap.get("begintime");// date format must be
            //   beginTime=DateUtil.formatDate2Str(ToolUtil.transferCNEsternDateToUSEsternDate(simpleDate.parse(beginTime)),DateUtil.C_TIME_PATTON_DEFAULT);
            endTime = (String) parameterMap.get("endtime");// date format must be
            //   endTime=DateUtil.formatDate2Str(ToolUtil.transferCNEsternDateToUSEsternDate(simpleDate.parse(endTime)),DateUtil.C_TIME_PATTON_DEFAULT);
            beginDate = beginTime.substring(0, 10);
            endDate = endTime.substring(0, 10);
            String dateKey = "date";
            //若为BBIN彩票
            if (platformStr.equals(UtilConstants.BBIN_LOTTERY_ORDER)) {
                dateKey = "rounddate";
                object = (String) parameterMap.get(UtilConstants.ORDER_BBIN_GAMEKIND);
                wholeUrl.append("gamekind");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            if (beginTime.substring(11, 19).equals("23:59:59")) {
                SimpleDateFormat sdf = new SimpleDateFormat(DateUtil.C_TIME_PATTON_DEFAULT);
                Date initDate = sdf.parse(beginTime);
                String nowBeginTime = sdf.format(initDate.getTime() + 1000);//往前推进1秒，进入下一日
                Long fix = Long.parseLong((String) parameterMap.get("endSeconds")) - Long.parseLong((String) parameterMap.get("beginSeconds"));
                String nowEndTime = sdf.format(initDate.getTime() + fix);
                wholeUrl.append(dateKey);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(nowBeginTime.substring(0, 10));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
                wholeUrl.append("starttime");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(nowBeginTime.substring(11, 19));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
              /*  wholeUrl.append("end_date");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(nowEndTime.substring(0, 10));
                wholeUrl.append(UtilConstants.LOGICAL_AND);*/
                wholeUrl.append("endtime");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(nowEndTime.substring(11, 19));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
                parameterMap.put("begintime", nowBeginTime);
                parameterMap.put("endtime", nowEndTime);
                //说明时间差跨天，则将endDate改成beginDate当天,时分秒为当天最后时分秒
            } else if ((Integer.parseInt(endDate.replace("-", "")) - Integer.parseInt(beginDate.replace("-", ""))) > 0) {
                wholeUrl.append(dateKey);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(beginDate);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
                wholeUrl.append("starttime");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(beginTime.substring(11, 19));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
                endDate = beginDate;
               /* wholeUrl.append("end_date");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(endDate);
                wholeUrl.append(UtilConstants.LOGICAL_AND);*/
                wholeUrl.append("endtime");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append("23:59:59");
                wholeUrl.append(UtilConstants.LOGICAL_AND);
                parameterMap.put("endtime", endDate + " 23:59:59");

                //  endTime=beginDateNow+;
            } else {
                wholeUrl.append(dateKey);
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(beginDate);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
                wholeUrl.append("starttime");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(beginTime.substring(11, 19));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
              /*  wholeUrl.append("end_date");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(endDate);
                wholeUrl.append(UtilConstants.LOGICAL_AND);*/
                wholeUrl.append("endtime");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(endTime.substring(11, 19));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            String gametype = (String) parameterMap.get("gametype");
            if (StringUtils.isNotBlank(gametype)) {
                wholeUrl.append("gametype");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(gametype);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get("page");
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("page");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get("num");
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("pagelimit");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(object);
                wholeUrl.append(UtilConstants.LOGICAL_AND);
            }
            object = (String) parameterMap.get("password");//值为KeyB
            sbKey.append(object);
            // YYYYMMDD
            sbKey.append(DateUtil.formatDate2Str(ToolUtil.transferCNEsternDateToUSEsternDate(new Date()), DateUtil.C_DATE_PATTON_YYYYMMDD));
            //sbKey.append(ToolUtil.getUsEasternTime(new Date(), DateUtil.C_DATE_PATTON_YYYYMMDD));
            // B=MD5(website + username + KeyB + YYYYMMDD)
            MD5KeyStr = MD5.MD5Encode(sbKey.toString());
            // append key
            wholeUrl.append(UtilConstants.ORDER_KEY);
            wholeUrl.append(UtilConstants.ASSIGNMENT);
            String codeA = (String) parameterMap.get("orderField");
            String codeC = (String) parameterMap.get("orderWay");
            wholeUrl.append(codeA + MD5KeyStr + codeC);

        } catch (Exception ex) {
            log.error("UrlGeneratorUtil generateBBINBYDSUrl error:" + ex.getMessage(), ex);
        }
        //    log.info("platform="+platformId+",URL= "+wholeUrl);
        return wholeUrl.toString();
    }

    /**
     * Generate URL for AGQJ Exceptionor key = MD5( productid+begintime+endtime+page+num+keyB)
     * CAP-2480 AGQJ篡改注单 20190108
     * @param parameterMap
     * @param baseUrl
     * @param encoding
     * @return String
     */
    public static String generateUrlForAGQJExceptionor(Map<String, Object> parameterMap, String baseUrl, String encoding) {
        StringBuffer sbKey = new StringBuffer();
        // construct URL
        StringBuffer wholeUrl = new StringBuffer(baseUrl);
        // according to baseUrl,add prefix for URL
        if (baseUrl.indexOf(UtilConstants.QUESTION_MARK) == -1) {
            wholeUrl.append(UtilConstants.QUESTION_MARK);
        } else {
            wholeUrl.append(UtilConstants.LOGICAL_AND);
        }
        try {
            // productid
            String object = (String) parameterMap.get("productId");
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("productid");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
                sbKey.append(object.trim());
            }
            // begintime
            object = (String) parameterMap.get("begintime");
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("begintime");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
                sbKey.append(object.trim());
            }
            // endtime
            object = (String) parameterMap.get("endtime");
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("endtime");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
                sbKey.append(object);
            }
            // page
            object = (String) parameterMap.get("page");
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("page");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
                sbKey.append(object.trim());
            }
            // num
            object = (String) parameterMap.get("num");
            if (!StringUtils.isBlank(object)) {
                wholeUrl.append("num");
                wholeUrl.append(UtilConstants.ASSIGNMENT);
                wholeUrl.append(URLEncoder.encode(object, encoding));
                wholeUrl.append(UtilConstants.LOGICAL_AND);
                sbKey.append(object.trim());
            }
            sbKey.append(parameterMap.get("password"));
        } catch (Exception e) {
            log.error("UrlGeneratorUtil generateUrlForAGQJExceptionor error:" + e.getMessage(), e);
        }
        String keyString = MD5.MD5Encode(sbKey.toString());
        wholeUrl.append("key");
        wholeUrl.append(UtilConstants.ASSIGNMENT);
        wholeUrl.append(keyString);
        return wholeUrl.toString();
    }

    public static void main(String args[]) {
        Map<String, Object> parameterMap = new HashMap<String, Object>();
        parameterMap.put(UtilConstants.GLOBAL_PLATFORMID_KEY, "bbin_lottery_order");
        parameterMap.put(UtilConstants.ORDER_BBIN_WEBSITE, "keno8");
        parameterMap.put("uppername", "da02real");
        parameterMap.put(UtilConstants.GAME_RESULT_BEGIN_TIME, "2018-06-02 09:20:37");
        parameterMap.put(UtilConstants.GAME_RESULT_END_TIME, "2018-06-02 09:26:57");
        parameterMap.put("beginSeconds", "0");
        parameterMap.put("endSeconds", "10000");
        parameterMap.put("page", "0");
        parameterMap.put("num", "100");
        parameterMap.put("gametype", "LT");
        parameterMap.put(UtilConstants.ORDER_BBIN_PAGENUM, "0");
        parameterMap.put(UtilConstants.GAME_RESULT_PAGE_NUMBER, "300");
        parameterMap.put(UtilConstants.ORDER_BBIN_PASSWORD, "9RIZi3FIZ");
        parameterMap.put("orderField", "abcdefghl");
        parameterMap.put("orderWay", "abc");
        parameterMap.put(UtilConstants.ORDER_BBIN_GAMEKIND, "12");
        parameterMap.put(UtilConstants.ORDER_PRODUCT_ID, "A02");
        String baseUrl = "http://linkapi.068k8.com/app/WebService/XML/display.php/BetRecord";
        parameterMap.put(UtilConstants.ORDER_BASE_URL, baseUrl);
        String encoding = "UTF-8";
        try {
            AnalysisBBINLotteryJSONUtil lottery = new AnalysisBBINLotteryJSONUtil();
            String url = UrlGeneratorUtil.generateBBINBYDSUrl(parameterMap, baseUrl, UtilConstants.ENCODING_UTF8);
            System.out.println(url);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private static boolean isIOMGame(Map<String, Object> parameterMap) {
        return parameterMap.get(GAME_TYPE_KEY_IOM) != null && ((Integer) (parameterMap.get(GAME_TYPE_KEY_IOM))).intValue() == GameType.IOM_WALLET.getType();
    }
}
