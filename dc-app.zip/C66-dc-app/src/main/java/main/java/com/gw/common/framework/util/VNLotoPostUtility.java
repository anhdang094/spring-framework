package main.java.com.gw.common.framework.util;

import lombok.extern.slf4j.Slf4j;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by peter.munsayac on 3/22/2019.
 * edited by lily.y on 7/11/2019
 */
@Slf4j
public class VNLotoPostUtility {
    public static List<Object> post(String address, List<Object> arr, int num) throws Exception {
        URL url = null;
        try {
            url = new URL(address);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(40000);
        connection.setReadTimeout(40000);
        connection.setUseCaches(false);
        connection.setDoInput(true);
        connection.setDoOutput(true);
        connection.setRequestProperty("Content-type", "application/x-java-serialized-object");
        OutputStream outputStream = connection.getOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(outputStream);
        for (int i = 0; i < arr.size(); i++) {
            oos.writeObject(arr.get(i));
        }
        oos.flush();
        oos.close();

        List<Object> params = new ArrayList<>();
        InputStream in = connection.getInputStream();
        ObjectInputStream objInStream = new ObjectInputStream(in);
        for (int i = 0; i < num; i++) {
            Object obj = objInStream.readObject();
            log.info(" VNloto  vnloto get all transactions , read response object:{}",obj.toString());
            params.add(obj);
        }
        in.close();
        objInStream.close();
        return params;
    }

    public static List<Object> post(String address, String type, int num) throws Exception {
        List<Object> list = new ArrayList<>();
        list.add(type);
        return post(address, list, num);
    }
}

