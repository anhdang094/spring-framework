/**
 *
 */
package main.java.com.gw.common.system.entity;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * @author alex.l
 */
@SuppressWarnings("unused")
public class BetAmtLimitEntity {
    private String platformId;
    private String loginName;
    private String oddType;
    private BigDecimal ordersTotal;
    private BigDecimal limitOrdersTotal;
    private BigDecimal percentage;

    /**
     * @return the platformId
     */
    public String getPlatformId() {
        return platformId;
    }

    /**
     * @return the loginName
     */
    public String getLoginName() {
        return loginName;
    }

    /**
     * @return the oddType
     */
    public String getOddType() {
        return oddType;
    }

    /**
     * @return the ordersTotal
     */
    public BigDecimal getOrdersTotal() {
        return ordersTotal;
    }

    /**
     * @return the limitOrdersTotal
     */
    public BigDecimal getLimitOrdersTotal() {
        return limitOrdersTotal;
    }

    /**
     * @return the percentage
     */
    public String getPercentage() {
        return ((limitOrdersTotal.divide(ordersTotal, 4, RoundingMode.HALF_UP)).multiply(BigDecimal.valueOf(100l))).toString() + "%";
    }

    /**
     * @param platformId the platformId to set
     */
    public void setPlatformId(String platformId) {
        this.platformId = platformId;
    }

    /**
     * @param loginName the loginName to set
     */
    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    /**
     * @param oddType the oddType to set
     */
    public void setOddType(String oddType) {
        this.oddType = oddType;
    }

    /**
     * @param ordersTotal the ordersTotal to set
     */
    public void setOrdersTotal(BigDecimal ordersTotal) {
        this.ordersTotal = ordersTotal;
    }

    /**
     * @param limitOrdersTotal the limitOrdersTotal to set
     */
    public void setLimitOrdersTotal(BigDecimal limitOrdersTotal) {
        this.limitOrdersTotal = limitOrdersTotal;
    }

    /**
     * @param percentage the percentage to set
     */
    public void setPercentage(BigDecimal percentage) {
        this.percentage = percentage;
    }

}
