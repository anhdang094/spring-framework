package main.java.com.gw.common.system.entity;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

/**
 * @Description: 冠军体育注单详情实体
 * @Author: eagle
 * @Date: 2019/6/6 19:57
 */
public class CSOrderDetailEntity {
    /**订单详情Id*/
    private long id;
    /**比赛Id*/
    private long matchId;
    /**比赛阶段ID*/
    private long matchPeroidId;
    /**比赛时间*/
    private long matchTime;
    /**运动Id*/
    private long sportId;
    /**运动名称*/
    private String sportName;
    /**地区ID*/
    private long regionId;
    /**地区*/
    private String regionName;
    /**联赛ID*/
    private long leagueId;
    /**联赛*/
    private String leagueName;

    /**主队*/
    private String homeTeam;

    /**客队*/
    private String awayTeam;
    /**玩法ID*/
    private long marketId;
    /**玩法*/
    private String marketName;
    /**比赛阶段类型*/
    private Integer eventPartnerId;
    /**比赛阶段，例如第几节*/
    private Integer periodNum;
    /**阶段名称*/
    private String periodName;
    /**是否滚球*/
    private Boolean isLive;
    /**赔率ID*/
    private long oddsId;
    /**投注时赔率*/
    private BigDecimal oddsValue;
    /**盘口*/
    private BigDecimal argument;
    /**投注时比分信息*/
    private String score;
    /**投注选项*/
    private String stakeName;
    /**投注状态*/
    private int stakeStatus;
    /**投注状态名称*/
    private String stakeStatusName;
    /**结算的比分信息*/
    private String finalScore;
    /**记录创建时间*/
    private Long createdAt;
    /**记录修改时间时间*/
    private Long updatedAt;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getMatchId() {
        return matchId;
    }

    public void setMatchId(long matchId) {
        this.matchId = matchId;
    }

    public long getMatchPeroidId() {
        return matchPeroidId;
    }

    public void setMatchPeroidId(long matchPeroidId) {
        this.matchPeroidId = matchPeroidId;
    }

    public long getMatchTime() {
        return matchTime;
    }

    public void setMatchTime(long matchTime) {
        this.matchTime = matchTime;
    }

    public long getSportId() {
        return sportId;
    }

    public void setSportId(long sportId) {
        this.sportId = sportId;
    }

    public String getSportName() {
        return sportName;
    }

    public void setSportName(String sportName) {
        this.sportName = sportName;
    }

    public long getRegionId() {
        return regionId;
    }

    public void setRegionId(long regionId) {
        this.regionId = regionId;
    }

    public String getRegionName() {
        return regionName;
    }

    public void setRegionName(String regionName) {
        this.regionName = regionName;
    }

    public long getLeagueId() {
        return leagueId;
    }

    public void setLeagueId(long leagueId) {
        this.leagueId = leagueId;
    }

    public String getLeagueName() {
        return leagueName;
    }

    public void setLeagueName(String leagueName) {
        this.leagueName = leagueName;
    }

    public String getHomeTeam() {
        return homeTeam;
    }

    public void setHomeTeam(String homeTeam) {
        this.homeTeam = homeTeam;
    }

    public String getAwayTeam() {
        return awayTeam;
    }

    public void setAwayTeam(String awayTeam) {
        this.awayTeam = awayTeam;
    }

    public long getMarketId() {
        return marketId;
    }

    public void setMarketId(long marketId) {
        this.marketId = marketId;
    }

    public String getMarketName() {
        return marketName;
    }

    public void setMarketName(String marketName) {
        this.marketName = marketName;
    }

    public Integer getEventPartnerId() {
        return eventPartnerId;
    }

    public void setEventPartnerId(Integer eventPartnerId) {
        this.eventPartnerId = eventPartnerId;
    }

    public Integer getPeriodNum() {
        return periodNum;
    }

    public void setPeriodNum(Integer periodNum) {
        this.periodNum = periodNum;
    }

    public String getPeriodName() {
        return periodName;
    }

    public void setPeriodName(String periodName) {
        this.periodName = periodName;
    }

    public Boolean getLive() {
        return isLive;
    }

    public void setLive(Boolean live) {
        isLive = live;
    }

    public long getOddsId() {
        return oddsId;
    }

    public void setOddsId(long oddsId) {
        this.oddsId = oddsId;
    }

    public BigDecimal getOddsValue() {
        return oddsValue;
    }

    public void setOddsValue(BigDecimal oddsValue) {
        this.oddsValue = oddsValue;
    }

    public BigDecimal getArgument() {
        return argument;
    }

    public void setArgument(BigDecimal argument) {
        this.argument = argument;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public String getStakeName() {
        return stakeName;
    }

    public void setStakeName(String stakeName) {
        this.stakeName = stakeName;
    }

    public int getStakeStatus() {
        return stakeStatus;
    }

    public void setStakeStatus(int stakeStatus) {
        this.stakeStatus = stakeStatus;
    }

    public String getStakeStatusName() {
        return stakeStatusName;
    }

    public void setStakeStatusName(String stakeStatusName) {
        this.stakeStatusName = stakeStatusName;
    }

    public String getFinalScore() {
        return finalScore;
    }

    public void setFinalScore(String finalScore) {
        this.finalScore = finalScore;
    }

    public Long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Long createdAt) {
        this.createdAt = createdAt;
    }

    public Long getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Long updatedAt) {
        this.updatedAt = updatedAt;
    }
}
