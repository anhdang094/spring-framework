package main.java.com.gw.common.system.entity;

import java.math.BigDecimal;
import java.util.List;

/**
 * @Description: 冠军体育注单实体
 * @Author: eagle
 * @Date: 2019/6/6 19:57
 */
public class CSOrderEntity {

    /**订单Id*/
    private long id;
    /**订单号*/
    private String orderNum;
    /**渠道方用户Id*/
    private String partnerUserId;
    /**过关方式Id*/
    private long betTypeId;
    /**过关方式*/
    private String betTypeName;
    /**串关方式Id*/
    private int combinationsId;
    /**串关方式*/
    private String combinationsName;
    /**处理阶段，1-下订，2-确认，3-结算，4-派奖，5-取消*/
    private int phase;
    /**处理阶段状态，1-初始化，2-处理中，3-成功，4-失败*/
    private int phaseStatus;
    /**订单金额*/
    private BigDecimal orderAmount;
    /**投注前额度*/
    private BigDecimal originalAmount;
    /**订单结果*/
    private int betResult;
    /**总赔率*/
    private BigDecimal totalOdds;
    /**赔率类型 1:小数式赔率 2:香港赔率*/
    private int oddsType;
    /***预计奖金*/
    private BigDecimal estimatedBonus;
    /**实际奖金*/
    private BigDecimal realBonus;
    /**实际奖金*/
    private BigDecimal winOrLose;
    /**记录创建时间*/
    private Long createdAt;
    /**记录修改时间时间*/
    private Long updatedAt;
    /**订单详情信息*/
    private List<CSOrderDetailEntity> details;

    private BigDecimal realOrderAmount;

    public BigDecimal getRealOrderAmount() {
        return realOrderAmount;
    }

    public void setRealOrderAmount(BigDecimal realOrderAmount) {
        this.realOrderAmount = realOrderAmount;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getOrderNum() { return orderNum; }

    public void setOrderNum(String orderNum) { this.orderNum = orderNum; }

    public String getPartnerUserId() {
        return partnerUserId;
    }

    public void setPartnerUserId(String partnerUserId) {
        this.partnerUserId = partnerUserId;
    }

    public long getBetTypeId() {
        return betTypeId;
    }

    public void setBetTypeId(long betTypeId) {
        this.betTypeId = betTypeId;
    }

    public String getBetTypeName() {
        return betTypeName;
    }

    public void setBetTypeName(String betTypeName) {
        this.betTypeName = betTypeName;
    }

    public int getCombinationsId() {
        return combinationsId;
    }

    public void setCombinationsId(int combinationsId) {
        this.combinationsId = combinationsId;
    }

    public String getCombinationsName() {
        return combinationsName;
    }

    public void setCombinationsName(String combinationsName) {
        this.combinationsName = combinationsName;
    }

    public int getPhase() {
        return phase;
    }

    public void setPhase(int phase) {
        this.phase = phase;
    }

    public int getPhaseStatus() {
        return phaseStatus;
    }

    public void setPhaseStatus(int phaseStatus) {
        this.phaseStatus = phaseStatus;
    }

    public BigDecimal getOrderAmount() {
        return orderAmount;
    }

    public void setOrderAmount(BigDecimal orderAmount) {
        this.orderAmount = orderAmount;
    }

    public BigDecimal getOriginalAmount() {
        return originalAmount;
    }

    public void setOriginalAmount(BigDecimal originalAmount) {
        this.originalAmount = originalAmount;
    }

    public int getBetResult() {
        return betResult;
    }

    public void setBetResult(int betResult) {
        this.betResult = betResult;
    }

    public BigDecimal getTotalOdds() { return totalOdds; }

    public void setTotalOdds(BigDecimal totalOdds) { this.totalOdds = totalOdds; }

    public int getOddsType() { return oddsType; }

    public void setOddsType(int oddsType) { this.oddsType = oddsType; }

    public BigDecimal getEstimatedBonus() {
        return estimatedBonus;
    }

    public void setEstimatedBonus(BigDecimal estimatedBonus) {
        this.estimatedBonus = estimatedBonus;
    }

    public BigDecimal getRealBonus() {
        return realBonus;
    }

    public void setRealBonus(BigDecimal realBonus) {
        this.realBonus = realBonus;
    }

    public Long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Long createdAt) {
        this.createdAt = createdAt;
    }

    public Long getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Long updatedAt) {
        this.updatedAt = updatedAt;
    }

    public List<CSOrderDetailEntity> getDetails() {
        return details;
    }

    public void setDetails(List<CSOrderDetailEntity> details) {
        this.details = details;
    }

    public BigDecimal getWinOrLose() {
        return winOrLose;
    }

    public void setWinOrLose(BigDecimal winOrLose) {
        this.winOrLose = winOrLose;
    }
}
