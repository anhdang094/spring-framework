package main.java.com.gw.common.system.entity;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class IMDJOrderEntity {

    private String orderNo;
    private String productId;
    private String userId;
    private String matchId;
    private BigDecimal betAmount;
    private BigDecimal winAmount;
    private BigDecimal totalRewardAmount;
    private BigDecimal previousAmount;
    private String betType;
    private int status;
    private String cancelled;
    private String odds;
    private String oddsType;
    private Timestamp betDate;
    private Timestamp settlementDate;
    private Timestamp realSettlementDate;

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getMatchId() {
        return matchId;
    }

    public void setMatchId(String matchId) {
        this.matchId = matchId;
    }

    public BigDecimal getBetAmount() {
        return betAmount;
    }

    public void setBetAmount(BigDecimal betAmount) {
        this.betAmount = betAmount;
    }

    public BigDecimal getWinAmount() {
        return winAmount;
    }

    public void setWinAmount(BigDecimal winAmount) {
        this.winAmount = winAmount;
    }

    public BigDecimal getTotalRewardAmount() {
        return totalRewardAmount;
    }

    public void setTotalRewardAmount(BigDecimal totalRewardAmount) {
        this.totalRewardAmount = totalRewardAmount;
    }

    public BigDecimal getPreviousAmount() {
        return previousAmount;
    }

    public void setPreviousAmount(BigDecimal previousAmount) {
        this.previousAmount = previousAmount;
    }

    public String getBetType() {
        return betType;
    }

    public void setBetType(String betType) {
        this.betType = betType;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getCancelled() {
        return cancelled;
    }

    public void setCancelled(String cancelled) {
        this.cancelled = cancelled;
    }

    public String getOdds() {
        return odds;
    }

    public void setOdds(String odds) {
        this.odds = odds;
    }

    public String getOddsType() {
        return oddsType;
    }

    public void setOddsType(String oddsType) {
        this.oddsType = oddsType;
    }

    public Timestamp getBetDate() {
        return betDate;
    }

    public void setBetDate(Timestamp betDate) {
        this.betDate = betDate;
    }

    public Timestamp getSettlementDate() {
        return settlementDate;
    }

    public void setSettlementDate(Timestamp settlementDate) {
        this.settlementDate = settlementDate;
    }

    public Timestamp getRealSettlementDate() {
        return realSettlementDate;
    }

    public void setRealSettlementDate(Timestamp realSettlementDate) {
        this.realSettlementDate = realSettlementDate;
    }

}
