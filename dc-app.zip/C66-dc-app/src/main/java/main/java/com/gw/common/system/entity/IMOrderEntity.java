package main.java.com.gw.common.system.entity;

import java.math.BigDecimal;
import java.util.Date;

public class IMOrderEntity {
    private String orderNo;
    private String productId;
    private String userId;
    private String requestType;
    private BigDecimal betAmount;
    private BigDecimal winAmount;
    private String betType;
    private Integer status;
    private String odds;
    private String checkOdds;
    private Date betDate;
    private Date settlementDate;
    private Date realSettlementDate;
    private BigDecimal previousAmount;
    private String oddsType;

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public BigDecimal getPreviousAmount() {
        return previousAmount;
    }

    public void setPreviousAmount(BigDecimal previousAmount) {
        this.previousAmount = previousAmount;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public BigDecimal getBetAmount() {
        return betAmount;
    }

    public void setBetAmount(BigDecimal betAmount) {
        this.betAmount = betAmount;
    }

    public BigDecimal getWinAmount() {
        return winAmount;
    }

    public void setWinAmount(BigDecimal winAmount) {
        this.winAmount = winAmount;
    }

    public String getBetType() {
        return betType;
    }

    public void setBetType(String betType) {
        this.betType = betType;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getOdds() {
        return odds;
    }

    public void setOdds(String odds) {
        this.odds = odds;
    }

    public String getCheckOdds() {
        return checkOdds;
    }

    public void setCheckOdds(String checkOdds) {
        this.checkOdds = checkOdds;
    }

    public Date getBetDate() {
        return betDate;
    }

    public void setBetDate(Date betDate) {
        this.betDate = betDate;
    }

    public Date getSettlementDate() {
        return settlementDate;
    }

    public void setSettlementDate(Date settlementDate) {
        this.settlementDate = settlementDate;
    }

    public Date getRealSettlementDate() {
        return realSettlementDate;
    }

    public void setRealSettlementDate(Date realSettlementDate) {
        this.realSettlementDate = realSettlementDate;
    }

    public String getOddsType() {
        return oddsType;
    }

    public void setOddsType(String oddsType) {
        this.oddsType = oddsType;
    }
}
