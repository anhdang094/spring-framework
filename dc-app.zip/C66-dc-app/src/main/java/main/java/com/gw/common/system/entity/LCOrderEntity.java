package main.java.com.gw.common.system.entity;

import java.util.Date;

public class LCOrderEntity {


    //游戏局号
    private String gameID;
    //玩家账号
    private String accounts;
    //房间id
    private String serverID;
    //游戏id
    private String kindID;
    //桌子号
    private String tableID;
    //椅子号
    private String chairId;
    //玩家数量
    private int userCount;

    public String getGameID() {
        return gameID;
    }

    public void setGameID(String gameID) {
        this.gameID = gameID;
    }

    public String getAccounts() {
        return accounts;
    }

    public void setAccounts(String accounts) {
        this.accounts = accounts;
    }

    public String getServerID() {
        return serverID;
    }

    public void setServerID(String serverID) {
        this.serverID = serverID;
    }

    public String getKindID() {
        return kindID;
    }

    public void setKindID(String kindID) {
        this.kindID = kindID;
    }

    public String getTableID() {
        return tableID;
    }

    public void setTableID(String tableID) {
        this.tableID = tableID;
    }

    public String getChairId() {
        return chairId;
    }

    public void setChairId(String chairId) {
        this.chairId = chairId;
    }

    public int getUserCount() {
        return userCount;
    }

    public void setUserCount(int userCount) {
        this.userCount = userCount;
    }

    public String getCardValue() {
        return cardValue;
    }

    public void setCardValue(String cardValue) {
        this.cardValue = cardValue;
    }

    public float getCellScore() {
        return cellScore;
    }

    public void setCellScore(float cellScore) {
        this.cellScore = cellScore;
    }

    public float getAllBet() {
        return allBet;
    }

    public void setAllBet(float allBet) {
        this.allBet = allBet;
    }

    public String getProfit() {
        return profit;
    }

    public void setProfit(String profit) {
        this.profit = profit;
    }

    public String getRevenue() {
        return revenue;
    }

    public void setRevenue(String revenue) {
        this.revenue = revenue;
    }

    public Date getGameStartTime() {
        return gameStartTime;
    }

    public void setGameStartTime(Date gameStartTime) {
        this.gameStartTime = gameStartTime;
    }

    public Date getGameEndTime() {
        return gameEndTime;
    }

    public void setGameEndTime(Date gameEndTime) {
        this.gameEndTime = gameEndTime;
    }

    public int getChannelID() {
        return channelID;
    }

    public void setChannelID(int channelID) {
        this.channelID = channelID;
    }

    public String getLineCode() {
        return lineCode;
    }

    public void setLineCode(String lineCode) {
        this.lineCode = lineCode;
    }

    public String getAgCode() {
        return agCode;
    }

    public void setAgCode(String agCode) {
        this.agCode = agCode;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getLoginname() {
        return loginname;
    }

    public void setLoginname(String loginname) {
        this.loginname = loginname;
    }

    //手牌公共牌
    private String cardValue;
    //有效下注
    private float cellScore;
    //总下注
    private  float allBet;
    //盈利
    private String profit;
    //抽水
    private String revenue;
    //开始时间
    private Date gameStartTime;
    //结束时间
    private Date gameEndTime;
    //渠道id
    private int channelID;
    //游戏结果对应玩家所属站点
    private  String lineCode;
    //代理编号
    private String agCode;

    private String result;

    private String productId;

    private String loginname;



}

