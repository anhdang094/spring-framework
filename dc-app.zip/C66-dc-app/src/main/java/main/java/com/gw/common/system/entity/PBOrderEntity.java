package main.java.com.gw.common.system.entity;

public class PBOrderEntity {

    private String wagerId;
    private String wagerDateFm;
    private String eventDateFm;
    private String settleDateFm;
    private String status;
    private String handicap;
    private String odds;
    private String oddsFormat;
    private String betType;
    private String stake;
    private String sportId;
    private String sport;
    private String currencyCode;
    private String toWin;
    private String toRisk;
    private String parlayMixOdds;
    private String userCode;
    private String loginId;
    private String winLoss;
    private String commission;
    private String turnover;
    private String result;

    private String productId;
    private String loginname;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getLoginname() {
        return loginname;
    }

    public void setLoginname(String loginname) {
        this.loginname = loginname;
    }

    public String getTurnover() {
        return turnover;
    }

    public void setTurnover(String turnover) {
        this.turnover = turnover;
    }

    public String getWagerId() {
        return wagerId;
    }

    public void setWagerId(String wagerId) {
        this.wagerId = wagerId;
    }

    public String getWagerDateFm() {
        return wagerDateFm;
    }

    public void setWagerDateFm(String wagerDateFm) {
        this.wagerDateFm = wagerDateFm;
    }

    public String getEventDateFm() {
        return eventDateFm;
    }

    public void setEventDateFm(String eventDateFm) {
        this.eventDateFm = eventDateFm;
    }

    public String getSettleDateFm() {
        return settleDateFm;
    }

    public void setSettleDateFm(String settleDateFm) {
        this.settleDateFm = settleDateFm;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getHandicap() {
        return handicap;
    }

    public void setHandicap(String handicap) {
        this.handicap = handicap;
    }

    public String getOdds() {
        return odds;
    }

    public void setOdds(String odds) {
        this.odds = odds;
    }

    public String getOddsFormat() {
        return oddsFormat;
    }

    public void setOddsFormat(String oddsFormat) {
        this.oddsFormat = oddsFormat;
    }

    public String getBetType() {
        return betType;
    }

    public void setBetType(String betType) {
        this.betType = betType;
    }

    public String getStake() {
        return stake;
    }

    public void setStake(String stake) {
        this.stake = stake;
    }

    public String getSportId() {
        return sportId;
    }

    public void setSportId(String sportId) {
        this.sportId = sportId;
    }

    public String getSport() {
        return sport;
    }

    public void setSport(String sport) {
        this.sport = sport;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getToWin() {
        return toWin;
    }

    public void setToWin(String toWin) {
        this.toWin = toWin;
    }

    public String getToRisk() {
        return toRisk;
    }

    public void setToRisk(String toRisk) {
        this.toRisk = toRisk;
    }

    public String getParlayMixOdds() {
        return parlayMixOdds;
    }

    public void setParlayMixOdds(String parlayMixOdds) {
        this.parlayMixOdds = parlayMixOdds;
    }

    public String getUserCode() {
        return userCode;
    }

    public void setUserCode(String userCode) {
        this.userCode = userCode;
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId;
    }

    public String getWinLoss() {
        return winLoss;
    }

    public void setWinLoss(String winLoss) {
        this.winLoss = winLoss;
    }

    public String getCommission() {
        return commission;
    }

    public void setCommission(String commission) {
        this.commission = commission;
    }

    //    private String orderNo;
//    private String userId;
//    private String loginName;
//    private String productId;
//    private BigDecimal betAmount;
//    private BigDecimal winAmount;
//    private String type;
//    private String betType;
//    private Integer status;
//    private BigDecimal odds;
//    private Date betDate;
//    private Date updatedDate;
//    private Date settlementDate;
//    private String realSettlementDate;
//    private BigDecimal validAmount;
//    private BigDecimal cusAmount;
//    private BigDecimal previousAmount;
//    private String oddsType;
//    private String currency;
//    private Integer flag;
//    private String playType;
//    private String gameType;
//
//    public String getGameType() {
//        return gameType;
//    }
//
//    public void setGameType(String gameType) {
//        this.gameType = gameType;
//    }
//
//    public String getPlayType() {
//        return playType;
//    }
//
//    public void setPlayType(String playType) {
//        this.playType = playType;
//    }
//
//    public String getOrderNo() {
//        return orderNo;
//    }
//
//    public void setOrderNo(String orderNo) {
//        this.orderNo = orderNo;
//    }
//
//    public String getUserId() {
//        return userId;
//    }
//
//    public void setUserId(String userId) {
//        this.userId = userId;
//    }
//
//    public String getLoginName() {
//        return loginName;
//    }
//
//    public void setLoginName(String loginName) {
//        this.loginName = loginName;
//    }
//
//    public String getProductId() {
//        return productId;
//    }
//
//    public void setProductId(String productId) {
//        this.productId = productId;
//    }
//
//    public BigDecimal getBetAmount() {
//        return betAmount;
//    }
//
//    public void setBetAmount(BigDecimal betAmount) {
//        this.betAmount = betAmount;
//    }
//
//    public BigDecimal getWinAmount() {
//        return winAmount;
//    }
//
//    public void setWinAmount(BigDecimal winAmount) {
//        this.winAmount = winAmount;
//    }
//
//    public String getType() {
//        return type;
//    }
//
//    public void setType(String type) {
//        this.type = type;
//    }
//
//    public String getBetType() {
//        return betType;
//    }
//
//    public void setBetType(String betType) {
//        this.betType = betType;
//    }
//
//    public Integer getStatus() {
//        return status;
//    }
//
//    public void setStatus(Integer status) {
//        this.status = status;
//    }
//
//    public BigDecimal getOdds() {
//        return odds;
//    }
//
//    public void setOdds(BigDecimal odds) {
//        this.odds = odds;
//    }
//
//    public Date getBetDate() {
//        return betDate;
//    }
//
//    public void setBetDate(Date betDate) {
//        this.betDate = betDate;
//    }
//
//    public Date getUpdatedDate() {
//        return updatedDate;
//    }
//
//    public void setUpdatedDate(Date updatedDate) {
//        this.updatedDate = updatedDate;
//    }
//
//    public Date getSettlementDate() {
//        return settlementDate;
//    }
//
//    public void setSettlementDate(Date settlementDate) {
//        this.settlementDate = settlementDate;
//    }
//
//    public String getRealSettlementDate() {
//        return realSettlementDate;
//    }
//
//    public void setRealSettlementDate(String realSettlementDate) {
//        this.realSettlementDate = realSettlementDate;
//    }
//
//    public BigDecimal getValidAmount() {
//        return validAmount;
//    }
//
//    public void setValidAmount(BigDecimal validAmount) {
//        this.validAmount = validAmount;
//    }
//
//    public BigDecimal getCusAmount() {
//        return cusAmount;
//    }
//
//    public void setCusAmount(BigDecimal cusAmount) {
//        this.cusAmount = cusAmount;
//    }
//
//    public BigDecimal getPreviousAmount() {
//        return previousAmount;
//    }
//
//    public void setPreviousAmount(BigDecimal previousAmount) {
//        this.previousAmount = previousAmount;
//    }
//
//    public String getOddsType() {
//        return oddsType;
//    }
//
//    public void setOddsType(String oddsType) {
//        this.oddsType = oddsType;
//    }
//
//    public String getCurrency() {
//        return currency;
//    }
//
//    public void setCurrency(String currency) {
//        this.currency = currency;
//    }
//
//    public Integer getFlag() {
//        return flag;
//    }
//
//    public void setFlag(Integer flag) {
//        this.flag = flag;
//    }
}
