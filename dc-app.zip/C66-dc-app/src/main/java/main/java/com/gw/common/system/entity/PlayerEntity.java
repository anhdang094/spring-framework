package main.java.com.gw.common.system.entity;

public class PlayerEntity {
    //玩家真实姓名
    private String realName;
    //玩家账户名
    private String playerName;
    //玩家别名
    private String aliasName;
    //代理代码
    private String agentCode;
    //代理名称
    private String agentName;
    //玩家额度
    private String currentAmount;
    //注册时间
    private String registerTime;
    //上次登录时间
    private String beforeLoginTime;
    //上次登录IP
    private String beforeLoginIp;
    //最近登录时间
    private String lastLoginTime;
    //最近登录IP
    private String lastLiginIp;
    //登陆次数
    private String loginTimes;
    //是否有效
    private String isValid;
    //产品名称
    private String productId;

    /**
     * @return the realName
     */
    public String getRealName() {
        return realName;
    }

    /**
     * @param realName the realName to set
     */
    public void setRealName(String realName) {
        this.realName = realName;
    }

    /**
     * @return the playerName
     */
    public String getPlayerName() {
        return playerName;
    }

    /**
     * @param playerName the playerName to set
     */
    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

    /**
     * @return the aliasName
     */
    public String getAliasName() {
        return aliasName;
    }

    /**
     * @param aliasName the aliasName to set
     */
    public void setAliasName(String aliasName) {
        this.aliasName = aliasName;
    }

    /**
     * @return the agentCode
     */
    public String getAgentCode() {
        return agentCode;
    }

    /**
     * @param agentCode the agentCode to set
     */
    public void setAgentCode(String agentCode) {
        this.agentCode = agentCode;
    }

    /**
     * @return the agentName
     */
    public String getAgentName() {
        return agentName;
    }

    /**
     * @param agentName the agentName to set
     */
    public void setAgentName(String agentName) {
        this.agentName = agentName;
    }

    /**
     * @return the currentAmount
     */
    public String getCurrentAmount() {
        return currentAmount;
    }

    /**
     * @param currentAmount the currentAmount to set
     */
    public void setCurrentAmount(String currentAmount) {
        this.currentAmount = currentAmount;
    }

    /**
     * @return the registerTime
     */
    public String getRegisterTime() {
        return registerTime;
    }

    /**
     * @param registerTime the registerTime to set
     */
    public void setRegisterTime(String registerTime) {
        this.registerTime = registerTime;
    }

    /**
     * @return the beforeLoginTime
     */
    public String getBeforeLoginTime() {
        return beforeLoginTime;
    }

    /**
     * @param beforeLoginTime the beforeLoginTime to set
     */
    public void setBeforeLoginTime(String beforeLoginTime) {
        this.beforeLoginTime = beforeLoginTime;
    }

    /**
     * @return the beforeLoginIp
     */
    public String getBeforeLoginIp() {
        return beforeLoginIp;
    }

    /**
     * @param beforeLoginIp the beforeLoginIp to set
     */
    public void setBeforeLoginIp(String beforeLoginIp) {
        this.beforeLoginIp = beforeLoginIp;
    }

    /**
     * @return the lastLoginTime
     */
    public String getLastLoginTime() {
        return lastLoginTime;
    }

    /**
     * @param lastLoginTime the lastLoginTime to set
     */
    public void setLastLoginTime(String lastLoginTime) {
        this.lastLoginTime = lastLoginTime;
    }

    /**
     * @return the lastLiginIp
     */
    public String getLastLiginIp() {
        return lastLiginIp;
    }

    /**
     * @param lastLiginIp the lastLiginIp to set
     */
    public void setLastLiginIp(String lastLiginIp) {
        this.lastLiginIp = lastLiginIp;
    }

    /**
     * @return the loginTimes
     */
    public String getLoginTimes() {
        return loginTimes;
    }

    /**
     * @param loginTimes the loginTimes to set
     */
    public void setLoginTimes(String loginTimes) {
        this.loginTimes = loginTimes;
    }

    /**
     * @return the isValid
     */
    public String getIsValid() {
        return isValid;
    }

    /**
     * @param isValid the isValid to set
     */
    public void setIsValid(String isValid) {
        this.isValid = isValid;
    }

    /**
     * @return the productId
     */
    public String getProductId() {
        return productId;
    }

    /**
     * @param productId the productId to set
     */
    public void setProductId(String productId) {
        this.productId = productId;
    }

}
