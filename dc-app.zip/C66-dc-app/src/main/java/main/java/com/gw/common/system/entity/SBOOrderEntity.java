package main.java.com.gw.common.system.entity;

import java.util.Date;
import java.util.List;

public class SBOOrderEntity {

    private Data data;
    private Error error;

    public class Data {
        private List<BetLog> betlogs;
        private String last_record_time;
        private Integer total;
        private String start_time;
        private String end_time;
        private Integer page;
        private Integer page_count;

        public List<BetLog> getBetlogs() {
            return betlogs;
        }

        public void setBetlogs(List<BetLog> betlogs) {
            this.betlogs = betlogs;
        }

        public String getLast_record_time() {
            return last_record_time;
        }

        public void setLast_record_time(String last_record_time) {
            this.last_record_time = last_record_time;
        }

        public Integer getTotal() {
            return total;
        }

        public void setTotal(Integer total) {
            this.total = total;
        }

        public String getStart_time() {
            return start_time;
        }

        public void setStart_time(String start_time) {
            this.start_time = start_time;
        }

        public String getEnd_time() {
            return end_time;
        }

        public void setEnd_time(String end_time) {
            this.end_time = end_time;
        }

        public Integer getPage() {
            return page;
        }

        public void setPage(Integer page) {
            this.page = page;
        }

        public Integer getPage_count() {
            return page_count;
        }

        public void setPage_count(Integer page_count) {
            this.page_count = page_count;
        }
    }

    public class BetLog {
        private String player_name;
        private String vendor_code;
        private String game_code;
        private String parent_bet_id;
        private String bet_id;
        private String trans_type;
        private String currency;
        private String wallet_code;
        private String bet_amount;
        private String win_amount;
        private String traceId;
        private String created_at;
        private String product_id;

        public String getProduct_id() {
            return product_id;
        }

        public void setProduct_id(String product_id) {
            this.product_id = product_id;
        }

        public String getPlayer_name() {
            return player_name;
        }

        public void setPlayer_name(String player_name) {
            this.player_name = player_name;
        }

        public String getVendor_code() {
            return vendor_code;
        }

        public void setVendor_code(String vendor_code) {
            this.vendor_code = vendor_code;
        }

        public String getGame_code() {
            return game_code;
        }

        public void setGame_code(String game_code) {
            this.game_code = game_code;
        }

        public String getParent_bet_id() {
            return parent_bet_id;
        }

        public void setParent_bet_id(String parent_bet_id) {
            this.parent_bet_id = parent_bet_id;
        }

        public String getBet_id() {
            return bet_id;
        }

        public void setBet_id(String bet_id) {
            this.bet_id = bet_id;
        }

        public String getTrans_type() {
            return trans_type;
        }

        public void setTrans_type(String trans_type) {
            this.trans_type = trans_type;
        }

        public String getCurrency() {
            return currency;
        }

        public void setCurrency(String currency) {
            this.currency = currency;
        }

        public String getWallet_code() {
            return wallet_code;
        }

        public void setWallet_code(String wallet_code) {
            this.wallet_code = wallet_code;
        }

        public String getBet_amount() {
            return bet_amount;
        }

        public void setBet_amount(String bet_amount) {
            this.bet_amount = bet_amount;
        }

        public String getWin_amount() {
            return win_amount;
        }

        public void setWin_amount(String win_amount) {
            this.win_amount = win_amount;
        }

        public String getTraceId() {
            return traceId;
        }

        public void setTraceId(String traceId) {
            this.traceId = traceId;
        }

        public String getCreated_at() {
            return created_at;
        }

        public void setCreated_at(String created_at) {
            this.created_at = created_at;
        }
    }

    public class Error {
        private String code;
        private String message;

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }

}
