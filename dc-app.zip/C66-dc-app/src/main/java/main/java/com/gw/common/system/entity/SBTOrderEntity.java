package main.java.com.gw.common.system.entity;

import java.math.BigDecimal;
import java.util.Date;

public class SBTOrderEntity {


    private String betId;

    private String loginName;

    private String reserveId;
    //投注额
    private BigDecimal amount;
    //有效投注额
    private BigDecimal validAmount;
    //客户输赢度
    private BigDecimal payOffAmount;
    //REMAIN_AMOUNT  (洗码)返水投注额
    private BigDecimal remainAmount;

    private String createTime;

    private String lastUpdateTime;

    //货币类型
    private String currency;

    /**
     * 注单状态：1已结算，0未结算，-1重置试玩额度，-2注单被篡改，-8取消指定局注单，-9取消注单
     */
    private int flag;


    private String productId;

    private String platformId;

    private String gameKind;

    private Date createDate;

    private Date lastUpdate;

    //赔率
    private BigDecimal odds;
    //盘口
    private String oddsType;
    //玩法类型，单注，三串一之类的
    private String betTypeName;

    //游戏类型，篮球，足球
    private String branchName;


    private String deviceType;

    private String updateIdFlag;

    //原金额 add by ziv 2018-03-28
    private BigDecimal previousBalance;

    //派奖金额（派奖金额-本金=payout） add by ziv 2018-03-28
    private BigDecimal winAmount;

    private String status;

	/**
	 *2018-09-24 by wythe终端类型
	 * @return
	 */
	private String termType="-1";


	public String getDeviceType() {
		return deviceType;
	}

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public BigDecimal getOdds() {
        return odds;
    }

    public void setOdds(BigDecimal odds) {
        this.odds = odds;
    }

    public String getOddsType() {
        return oddsType;
    }

    public void setOddsType(String oddsType) {
        this.oddsType = oddsType;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getPlatformId() {
        return platformId;
    }

    public void setPlatformId(String platformId) {
        this.platformId = platformId;
    }

    public String getGameKind() {
        return gameKind;
    }

    public void setGameKind(String gameKind) {
        this.gameKind = gameKind;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    public String getBetId() {
        return betId;
    }

    public void setBetId(String betId) {
        this.betId = betId;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getReserveId() {
        return reserveId;
    }

    public void setReserveId(String reserveId) {
        this.reserveId = reserveId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getValidAmount() {
        return validAmount;
    }

    public void setValidAmount(BigDecimal validAmount) {
        this.validAmount = validAmount;
    }

    public BigDecimal getPayOffAmount() {
        return payOffAmount;
    }

    public void setPayOffAmount(BigDecimal payOffAmount) {
        this.payOffAmount = payOffAmount;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getLastUpdateTime() {
        return lastUpdateTime;
    }

    public void setLastUpdateTime(String lastUpdateTime) {
        this.lastUpdateTime = lastUpdateTime;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getBetTypeName() {
        return betTypeName;
    }

    public void setBetTypeName(String betTypeName) {
        this.betTypeName = betTypeName;
    }

    public String getBranchName() {
        return branchName;
    }

    public void setBranchName(String branchName) {
        this.branchName = branchName;
    }

    public BigDecimal getRemainAmount() {
        return remainAmount;
    }

    public void setRemainAmount(BigDecimal remainAmount) {
        this.remainAmount = remainAmount;
    }

    public BigDecimal getPreviousBalance() {
        return previousBalance;
    }

    public void setPreviousBalance(BigDecimal previousBalance) {
        this.previousBalance = previousBalance;
    }

    public BigDecimal getWinAmount() {
        return winAmount;
    }

    public void setWinAmount(BigDecimal winAmount) {
        this.winAmount = winAmount;
    }

    public String getUpdateIdFlag() {
        return updateIdFlag;
    }

	public void setUpdateIdFlag(String updateIdFlag) {
		this.updateIdFlag = updateIdFlag;
	}
	public String getTermType() {
		return termType;
	}

	public void setTermType(String termType) {
		this.termType = termType;
	}

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
