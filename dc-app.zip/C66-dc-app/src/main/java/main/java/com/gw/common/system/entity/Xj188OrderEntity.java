package main.java.com.gw.common.system.entity;

import org.apache.abdera.model.DateTime;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class Xj188OrderEntity {

    private String memberCode;

    private String currencyCode;

    private String ipAddress;

    private String id;

    private String createTime;

    private String settleTime;

    private int wagerStatus;

    private BigDecimal stake;

    private BigDecimal returnAmount;

    private BigDecimal cashoutStake;

    private BigDecimal cashoutReturnAmount;

    private BigDecimal remainingStake;

    private BigDecimal remainingReturnAmount;

    private int channel;

    private int oddsType;

    private BigDecimal odds;

    private List<Xj188OrderDetailEntity> bets;

    public BigDecimal getCashoutStake() {
        return cashoutStake;
    }

    public void setCashoutStake(BigDecimal cashoutStake) {
        this.cashoutStake = cashoutStake;
    }

    public BigDecimal getCashoutReturnAmount() {
        return cashoutReturnAmount;
    }

    public void setCashoutReturnAmount(BigDecimal cashoutReturnAmount) {
        this.cashoutReturnAmount = cashoutReturnAmount;
    }

    public BigDecimal getRemainingStake() {
        return remainingStake;
    }

    public void setRemainingStake(BigDecimal remainingStake) {
        this.remainingStake = remainingStake;
    }

    public BigDecimal getRemainingReturnAmount() {
        return remainingReturnAmount;
    }

    public void setRemainingReturnAmount(BigDecimal remainingReturnAmount) {
        this.remainingReturnAmount = remainingReturnAmount;
    }

    public String getMemberCode() {
        return memberCode;
    }

    public void setMemberCode(String memberCode) {
        this.memberCode = memberCode;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getSettleTime() {
        return settleTime;
    }

    public void setSettleTime(String settleTime) {
        this.settleTime = settleTime;
    }

    public int getWagerStatus() {
        return wagerStatus;
    }

    public void setWagerStatus(int wagerStatus) {
        this.wagerStatus = wagerStatus;
    }

    public BigDecimal getStake() {
        return stake;
    }

    public void setStake(BigDecimal stake) {
        this.stake = stake;
    }

    public BigDecimal getReturnAmount() {
        return returnAmount;
    }

    public void setReturnAmount(BigDecimal returnAmount) {
        this.returnAmount = returnAmount;
    }

    public int getChannel() {
        return channel;
    }

    public void setChannel(int channel) {
        this.channel = channel;
    }

    public int getOddsType() {
        return oddsType;
    }

    public void setOddsType(int oddsType) {
        this.oddsType = oddsType;
    }

    public BigDecimal getOdds() {
        return odds;
    }

    public void setOdds(BigDecimal odds) {
        this.odds = odds;
    }

    public List<Xj188OrderDetailEntity> getBets() {
        return bets;
    }

    public void setBets(List<Xj188OrderDetailEntity> bets) {
        this.bets = bets;
    }
}
