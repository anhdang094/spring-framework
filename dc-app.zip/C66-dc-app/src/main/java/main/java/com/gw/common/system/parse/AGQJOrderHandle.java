package main.java.com.gw.common.system.parse;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Slf4j
public class AGQJOrderHandle {

    public List<Object> getAGQJOrderRecords(String url, Map<String, Object> parameterMap) throws Exception {
        List<Object> orderEntityList = new ArrayList<>();
        HttpUtil httpUtil = new HttpUtil();
        String result = httpUtil.doPost(url, parameterMap);
        // String result = "{\"code\":\"success\",\"data\":[{\"account\":20,\"agCode\":\"731001001001001\",\"billNo\":\"20080220261003\",\"billTime\":\"2020-08-03T08:41:32\",\"bonusAmount\":0,\"creationDate\":null,\"curIp\":\"10.66.73.131\",\"currency\":\"CNY\",\"currencyType\":0,\"currentAmount\":null,\"cusAccount\":0,\"cusAccountStr\":null,\"deviceType\":\"70\",\"flag\":1,\"gameKind\":null,\"gameType\":\"LINK\",\"gmCode\":\"FD051208021TC\",\"id\":1,\"isFreeGame\":null,\"isSpecia\":0,\"loginName\":\"etest1001\",\"odds\":null,\"oddsType\":null,\"orderType\":null,\"orignalBillTime\":\"2020-08-03T08:41:32\",\"orignalReckonTime\":\"1970-01-01T08:00:00\",\"orignalTimezone\":null,\"platId\":null,\"playType\":0,\"playTypeStr\":null,\"previosAmount\":0,\"productId\":\"B01\",\"reckonTime\":\"1970-01-01T08:00:00\",\"recordId\":null,\"remainAmount\":0,\"remark\":null,\"round\":null,\"tableCode\":\"D560\",\"topAgCode\":\"116\",\"validAccount\":0,\"validAccountStr\":null}]}";
        if (ToolUtil.isNeedInterceptResponse(parameterMap.get(UtilConstants.ORDER_TASK_ID) + "")) {
            log.info(" Intercept:TaskId={},Url={},Response={}", parameterMap.get(UtilConstants.ORDER_TASK_ID), url, result);
        }
        if (StringUtils.isEmpty(result)) {
            log.info("AGQJ Response empty Params:{}", parameterMap);
            return orderEntityList;
        }
        log.info(" AGQJ get AGQJ order record result:{}", result);
        JSONObject object = JSONObject.parseObject(result);
        JSONArray dataList = object.getJSONArray("data");
        if (dataList == null || dataList.isEmpty()) {
            return orderEntityList;
        }
        for (int i = 0; i < dataList.size(); i++) {
            JSONObject jsonObject = dataList.getJSONObject(i);
            OrderEntity agqjOrderEntity = JSON.toJavaObject(jsonObject, OrderEntity.class);
            OrderEntity orderEntity = new OrderEntity();
            orderEntity.setBillNo(agqjOrderEntity.getBillNo());
            String productId = agqjOrderEntity.getProductId();
            if (StringUtils.isNotBlank(agqjOrderEntity.getLoginName()) && agqjOrderEntity.getLoginName().startsWith(productId)) {
                String name = agqjOrderEntity.getLoginName().substring(productId.length());
                orderEntity.setLoginName(name);
            } else {
                orderEntity.setLoginName(agqjOrderEntity.getLoginName());
            }
            orderEntity.setAgCode(agqjOrderEntity.getAgCode());
            orderEntity.setTopAgCode("116");
            orderEntity.setProductId(agqjOrderEntity.getProductId());
            orderEntity.setPlatId(UtilConstants.AGQJ);
            orderEntity.setPreviosAmount(agqjOrderEntity.getPreviosAmount());//
            orderEntity.setAccount(agqjOrderEntity.getAccount());
            orderEntity.setValidAccount(agqjOrderEntity.getValidAccount());
            orderEntity.setCusAccount(agqjOrderEntity.getCusAccount());
            orderEntity.setGmCode(String.valueOf(agqjOrderEntity.getGmCode()));
            orderEntity.setBillTime(agqjOrderEntity.getBillTime());
            orderEntity.setOrignalBillTime(agqjOrderEntity.getBillTime());
            orderEntity.setOrignalReckonTime(agqjOrderEntity.getBillTime());
            orderEntity.setReckonTime(agqjOrderEntity.getBillTime());
            orderEntity.setFlag(1);
            orderEntity.setCurrency(agqjOrderEntity.getCurrency());
            orderEntity.setTableCode(agqjOrderEntity.getTableCode());
            orderEntity.setGameType(agqjOrderEntity.getGameType());
            orderEntity.setPlayType(agqjOrderEntity.getPlayType());
            orderEntity.setCurIp(agqjOrderEntity.getCurIp());
            orderEntity.setCreationDate(new Date());
            orderEntity.setRemark(agqjOrderEntity.getRemark());
            orderEntity.setCurrencyType(0);
            orderEntity.setId(1L);//
            orderEntity.setDeviceType(agqjOrderEntity.getDeviceType());
            orderEntity.setGameKind(UtilConstants.GAME_KIND_ENUM.VIDEO.getCode());
            orderEntity.setBonusAmount(BigDecimal.ZERO);
            orderEntity.setIsSpecia(0);
            orderEntity.setRemainAmount(agqjOrderEntity.getValidAccount());
            orderEntity.setTermType(agqjOrderEntity.getTermType());
            orderEntityList.add(orderEntity);
        }
        return orderEntityList;
    }

}
