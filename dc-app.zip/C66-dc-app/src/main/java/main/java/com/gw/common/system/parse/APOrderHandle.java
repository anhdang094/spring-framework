package main.java.com.gw.common.system.parse;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.common.framework.util.MD5;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.parse.vo.OrderRes;
import main.java.com.gw.common.system.props.CustomerPropertyholder;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Slf4j
public class APOrderHandle extends AbstractHandle {

    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        return null;
    }

    @Override
    public String retrieveData(String url, Map<String, Object> paramaterMap) throws GWCallRemoteApiException {
        String content = "";
        try {
            content = new HttpUtil().httpGet(url, paramaterMap);

        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new GWCallRemoteApiException("Failed to call remote interface!" + ex.getMessage(), ex);
        }

        return content;

    }

    /* 对接 gavin.h
     * 旧接口：http://10.9.2.85:8888/getGameOrdering?gplatform=12323213&productid=101&gameid=4&like=false&&begintime=2016/06/10%2000:00:00&endtime=2016/06/16%2023:59:59&page=1&num=25&order=tradetime&by=desc&key=42FC4B101E02E85F2222150AEDC0BD2F
     * 新接口：http://10.9.2.85:8888/getGameOrdering?gplatform=12323213&productid=101&startid=1000&recordsize=100&key=C944EF2E7D44A0DF70427688BE870925
     * 
     * 返回：
     * {
		  "responseaction": "getGameOrdering",
		  "Results": [
		    {
		      "recordid": 7731848,
		      "username": "test33",
		      "productid": "101",
		      "gametime": "2016-05-17 16:11:48",
		      "suminputcredit": 0,
		      "sumreckon": -200,
		      "tax": 0,
		      "taxrate": 0,
		      "jifen": 4,
		      "realinputcredit": 0,
		      "roomtype": 0,
		      "cur": "cny",
		      "game": "GDMJ3(????3)",
		      "round": "497OMFB",
		      "amountbefore": 1000,
		      "amountafter": 800,
		      "tradeno": "GDMJ37731848",
		      "dijin": 100
		    }
		  ]
		  "status": 0,
		  "errdesc": 0,
		  "totalrecords": 1621
	   }		
     */
    public static void main(String[] args) {
        Map<String, Object> paramaterMap = new HashMap<String, Object>();
        String baseUrl = "http://10.71.3.11:8888/getGameOrdering?";
        String gplatform = "044";
        paramaterMap.put("gplatform", gplatform);
        String productid = "B05";// "0";
        // String productid = "A05";// "0";
        paramaterMap.put("productid", productid);
        // String ptype = "";
        // String username = "";
        // String like = "";
        // String pnum = "";
        // String win = "";
        String roomtype = "1";
        String like = "false";
        String gameid = "3";
//        String begintime = "2016-11-08 00:00:00";
//        String endtime = "2016-11-08 23:59:59";
//        paramaterMap.put("begintime", begintime);
//        paramaterMap.put("endtime", endtime);
        String startid = "9816281";
        String recordsize = "100";
        paramaterMap.put("startid", startid);
        paramaterMap.put("recordsize", recordsize);
        paramaterMap.put("gameid", gameid);
        paramaterMap.put("like", like);
        //paramaterMap.put("roomtype", roomtype);
        String page = "1";
        paramaterMap.put("page", page);
        String num = "500";
        paramaterMap.put("num", num);
        String order = "gametime";
        paramaterMap.put("order", order);
        String by = "desc";
        paramaterMap.put("by", by);
        String key = MD5.md5Encoding(gplatform + productid + startid + recordsize + "enckey").toUpperCase();
        paramaterMap.put("key", key);
        String tmp_uri = "gplatform=%s&productid=%s&startid=%s&recordsize=%s&key=%s";
        tmp_uri = String.format(tmp_uri, gplatform, productid, startid, recordsize, key);
        System.out.println("请求地址= " + baseUrl + tmp_uri);

        AbstractHandle handle = new APOrderHandle();
        try {
            String result = handle.retrieveData(baseUrl, paramaterMap);
            System.out.println(result);
            System.out.println(handle.parse(result).getOrderList());
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    @Override
    public OrderRes parse(String content) throws GWCallRemoteApiException {
        try {

            content = new String(content.getBytes("UTF-8"), "GBK");
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        JSONObject obj = JSONObject.fromObject(content);
        OrderRes res = new OrderRes();
        String p_status = obj.optString("status");
        String p_errdesc = obj.optString("errdesc");
        res.setReturnCode(p_status);
        res.setComment(p_errdesc);
        if (!p_status.equals("0")) {
            throw new GWCallRemoteApiException(p_errdesc);
        }
        JSONArray arr = obj.optJSONArray("Results");
        if (arr != null) {
            res.setTotal(arr.size());
            JSONObject order_obj = null;
            String loginname = "";
            String pid = "";
            for (int i = 0; i < arr.size(); i++) {
                order_obj = arr.optJSONObject(i);
                OrderEntity order = new OrderEntity();
                loginname = order_obj.optString("username", "");
                pid = order_obj.optString("productid", "").toUpperCase();//因为有些数据平台类型为小写所以需要转换
                order.setLoginName(loginname.substring(4));
                order.setProductId(pid.toUpperCase());
                order.setGmCode(order_obj.optString("round", ""));
                order.setPlatId(UtilConstants.AP);
                String gameType = order_obj.optString("game", "");
                Integer index = gameType.indexOf("(");
                gameType = index > 0 ? gameType.substring(0, index) : "";
                order.setGameType(gameType);
                Date billTime = ToolUtil.transferUSEsternDateToCNEsternDate(DateUtil.formatStr2Date(order_obj.optString("gametime", "")));
                //WHM-1136  德州扑克、雀神麻将、牛牛三键合一

                resetGameKind(billTime, order, pid, gameType);


                order.setPlayType(10 * order_obj.optInt("dijin", 0));
                // TABLECODE
                order.setTableCode(order_obj.optString("deskid", ""));
                // RESULT抽水
                order.setResult(order_obj.optString("tax", ""));
                // CARD_LIST牌1牌2 公共牌
                order.setCardList(order_obj.optString("pai1", "") + UtilConstants.COMMA_SYMBOL + order_obj.optString("pai2", "")
                        + UtilConstants.COMMA_SYMBOL + order_obj.optString("paigg", ""));
                // 大盲 小盲 人数
                order.setRemark(order_obj.optString("sdijin", "") + UtilConstants.COMMA_SYMBOL + order_obj.optString("ldijin", "")
                        + UtilConstants.COMMA_SYMBOL + order_obj.optString("pnum", ""));
                // 投注额
                String amountStr = order_obj.optString("realinputcredit", "0");

                // 积分
                String validAccountStr = order_obj.optString("jifen", "0");
                String winStr = order_obj.optString("sumreckon", "0");
                String previosAmountStr = order_obj.optString("amountbefore", "0");
                order.setAccount(new BigDecimal(amountStr));
                order.setValidAccount(new BigDecimal(validAccountStr));

                order.setCusAccount(new BigDecimal(winStr));
                order.setPreviosAmount(new BigDecimal(previosAmountStr));
                order.setCurrentAmount(new BigDecimal(order_obj.optString("amountafter", "0")));

                // 桌子编号 注单时间 游戏类型 玩法类型 投注额 有效投注额 客户输赢度 原额度 现额度 货币 终端
                order.setBillTime(billTime);
                // 对战

                order.setBillNo(order_obj.optString("tradeno", ""));
                order.setFlag(1);
                Long recordId = order_obj.optLong("recordid");
                order.setRecordId(recordId);
                res.addOrder(order);
            }
        }
        return res;
    }

    // WHM-1136  德州扑克、雀神麻将、牛牛三键合一
    private void resetGameKind(Date billTime, OrderEntity order, String pid, String gameType) {

        if (StringUtils.isBlank(gameType)) {
            log.error("AP Timer 抓取数据的时候发现没有GameType");
            order.setGameKind(UtilConstants.GAME_KIND_ENUM.FIGHT.getCode());
            return;
        }

        String switchTime = CustomerPropertyholder.getProperty(pid.trim() + ".ap.startSwitch.time");
        if (StringUtils.isBlank(switchTime)) {
            log.error("AP Timer 抓取数据的时候发现没有GameType");
            order.setGameKind(UtilConstants.GAME_KIND_ENUM.FIGHT.getCode());
            return;
        }

        Date swithDate = DateUtil.formatStr2Date(switchTime);

        if (swithDate == null || swithDate.getTime() >= billTime.getTime()) {
            //旧的还是保持原来的一样
            if ("DZPK".equalsIgnoreCase(gameType)) {
                order.setGameKind(UtilConstants.GAME_KIND_ENUM.FIGHT.getCode());
            } else if ("GDMJ3".equalsIgnoreCase(gameType)) {
                order.setGameKind(UtilConstants.GAME_KIND_ENUM.MAHJONG.getCode());
            } else if ("NIUNIU".equalsIgnoreCase(gameType)) {
                order.setGameKind(UtilConstants.GAME_KIND_ENUM.NIUNIU.getCode());
            } else {
                order.setGameKind(UtilConstants.GAME_KIND_ENUM.FIGHT.getCode());
            }
        } else {
            order.setGameKind(UtilConstants.GAME_KIND_ENUM.FIGHT.getCode());
        }


    }
}
