package main.java.com.gw.common.system.parse;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.common.framework.util.MD5;
import main.java.com.gw.common.system.parse.vo.Result;
import main.java.com.gw.common.system.parse.vo.TransRes;
import main.java.com.gw.datacenter.accounttransfer.entity.AccountTransferEntity;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@Slf4j
public class APTransHandle extends AbstractHandle {

    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        return null;
    }

    @Override
    public String retrieveData(String url, Map<String, Object> paramaterMap) throws GWCallRemoteApiException {
        String content = "";
        try {
            content = new HttpUtil().httpGet(url, paramaterMap);
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new GWCallRemoteApiException("Failed to call remote interface!" + ex.getMessage(), ex);
        }
        return content;
    }

    public static void main(String[] args) {
        Map<String, Object> paramaterMap = new HashMap<String, Object>();
        String baseUrl = "http://www.agpok.com:8886/getDzpkCharge?";

        String gplatform = "044";
        paramaterMap.put("gplatform", gplatform);
        String productid = "A01";
        paramaterMap.put("productid", productid);
        String like = "false";
        String roomtype = "1";
        paramaterMap.put("like", like);
        String begintime = "2017-07-04 00:00:00";
        String endtime = "2017-07-14 23:59:59";
        paramaterMap.put("begintime", begintime);
        paramaterMap.put("endtime", endtime);
        paramaterMap.put("roomtype", roomtype);
        String page = "1";
        paramaterMap.put("page", page);
        String num = "400";
        paramaterMap.put("num", num);
        String order = "tradetime";
        paramaterMap.put("order", order);
        String by = "desc";
        paramaterMap.put("by", by);
        String key = MD5.md5Encoding(gplatform + productid + like + roomtype + begintime + endtime + page + num + order + by + "enckey").toUpperCase();
        paramaterMap.put("key", key);

        AbstractHandle handle = new APTransHandle();
        try {
            String result = handle.retrieveData(baseUrl, paramaterMap);
            Result res = handle.parse(result);
            System.out.println(result);
            System.out.println(res.getOrderList());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public TransRes parse(String content) throws GWCallRemoteApiException {
        JSONObject obj = JSONObject.fromObject(content);
        TransRes res = new TransRes();
        String p_status = obj.optString("status");
        String p_errdesc = obj.optString("errdesc");
        if (!p_status.equals("0")) {
            throw new GWCallRemoteApiException(p_errdesc);
        }
        JSONObject p_obj = obj.optJSONObject("pagination");
        if (p_obj != null) {
            res.setPerpage(p_obj.optInt("pagenum"));
            res.setTotal(p_obj.optInt("totalrecords"));
            JSONArray arr = obj.optJSONArray("Results");
            JSONObject trans_obj = null;
            String loginname = "";
            String pid = "";
            for (int i = 0; i < arr.size(); i++) {
                trans_obj = arr.optJSONObject(i);
                AccountTransferEntity trans = new AccountTransferEntity();
                loginname = trans_obj.optString("username", "");
                pid = trans_obj.optString("productid", "");
                String transferTime = trans_obj.optString("tradetime", "");
                trans.setUserName(loginname.substring(4));
                trans.setProductId(pid.toUpperCase());
                // trans.setAgCode(trans_obj.optString("KIOSKNAME", ""));
                trans.setTime__0to12(transferTime);
                trans.setTransferAmount(new BigDecimal(trans_obj.optString("tradeamount", "0")));
                trans.setPreviousAmount(new BigDecimal(trans_obj.optString("tradesrcamount", "0")));
                trans.setCurrentAmount(new BigDecimal(trans_obj.optString("tradedstamount", "0")));
                // trans.setIP(trans_obj.optString("REMOTEIP", "0"));
                // 需要在转换
                String transferType = trans_obj.optString("tradeaction", "");
                trans.setTransferType(transferType);


                String tradeid = trans_obj.optString("tradeid", "");
                if (transferType.equalsIgnoreCase(UtilConstants.TRANSFER_TYPE_AP_DEPOSIT) ||
                        transferType.equalsIgnoreCase(UtilConstants.TRANSFER_TYPE_AP_WITHFRAW) ||
                        StringUtils.isEmpty(tradeid)) {
                    tradeid = trans_obj.optString("tradeno", "");

                }


                trans.setTransId(tradeid);

                trans.setPlatformId(UtilConstants.AP);
                trans.setRemark(trans_obj.optString("round", ""));
                res.addOrder(trans);
            }

        }
        return res;
    }
}
