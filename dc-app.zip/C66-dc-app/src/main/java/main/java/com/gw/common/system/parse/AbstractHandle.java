package main.java.com.gw.common.system.parse;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.common.system.parse.vo.Result;
import org.apache.commons.digester3.Digester;

import java.io.File;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Slf4j
public abstract class AbstractHandle {

    // PDATACENTER-845 PT_KEY 证书文件移动到conf/saconfig/secure文件夹下 add by walter 2018-10-29
    protected static final String PT_KEY_DIR = "conf" + File.separator + "saconfig" + File.separator + "secure";

    protected int timeOut_PT = 10 * 1000;

    protected Map<String, Serializable> params = null;

    public void addParam(String name, Serializable value) {
        if (params == null) {
            params = new HashMap<>();
        }
        params.put(name, value);
    }

    public void resetParam() {
        if (params == null) {
            params = new HashMap<>();
        }
        params.clear();
    }

    /**
     * get Whole URL
     *
     * @param paramaterMap
     * @return
     */
    public abstract String getUrl(Map<String, Object> paramaterMap);

    public Result parse(String xml) throws GWCallRemoteApiException {
        Digester d = new Digester();
        d.setValidating(false);
        parseRules(d);
        try {
            d.parse(new java.io.StringReader(xml));
        } catch (Exception e) {
            log.info(xml);
            log.error(e.getMessage(), e);
            throw new GWCallRemoteApiException("parse" + e);
        }
        return d.getRoot();
    }

    public Result parse(String xml, String lable) {
        Digester d = new Digester();
        d.setValidating(false);
        parseRules(d, lable);
        try {
            d.parse(new java.io.StringReader(xml));
        } catch (Exception e) {
            log.info(xml);
            log.error(e.getMessage(), e);
        }
        return d.getRoot();
    }

    /**
     * Parse XML Rule
     *
     * @param d
     */
    public void parseRules(Digester d) {

    }

    /**
     * Parse XML Rule
     *
     * @param d
     */
    public void parseRules(Digester d, String lable) {

    }

    public String retrieveData(Map<String, Object> paramaterMap) throws Exception {
        String content = "";
        String wholeRrl = null;
        try {
            wholeRrl = getUrl(paramaterMap);
            log.info("whole url ===>" + wholeRrl);
            if (wholeRrl != null) {
                content = new HttpUtil().doGet(wholeRrl);
//                log.info("productId:{},response:{}",paramaterMap.get("productId"),content);
            }
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            log.error("Call remote interface failure with URL:" + wholeRrl);
            throw new GWCallRemoteApiException("Failed to call remote interface!" + ex.getMessage(), ex);
        }
        return content;

    }

    private String getValueByKeyNotEncode(Map<String, Object> paramaterMap, String key) {
        Object o = paramaterMap.get(key);
        if (o instanceof String) {
            return (String) o;
        }
        if (o instanceof Number) {
            return o.toString();
        }
        if (o instanceof Date) {
            return DateUtil.formatDate2Str((Date) o);
        }
        return "";
    }

    protected String getValueByKey(Map<String, Object> paramaterMap, String key) {
        return getValueByKey(paramaterMap, key, true);
    }

    protected String getValueByKey(Map<String, Object> paramaterMap, String key, boolean encode) {
        String value = getValueByKeyNotEncode(paramaterMap, key);
        if (!encode) {
            return value;
        }
        try {
            return URLEncoder.encode(getValueByKeyNotEncode(paramaterMap, key), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            log.error("AbstractHandle getValueByKey error:" + e.getMessage(), e);
        }
        return "";
    }

    public String retrieveData(String url, Map<String, Object> parameterMap) throws GWCallRemoteApiException {
        return null;
    }

    public Result parse(String content, String productId, String platFormId) {
        return null;
    }

    public String retrieveData() {
        return "";
    }

    public Integer getFlag(String state) {
        return null;
    }
}
