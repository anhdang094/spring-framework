package main.java.com.gw.common.system.parse;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.common.framework.util.MD5;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.parse.vo.OrderRes;
import main.java.com.gw.common.system.parse.vo.Result;
import main.java.com.gw.common.system.timer.Order4AGINNewFishGameTimer;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import net.sf.json.JSON;
import org.apache.commons.digester3.Digester;
import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.XML;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

@Slf4j
public class AginFishNewHandle extends AbstractHandle {

    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        String baseUrl = (String) paramaterMap.get("baseUrl");
        String begintimeStr = (String) paramaterMap.get("begintime");
        String endtimeStr = (String) paramaterMap.get("endtime");
//        Date d = DateUtil.formatStr2Date(begintimeStr);
//        Date d1 = DateUtil.formatStr2Date(endtimeStr);
        String productid = (String) paramaterMap.get("productId");
//        String pidtoken = (String) paramaterMap.get("pidtoken");
        String begintime = Order4AGINNewFishGameTimer.Date2TimeStamp(begintimeStr,DateUtil.C_TIME_PATTON_DEFAULT);
        String endtime = Order4AGINNewFishGameTimer.Date2TimeStamp(endtimeStr,DateUtil.C_TIME_PATTON_DEFAULT);
//        begintime = begintime.substring(0, 10);
//        endtime = endtime.substring(0, 10);
//        String order = "time";
        int numperpage = Integer.valueOf((String) paramaterMap.get(UtilConstants.ORDER_PAGE_NUMBER));
        int page = Integer.valueOf((String) paramaterMap.get("page"));
//        String by = "desc";
        String str = (String) paramaterMap.get("pidtoken");
        String source=productid+begintime+endtime+page+numperpage+str;
        String sessionkey = MD5.MD5Encode(source);
        String act = (String) paramaterMap.get("act");
//        String tmp_uri = "?act=%s&pidtoken=%s&begintime=%s&endtime=%s&numperpage=%s&order=%s&page=%s&productid=%s&sessionkey=%s";
        String url = String.format("%s?cagent=%s&startdate=%s&enddate=%s&perpage=%s&page=%s&key=%s",baseUrl,productid,begintime,endtime,numperpage,page,sessionkey);
        log.info("AginFishNewHandle request to aginfish:{}",url);
        return url;
    }
//    @Override
//    public String retrieveData(Map<String, Object> paramaterMap) throws Exception {
////        String xml =
////                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><result><info>0</info><row billno=\"15662746521337243\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"444\" fishcost=\"200\" hunted=\"0\" billtime=\"1566274652\" reckontime=\"1566274652\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"63.650000\" dst_amount=\"62.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746541338803\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"475\" fishcost=\"2\" hunted=\"0\" billtime=\"1566274653\" reckontime=\"1566274653\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"62.650000\" dst_amount=\"61.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746541339823\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"480\" fishcost=\"700\" hunted=\"0\" billtime=\"1566274653\" reckontime=\"1566274653\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"61.650000\" dst_amount=\"60.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746551340743\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"444\" fishcost=\"200\" hunted=\"0\" billtime=\"1566274654\" reckontime=\"1566274654\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"60.650000\" dst_amount=\"59.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746561341923\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"444\" fishcost=\"200\" hunted=\"0\" billtime=\"1566274656\" reckontime=\"1566274656\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"59.650000\" dst_amount=\"58.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746571343753\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"480\" fishcost=\"700\" hunted=\"0\" billtime=\"1566274657\" reckontime=\"1566274657\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"58.650000\" dst_amount=\"57.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746581344723\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"480\" fishcost=\"700\" hunted=\"0\" billtime=\"1566274657\" reckontime=\"1566274657\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"57.650000\" dst_amount=\"56.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746591345553\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"480\" fishcost=\"700\" hunted=\"0\" billtime=\"1566274658\" reckontime=\"1566274658\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"56.650000\" dst_amount=\"55.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746591346833\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"480\" fishcost=\"700\" hunted=\"0\" billtime=\"1566274658\" reckontime=\"1566274658\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"55.650000\" dst_amount=\"54.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746601348213\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"480\" fishcost=\"700\" hunted=\"0\" billtime=\"1566274660\" reckontime=\"1566274660\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"54.650000\" dst_amount=\"53.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746611349153\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"498\" fishcost=\"8\" hunted=\"0\" billtime=\"1566274661\" reckontime=\"1566274661\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"53.650000\" dst_amount=\"52.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746621350373\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"480\" fishcost=\"700\" hunted=\"0\" billtime=\"1566274661\" reckontime=\"1566274661\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"52.650000\" dst_amount=\"51.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746631351503\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"480\" fishcost=\"700\" hunted=\"0\" billtime=\"1566274662\" reckontime=\"1566274662\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"51.650000\" dst_amount=\"50.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746631352543\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"480\" fishcost=\"700\" hunted=\"0\" billtime=\"1566274662\" reckontime=\"1566274662\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"50.650000\" dst_amount=\"49.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746641353483\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"480\" fishcost=\"700\" hunted=\"0\" billtime=\"1566274664\" reckontime=\"1566274664\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"49.650000\" dst_amount=\"48.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746651354403\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"480\" fishcost=\"700\" hunted=\"0\" billtime=\"1566274665\" reckontime=\"1566274665\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"48.650000\" dst_amount=\"47.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746671357063\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"482\" fishcost=\"180\" hunted=\"0\" billtime=\"1566274667\" reckontime=\"1566274667\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"47.650000\" dst_amount=\"46.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746681358733\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"482\" fishcost=\"180\" hunted=\"0\" billtime=\"1566274668\" reckontime=\"1566274668\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"46.650000\" dst_amount=\"45.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746691360753\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"506\" fishcost=\"8\" hunted=\"0\" billtime=\"1566274669\" reckontime=\"1566274669\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"45.650000\" dst_amount=\"44.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746711362143\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"495\" fishcost=\"80\" hunted=\"0\" billtime=\"1566274671\" reckontime=\"1566274671\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"44.650000\" dst_amount=\"43.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><addition><total>53</total><num_per_page>20</num_per_page><currentpage>1</currentpage><totalpage>3</totalpage><perpage>20</perpage></addition></result>";
////        ;
////        String xml =
////                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><result><info>0</info><addition><total>0</total><num_per_page>20</num_per_page><currentpage>1</currentpage><totalpage>0</totalpage><perpage>0</perpage></addition></result>";
//;
//        String xml =
//                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n" +
//                        "\t<result>\n" +
//                        "\t\t<info>0</info>\n" +
////                        "\t\t<row billno=\"15662746711362143\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"495\" fishcost=\"80\" hunted=\"0\" billtime=\"1566274671\" reckontime=\"1566274671\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"44.650000\" dst_amount=\"43.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" />\n" +
//                        "\t\t<row billno=\"1001582619629060881\" productid=\"B07\" username=\"u0119oy67\" roomid=\"301\" betx=\"2\" sceneid=\"15826195290301\" fishid=\"243\" fishcost=\"60\" hunted=\"0\" billtime=\"1582619628\" reckontime=\"1582619628\" currency=\"CNY\" account=\"2\" cus_account=\"-2\" valid_account=\"2\" src_amount=\"84806.706600\" dst_amount=\"84804.706600\" betIp=\"113.243.220.54\" gametype=\"HMFP\" devicetype=\"0\" jackpotcontribute=\"0\" flag=\"1\"/>\n" +
//                        "\t\t<addition>\n" +
//                        "\t\t\t<total>53</total>\n" +
//                        "\t\t\t<num_per_page>20</num_per_page>\n" +
//                        "\t\t\t<currentpage>1</currentpage>\n" +
//                        "\t\t\t<totalpage>3</totalpage>\n" +
//                        "\t\t\t<perpage>20</perpage>\n" +
//                        "\t\t</addition>\n" +
//                        "\t</result>";
//        return xml;
//    }

    public static void main(String[] args) throws GWCallRemoteApiException {
        String myKey = "421EDD85303CF8FAAED9115BFE0689A3";
        String url="http://gsapi.casino6888.com:3335/gethunterorders.xml";
        String cagent="B07";
        String startdate= Order4AGINNewFishGameTimer.Date2TimeStamp("2019-08-20 12:10:00","yyyy-MM-dd HH:mm:ss");
        String enddate= Order4AGINNewFishGameTimer.Date2TimeStamp("2019-08-20 12:20:00","yyyy-MM-dd HH:mm:ss");
        String perpage="20";
        String page="1";
        String source=cagent+startdate+enddate+page+perpage+myKey;
        System.out.println(source);
        String key= MD5.MD5Encode(source);

        String curl = String.format("%s?cagent=%s&startdate=%s&enddate=%s&perpage=%s&page=%s&key=%s",url,cagent,startdate,enddate,perpage,page,key);
        System.out.println(curl);

        AbstractHandle handle = new AginFishNewHandle();
//        String xml =
//                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><result><info>0</info><row billno=\"15662746521337243\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"444\" fishcost=\"200\" hunted=\"0\" billtime=\"1566274652\" reckontime=\"1566274652\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"63.650000\" dst_amount=\"62.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746541338803\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"475\" fishcost=\"2\" hunted=\"0\" billtime=\"1566274653\" reckontime=\"1566274653\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"62.650000\" dst_amount=\"61.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746541339823\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"480\" fishcost=\"700\" hunted=\"0\" billtime=\"1566274653\" reckontime=\"1566274653\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"61.650000\" dst_amount=\"60.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746551340743\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"444\" fishcost=\"200\" hunted=\"0\" billtime=\"1566274654\" reckontime=\"1566274654\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"60.650000\" dst_amount=\"59.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746561341923\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"444\" fishcost=\"200\" hunted=\"0\" billtime=\"1566274656\" reckontime=\"1566274656\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"59.650000\" dst_amount=\"58.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746571343753\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"480\" fishcost=\"700\" hunted=\"0\" billtime=\"1566274657\" reckontime=\"1566274657\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"58.650000\" dst_amount=\"57.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746581344723\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"480\" fishcost=\"700\" hunted=\"0\" billtime=\"1566274657\" reckontime=\"1566274657\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"57.650000\" dst_amount=\"56.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746591345553\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"480\" fishcost=\"700\" hunted=\"0\" billtime=\"1566274658\" reckontime=\"1566274658\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"56.650000\" dst_amount=\"55.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746591346833\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"480\" fishcost=\"700\" hunted=\"0\" billtime=\"1566274658\" reckontime=\"1566274658\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"55.650000\" dst_amount=\"54.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746601348213\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"480\" fishcost=\"700\" hunted=\"0\" billtime=\"1566274660\" reckontime=\"1566274660\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"54.650000\" dst_amount=\"53.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746611349153\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"498\" fishcost=\"8\" hunted=\"0\" billtime=\"1566274661\" reckontime=\"1566274661\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"53.650000\" dst_amount=\"52.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746621350373\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"480\" fishcost=\"700\" hunted=\"0\" billtime=\"1566274661\" reckontime=\"1566274661\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"52.650000\" dst_amount=\"51.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746631351503\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"480\" fishcost=\"700\" hunted=\"0\" billtime=\"1566274662\" reckontime=\"1566274662\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"51.650000\" dst_amount=\"50.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746631352543\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"480\" fishcost=\"700\" hunted=\"0\" billtime=\"1566274662\" reckontime=\"1566274662\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"50.650000\" dst_amount=\"49.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746641353483\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"480\" fishcost=\"700\" hunted=\"0\" billtime=\"1566274664\" reckontime=\"1566274664\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"49.650000\" dst_amount=\"48.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746651354403\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"480\" fishcost=\"700\" hunted=\"0\" billtime=\"1566274665\" reckontime=\"1566274665\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"48.650000\" dst_amount=\"47.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746671357063\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"482\" fishcost=\"180\" hunted=\"0\" billtime=\"1566274667\" reckontime=\"1566274667\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"47.650000\" dst_amount=\"46.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746681358733\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"482\" fishcost=\"180\" hunted=\"0\" billtime=\"1566274668\" reckontime=\"1566274668\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"46.650000\" dst_amount=\"45.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746691360753\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"506\" fishcost=\"8\" hunted=\"0\" billtime=\"1566274669\" reckontime=\"1566274669\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"45.650000\" dst_amount=\"44.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><row billno=\"15662746711362143\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"495\" fishcost=\"80\" hunted=\"0\" billtime=\"1566274671\" reckontime=\"1566274671\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"44.650000\" dst_amount=\"43.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" /><addition><total>53</total><num_per_page>20</num_per_page><currentpage>1</currentpage><totalpage>3</totalpage><perpage>20</perpage></addition></result>";
        String xml =
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n" +
                        "\t<result>\n" +
                        "\t\t<info>0</info>\n" +
//                        "\t\t<row billno=\"15662746711362143\" productid=\"B07\" username=\"u0119oy67\" roomid=\"5\" betx=\"1\" sceneid=\"15662744020005\" fishid=\"495\" fishcost=\"80\" hunted=\"0\" billtime=\"1566274671\" reckontime=\"1566274671\" currency=\"CNY\" account=\"1\" cus_account=\"-1\" valid_account=\"1\" src_amount=\"44.650000\" dst_amount=\"43.650000\" betIp=\"113.243.220.54\" gametype=\"HM3D\" devicetype=\"1\" jackpotcontribute=\"0\" flag=\"1\" />\n" +
                        "\t\t<row billno=\"1001582619629060881\" productid=\"B07\" username=\"u0119oy67\" roomid=\"301\" betx=\"2\" sceneid=\"15826195290301\" fishid=\"243\" fishcost=\"60\" hunted=\"0\" billtime=\"1582619628\" reckontime=\"1582619628\" currency=\"CNY\" account=\"2\" cus_account=\"-2\" valid_account=\"2\" src_amount=\"84806.706600\" dst_amount=\"84804.706600\" betIp=\"113.243.220.54\" gametype=\"HMFP\" devicetype=\"0\" jackpotcontribute=\"0\" flag=\"1\"/>\n" +
                        "\t\t<addition>\n" +
                        "\t\t\t<total>53</total>\n" +
                        "\t\t\t<num_per_page>20</num_per_page>\n" +
                        "\t\t\t<currentpage>1</currentpage>\n" +
                        "\t\t\t<totalpage>3</totalpage>\n" +
                        "\t\t\t<perpage>20</perpage>\n" +
                        "\t\t</addition>\n" +
                        "\t</result>";
        Result res = handle.parse(xml);
        JSONObject obj = new JSONObject(res);
        System.out.println(obj.toString());

    }

    @Override
    public OrderRes parse(String content) throws GWCallRemoteApiException {
        JSONObject obj = XML.toJSONObject(content);
        obj = obj.optJSONObject("result");
        JSONObject addition = obj.optJSONObject("addition");
        JSONArray rows = obj.optJSONArray("row");
        if (rows == null && obj.optJSONObject("row") != null){
            rows = new JSONArray().put(obj.optJSONObject("row"));
        }

        OrderRes orderRes = new OrderRes();
        orderRes.setCode(obj.optString("info"));
        orderRes.setPerpage(addition.optInt("perpage"));
        orderRes.setTotal(addition.optInt("total"));
        orderRes.setCurrentPage(addition.optInt("currentpage"));
        orderRes.setNumpage(addition.optInt("num_per_page"));
        orderRes.setTotalPages(addition.optInt("totalpage"));

        if(rows !=null) {
            for (int i = 0; i < rows.length(); i++) {

                JSONObject row = rows.optJSONObject(i);
                OrderEntity order = new OrderEntity();

                order.setBillNo(row.optString("billno"));
                order.setPreviosAmount(new BigDecimal(row.optString("src_amount")));
                BigDecimal jackpotcontribute = StringUtils.isBlank(row.optString("jackpotcontribute")) ? BigDecimal.ZERO : new BigDecimal(row.optString("jackpotcontribute"));//add by ziv 2019-09-04
                order.setCusAccount(new BigDecimal(row.optString("cus_account")).subtract(jackpotcontribute));
                order.setCurrentAmount(new BigDecimal(row.optString("dst_amount")));
                order.setAccount(new BigDecimal(row.optString("account")));
                order.setValidAccount(new BigDecimal(row.optString("valid_account")));
                order.setRound(row.optString("sceneid"));
                order.setGmCode(row.optString("sceneid"));
                order.setPlayType(row.optInt("betx"));
                order.setUnixTimeStampToDate(row.optString("reckontime"));
                order.setProductId(row.optString("productid"));
                order.setLoginName(row.optString("username"));
                order.setGameType(UtilConstants.AGIN_FISHING); /** 不管捕鱼新增什么游戏类型，这里都不要修改，因为页面上面直接代码进行了判断，只认FISH, RAISEFISH */
                order.setDefaultFlag();

                orderRes.addOrder(order);
            }
        }

        return orderRes;
    }



    /**
     * @Description: 查询Agin投注额度
     * @Author: wythe
     * @Date: 2018/7/26 11:47
     */
    public BigDecimal getAginTotalBetAmount(Map<String, Object> paramaterMap) throws Exception {
        BigDecimal totalBets = BigDecimal.ZERO;
        try {
            log.info("getAginTotalBetAmount paramMapTemp:" + paramaterMap);
            String url = getUrl(paramaterMap);//URL地址
            log.info("获取URL地址getAginTotalBetAmount=" + url + "<>>>>>>>>>>>>>>>>>>>>>>");
            String xmlValue = new HttpUtil().doGet(url);//获取远程数据
            //测试数据
            //String xmlValue="<?xml version=\"1.0\" ?>\n" + "<OrderRes>\n" + "<Code>0</Code>\n" + "<Total>1</Total>\n" + "<TotalCashPay>1000</TotalCashPay>\n" + "<TotalCashBalance>输赢额度总计</TotalCashBalance>\n" + "<perpage>50</perpage>\n" + "<numpage>1 </numpage>\n" + "<Bill>\n" + " <BillId>单号</BillId>\n" + " <UserId>2</UserId>\n" + " <UserCashBefore>10000</UserCashBefore>\n" + " <UserCashDelta>-6</UserCashDelta>\n" + " <UserCashCurrent>9994</UserCashCurrent>\n" + " <UserCashEarn>捕鱼总收入</UserCashEarn>\n" + " <UserCashPay>捕鱼总支出</UserCashPay>\n" + " <Time>2014-07-23 19:22:35</Time>\n" + " <ProductId>01 </ProductId>\n" + " <UserName>rse9s80</UserName>\n" + " <HitInfo>\n" + " <CannonId>炮类型号</CannonId>\n" + " <CannonCost>炮单价</CannonCost>\n" + " <Boost>炮倍数</Boost>\n" + " <FishNum>1</FishNum>\n" + " <FishMiss> #未打中的鱼\n" + " <Type>鱼类型</Type>\n" + " <Num>条数</Num>\n" + " <Cost>鱼单价</Cost>\n" + " </FishMiss>\n" + "   <FishHit>#打中的鱼\n" + " <Type>鱼类型</Type>\n" + " <Num>条数</Num>\n" + " <Cost>鱼单价</Cost>\n" + " </FishHit>\n" + " </HitInfo>\n" + "</Bill>\n" + " </OrderRes>";
            /*String xmlValue="<?xml version=\"1.0\" ?>\n" +
                    "<OrderRes>\n" +
					"    <Code>0</Code>\n" +
					"    <Total>18543</Total>\n" +
					"    <TotalCashPay>97637.59999999999</TotalCashPay>\n" +
					"    <TotalCashBalance>-11836.879999999997</TotalCashBalance>\n" +
					"    <perpage>1600</perpage>\n" +
					"    <numpage>1</numpage>\n" +
					"    <TotalJackpotComm>460.47969999999907</TotalJackpotComm>\n" +
					"    <TotalComm>0</TotalComm>\n" +
					"    <Bill>\n" +
					"        <RoomId>2160</RoomId>\n" +
					"        <RoomBet>0.1</RoomBet>\n" +
					"        <UserId>179893</UserId>\n" +
					"        <BombFish>false</BombFish>\n" +
					"        <Hunted>false</Hunted>\n" +
					"        <FishType>101</FishType>\n" +
					"        <FishLife>5125</FishLife>\n" +
					"        <FishId>3887838809</FishId>\n" +
					"        <CannonBoost>1</CannonBoost>\n" +
					"        <CannonCost>10</CannonCost>\n" +
					"        <FishCost>20</FishCost>\n" +
					"        <UserCashBefore>27.64</UserCashBefore>\n" +
					"        <UserCashDelta>-1</UserCashDelta>\n" +
					"        <UserCashCurrent>26.64</UserCashCurrent>\n" +
					"        <SceneId>21601533218389</SceneId>\n" +
					"        <Time>1533218401</Time>\n" +
					"        <UserCashPay>1</UserCashPay>\n" +
					"        <UserCashEarn>0</UserCashEarn>\n" +
					"        <UserName>f252922</UserName>\n" +
					"        <ProductId>A03</ProductId>\n" +
					"        <UserType></UserType>\n" +
					"        <BillId>0017989300000008038491</BillId>\n" +
					"        <JackPotComm>0.002</JackPotComm>\n" +
					"        <OperType>1</OperType>\n" +
					"    </Bill>\n" +
					"</OrderRes>";*/
            //AGIN返回的注单数据
            String valueZhuDanData = "<OrderRes>\\n\" +\n" +
                    "                        \"<Code>0</Code>\\n\" +\n" +
                    "                        \"<Total>606</Total>\\n\" +\n" +
                    "                        \"<TotalCashPay>15590.3</TotalCashPay>\\n\" +\n" +
                    "                        \"<TotalCashBalance>-11547.17</TotalCashBalance>\\n\" +\n" +
                    "                        \"<perpage>1600</perpage>\\n\" +\n" +
                    "                        \"<numpage>1</numpage>\\n\" +\n" +
                    "                        \"<totaljackpotcomm>77.94700000000003</totaljackpotcomm>\\n\" +\n" +
                    "                        \"<totalcomm>-701.5635000000005</totalcomm>\\n\" +\n" +
                    "                        \"<Bill>\\n\" +\n" +
                    "                        \"<roomid>133</roomid>\\n\" +\n" +
                    "                        \"<RoomBet>0.2</RoomBet>\\n\" +\n" +
                    "                        \"<userid>6228456</userid>\\n\" +\n" +
                    "                        \"<bombfish>false</bombfish>\\n\" +\n" +
                    "                        \"<hunted>false</hunted>\\n\" +\n" +
                    "                        \"<fishtype>8</fishtype>\\n\" +\n" +
                    "                        \"<fishlife>3721</fishlife>\\n\" +\n" +
                    "                        \"<fishid>2283161534</fishid>\\n\" +\n" +
                    "                        \"<cannonboost>2</cannonboost>\\n\" +\n" +
                    "                        \"<cannoncost>10</cannoncost>\\n\" +\n" +
                    "                        \"<fishcost>50</fishcost>\\n\" +\n" +
                    "                        \"<UserCashBefore>5076.06</UserCashBefore>\\n\" +\n" +
                    "                        \"<UserCashDelta>-4</UserCashDelta>\\n\" +\n" +
                    "                        \"<UserCashCurrent>5072.06</UserCashCurrent>\\n\" +\n" +
                    "                        \"<SceneId>1331537339761</SceneId>\\n\" +\n" +
                    "                        \"<Time>1537339919</Time>\\n\" +\n" +
                    "                        \"<usercashpay>4</usercashpay>\\n\" +\n" +
                    "                        \"<usercashearn>0</usercashearn>\\n\" +\n" +
                    "                        \"<UserName>fmob7401</UserName>\\n\" +\n" +
                    "                        \"<ProductId>A03</ProductId>\\n\" +\n" +
                    "                        \"<usertype></usertype>\\n\" +\n" +
                    "                        \"<BillId>0622845600000000877960</BillId>\\n\" +\n" +
                    "                        \"<JackPotComm>0.02</JackPotComm>\\n\" +\n" +
                    "                        \"<opertype>1</opertype>\\n\" +\n" +
                    "                        \"</Bill>\\n\" +\n" +
                    "                        \"</OrderRes>\"";

            if (ToolUtil.isNeedInterceptResponse(paramaterMap.get(UtilConstants.ORDER_TASK_ID) + "")) {
                log.info("Intercept:TaskId=" + paramaterMap.get(UtilConstants.ORDER_TASK_ID) + ",Url=" + url + ",Response=" + xmlValue);
            }
            if (StringUtils.isNotBlank(xmlValue)) {
                Document balanceXml = DocumentHelper.parseText(xmlValue);
                Element totalCashPay = balanceXml.getRootElement().element("TotalCashPay");
                String totalCashPayValue = totalCashPay.getText();
                log.info("获取接口总数据getAginTotalBetAmount=" + totalCashPayValue + "<>>>>>>>>>>>>>>>>>>>>>>");
                totalBets = new BigDecimal(totalCashPayValue);
            }
        } catch (Exception e) {
            log.error("getTotalBetAmount error", e);
            throw e;
        }
        return totalBets;
    }


}
