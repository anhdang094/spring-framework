package main.java.com.gw.common.system.parse;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.exception.GWPersistenceException;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.system.parse.vo.OrderRes;
import main.java.com.gw.common.system.parse.vo.Result;
import main.java.com.gw.datacenter.order.dao.OrderDao;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.digester3.Digester;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.context.support.FileSystemXmlApplicationContext;

/**
 * <pre>
 * @Overview: BTTM-1434 新增养鱼功能, 文档见svn://10.66.72.114/team/game-api/AGIN/hunter gdc接口(5).pdf
 * @author: Richard.C
 * @History:
 *              date         author     JIRA NO.  method  function
 *            -------------------------------------------------------------------
 *             2017年2月22日   Richard.C    BTTM-1434 create   create
 *
 *            -------------------------------------------------------------------
 */
public class AginFishRaiseFishHandle extends AbstractHandle {

    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        String baseUrl = (String) paramaterMap.get("baseUrl");
        String begintimeStr = (String) paramaterMap.get("begintime");
        String endtimeStr = (String) paramaterMap.get("endtime");
        Date d = DateUtil.formatStr2Date(begintimeStr);
        Date d1 = DateUtil.formatStr2Date(endtimeStr);
        String productid = (String) paramaterMap.get("productId");
        String pidtoken = (String) paramaterMap.get("pidtoken");
        String begintime = String.valueOf(d.getTime());
        String endtime = String.valueOf(d1.getTime());
        begintime = begintime.substring(0, 10);
        endtime = endtime.substring(0, 10);
        String order = "time";
        int numperpage = Integer.valueOf((String) paramaterMap.get(UtilConstants.ORDER_PAGE_NUMBER));
        int page = Integer.valueOf((String) paramaterMap.get("page"));
        String by = "desc";
        String str = (String) paramaterMap.get("str");
        //String sessionkey=MD5.MD5Encode(pidtoken+begintime+endtime+numperpage+order+page+productid+str);
        String sessionkey = "superd84b062c76a87a9322Q";
        String act = (String) paramaterMap.get("act");
        String hunted = (String) paramaterMap.get("hunted") == null ? "1" : (String) paramaterMap.get("hunted");
        String usertype = "formal";
        String tmp_uri = "?act=%s&pidtoken=%s&begintime=%s&endtime=%s&numperpage=%s&order=%s&page=%s&productid=%s&sessionkey=%s&hunted=%s&usertype=%s";
        tmp_uri = String.format(tmp_uri, act, pidtoken, begintime, endtime, numperpage, order, page, productid, sessionkey, hunted, usertype);
        return baseUrl + tmp_uri;
    }

    public static void main(String args[]) throws IOException, GWPersistenceException {
        SortedMap<String, Object> paramaterMap = new TreeMap<String, Object>();
        String url = "http://218.213.212.40:7732/api";  //AGIN养鱼测试接口
        String begintimeStr = "2017-01-16 00:00:00";
        String endtimeStr = "2017-01-16 23:59:59";
        String pidtoken = "superd84b062c76a87a7322a";
        String sessionKey = "90e96c7ce853252177b0657c54754765";
        String numperpage = "400";
        String page = "1";
        String usertype = "formal";
        String order = "time";
        String productid = "TST";
        String hunted = "1";
        String act = "getdetailbuyfishs";
        Date d = DateUtil.formatStr2Date(begintimeStr);
        Date d1 = DateUtil.formatStr2Date(endtimeStr);
        String begintime = String.valueOf(d.getTime());
        String endtime = String.valueOf(d1.getTime());
        begintime = begintime.substring(0, 10);
        endtime = endtime.substring(0, 10);
        paramaterMap.put("begintime", begintime);
        paramaterMap.put("endtime", endtime);
        paramaterMap.put("productid", productid);
        paramaterMap.put("order", order);
        paramaterMap.put("usertype", usertype);
        paramaterMap.put("page", page);
        paramaterMap.put("num", numperpage);
        paramaterMap.put("hunted", hunted);
        StringBuffer sb = new StringBuffer();
        sb.append(pidtoken);
        for (Map.Entry<String, Object> e : paramaterMap.entrySet())
            sb.append(e.getValue());
        sb.append(sessionKey);
        //String sessionkey=MD5.MD5Encode(str);
        //String sessionkey="superd84b062c76a87a9322Q";
        String tmp_uri = "?act=%s&pidtoken=%s&usertype=%s&begintime=%s&endtime=%s&numperpage=%s&order=%s&page=%s&productid=%s&sessionkey=%s&hunted=%s";
        tmp_uri = String.format(tmp_uri, act, pidtoken, usertype, begintime, endtime, numperpage, order, page, productid, sessionKey, hunted);
        System.out.println(url + tmp_uri);
//		?act=%s&pidtoken=%s&begintime=%s&endtime=%s&numperpage=%s&order=%s&page=%s&productid=%s&sessionkey=%s
//		 paramaterMap.put("act", "getproductsreports");

//		 SortedMap<String, String> params=new TreeMap<String, String>();


        StringBuffer xml = new StringBuffer();
//			try {
//				List<String> list= IOUtils.readLines(new FileInputStream(new File("D:\\workspace\\GWDataCenterAppTrunk\\src\\test\\test.xml")), "UTF-8");
//				for (int i = 0; i < list.size(); i++) {
//					xml.append(list.get(i));
//				}
//				System.out.println(xml);
//			} catch (FileNotFoundException e1) {
//				// TODO Auto-generated catch block
//				e1.printStackTrace();
//			} catch (IOException e1) {
//				// TODO Auto-generated catch block
//				e1.printStackTrace();
//			}
//		 String xml="<Result><Code>4</Code><Data>NCone</Data><Comment>product id error</Comment></Result>";
        AbstractHandle h = new AginFishRaiseFishHandle();

        Result res;
        try {
//				System.out.println(xml);
            //String content = new HttpUtil().doGet(url+tmp_uri);
            String content = "<OrderRes><Code>0</Code><Total>75</Total><Totalfishcost>61650.10000001639</Totalfishcost><Totalprofit>87640.35</Totalprofit><perpage>25</perpage><numpage>1</numpage><Bill>	<UserId>27</UserId>	<BetX>0.1</BetX>	<CashBill>586468</CashBill>	<Time>1484547231</Time>	<UserCashDelta>-6649</UserCashDelta>	<UserCashBefore>9.71189022e+07</UserCashBefore>	<UserCashAfter>9.71122532e+07</UserCashAfter>	<FishID>82564</FishID>	<FishTypeId>9</FishTypeId>	<BillNo>FishMgr-1b000000-0000-0000-3b39-537bd72b9a14</BillNo>	<PID>TST</PID>	<UserType>formal</UserType>	<HunterUID>28</HunterUID>	<HunterPID>TST</HunterPID>	<RoomId>126</RoomId>	<SRoomId>0</SRoomId>	<BulletInFish>1</BulletInFish>	<BulletCostInFish>0.955</BulletCostInFish>	<FishCost>6</FishCost>	<HuntedTime>1484547508</HuntedTime>	<HunterUserType>formal</HunterUserType>	<FishLife>0</FishLife>	<Flag>1</Flag>	<UserName>test378</UserName>	<HunterName>test390</HunterName>	<BillId>587c649f9ce6bf869580abdc</BillId></Bill><Bill><UserId>27</UserId><BetX>0.1</BetX><CashBill>586468</CashBill><Time>1484547231</Time><UserCashDelta>-6649</UserCashDelta><UserCashBefore>9.71189022e+07</UserCashBefore><UserCashAfter>9.71122532e+07</UserCashAfter><FishID>82619</FishID><FishTypeId>19</FishTypeId><BillNo>FishMgr-1b000000-0000-0000-3b39-537bd72b9a14</BillNo><PID>TST</PID><UserType>formal</UserType><HunterUID>0</HunterUID><HunterPID/><RoomId>0</RoomId><SRoomId>0</SRoomId><BulletInFish>0</BulletInFish><BulletCostInFish>0</BulletCostInFish><FishCost>500</FishCost><HuntedTime>0</HuntedTime><HunterUserType/><FishLife>0</FishLife><Flag>0</Flag><UserName>test378</UserName><HunterName/><BillId>587c649f9ce6bf869580ac13</BillId></Bill><Bill><UserId>27</UserId><BetX>0.1</BetX><CashBill>586468</CashBill><Time>1484547231</Time><UserCashDelta>-6649</UserCashDelta><UserCashBefore>9.71189022e+07</UserCashBefore><UserCashAfter>9.71122532e+07</UserCashAfter><FishID>82618</FishID><FishTypeId>19</FishTypeId><BillNo>FishMgr-1b000000-0000-0000-3b39-537bd72b9a14</BillNo><PID>TST</PID><UserType>formal</UserType><HunterUID>0</HunterUID><HunterPID/><RoomId>0</RoomId><SRoomId>0</SRoomId><BulletInFish>0</BulletInFish><BulletCostInFish>0</BulletCostInFish><FishCost>500</FishCost><HuntedTime>0</HuntedTime><HunterUserType/><FishLife>0</FishLife><Flag>0</Flag><UserName>test378</UserName><HunterName/><BillId>587c649f9ce6bf869580ac12</BillId></Bill><Bill><UserId>27</UserId><BetX>0.1</BetX><CashBill>586468</CashBill><Time>1484547231</Time><UserCashDelta>-6649</UserCashDelta><UserCashBefore>9.71189022e+07</UserCashBefore><UserCashAfter>9.71122532e+07</UserCashAfter><FishID>82617</FishID><FishTypeId>19</FishTypeId><BillNo>FishMgr-1b000000-0000-0000-3b39-537bd72b9a14</BillNo><PID>TST</PID><UserType>formal</UserType><HunterUID>0</HunterUID><HunterPID/><RoomId>0</RoomId><SRoomId>0</SRoomId><BulletInFish>0</BulletInFish><BulletCostInFish>0</BulletCostInFish><FishCost>500</FishCost><HuntedTime>0</HuntedTime><HunterUserType/><FishLife>0</FishLife><Flag>0</Flag><UserName>test378</UserName><HunterName/><BillId>587c649f9ce6bf869580ac11</BillId></Bill><Bill><UserId>27</UserId><BetX>0.1</BetX><CashBill>586468</CashBill><Time>1484547231</Time><UserCashDelta>-6649</UserCashDelta><UserCashBefore>9.71189022e+07</UserCashBefore><UserCashAfter>9.71122532e+07</UserCashAfter><FishID>82616</FishID><FishTypeId>19</FishTypeId><BillNo>FishMgr-1b000000-0000-0000-3b39-537bd72b9a14</BillNo><PID>TST</PID><UserType>formal</UserType><HunterUID>0</HunterUID><HunterPID/><RoomId>0</RoomId><SRoomId>0</SRoomId><BulletInFish>0</BulletInFish><BulletCostInFish>0</BulletCostInFish><FishCost>500</FishCost><HuntedTime>0</HuntedTime><HunterUserType/><FishLife>0</FishLife><Flag>0</Flag><UserName>test378</UserName><HunterName/><BillId>587c649f9ce6bf869580ac10</BillId></Bill><Bill><UserId>27</UserId><BetX>0.1</BetX><CashBill>586468</CashBill><Time>1484547231</Time><UserCashDelta>-6649</UserCashDelta><UserCashBefore>9.71189022e+07</UserCashBefore><UserCashAfter>9.71122532e+07</UserCashAfter><FishID>82551</FishID><FishTypeId>7</FishTypeId><BillNo>FishMgr-1b000000-0000-0000-3b39-537bd72b9a14</BillNo><PID>TST</PID><UserType>formal</UserType><HunterUID>28</HunterUID><HunterPID>TST</HunterPID><RoomId>126</RoomId><SRoomId>0</SRoomId><BulletInFish>8</BulletInFish><BulletCostInFish>7.64</BulletCostInFish><FishCost>4</FishCost><HuntedTime>1484548417</HuntedTime><HunterUserType>formal</HunterUserType><FishLife>0</FishLife><Flag>1</Flag><UserName>test378</UserName><HunterName>test390</HunterName><BillId>587c649f9ce6bf869580abcf</BillId></Bill><Bill><UserId>27</UserId><BetX>0.1</BetX><CashBill>586468</CashBill><Time>1484547231</Time><UserCashDelta>-6649</UserCashDelta><UserCashBefore>9.71189022e+07</UserCashBefore><UserCashAfter>9.71122532e+07</UserCashAfter><FishID>82552</FishID><FishTypeId>7</FishTypeId><BillNo>FishMgr-1b000000-0000-0000-3b39-537bd72b9a14</BillNo><PID>TST</PID><UserType>formal</UserType><HunterUID>28</HunterUID><HunterPID>TST</HunterPID><RoomId>126</RoomId><SRoomId>0</SRoomId><BulletInFish>4</BulletInFish><BulletCostInFish>3.82</BulletCostInFish><FishCost>4</FishCost><HuntedTime>1484551290</HuntedTime><HunterUserType>formal</HunterUserType><FishLife>0</FishLife><Flag>1</Flag><UserName>test378</UserName><HunterName>test390</HunterName><BillId>587c649f9ce6bf869580abd0</BillId></Bill><Bill><UserId>27</UserId><BetX>0.1</BetX><CashBill>586468</CashBill><Time>1484547231</Time><UserCashDelta>-6649</UserCashDelta><UserCashBefore>9.71189022e+07</UserCashBefore><UserCashAfter>9.71122532e+07</UserCashAfter><FishID>82553</FishID><FishTypeId>7</FishTypeId><BillNo>FishMgr-1b000000-0000-0000-3b39-537bd72b9a14</BillNo><PID>TST</PID><UserType>formal</UserType><HunterUID>28</HunterUID><HunterPID>TST</HunterPID><RoomId>126</RoomId><SRoomId>0</SRoomId><BulletInFish>6</BulletInFish><BulletCostInFish>5.73</BulletCostInFish><FishCost>4</FishCost><HuntedTime>1484552611</HuntedTime><HunterUserType>formal</HunterUserType><FishLife>0</FishLife><Flag>1</Flag><UserName>test378</UserName><HunterName>test390</HunterName><BillId>587c649f9ce6bf869580abd1</BillId></Bill><Bill><UserId>27</UserId><BetX>0.1</BetX><CashBill>586468</CashBill><Time>1484547231</Time><UserCashDelta>-6649</UserCashDelta><UserCashBefore>9.71189022e+07</UserCashBefore><UserCashAfter>9.71122532e+07</UserCashAfter><FishID>82554</FishID><FishTypeId>7</FishTypeId><BillNo>FishMgr-1b000000-0000-0000-3b39-537bd72b9a14</BillNo><PID>TST</PID><UserType>formal</UserType><HunterUID>28</HunterUID><HunterPID>TST</HunterPID><RoomId>126</RoomId><SRoomId>0</SRoomId><BulletInFish>2</BulletInFish><BulletCostInFish>1.91</BulletCostInFish><FishCost>4</FishCost><HuntedTime>1484549722</HuntedTime><HunterUserType>formal</HunterUserType><FishLife>0</FishLife><Flag>1</Flag><UserName>test378</UserName><HunterName>test390</HunterName><BillId>587c649f9ce6bf869580abd2</BillId></Bill><Bill><UserId>27</UserId><BetX>0.1</BetX><CashBill>586468</CashBill><Time>1484547231</Time><UserCashDelta>-6649</UserCashDelta><UserCashBefore>9.71189022e+07</UserCashBefore><UserCashAfter>9.71122532e+07</UserCashAfter><FishID>82555</FishID><FishTypeId>7</FishTypeId><BillNo>FishMgr-1b000000-0000-0000-3b39-537bd72b9a14</BillNo><PID>TST</PID><UserType>formal</UserType><HunterUID>28</HunterUID><HunterPID>TST</HunterPID><RoomId>126</RoomId><SRoomId>0</SRoomId><BulletInFish>6</BulletInFish><BulletCostInFish>5.73</BulletCostInFish><FishCost>4</FishCost><HuntedTime>1484558866</HuntedTime><HunterUserType>formal</HunterUserType><FishLife>0</FishLife><Flag>1</Flag><UserName>test378</UserName><HunterName>test390</HunterName><BillId>587c649f9ce6bf869580abd3</BillId></Bill><Bill><UserId>27</UserId><BetX>0.1</BetX><CashBill>586468</CashBill><Time>1484547231</Time><UserCashDelta>-6649</UserCashDelta><UserCashBefore>9.71189022e+07</UserCashBefore><UserCashAfter>9.71122532e+07</UserCashAfter><FishID>82556</FishID><FishTypeId>8</FishTypeId><BillNo>FishMgr-1b000000-0000-0000-3b39-537bd72b9a14</BillNo><PID>TST</PID><UserType>formal</UserType><HunterUID>28</HunterUID><HunterPID>TST</HunterPID><RoomId>126</RoomId><SRoomId>0</SRoomId><BulletInFish>2</BulletInFish><BulletCostInFish>1.91</BulletCostInFish><FishCost>5</FishCost><HuntedTime>1484548753</HuntedTime><HunterUserType>formal</HunterUserType><FishLife>0</FishLife><Flag>1</Flag><UserName>test378</UserName><HunterName>test390</HunterName><BillId>587c649f9ce6bf869580abd4</BillId></Bill><Bill><UserId>27</UserId><BetX>0.1</BetX><CashBill>586468</CashBill><Time>1484547231</Time><UserCashDelta>-6649</UserCashDelta><UserCashBefore>9.71189022e+07</UserCashBefore><UserCashAfter>9.71122532e+07</UserCashAfter><FishID>82557</FishID><FishTypeId>8</FishTypeId><BillNo>FishMgr-1b000000-0000-0000-3b39-537bd72b9a14</BillNo><PID>TST</PID><UserType>formal</UserType><HunterUID>28</HunterUID><HunterPID>TST</HunterPID><RoomId>126</RoomId><SRoomId>0</SRoomId><BulletInFish>10</BulletInFish><BulletCostInFish>9.549999999999999</BulletCostInFish><FishCost>5</FishCost><HuntedTime>1484548884</HuntedTime><HunterUserType>formal</HunterUserType><FishLife>0</FishLife><Flag>1</Flag><UserName>test378</UserName><HunterName>test390</HunterName><BillId>587c649f9ce6bf869580abd5</BillId></Bill><Bill><UserId>27</UserId><BetX>0.1</BetX><CashBill>586468</CashBill><Time>1484547231</Time><UserCashDelta>-6649</UserCashDelta><UserCashBefore>9.71189022e+07</UserCashBefore><UserCashAfter>9.71122532e+07</UserCashAfter><FishID>82558</FishID><FishTypeId>8</FishTypeId><BillNo>FishMgr-1b000000-0000-0000-3b39-537bd72b9a14</BillNo><PID>TST</PID><UserType>formal</UserType><HunterUID>28</HunterUID><HunterPID>TST</HunterPID><RoomId>126</RoomId><SRoomId>0</SRoomId><BulletInFish>4</BulletInFish><BulletCostInFish>3.82</BulletCostInFish><FishCost>5</FishCost><HuntedTime>1484548754</HuntedTime><HunterUserType>formal</HunterUserType><FishLife>0</FishLife><Flag>1</Flag><UserName>test378</UserName><HunterName>test390</HunterName><BillId>587c649f9ce6bf869580abd6</BillId></Bill><Bill><UserId>27</UserId><BetX>0.1</BetX><CashBill>586468</CashBill><Time>1484547231</Time><UserCashDelta>-6649</UserCashDelta><UserCashBefore>9.71189022e+07</UserCashBefore><UserCashAfter>9.71122532e+07</UserCashAfter><FishID>82559</FishID><FishTypeId>8</FishTypeId><BillNo>FishMgr-1b000000-0000-0000-3b39-537bd72b9a14</BillNo><PID>TST</PID><UserType>formal</UserType><HunterUID>28</HunterUID><HunterPID>TST</HunterPID><RoomId>126</RoomId><SRoomId>0</SRoomId><BulletInFish>3</BulletInFish><BulletCostInFish>2.865</BulletCostInFish><FishCost>5</FishCost><HuntedTime>1484548247</HuntedTime><HunterUserType>formal</HunterUserType><FishLife>0</FishLife><Flag>1</Flag><UserName>test378</UserName><HunterName>test390</HunterName><BillId>587c649f9ce6bf869580abd7</BillId></Bill><Bill><UserId>27</UserId><BetX>0.1</BetX><CashBill>586468</CashBill><Time>1484547231</Time><UserCashDelta>-6649</UserCashDelta><UserCashBefore>9.71189022e+07</UserCashBefore><UserCashAfter>9.71122532e+07</UserCashAfter><FishID>82560</FishID><FishTypeId>8</FishTypeId><BillNo>FishMgr-1b000000-0000-0000-3b39-537bd72b9a14</BillNo><PID>TST</PID><UserType>formal</UserType><HunterUID>28</HunterUID><HunterPID>TST</HunterPID><RoomId>126</RoomId><SRoomId>0</SRoomId><BulletInFish>10</BulletInFish><BulletCostInFish>9.549999999999999</BulletCostInFish><FishCost>5</FishCost><HuntedTime>1484549012</HuntedTime><HunterUserType>formal</HunterUserType><FishLife>0</FishLife><Flag>1</Flag><UserName>test378</UserName><HunterName>test390</HunterName><BillId>587c649f9ce6bf869580abd8</BillId></Bill><Bill><UserId>27</UserId><BetX>0.1</BetX><CashBill>586468</CashBill><Time>1484547231</Time><UserCashDelta>-6649</UserCashDelta><UserCashBefore>9.71189022e+07</UserCashBefore><UserCashAfter>9.71122532e+07</UserCashAfter><FishID>82561</FishID><FishTypeId>9</FishTypeId><BillNo>FishMgr-1b000000-0000-0000-3b39-537bd72b9a14</BillNo><PID>TST</PID><UserType>formal</UserType><HunterUID>28</HunterUID><HunterPID>TST</HunterPID><RoomId>126</RoomId><SRoomId>0</SRoomId><BulletInFish>1</BulletInFish><BulletCostInFish>0.955</BulletCostInFish><FishCost>6</FishCost><HuntedTime>1484548080</HuntedTime><HunterUserType>formal</HunterUserType><FishLife>0</FishLife><Flag>1</Flag><UserName>test378</UserName><HunterName>test390</HunterName><BillId>587c649f9ce6bf869580abd9</BillId></Bill><Bill><UserId>27</UserId><BetX>0.1</BetX><CashBill>586468</CashBill><Time>1484547231</Time><UserCashDelta>-6649</UserCashDelta><UserCashBefore>9.71189022e+07</UserCashBefore><UserCashAfter>9.71122532e+07</UserCashAfter><FishID>82562</FishID><FishTypeId>9</FishTypeId><BillNo>FishMgr-1b000000-0000-0000-3b39-537bd72b9a14</BillNo><PID>TST</PID><UserType>formal</UserType><HunterUID>28</HunterUID><HunterPID>TST</HunterPID><RoomId>126</RoomId><SRoomId>0</SRoomId><BulletInFish>10</BulletInFish><BulletCostInFish>9.549999999999999</BulletCostInFish><FishCost>6</FishCost><HuntedTime>1484548080</HuntedTime><HunterUserType>formal</HunterUserType><FishLife>0</FishLife><Flag>1</Flag><UserName>test378</UserName><HunterName>test390</HunterName><BillId>587c649f9ce6bf869580abda</BillId></Bill><Bill><UserId>27</UserId><BetX>0.1</BetX><CashBill>586468</CashBill><Time>1484547231</Time><UserCashDelta>-6649</UserCashDelta><UserCashBefore>9.71189022e+07</UserCashBefore><UserCashAfter>9.71122532e+07</UserCashAfter><FishID>82563</FishID><FishTypeId>9</FishTypeId><BillNo>FishMgr-1b000000-0000-0000-3b39-537bd72b9a14</BillNo><PID>TST</PID><UserType>formal</UserType><HunterUID>28</HunterUID><HunterPID>TST</HunterPID><RoomId>126</RoomId><SRoomId>0</SRoomId><BulletInFish>5</BulletInFish><BulletCostInFish>4.7749999999999995</BulletCostInFish><FishCost>6</FishCost><HuntedTime>1484547510</HuntedTime><HunterUserType>formal</HunterUserType><FishLife>0</FishLife><Flag>1</Flag><UserName>test378</UserName><HunterName>test390</HunterName><BillId>587c649f9ce6bf869580abdb</BillId></Bill><Bill><UserId>27</UserId><BetX>0.1</BetX><CashBill>586468</CashBill><Time>1484547231</Time><UserCashDelta>-6649</UserCashDelta><UserCashBefore>9.71189022e+07</UserCashBefore><UserCashAfter>9.71122532e+07</UserCashAfter><FishID>82615</FishID><FishTypeId>18</FishTypeId><BillNo>FishMgr-1b000000-0000-0000-3b39-537bd72b9a14</BillNo><PID>TST</PID><UserType>formal</UserType><HunterUID>0</HunterUID><HunterPID/><RoomId>0</RoomId><SRoomId>0</SRoomId><BulletInFish>0</BulletInFish><BulletCostInFish>0</BulletCostInFish><FishCost>300</FishCost><HuntedTime>0</HuntedTime><HunterUserType/><FishLife>0</FishLife><Flag>0</Flag><UserName>test378</UserName><HunterName/><BillId>587c649f9ce6bf869580ac0f</BillId></Bill><Bill><UserId>27</UserId><BetX>0.1</BetX><CashBill>586468</CashBill><Time>1484547231</Time><UserCashDelta>-6649</UserCashDelta><UserCashBefore>9.71189022e+07</UserCashBefore><UserCashAfter>9.71122532e+07</UserCashAfter><FishID>82565</FishID><FishTypeId>10</FishTypeId><BillNo>FishMgr-1b000000-0000-0000-3b39-537bd72b9a14</BillNo><PID>TST</PID><UserType>formal</UserType><HunterUID>28</HunterUID><HunterPID>TST</HunterPID><RoomId>126</RoomId><SRoomId>0</SRoomId><BulletInFish>9</BulletInFish><BulletCostInFish>8.594999999999999</BulletCostInFish><FishCost>8</FishCost><HuntedTime>1484550149</HuntedTime><HunterUserType>formal</HunterUserType><FishLife>0</FishLife><Flag>1</Flag><UserName>test378</UserName><HunterName>test390</HunterName><BillId>587c649f9ce6bf869580abdd</BillId></Bill><Bill><UserId>27</UserId><BetX>0.1</BetX><CashBill>586468</CashBill><Time>1484547231</Time><UserCashDelta>-6649</UserCashDelta><UserCashBefore>9.71189022e+07</UserCashBefore><UserCashAfter>9.71122532e+07</UserCashAfter><FishID>82566</FishID><FishTypeId>10</FishTypeId><BillNo>FishMgr-1b000000-0000-0000-3b39-537bd72b9a14</BillNo><PID>TST</PID><UserType>formal</UserType><HunterUID>28</HunterUID><HunterPID>TST</HunterPID><RoomId>126</RoomId><SRoomId>0</SRoomId><BulletInFish>5</BulletInFish><BulletCostInFish>4.7749999999999995</BulletCostInFish><FishCost>8</FishCost><HuntedTime>1484547747</HuntedTime><HunterUserType>formal</HunterUserType><FishLife>0</FishLife><Flag>1</Flag><UserName>test378</UserName><HunterName>test390</HunterName><BillId>587c649f9ce6bf869580abde</BillId></Bill><Bill><UserId>27</UserId><BetX>0.1</BetX><CashBill>586468</CashBill><Time>1484547231</Time><UserCashDelta>-6649</UserCashDelta><UserCashBefore>9.71189022e+07</UserCashBefore><UserCashAfter>9.71122532e+07</UserCashAfter><FishID>82567</FishID><FishTypeId>10</FishTypeId><BillNo>FishMgr-1b000000-0000-0000-3b39-537bd72b9a14</BillNo><PID>TST</PID><UserType>formal</UserType><HunterUID>28</HunterUID><HunterPID>TST</HunterPID><RoomId>126</RoomId><SRoomId>0</SRoomId><BulletInFish>4</BulletInFish><BulletCostInFish>3.82</BulletCostInFish><FishCost>8</FishCost><HuntedTime>1484550529</HuntedTime><HunterUserType>formal</HunterUserType><FishLife>0</FishLife><Flag>1</Flag><UserName>test378</UserName><HunterName>test390</HunterName><BillId>587c649f9ce6bf869580abdf</BillId></Bill><Bill><UserId>27</UserId><BetX>0.1</BetX><CashBill>586468</CashBill><Time>1484547231</Time><UserCashDelta>-6649</UserCashDelta><UserCashBefore>9.71189022e+07</UserCashBefore><UserCashAfter>9.71122532e+07</UserCashAfter><FishID>82568</FishID><FishTypeId>10</FishTypeId><BillNo>FishMgr-1b000000-0000-0000-3b39-537bd72b9a14</BillNo><PID>TST</PID><UserType>formal</UserType><HunterUID>28</HunterUID><HunterPID>TST</HunterPID><RoomId>126</RoomId><SRoomId>0</SRoomId><BulletInFish>15</BulletInFish><BulletCostInFish>14.325</BulletCostInFish><FishCost>8</FishCost><HuntedTime>1484547355</HuntedTime><HunterUserType>formal</HunterUserType><FishLife>0</FishLife><Flag>1</Flag><UserName>test378</UserName><HunterName>test390</HunterName><BillId>587c649f9ce6bf869580abe0</BillId></Bill><Bill><UserId>27</UserId><BetX>0.1</BetX><CashBill>586468</CashBill><Time>1484547231</Time><UserCashDelta>-6649</UserCashDelta><UserCashBefore>9.71189022e+07</UserCashBefore><UserCashAfter>9.71122532e+07</UserCashAfter><FishID>82569</FishID><FishTypeId>10</FishTypeId><BillNo>FishMgr-1b000000-0000-0000-3b39-537bd72b9a14</BillNo><PID>TST</PID><UserType>formal</UserType><HunterUID>28</HunterUID><HunterPID>TST</HunterPID><RoomId>126</RoomId><SRoomId>0</SRoomId><BulletInFish>14</BulletInFish><BulletCostInFish>13.370000000000001</BulletCostInFish><FishCost>8</FishCost><HuntedTime>1484547743</HuntedTime><HunterUserType>formal</HunterUserType><FishLife>0</FishLife><Flag>1</Flag><UserName>test378</UserName><HunterName>test390</HunterName><BillId>587c649f9ce6bf869580abe1</BillId></Bill><Bill><UserId>27</UserId><BetX>0.1</BetX><CashBill>586468</CashBill><Time>1484547231</Time><UserCashDelta>-6649</UserCashDelta><UserCashBefore>9.71189022e+07</UserCashBefore><UserCashAfter>9.71122532e+07</UserCashAfter><FishID>82570</FishID><FishTypeId>11</FishTypeId><BillNo>FishMgr-1b000000-0000-0000-3b39-537bd72b9a14</BillNo><PID>TST</PID><UserType>formal</UserType><HunterUID>28</HunterUID><HunterPID>TST</HunterPID><RoomId>126</RoomId><SRoomId>0</SRoomId><BulletInFish>21</BulletInFish><BulletCostInFish>20.055</BulletCostInFish><FishCost>10</FishCost><HuntedTime>1484547782</HuntedTime><HunterUserType>formal</HunterUserType><FishLife>0</FishLife><Flag>1</Flag><UserName>test378</UserName><HunterName>test390</HunterName><BillId>587c649f9ce6bf869580abe2</BillId></Bill></OrderRes>";
            System.out.println(content);
            res = h.parse(content);
            System.out.println(res.getOrderList().toString());
//				String time="1448626199";
//				new OrderEntity().setUnixTimeStampToDate(time);

//				System.out.println(new Date(1448626199));
            String confDir = File.separator + System.getProperty("user.dir") + File.separator + "conf";
            FileSystemXmlApplicationContext factory = new FileSystemXmlApplicationContext(confDir + "/spring/applicationContext.xml");
            OrderDao orderDao = (OrderDao) factory.getBean("orderDao");
            SqlSessionFactory myBatisSessionFactory = (SqlSessionFactory) factory.getBean("myBatisSessionFactory");
            SqlSession session = myBatisSessionFactory.openSession();
            for (Object obj : res.getOrderList()) {
                OrderEntity orderEntity = (OrderEntity) obj;
                orderEntity.setGameKind("5");
                orderEntity.setAgCode("TST");
                orderEntity.setProductId("A01");
                orderEntity.setBonusAmount(new BigDecimal(0));
                orderEntity.setCreationDate(new Date());
                orderEntity.setPlatId("026");
                orderEntity.setGameType("RAISEFISH");
            }
            orderDao.insertOrder4AG(res.getOrderList(), session, false);
        } catch (GWCallRemoteApiException e) {

            // TODO Auto-generated catch block
            e.printStackTrace();

        }
    }


    public void parseRules(Digester d) {

        d.addObjectCreate("Result", OrderRes.class);
        d.addBeanPropertySetter("Result/Code", "code");
        d.addBeanPropertySetter("Result/Comment", "comment");

        d.addObjectCreate("OrderRes", OrderRes.class);
        d.addBeanPropertySetter("OrderRes/Total", "total");
        d.addBeanPropertySetter("OrderRes/Code", "code");
        d.addBeanPropertySetter("OrderRes/perpage", "perpage");
        d.addBeanPropertySetter("OrderRes/numpage", "numpage");

        d.addObjectCreate("OrderRes/Bill", OrderEntity.class);
        d.addSetNext("OrderRes/Bill", "addOrder");

		d.addBeanPropertySetter("OrderRes/Bill/BillId","billNo");
		d.addBeanPropertySetter("OrderRes/Bill/FishID","round");
		 d.addBeanPropertySetter("OrderRes/Bill/FishID","gmCode");//将round也写入gmCode,便于后期dc-office后台统一使用gmCode查询
		d.addBeanPropertySetter("OrderRes/Bill/FishTypeId","tableCode");
		//d.addBeanPropertySetter("OrderRes/Bill/UserCashBefore","previosAmount");
		//d.addBeanPropertySetter("OrderRes/Bill/bulletcostinfish","cusAccount");
		//d.addBeanPropertySetter("OrderRes/Bill/UserCashCurrent","currentAmount");
		
		d.addBeanPropertySetter("OrderRes/Bill/BulletCostInFish","cusAccount");
		d.addCallMethod("OrderRes/Bill/FishCost", "setAginRaiseFishCusAccount", 1);
		d.addCallParam("OrderRes/Bill/FishCost", 0);
		
		d.addBeanPropertySetter("OrderRes/Bill/FishCost","account");
		d.addBeanPropertySetter("OrderRes/Bill/FishCost","validAccount");
		d.addBeanPropertySetter("OrderRes/Bill/PID","productId");
		
		d.addBeanPropertySetter("OrderRes/Bill/FishTypeId","playType");
		d.addCallMethod("OrderRes/Bill/RoomBet", "setFishPlayType",1);
		d.addCallParam("OrderRes/Bill/RoomBet", 0);
		d.addCallMethod("OrderRes/Bill/Time", "setUnixTimeStampToDate",1);
		d.addCallParam("OrderRes/Bill/Time", 0);
		d.addBeanPropertySetter("OrderRes/Bill/ProductId","productId");
		d.addBeanPropertySetter("OrderRes/Bill/UserName","loginName");
		d.addCallMethod("OrderRes/Bill/UserName", "setDefaultFlag");
		


    }


}
