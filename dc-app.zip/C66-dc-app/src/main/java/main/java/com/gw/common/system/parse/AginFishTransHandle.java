package main.java.com.gw.common.system.parse;

import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.MD5;
import main.java.com.gw.common.system.parse.vo.TransRes;
import main.java.com.gw.datacenter.accounttransfer.entity.AccountTransferEntity;
import org.apache.commons.digester3.Digester;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.XML;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class AginFishTransHandle extends AbstractHandle {

    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        String baseUrl = (String) paramaterMap.get("baseUrl");//url
        String begintimeStr = (String) paramaterMap.get("begintime");//开始时间
        String endtimeStr = (String) paramaterMap.get("endtime");//结束时间
        Date d = DateUtil.formatStr2Date(begintimeStr);//转化格式
        Date d1 = DateUtil.formatStr2Date(endtimeStr);
        String productid = (String) paramaterMap.get("productId");//产品id
        /*String pidtoken = (String) paramaterMap.get("pidtoken"); //产品id秘钥*/
        String begintime = String.valueOf(d.getTime());
        String endtime = String.valueOf(d1.getTime());
        begintime = begintime.substring(0, 10);
        endtime = endtime.substring(0, 10);
//        String order = "time";//排序字段
        String order = "transtime";//排序字段
        String by ="DESC";
        int numperpage = Integer.valueOf((String) paramaterMap.get(UtilConstants.ORDER_PAGE_NUMBER));//每页显示条数
        int page = Integer.valueOf((String) paramaterMap.get("page"));//显示第几页
        String billtypes = (String) paramaterMap.get("billtypes");//账单类型
        String str = (String) paramaterMap.get("str");//API驗證KEY,加密方式為
//        String sessionkey = MD5.MD5Encode(pidtoken + begintime + billtypes + endtime + numperpage + order + page + productid + str);
//        String key = MD5.MD5Encode(productid+begintime+endtime+order+by+page+numperpage+str);
        String key = MD5.MD5Encode(productid+begintime+endtime+page+numperpage+str);
        String act = (String) paramaterMap.get("act"); //API 名称
//        String tmp_uri = "?&act=%s&pidtoken=%s&begintime=%s&billtypes=%s&endtime=%s&numperpage=%s&order=%s&page=%s&productid=%s&sessionkey=%s";
//        tmp_uri = String.format(tmp_uri, act, pidtoken, begintime, billtypes, endtime, numperpage, order, page, productid, sessionkey);
        /*String tmp_uri = "?cagent=%s&startdate=%s&enddate=%s&perpage=%s&page=%s&key=%s";
        tmp_uri = String.format(tmp_uri, productid,begintime,endtime,numperpage,page,key);*/
        String tmp_uri = "?cagent=%s&startdate=%s&enddate=%s&perpage=%s&page=%s&key=%s";
        tmp_uri = String.format(tmp_uri, productid,begintime,endtime,numperpage,page,key);
        return baseUrl+act+ tmp_uri;
    }

    public static void main(String args[]) {
        Map<String, Object> paramaterMap = new HashMap<String, Object>();
//        paramaterMap.put("baseUrl", "http://hunteriv.agin.cc:7733/api");
        paramaterMap.put("baseUrl", "http://gsapi.casino6888.com:3335/");
        paramaterMap.put("begintime", "2019-11-23 12:55:01");
        paramaterMap.put("endtime", "2019-11-23 13:00:01");
        paramaterMap.put("productId", "B01");
        paramaterMap.put("pidtoken", "superd84b062c76a87a7322a");
        paramaterMap.put("page", "1");
        paramaterMap.put("num", "400");
        paramaterMap.put("billtypes", "1,2,7");//账单类型
        paramaterMap.put("act", "gethuntercustrans.xml");
        paramaterMap.put("str", "421EDD85303CF8FAAED9115BFE0689A3");
//        paramaterMap.put("str", "supermd87a7322ad84b062c7");
        AbstractHandle handle = new AginFishTransHandle();
        try {
//            String result = handle.retrieveData(paramaterMap);
            String result = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                    "<result><info>0</info>" +
                    "<row transno=\"191121046418181\"" +
                    " productid=\"E03\" " +
                    "username=\"vyl009876\" " +
                    "sceneid=\"\" " +
                    "transtime=\"1574308820\"" +
                    " currency=\"CNY\"" +
                    " trans_amount=\"50.250000\"" +
                    " before_credit=\"0\"" +
                    " current_credit=\"50.250000\"" +
                    " transtype=\"1\"" +
                    " code=\"IN\"" +
                    " remark=\"1574308821015870;TRANSFER_IN\" />" +
                    "<row transno=\"191121046460390\" productid=\"E03\" username=\"vyl009876\" sceneid=\"15743087330026\" transtime=\"1574308859\" currency=\"CNY\" trans_amount=\"-0.300000\" before_credit=\"50.250000\" current_credit=\"49.950000\" transtype=\"3\" code=\"BET\" remark=\"15743087330026;15743088602907452;HM2D\" />" +
                    "<row transno=\"191121046461178\" productid=\"E03\" username=\"vyl009876\" sceneid=\"15743087330026\" transtime=\"1574308859\" currency=\"CNY\" trans_amount=\"-0.300000\" before_credit=\"49.950000\" current_credit=\"49.650000\" transtype=\"3\" code=\"BET\" remark=\"15743087330026;15743088602910902;HM2D\" />" +
                    "<addition><total>3</total><num_per_page>20</num_per_page><currentpage>1</currentpage><totalpage>1</totalpage><perpage>3</perpage></addition>" +
                    "</result>";
            System.out.println(result);
            System.out.println(handle.parse(result).getOrderList());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public TransRes parse(String content) {
        JSONObject obj = XML.toJSONObject(content);
        obj = obj.optJSONObject("result");
        JSONObject addition = obj.optJSONObject("addition");
        JSONArray rows = obj.optJSONArray("row");

        TransRes orderRes = new TransRes();
        orderRes.setCode(obj.optString("info"));
        orderRes.setTotal(addition.optInt("total"));
        orderRes.setNumpage(addition.optInt("num_per_page"));
        orderRes.setCurrentPage(addition.optInt("currentpage"));
        orderRes.setTotalPages(addition.optInt("totalpage"));
        orderRes.setPerpage(addition.optInt("perpage"));

        if(rows !=null) {
            for (int i = 0; i < rows.length(); i++) {

                JSONObject row = rows.optJSONObject(i);
                AccountTransferEntity order = new AccountTransferEntity();

                order.setTradeNo(row.optString("transno"));
                order.setProductId(row.optString("productid"));
                order.setUserName(row.optString("username"));
                order.setTransId(row.optString("sceneid"));
                order.setTime(row.optString("transtime"));
                //同时赋值-赋值原始创建时间/创建时间-两个时间同时格式化和设置
                order.setUnixTimeStampToDate(row.optString("transtime"));
                order.setCurrency(row.optString("currency"));
                order.setPreviousAmount(new BigDecimal(row.optString("before_credit")));
                order.setTransferAmount(new BigDecimal(row.optString("trans_amount")));
                order.setCurrentAmount(new BigDecimal(row.optString("current_credit")));
                order.setTransferType(row.optString("code"));
                order.setRemark(row.optString("remark"));
                orderRes.addOrder(order);
            }
        }
        return orderRes;
    }

    //解析xml中的数据- 老的方法作废
    public void parseRules(Digester d) {
        d.addObjectCreate("OrderRes", TransRes.class);
        d.addBeanPropertySetter("OrderRes/perpage");
        d.addBeanPropertySetter("OrderRes/Total", "total");
        d.addBeanPropertySetter("OrderRes/numpage");
        d.addBeanPropertySetter("OrderRes/Code", "code");
        d.addBeanPropertySetter("OrderRes/Comment", "comment");

        d.addObjectCreate("OrderRes/Bill", AccountTransferEntity.class);
        d.addSetNext("OrderRes/Bill", "addOrder");
        d.addCallMethod("OrderRes/Bill/BillId", "setTradeNo", 1);//系统订单号
        d.addCallParam("OrderRes/Bill/BillId", 0);
        d.addBeanPropertySetter("OrderRes/Bill/UserName", "userName");//名称
        d.addCallMethod("OrderRes/Bill/Time", "setUnixTimeStampToDate", 1);//时间
        d.addCallParam("OrderRes/Bill/Time", 0);
        d.addCallMethod("OrderRes/Bill/BillType", "setAsTransferType", 1);//转账类型
        d.addCallParam("OrderRes/Bill/BillType", 0);
        d.addBeanPropertySetter("OrderRes/Bill/UserCashBefore", "previousAmount");//投注前额度
        d.addBeanPropertySetter("OrderRes/Bill/UserCashDelta", "transferAmount");//客户输赢额度
        d.addBeanPropertySetter("OrderRes/Bill/UserCashCurrent", "currentAmount");//投注后额度
        d.addBeanPropertySetter("OrderRes/Bill/ProductId", "productId");//产品id
    }


}
