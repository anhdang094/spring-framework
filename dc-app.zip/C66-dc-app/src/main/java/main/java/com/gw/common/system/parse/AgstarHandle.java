package main.java.com.gw.common.system.parse;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.util.CipherUtils;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.HttpClientUtils;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.datacenter.accounttransfer.entity.AccountTransferEntity;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.json.XML;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author Dominik.X
 * @description
 * @date 2019/9/20 11:47
 */
@Slf4j
public class AgstarHandle {

    public JSONObject postToAS(String betApiUrl, Map<String, Object> params) throws Exception {
        String response = null;
        JSONObject baseJsonObject = null;
        JSONObject json = new JSONObject();
        json.put("timestamp", String.valueOf(System.currentTimeMillis()));
        json.put("begintime", params.get("begintime"));
        json.put("endtime", params.get("endtime"));
        json.put("page", params.get("page"));
        json.put("num", params.get("num"));
        String key = CipherUtils.string2MD5CipherText(params.get("password").toString());
        String param = CipherUtils.string2AESCipherText(key, json.toString());
        try {
            log.info("as-getASOrders betApiUrl[{}] params[{}] ,加密之后参数：[{}]", betApiUrl, json.toString(), param);
            response = HttpClientUtils.postSSL(betApiUrl, param);
            if (StringUtils.isNotBlank(response)) {
                baseJsonObject = XML.toJSONObject(response).getJSONObject("response");
            }
        } catch (Exception e) {
            log.info("as-getASOrders ERROR in HTTP get,response:{} ", response, e);
            throw new GWCallRemoteApiException("请求as注单数据出现异常");
        }
        return baseJsonObject;
    }

    public List<Object> constructOrders(JSONObject object) {
        List<Object> result = new ArrayList<>();
        if (object.has("datas")) {
            Object datas = new JSONTokener(object.get("datas").toString()).nextValue();
            if (datas instanceof JSONArray) {
                JSONArray jsonArray = (JSONArray) datas;
                for (Object o : jsonArray) {
                    result.add(assemblyOrder((JSONObject) o));
                }
            } else if (datas instanceof JSONObject) {
                result.add(assemblyOrder((JSONObject) datas));
            }
        }

        return result;
    }

    public List<AccountTransferEntity> constructTransfer(JSONObject object) {
        List<AccountTransferEntity> transferEntities = new ArrayList<>();
        if (object.has("datas")) {
            Object datas = new JSONTokener(object.get("datas").toString()).nextValue();
            if (datas instanceof JSONArray) {
                JSONArray jsonArray = (JSONArray) datas;
                for (Object o : jsonArray) {
                    transferEntities.add(assemblyTransfer((JSONObject) o));
                }
            } else if (datas instanceof JSONObject) {
                transferEntities.add(assemblyTransfer((JSONObject) datas));
            }
        }
        return transferEntities;
    }

    private AccountTransferEntity assemblyTransfer(JSONObject data) {
        AccountTransferEntity entity = new AccountTransferEntity();
        entity.setTradeNo(data.optString("TradeNo"));
        entity.setUserName(data.optString("UserName"));
        entity.setCreationTime(ToolUtil.transferUSEsternDateToCNEsternDate(DateUtil.formatStr2Date(data.optString("CreateTime"))));
        entity.setOrignalCreationTime(DateUtil.formatStr2Date(data.optString("CreateTime")));
        String transType = data.optString("TransType");
        if (UtilConstants.TRANSFER_TYPE_OUT_CN.equals(transType)) {
            entity.setTransferType(UtilConstants.TRANSFER_TYPE_OUT);
        } else if (UtilConstants.TRANSFER_TYPE_IN_CN.equals(transType)) {
            entity.setTransferType(UtilConstants.TRANSFER_TYPE_IN);
        } else if (UtilConstants.TRANSFER_TYPE_AMAYA_WITHFRAW.equals(transType)) {
            entity.setTransferType(UtilConstants.TRANSFER_TYPE_OUT);
        } else if (UtilConstants.TRANSFER_TYPE_AMAYA_DEPOSIT.equals(transType)) {
            entity.setTransferType(UtilConstants.TRANSFER_TYPE_IN);
        } else {
            entity.setTransferType(transType);
        }
        entity.setName(data.optString("Name"));
        if (data.has("Amount") && StringUtils.isNotBlank(data.get("Amount").toString())) {
            entity.setTransferAmount(data.getBigDecimal("Amount"));
        }
        if (data.has("Src_Amount") && StringUtils.isNotBlank(data.get("Src_Amount").toString())) {
            entity.setPreviousAmount(data.getBigDecimal("Src_Amount"));
        }
        if (data.has("Balance") && StringUtils.isNotBlank(data.get("Balance").toString())) {
            entity.setCurrentAmount(data.getBigDecimal("Balance"));
        }
        if (data.has("ExchangeRate") && StringUtils.isNotBlank(data.get("ExchangeRate").toString())) {
            entity.setExchangeRate(data.getBigDecimal("ExchangeRate"));
        }
        entity.setWagerId(data.optString("WagersID"));
        entity.setBalanceType(data.optInt("BalanceType"));
        entity.setIP(data.optString("IP"));
        entity.setCurrency(data.optString("Currency"));
        String transID = data.optString("TransID");
        if (transID != null && transID.contains(UtilConstants.SEMICOLON)) {
            entity.setRemark((transID.split(UtilConstants.SEMICOLON))[1]);
        } else if (transID != null && transID.contains(UtilConstants.COLON)) {
            entity.setRemark(transID);
        } else {
            entity.setTransId(transID);
        }
        entity.setFlag(data.getInt("Flag"));
        entity.setProductId(data.optString("ProductID"));
        if ("A07".equals(data.optString("ProductID"))) {
            //如果是A07就转换成产品为A02
            entity.setProductId("A02");
        }
        entity.setPlatformId(UtilConstants.AGSTAR);
        return entity;
    }

    private OrderEntity assemblyOrder(JSONObject data) {
        OrderEntity entity = new OrderEntity();
        entity.setPlatId(UtilConstants.AGSTAR);
        entity.setBillNo(data.optString("billno"));
        entity.setGameType(data.optString("gametype"));
        entity.setLoginName(data.optString("username"));
        entity.setAgCode(data.optString("agcode"));
        entity.setTopAgCode((data.optString("agcode")).substring(0, 3));
        entity.setGmCode(data.optString("gmcode"));
        if (data.has("cus_account") && StringUtils.isNotBlank(data.get("cus_account").toString())) {
            entity.setCusAccount(data.getBigDecimal("cus_account"));
        }
        if (data.has("account") && StringUtils.isNotBlank(data.get("account").toString())) {
            entity.setAccount(data.getBigDecimal("account"));
        }
        if (data.has("valid_account") && StringUtils.isNotBlank(data.get("valid_account").toString())) {
            entity.setValidAccount(data.getBigDecimal("valid_account"));
        }
        if (data.has("BASEPOINT") && StringUtils.isNotBlank(data.get("BASEPOINT").toString())) {
            entity.setPreviosAmount(data.getBigDecimal("BASEPOINT"));
        }
        entity.setBillTime(ToolUtil.transferUSEsternDateToCNEsternDate(DateUtil.formatStr2Date(data.optString("billtime"))));
        entity.setOrignalBillTime(DateUtil.formatStr2Date(data.optString("billtime")));
        entity.setTableCode(data.optString("tablecode"));
        entity.setFlag(data.getInt("flag"));
        entity.setRemark(data.optString("remark"));
        if (data.has("playtype")) {
            entity.setPlayType(data.getInt("playtype"));
        }
        entity.setCurrency(data.optString("currency"));
        entity.setCurIp(data.optString("cur_ip"));
        entity.setReckonTime(ToolUtil.transferUSEsternDateToCNEsternDate(DateUtil.formatStr2Date(data.optString("reckontime"))));
        entity.setOrignalReckonTime(DateUtil.formatStr2Date(data.optString("reckontime")));
        entity.setProductId(data.optString("productid"));
        entity.setDeviceType(data.optString("devicetype"));

        return entity;
    }
}
