package main.java.com.gw.common.system.parse;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.exception.GWPersistenceException;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.common.framework.util.MD5;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.parse.vo.OrderRes;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.digester3.Digester;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Angus.Z on 2017/10/3.
 */
@Slf4j
public class AmayaOrderHandle extends AbstractHandle {
    public String retrieveData(String url, Map<String, Object> paramaterMap) throws GWCallRemoteApiException {
        String content = "";
        try {
            log.info("url=" + url + "  parama=" + paramaterMap);
            content = new HttpUtil().httpGet(url, paramaterMap);
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new GWCallRemoteApiException("Failed to call remote interface!" + ex.getMessage(), ex);
        }

        return content;

    }

    public static void main(String[] args) throws GWCallRemoteApiException, GWPersistenceException {
        try {
            Map<String, Object> parameterMap = new HashMap<String, Object>();
            String baseUrl = "http://localhost:8080/cw/TTMSBetRecord";
            String productid = "A03";// "0";
            parameterMap.put("productId", productid);
//        String starttime = "2017-04-14 09:41:48";
//        String endtime = "2017-04-14 09:41:48";
            String starttime = "2017-04-14 09:41:48";
            String endtime = "2017-04-14 09:51:48";
            parameterMap.put("begintime", starttime);
            parameterMap.put("endtime", endtime);
            String page = "1";
            parameterMap.put("page", page);
            String num = "500";
            parameterMap.put("num", num);
            String gameCode = "1";
            parameterMap.put("gameCode", gameCode);
            String key = MD5.md5Encoding("12").toUpperCase();
            parameterMap.put("key", key);
            parameterMap.put("timeZone", "Etc/GMT+1");
            parameterMap.put("dataDelay", 2);
            parameterMap.put("baseUrl", baseUrl);
            parameterMap.put("platformid", "order_amaya_fclrc");
            parameterMap.put("remark", "2017-04-14 09:40:00TTG 电子游艺注单 A01,A");
            String platform = "027"; // ttg:027, ttgvip:053
            String timeZone = (String) parameterMap.get("timeZone");
            int dataDelay = (int) parameterMap.get("dataDelay");
            AbstractHandle handle = new AmayaOrderHandle();

            // Add this block code to correct the mistake, Remove this code after separate time
            String separateTime = (String) parameterMap.get("remark"); //切换时间点
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            if (separateTime == null || separateTime.equals("") || separateTime.length() < 19) {
                Calendar calendar = Calendar.getInstance();
                calendar.add(Calendar.YEAR, 1);
                separateTime = format.format(calendar.getTime());
            } else {
                try {
                    separateTime = separateTime.substring(0, 19);
                    format.parse(separateTime);
                } catch (Exception e) {
                    Calendar calendar = Calendar.getInstance();
                    calendar.add(Calendar.YEAR, 1);
                    separateTime = format.format(calendar.getTime());
                }
            }
//        log.info("SeparateTime for TTG:taskId="+taskId+", SeparateTime="+separateTime);
            System.out.println("SeparateTime for TTG: SeparateTime=" + separateTime);
            Date separate = format.parse(separateTime);
            Date start = format.parse((String) parameterMap.get("begintime"));
            Date end = format.parse((String) parameterMap.get("endtime"));
            if (start.before(separate) && end.compareTo(separate) >= 0) {
                parameterMap.put("endtime", separateTime);
            }
            // Add this block code to correct the mistake end


            //boolean isWait = ToolUtil.isWaitXMins(parameterMap, UtilConstants.TIMEZONE_GMT, 4);
            boolean isWait = ToolUtil.isWaitXMins(parameterMap, timeZone, dataDelay);
            if (!isWait) {
//            String confDir = File.separator + System.getProperty("user.dir") + File.separator + "conf";
//            FileSystemXmlApplicationContext factory = new FileSystemXmlApplicationContext(confDir + "/spring/applicationContext.xml");
//            OrderService orderService= (OrderService)factory.getBean("orderService");
//            String Url = (String)parameterMap.get("baseUrl");
                if (start.compareTo(separate) >= 0) {// Remove this code after separate time
                    baseUrl = baseUrl.substring(0, baseUrl.lastIndexOf("/") + 1) + "TTMSBetRecord";
//                log.info("new url for TTG:"+baseUrl);
                    System.out.println("new url for TTG:" + baseUrl);
                    parameterMap.put("baseUrl", baseUrl); // Remove this code after separate time
//                orderService.insertOrder4TTMS(parameterMap, baseUrl, null, false);
                    System.out.println("insertOrder4TTMS");
                } else {
//                orderService.insertOrder4TTG(parameterMap, baseUrl, null, false);
                    System.out.println("insertOrder4TTG");
                }
                System.out.println(parameterMap.get("begintime"));
                System.out.println(parameterMap.get("endtime"));
                parameterMap = ToolUtil.updateTimeForBBINParameterMap(parameterMap, 0, 600000);
                System.out.println(parameterMap.get("begintime"));
                System.out.println(parameterMap.get("endtime"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }


//        String result = handle.retrieveData(baseUrl, parameterMap);
//        //String result="<Data Page=\"1\" PageLimit=\"20\" TotalNumber=\"2\" TotalPage=\"1\" sattus=\"0\" desc=\"\"  > <Record>       <amount>0.02</amount>        <bonusAmount>0</bonusAmount>        <createdDate>2017-09-27 13:40:10</createdDate>        <currency>CNY</currency>        <currentbalance>8826.18</currentbalance>        <gameCode>52</gameCode>        <gameTypeid>53</gameTypeid>        <gameid>53</gameid>        <gamesessionid>png_session_1</gamesessionid>        <isfreegame>1</isfreegame>        <loginname>A02crndtest</loginname>        <previousbalance>8826.2</previousbalance>        <productid>A02</productid>        <remark>VIP</remark>        <requestid>43211</requestid>        <requesttype>700</requesttype>        <roundid>87654322</roundid>        <transactionid>323</transactionid>    </Record>   <Record>       <amount>0.02</amount>        <bonusAmount>0</bonusAmount>        <createdDate>2017-09-27 13:40:46</createdDate>        <currency>CNY</currency>        <currentbalance>8826.2</currentbalance>        <gameCode>52</gameCode>        <isfreegame>1</isfreegame>        <loginname>A02crndtest</loginname>        <previousbalance>8826.18</previousbalance>        <productid>A02</productid>        <requestid>43211</requestid>        <requesttype>702</requesttype>        <roundid>87654322</roundid>        <transactionid>324</transactionid>    </Record>  <Record>       <amount>0.22</amount>        <bonusAmount>0</bonusAmount>        <createdDate>2017-09-27 13:40:46</createdDate>        <currency>CNY</currency>        <currentbalance>8826.2</currentbalance>        <gameCode>52</gameCode>        <isfreegame>1</isfreegame>        <loginname>A02crndtest</loginname>        <previousbalance>8826.18</previousbalance>        <productid>A02</productid>        <requestid>43212</requestid>        <requesttype>700</requesttype>        <roundid>87654323</roundid>        <transactionid>324</transactionid>    </Record> <Record>       <amount>0.44</amount>        <bonusAmount>0</bonusAmount>        <createdDate>2017-09-27 13:40:46</createdDate>        <currency>CNY</currency>        <currentbalance>8826.2</currentbalance>        <gameCode>52</gameCode>        <isfreegame>1</isfreegame>        <loginname>A02crndtest</loginname>        <previousbalance>8826.18</previousbalance>        <productid>A02</productid>        <requestid>43212</requestid>        <requesttype>710</requesttype>        <roundid>87654323</roundid>        <transactionid>324</transactionid>    </Record>   </Data>";
//        System.out.println(result);
//        List<Object> orderLit = handle.parse(result).getOrderList();
//        System.out.println(orderLit);
//
//        String confDir = File.separator + System.getProperty("user.dir") + File.separator + "conf";
//        FileSystemXmlApplicationContext factory = new FileSystemXmlApplicationContext(confDir + "/spring/applicationContext.xml");
//        OrderDao orderDao= (OrderDao)factory.getBean("orderDao");
//        AllocationDao allocationDao= (AllocationDao)factory.getBean("allocationDao");
//        SqlSessionFactory myBatisSessionFactory = (SqlSessionFactory)factory.getBean("myBatisSessionFactory");
//        SqlSession session = myBatisSessionFactory.openSession();
//        ToolUtil.initSpecialGames(platform, allocationDao);
//
//        orderDao.insertOrder4Amaya(orderLit, session, false,platform);


    }

    public void parseRules(Digester d) {
        d.addObjectCreate("Data", OrderRes.class);
        d.addSetProperties("Data", "sattus", "code");
        d.addSetProperties("Data", "desc", "comment");
        d.addSetProperties("Data", "Page", "numpage");
        d.addSetProperties("Data", "PageLimit", "perpage");
        d.addSetProperties("Data", "TotalNumber", "total");
        d.addSetProperties("Data", "TotalPage", "totalPages");
        d.addObjectCreate("Data/Record", OrderEntity.class);
        d.addSetNext("Data/Record", "addOrder");
//        d.addBeanPropertySetter("Data/Record/transactionid","billNo");
        d.addBeanPropertySetter("Data/Record/previousbalance", "previosAmount");
        d.addBeanPropertySetter("Data/Record/currentbalance", "currentAmount");
        d.addBeanPropertySetter("Data/Record/transactionSubtypeid", "playType");
        d.addBeanPropertySetter("Data/Record/bonusAmount", "bonusAmount");
        d.addBeanPropertySetter("Data/Record/amount", "account");
        d.addBeanPropertySetter("Data/Record/amount", "validAccount");
        d.addBeanPropertySetter("Data/Record/gameid", "billNo");
        d.addBeanPropertySetter("Data/Record/gameid", "gmCode");
        d.addBeanPropertySetter("Data/Record/gameTypeid", "gameType");
        d.addBeanPropertySetter("Data/Record/currency", "currency");
        d.addCallMethod("Data/Record/createdDate", "setTime", 1);
        d.addCallParam("Data/Record/createdDate", 0);
        d.addBeanPropertySetter("Data/Record/productid", "productId");
//        d.addBeanPropertySetter("Data/Record/loginname","loginName");
        d.addCallMethod("Data/Record/loginname", "setLoginNameSubString3", 1);
        d.addCallParam("Data/Record/loginname", 0);
        d.addBeanPropertySetter("Data/Record/deviceType", "deviceType");
        d.addCallMethod("Data/Record/transactionSubtypeid", "setFlagAccordingRequesttype", 1);
        d.addCallParam("Data/Record/transactionSubtypeid", 0);
    }

    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        return null;
    }
}
