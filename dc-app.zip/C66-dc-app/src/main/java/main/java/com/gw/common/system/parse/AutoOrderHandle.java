package main.java.com.gw.common.system.parse;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.common.system.parse.vo.OrderRes;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.digester3.Digester;

import java.util.Map;

@Slf4j
public class AutoOrderHandle extends AbstractHandle {

    public String retrieveData(String url, Map<String, Object> paramaterMap) throws GWCallRemoteApiException {
        String content = "";
        try {
            log.info("url=" + url + "  parama=" + paramaterMap);
            content = new HttpUtil().httpGet(url, paramaterMap);
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new GWCallRemoteApiException("Failed to call remote interface!" + ex.getMessage(), ex);
        }

        return content;
    }

    public void parseRules(Digester d) {
        d.addObjectCreate("Data", OrderRes.class);
        d.addSetProperties("Data", "status", "code");
        d.addSetProperties("Data", "desc", "comment");
        d.addSetProperties("Data", "Page", "numpage");
        d.addSetProperties("Data", "PageLimit", "perpage");
        d.addSetProperties("Data", "TotalNumber", "total");
        d.addSetProperties("Data", "TotalPage", "totalPages");

        d.addObjectCreate("Data/Record", OrderEntity.class);
        d.addSetNext("Data/Record", "addOrder");
        {
            d.addBeanPropertySetter("Data/Record/loginName", "loginName"); // 用戶名
            d.addBeanPropertySetter("Data/Record/betNo", "billNo"); // 注单号
            d.addBeanPropertySetter("Data/Record/orderNo", "gmCode");  // 局号, 订单号

            d.addCallMethod("Data/Record/orderDate", "setTimeBillTime", 1); // 下注日期
            d.addCallParam("Data/Record/orderDate", 0); // 下注日期
            d.addCallMethod("Data/Record/settlementDate", "setTimeReckonTime", 1);
            d.addCallParam("Data/Record/settlementDate", 0); // 派彩日期
            d.addBeanPropertySetter("Data/Record/gameKind", "gameKind"); // 遊戲大類 ex. 真人/电子/体育/彩票
            d.addBeanPropertySetter("Data/Record/gameType", "gameType"); // 游戏种类 ex 真人(百家乐/龙虎)/ 电子(猛龙传奇/斗三公/日本武士)/体育(Billiards /Soccer /Basketball )/ 彩票(北京keno8/重庆时时彩(10选5)/加拿大西部/上海时时乐)
            d.addBeanPropertySetter("Data/Record/playType", "playType");  // 玩法类型 ex. 闲/庄/超和/和值/庄对
            d.addBeanPropertySetter("Data/Record/flag", "flag"); // 1:结算SETTLED,0:结算UNSETTLED,-9:取消CANCELED
            d.addBeanPropertySetter("Data/Record/result", "result"); //(输赢/开牌结果) ex.W: Win/L: Lose
            d.addBeanPropertySetter("Data/Record/betAmount", "account"); // 下注金额
            d.addBeanPropertySetter("Data/Record/validAmount", "validAccount"); // 有效投注额
            d.addBeanPropertySetter("Data/Record/winAmount", "cusAccount"); // 客户输赢度
            d.addBeanPropertySetter("Data/Record/currency", "currency"); // 币别
            d.addBeanPropertySetter("Data/Record/previousBalance", "previosAmount"); // 前次剩余额度
            d.addBeanPropertySetter("Data/Record/productId", "productId"); // 产品
            d.addBeanPropertySetter("Data/Record/deviceType", "deviceType"); // 终端 0：电脑网页版，1:手机网页版/手机网站APP,101:手机厅方APP
            d.addBeanPropertySetter("Data/Record/odds", "odds"); // 赔率
            d.addBeanPropertySetter("Data/Record/oddsType", "oddsType");  // 盘口
            d.addBeanPropertySetter("Data/Record/resultType", "resultType"); // todo, like result
            d.addBeanPropertySetter("Data/Record/jackpotAmount", "jackpotAmount"); // 彩金
        }
    }

    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        // TODO Auto-generated method stub
        return null;
    }
}
