package main.java.com.gw.common.system.parse;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.common.system.parse.vo.OrderRes;
import org.apache.commons.digester3.Digester;
import org.apache.commons.lang.StringUtils;

import java.util.HashMap;
import java.util.Map;

@Slf4j
public class BOCustomerHandle extends AbstractHandle {

    @Override
    public String getUrl(Map<String, Object> parameterMap) {
        return null;
    }

    @Override
    public String retrieveData(Map<String, Object> parameterMap) throws GWCallRemoteApiException {
        return null;
    }

    public static void main(String[] args) {

        Map<String, Object> parameterMap = new HashMap<String, Object>();
        parameterMap.put(UtilConstants.COMMAND, UtilConstants.COMMAND_VIEW);
        parameterMap.put(UtilConstants.MODULE, UtilConstants.CUSTOMER_MODULE);
        parameterMap.put("api_username", "api@cf88.com");
        parameterMap.put("api_password", "5TbTuRQamM00R2f0JTPA");
        parameterMap.put("api_whiteLabel", "cf88");

        parameterMap.put(UtilConstants.FILTER_ID, "25797");

//        parameterMap.put("FILTER[date][min]", "2015-01-16 02:25:00");
//        parameterMap.put("num", "400");
//        parameterMap.put("endtime", "2015-01-16 02:44:59");
//        
//        parameterMap.put("begintime", "2015-01-16 02:25:00");
//        parameterMap.put("task_id", "129");
//        parameterMap.put("baseUrl", "http://www.api.finance.cfoption88.com/Api");
//        parameterMap.put("FILTER[date][max]", "2015-01-16 02:44:59");


        AbstractHandle handle = new BOCustomerHandle();
        String url = "http://www.api.finance.cfoption88.com/Api";
        String result;
        try {
            result = new HttpUtil().doPost(url, parameterMap);
            String[] substr = StringUtils.substringsBetween(result, "<data", "><id>");
            for (String substr1 : substr) {
                result = result.replace("data" + substr1, "data");
            }
            System.out.println(result);
            System.out.println(UtilConstants.B01REALPREFIX + handle.parse(result).getReturnCode());
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public void parseRules(Digester d) {
        d.addObjectCreate("status", OrderRes.class);
        // d.addBeanPropertySetter("status/connection_status", "code");
        d.addBeanPropertySetter("status/Customer/data/FirstName", "returnCode");
    }


    public String getLoginname(Map<String, Object> parameterMap, String customerId) {
        Map<String, Object> parameterMapTemp = new HashMap<String, Object>();
        parameterMapTemp.put(UtilConstants.COMMAND, UtilConstants.COMMAND_VIEW);
        parameterMapTemp.put(UtilConstants.MODULE, UtilConstants.CUSTOMER_MODULE);
        parameterMapTemp.put("api_username", parameterMap.get("api_username"));
        parameterMapTemp.put("api_password", parameterMap.get("api_password"));
        parameterMapTemp.put("api_whiteLabel", parameterMap.get("api_whiteLabel"));
        parameterMapTemp.put(UtilConstants.FILTER_ID, customerId);

        AbstractHandle handle = new BOCustomerHandle();
        String url = parameterMap.get("baseUrl").toString();
        String result;
        try {
            result = new HttpUtil().doPost(url, parameterMapTemp);
            if (!StringUtils.isBlank(result)) {
                String[] substrArray = StringUtils.substringsBetween(result, "<data", "><id>");
                if (substrArray != null) {
                    for (String substr : substrArray) {
                        result = result.replace("data" + substr, "data");
                    }
                    return handle.parse(result).getReturnCode();
                }
            }

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return "";
    }
}
