package main.java.com.gw.common.system.parse;

import java.util.HashMap;
import java.util.Map;

import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.system.parse.vo.OrderRes;

import org.apache.commons.digester3.Digester;
import org.apache.commons.lang.StringUtils;

import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.datacenter.order.entity.OrderEntity;

public class BOOrderHandle extends AbstractHandle {

    @Override
    public String getUrl(Map<String, Object> parameterMap) {
        return null;
    }

    @Override
    public String retrieveData(Map<String, Object> parameterMap) throws GWCallRemoteApiException {
        return null;
    }

    public static void main(String[] args) {

        Map<String, Object> parameterMap = new HashMap<String, Object>();

        // parameterMap.put("baseUrl", "http://www.api.finance.cfoption88.com/Api");

        parameterMap.put(UtilConstants.COMMAND, UtilConstants.COMMAND_VIEW);
        parameterMap.put(UtilConstants.MODULE, UtilConstants.POSITION_MODULE);
        // parameterMap.put(UtilConstants.ISDEMO, 1);
        // parameterMap.put("FILTER[isDemo]", 0);
        parameterMap.put("api_username", "api@cf88.com");
        parameterMap.put("api_password", "5TbTuRQamM00R2f0JTPA");
        parameterMap.put("api_whiteLabel", "cf88");

        // parameterMap.put(UtilConstants.FILTER_MINDATE, "2015-02-23 08:00:00");
        // parameterMap.put(UtilConstants.FILTER_MAXDATE, "2015-02-23 09:00:00");

        // parameterMap.put("FILTER[status]", "open");

        parameterMap.put("LFILTER[options][endDate][min]", "2015-02-23 03:00:00");
        parameterMap.put("LFILTER[options][endDate][max]", "2015-02-23 05:30:00");

        parameterMap.put("page", "1");

        // parameterMap.put("num", "400");
        // parameterMap.put("endtime", "2015-02-09 04:00:00");
        // parameterMap.put("begintime", "2015-02-09 05:00:00");
        // parameterMap.put("task_id", "129");
        // parameterMap.put("FILTER[id]", "38036");

        // parameterMap.put("size", "10000");
        AbstractHandle handle = new BOOrderHandle();
        String url = "http://www.api.finance.cfoption88.com/Api";
        String result;
        try {
            result = new HttpUtil().doPost(url, parameterMap);
            System.out.println(result);
            System.out.println("==============================================================================");
            String[] substr = StringUtils.substringsBetween(result, "<data", "><executionDate>");
            for (int i = substr.length - 1; i >= 0; i--) {
                result = result.replace("data" + substr[i], "data");
            }
            System.out.println(result);
            System.out.println(handle.parse(result).getOrderList());
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public void parseRules(Digester d) {
        d.addObjectCreate("status", OrderRes.class);
        // d.addBeanPropertySetter("status");
        // d.addBeanPropertySetter("status", "total");
        // d.addBeanPropertySetter("status");
        d.addBeanPropertySetter("status/connection_status", "returnCode");
        d.addBeanPropertySetter("status/operation_status", "comment");
        d.addObjectCreate("status/Positions/data", OrderEntity.class);
        d.addSetNext("status/Positions/data", "addOrder");

        d.addBeanPropertySetter("status/Positions/data/customerId", "loginName");

        d.addBeanPropertySetter("status/Positions/data/id", "billNo");
        d.addBeanPropertySetter("status/Positions/data/amount", "account");
        d.addBeanPropertySetter("status/Positions/data/payout", "cusAccount");// payout-amount
        d.addBeanPropertySetter("status/Positions/data/payout", "validAccount");// abs(payout-amount)

        d.addCallMethod("status/Positions/data/date", "setTime__0to8", 1);
        d.addCallParam("status/Positions/data/date", 0);

        d.addBeanPropertySetter("status/Positions/data/name", "tableCode");
        d.addBeanPropertySetter("status/Positions/data/format", "gameType");
        d.addBeanPropertySetter("status/Positions/data/profit", "playType");//
        d.addBeanPropertySetter("status/Positions/data/ip", "curIp");
        d.addBeanPropertySetter("status/Positions/data/status", "gmCode");
        d.addBeanPropertySetter("status/Positions/data/isDemo", "hashCode");
    }
}
