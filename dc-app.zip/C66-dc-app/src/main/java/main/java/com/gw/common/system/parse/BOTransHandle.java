package main.java.com.gw.common.system.parse;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import main.java.com.gw.common.system.parse.vo.OrderRes;
import main.java.com.gw.datacenter.accounttransfer.entity.AccountTransferEntity;

import org.apache.commons.digester3.Digester;
import org.apache.commons.lang.StringUtils;

import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.common.system.parse.vo.Result;

public class BOTransHandle extends AbstractHandle {

    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        return null;
    }

    @Override
    public String retrieveData(Map<String, Object> paramaterMap) throws GWCallRemoteApiException {
        return null;
    }

    public static void main(String[] args) {

        Map<String, Object> paramaterMap = new HashMap<String, Object>();

        // flag=1,
        // num=400,
        // endtime=2015-01-15 04:44:59,
        // begintime=2015-01-15 04:25:00,
        // task_id=261,

        // FILTER[date][min]=2015-01-15 04:20:00,
        // api_password=5TbTuRQamM00R2f0JTPA,
        // api_username=api@cf88.com,
        // MODULE=Withdrawal,
        // FILTER[date][max]=2015-01-15 04:24:59,
        // COMMAND=view,
        // page=1,
        // api_whiteLabel=cf88
        paramaterMap.put("task_id", "261");
        paramaterMap.put("num", "400");
        paramaterMap.put("flag", "1");
        paramaterMap.put("begintime", "2015-01-16 09:00:00");
        paramaterMap.put("endtime", "2015-01-16 23:59:59");

        paramaterMap.put(UtilConstants.COMMAND, UtilConstants.COMMAND_VIEW);
        paramaterMap.put(UtilConstants.MODULE, UtilConstants.WITHDRAWAL_MODULE);
        String lable = "Withdrawal";

        // paramaterMap.put(UtilConstants.MODULE, UtilConstants.CUSTOMERDEPOSITS_MODULE);
        // String lable = "CustomerDeposits";

        paramaterMap.put("api_username", "api@cf88.com");
        paramaterMap.put("api_password", "5TbTuRQamM00R2f0JTPA");
        paramaterMap.put("api_whiteLabel", "cf88");
        paramaterMap.put(UtilConstants.FILTER_REQUESTTIME_MIN, "2015-01-16 00:00:00");
        paramaterMap.put(UtilConstants.FILTER_REQUESTTIME_MAX, "2015-01-16 23:59:59");
        // paramaterMap.put("page", "1");
        // paramaterMap.put("size", "2000");

        AbstractHandle handle = new BOTransHandle();
        String url = "http://www.api.finance.cfoption88.com/Api";
        String result;
        try {
            result = new HttpUtil().doPost(url, paramaterMap);
            Result res = new Result();
            if (!StringUtils.isBlank(result)) {
                String[] substrArray = StringUtils.substringsBetween(result, "<data", "><id>");
                if (substrArray != null) {
                    for (String substr : substrArray) {
                        result = result.replace("data" + substr, "data");
                    }
                    res = handle.parse(result, lable);
                }
            }
            System.out.println(result);
            System.out.println(handle.parse(result, lable).getOrderList());
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public void parseRules(Digester d, String lable) {
        d.addObjectCreate("status", OrderRes.class);
        d.addBeanPropertySetter("status/connection_status", "returnCode");
        d.addBeanPropertySetter("status/operation_status", "comment");
        d.addObjectCreate("status/" + lable + "/data", AccountTransferEntity.class);
        d.addSetNext("status/" + lable + "/data", "addOrder");
        // d.addCallMethod("Result/DealList/Item", "setTradeNo", 1);
        // d.addCallParam("Result/DealList/Item", 0, "id");

        d.addBeanPropertySetter("status/" + lable + "/data/customerId", "userName");
        d.addBeanPropertySetter("status/" + lable + "/data/transactionID", "transId");
        d.addBeanPropertySetter("status/" + lable + "/data/type", "transferType");
        d.addBeanPropertySetter("status/" + lable + "/data/amount", "transferAmount");
        d.addCallMethod("status/" + lable + "/data/requestTime", "setTime__0to8", 1);
        d.addCallParam("status/" + lable + "/data/requestTime", 0);

    }
}
