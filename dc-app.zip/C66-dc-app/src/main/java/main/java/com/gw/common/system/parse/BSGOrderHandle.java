package main.java.com.gw.common.system.parse;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.common.framework.util.MD5;
import main.java.com.gw.common.system.parse.vo.OrderRes;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.digester3.Digester;

import java.util.HashMap;
import java.util.Map;

@Slf4j
public class BSGOrderHandle extends AbstractHandle {

    public String retrieveData(String url, Map<String, Object> paramaterMap) throws GWCallRemoteApiException {
        String content = "";
        try {
            log.info("url=" + url + "  parama=" + paramaterMap);
            content = new HttpUtil().httpGet(url, paramaterMap);
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new GWCallRemoteApiException("Failed to call remote interface!" + ex.getMessage(), ex);
        }

        return content;

    }

    public static void main(String[] args) {
        Map<String, Object> paramaterMap = new HashMap<String, Object>();
        String baseUrl = "http://localhost:8081/commonwallet_datacenter/BSGBetRecord.do";
        String productid = "A03,B01";// "0";
        paramaterMap.put("productId", productid);
        String starttime = "2016-07-01 16:05:00";
        String endtime = "2016-07-01 16:09:59";
        paramaterMap.put("starttime", starttime);
        paramaterMap.put("endtime", endtime);
        String page = "1";
        paramaterMap.put("page", page);
        String num = "500";
        paramaterMap.put("num", num);
        String gameCode = "85";
        paramaterMap.put("gameCode", gameCode);
        String key = MD5.md5Encoding("12").toUpperCase();
        paramaterMap.put("key", key);
        AbstractHandle handle = new BSGOrderHandle();
        try {
            String result = handle.retrieveData(baseUrl, paramaterMap);
            System.out.println(result);
            System.out.println(handle.parse(result).getOrderList());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void parseRules(Digester d) {
        d.addObjectCreate("Data", OrderRes.class);
        d.addSetProperties("Data", "sattus", "code");
        d.addSetProperties("Data", "desc", "comment");
        d.addSetProperties("Data", "Page", "numpage");
        d.addSetProperties("Data", "PageLimit", "perpage");
        d.addSetProperties("Data", "TotalNumber", "total");
        d.addSetProperties("Data", "TotalPage", "totalPages");
        d.addObjectCreate("Data/Record", OrderEntity.class);
        d.addSetNext("Data/Record", "addOrder");
        d.addBeanPropertySetter("Data/Record/WagersID", "billNo");
        d.addBeanPropertySetter("Data/Record/BeforeBalance", "previosAmount");
        d.addBeanPropertySetter("Data/Record/CurrentBalance", "currentAmount");
        d.addBeanPropertySetter("Data/Record/ResultType", "playType");
        d.addBeanPropertySetter("Data/Record/BonusAmount", "bonusAmount");
        d.addCallMethod("Data/Record/Amount", "setBetSoftBetAmount", 1);
        d.addCallParam("Data/Record/Amount", 0);
        d.addBeanPropertySetter("Data/Record/RoundNo", "round");
        d.addBeanPropertySetter("Data/Record/GameType", "gameType");
        d.addBeanPropertySetter("Data/Record/Currency", "currency");
        d.addBeanPropertySetter("Data/Record/deviceType", "deviceType");
        d.addCallMethod("Data/Record/WagersDate", "setTime", 1);
        d.addCallParam("Data/Record/WagersDate", 0);
        d.addBeanPropertySetter("Data/Record/ProductID", "productId");
        d.addBeanPropertySetter("Data/Record/UserName", "loginName");
        d.addCallMethod("Data/Record/UserName", "setDefaultFlag");
    }

    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        // TODO Auto-generated method stub
        return null;
    }

}
