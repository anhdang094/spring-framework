package main.java.com.gw.common.system.parse;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.system.parse.vo.OrderRes;
import main.java.com.gw.common.system.parse.vo.Result;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.digester3.Digester;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Slf4j
public class Bet188Handle extends AbstractHandle {

    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        String baseUrl = (String) paramaterMap.get("baseUrl");
        String begin = (String) paramaterMap.get("begintime");
        begin = DateUtil.formatSource2Target(begin, DateUtil.C_TIME_PATTON_DEFAULT, DateUtil.C_TIME_PATTON_DEFAULT7);
        String end = (String) paramaterMap.get("endtime");
        end = DateUtil.formatSource2Target(end, DateUtil.C_TIME_PATTON_DEFAULT, DateUtil.C_TIME_PATTON_DEFAULT7);
        paramaterMap.put("xml", generateXml("GetWagerInfoByDateRange", begin, end));
        log.info("paramater  ===>" + paramaterMap);
        return baseUrl;
    }

    private String generateXml(String methodName, String beginTime, String endTime) {
        StringBuffer xmlBuffer = new StringBuffer();
        xmlBuffer.append("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
        xmlBuffer.append("<Request Method=\"" + methodName + "\">");
        xmlBuffer.append("<Begin>" + beginTime + "</Begin>");
        xmlBuffer.append("<End>" + endTime + "</End>");
        xmlBuffer.append("<MemberCode></MemberCode>");
        xmlBuffer.append("</Request>");
        return xmlBuffer.toString();
    }

    public static void main(String[] args) {
        String begintime = "2014-09-01 00:00:00";
        String endtime = "2014-09-01 23:59:59";
        Date bDate = DateUtil.formatStr2Date(begintime, DateUtil.C_TIME_PATTON_DEFAULT);
        Date eDate = DateUtil.formatStr2Date(endtime, DateUtil.C_TIME_PATTON_DEFAULT);
        for (int i = 1; i < 5; i++) {
            begintime = DateUtil.defineDayBefore2Str(bDate, i);
            endtime = DateUtil.defineDayBefore2Str(eDate, i);
            String iv = ThreeDES.getIV(16);
            String key = "HhLlGg2os9hj45r8";
            Map<String, Object> parameterMap = new HashMap<String, Object>();
            parameterMap.put("baseUrl", "http://spitest.happy778.com/Sportsbook/GetWagerInfoByDateRange");
            parameterMap.put("password", key);
            parameterMap.put("username", "m1");
            parameterMap.put("begintime", begintime);
            parameterMap.put("endtime", endtime);
            parameterMap.put("iv", iv);
            AbstractHandle handle = new Bet188Handle();
            try {
                String str = handle.retrieveData(parameterMap);
//				System.out.println(str);
                String response = ThreeDES.decrypt(str, key, key);
                System.out.println(response);
                Result res = handle.parse(response);
//				System.out.println(res.total);
                if (res.getOrderList().size() > 0)
                    for (int j = 0; j < res.getOrderList().size(); j++) {
                        System.out.print(res.getOrderList().get(j).toString());
                    }
            } catch (Exception e) {
                e.printStackTrace();
            }

            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }


    @Override
    public String retrieveData(Map<String, Object> paramaterMap)
            throws GWCallRemoteApiException {
        String wholeRrl = getUrl(paramaterMap);
        String _str_key = (String) paramaterMap.get(UtilConstants.ACCOUNT_TRANSFER_PASSWORD);
        String _str_iv = (String) paramaterMap.get("iv");
        String _str_merchant_id = (String) paramaterMap.get(UtilConstants.ACCOUNT_TRANSFER_USERNAME);
        String xml = (String) paramaterMap.get("xml");
        String _encode_xml = ThreeDES.encrypt(xml, _str_key, _str_key);
        String mid = ThreeDES.encrypt(_str_merchant_id, _str_key, _str_iv);
        mid = _str_iv + mid;
        StringBuffer stringBuffer = new StringBuffer();
        HttpURLConnection conn = null;
        BufferedReader bufferReader = null;
        InputStream inutStream = null;
        String xmlStr = null;
        try {
            log.info("whole url ===>" + wholeRrl);
            if (wholeRrl != null) {
                URL url = new URL(wholeRrl);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestProperty("mid", mid);
                conn.setDoOutput(true);
                conn.setDoInput(true);
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(70000);
                conn.connect();
                PrintWriter out = new PrintWriter(new OutputStreamWriter(conn.getOutputStream()));
                out.print(_encode_xml);
                out.flush();
                out.close();
                int rec = 0;
                rec = conn.getResponseCode();
                inutStream = conn.getInputStream();
                bufferReader = new BufferedReader(new InputStreamReader(inutStream));
                while ((xmlStr = bufferReader.readLine()) != null) {
                    stringBuffer.append(xmlStr);
                }
            }
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            log.error("Call remote interface failure with URL:" + wholeRrl);
            throw new GWCallRemoteApiException("Failed to call remote interface!" + ex.getMessage(), ex);
        } finally {
            if (bufferReader != null) {
                try {
                    bufferReader.close();
                } catch (Exception e) {
                    log.error("Close buffer stream failure!", e);
                }
            }
            if (inutStream != null) {
                try {
                    inutStream.close();
                } catch (Exception e) {
                    log.error("Close inputstream failure!", e);
                }
            }
            if (conn != null) {
                conn.disconnect();
            }
        }
        log.info("Call remote interface successfully by URL:" + wholeRrl);
        return stringBuffer.toString();
    }


    public void parseRules(Digester d) {
        d.addObjectCreate("Response", OrderRes.class);
        d.addBeanPropertySetter("Response/perpage");
        d.addBeanPropertySetter("Response/Total", "total");
        d.addBeanPropertySetter("Response/numpage");
        d.addBeanPropertySetter("Response/ReturnCode", "returnCode");
        d.addBeanPropertySetter("Response/Description", "comment");
        d.addObjectCreate("Response/Wagers/TimeSpanBetWagerInfoDto", OrderEntity.class);
        d.addSetNext("Response/Wagers/TimeSpanBetWagerInfoDto", "addOrder");
        d.addBeanPropertySetter("Response/Wagers/TimeSpanBetWagerInfoDto/WagerNo", "billNo");
        d.addBeanPropertySetter("Response/Wagers/TimeSpanBetWagerInfoDto/TotalStakeF", "account");
        d.addBeanPropertySetter("Response/Wagers/TimeSpanBetWagerInfoDto/TotalStakeF", "validAccount");
        d.addCallMethod("Response/Wagers/TimeSpanBetWagerInfoDto/DateCreated", "setTime", 1);
        d.addCallParam("Response/Wagers/TimeSpanBetWagerInfoDto/DateCreated", 0);
        d.addBeanPropertySetter("Response/Wagers/TimeSpanBetWagerInfoDto/UserCode", "loginName");
        d.addBeanPropertySetter("Response/Wagers/TimeSpanBetWagerInfoDto/SportName", "gameType");
        d.addBeanPropertySetter("Response/Wagers/TimeSpanBetWagerInfoDto/MemberIPAddress", "curIp");
        d.addBeanPropertySetter("Response/Wagers/TimeSpanBetWagerInfoDto/BetTypeName", "playType");
        d.addBeanPropertySetter("Response/Wagers/TimeSpanBetWagerInfoDto/EventId", "gmCode");
        d.addSetProperties("Response/Wagers/TimeSpanBetWagerInfoDto/WinLossAmount", "xsi:nil", "cusAccountStr");
        d.addSetProperties("Response/Wagers/TimeSpanBetWagerInfoDto/SettlementStatus", "xsi:nil", "flag");

        d.addBeanPropertySetter("Response/Wagers/TimeSpanBetWagerInfoDto/WinLossAmount", "cusAccountStr");
        d.addBeanPropertySetter("Response/Wagers/TimeSpanBetWagerInfoDto/SettlementStatus", "flag");


//		d.addBeanPropertySetter("Response/Wagers/TimeSpanBetWagerInfoDto/SettlementStatus", "flag");
//		d.addBeanPropertySetter("Response/Wagers/TimeSpanBetWagerInfoDto/WinLossAmount", "cusAccount");

    }

}
