package main.java.com.gw.common.system.parse;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.HttpClientUtils;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Slf4j
public class CQ9OrderHandle {

    private static final String TIME_SUFFIX = "-04:00";// 时间参数后缀

    private static final String END_TIME_SUFFIX = ".999-04:00";// 时间参数后缀
    private static final String T_STR = "T";//


    /**
     * CQ9获取数据接口
     *
     * @param url
     * @param parameterMap
     * @return
     * @throws IOException
     */
    public List<OrderEntity> getNewCQ9OrderRecord(String url, Map<String, Object> parameterMap) throws Exception {
        HttpUtil http = new HttpUtil();
        List<OrderEntity> list = new ArrayList<>();//定义一个集合对象把返回的数据存放到这里
        String timeZone = (String) parameterMap.get("timeZone");
        String productId = (String) parameterMap.get(UtilConstants.GLOBAL_PRODUCTID_KEY);
//        String platformId = (String) parameterMap.get(UtilConstants.GLOBAL_PLATFORMID_KEY);
        String platformId =  UtilConstants.CQ9;;
        String remark = (String) parameterMap.get("remark");
//        String productId =   parameterMap.get("productId").toString();
        String currency = (String) parameterMap.get("currency");
        String begintime = (String) parameterMap.get("begintime");
        String endtime = (String) parameterMap.get("endtime");
        //配置请求头
        Map<String, String> headers = Maps.newHashMap();
        String token = parameterMap.get(UtilConstants.ACCOUNT_TRANSFER_AGCODE).toString().trim();
        headers.put("Authorization", token );
        //headers.put("Content-Type", "application/x-www-form-urlencoded");
        //配置参数

        String result = "";

        String  starttimeStr = begintime.replace(" ", T_STR) + TIME_SUFFIX;
        String  endtimeStr  =  endtime.replace(" ", T_STR) + END_TIME_SUFFIX;
        int page = Integer.parseInt( parameterMap.get(UtilConstants.ORDER_PAGE).toString() );
        int pagesize = Integer.parseInt( parameterMap.get(UtilConstants.ORDER_PAGE_NUMBER).toString() );
         url = MessageFormat.format(url, starttimeStr,endtimeStr, page, pagesize);
        try {
            result = HttpClientUtils.execGetWithHeader(url, null, headers);
            log.info("CQ9-注单抓取-url-{}-#####-Authorization-{}--#####-#####-result-{}",url ,token,result);
        }catch (Exception e){
            log.error("CQ9-注单抓取-HTTP请求异常-detail-{}" ,e);
            throw new GWCallRemoteApiException("CQ9-注单抓取-HTTP请求异常",e);
        }
        if (StringUtils.isEmpty(result)) {
            log.error("getNewCQ9OrderRecord  log, resonse no data");
            throw new GWCallRemoteApiException("CQ9-注单抓取-response==null");
        }
        JSONObject jsonObject = null;
        try {
            jsonObject = JSONObject.parseObject(result);
            JSONObject statusObject = jsonObject.getJSONObject("status");
            if (statusObject.getInteger("code") != 0) {
                return list;
            }
        } catch (Exception e) {
            log.error("newcq9-拉取注单结果解析异常-{}" ,e);
        }
        if(jsonObject.getJSONObject("data")==null){
            return list;
        }
        JSONObject data = jsonObject.getJSONObject("data");
        Integer totalSize = data.getInteger("TotalSize");
        if (0 == totalSize) {
            log.info("getNewCQ9OrderRecord data is null");
            return list;
        }
        parameterMap.put("apiTotal", totalSize);
        JSONArray resultList = data.getJSONArray("Data");
        for (int i = 0; i < resultList.size(); i++) {
            JSONObject o = (JSONObject) resultList.get(i);
            OrderEntity orderEntity = new OrderEntity();
            orderEntity.setBillNo(o.getString("round"));//注单
            orderEntity.setLoginName(o.getString("account").substring(productId.trim().length()));//玩家
            orderEntity.setAgCode(o.getString("cq9"));
            orderEntity.setTopAgCode(platformId);
            orderEntity.setPlatId(platformId);
            orderEntity.setProductId(productId);
//            orderEntity.setGmCode();//
            String bettime = o.getString("bettime");
            begintime = bettime.replace(TIME_SUFFIX, "");
            orderEntity.setBillTime(getDate(begintime, timeZone));
            log.info("betttimecq9:{}",orderEntity.getBillTime());

            orderEntity.setFlag(1);//拉到得注单都是已结算得
            orderEntity.setRemark(remark);
            orderEntity.setCurrency(currency);
            orderEntity.setTableCode(o.getString("tableid"));
            orderEntity.setRound(o.getString("roundnumber"));
            orderEntity.setGameType(o.getString("gamecode"));
            orderEntity.setGameKind(UtilConstants.ELECT_GAME_KIND);
            orderEntity.setAccount(getBigDecimal(o, "bet"));
            // TODO ： 注意 电游类 没有 validbet ，getBigDecimal(o, "validbet")
            orderEntity.setValidAccount( getBigDecimal(o, "bet") );
            orderEntity.setValidAccountStr(o.getString("bet"));
            orderEntity.setCurrentAmount(getBigDecimal(o, "balance"));
            orderEntity.setCreationDate(orderEntity.getBillTime());
            orderEntity.setOrignalBillTime(orderEntity.getBillTime());
            orderEntity.setOrignalReckonTime(orderEntity.getBillTime());
            orderEntity.setOrignalTimezone(timeZone);
            BigDecimal gameWin = getBigDecimal(o, "win");
            orderEntity.setBonusAmount( BigDecimal.ZERO  );
            orderEntity.setRemainAmount(orderEntity.getValidAccount().setScale(2, RoundingMode.HALF_UP));
            orderEntity.setResult("");//
            orderEntity.setDeviceType( "0");//
            orderEntity.setExchangeRate(BigDecimal.ONE);
            orderEntity.setTermType("0");
            //计算输赢
            String gametype = o.getString("gametype");
            if ("table".equals(gametype)) {
                BigDecimal gameRake = getBigDecimal(o, "rake");
                BigDecimal gameRoomFee = getBigDecimal(o, "roomfee");
                orderEntity.setCusAccount(gameWin.subtract(gameRake).subtract(gameRoomFee));//用户输赢
                orderEntity.setPreviosAmount( new BigDecimal(o.getString("balance")).add(gameRoomFee).add(gameRake).subtract(gameWin));
            } else {
                orderEntity.setCusAccount(gameWin.subtract(orderEntity.getAccount()));//用户输赢
                orderEntity.setPreviosAmount(new BigDecimal(o.getString("balance")).subtract(orderEntity.getCusAccount()));
            }
            list.add(orderEntity);
        }
        return list;
    }

    private BigDecimal getBigDecimal(JSONObject jsonObject, String fieldName) {
        BigDecimal bigDecimal = jsonObject.getBigDecimal(fieldName);
        return null == bigDecimal ? BigDecimal.ZERO : bigDecimal;
    }


    private Date getDate(String dateStr, String zone) {
//        if (null == dateStr) {
//            return null;
//        }
//        LocalDateTime parse = LocalDateTime.parse(dateStr.substring(0, 19), DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss"));
//        ZoneId zoneId = ZoneId.of(zone);
//        ZonedDateTime zonedDateTime = ZonedDateTime.of(parse, zoneId);
//        return Date.from(zonedDateTime.toInstant());
        Date   date= DateUtil.parseWithTimeZone(  dateStr.substring(0, 19),
                "yyyy-MM-dd'T'HH:mm:ss",zone );
        return date;
    }

}
