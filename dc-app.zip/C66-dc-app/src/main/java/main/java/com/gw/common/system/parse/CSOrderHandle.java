package main.java.com.gw.common.system.parse;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.*;
import main.java.com.gw.common.system.entity.CSOrderDetailEntity;
import main.java.com.gw.common.system.entity.CSOrderEntity;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;


/**
 * @author eagle
 */
@Slf4j
public class CSOrderHandle {


    /**
     * 获取CS(冠军体育)注单记录
     * @param url
     * @param parameterMap
     * @return
     */
    public List<Object> getCSOrderRecord(String url, Map<String, Object> parameterMap) throws Exception {
        List<Object> list = new ArrayList<>();
        //构建请求冠军体育查询订单信息接口
        boolean isPrintLog=ToolUtil.isNeedInterceptResponse(parameterMap.get(UtilConstants.ORDER_TASK_ID) + "");
        Map<String, Object> requestMap=bulidRequestMap(parameterMap,isPrintLog);
        String result=HttpClientUtils.postJson(url,null,JsonUtil.toJSONString(requestMap));
        if (isPrintLog) {
            log.info("Intercept:TaskId={},Url={},Response={}",parameterMap.get(UtilConstants.ORDER_TASK_ID),url,result);
        }
        if (StringUtils.isEmpty(result)) {
            log.info("getCSOrderRecord log, response no data, request params:{}",parameterMap);
            return list;
        }
        JSONObject object = JsonUtil.StringToJSONOBject(result);
        String returnCode = object.getJSONObject("header").getString("returnCode");
        if(Objects.equals(returnCode,"0")){
            JSONArray dataList=object.optJSONArray("content");
            if (dataList == null || dataList.isEmpty()) {
                return list;
            }
            String productId=parameterMap.get("productId").toString();
            String currency=parameterMap.get("currency").toString();
            String timeZone=parameterMap.get("timeZone").toString();
            for (int i = 0; i < dataList.size(); i++) {
                JSONObject object2 = dataList.getJSONObject(i);
                CSOrderEntity bean = (CSOrderEntity) JSONObject.toBean(object2,CSOrderEntity.class);
                JSONArray jsonDataList=object2.getJSONArray("details");
                if(!CollectionUtils.isEmpty(jsonDataList)){
                    List<CSOrderDetailEntity> details= (List<CSOrderDetailEntity>)JSONArray.toCollection(jsonDataList,CSOrderDetailEntity.class);
                    bean.setDetails(details);
                }
                /**CSOrderEntity转OrderEntity*/
                OrderEntity orderEntityTemp = transferEntityForCS(bean);
                orderEntityTemp.setProductId(productId);
                orderEntityTemp.setPlatId(UtilConstants.CS);
                orderEntityTemp.setCurrency(currency);
                orderEntityTemp.setDeviceType("1");
                orderEntityTemp.setGameKind(UtilConstants.GAME_KIND_ENUM.BALL.getCode());
                orderEntityTemp.setOrignalTimezone(timeZone);
                //洗码投注额计算
                ObjectConstructUtil.calculateValidAndRemainAmountForSportGame(orderEntityTemp);

                //BTTP-1456 A01 数据中心CS厅提前结算:提前结算cashout时，洗码投注额等于用户输赢值。这是临时处理方案，后续要全部移动到洗码计算公共方法中 modified by ziv 2019-12-24
                if (orderEntityTemp.getFlag() == 1 && bean.getBetResult() == 5) {
                    orderEntityTemp.setRemainAmount(orderEntityTemp.getCusAccount().setScale(6, RoundingMode.DOWN).abs());
                }

                list.add(orderEntityTemp);
            }
        }else{
            log.info("请求CS获取注单 getCSOrderRecord 返回失败:{}",result);
            throw new RuntimeException("请求CS获取注单 getCSOrderRecord 返回错误异常:"+result);
        }
        return list;
    }

    /**
     * 构建订单信息OrderEntity
     * @param entity
     * @return
     */
    public static OrderEntity transferEntityForCS(CSOrderEntity entity) {
        if (entity == null) {
            return null;
        }
        OrderEntity orderEntity = new OrderEntity();
        orderEntity.setLoginName(String.valueOf(entity.getPartnerUserId()));
        //订单单号
        orderEntity.setBillNo(entity.getOrderNum());
        orderEntity.setBillTime(new Date(entity.getCreatedAt()));
        orderEntity.setAccount(entity.getOrderAmount());
        //获取注单的结算状态
        int flag=getFlag(entity);
        if(flag==1){
            orderEntity.setValidAccount(entity.getOrderAmount());
            orderEntity.setCusAccount(entity.getRealBonus().subtract(entity.getOrderAmount()));
            if(BigDecimal.ZERO.compareTo(orderEntity.getCusAccount()) == 0){
                orderEntity.setValidAccount(BigDecimal.ZERO.setScale(2));
                orderEntity.setRemainAmount(BigDecimal.ZERO.setScale(2));
                //和局，更新游戏结果，洗码时判断使用
                orderEntity.setResult("Tie");
            }else{
                orderEntity.setValidAccount(entity.getOrderAmount());
                orderEntity.setRemainAmount(entity.getOrderAmount());
            }
        }else{
            //取消的注單和未结算不计算有效投注额
            orderEntity.setCusAccount(BigDecimal.ZERO.setScale(2));
            orderEntity.setValidAccount(BigDecimal.ZERO.setScale(2));
            orderEntity.setRemainAmount(BigDecimal.ZERO.setScale(2));
        }
        orderEntity.setPreviosAmount(entity.getOriginalAmount());
        //现额度=原额度+用户输赢额度
        orderEntity.setCurrentAmount(entity.getOriginalAmount().add(orderEntity.getCusAccount()));
        orderEntity.setCurrency(UtilConstants.CNY);
        orderEntity.setFlag(flag);
        orderEntity.setOrignalBillTime(new Date(entity.getUpdatedAt()));
        orderEntity.setOrignalReckonTime(new Date(entity.getUpdatedAt()));
        //设置赔率和盘口类型信息
        orderEntity.setOdds(entity.getTotalOdds());
        //厅方返回oddsType	int	赔率类型 1:小数式赔率 2:香港赔率 需转换1:小数式赔率为欧盘
        String oddsType=entity.getOddsType()==1? UtilConstants.OddsTypeEnum.DECIMAL.getValueStr()
                :String.valueOf(entity.getOddsType());
        orderEntity.setOddsType(oddsType);
        //获取当前注单的订单详情信息
        List<CSOrderDetailEntity> details=entity.getDetails();
        if(!CollectionUtils.isEmpty(details)){
            //设置游戏类型，判断如果类型全部相同则去任意一个，否则则是混合为-1
            CSOrderDetailEntity csOrderDetailEntity=details.stream().findFirst().get();
            boolean isMatch=details.stream().allMatch(detail->detail.getSportId()==csOrderDetailEntity.getSportId());
            //如果混合投注游戏类型，99999是CS平台游戏类型字典定义的混合类型
            String gameType=isMatch?String.valueOf(csOrderDetailEntity.getSportId()):"99999";
            orderEntity.setGameType(gameType);
        }
        orderEntity.setCreationDate(new Date(entity.getCreatedAt()));
        orderEntity.setReckonTime(new Date(entity.getUpdatedAt()));
        return orderEntity;
    }

    /**
     * phase值	名称	说明
     * 4	支付阶段	创建并被保存的订单已经经过必要的校验，因此订单最初阶段就是进入支付阶段
     * 5	提交结算阶段	支付完成后订单需要提交专门结算系统
     * 6	结算阶段	由结算系统负责对订单进行结算
     * 7	派奖阶段	结算完成后进入派奖阶段
     *
     * phase_status值	名称	说明
     * 1	初始化	处理阶段的最初状态，此时当前阶段的处理还未开始
     * 2	处理中	当前处理阶段已经开始，但还没有得到结果
     * 3	处理成功	当前处理阶段已结束，并且处理成功
     * 4	处理失败	当前处理阶段已结束，并且处理失败
     * 5	关闭	当前处理阶段已结束，并且没有处理结果，可以理解为流程被中断，处理结束，但没有最终处理结果
     * 6	失效	与关闭类似，单独定义是为了兼容更多业务场景
     *
     * 已撤销： 目前订单没有撤销状态，撤销操作的实际是把订单当作中奖来处理，并且奖金金额等于投注金额
     * @param entity
     * @return
     */
    private static int getFlag(CSOrderEntity entity){
        //默认未结算
        int flag=0;
        //处理阶段
        int phase=entity.getPhase();
        //处理阶段状态
        int phaseStatus=entity.getPhaseStatus();
        /**
         * phase==7派奖阶段并且phase_status=3处理成功，即flag对应为已结算
         */
        if(phase==7 && phaseStatus==3){
            //已结算
            flag=UtilConstants.ORDERS_FLAG_ENUM.SETTLED.getFalg();
        }else if(phase==5 && phaseStatus==4){
            //已撤销
            flag=UtilConstants.ORDERS_FLAG_ENUM.CANCELED.getFalg();
        }else{
            //未结算
            flag= UtilConstants.ORDERS_FLAG_ENUM.UNSETTLED.getFalg();
        }
        return flag;
    }

    /**
     * 构建订单查询抓取参数
     * @param parameterMap
     * @return
     */
    private Map<String, Object> bulidRequestMap(Map<String, Object> parameterMap,boolean isPrintLog) {
        Map<String, Object>  requestMap= Maps.newHashMap();
        try {
            String appId=parameterMap.get("app_id").toString();
            String publicKey=parameterMap.get("public_key").toString();
            //随机生成AES加密所需的密钥
            String secretKey =AESUtil.generateSecretKey();
            String crpTxNo = UUID.randomUUID().toString();
            long crpTimestamp = System.currentTimeMillis();
            JSONObject jsonObject=new JSONObject();
            jsonObject.put("crpTxNo", crpTxNo);
            jsonObject.put("crpTimestamp",crpTimestamp);
            jsonObject.put("crpLanguageCode", "1");
            jsonObject.put("startTime", parameterMap.get("startTime"));
            jsonObject.put("endTime", parameterMap.get("endTime"));
            if(isPrintLog){
                log.info("获取CS(冠军体育)注单记录加密前参数：{}",jsonObject.toString());
            }
            //对业务参数进行AES加密返回params
            String encryptedParams = AESUtil.encrypt(jsonObject.toString(),secretKey);
            //对业务参数进行先MD5然后Base64.encode生成签名
            String signStr =StringUtils.join(encryptedParams,crpTxNo,crpTimestamp,secretKey);
            String sign = MD5(signStr);
            //对参数的Aes秘钥进行RAS非对称加密处理
            String encryptedSecretKey = RSAUtil.encryptRSA(secretKey, publicKey);
            requestMap.put("appId", appId);
            requestMap.put("params", encryptedParams);
            requestMap.put("sign", sign);
            requestMap.put("secretKey", encryptedSecretKey);
        } catch (Exception e) {
            log.error("请求前增加接口签名参数出现异常:{}", e);
        }
        return requestMap;
    }

    private static String MD5(String data) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("MD5");
        return new String(Base64.encodeBase64(md.digest(data.getBytes(StandardCharsets.UTF_8))));
    }




    public static void main(String[] args) throws NoSuchAlgorithmException {
//        String publicKey="MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAzG/odNj/c807h3tvwXqXK2rpzYi75ZjEgEeGapbPhcp2FByZnzSutMBME9lQBF+YUT8vlw+rNKy0PMG3XdTGudmcgpuhRD1EIYnX31298nFkwobOmFr2rxqVMKyr6jOmSJugiG/1aroElnPmX+yTEmpd5KAhh4EsyZCXVgHUAs0oqNu6funjKVb5ZKdATHNDK1zSSIhaK0eZb5R0MIZtoO0U+3BdAe+ORyACDO9kwFlb1txnA/AEQqmNueZVDft8A8/Kx+Vz46QfJnDwytzeYkelSXPTsuCgi5nghjExrKJmCbAK4MVhIsjtbVvGw6vaE3Fwf5zNuxo+JQy7G0h9zwIDAQAB";
//        String crpTxNo = UUID.randomUUID().toString();
//        JSONObject jsonObject=new JSONObject();
//        long crpTimestamp=System.currentTimeMillis();
//        jsonObject.put("crpTxNo", crpTxNo);
//        jsonObject.put("crpTimestamp",crpTimestamp);
//        jsonObject.put("crpLanguageCode", "1");
//        jsonObject.put("startTime",DateUtil.formatStr2Date("2019-07-29 15:00:00","yyyy-MM-dd HH:mm:ss").getTime());
//        jsonObject.put("endTime", DateUtil.formatStr2Date("2019-07-29 15:10:00","yyyy-MM-dd HH:mm:ss").getTime());
//        //随机生成AES加密所需的密钥
//        String secretKey =AESUtil.generateSecretKey();
//        //对业务参数进行AES加密返回params
//        String encryptedParams = AESUtil.encrypt(jsonObject.toString(),secretKey);
//        //对业务参数进行先MD5然后Base64.encode生成签名
//        String signStr =StringUtils.join(encryptedParams,crpTxNo,crpTimestamp,secretKey);
//        String sign = MD5(signStr);
//        //对参数的Aes秘钥进行RAS非对称加密处理
//        String encryptedSecretKey = RSAUtil.encryptRSA(secretKey, publicKey);
//        Map<String,Object> requestMap=Maps.newLinkedHashMap();
//        requestMap.put("appId", "80080081");
//        requestMap.put("params", encryptedParams);
//        requestMap.put("sign", sign);
//        requestMap.put("secretKey", encryptedSecretKey);
//        System.out.println("输出请求参数json:"+JsonUtil.toJSONString(requestMap));

        String result = "{\"header\":{\"returnCode\":0,\"hasContent\":true,\"transactionNo\":\"30b68530-41a9-462b-ad5f-f69a2aceb94a\",\"receiveTime\":1*疑似敏感信息*921,\"receiveTimeString\":\"2020-03-06T14:38:51.921+0800\",\"responseTime\":1*疑似敏感信息*016,\"responseTimeString\":\"2020-03-06T14:38:52.016+0800\"},\"content\":[{\"id\":29720,\"orderNum\":\"2003060730265520\",\"partnerUserId\":\"gyhw123\",\"betTypeId\":1,\"betTypeName\":\"Single bet\",\"combinationsId\":1,\"combinationsName\":\"Single\",\"phase\":5,\"phaseStatus\":4,\"orderAmount\":1000.00,\"realOrderAmount\":null,\"betResult\":0,\"estimatedBonus\":1930.00,\"realBonus\":0.00,\"winOrLose\":null,\"totalOdds\":1.93,\"originalAmount\":8000.00,\"oddsType\":1,\"createdAt\":1*疑似敏感信息*553,\"updatedAt\":1*疑似敏感信息*824,\"phaseUpdatedAt\":1*疑似敏感信息*000,\"details\":[{\"id\":31734,\"matchId\":5766718,\"matchPeriodId\":5773977,\"matchTime\":1*疑似敏感信息*000,\"sportId\":1,\"sportName\":\"Football\",\"regionId\":1320,\"regionName\":\"South America\",\"leagueId\":4651,\"leagueName\":\"Copa Libertadores\",\"homeTeam\":\"EM Deportivo Binacional\",\"awayTeam\":\"Sao Paulo\",\"marketId\":3,\"marketName\":\"Over/Under\",\"eventPartnerId\":null,\"periodNum\":1,\"periodName\":null,\"isLive\":0,\"oddsId\":734276072,\"oddsValue\":1.93,\"argument\":9.50,\"score\":\"\",\"stakeName\":\"O\",\"stakeStatus\":1,\"stakeStatusName\":\"New\",\"finalScore\":\"\",\"createdAt\":1*疑似敏感信息*560,\"updatedAt\":1*疑似敏感信息*560}],\"orderStateName\":\"已拒绝\"}],\"error\":null}";
        JSONObject object = JsonUtil.StringToJSONOBject(result);
        String returnCode = object.getJSONObject("header").getString("returnCode");
        if(Objects.equals(returnCode,"0")) {
            JSONArray dataList = object.optJSONArray("content");
            for (int i = 0; i < dataList.size(); i++) {
                JSONObject object2 = dataList.getJSONObject(i);
                CSOrderEntity bean = (CSOrderEntity) JSONObject.toBean(object2, CSOrderEntity.class);
                JSONArray jsonDataList = object2.getJSONArray("details");
                if (!CollectionUtils.isEmpty(jsonDataList)) {
                    List<CSOrderDetailEntity> details = (List<CSOrderDetailEntity>) JSONArray.toCollection(jsonDataList, CSOrderDetailEntity.class);
                    bean.setDetails(details);
                }
                /**CSOrderEntity转OrderEntity*/
                OrderEntity orderEntityTemp = transferEntityForCS(bean);
                orderEntityTemp.setPlatId(UtilConstants.CS);
                orderEntityTemp.setDeviceType("1");
                orderEntityTemp.setGameKind(UtilConstants.GAME_KIND_ENUM.BALL.getCode());
                //洗码投注额计算
                ObjectConstructUtil.calculateValidAndRemainAmountForSportGame(orderEntityTemp);

                //BTTP-1456 A01 数据中心CS厅提前结算:提前结算cashout时，洗码投注额等于用户输赢值。这是临时处理方案，后续要全部移动到洗码计算公共方法中 modified by ziv 2019-12-24
                if (orderEntityTemp.getFlag() == 1 && bean.getBetResult() == 5) {
                    orderEntityTemp.setRemainAmount(orderEntityTemp.getCusAccount().setScale(6, RoundingMode.DOWN).abs());
                }

            }

        }}

/*    String result="{\n" +
            "    \"content\": [\n" +
            "        {\n" +
            "            \"betResult\": 12345678,\n" +
            "            \"betTypeId\": 12345678,\n" +
            "            \"betTypeName\": \"ABCD1234\",\n" +
            "            \"combinationsId\": 12345678,\n" +
            "            \"combinationsName\": \"ABCD1234\",\n" +
            "            \"createdAt\": 12345678,\n" +
            "            \"details\": [\n" +
            "                {\n" +
            "                    \"argument\": 12345678.00,\n" +
            "                    \"awayTeam\": \"ABCD1234\",\n" +
            "                    \"createdAt\": 12345678,\n" +
            "                    \"eventPartnerId\": 12345678,\n" +
            "                    \"finalScore\": \"ABCD1234\",\n" +
            "                    \"homeTeam\": \"ABCD1234\",\n" +
            "                    \"id\": 123456,\n" +
            "                    \"isLive\": 0,\n" +
            "                    \"leagueId\": 12345678,\n" +
            "                    \"leagueName\": \"ABCD1234\",\n" +
            "                    \"marketId\": 12345678,\n" +
            "                    \"marketName\": \"ABCD1234\",\n" +
            "                    \"matchId\": 12345678,\n" +
            "                    \"matchPeroidId\": 12345678,\n" +
            "                    \"matchTime\": 12345678,\n" +
            "                    \"oddsId\": 12345678,\n" +
            "                    \"oddsValue\": 300.00,\n" +
            "                    \"orderId\": 12345678,\n" +
            "                    \"periodName\": \"ABCD1234\",\n" +
            "                    \"periodNum\": 12345678,\n" +
            "                    \"regionId\": 12345678,\n" +
            "                    \"regionName\": \"ABCD1234\",\n" +
            "                    \"score\": \"ABCD1234\",\n" +
            "                    \"sportId\": 12345678,\n" +
            "                    \"sportName\": \"ABCD1234\",\n" +
            "                    \"stakeName\": \"ABCD1234\",\n" +
            "                    \"stakeStatus\": 12345678,\n" +
            "                    \"stakeStatusName\": \"ABCD1234\",\n" +
            "                    \"updatedAt\": 12345678\n" +
            "                },\n" +
            "                {\n" +
            "                    \"argument\": 12345678.00,\n" +
            "                    \"awayTeam\": \"ABCD1234\",\n" +
            "                    \"createdAt\": 12345678,\n" +
            "                    \"eventPartnerId\": 12345678,\n" +
            "                    \"finalScore\": \"ABCD1234\",\n" +
            "                    \"homeTeam\": \"ABCD1234\",\n" +
            "                    \"id\": 123457,\n" +
            "                    \"isLive\": 0,\n" +
            "                    \"leagueId\": 12345678,\n" +
            "                    \"leagueName\": \"ABCD1234\",\n" +
            "                    \"marketId\": 12345678,\n" +
            "                    \"marketName\": \"ABCD1234\",\n" +
            "                    \"matchId\": 12345678,\n" +
            "                    \"matchPeroidId\": 12345678,\n" +
            "                    \"matchTime\": 12345678,\n" +
            "                    \"oddsId\": 12345678,\n" +
            "                    \"oddsValue\": 600.00,\n" +
            "                    \"orderId\": 12345678,\n" +
            "                    \"periodName\": \"ABCD1234\",\n" +
            "                    \"periodNum\": 12345678,\n" +
            "                    \"regionId\": 12345678,\n" +
            "                    \"regionName\": \"ABCD1234\",\n" +
            "                    \"score\": \"ABCD1234\",\n" +
            "                    \"sportId\": 12345678,\n" +
            "                    \"sportName\": \"ABCD1234\",\n" +
            "                    \"stakeName\": \"ABCD1234\",\n" +
            "                    \"stakeStatus\": 12345678,\n" +
            "                    \"stakeStatusName\": \"ABCD1234\",\n" +
            "                    \"updatedAt\": 12345678\n" +
            "                },\n" +
            "                {\n" +
            "                    \"argument\": 12345678.00,\n" +
            "                    \"awayTeam\": \"ABCD1234\",\n" +
            "                    \"createdAt\": 12345678,\n" +
            "                    \"eventPartnerId\": 12345678,\n" +
            "                    \"finalScore\": \"ABCD1234\",\n" +
            "                    \"homeTeam\": \"ABCD1234\",\n" +
            "                    \"id\": 123458,\n" +
            "                    \"isLive\": 0,\n" +
            "                    \"leagueId\": 12345678,\n" +
            "                    \"leagueName\": \"ABCD1234\",\n" +
            "                    \"marketId\": 12345678,\n" +
            "                    \"marketName\": \"ABCD1234\",\n" +
            "                    \"matchId\": 12345678,\n" +
            "                    \"matchPeroidId\": 12345678,\n" +
            "                    \"matchTime\": 12345678,\n" +
            "                    \"oddsId\": 12345678,\n" +
            "                    \"oddsValue\": 200.00,\n" +
            "                    \"orderId\": 12345678,\n" +
            "                    \"periodName\": \"ABCD1234\",\n" +
            "                    \"periodNum\": 12345678,\n" +
            "                    \"regionId\": 12345678,\n" +
            "                    \"regionName\": \"ABCD1234\",\n" +
            "                    \"score\": \"ABCD1234\",\n" +
            "                    \"sportId\": 12345678,\n" +
            "                    \"sportName\": \"ABCD1234\",\n" +
            "                    \"stakeName\": \"ABCD1234\",\n" +
            "                    \"stakeStatus\": 12345678,\n" +
            "                    \"stakeStatusName\": \"ABCD1234\",\n" +
            "                    \"updatedAt\": 12345678\n" +
            "                }\n" +
            "            ],\n" +
            "            \"estimatedBonus\": 12345678.00,\n" +
            "            \"id\": 12345678,\n" +
            "            \"orderAmount\": 12345678.00,\n" +
            "            \"partnerUserId\": \"12345678\",\n" +
            "            \"phase\": 12345678,\n" +
            "            \"phaseStatus\": 12345678,\n" +
            "            \"realBonus\": 12345678.00,\n" +
            "            \"updatedAt\": 12345678\n" +
            "        }\n" +
            "    ],\n" +
            "    \"error\": {\n" +
            "        \"code\": 0,\n" +
            "        \"message\": \"SUCESS\"\n" +
            "    },\n" +
            "    \"header\": {\n" +
            "        \"hasContent\": true,\n" +
            "        \"receiveTime\": \"2019-03-19T18:00:16.721+0800\",\n" +
            "        \"responseTime\": \"2019-03-19T18:00:16.725+0800\",\n" +
            "        \"returnCode\": 0,\n" +
            "        \"transactionNo\": \"8f8fba96-788b-4480-a816-8c68d8d67040\"\n" +
            "    }\n" +
            "}";*/
    //String result="{\"header\":{\"returnCode\":0,\"hasContent\":true,\"transactionNo\":\"fbb07f68-9445-4adf-a4e1-4fbe8aad2285\",\"receiveTime\":1564560076457,\"receiveTimeString\":\"2019-07-31T16:01:16.457+0800\",\"responseTime\":1564560076472,\"responseTimeString\":\"2019-07-31T16:01:16.472+0800\"},\"content\":[{\"id\":517,\"orderNum\":\"1907291507839657\",\"partnerUserId\":\"gguan2\",\"betTypeId\":1,\"betTypeName\":\"Single bet\",\"combinationsId\":1,\"combinationsName\":\"Single\",\"phase\":7,\"phaseStatus\":3,\"orderAmount\":50.00,\"betResult\":5,\"estimatedBonus\":160.00,\"realBonus\":47.03,\"totalOdds\":3.20,\"originalAmount\":480.00,\"oddsType\":1,\"createdAt\":1564384048000,\"updatedAt\":1564384129000,\"details\":[{\"id\":546,\"matchId\":5187799,\"matchPeriodId\":5187799,\"matchTime\":1564382100000,\"sportId\":1,\"sportName\":\"Football\",\"regionId\":23453,\"regionName\":\"Indonesia. 3rd League\",\"leagueId\":23453,\"leagueName\":\"Indonesia. 3rd League\",\"homeTeam\":\"Bantara SC\",\"awayTeam\":\"Sams SC\",\"marketId\":1,\"marketName\":\"Result\",\"eventPartnerId\":0,\"periodNum\":0,\"periodName\":null,\"isLive\":1,\"oddsId\":619291293,\"oddsValue\":3.20,\"argument\":0.00,\"score\":\"0:1\",\"stakeName\":\"Win1\",\"stakeStatus\":3,\"stakeStatusName\":\"Lost\",\"finalScore\":\"1:2 (0:1-1:1)\",\"createdAt\":1564384048000,\"updatedAt\":1564389600000}]},{\"id\":518,\"orderNum\":\"1907291507065950\",\"partnerUserId\":\"gguan2\",\"betTypeId\":1,\"betTypeName\":\"Single bet\",\"combinationsId\":1,\"combinationsName\":\"Single\",\"phase\":5,\"phaseStatus\":4,\"orderAmount\":10.00,\"betResult\":0,\"estimatedBonus\":17.90,\"realBonus\":0.00,\"totalOdds\":1.79,\"originalAmount\":430.00,\"oddsType\":1,\"createdAt\":1564384056000,\"updatedAt\":1564384056000,\"details\":[{\"id\":547,\"matchId\":5187641,\"matchPeriodId\":5187641,\"matchTime\":1564380000000,\"sportId\":1,\"sportName\":\"Football\",\"regionId\":1343,\"regionName\":\"Russia\",\"leagueId\":9291,\"leagueName\":\"Russia. Amateur Championship\",\"homeTeam\":\"Nogliki\",\"awayTeam\":\"RSSSh Neryungri\",\"marketId\":2,\"marketName\":\"Handicap\",\"eventPartnerId\":0,\"periodNum\":0,\"periodName\":null,\"isLive\":1,\"oddsId\":619288210,\"oddsValue\":1.79,\"argument\":-4.50,\"score\":\"3:0\",\"stakeName\":\"Handicap 1 \",\"stakeStatus\":1,\"stakeStatusName\":\"New\",\"finalScore\":\"\",\"createdAt\":1564384056000,\"updatedAt\":1564384056000}]},{\"id\":519,\"orderNum\":\"1907291507649649\",\"partnerUserId\":\"gguan2\",\"betTypeId\":1,\"betTypeName\":\"Single bet\",\"combinationsId\":1,\"combinationsName\":\"Single\",\"phase\":7,\"phaseStatus\":3,\"orderAmount\":50.00,\"betResult\":5,\"estimatedBonus\":78.50,\"realBonus\":53.13,\"totalOdds\":1.57,\"originalAmount\":430.00,\"oddsType\":1,\"createdAt\":1564384064000,\"updatedAt\":1564384090000,\"details\":[{\"id\":548,\"matchId\":5186446,\"matchPeriodId\":5186446,\"matchTime\":1564380600000,\"sportId\":4,\"sportName\":\"Basketball\",\"regionId\":15483,\"regionName\":\"Men. Thailand TBL \",\"leagueId\":15483,\"leagueName\":\"Men. Thailand TBL \",\"homeTeam\":\"Dunkin Raptors\",\"awayTeam\":\"Madgoat\",\"marketId\":702,\"marketName\":\"Result\",\"eventPartnerId\":0,\"periodNum\":0,\"periodName\":null,\"isLive\":1,\"oddsId\":619000244,\"oddsValue\":1.57,\"argument\":0.00,\"score\":\"44:47\",\"stakeName\":\"Win1\",\"stakeStatus\":3,\"stakeStatusName\":\"Lost\",\"finalScore\":\"0:0 (25:22-15:19-13:13-12:21)\",\"createdAt\":1564384064000,\"updatedAt\":1564386300000}]}],\"error\":null}";


}
