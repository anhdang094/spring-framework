package main.java.com.gw.common.system.parse;


import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.*;
import main.java.com.gw.common.system.parse.vo.Result;
import main.java.com.gw.common.system.parse.vo.TransRes;
import main.java.com.gw.datacenter.accounttransfer.entity.AccountTransferEntity;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Date;
import java.util.Map;
import java.util.Objects;

@Slf4j
public class CSTransHandle {

    /**
     * 获取CS(冠军体育)转账记录
     * @param url
     * @param parameterMap
     * @return
     */
    public  Result<AccountTransferEntity> getCSTransferRecords(String url, Map<String, Object> parameterMap) {
        Result<AccountTransferEntity> accountTransferEntity = new TransRes<>();
        accountTransferEntity.setCode("0");
        String crpTxNo=parameterMap.get("crpTxNo").toString();
        boolean isPrintLog=ToolUtil.isNeedInterceptResponse(parameterMap.get(UtilConstants.ORDER_TASK_ID) + "");
        Map<String, Object> requestMap=bulidRequestMap(parameterMap,isPrintLog);
        try {
            String result= HttpClientUtils.postJson(url,null, JsonUtil.toJSONString(requestMap));
            if (isPrintLog) {
                log.info("Intercept:TaskId={},Url={},Response={}",parameterMap.get(UtilConstants.ORDER_TASK_ID),url,result);
            }
            if (StringUtils.isEmpty(result)) {
                log.warn("getCSTransferRecords log, response no data, request params:{}",parameterMap);
                return accountTransferEntity;
            }
            JSONObject object = JsonUtil.StringToJSONOBject(result);
            String returnCode = object.getJSONObject("header").getString("returnCode");
            if(Objects.equals(returnCode,"0")){
                JSONObject jsonContent=object.optJSONObject("content");
                if(null!=jsonContent){
                    JSONArray dataList=jsonContent.optJSONArray("results");
                    if (dataList == null || dataList.isEmpty()) {
                        return accountTransferEntity;
                    }
                    accountTransferEntity.setCode("0");
                    accountTransferEntity.setCurrentPage(jsonContent.optInt("currentPage"));
                    accountTransferEntity.setPerpage(jsonContent.optInt("pageSize"));
                    accountTransferEntity.setTotal(jsonContent.optInt("totalCount"));
                    accountTransferEntity.setTotalPages(jsonContent.optInt("pageCount"));
                    String productId=parameterMap.get("productId").toString();
                    String currency=parameterMap.get("currency").toString();
                    AccountTransferEntity entity=null;
                    for (int i = 0; i < dataList.size(); i++) {
                        JSONObject transRecord = dataList.getJSONObject(i);
                        String nickName=transRecord.optString("nickname");
                        String balanceBefore=transRecord.optString("balanceBefore");
                        String balanceAfter=transRecord.optString("balanceAfter");
                        String transNo=transRecord.optString("transNo");
                        String amount=transRecord.optString("amount");
                        int transType=transRecord.optInt("transType");
                        long createdAt=transRecord.optLong("createdAt");
                        entity = new AccountTransferEntity();
                        entity.setTransId(crpTxNo);
                        entity.setTradeNo(transNo);
                        entity.setCreationTime(new Date(createdAt));
                        entity.setProductId(productId);
                        entity.setPlatformId(UtilConstants.CS);
                        entity.setCurrency(currency);
                        entity.setTransferAmount(new BigDecimal(amount));
                        entity.setPreviousAmount(new BigDecimal(balanceBefore));
                        entity.setCurrentAmount(new BigDecimal(balanceAfter));
                        entity.setUserName(nickName);
                        String transTypeStr="";
                        if(transType==1){
                            transTypeStr=UtilConstants.TRANSFER_TYPE_IN;
                        }else if(transType==2){
                            transTypeStr=UtilConstants.TRANSFER_TYPE_OUT;
                        }
                        entity.setTransferType(transTypeStr);
                        accountTransferEntity.getOrderList().add(entity);
                    }
                }
            }else{
                accountTransferEntity.setCode("-1");
                log.error("请求CS转账 getCSTransferRecords  in HTTP Post,转账记录返回响应:{}",result);
            }
        } catch (Exception e) {
            accountTransferEntity.setCode("-1");
            log.error("请求CS转账 getCSTransferRecords异常", e);
        }
        return accountTransferEntity;
    }


    /**
     * 构建订单查询抓取参数
     * @param parameterMap
     * @return
     */
    private Map<String, Object> bulidRequestMap(Map<String, Object> parameterMap,boolean isPrintLog) {
        Map<String, Object>  requestMap= Maps.newHashMap();
        try {
            String appId=parameterMap.get("app_id").toString();
            String publicKey=parameterMap.get("public_key").toString();
            int page=Integer.parseInt(parameterMap.get("pageNo").toString());
            int pageSize=Integer.parseInt(parameterMap.get("pageSize").toString());
            String crpTxNo=parameterMap.get("crpTxNo").toString();
            //随机生成AES加密所需的密钥
            String secretKey = AESUtil.generateSecretKey();
            long crpTimestamp = System.currentTimeMillis();
            net.sf.json.JSONObject jsonObject=new net.sf.json.JSONObject();
            jsonObject.put("crpTxNo", crpTxNo);
            jsonObject.put("crpTimestamp",crpTimestamp);
            jsonObject.put("crpLanguageCode", "1");
            jsonObject.put("page", page);
            jsonObject.put("pageSize",pageSize);
            jsonObject.put("startTime", parameterMap.get("startTime"));
            jsonObject.put("endTime", parameterMap.get("endTime"));
            if(isPrintLog){
                log.info("获取CS(冠军体育)转账记录加密前参数：{}",jsonObject.toString());
            }
            //对业务参数进行AES加密返回params
            String encryptedParams = AESUtil.encrypt(jsonObject.toString(),secretKey);
            //对业务参数进行先MD5然后Base64.encode生成签名
            String signStr =StringUtils.join(encryptedParams,crpTxNo,crpTimestamp,secretKey);
            String sign = MD5(signStr);
            //对参数的Aes秘钥进行RAS非对称加密处理
            String encryptedSecretKey = RSAUtil.encryptRSA(secretKey, publicKey);
            requestMap.put("appId", appId);
            requestMap.put("params", encryptedParams);
            requestMap.put("sign", sign);
            requestMap.put("secretKey", encryptedSecretKey);
        } catch (Exception e) {
            log.error("请求前增加接口签名参数出现异常:{}", e);
        }
        return requestMap;
    }

    private static String MD5(String data) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("MD5");
        return new String(Base64.encodeBase64(md.digest(data.getBytes(StandardCharsets.UTF_8))));
    }

    String result="{\n" +
            "    \"content\": {\n" +
            "        \"currentPage\": 1,\n" +
            "        \"pageCount\": 1,\n" +
            "        \"pageSize\": 10,\n" +
            "        \"results\": [\n" +
            "            {\n" +
            "                \"amount\": 111.00,\n" +
            "                \"balanceAfter\": 2111.00,\n" +
            "                \"balanceBefore\": 2000.00,\n" +
            "                \"createdAt\": \"1563393393\",\n" +
            "                \"nickname\": \"TestAccount\",\n" +
            "                \"transNo\": \"eb202813-45ff-4135-828a-824c3fb0f7a7\",\n" +
            "                \"transType\": 1,\n" +
            "                \"updatedAt\": \"1563393393\"\n" +
            "            }\n" +
            "        ],\n" +
            "        \"totalCount\": 1\n" +
            "    },\n" +
            "    \"error\": {\n" +
            "        \"code\": 12345678,\n" +
            "        \"message\": \"Error message\"\n" +
            "    },\n" +
            "    \"header\": {\n" +
            "        \"hasContent\": false,\n" +
            "        \"receiveTime\": \"2019-03-19T18:00:16.721+0800\",\n" +
            "        \"responseTime\": \"2019-03-19T18:00:16.725+0800\",\n" +
            "        \"returnCode\": 0,\n" +
            "        \"transactionNo\": \"8f8fba96-788b-4480-a816-8c68d8d67040\"\n" +
            "    }\n" +
            "}";
}
