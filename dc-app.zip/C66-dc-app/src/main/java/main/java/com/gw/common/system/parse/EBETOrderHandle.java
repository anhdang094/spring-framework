package main.java.com.gw.common.system.parse;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.common.system.parse.vo.OrderRes;
import main.java.com.gw.common.system.parse.vo.Result;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class EBETOrderHandle extends AbstractHandle {
    static String ERROR = "error";
    static volatile Map<String, Object> cacheData = new HashMap<String, Object>();

    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        return null;
    }

    public String retrieveData(Map<String, Object> paramaterMap) throws GWCallRemoteApiException {
        String baseUrl = (String) paramaterMap.get(UtilConstants.ORDER_BASE_URL);
        String begintimeStr = (String) paramaterMap.get(UtilConstants.ORDER_BEGIN_TIME);//开始时间
        String endtimeStr = (String) paramaterMap.get(UtilConstants.ORDER_END_TIME);//结束时间
        String timestamp = String.valueOf(new Date().getTime());   //时间戳
        String privateKey = (String) paramaterMap.get("agcode"); //私钥
        String signature = null;//签名
        try {
            signature = sign(timestamp, privateKey);
        } catch (Exception e) {
            log.error("Ebet 抓取注单信息签名失败：ErrorMessage=" + e.getMessage(), e);
        }
        Map<String, Object> ebetParams = new LinkedHashMap<String, Object>();
        ebetParams.put("startTimeStr", begintimeStr);
        ebetParams.put("endTimeStr", endtimeStr);
        ebetParams.put("channelId", (String) paramaterMap.get("billno"));
        ebetParams.put("betStatus", 1);//只查询成功注单 add by ziv 2018-07-24
        ebetParams.put("pageNum", (String) paramaterMap.get("page"));//页码
        ebetParams.put("pageSize", (String) paramaterMap.get("num"));//每页数量 我们设置为400
        ebetParams.put("timestamp", timestamp);
        ebetParams.put("signature", signature);
        log.info("Ebet 抓取注单信息参数 调用 url:" + baseUrl + ",参数为ebetParams：" + ebetParams);
        String content = null;
        //String requestUrl = getUrl(paramaterMap);//获取返回的url地址
        try {
            content = new HttpUtil().doPost(baseUrl, ebetParams);
            //content="{\"remainingVisits\":100,\"count\":7,\"status\":200,\"betHistories\":[{\"gameType\":3,\"allDices\":[4,4,2],\"payout\":0.0,\"betMap\":[{\"betMoney\":20.0,\"betType\":136},{\"betMoney\":20.0,\"betType\":138},{\"betMoney\":20.0,\"betType\":128},{\"betMoney\":20.0,\"betType\":139},{\"betMoney\":20.0,\"betType\":129}],\"judgeResult\":[101,103,107,126,135,137,146,155],\"userId\":1201417,\"betHistoryId\":\"5902ddf3a7284608edf3003c\",\"payoutTime\":1493360146,\"createTime\":1493360085,\"roundNo\":\"S2-170428141442\",\"subChannelId\":0,\"validBet\":100.0,\"username\":\"sbttest\"},{\"gameType\":3,\"allDices\":[2,2,5],\"payout\":40.0,\"betMap\":[{\"betMoney\":20.0,\"betType\":136},{\"betMoney\":20.0,\"betType\":137},{\"betMoney\":20.0,\"betType\":138},{\"betMoney\":20.0,\"betType\":129},{\"betMoney\":20.0,\"betType\":130}],\"judgeResult\":[100,103,105,125,135,138,147,155],\"userId\":1201417,\"betHistoryId\":\"5902dda5a7284608edf2ff26\",\"payoutTime\":1493360077,\"createTime\":1493360020,\"roundNo\":\"S2-170428141337\",\"subChannelId\":0,\"validBet\":100.0,\"username\":\"sbttest\"},{\"gameType\":2,\"payout\":20.0,\"betMap\":[{\"betMoney\":20.0,\"betType\":11}],\"judgeResult\":[11],\"userId\":1201417,\"tigerCard\":39,\"betHistoryId\":\"5902dbc3a7284608edf2f826\",\"payoutTime\":1493359572,\"createTime\":1493359538,\"dragonCard\":25,\"roundNo\":\"D1-170428140535\",\"subChannelId\":0,\"validBet\":0.0,\"username\":\"sbttest\"},{\"gameType\":2,\"payout\":40.0,\"betMap\":[{\"betMoney\":20.0,\"betType\":10}],\"judgeResult\":[10],\"userId\":1201417,\"tigerCard\":7,\"betHistoryId\":\"5902db9ca7284608edf2f755\",\"payoutTime\":1493359531,\"createTime\":1493359496,\"dragonCard\":22,\"roundNo\":\"D1-170428140453\",\"subChannelId\":0,\"validBet\":20.0,\"username\":\"sbttest\"},{\"gameType\":2,\"payout\":0.0,\"betMap\":[{\"betMoney\":20.0,\"betType\":68}],\"judgeResult\":[11],\"userId\":1201417,\"tigerCard\":21,\"betHistoryId\":\"5902db24a7284608edf2f589\",\"payoutTime\":1493359407,\"createTime\":1493359373,\"dragonCard\":28,\"roundNo\":\"D1-170428140250\",\"subChannelId\":0,\"validBet\":20.0,\"username\":\"sbttest\"},{\"gameType\":2,\"payout\":40.0,\"betMap\":[{\"betMoney\":20.0,\"betType\":10}],\"judgeResult\":[10],\"userId\":1201417,\"tigerCard\":41,\"betHistoryId\":\"5902daf0a7284608edf2f495\",\"payoutTime\":1493359367,\"createTime\":1493359332,\"dragonCard\":9,\"roundNo\":\"D1-170428140209\",\"subChannelId\":0,\"validBet\":20.0,\"username\":\"sbttest\"},{\"gameType\":2,\"payout\":40.0,\"betMap\":[{\"betMoney\":20.0,\"betType\":11}],\"judgeResult\":[11],\"userId\":1201417,\"tigerCard\":22,\"betHistoryId\":\"5902dacba7284608edf2f41a\",\"payoutTime\":1493359325,\"createTime\":1493359291,\"dragonCard\":40,\"roundNo\":\"D1-170428140128\",\"subChannelId\":0,\"validBet\":20.0,\"username\":\"sbttest\"}]}";
            //content =  HttpUtil.URLPost(baseUrl, ebetParams);
            log.info("Ebet 数据抓取完成");
        } catch (Exception e) {
            log.info("Ebet 抓取注单信息失败 ：ErrorMessage=" + e);
            throw new GWCallRemoteApiException("EBETOrderHandle.retrieveData 注单抓取数据异常：" + e.getMessage(), e);
        }
        return content;
    }

    @Override
    public OrderRes parse(String content) throws GWCallRemoteApiException {
        OrderRes res = new OrderRes();
        JSONObject resultJson = JSONObject.parseObject(content);
        String status = resultJson.getString("status");
        //200:成功, 202:渠道不存在, 401:用户已存在, 4026: 验签失败 , 4027:IP无访问权限
        log.info("ebet parse方法解析status处理为:" + status);
        if (StringUtils.isNotBlank(status) && status.equals("200")) {
            String count = resultJson.getString("count");//总行数
            res.setTotal(Integer.valueOf(count)); //总行数
            JSONArray betHisJsonArray = resultJson.getJSONArray("betHistories");
            for (int i = 0; i < betHisJsonArray.size(); i++) {
                OrderEntity order = new OrderEntity();
                JSONObject betHisJSONObject = (JSONObject) betHisJsonArray.get(i);          // 获取每个的对象
                order.setBillNo(betHisJSONObject.getString("betHistoryId"));                // 内部投注标示码 保证唯一
                Date billTime = modification(betHisJSONObject.getString("createTime"));
                if (billTime == null) {
                    //失败注单厅方返回的报文中没有createTime，不处理失败注单 add by ziv 23018-07-25
                    continue;
                }
                order.setBillTime(billTime);  // 注单时间
                order.setReckonTime(modification(betHisJSONObject.getString("payoutTime")));// 投注更新时间
                order.setRound(betHisJSONObject.getString("roundNo"));                      // 局号id
                order.setGmCode(betHisJSONObject.getString("roundNo"));                     // 回合id
                order.setLoginName(betHisJSONObject.getString("username"));                 // 用户名
                order.setGameType("EBET_" + betHisJSONObject.getString("gameType"));          // 游戏提供商的唯独游戏辨识吗
                BigDecimal account = getAccount(betHisJSONObject.getJSONArray("betMap"));   // 投注额获取
                order.setAccount(account);                                                  // 存储进入投注额字段
                String payout = betHisJSONObject.getString("payout");                       // 派彩 0表示输了  大于0就表示赢的
                String validBet = betHisJSONObject.getString("validBet");                   // 有效投注额

                // PDATACENTER-969 ebet 牛牛玩法 需要考虑预扣值
                String gameType = betHisJSONObject.getString("gameType");
                if (gameType.equals(UtilConstants.EBET_NIUNIU_GAMETYPE)) {
                    String niuniuWithHoldingTotal = betHisJSONObject.getString("niuniuWithHoldingTotal"); // 牛牛预扣值
                    order.setCusAccount(getCusAccount(payout, account, niuniuWithHoldingTotal));
                }
                else {
                    order.setCusAccount(getCusAccount(payout, account));                         // 客户输赢额度
                }
                order.setValidAccount(new BigDecimal(StringUtils.isBlank(validBet) ? "0" : validBet));    // 有效投注额
                //order.setPreviosAmount(new BigDecimal(0));                                // 投注前玩家余额,
                order.setCurrency(UtilConstants.CNY);                                      // cur(货币类型)
                order.setGameKind(UtilConstants.GAME_KIND_ENUM.VIDEO.getCode());            // 表示真人  目前只有真人
                order.setDeviceType("0");                                                   // 游戏平台类型，电脑手机登
                //order.setCurIp(dataArray[22]);                                            // 游戏提供商ip
                //order.setResult("");                                                      // 游戏动作种类，目前这个值永远是“PlaceBet”
                String judgeResult = betHisJSONObject.getString("judgeResult");
                //order.setPlayType(getPlayType(betHisJSONObject.getString("gameType"),judgeResult));                                 //玩法类型 转换以后的
                //order.setPlayType(betHisJSONObject.getString("judgeResult"));
                order.setRemark(getPlayType(betHisJSONObject.getJSONArray("betMap")));      //因为数据类型原因将palytype数据存储到remark中
                order.setResultType(judgeResult);                                           //将开牌的结果存储在这里
                order.setFlag(UtilConstants.ORDERS_FLAG_ENUM.SETTLED.getFalg());            // 已结算
                //order.setProductId(UtilConstants.PRODUCT_ENUM.E04.toString());
                order.setPlatId(UtilConstants.EBET);
                res.addOrder(order);
            }
            return res;
        } else {
            log.info("Ebet 数据解析返回状态不成功：content=" + content);
            throw new GWCallRemoteApiException("EBETOrderHandle.parse 数据解析出错status：" + status);
        }
    }

    //请求参数加密
    public static String sign(String param, String privateKey)
            throws NoSuchAlgorithmException, InvalidKeySpecException, InvalidKeyException, SignatureException {
        byte[] data = param.getBytes();
        byte[] keyBytes = Base64.decodeBase64(privateKey.getBytes());
        PKCS8EncodedKeySpec pkcs8EncodedKeySpec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PrivateKey priKey = keyFactory.generatePrivate(pkcs8EncodedKeySpec);
        Signature signature = Signature.getInstance("MD5withRSA");
        signature.initSign(priKey);
        signature.update(data);
        return new String(Base64.encodeBase64(signature.sign()));
    }

    public BigDecimal getCusAccount(String payout, BigDecimal account, String niuniuWithHoldingTotal)  throws GWCallRemoteApiException{
        BigDecimal bdPayout = new BigDecimal(payout);//派彩
        BigDecimal bdValidBet = account;//投注额
        BigDecimal niuniuWIthholding = new BigDecimal(niuniuWithHoldingTotal);
        int py = bdPayout.compareTo(BigDecimal.ZERO);
        if (py == 1) {//大于0
            //bdPayout=bdValidBet;
            bdPayout = bdPayout.subtract(bdValidBet).subtract(niuniuWIthholding); // 有预扣的情况下，派彩=实际派彩+预扣返还，计算输赢值时，需要减去预扣返还
        } else if (py == 0) {//等于0
            bdPayout = bdValidBet.multiply(new BigDecimal("-1")).subtract(niuniuWIthholding); // 派彩为0时，认为没有做预扣
        } else {//小于0
            log.info("EBETOrderHandle.getCusAccount方法出错 ，数据出现负数 payout=" + payout);
            throw new GWCallRemoteApiException("EBETOrderHandle.getCusAccount方法出现负数payout=" + payout);
        }
        return bdPayout;
    }

    //获取输赢额度 客户输赢度=派彩-投注额
    public BigDecimal getCusAccount(String payout, BigDecimal account) throws GWCallRemoteApiException {
        return getCusAccount(payout, account, "0");
    }


	/*
    //获取玩法类型
	public Integer getPlayType(String gameType,String judgeResult){
		Integer type=null;
		//1百家乐 2龙虎 3骰子 4轮盘 5水果机
		if(gameType.equals("1")){//百家乐
			type=Integer.valueOf(gameType+judgeResult);
		}else if(gameType.equals("2")){//龙虎
			type=Integer.valueOf(gameType+judgeResult);
		}else if(gameType.equals("4")){//轮盘
			type=Integer.valueOf(gameType+judgeResult);
		}else{
			log.info("gameType 类型为："+gameType);
		}
		return type;
		
	}*/


    //将返回的"1492572585"格式时间戳进行存储
    public Date modification(String time) {
        //1483502400000
        SimpleDateFormat format = new SimpleDateFormat(DateUtil.C_TIME_PATTON_DEFAULT);
        Date date = null;
        if (StringUtils.isNotBlank(time)) {
            String d = format.format(new Date(Long.valueOf(time + "000")));
            try {
                date = format.parse(d);
            } catch (ParseException e) {
                log.info("Ebet 日期格式转换错误 ：" + e, e);
            }
        }
        return date;
    }

    //用户投注额计算
    public BigDecimal getAccount(JSONArray limitArray) {
        BigDecimal sumAmount = new BigDecimal(0);
        for (int i = 0; i < limitArray.size(); i++) {
            JSONObject betMapJSONObject = (JSONObject) limitArray.get(i);//获取每个的对象
            BigDecimal nowAmount = new BigDecimal(betMapJSONObject.getString("betMoney"));
            sumAmount = sumAmount.add(nowAmount);
        }
        return sumAmount;
    }


    //获取用户下注类型
    public String getPlayType(JSONArray limitArray) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < limitArray.size(); i++) {
            JSONObject betMapJSONObject = (JSONObject) limitArray.get(i);//获取每个的对象
            String betType = betMapJSONObject.getString("betType");
            if (sb.length() == 0) {
                sb.append(betType);
            } else {
                sb.append(",").append(betType);
            }

        }
        return sb.toString();
    }

    public static void main(String[] args) {
        String privateKey = "MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBAJEz2PL7HkyUituwdgKFZH6sYgZTgV4ixzbrP57m7CNt+4v1G+akushIcNbGi/1WJvnq/Ovr+D1ZBCPjD3l1QdHEe8uLqwBPOwiWt2motmqUvLTAo4qgvRBLZSniZQrIXUqi3vTnZ6c5z/dpI3EwwG5CQR8XBxL89EgIZfz+IezNAgMBAAECgYA/W+Vd2U/WULbqt+w2m2hHkgbQBd4caoaNI0fGmbMOnq412wWKtfS+8kUyor5xFAe749rrQzM16cLRugGFmTHXn5EDwHqNNKX5hsW1LqfVh2n/FZLY0ZxZ6E+vqwpMWrL22Pe+L6u1UNgqOxLrdnbxsvGhf8jqAYhnWr/Ea5T8TQJBAO6d8JWTU5NJfw4gQEDb+YFauxoopWBIsfWMnNLnkA8jFnKrLyIx05iORFaJKWXPQQyu3SOTSd3TVIEOWTM7GXMCQQCbx8krVhBgf1E4B4lU+TCsQpN8MQUro8F0a6sNV4vZRcqy3DPrvZVtMk9z6xpnGNCFeUumtk9KPOHrM1+xElC/AkAYu6Q5TMkH5kFWLH+ceXCWONpV7sqdfUt84TNMJRZoi0GDZzz+dV2yXWS194ej9uSONP3U9ypb5NDIg705MzIDAkBUFVxCJewlCdOe+IJp+S8Ka80LpbHywirzWgIz62My3XbxX+YugmAbVqKIIQhZSY2T3cq1q4XUvlP7DfnCq+4lAkAzfr8eMXZF6CGHrDe2M+3jcJTyWanBCUoCe337udrB3lafvEPra5Y4vfrUebb3hrX1MnqH6dbFf65HeM/R/5Zg";
        //String privateKey="MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAJHeb38HVPDLIHPyx4hmJnQGSEobeDS7pkTYp1G6PZRAUqxns6Gig1DlanAWrO0gLCEVkpuWHo2qJy4I8/rVQ0J1aZ6qo10mbKCsl/pbN3/MXF3BuV1yaAj6Lhi/W+W3adMhTVSOWvWyQfQQecD4nX2fbM3FGiAaChIru0cmzuuHAgMBAAECgYARNsTFouHdQLtls4Lkj9l927fwNumqn3JxsXedZ3MY6bZX7iz+qCUDCO/Upnhly2Qpy1fv0HlukmPpRNk2ArDbGzMmxd5GMf6THdNOVg+m8jVtlXdtzv7TtkfZva+BSd17H6p7nlThJZu1oI0BBvLlgkqfCvmKh7fpVbmKvxtbUQJBAM9PyO1NmTJ6M30ozHPMcfAr8ADfO2c/SHHToOvXmomcSnrhW3MUpQl5xp01iZIb8d3ARlRUUJnTj2r+AM6/a50CQQC0IIWrKUaw/fmVs35b/7VrgJrwas570AThvU5Eai2bmuxgl7CF6IZ2+GW2cJXODBcBKBUf2wLlwD2Vrfd6FaRzAkEAkjnCja9YSYRsYPGwFFW2YCN9q//JFLBMVw1gyjlPZZT56+ac7HU5W4+riiPDH23akgEXGlBGcdoJpPv4cdwO+QJAY1dMYQlyo0puy9Eibzqno5JZ4R4GouImzxjIgZLNdHQMyXjfMfr7rcFw1x1ggTLJvSmN/POctXlAfbxkMECfYQJAGpVh/M1GWCHiOHXMIVZJ824Qp/2tGX/PS/PP3BQZMTkJVLf1f43/XPl8Vp8h/oOHef1K5LDNCaRjSzoh2jAFIw==";
        Map<String, Object> paramaterMap = new HashMap<String, Object>();
        paramaterMap.put("begintime", "2017-04-28 14:00:00");
        paramaterMap.put("endtime", "2017-04-28 14:30:00");
        paramaterMap.put("platformid", "order_ebet");
        paramaterMap.put("agcode", privateKey);//在ebet中agcode表示秘钥
        paramaterMap.put("billno", "127");//在ebet中billno表示渠道ID
        paramaterMap.put("productId", "E03");
        paramaterMap.put("num", "10");//每页多少
        paramaterMap.put("page", "1");//第几页
        paramaterMap.put("timeZone", "Etc/GMT-8");
        paramaterMap.put("dataDelay", "1");
        paramaterMap.put("baseUrl", "http://yongle.ebet.im:8888/api/userbethistory");
        paramaterMap.put(UtilConstants.ORDER_TASK_ID, "825");
        AbstractHandle handle = new EBETOrderHandle();
        try {
            String result = handle.retrieveData(paramaterMap);

            System.out.println(result);
            Result res = new Result();
            if (!StringUtils.isBlank(result)) {
                res = handle.parse(result);
            }
            List<Object> orderList = res.getOrderList();
            System.out.println(orderList);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String timeStamp2Date(String seconds, String format) {
        if (seconds == null || seconds.isEmpty() || seconds.equals("null")) {
            return "";
        }
        if (format == null || format.isEmpty()) {
            format = "yyyy-MM-dd HH:mm:ss";
        }
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        return sdf.format(new Date(Long.valueOf(seconds + "000")));
    }

}
