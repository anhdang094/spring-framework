package main.java.com.gw.common.system.parse;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.constant.UtilConstants.ORDERS_FLAG_ENUM;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.common.system.parse.vo.OrderRes;
import main.java.com.gw.common.system.parse.vo.Result;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.digester3.Digester;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by Span on 2016/7/15.
 */
@Slf4j
public class EVOOrderHandle extends AbstractHandle {

    private String url = "";

    public EVOOrderHandle(String url) {
        this.url = url;
    }

    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        return getFinalURL();
    }

    public String getFinalURL() {
        StringBuilder fullUrl = new StringBuilder();
        this.params.forEach((k, v) -> {
            String encodedVal = v.toString();
            try {
                encodedVal = URLEncoder.encode(v.toString(), "UTF-8");
            } catch (UnsupportedEncodingException e) {
                log.error("生成调度任务的url地址出错", e);
            }
            fullUrl.append(k).append("=").append(encodedVal).append("&");
        });
        fullUrl.insert(0, "?").insert(0, url);
        return fullUrl.toString();
    }

    public String retrieveData() {
        String content = "";
        String fullUrl = getFinalURL();
        log.info("retrieve EVO data url:" + fullUrl);
        try {
            content = new HttpUtil().doGet(fullUrl);
        } catch (IOException e) {
            log.error("HttpGet url=" + fullUrl + " exception {}," + e.getMessage(), e);
            throw new RuntimeException(e.getMessage(), e);
        }
        return content;
    }

  /*  public String getUrl(Map<String, Object> paramaterMap) {
        String baseUrl = (String) paramaterMap.get("baseUrl");
        String begintime=(String) paramaterMap.get("begintime");
        String endtime=(String) paramaterMap.get("endtime");
        String rounddate=begintime.substring(0,10);
        String page=(String)paramaterMap.get("page");
        String pagelimit=(String)paramaterMap.get("num");
        String productId = (String) paramaterMap.get("productId");
        SortedMap<String,String> pMap=new TreeMap<>();
        pMap.put("rounddate", rounddate);
        pMap.put("starttime", begintime.substring(11,begintime.length()));
        pMap.put("endtime",endtime.substring(11,endtime.length()));
        pMap.put("page", page);
        pMap.put("gameCode", (String) paramaterMap.get("gameCode"));
        pMap.put("pagelimit", pagelimit);
        pMap.put("productId", productId);

        StringBuilder enVal = new StringBuilder();
        pMap.forEach((key,val)->enVal.append(key).append("=").append(val).append("&"));
        String key = "IOM";
        String queryString = enVal.deleteCharAt(enVal.length()-1).toString();
        queryString = queryString +"&key="+ MD5.MD5Encode(key+queryString);
        return  baseUrl+"?"+queryString;
    }*/

    @Override
    public String retrieveData(String url, Map<String, Object> paramaterMap) throws GWCallRemoteApiException {
        String content = "";
        try {
            String tUrl = getUrl(paramaterMap);
            log.info("retrieve EVO data url:" + tUrl);
            content = new HttpUtil().doGet(tUrl);
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new GWCallRemoteApiException("EVO Failed to call remote interface!" + ex.getMessage(), ex);
        }
        return content;

    }

    public void parseRules(Digester d) {
        d.addObjectCreate("Data", OrderRes.class);
        d.addSetProperties("Data", "PageLimit", "perpage");
        d.addSetProperties("Data", "TotalNumber", "total");
        d.addSetProperties("Data", "Page", "numpage");
        d.addObjectCreate("Data/Record", OrderEntity.class);
        d.addSetNext("Data/Record", "addOrder");
        d.addBeanPropertySetter("Data/Record/WagersID", "billNo");
        d.addBeanPropertySetter("Data/Record/RoundNo", "round");
        d.addBeanPropertySetter("Data/Record/TableId", "tableCode");
        d.addBeanPropertySetter("Data/Record/BeforeBalance", "previosAmount");
        d.addBeanPropertySetter("Data/Record/Commissionable", "validAccount");
        d.addBeanPropertySetter("Data/Record/BetAmount", "account");
        d.addBeanPropertySetter("Data/Record/CurrentBalance", "currentAmount");
        d.addBeanPropertySetter("Data/Record/Payoff", "cusAccount");
        d.addBeanPropertySetter("Data/Record/ProductID", "productId");
        d.addBeanPropertySetter("Data/Record/UserName", "loginName");
        d.addBeanPropertySetter("Data/Record/Currency", "currency");
        d.addBeanPropertySetter("Data/Record/GameType", "gameType");
        d.addBeanPropertySetter("Data/Record/BonusAmount", "bonusAmount");

        d.addBeanPropertySetter("Data/Record/ResultType", "resultType");
        d.addBeanPropertySetter("Data/Record/Result", "result");
        //API抓取的数据是北京时间
        d.addCallMethod("Data/Record/WagersDate", "setTime", 1);
        d.addCallParam("Data/Record/WagersDate", 0);
    }

    public static void main(String[] args) {
        try {
            String result = FileUtils.readFileToString(new File("D:\\Documents and Settings\\sanco\\Desktop\\sanco\\BetRecord.xml"), "UTF-8");
            AbstractHandle handle = new EVOOrderHandle("");
            Result res = handle.parse(result);
            List<Object> orderList = res.getOrderList();
            for (Object obj : orderList) {
                //重置 过的时候做一下记录是否判断
                System.out.println(obj);

            }

            System.out.println(orderList);
            orderList.forEach(o -> {
                OrderEntity oe = (OrderEntity) o;
                oe.setProductId("C04");
                oe.setPlatId("050");
                //oe.setFlag(1);//already settled or payouted
                oe.setGameKind(UtilConstants.GAME_KIND_ENUM.VIDEO.getCode());
                if (StringUtils.isNotBlank(oe.getResult())) {
                    switch (oe.getResult()) {
                        case "200":
                            oe.setFlag(ORDERS_FLAG_ENUM.SETTLED.getFalg());
                            break;
                        case "2":
                            oe.setFlag(ORDERS_FLAG_ENUM.UNSETTLED.getFalg());
                            oe.setFlag(0);
                            break;
                        case "-1":
                            oe.setFlag(ORDERS_FLAG_ENUM.CANCELED.getFalg());
                            break;
                        case "1":
                            oe.setFlag(ORDERS_FLAG_ENUM.SETTLED.getFalg());
                            break;
                    }
                }
                oe.setCreationDate(new Date());
                if (oe.getCurrency() == null) {
                    oe.setCurrency(UtilConstants.CNY);
                }
            });
            System.out.println(orderList);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (GWCallRemoteApiException e) {
            e.printStackTrace();
        }
    }

}
