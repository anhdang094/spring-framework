package main.java.com.gw.common.system.parse;

import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.common.framework.util.MD5;
import net.sf.json.JSONObject;

import java.util.Map;
import java.util.TreeMap;

/**
 * @author Herman.T
 */
public class EspHandle extends AbstractHandle {

    @Override
    public String getUrl(Map<String, Object> parameterMap) {
        return null;
    }

    @Override
    public String retrieveData(String url, Map<String, Object> parameterMap) throws GWCallRemoteApiException {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("cluster", parameterMap.get("instanceId"));
        jsonObject.put(UtilConstants.ORDER_PAGE, parameterMap.get(UtilConstants.ORDER_PAGE));
        jsonObject.put("limit", parameterMap.get(UtilConstants.ORDER_PAGE_NUMBER));
        jsonObject.put("start", DateUtil.formatStr2Date((String) parameterMap.get("begintime")).getTime());
        jsonObject.put("end", DateUtil.formatStr2Date((String) parameterMap.get("endtime")).getTime());
        String token = (String) parameterMap.get("token");

        String params = sortByKey(jsonObject);
        String finalToken = MD5.MD5Encode(params+token);

        return new HttpUtil().doPost(url, jsonObject.toString(), token,finalToken);
    }

    /**
     * Map排序，按key的字母自然顺序
     * @param jsonObject
     * @return
     */
    private static String sortByKey(JSONObject jsonObject){
        Map map = (Map)jsonObject;
        Map treeMap = new TreeMap(map);
        JSONObject jsonObject2 = new JSONObject();
        jsonObject2.putAll(treeMap);
        String s = jsonObject2.toString();
        return s;
    }
}
