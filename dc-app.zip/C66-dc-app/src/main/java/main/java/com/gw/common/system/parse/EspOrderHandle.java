package main.java.com.gw.common.system.parse;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.system.parse.vo.OrderRes;
import main.java.com.gw.common.system.parse.vo.Result;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

/**
 * @author Herman.T
 */
@Slf4j
public class EspOrderHandle extends EspHandle {

    @Override
    public Result<OrderEntity> parse(String content, String productId, String platFormId) {
        Result<OrderEntity> result = new OrderRes<>();
        try {
            JSONObject response = JSONObject.fromObject(content);

            result.setCode("0");
            result.setCurrentPage(response.getInt("currentPage"));
            result.setPerpage(response.getInt("perPage"));
            result.setTotal(response.getInt("total"));
            result.setTotalPages(response.getInt("totalPages"));

            JSONArray data = response.getJSONArray("data");
            for (int i = 0; i < data.size(); i++) {
                JSONObject object = data.getJSONObject(i);
                log.info("object=" + object.toString());
                OrderEntity orderEntity = new OrderEntity();
                orderEntity.setBillNo(object.getString("id"));
                orderEntity.setBillTime(new Date(object.getLong("created")));
                orderEntity.setLoginName(object.getString("login"));
                orderEntity.setOrderType(UtilConstants.ORDERS_TYPE_ENUM.BET.getFlag());
                orderEntity.setProductId(productId);
                orderEntity.setPlatId(platFormId);
                orderEntity.setGameKind(UtilConstants.GAME_KIND_ENUM.E_SPORT.getCode());
                orderEntity.setAccount(new BigDecimal(object.getString("amount")));
                orderEntity.setValidAccount(BigDecimal.ZERO);
                orderEntity.setRemainAmount(BigDecimal.ZERO);
                orderEntity.setCusAccount(BigDecimal.ZERO);
                orderEntity.setPreviosAmount(new BigDecimal(object.getString("balanceBefore")));
                orderEntity.setCurrentAmount(new BigDecimal(object.getString("balanceAfter")));
                String cusAccount = object.optString("profit");
                if (StringUtils.isNotBlank(cusAccount) && !StringUtils.equals("null", cusAccount.toLowerCase())) {
                    orderEntity.setCusAccount(new BigDecimal(cusAccount));
                }
                Long payoutTime = object.optLong("createdOfPayout");
                orderEntity.setReckonTime(payoutTime == 0L ? null : new Date(payoutTime));
                orderEntity.setGameType(object.getString("gameid"));
                orderEntity.setDeviceType("0");
                orderEntity.setGmCode(object.getString("seriesid"));
                String odds = object.optString("odds");
                if (StringUtils.isNotBlank(odds) && !StringUtils.equals("null", odds.toLowerCase())) {
                    orderEntity.setOdds(new BigDecimal(odds));
                }
                orderEntity.setOddsType(object.getString("propositionid"));
                String state = (String) object.get("state");

                orderEntity.setFlag(this.getFlag(state));
                if (UtilConstants.ORDERS_FLAG_ENUM.SETTLED.getFalg() == orderEntity.getFlag()) {
                    orderEntity.setValidAccount(new BigDecimal(StringUtils.isBlank(object.optString("worthAmount")) || "null".equals(object.optString("worthAmount")) ? "0" : object.optString("worthAmount")));
                    orderEntity.setRemainAmount(orderEntity.getValidAccount());
                }
                if ("lost".equals(state)) {
                    orderEntity.setCusAccount(orderEntity.getAccount().negate());
                    Long updateDate = object.optLong("updated");
                    orderEntity.setReckonTime(updateDate == 0L ? orderEntity.getReckonTime() : new Date(updateDate));
                }

                result.getOrderList().add(orderEntity);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            result.setCode("-1");
        }
        return result;
    }

    @Override
    public Integer getFlag(String state) {
        if (StringUtils.isBlank(state)) {
            return UtilConstants.ORDERS_FLAG_ENUM.UNSETTLED.getFalg();
        }
        //当投注数据状态为赢时，依然设置为未结算，要判断是否抓到派彩数据
        switch (state.toLowerCase()) {
            case "created":
                return UtilConstants.ORDERS_FLAG_ENUM.UNSETTLED.getFalg();
            case "transaction":
                return UtilConstants.ORDERS_FLAG_ENUM.UNSETTLED.getFalg();
            case "placed":
                return UtilConstants.ORDERS_FLAG_ENUM.UNSETTLED.getFalg();
            case "won":
                return UtilConstants.ORDERS_FLAG_ENUM.SETTLED.getFalg();
            case "lost":
                return UtilConstants.ORDERS_FLAG_ENUM.SETTLED.getFalg();
            case "canceled":
                return UtilConstants.ORDERS_FLAG_ENUM.CANCELED.getFalg();
            case "refund":
                return UtilConstants.ORDERS_FLAG_ENUM.CANCELED.getFalg();
            case "failure":
                return UtilConstants.ORDERS_FLAG_ENUM.CANCELED.getFalg();
            default:
                throw new RuntimeException("state exception! " + state);
        }
    }

    @Override
    public String retrieveData(String url, Map<String, Object> parameterMap) throws GWCallRemoteApiException {
        return super.retrieveData(url, parameterMap);
    }
}
