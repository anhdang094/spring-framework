package main.java.com.gw.common.system.parse;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.system.parse.vo.OrderRes;
import main.java.com.gw.common.system.parse.vo.Result;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Herman.T
 */
@Slf4j
public class EspPayoutHandle extends EspHandle {

    @Override
    public Result<OrderEntity> parse(String content, String productId, String platFormId) {
        Result<OrderEntity> result = new OrderRes<>();
        try {
            JSONObject response = JSONObject.fromObject(content);

            result.setCode("0");
            result.setCurrentPage(response.getInt("currentPage"));
            result.setPerpage(response.getInt("perPage"));
            result.setTotal(response.getInt("total"));
            result.setTotalPages(response.getInt("totalPages"));

            JSONArray data = response.getJSONArray("data");
            for (int i = 0; i < data.size(); i++) {
                JSONObject object = data.getJSONObject(i);
                String state = (String) object.get("state");
                if (!"success".equals(state)) {
                    continue;
                }
                OrderEntity orderEntity = new OrderEntity();
                orderEntity.setBillNo(object.getString("id"));
                orderEntity.setLoginName(object.getString("login"));
                orderEntity.setReckonTime(new Date(object.getLong("created")));
                orderEntity.setOrderType(UtilConstants.ORDERS_TYPE_ENUM.PAYOUT.getFlag());
                orderEntity.setProductId(productId);
                orderEntity.setPlatId(platFormId);
                orderEntity.setGameKind(UtilConstants.GAME_KIND_ENUM.E_SPORT.getCode());
                orderEntity.setCusAccount(new BigDecimal(object.getString("amount")));
                orderEntity.setGameType(object.getString("gameid"));
                orderEntity.setDeviceType("0");
                orderEntity.setGmCode(object.getString("seriesid"));
                orderEntity.setOdds(new BigDecimal(object.getString("odds")));
                orderEntity.setOddsType(object.getString("propositionid"));

                result.getOrderList().add(orderEntity);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            result.setCode("-1");
        }
        return result;
    }

}
