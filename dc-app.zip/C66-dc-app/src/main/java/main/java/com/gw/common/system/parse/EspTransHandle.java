package main.java.com.gw.common.system.parse;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.system.parse.vo.Result;
import main.java.com.gw.common.system.parse.vo.TransRes;
import main.java.com.gw.datacenter.accounttransfer.entity.AccountTransferEntity;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Herman.T
 */
@Slf4j
public class EspTransHandle extends EspHandle {

    @Override
    public Result<AccountTransferEntity> parse(String content, String productId, String platformId) {
        Result<AccountTransferEntity> result = new TransRes<>();
        try {
            JSONObject response = JSONObject.fromObject(content);

            result.setCode("0");
            result.setCurrentPage(response.getInt("currentPage"));
            result.setPerpage(response.getInt("perPage"));
            result.setTotal(response.getInt("total"));
            result.setTotalPages(response.getInt("totalPages"));

            JSONArray data = response.getJSONArray("data");
            if (CollectionUtils.isEmpty(data)) {
                result.setOrderList(null);
                return result;
            }
            for (int i = 0; i < data.size(); i++) {
                JSONObject object = data.getJSONObject(i);
                JSONObject meta = object.getJSONObject("meta");
                // meta为空的不抓，因为gi这边转账meta里面会加上transactionType
                if (meta == null || meta.isNullObject()) {
                    continue;
                }
                String transactionType = meta.optString("transactionType");
                if (!UtilConstants.TRANSFER_TYPE_DEPOSIT.equals(transactionType)
                        && !UtilConstants.TRANSFER_TYPE_WITHDRAW.equals(transactionType)) {
                    continue;
                }
                //done不为true的不抓，done为false表明这个转账刚创建
                boolean done = object.getBoolean("done");
                if (!done) {
                    continue;
                }
                //state不为success的不抓，不为success表明转账还未成功
                String state = object.getString("state");
                if (!StringUtils.equals(state, "success")) {
                    continue;
                }

                AccountTransferEntity entity = new AccountTransferEntity();
                entity.setTransId(object.getString("id"));
                entity.setCreationTime(new Date(object.getLong("created")));
                entity.setProductId(productId);
                entity.setPlatformId(platformId);
                entity.setTransferAmount(new BigDecimal(object.getString("amount")));
                entity.setPreviousAmount(new BigDecimal(object.getString("balanceBefore")));
                entity.setCurrentAmount(new BigDecimal(object.getString("balanceAfter")));
                if (UtilConstants.TRANSFER_TYPE_DEPOSIT.equals(transactionType)) {
                    entity.setTransferType(UtilConstants.TRANSFER_TYPE_IN);
                    entity.setUserName(object.getString("loginTo"));
                } else if (UtilConstants.TRANSFER_TYPE_WITHDRAW.equals(transactionType)) {
                    entity.setTransferType(UtilConstants.TRANSFER_TYPE_OUT);
                    entity.setUserName(object.getString("loginFrom"));
                }

                result.getOrderList().add(entity);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            result.setCode("-1");
        }

        return result;
    }
}
