package main.java.com.gw.common.system.parse;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.MD5;
import main.java.com.gw.common.system.parse.vo.OrderRes;
import main.java.com.gw.datacenter.order.entity.OrderEntity;

import org.apache.commons.digester3.Digester;

public class Gt1OrderHandle extends AbstractHandle {

    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        StringBuffer url = new StringBuffer();
        String baseUrl = getValueByKey(paramaterMap, "baseUrl", false);
        String page_no = getValueByKey(paramaterMap, "page");
        String page_count = getValueByKey(paramaterMap, "num");
        String agName = getValueByKey(paramaterMap, "agcode");
        String login = getValueByKey(paramaterMap, "username");

        Date date = new Date();
        long longtime = date.getTime();
        String curtime = DateUtil.formatDate2Str(date);
        paramaterMap.put("curtime", curtime);
        curtime = getValueByKey(paramaterMap, "curtime");

        String beginTime = getValueByKey(paramaterMap, "begintime");
        String endTime = getValueByKey(paramaterMap, "endtime");
        //md5_hash(login + curtime+"Goldway")
        String sid = MD5.MD5Encode(login + longtime + "Goldway");

        url.append(baseUrl).append("?");
        url.append("page_no=").append(page_no).append("&");
        url.append("page_count=").append(page_count).append("&");
        url.append("Login=").append(login).append("&");
        url.append("AgName=").append(agName).append("&");
        url.append("curtime=").append(curtime).append("&");
        url.append("longtime=").append(longtime).append("&");
        url.append("BeginTime=").append(beginTime).append("&");
        url.append("EndTime=").append(endTime).append("&");
        url.append("sid=").append(sid).append("&");
        url.append("Platform=CASH_GT1_IN");

        return url.toString();
    }

    /**
     * http://59.152.226.218:5555/rpt_agent_deal.ucs?
     * Login=test1&
     * AgName=c1&
     * curtime=2013-12-06 23:47:29&
     * longtime=1409123410&
     * sid=e4e49d2341960f2410e9495d8801fcb4&
     * UID=&
     * Symbol=&
     * OrderType=1&
     * Entry=1&
     * BuyOrAsk=1&
     * BeginTime=&
     * EndTime=&
     * page_no=1&
     * page_count=20
     *
     * @param args
     */
    public static void main(String[] args) {
        String beginTime = "2015-01-06 00:00:00";
        String endTime = "2015-01-06 23:59:59";
        Date time1 = DateUtil.formatStr2Date(beginTime, DateUtil.C_TIME_PATTON_DEFAULT);
        Date time2 = DateUtil.formatStr2Date(endTime, DateUtil.C_TIME_PATTON_DEFAULT);
        for (int i = 1; i < 2; i++) {
            beginTime = DateUtil.defineDayBefore2Str(time1, i);
            endTime = DateUtil.defineDayBefore2Str(time2, i);
            Map<String, Object> parameterMap = new HashMap<String, Object>();
            parameterMap.put("baseUrl", "http://59.152.226.218:5555/rpt_agent_deal.ucs");
            parameterMap.put("num", "30");
            parameterMap.put("page", "1");
            parameterMap.put("login", "test1");
            parameterMap.put("agcode", "c1");

            parameterMap.put("beginTime", beginTime);
            parameterMap.put("endTime", endTime);

            AbstractHandle handle = new Gt1OrderHandle();
            try {
                String response = handle.retrieveData(parameterMap);
                System.out.println(beginTime);
                System.out.println(response);
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    public void parseRules(Digester d) {
        d.addObjectCreate("Result", OrderRes.class);
        d.addSetProperties("Result", "TotalCount", "total");
        d.addSetProperties("Result", "Code", "code");
        d.addObjectCreate("Result/DealList/Deal", OrderEntity.class);
        d.addSetNext("Result/DealList/Deal", "addOrder");

        d.addSetProperties("Result/DealList/Deal", "Id", "billNo");
        d.addSetProperties("Result/DealList/Deal", "Login", "loginName");
        d.addSetProperties("Result/DealList/Deal", "SumValue", "cusAccount");
        d.addSetProperties("Result/DealList/Deal", "Symbol", "gameType");
        d.addSetProperties("Result/DealList/Deal", "Action", "gmCode");
        d.addSetProperties("Result/DealList/Deal", "OrderType", "remark");
        d.addSetProperties("Result/DealList/Deal", "Entry", "playType");
        d.addSetProperties("Result/DealList/Deal", "ExtendedData", "hashCode");
        d.addSetProperties("Result/DealList/Deal", "Volume", "tableCode");

        d.addCallMethod("Result/DealList/Deal", "setTime", 1);
        d.addCallParam("Result/DealList/Deal", 0, "Time");


//		d.addBeanPropertySetter("Response/Wagers/TimeSpanBetWagerInfoDto/SettlementStatus", "flag");
//		d.addBeanPropertySetter("Response/Wagers/TimeSpanBetWagerInfoDto/WinLossAmount", "cusAccount");

    }

}
