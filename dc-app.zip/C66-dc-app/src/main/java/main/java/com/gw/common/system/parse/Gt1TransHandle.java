package main.java.com.gw.common.system.parse;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.MD5;
import main.java.com.gw.common.system.parse.vo.TransRes;
import main.java.com.gw.datacenter.accounttransfer.entity.AccountTransferEntity;

import org.apache.commons.digester3.Digester;

public class Gt1TransHandle extends AbstractHandle {

    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        StringBuffer url = new StringBuffer();
        String baseUrl = getValueByKey(paramaterMap, "baseUrl", false);
        String page_no = getValueByKey(paramaterMap, "page");
        String page_count = getValueByKey(paramaterMap, "num");
        String agName = getValueByKey(paramaterMap, "agcode");
        String login = getValueByKey(paramaterMap, "username");

        Date date = new Date();
        long longtime = date.getTime();
        String curtime = DateUtil.formatDate2Str(date);
        paramaterMap.put("curtime", curtime);
        curtime = getValueByKey(paramaterMap, "curtime");

        String beginTime = getValueByKey(paramaterMap, "begintime");
        String endTime = getValueByKey(paramaterMap, "endtime");
        //md5_hash(login + curtime+"Goldway")
        String sid = MD5.MD5Encode(login + longtime + "Goldway");

        url.append(baseUrl).append("?");
        url.append("page_no=").append(page_no).append("&");
        url.append("page_count=").append(page_count).append("&");
        url.append("Login=").append(login).append("&");
        url.append("AgName=").append(agName).append("&");
        url.append("curtime=").append(curtime).append("&");
        url.append("longtime=").append(longtime).append("&");
        url.append("BeginTime=").append(beginTime).append("&");
        url.append("EndTime=").append(endTime).append("&");
        url.append("sid=").append(sid).append("&");
        url.append("Platform=CASH_GT1_IN");
        return url.toString();
    }

    public static void main(String[] args) {
        String beginTime = "2010-01-06 00:00:00";
        String endTime = "2015-01-10 23:59:59";
        Date time1 = DateUtil.formatStr2Date(beginTime, DateUtil.C_TIME_PATTON_DEFAULT);
        Date time2 = DateUtil.formatStr2Date(endTime, DateUtil.C_TIME_PATTON_DEFAULT);
        for (int i = 1; i < 2; i++) {
            beginTime = DateUtil.defineDayBefore2Str(time1, i);
            endTime = DateUtil.defineDayBefore2Str(time2, i);
            Map<String, Object> parameterMap = new HashMap<String, Object>();
            parameterMap.put("baseUrl", "http://59.152.226.218:5555/rpt_agent_credit.ucs");
            parameterMap.put("num", "30");
            parameterMap.put("page", "1");
            parameterMap.put("login", "test1");
            parameterMap.put("agcode", "c1");

            Date date = new Date();
            parameterMap.put("curtime", DateUtil.formatDate2Str(date));
            parameterMap.put("longtime", date.getTime());

            parameterMap.put("begintime", beginTime);
            parameterMap.put("endtime", endTime);

            AbstractHandle handle = new Gt1TransHandle();
            try {
                String response = handle.retrieveData(parameterMap);
                System.out.println(response);
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    public void parseRules(Digester d) {
        d.addObjectCreate("Result", TransRes.class);
        d.addSetProperties("Result", "TotalCount", "total");
        d.addSetProperties("Result", "Code", "code");
        d.addObjectCreate("Result/DealList/Item", AccountTransferEntity.class);
        d.addSetNext("Result/DealList/Item", "addOrder");

        d.addCallMethod("Result/DealList/Item", "setTradeNo", 1);
        d.addCallParam("Result/DealList/Item", 0, "id");

        d.addSetProperties("Result/DealList/Item", "Login", "userName");
        d.addSetProperties("Result/DealList/Item", "id", "transId");
        d.addSetProperties("Result/DealList/Item", "Type", "transferType");
        d.addSetProperties("Result/DealList/Item", "Change", "transferAmount");
        d.addSetProperties("Result/DealList/Item", "PrevAvailCredit", "previousAmount");
        d.addSetProperties("Result/DealList/Item", "NewAvailCredit", "currentAmount");

        d.addCallMethod("Result/DealList/Item", "setTime", 1);
        d.addCallParam("Result/DealList/Item", 0, "CreateTime");

    }

}
