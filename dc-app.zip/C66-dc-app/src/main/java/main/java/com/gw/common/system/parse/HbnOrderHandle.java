package main.java.com.gw.common.system.parse;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.HttpClientUtils;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.common.framework.util.JsonUtil;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.*;

@Slf4j
public class HbnOrderHandle {
    private static final String T_STR = "T";
    /**
     * HBN获取数据接口
     *
     * @param url
     * @param parameterMap
     * @return
     * @throws IOException
     */
    public List<OrderEntity> getHBNOrderRecord(String url, Map<String, Object> parameterMap) throws Exception {
        List<OrderEntity> list = new ArrayList<>();//定义一个集合对象把返回的数据存放到这里
        String timeZone = (String) parameterMap.get("timeZone");
        String productId = (String) parameterMap.get(UtilConstants.GLOBAL_PRODUCTID_KEY);
        String platformId =  UtilConstants.HBN;;
        String remark = (String) parameterMap.get("remark");
        String currency = (String) parameterMap.get("currency");
        String begintime = (String) parameterMap.get("begintime");
        String endtime = (String) parameterMap.get("endtime");
        String result = "";
        net.sf.json.JSONObject jsonObject=new net.sf.json.JSONObject();
        try {
            log.info("hbn parameterMap{}",JsonUtil.toJSONString(parameterMap));

            jsonObject.put("BrandId", parameterMap.get("brandId"));
            jsonObject.put("APIKey",parameterMap.get("apikey"));
            jsonObject.put("DTStartUTC", DateUtil.formatDefault2Define(begintime,DateUtil.C_TIME_PATTON_DEFAULT11));
            jsonObject.put("DTEndUTC", DateUtil.formatDefault2Define(endtime,DateUtil.C_TIME_PATTON_DEFAULT11));
            log.info("param list:{}",JsonUtil.toJSONString(jsonObject));
            result=HttpClientUtils.postJson(url,null,JsonUtil.toJSONString(jsonObject));
            log.info("HBN-注单抓取-url{}-result{}",url ,result);
        }catch (Exception e){
            log.error("HBN-注单抓取-url-BrandId{}-APIKey{}--DTStartUTC{}-DTEndUTC-{}-result:{}",url
                    ,jsonObject.get("BrandId"),jsonObject.get("APIKey"),jsonObject.get("DTStartUTC"),jsonObject.get("DTEndUTC"),result);
            log.error("HBN-注单抓取-HTTP请求异常-detail-{},{}" ,e);
            throw new GWCallRemoteApiException("HBN-注单抓取-HTTP请求异常",e);
        }
        if (StringUtils.isEmpty(result)) {
            log.error("getNewHbnOrderRecord  log, resonse no data");
            throw new GWCallRemoteApiException("HBN-注单抓取-response==null");
        }
        if(result.contains("Error")) {
            log.info("参数错误或异常：{}",result);
            return list;
        }

        JSONArray arr = null;
        try {
            arr = JSONObject.parseArray(result);

        } catch (Exception e) {
            log.error("hbn-拉取注单结果解析异常-{}" ,e);
        }

        Integer totalSize = arr.size();
        if (totalSize <=0) {
            log.info("hbn-拉取注单结果错误：-{}条" ,arr.size());
            return list;
        }
        parameterMap.put("apiTotal", totalSize);

        /**
         * [{"GameStateId":3,"PlayerId":"80758960-b887-eb11-b566-00155db545d0",
         * "BrandId":"b5974823-dc78-eb11-b566-00155db545d0","Username":"keli19",
         * "BrandGameId":"20772e6f-9470-49d8-97fb-ec0558bdfdce",
         * "GameKeyName":"SGOrbsOfAtlantis","GameTypeId":11,"DtStarted":"2021-03-18T13:59:34.987",
         * "DtCompleted":"2021-03-18T13:59:35.097","FriendlyGameInstanceId":1395562791,
         * "GameInstanceId":"a5d14f25-f287-eb11-b566-00155db545d0","Stake":7.5000,"Payout":0.0000,"JackpotWin":0.0,
         * "JackpotContribution":0.0,"CurrencyCode":"PHP","ChannelTypeId":1,"BalanceAfter":92.5000}]
         */
        for (int i = 0; i < arr.size(); i++) {
            Map<String,Object> arrMap= (Map<String,Object>)arr.get(i);
            // HBN GameStateId: 3-Completed, 4-Voided, 11-Expired, 3和11都是有效注单
            if(!arrMap.get("GameStateId").toString().equals("3")
                && !arrMap.get("GameStateId").toString().equals("11")){
                log.warn("状态非正常的注单: {}", JsonUtil.toJSONString(arrMap));
                continue;
            }
            try{
                log.info(JsonUtil.toJSONString(arrMap));
            }catch (Exception  ex){
                log.error(" hbn exception:{} ",ex.getMessage());
            }
            OrderEntity orderEntity = new OrderEntity();
            orderEntity.setBillNo(arrMap.get("GameInstanceId").toString());//注单
            orderEntity.setLoginName(arrMap.get("Username").toString());//玩家
            orderEntity.setAgCode(arrMap.get("BrandId").toString().substring(0,18));
            orderEntity.setTopAgCode(platformId);
            orderEntity.setPlatId(platformId);
            orderEntity.setProductId(productId);
            String bettime = arrMap.get("DtCompleted").toString();
            orderEntity.setBillTime(getDate(bettime, timeZone));
            log.info("betttimehbn:{}",orderEntity.getBillTime());
            orderEntity.setFlag(1);//拉到得注单都是已结算得
            orderEntity.setRemark(remark);
            orderEntity.setCurrency(arrMap.get("CurrencyCode").toString());
            orderEntity.setTableCode("");
            orderEntity.setRound("");
            orderEntity.setGameType(arrMap.get("GameKeyName").toString());
            orderEntity.setGameKind(UtilConstants.ELECT_GAME_KIND);
            orderEntity.setAccount(new BigDecimal(arrMap.get("Stake").toString()));
            orderEntity.setValidAccount( new BigDecimal(arrMap.get("Stake").toString()) );
            orderEntity.setValidAccountStr(arrMap.get("Stake").toString());
            orderEntity.setCurrentAmount(new BigDecimal(arrMap.get("BalanceAfter").toString()));
            orderEntity.setCreationDate(orderEntity.getBillTime());
            orderEntity.setOrignalBillTime(orderEntity.getBillTime());
            orderEntity.setOrignalReckonTime(orderEntity.getBillTime());
            orderEntity.setOrignalTimezone(timeZone);
            BigDecimal gameWin = new BigDecimal(arrMap.get("Payout").toString());
            gameWin = gameWin.subtract(orderEntity.getValidAccount());//老虎机输赢值 为派彩金额-投注金额
            orderEntity.setBonusAmount( BigDecimal.ZERO  );
            orderEntity.setRemainAmount(orderEntity.getValidAccount().setScale(2, RoundingMode.HALF_UP));
            orderEntity.setResult("");//
            orderEntity.setDeviceType( "");//
            orderEntity.setExchangeRate(BigDecimal.ONE);
            orderEntity.setTermType("0");
            orderEntity.setCusAccount(gameWin);//用户输赢
            orderEntity.setPreviosAmount(orderEntity.getCurrentAmount().subtract(orderEntity.getCusAccount()));
            list.add(orderEntity);
        }
        log.info("hbnlist:{}", JSON.toJSONString(list));
        return list;
    }


    private  Date getDate(String dateStr, String zone) {
//        if (null == dateStr) {
//            return null;
//        }
//        LocalDateTime parse = LocalDateTime.parse(dateStr.substring(0, 19), DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss"));
//        ZoneId zoneId = ZoneId.of(zone);
//        ZonedDateTime zonedDateTime = ZonedDateTime.of(parse, zoneId);
//        return Date.from(zonedDateTime.toInstant());
        Date   date= DateUtil.parseWithTimeZone(  dateStr.substring(0, 19),
                "yyyy-MM-dd'T'HH:mm:ss",zone );
        return date;
    }
    public static void main(String[] args) {
        String str = "[{\"GameStateId\":3,\"PlayerId\":\"80758960-b887-eb11-b566-00155db545d0\",\n" +
                "         \"BrandId\":\"b5974823-dc78-eb11-b566-00155db545d0\",\"Username\":\"keli19\",\n" +
                "         \"BrandGameId\":\"20772e6f-9470-49d8-97fb-ec0558bdfdce\",\n" +
                "         \"GameKeyName\":\"SGOrbsOfAtlantis\",\"GameTypeId\":11,\"DtStarted\":\"2021-03-18T13:59:34.987\", \"DtCompleted\":\"2021-03-18T13:59:35.097\",\"FriendlyGameInstanceId\":1395562791,\n" +
                "         \"GameInstanceId\":\"a5d14f25-f287-eb11-b566-00155db545d0\",\"Stake\":7.5000,\"Payout\":0.0000,\"JackpotWin\":0.0, \"JackpotContribution\":0.0,\"CurrencyCode\":\"PHP\",\"ChannelTypeId\":1,\"BalanceAfter\":92.5000}]";
        JSONArray  str1 =  JSONObject.parseArray(str);
        Map<String,Object> arrMap= (Map<String,Object>)str1.get(0);
        String bettime = "2020-07-14T03:40:42";
        System.out.println(DateUtil.formatDefault2Define("2021-03-24 23:51:59",DateUtil.C_TIME_PATTON_DEFAULT11));
       // Date d  =getDate(bettime, "Etc/GMT");
     //   System.out.println( d);
        log.info("{}",arrMap);
    }
}
