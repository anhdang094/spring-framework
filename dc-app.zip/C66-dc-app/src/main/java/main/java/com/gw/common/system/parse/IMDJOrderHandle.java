package main.java.com.gw.common.system.parse;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.entity.IMDJOrderEntity;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Slf4j
public class IMDJOrderHandle {

    public List<Object> getIMDJOrderRecords(String url, Map<String, Object> parameterMap) throws Exception {
        List<Object> orderEntityList = new ArrayList<>();
        HttpUtil httpUtil = new HttpUtil();
        String result = httpUtil.doPost(url, parameterMap);
//        String result = "{\"code\":\"success\",\"data\":[{\"betAmount\":-6545.65,\"betDate\":\"2019-08-05T14:52:33\",\"betType\":null,\"cancelled\":null,\"matchId\":null,\"odds\":\"0\",\"oddsType\":\"Euro\",\"orderNo\":\"1908050352310445\",\"previousAmount\":0,\"productId\":\"C07\",\"realSettlementDate\":\"2019-08-05T14:52:33\",\"settlementDate\":\"2019-08-05T14:52:33\",\"status\":0,\"totalRewardAmount\":null,\"userId\":\"C07ntestyoman1\",\"winAmount\":0},{\"betAmount\":-25000,\"betDate\":\"2019-08-05T14:36:17\",\"betType\":null,\"cancelled\":null,\"matchId\":null,\"odds\":\"0\",\"oddsType\":\"Euro\",\"orderNo\":\"1908050336160421\",\"previousAmount\":0,\"productId\":\"C07\",\"realSettlementDate\":\"2019-08-05T17:21:35\",\"settlementDate\":\"2019-08-05T16:21:35\",\"status\":-1,\"totalRewardAmount\":null,\"userId\":\"C07ntestyoman1\",\"winAmount\":-25000},{\"betAmount\":-798650.48,\"betDate\":\"2019-08-05T14:56:42\",\"betType\":null,\"cancelled\":null,\"matchId\":null,\"odds\":\"0\",\"oddsType\":\"Euro\",\"orderNo\":\"1908050356410452\",\"previousAmount\":0,\"productId\":\"C07\",\"realSettlementDate\":\"2019-08-05T17:50:37\",\"settlementDate\":\"2019-08-05T16:50:37\",\"status\":2,\"totalRewardAmount\":null,\"userId\":\"C07ntestyoman1\",\"winAmount\":718785.43},{\"betAmount\":-100,\"betDate\":\"2019-08-05T14:46:47\",\"betType\":null,\"cancelled\":null,\"matchId\":null,\"odds\":\"0\",\"oddsType\":\"Euro\",\"orderNo\":\"1908050346460434\",\"previousAmount\":0,\"productId\":\"C07\",\"realSettlementDate\":\"2019-08-05T17:41:38\",\"settlementDate\":\"2019-08-05T16:41:38\",\"status\":-1,\"totalRewardAmount\":null,\"userId\":\"C07ntestyoman1\",\"winAmount\":-100},{\"betAmount\":-1000000,\"betDate\":\"2019-08-05T14:48:27\",\"betType\":null,\"cancelled\":null,\"matchId\":null,\"odds\":\"0\",\"oddsType\":\"Euro\",\"orderNo\":\"1908050348260438\",\"previousAmount\":0,\"productId\":\"C07\",\"realSettlementDate\":\"2019-08-05T17:41:39\",\"settlementDate\":\"2019-08-05T16:41:39\",\"status\":-1,\"totalRewardAmount\":null,\"userId\":\"C07ntestyoman1\",\"winAmount\":-1000000},{\"betAmount\":-1000,\"betDate\":\"2019-08-05T14:29:41\",\"betType\":null,\"cancelled\":null,\"matchId\":null,\"odds\":\"0\",\"oddsType\":\"Euro\",\"orderNo\":\"1908050329260411\",\"previousAmount\":0,\"productId\":\"C07\",\"realSettlementDate\":\"2019-08-05T14:29:41\",\"settlementDate\":\"2019-08-05T14:29:41\",\"status\":0,\"totalRewardAmount\":null,\"userId\":\"C07ntestimsport\",\"winAmount\":0},{\"betAmount\":-35000,\"betDate\":\"2019-08-05T14:36:48\",\"betType\":null,\"cancelled\":null,\"matchId\":null,\"odds\":\"0\",\"oddsType\":\"Euro\",\"orderNo\":\"1908050336460422\",\"previousAmount\":0,\"productId\":\"C07\",\"realSettlementDate\":\"2019-08-05T17:43:09\",\"settlementDate\":\"2019-08-05T16:43:09\",\"status\":-1,\"totalRewardAmount\":null,\"userId\":\"C07ntestyoman1\",\"winAmount\":-35000},{\"betAmount\":-1000,\"betDate\":\"2019-08-05T14:24:25\",\"betType\":null,\"cancelled\":null,\"matchId\":null,\"odds\":\"0\",\"oddsType\":\"Euro\",\"orderNo\":\"1908050324230406\",\"previousAmount\":0,\"productId\":\"C07\",\"realSettlementDate\":\"2019-08-05T14:24:25\",\"settlementDate\":\"2019-08-05T14:24:25\",\"status\":0,\"totalRewardAmount\":null,\"userId\":\"C07ntestimsport\",\"winAmount\":0},{\"betAmount\":-1000,\"betDate\":\"2019-08-05T14:29:17\",\"betType\":null,\"cancelled\":null,\"matchId\":null,\"odds\":\"0\",\"oddsType\":\"Euro\",\"orderNo\":\"1908050329150410\",\"previousAmount\":0,\"productId\":\"C07\",\"realSettlementDate\":\"2019-08-05T14:29:17\",\"settlementDate\":\"2019-08-05T14:29:17\",\"status\":0,\"totalRewardAmount\":null,\"userId\":\"C07ntestimsport\",\"winAmount\":0},{\"betAmount\":-1000,\"betDate\":\"2019-08-05T14:31:28\",\"betType\":null,\"cancelled\":null,\"matchId\":null,\"odds\":\"0\",\"oddsType\":\"Euro\",\"orderNo\":\"1908050331270413\",\"previousAmount\":0,\"productId\":\"C07\",\"realSettlementDate\":\"2019-08-05T17:18:14\",\"settlementDate\":\"2019-08-05T16:18:14\",\"status\":2,\"totalRewardAmount\":null,\"userId\":\"C07ntestimsport\",\"winAmount\":1770},{\"betAmount\":-1000,\"betDate\":\"2019-08-05T14:31:15\",\"betType\":null,\"cancelled\":null,\"matchId\":null,\"odds\":\"0\",\"oddsType\":\"Euro\",\"orderNo\":\"1908050331140412\",\"previousAmount\":0,\"productId\":\"C07\",\"realSettlementDate\":\"2019-08-05T14:31:15\",\"settlementDate\":\"2019-08-05T14:31:15\",\"status\":0,\"totalRewardAmount\":null,\"userId\":\"C07ntestimsport\",\"winAmount\":0},{\"betAmount\":-40000,\"betDate\":\"2019-08-05T14:37:39\",\"betType\":null,\"cancelled\":null,\"matchId\":null,\"odds\":\"0\",\"oddsType\":\"Euro\",\"orderNo\":\"1908050337370425\",\"previousAmount\":0,\"productId\":\"C07\",\"realSettlementDate\":\"2019-08-05T14:37:39\",\"settlementDate\":\"2019-08-05T14:37:39\",\"status\":0,\"totalRewardAmount\":null,\"userId\":\"C07ntestyoman1\",\"winAmount\":0},{\"betAmount\":-59910,\"betDate\":\"2019-08-05T14:34:54\",\"betType\":null,\"cancelled\":null,\"matchId\":null,\"odds\":\"0\",\"oddsType\":\"Euro\",\"orderNo\":\"1908050334530419\",\"previousAmount\":0,\"productId\":\"C07\",\"realSettlementDate\":\"2019-08-05T14:34:54\",\"settlementDate\":\"2019-08-05T14:34:54\",\"status\":0,\"totalRewardAmount\":null,\"userId\":\"C07ntestyoman1\",\"winAmount\":0}]}";
        if (ToolUtil.isNeedInterceptResponse(parameterMap.get(UtilConstants.ORDER_TASK_ID) + "")) {
            log.info(" Intercept:TaskId:{},Url:{},Response:{}", parameterMap.get(UtilConstants.ORDER_TASK_ID), url, result);
        }
        if (StringUtils.isEmpty(result)) {
            log.info("IMDJ Response empty Params:{}", parameterMap);
            return orderEntityList;
        }
        log.info(" IMDJ get IMDJ order record result:{}", result);
        JSONObject object = JSONObject.parseObject(result);
        JSONArray dataList = object.getJSONArray("data");
        if (dataList == null || dataList.isEmpty()) {
            return orderEntityList;
        }
        for (int i = 0; i < dataList.size(); i++) {
            JSONObject jsonObject = dataList.getJSONObject(i);
            IMDJOrderEntity imdjOrderEntity = JSON.toJavaObject(jsonObject, IMDJOrderEntity.class);
            OrderEntity orderEntity = new OrderEntity();
            orderEntity.setAccount(imdjOrderEntity.getBetAmount().abs());
            orderEntity.setBillNo(imdjOrderEntity.getOrderNo());
            orderEntity.setBillTime(imdjOrderEntity.getBetDate());
            orderEntity.setCreationDate(new Date());
            orderEntity.setCusAccount(imdjOrderEntity.getWinAmount());
            orderEntity.setRemainAmount(imdjOrderEntity.getBetAmount().abs());
            orderEntity.setValidAccount(imdjOrderEntity.getBetAmount().abs());
            String productId = imdjOrderEntity.getProductId();
            if (StringUtils.isNotBlank(imdjOrderEntity.getUserId()) && imdjOrderEntity.getUserId().startsWith(productId)) {
                String name = imdjOrderEntity.getUserId().substring(productId.length());
                orderEntity.setLoginName(name);
            } else {
                orderEntity.setLoginName(imdjOrderEntity.getUserId());
            }
            orderEntity.setPlatId(UtilConstants.IMDJ);
            orderEntity.setGmCode(String.valueOf(imdjOrderEntity.getOrderNo()));
            orderEntity.setReckonTime(imdjOrderEntity.getRealSettlementDate() != null ? imdjOrderEntity.getRealSettlementDate() : imdjOrderEntity.getBetDate());
            orderEntity.setGameType(imdjOrderEntity.getBetType());
            orderEntity.setCurrency((String) parameterMap.get("currency"));
            orderEntity.setBonusAmount(BigDecimal.ZERO);
            orderEntity.setDeviceType("0");
            orderEntity.setOdds(imdjOrderEntity.getOdds() == null ? BigDecimal.ZERO : new BigDecimal(imdjOrderEntity.getOdds()));
            orderEntity.setGameKind(UtilConstants.GAME_KIND_ENUM.E_SPORT.getCode());
            orderEntity.setProductId(imdjOrderEntity.getProductId());
            orderEntity.setPreviosAmount(imdjOrderEntity.getPreviousAmount());

            switch (imdjOrderEntity.getStatus()) {
                case -1:
                    orderEntity.setResult("Lose");
                    orderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.SETTLED.getFalg());
                    if (orderEntity.getOdds().compareTo(new BigDecimal("1.5")) <= 0) {
                        orderEntity.setRemainAmount(BigDecimal.ZERO);
                        orderEntity.setValidAccount(BigDecimal.ZERO);
                    }
                    break;
                case 0:
                    orderEntity.setResult("Pending");
                    orderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.UNSETTLED.getFalg());
                    orderEntity.setRemainAmount(BigDecimal.ZERO);
                    orderEntity.setValidAccount(BigDecimal.ZERO);
                    break;
                case 1:
                    orderEntity.setResult("Cancelled");
                    orderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.CANCELED.getFalg());
                    orderEntity.setRemainAmount(BigDecimal.ZERO);
                    orderEntity.setValidAccount(BigDecimal.ZERO);
                    break;
                case 2:
                    orderEntity.setResult("Win");
                    orderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.SETTLED.getFalg());
                    if (orderEntity.getOdds().compareTo(new BigDecimal("1.5")) <= 0) {
                        orderEntity.setRemainAmount(BigDecimal.ZERO);
                        orderEntity.setValidAccount(BigDecimal.ZERO);
                    }
                    break;
                case 3:
                    orderEntity.setResult("Tie");
                    orderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.SETTLED.getFalg());
                    orderEntity.setRemainAmount(BigDecimal.ZERO);
                    orderEntity.setValidAccount(BigDecimal.ZERO);
                    break;
            }
            if("C08".equals(orderEntity.getProductId())) {
                if(orderEntity.getOdds().compareTo(new BigDecimal(1.5))<0) {
                    orderEntity.setValidAccount(BigDecimal.ZERO);
                    orderEntity.setRemainAmount(BigDecimal.ZERO);
                }
            }

            orderEntityList.add(orderEntity);
        }
        return orderEntityList;
    }



}
