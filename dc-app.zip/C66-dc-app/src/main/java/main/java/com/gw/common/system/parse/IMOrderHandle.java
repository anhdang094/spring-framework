package main.java.com.gw.common.system.parse;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.entity.IMOrderEntity;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Slf4j
public class IMOrderHandle {

    public List<Object> getIMOrderRecords(String url, Map<String, Object> parameterMap) throws Exception {
        List<Object> orderEntityList = new ArrayList<>();
        HttpUtil httpUtil = new HttpUtil();
        String result = httpUtil.doPost(url, parameterMap);
//        String result = "{\"code\":\"success\",\"data\":[{\"betAmount\":10,\"betDate\":\"2019-06-10T15:50:16\",\"betType\":\"1\",\"checkOdds\":null,\"odds\":\"1.56\",\"orderNo\":\"C0720190409144814567807\",\"productId\":\"C07\",\"realSettlementDate\":\"2019-06-10T15:50:16\",\"settlementDate\":\"2019-06-10T15:50:16\",\"status\":0,\"userId\":\"C07test\",\"winAmount\":0}]}";

        if (ToolUtil.isNeedInterceptResponse(parameterMap.get(UtilConstants.ORDER_TASK_ID) + "")) {
            log.info(" Intercept:TaskId={},Url={},Response={}", parameterMap.get(UtilConstants.ORDER_TASK_ID), url, result);
        }
        if (StringUtils.isEmpty(result)) {
            log.info("IM Response empty Params:{}", parameterMap);
            return orderEntityList;
        }
        log.info(" IM get IM order record result:{}", result);
        JSONObject object = JSONObject.parseObject(result);
        JSONArray dataList = object.getJSONArray("data");
        if (dataList == null || dataList.isEmpty()) {
            return orderEntityList;
        }
        for (int i = 0; i < dataList.size(); i++) {
            JSONObject jsonObject = dataList.getJSONObject(i);
            IMOrderEntity imOrderEntity = JSON.toJavaObject(jsonObject, IMOrderEntity.class);
            OrderEntity orderEntity = new OrderEntity();
            orderEntity.setAccount(imOrderEntity.getBetAmount().abs());
            orderEntity.setBillNo(imOrderEntity.getOrderNo());
            orderEntity.setBillTime(imOrderEntity.getBetDate());
            orderEntity.setCreationDate(new Date());
            orderEntity.setCusAccount(imOrderEntity.getWinAmount());
            orderEntity.setRemainAmount(imOrderEntity.getBetAmount().abs());
            orderEntity.setValidAccount(imOrderEntity.getBetAmount().abs());
            String productId = imOrderEntity.getProductId();
            if (StringUtils.isNotBlank(imOrderEntity.getUserId()) && imOrderEntity.getUserId().startsWith(productId)) {
                String name = imOrderEntity.getUserId().substring(productId.length(), imOrderEntity.getUserId().length());
                orderEntity.setLoginName(name);
            } else {
                orderEntity.setLoginName(imOrderEntity.getUserId());
            }
            orderEntity.setPlatId(UtilConstants.IM);
            orderEntity.setGmCode(String.valueOf(imOrderEntity.getOrderNo()));
            orderEntity.setReckonTime(imOrderEntity.getRealSettlementDate() != null ? imOrderEntity.getRealSettlementDate() : imOrderEntity.getBetDate());
            orderEntity.setRemark(imOrderEntity.getCheckOdds());
            orderEntity.setGameType(imOrderEntity.getBetType());
            orderEntity.setCurrency((String) parameterMap.get("currency"));
            orderEntity.setBonusAmount(BigDecimal.ZERO);
            orderEntity.setDeviceType("0");
            orderEntity.setGameKind(UtilConstants.GAME_KIND_ENUM.BALL.getCode());
            orderEntity.setProductId(imOrderEntity.getProductId());
            orderEntity.setPreviosAmount(imOrderEntity.getPreviousAmount());

            switch (imOrderEntity.getStatus()) {
                case -1:
                    orderEntity.setResult("Lose");
                    orderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.SETTLED.getFalg());
                    orderEntity.setOdds(imOrderEntity.getWinAmount().abs().divide(imOrderEntity.getBetAmount(), 2, RoundingMode.DOWN).setScale(2, RoundingMode.DOWN).abs());
                    if (cacul(imOrderEntity.getWinAmount().abs(), imOrderEntity.getBetAmount().abs()) >= 0) {
                        orderEntity.setRemainAmount(imOrderEntity.getBetAmount().abs());
                    } else {
                        orderEntity.setRemainAmount(BigDecimal.ZERO);
                    }
                    break;
                case 0:
                    orderEntity.setResult("Pending");
                    orderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.UNSETTLED.getFalg());
                    orderEntity.setRemainAmount(BigDecimal.ZERO);
                    orderEntity.setValidAccount(BigDecimal.ZERO);

                    break;
                case 1:
                    orderEntity.setResult("Cancelled");
                    orderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.CANCELED.getFalg());
                    orderEntity.setRemainAmount(BigDecimal.ZERO);
                    orderEntity.setValidAccount(BigDecimal.ZERO);

                    break;
                case 2:
                    orderEntity.setResult("Win");
                    orderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.SETTLED.getFalg());
                    orderEntity.setOdds(imOrderEntity.getWinAmount().abs().divide(imOrderEntity.getBetAmount(), 2, RoundingMode.DOWN).setScale(2, RoundingMode.DOWN).abs());
                    if (cacul(imOrderEntity.getWinAmount().abs(), imOrderEntity.getBetAmount().abs()) >= 0) {
                        orderEntity.setRemainAmount(imOrderEntity.getBetAmount().abs());
                    } else {
                        orderEntity.setRemainAmount(BigDecimal.ZERO);
                    }
                    break;
                case 3:
                    orderEntity.setResult("Tie");
                    orderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.SETTLED.getFalg());
                    orderEntity.setRemainAmount(BigDecimal.ZERO);
                    orderEntity.setValidAccount(BigDecimal.ZERO);
                    break;
                default:
            }

            //如果是提前结算需要设置他的有效投注额为用户输赢的绝对值 add by yaser 2020.4.21
            if(UtilConstants.IMRequestType.BT_BUY_BACK.getRequestType().equals(imOrderEntity.getRequestType())){
                orderEntity.setValidAccount(orderEntity.getCusAccount().setScale(6, RoundingMode.DOWN).abs());
            }
            orderEntityList.add(orderEntity);
        }
        return orderEntityList;
    }

    private int cacul(BigDecimal winLoseAmount, BigDecimal remainAmount) {
        return winLoseAmount.divide(remainAmount, 2, RoundingMode.DOWN).setScale(2, RoundingMode.DOWN).compareTo(new BigDecimal("0.5"));
    }
}
