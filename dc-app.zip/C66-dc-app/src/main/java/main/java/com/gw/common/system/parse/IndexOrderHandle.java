package main.java.com.gw.common.system.parse;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.MD5;
import main.java.com.gw.common.system.parse.vo.OrderRes;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.digester3.Digester;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Slf4j
public class IndexOrderHandle extends AbstractHandle {

    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        /**
         * http://10.5.15.51:6666/order_list.xml?
         * num=30&
         * page=1&
         * timetype=0&
         * billtime1=2011-08-05 00:00:00&
         * billtime2=2011-08-05 23:59:59&
         * producttype=B01&
         * key=d4f1ad125a3406253ff3a3f0334cb803
         */
        StringBuffer url = new StringBuffer();
        String baseUrl = getValueByKey(paramaterMap, "baseUrl", false);
        String agent = getValueByKey(paramaterMap, "agcode");
        String num = getValueByKey(paramaterMap, "num");
        String page = getValueByKey(paramaterMap, "page");
        String timetype = getValueByKey(paramaterMap, "timetype");
        String billtime1 = getValueByKey(paramaterMap, "begintime");
        String billtime1_1 = getValueByKey(paramaterMap, "begintime", false);
        String billtime2 = getValueByKey(paramaterMap, "endtime");
        String billtime2_1 = getValueByKey(paramaterMap, "endtime", false);
        String key = MD5.MD5Encode(agent + timetype + billtime1_1 + billtime2_1 + num + page + "index_new");
        try {
            url.append(baseUrl).append("?");
            url.append("agent=").append(agent).append("&");
            url.append("num=").append(num).append("&");
            url.append("page=").append(page).append("&");
            url.append("timetype=").append(timetype).append("&");
            url.append("billtime1=").append(billtime1).append("&");
            url.append("billtime2=").append(billtime2).append("&");
            url.append("key=").append(key);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
//		System.out.println(url);
        return url.toString();
    }

    public static void main(String[] args) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(DateUtil.C_TIME_PATTON_DEFAULT7);
        String a = dateFormat.format(new Date());
        System.out.println(a);
        String billtime1 = "2013-01-01 00:00:00";
        String billtime2 = "2013-11-01 23:59:59";
        Date time1 = DateUtil.formatStr2Date(billtime1, DateUtil.C_TIME_PATTON_DEFAULT);
        Date time2 = DateUtil.formatStr2Date(billtime2, DateUtil.C_TIME_PATTON_DEFAULT);
        for (int i = 1; i < 2; i++) {
            billtime1 = DateUtil.defineDayBefore2Str(time1, i);
            billtime2 = DateUtil.defineDayBefore2Str(time2, i);
            Map<String, Object> parameterMap = new HashMap<String, Object>();
            parameterMap.put("baseUrl", "http://10.5.15.51:6666/order_list.xml");
            parameterMap.put("num", "30");
            parameterMap.put("page", "1");
            parameterMap.put("timetype", "0");
            parameterMap.put("billtime1", billtime1);
            parameterMap.put("billtime2", billtime2);
            parameterMap.put("producttype", "B01");
            AbstractHandle handle = new IndexOrderHandle();
            try {
                String response = handle.retrieveData(parameterMap);
                if (response.contains("row")) {
                    //return;
                }
                System.out.println(billtime1);
                System.out.println(response);

                //OrderRes res=handle.parse(response);
//				System.out.println(res.total);
//				if(res.orderList.size()>0)
//					for (int j = 0; j <res.orderList.size(); j++) {
//						System.out.print(res.orderList.get(j).toString());
//					}
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    public void parseRules(Digester d) {
        d.addObjectCreate("result", OrderRes.class);
        d.addBeanPropertySetter("result/addition/total", "total");
        d.addObjectCreate("result/row", OrderEntity.class);
        d.addSetNext("result/row", "addOrder");

        d.addSetProperties("result/row", "BILLNO", "billNo");
        d.addSetProperties("result/row", "LOGINNAME", "loginName");
        d.addSetProperties("result/row", "PRDID", "gameType");//游戏类型
        d.addSetProperties("result/row", "ORDERTYPE", "playType");//玩法
        d.addSetProperties("result/row", "CUS_ACCOUNT", "cusAccount");
        d.addSetProperties("result/row", "DEPOSIT", "account");
        d.addSetProperties("result/row", "POSITIONTYPE", "gmCode");//游戏局号
        d.addSetProperties("result/row", "apptype", "platId");//游戏平台
        d.addSetProperties("result/row", "FLAG", "tableCode");// 0--未平仓、5--已取消、2--自动平仓、1--手动平仓、3--日结算、4--周结算）
        d.addSetProperties("result/row", "FLAG", "flag");// 0--未平仓、5--已取消、2--自动平仓、1--手动平仓、3--日结算、4--周结算）
        //d.addSetProperties("result/row", "OPENTIME","billTime");

        d.addCallMethod("result/row", "setTime__0to8", 1);
        d.addCallParam("result/row", 0, "OPENTIME");


//		d.addBeanPropertySetter("Response/Wagers/TimeSpanBetWagerInfoDto/SettlementStatus", "flag");
//		d.addBeanPropertySetter("Response/Wagers/TimeSpanBetWagerInfoDto/WinLossAmount", "cusAccount");

    }

}
