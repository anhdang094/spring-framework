package main.java.com.gw.common.system.parse;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.MD5;
import main.java.com.gw.common.system.parse.vo.TransRes;
import main.java.com.gw.datacenter.accounttransfer.entity.AccountTransferEntity;

import org.apache.commons.digester3.Digester;

public class IndexTransHandle extends AbstractHandle {
    private String producttype = "B01";

    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        StringBuffer url = new StringBuffer();
        String baseUrl = getValueByKey(paramaterMap, "baseUrl", false);
        String date_start = getValueByKey(paramaterMap, "begintime");
        String date_end = getValueByKey(paramaterMap, "endtime");
        String num = getValueByKey(paramaterMap, "num");
        String page = getValueByKey(paramaterMap, "page");
        String agCode = getValueByKey(paramaterMap, "agcode");

//		String yyyymmdd = DateUtil.formatDate2Str(new Date(), DateUtil.C_DATE_PATTON_YYYYMMDD);
        String yyyymmdd = getYYYYMMDD();
        String key = MD5.MD5Encode(agCode + producttype + yyyymmdd + num + page + "index_new");
        url.append(baseUrl).append("?");
        url.append("producttype=").append(producttype).append("&");
        url.append("username=").append(agCode).append("&");
        url.append("num=").append(num).append("&");
        url.append("page=").append(page).append("&");
        url.append("date_start=").append(date_start).append("&");
        url.append("date_end=").append(date_end).append("&");
        url.append("key=").append(key);
        return url.toString();
    }

    private String getYYYYMMDD() {
        Calendar calendar = DateUtil.date2Calendar(new Date());
        calendar.add(Calendar.HOUR_OF_DAY, -8);
        return DateUtil.formatDate2Str(DateUtil.calendar2Date(calendar), DateUtil.C_DATE_PATTON_YYYYMMDD);
    }


    public static void main(String[] args) {
        String date_start = "20140208";
        String date_end = "20140209";
        Date time1 = DateUtil.formatStr2Date(date_start, DateUtil.C_DATE_PATTON_YYYYMMDD);
        Date time2 = DateUtil.formatStr2Date(date_end, DateUtil.C_DATE_PATTON_YYYYMMDD);
        for (int i = 1; i < 300; i++) {
            date_start = DateUtil.defineDayBefore2Object(time1, i, DateUtil.C_DATE_PATTON_YYYYMMDD, "");
            date_end = DateUtil.defineDayBefore2Object(time2, i, DateUtil.C_DATE_PATTON_YYYYMMDD, "");
            Map<String, Object> parameterMap = new HashMap<String, Object>();
            parameterMap.put("baseUrl", "http://10.5.15.51:6666/report_trans.xml");
            parameterMap.put("num", "30");
            parameterMap.put("page", "1");
            parameterMap.put("date_start", date_start);
            parameterMap.put("date_end", date_end);
            parameterMap.put("producttype", "B01");
            AbstractHandle handle = new IndexTransHandle();
            try {
                String response = handle.retrieveData(parameterMap);
//				System.out.println(date_start);
                System.out.println(response);
                if (response.contains("<Record>")) {
                    return;
                }

                //OrderRes res=handle.parse(response);
//				System.out.println(res.total);
//				if(res.orderList.size()>0)
//					for (int j = 0; j <res.orderList.size(); j++) {
//						System.out.print(res.orderList.get(j).toString());
//					}
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    public void parseRules(Digester d) {
        d.addObjectCreate("Data", TransRes.class);
        d.addBeanPropertySetter("Data/addition/total", "total");
        d.addBeanPropertySetter("Data/Code", "code");
        d.addObjectCreate("Data/Record", AccountTransferEntity.class);
        d.addSetNext("Data/Record", "addOrder");

        d.addCallMethod("Data/Record/TradeNo", "setTradeNo", 1);
        d.addCallParam("Data/Record/TradeNo", 0);

        d.addCallMethod("Data/Record/CreateTime", "setTime__0to8", 1);
        d.addCallParam("Data/Record/CreateTime", 0);

        d.addBeanPropertySetter("Data/Record/UserName", "userName");
        d.addBeanPropertySetter("Data/Record/TransType", "transferType");
        d.addBeanPropertySetter("Data/Record/Amount", "transferAmount");
        d.addBeanPropertySetter("Data/Record/SrcAmount", "previousAmount");
        d.addBeanPropertySetter("Data/Record/Balance", "currentAmount");
        d.addBeanPropertySetter("Data/Record/WagersID", "wagerId");
        d.addBeanPropertySetter("Data/Record/BalanceType", "balanceType");

        d.addCallMethod("Data/Record/IP", "setIP", 1);
        d.addCallParam("Data/Record/IP", 0);

        d.addBeanPropertySetter("Data/Record/Currency", "currency");
        d.addBeanPropertySetter("Data/Record/ExchangeRate", "exchangeRate");
        d.addBeanPropertySetter("Data/Record/TransID", "transId");
        //d.addBeanPropertySetter("Data/Record/RATE", "exchangeRate");
        d.addBeanPropertySetter("Data/Record/Flag", "flag");

    }

}
