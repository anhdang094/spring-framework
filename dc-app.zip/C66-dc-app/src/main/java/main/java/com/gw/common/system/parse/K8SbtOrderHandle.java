package main.java.com.gw.common.system.parse;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.common.framework.util.MD5;
import main.java.com.gw.common.system.entity.SBTOrderEntity;
import main.java.com.gw.common.system.parse.vo.SbtBetResult;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Slf4j
public class K8SbtOrderHandle extends AbstractHandle {

    public String retrieveData(String url, Map<String, Object> paramaterMap)
            throws GWCallRemoteApiException {

        Map<String, Object> para = new HashMap<String, Object>();
        List<String> keys = Arrays.asList(UtilConstants.ORDER_BEGIN_TIME, UtilConstants.ORDER_END_TIME, "pageSize", "pageNum");
        for (String key : keys) {
            para.put(UtilConstants.ORDER_BEGIN_TIME.equals(key) ? "startDate" : UtilConstants.ORDER_END_TIME.equals(key) ? "endDate" : key, paramaterMap.get(key));
        }
        para.put("sign", getNewMap(para));
        String content = "";
        HttpUtil httpUtil = new HttpUtil();
        try {
            content = httpUtil.doPost(url, para);
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new GWCallRemoteApiException("Failed to call remote interface!" + ex.getMessage(), ex);
        }

        return content;

    }

    public static String getNewMap(Map<String, Object> para) {
        List<String> keyList = new ArrayList<>(para.keySet());
        Collections.sort(keyList);
        String sign = "";
        for (String key : keyList) {
            sign += para.get(key);
        }
        return MD5.MD5Encode(sign + "The#%!oNE");
    }

    private static Integer getFlag(Integer oldFlag) {
        Integer newFlag = 0;
        switch (oldFlag) {//sbt返回 1 结算 2进行中  3无效  4 兑现
            //结算
            case 1:
            case 4:
                newFlag = 1;
                break;
            //进行中
            case 2:
                newFlag = 0;
                break;
            //取消
            case 3:
                newFlag = -9;
                break;
            default:
                break;
        }
        return newFlag;
    }

    private static String getPlatformId(String oldId) {
        String newId = "";
        if ("SBT".equals(oldId.toUpperCase())) {
            newId = UtilConstants.K8_SPORT_SBT;
        } else {
            newId = UtilConstants.K8_SHABA_FCLRC;
        }
        return newId;
    }

    /**
     * 体育站抓取注单解析数据
     *
     * @param data
     * @return
     * @throws GWCallRemoteApiException
     */
    public SbtBetResult parseData(String data) throws GWCallRemoteApiException {
        JSONObject parseObject = JSONObject.parseObject(data);
        SbtBetResult result = new SbtBetResult();
        if (parseObject == null) {
            return result;
        }
        result.setCode(parseObject.getJSONObject("status").getString("err_code"));
        JSONObject pagination = parseObject.getJSONObject("data").getJSONObject("pagination");
        result.setCurrentPage(pagination.getInteger("current_page"));
        result.setTotal(pagination.getInteger("total_count"));
        result.setTotalPages(pagination.getInteger("page_count"));
        JSONArray list = parseObject.getJSONObject("data").getJSONArray("list");
        List<SBTOrderEntity> orderList = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) {
            String bet_id = "";
            try {
                JSONObject ob = list.getJSONObject(i);
                log.info("开始处理体育站原始信息:注单ID:" + ob.getString("bet_id") + "," + "注单状态:" + ob.getIntValue("order_state") + ",data:" + ob.toJSONString());
                SBTOrderEntity orderEntity = new SBTOrderEntity();

                // 读取单条注单数据
                String loginName = ob.getString("loginName");
                // 总赔率
                BigDecimal odds = new BigDecimal(ob.getString("odds") == null ? "0" : ob.getString("odds").replaceAll(",", ""));
                bet_id = ob.getString("bet_id");
                String update_time = ob.getString("update_time");
                String creation_date = ob.getString("creation_date");
                String platform = ob.getString("platform");
                String sport_name = ob.getString("sport_name");
                String line_type_name = ob.getString("line_type_name");
                // 投注额
                BigDecimal stake = new BigDecimal(ob.getString("stake") == null ? "0" : ob.getString("stake").replaceAll(",", ""));
                // 实际有效投注额
                BigDecimal valid_stake = new BigDecimal(ob.getString("valid_stake") == null ? "0" : ob.getString("valid_stake").replaceAll(",", ""));
                // 订单状态
                int order_state = ob.getIntValue("order_state");
                // 总输赢值
                BigDecimal win_or_lose = new BigDecimal(ob.getString("win_or_lose") == null ? "0" : ob.getString("win_or_lose").replaceAll(",", ""));
                // 派奖值
                BigDecimal win_amount = new BigDecimal(ob.getString("win_amount") == null ? "0" : ob.getString("win_amount").replaceAll(",", ""));
                Integer combinations = ob.getInteger("combinations");

                // 设置注单数据对象
                orderEntity.setBetId(bet_id);
                orderEntity.setLoginName(loginName);
                orderEntity.setProductId("A02");
                orderEntity.setPlatformId(getPlatformId(platform));
                orderEntity.setCurrency("CNY");
                orderEntity.setFlag(getFlag(order_state));
                orderEntity.setCreateDate(new SimpleDateFormat(DateUtil.C_TIME_PATTON_DEFAULT).parse(creation_date));
                orderEntity.setLastUpdate(new SimpleDateFormat(DateUtil.C_TIME_PATTON_DEFAULT).parse(update_time));
                orderEntity.setBranchName(sport_name);
                orderEntity.setBetTypeName(line_type_name);
                orderEntity.setAmount(stake);
                orderEntity.setValidAmount(BigDecimal.ZERO);
                orderEntity.setRemainAmount(BigDecimal.ZERO);
                orderEntity.setPayOffAmount(win_or_lose);

                // 注单状态为已结算，才计算有效投注额和洗码投注额，否则为0
                if (orderEntity.getFlag() == 1) {
                    log.info("体育站开始过滤洗码投注额规则:注单ID:" + bet_id);
                    orderEntity.setValidAmount(stake);
                    orderEntity.setRemainAmount(stake);
                    //  #######不计算洗码投注额####### 混合模式下， 只要有一条赔率低于0.5，则视为不计算洗码投注额
                    if (combinations != null && combinations > 1) {

                        JSONArray detailArr = ob.getJSONArray("detail");
                        if (detailArr != null && detailArr.size() > 0) {
                            if (checkMixGameTypeRabetAmount(detailArr)) {
                                log.info("体育站洗码投注额规则1，混合模式，存在赔率低于欧盘（1.5）:主注单ID:" + bet_id);
                                orderEntity.setRemainAmount(BigDecimal.ZERO);
                            }
                        } else {
                            log.info("体育站获取混合模式子单信息记录为空:主注单ID:" + bet_id + "," + "注单状态:" + order_state);
                            continue;
                        }
                    } else {
                        //  #######不计算洗码投注额####### 赔率低于1.5
                        if (odds.compareTo(new BigDecimal(1.5)) < 0) {
                            log.info("体育站洗码投注额规则2，不计算洗码投注额（赔率低于欧盘（1.5））:注单ID:" + bet_id + "，赔率：" + odds);
                            orderEntity.setRemainAmount(BigDecimal.ZERO);
                        }
                    }
                    // #######不计算洗码投注额####### 单注注单金额为X元，派彩X元，单注总输赢额为0 则计算不洗码投注额为0, 有效投注额为0
                    if (stake.compareTo(win_amount) == 0 && win_or_lose.compareTo(BigDecimal.ZERO) == 0) {
                        log.info("体育站洗码投注额规则3，不计算洗码投注额（赛事取消）:注单ID:" + bet_id);
                        orderEntity.setRemainAmount(BigDecimal.ZERO);
                        orderEntity.setValidAmount(BigDecimal.ZERO);
                    }
                }
                log.info("DC转换之后信息:注单ID:" + orderEntity.getBetId() + "," + "注单状态:" + orderEntity.getFlag());
                orderList.add(orderEntity);
            } catch (ParseException e) {
                log.error("体育站获取信息解析数据异常:主注单ID:" + bet_id, e);
            }
        }
        result.setOrderList(orderList);
        return result;
    }

    public static void main(String[] args) {
        // String url = "http://54.169.107.60:8082/sport/search-bet-result";
        String url = "http://67.229.225.106:81/sport/search-bet-result";
        // {website=null, productId=A02, endDate=2017-01-12 00:00:00,
        // pageSize=10, timeZone=Etc/GMT-8, task_id=846, platformid=orders_sbt,
        // dataDelay=0, pageNum=1, gamekind=null, password=null,
        // baseUrl=http://54.169.107.60:8082/sport/search-bet-result,
        // beginSeconds=1000, endSeconds=3600000, model=null, gameCode=null,
        // platformName=SBT, startDate=2017-01-12 00:00:00,
        // username=http://whlapi3.sbtech.com/whlcustomers.asmx/GetOpenBets}
        Map<String, Object> para = new HashMap<String, Object>();
//		para.put("startDate", "2017-01-12 00:00:00");
//		para.put("endDate", "2017-10-12 00:00:00");
//		para.put("pageNum", "1");
//		para.put("pageSize", "1000");
//		para.put("platformName", "SHANGBA");
//		para.put("sign", getNewMap(para));

        para.put("platformName", "SBT");
        para.put("credit", "100");
        para.put("loginName", "cjack003");
        para.put("type", "OUT");
        para.put("sign", getNewMap(para));

        System.out.println(JSON.toJSONString(para));

        try {
            K8SbtOrderHandle k8SbtOrderHandle = new K8SbtOrderHandle();
            String retrieveData = k8SbtOrderHandle.retrieveData(url, para);
            SbtBetResult parse = k8SbtOrderHandle.parseData(retrieveData);
            Set<String> set = new HashSet<>();
            for (SBTOrderEntity orderEntity : parse.getOrderList()) {
                set.add(orderEntity.getBetId());
            }
            System.out.println(set.size());
            //System.out.println(JSON.toJSONString(parse));
        } catch (GWCallRemoteApiException e) {
            e.printStackTrace();
        }
    }

    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        return null;
    }

    /**
     * 混合模式判断明细中是否存在赔率低于限定最小值0.5，如果存在则全部不计算
     * true=存在；false=不存在
     *
     * @param detailArr
     * @return
     */
    public static boolean checkMixGameTypeRabetAmount(JSONArray detailArr) {
        for (Object detail : detailArr) {
            JSONObject detailObj = (JSONObject) detail;
            BigDecimal odds = new BigDecimal(detailObj.getString("odds_in_user_style") == null ? "0" : detailObj.getString("odds_in_user_style").replaceAll(",", ""));
            if (odds.compareTo(new BigDecimal(1.5)) < 0) {
                return true;
            }
        }
        return false;
    }

}
