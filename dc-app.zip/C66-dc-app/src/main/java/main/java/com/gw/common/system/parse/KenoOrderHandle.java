package main.java.com.gw.common.system.parse;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.MD5;
import main.java.com.gw.common.system.parse.vo.OrderRes;
import main.java.com.gw.common.system.parse.vo.Result;
import main.java.com.gw.datacenter.order.entity.OrderEntity;

import org.apache.commons.digester3.Digester;
import org.apache.commons.io.IOUtils;

public class KenoOrderHandle extends AbstractHandle {

    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        String baseUrl = (String) paramaterMap.get("baseUrl");
        String begintimeStr = (String) paramaterMap.get("begintime");
        String endtimeStr = (String) paramaterMap.get("endtime");
        Date d = DateUtil.formatStr2Date(begintimeStr);
        Date d1 = DateUtil.formatStr2Date(endtimeStr);
        String productid = (String) paramaterMap.get("productId");
        String pidtoken = (String) paramaterMap.get("pidtoken");
        String begintime = String.valueOf(d.getTime());
        String endtime = String.valueOf(d1.getTime());
        begintime = begintime.substring(0, 10);
        endtime = endtime.substring(0, 10);
        String order = "Time";
        int numperpage = Integer.valueOf((String) paramaterMap.get(UtilConstants.ORDER_PAGE_NUMBER));
        int page = Integer.valueOf((String) paramaterMap.get("page"));
        String by = "desc";
        String str = (String) paramaterMap.get("str");
        String sessionkey = MD5.MD5Encode(pidtoken + begintime + endtime + numperpage + order + page + productid + str);
        String act = (String) paramaterMap.get("act");
        String tmp_uri = "?&act=%s&pidtoken=%s&begintime=%s&endtime=%s&numperpage=%s&order=%s&page=%s&productid=%s&sessionkey=%s";
        tmp_uri = String.format(tmp_uri, act, pidtoken, begintime, endtime, numperpage, order, page, productid, sessionkey);
        return baseUrl + tmp_uri;
    }


    public static void main(String args[]) {
        Map<String, Object> paramaterMap = new HashMap<String, Object>();
        StringBuffer xml = new StringBuffer();
        try {
            List<String> list = IOUtils.readLines(new FileInputStream(new File("D:\\workspace\\GWDataCenterAppTrunk\\src\\test\\test.xml")), "UTF-8");
            for (int i = 0; i < list.size(); i++) {
                xml.append(list.get(i));
            }
            System.out.println(xml);
        } catch (FileNotFoundException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        } catch (IOException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
        KenoOrderHandle h = new KenoOrderHandle();

        Result res;
        try {
//				String xml=h.retrieveData(paramaterMap);
//				System.out.println(xml);
            res = h.parse(xml.toString());
            System.out.println(res.getOrderList().toString());
//				String time="1448626199";
//				new OrderEntity().setUnixTimeStampToDate(time);

//				System.out.println(new Date(1448626199));
        } catch (GWCallRemoteApiException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();

        }
    }


    public void parseRules(Digester d) {
        d.addObjectCreate("result", OrderRes.class);
        d.addBeanPropertySetter("result/addition/num_per_page", "perpage");
        d.addBeanPropertySetter("result/addition/total", "total");


        d.addObjectCreate("result/row", OrderEntity.class);
        d.addSetNext("result/row", "addOrder");
        d.addSetProperties("result/row", "billno", "billNo");
        d.addSetProperties("result/row", "loginname", "loginName");
        d.addSetProperties("result/row", "agcode", "agCode");
        d.addSetProperties("result/row", "gmcode", "gmCode");
        d.addSetProperties("result/row", "billtime", "billNo");
        d.addSetProperties("result/row", "reckontime", "billNo");
        d.addSetProperties("result/row", "playtype", "playType");
        d.addSetProperties("result/row", "currency", "currency");
        d.addSetProperties("result/row", "round", "round");
        d.addSetProperties("result/row", "remark", "remark");
        d.addSetProperties("result/row", "account", "billNo");
        d.addSetProperties("result/row", "cus_account", "cusAccount");
        d.addSetProperties("result/row", "valid_account", "billNo");
        d.addSetProperties("result/row", "flag", "billNo");
        d.addSetProperties("result/row", "device", "billNo");
        d.addBeanPropertySetter("OrderRes/Bill/UserCashBefore", "previosAmount");
        d.addBeanPropertySetter("OrderRes/Bill/UserCashDelta", "cusAccount");
        d.addBeanPropertySetter("OrderRes/Bill/UserCashCurrent", "currentAmount");
//		d.addBeanPropertySetter("OrderRes/Bill/UserCashEarn","userCashEarn");
        d.addBeanPropertySetter("OrderRes/Bill/UserCashPay", "account");
        d.addBeanPropertySetter("OrderRes/Bill/UserCashPay", "validAccount");
        d.addCallMethod("OrderRes/Bill/Time", "setUnixTimeStampToDate", 1);
        d.addCallParam("OrderRes/Bill/Time", 0);
        d.addBeanPropertySetter("OrderRes/Bill/ProductId", "productId");
        d.addCallMethod("OrderRes/Bill/ProductId", "setPlatId", 1);
        d.addBeanPropertySetter("OrderRes/Bill/UserName", "loginName");
        d.addCallMethod("OrderRes/Bill/UserName", "setDefaultFlag");
    }


}
