package main.java.com.gw.common.system.parse;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.HttpClientUtils;
import main.java.com.gw.common.framework.util.LCSignature;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.entity.LCOrderEntity;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Slf4j
public class LCOrderHandle {

    private static final SimpleDateFormat dateFormat = dateFormat();

    private static SimpleDateFormat dateFormat() {
        SimpleDateFormat dateFormat = new SimpleDateFormat(DateUtil.C_TIME_PATTON_DEFAULT);
        dateFormat.setTimeZone(TimeZone.getTimeZone("Etc/GMT-8")); // 厅方时区
        return dateFormat;
    }

    private static Date transferDate(String date) {
        try {
            return new Date(dateFormat.parse(date).getTime());
        } catch (ParseException e) {
            log.error("pbOrderHandler parse time error!!!!");
            return null;
        }
    }

    private void setRemainAmount(OrderEntity newOrderEntity) {
        if (newOrderEntity.getRemainAmount() == null) {
            newOrderEntity.setRemainAmount(newOrderEntity.getValidAccount().setScale(6, RoundingMode.DOWN));
        }
    }


    public List<OrderEntity> getLCOrderRecord(String url, Map<String, Object> parameterMap) {
        log.info("trying to getLCOrderRecord, url: {}", url);
        List<OrderEntity> list = new ArrayList<>();
        String[] pbParam = ((String) parameterMap.get("password")).split(";");
        String productId = ((String) parameterMap.get(UtilConstants.GLOBAL_PRODUCTID_KEY));
        String agentCode = pbParam[0];
        String time = new Date().getTime() + "";
        String result = null;
        String deskey = pbParam[1];
        String md5key = pbParam[2];
        String startTime = transferDate((String) parameterMap.get("begintime")).getTime() + "";
        String endTime = transferDate((String) parameterMap.get("endtime")).getTime() + "";
        log.info("getLCOrderRecord lc log ,startTime ：{}", startTime);
        log.info("getLCOrderRecord lc log ,endTime ：{}", endTime);
        String params = "s=6&startTime=" + startTime + "&endTime=" + endTime;
        log.info("getLCOrderRecord lc log,request params:" + params);
        try {
            String eneParam = LCSignature.AESEncrypt(params, deskey);
            String key = LCSignature.MD5(agentCode + time + md5key);
            String IcUrl = url + "?agent=" + agentCode + "&timestamp=" + time + "&param=" + eneParam + "&key=" + key;
            log.info("getLCOrderRecord lc log,request IcUrl:" + IcUrl);
            result = HttpClientUtils.execGet(IcUrl, null);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        if (ToolUtil.isNeedInterceptResponse(parameterMap.get(UtilConstants.ORDER_TASK_ID) + "")) {
            log.info(">> LC >> get lc order record:TaskId=" + parameterMap.get(UtilConstants.ORDER_TASK_ID) + ",Url=" + url+", result:" + result);
        }

        if (StringUtils.isEmpty(result)) {
            log.info("getLCOrderRecord lc log, response no data, request params:" + parameterMap);
            return list;
        }

        JSONObject jsonObject = com.alibaba.fastjson.JSONObject.parseObject(result);
        JSONObject d = JSONObject.parseObject(jsonObject.getString("d"));
        int code = d.getIntValue("code");
        if(code==16 || code==43){
            return list;
        }
        int count = d.getInteger("count");
        log.info(">> LC >> get lc count :" + count);
        if (count < 1) {
            return list;
        }
        JSONObject listStr = JSONObject.parseObject(d.getString("list"));
        JSONArray gameID = listStr.getJSONArray("GameID");
        JSONArray accounts = listStr.getJSONArray("Accounts");
        JSONArray gameStartTime = listStr.getJSONArray("GameStartTime");
        JSONArray gameEndTime = listStr.getJSONArray("GameEndTime");
        JSONArray cellScore = listStr.getJSONArray("CellScore");
        JSONArray allBet=listStr.getJSONArray("AllBet");
        JSONArray revenue = listStr.getJSONArray("Revenue");
        JSONArray kindID = listStr.getJSONArray("KindID");
        JSONArray tableID = listStr.getJSONArray("TableID");
        JSONArray profit = listStr.getJSONArray("Profit");
        for (int i = 0; i < count; i++) {
            String userName = accounts.getString(i).replaceFirst(agentCode+"_","");
            LCOrderEntity lcOrderEntity = new LCOrderEntity();
            lcOrderEntity.setLoginname(userName);
            lcOrderEntity.setProductId(productId);
            lcOrderEntity.setRevenue(revenue.getString(i));
            lcOrderEntity.setGameID(gameID.getString(i));
            lcOrderEntity.setGameStartTime(transferDate(gameStartTime.getString(i)));
            lcOrderEntity.setGameEndTime(transferDate(gameEndTime.getString(i)));
            lcOrderEntity.setCellScore(Float.parseFloat(cellScore.getString(i)));
            lcOrderEntity.setAllBet(Float.parseFloat(allBet.getString(i)));
            lcOrderEntity.setRevenue(revenue.getString(i));
            lcOrderEntity.setKindID(kindID.getString(i));
            lcOrderEntity.setTableID(tableID.getString(i));
            lcOrderEntity.setAgCode(agentCode);
            lcOrderEntity.setProfit(profit.getString(i));
            OrderEntity orderEntityTemp = transferEntityForLC(lcOrderEntity);
            orderEntityTemp.setOrignalTimezone((String) parameterMap.get(UtilConstants.NSS_TIMEZONE));
            setRemainAmount(orderEntityTemp);
            list.add(orderEntityTemp);
        }
        return list;
    }


    private static OrderEntity transferEntityForLC(LCOrderEntity entity) {
        if (entity == null) {
            return null;
        }
        OrderEntity o = new OrderEntity();
        o.setBillNo(entity.getGameID());
        o.setProductId(entity.getProductId());
        o.setPlatId(UtilConstants.LC);
        o.setLoginName(entity.getLoginname());
        o.setBillNo(entity.getGameID());
        o.setBillTime(entity.getGameStartTime());
        o.setOrignalBillTime(entity.getGameEndTime());
        o.setReckonTime(new Date());
        o.setOrignalReckonTime(new Date());
        o.setCreationDate(new Date());
        o.setAccount(new BigDecimal(entity.getAllBet()));
        o.setCusAccount(new BigDecimal(entity.getProfit()));
        o.setOdds(new BigDecimal(entity.getRevenue()).setScale(2, RoundingMode.HALF_UP));
        o.setOddsType(entity.getLineCode());
        o.setTableCode(entity.getTableID());
        o.setGmCode(entity.getGameID());
        o.setGameType(entity.getKindID());
        o.setFlag(1);
        o.setValidAccount(new BigDecimal(entity.getCellScore()));
        o.setGameKind(UtilConstants.GAME_KIND_ENUM.CHESS.getCode());
        o.setDeviceType("0");
        o.setAgCode(entity.getAgCode());
        return o;
    }


}
