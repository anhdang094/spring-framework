package main.java.com.gw.common.system.parse;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.exception.GWPersistenceException;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.common.framework.util.MD5;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.parse.vo.OrderRes;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.digester3.Digester;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Angus.Z on 2017/10/3.
 */
@Slf4j
public class MGOrderHandle extends AbstractHandle {

    public String retrieveData(String url, Map<String, Object> paramaterMap) throws GWCallRemoteApiException {
        String content = "";
        try {
            log.info("url=" + url + "  parama=" + paramaterMap);
            content = new HttpUtil().httpGet(url, paramaterMap);
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new GWCallRemoteApiException("Failed to call remote interface!" + ex.getMessage(), ex);
        }

        return content;

    }

    public static void main(String[] args) throws GWCallRemoteApiException, GWPersistenceException {
        try {
            Map<String, Object> parameterMap = new HashMap<>();

            String baseUrl = "http://localhost:8080/cw/MGBetRecord";
            String productid = "A02";// "0";
            parameterMap.put("productId", productid);
//        String starttime = "2017-01-16 15:10:33";
//        String endtime = "2017-01-16 15:10:33";
//        String starttime = "2017-01-16 07:10:33"; // minux 8 hours
//        String endtime = "2017-01-16 07:10:33"; // minux 8 hours
            String starttime = "2017-01-16 00:00:00"; // test separate time
            String endtime = "2017-01-16 00:10:00"; // test separate time
            parameterMap.put("begintime", starttime);
            parameterMap.put("endtime", endtime);
            String page = "1";
            parameterMap.put("page", page);
            String num = "500";
            parameterMap.put("num", num);
            String gameCode = "2";
            parameterMap.put("gameCode", gameCode);
            String key = MD5.md5Encoding("12").toUpperCase();
            parameterMap.put("key", key);
            parameterMap.put("timeZone", "Etc/GMT+1");
            parameterMap.put("dataDelay", 2);
            parameterMap.put("baseUrl", baseUrl);
            parameterMap.put("platformid", "order_mg");
            parameterMap.put("task_id", 751);
            parameterMap.put("remark", "B06 MG 注单");
            String platform = "035"; //mg:035,mgvip:054
            String timeZone = (String) parameterMap.get("timeZone");
            int dataDelay = (int) parameterMap.get("dataDelay");

            AbstractHandle handle = new MGOrderHandle();

            // Add this block to correct the mistake
            String separateTime = (String) parameterMap.get("remark"); //切换时间点
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            if (separateTime == null || separateTime.equals("") || separateTime.length() < 19) {
                Calendar calendar = Calendar.getInstance();
                calendar.add(Calendar.YEAR, 1);
                separateTime = format.format(calendar.getTime());
            } else {
                try {
                    separateTime = separateTime.substring(0, 19);
                    format.parse(separateTime);
                } catch (Exception e) {
                    Calendar calendar = Calendar.getInstance();
                    calendar.add(Calendar.YEAR, 1);
                    separateTime = format.format(calendar.getTime());
                }
            }
            System.out.println(separateTime);
            int switchTaskId = 751; //只切751这个任务
            int tid = (Integer) parameterMap.get(UtilConstants.ORDER_TASK_ID);
            Date separate = format.parse(separateTime);
            Date start = format.parse((String) parameterMap.get("begintime"));
            Date end = format.parse((String) parameterMap.get("endtime"));
            if (tid == switchTaskId && start.before(separate) && end.compareTo(separate) >= 0) {
                parameterMap.put("endtime", separateTime);
            }


            //boolean isWait = ToolUtil.isWaitXMins(parameterMap, UtilConstants.TIMEZONE_GMT, 4);
            boolean isWait = ToolUtil.isWaitXMins(parameterMap, timeZone, dataDelay);
            if (!isWait) {
//            String confDir = File.separator + System.getProperty("user.dir") + File.separator + "conf";
//            FileSystemXmlApplicationContext factory = new FileSystemXmlApplicationContext(confDir + "/spring/applicationContext.xml");
//            OrderService orderService= (OrderService)factory.getBean("orderService");
//            String Url = (String)parameterMap.get("baseUrl");
                if (start.compareTo(separate) >= 0 && tid == switchTaskId) {
//                orderService.insertOrder4MGS(parameterMap, Url, null, false);
                    System.out.println("insertOrder4MGS");
                } else {
//                orderService.insertOrder4MG(parameterMap, Url, null, false);
                    System.out.println("insertOrder4MG");
                }
                System.out.println(parameterMap.get("begintime"));
                System.out.println(parameterMap.get("endtime"));
                parameterMap = ToolUtil.updateTimeForBBINParameterMap(parameterMap, 0, 600000);
                System.out.println(parameterMap.get("begintime"));
                System.out.println(parameterMap.get("endtime"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
//        String result = handle.retrieveData(baseUrl, parameterMap);
//        //String result="<Data Page=\"1\" PageLimit=\"20\" TotalNumber=\"2\" TotalPage=\"1\" sattus=\"0\" desc=\"\"  > <Record>       <amount>0.02</amount>        <bonusAmount>0</bonusAmount>        <createdDate>2017-09-27 13:40:10</createdDate>        <currency>CNY</currency>        <currentbalance>8826.18</currentbalance>        <gameCode>52</gameCode>        <gameTypeid>53</gameTypeid>        <gameid>53</gameid>        <gamesessionid>png_session_1</gamesessionid>        <isfreegame>1</isfreegame>        <loginname>A02crndtest</loginname>        <previousbalance>8826.2</previousbalance>        <productid>A02</productid>        <remark>VIP</remark>        <requestid>43211</requestid>        <requesttype>700</requesttype>        <roundid>87654322</roundid>        <transactionid>323</transactionid>    </Record>   <Record>       <amount>0.02</amount>        <bonusAmount>0</bonusAmount>        <createdDate>2017-09-27 13:40:46</createdDate>        <currency>CNY</currency>        <currentbalance>8826.2</currentbalance>        <gameCode>52</gameCode>        <isfreegame>1</isfreegame>        <loginname>A02crndtest</loginname>        <previousbalance>8826.18</previousbalance>        <productid>A02</productid>        <requestid>43211</requestid>        <requesttype>702</requesttype>        <roundid>87654322</roundid>        <transactionid>324</transactionid>    </Record>  <Record>       <amount>0.22</amount>        <bonusAmount>0</bonusAmount>        <createdDate>2017-09-27 13:40:46</createdDate>        <currency>CNY</currency>        <currentbalance>8826.2</currentbalance>        <gameCode>52</gameCode>        <isfreegame>1</isfreegame>        <loginname>A02crndtest</loginname>        <previousbalance>8826.18</previousbalance>        <productid>A02</productid>        <requestid>43212</requestid>        <requesttype>700</requesttype>        <roundid>87654323</roundid>        <transactionid>324</transactionid>    </Record> <Record>       <amount>0.44</amount>        <bonusAmount>0</bonusAmount>        <createdDate>2017-09-27 13:40:46</createdDate>        <currency>CNY</currency>        <currentbalance>8826.2</currentbalance>        <gameCode>52</gameCode>        <isfreegame>1</isfreegame>        <loginname>A02crndtest</loginname>        <previousbalance>8826.18</previousbalance>        <productid>A02</productid>        <requestid>43212</requestid>        <requesttype>710</requesttype>        <roundid>87654323</roundid>        <transactionid>324</transactionid>    </Record>   </Data>";
//        System.out.println(result);
//        List<Object> orderLit = handle.parse(result).getOrderList();
//        System.out.println(orderLit);
//
//        String confDir = File.separator + System.getProperty("user.dir") + File.separator + "conf";
//        FileSystemXmlApplicationContext factory = new FileSystemXmlApplicationContext(confDir + "/spring/applicationContext.xml");
//        OrderDao orderDao= (OrderDao)factory.getBean("orderDao");
//        AllocationDao allocationDao= (AllocationDao)factory.getBean("allocationDao");
//        SqlSessionFactory myBatisSessionFactory = (SqlSessionFactory)factory.getBean("myBatisSessionFactory");
//        SqlSession session = myBatisSessionFactory.openSession();
//        ToolUtil.initSpecialGames(platform, allocationDao);
//
//        orderDao.insertOrder4MG(orderLit, session, false,platform);


    }

    public void parseRules(Digester d) {
        d.addObjectCreate("Data", OrderRes.class);
        d.addSetProperties("Data", "sattus", "code");
        d.addSetProperties("Data", "desc", "comment");
        d.addSetProperties("Data", "Page", "numpage");
        d.addSetProperties("Data", "PageLimit", "perpage");
        d.addSetProperties("Data", "TotalNumber", "total");
        d.addSetProperties("Data", "TotalPage", "totalPages");
        d.addObjectCreate("Data/Record", OrderEntity.class);
        d.addSetNext("Data/Record", "addOrder");
//        d.addBeanPropertySetter("Data/Record/transactionid","billNo");
        d.addBeanPropertySetter("Data/Record/previousbalance", "previosAmount");
        d.addBeanPropertySetter("Data/Record/currentbalance", "currentAmount");
        d.addBeanPropertySetter("Data/Record/transactionSubtypeid", "playType");
        d.addBeanPropertySetter("Data/Record/bonusAmount", "bonusAmount");
        d.addBeanPropertySetter("Data/Record/amount", "account");
        d.addBeanPropertySetter("Data/Record/amount", "validAccount");
        d.addBeanPropertySetter("Data/Record/gameid", "billNo");
        d.addBeanPropertySetter("Data/Record/gameid", "tableCode");
        d.addBeanPropertySetter("Data/Record/gameTypeid", "gameType");
        d.addBeanPropertySetter("Data/Record/currency", "currency");
        d.addCallMethod("Data/Record/createdDate", "setTime", 1);
        d.addCallParam("Data/Record/createdDate", 0);
        d.addBeanPropertySetter("Data/Record/productid", "productId");
        d.addCallMethod("Data/Record/loginname", "setLoginNameSubString3", 1);
        d.addCallParam("Data/Record/loginname", 0);
        d.addBeanPropertySetter("Data/Record/deviceType", "deviceType");
        d.addCallMethod("Data/Record/transactionSubtypeid", "setFlagAccordingRequesttype", 1);
        d.addCallParam("Data/Record/transactionSubtypeid", 0);
    }

    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        return null;
    }
}
