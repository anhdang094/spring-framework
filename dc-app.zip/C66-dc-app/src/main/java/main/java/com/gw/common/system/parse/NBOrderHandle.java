package main.java.com.gw.common.system.parse;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.common.framework.util.JsonUtil;
import main.java.com.gw.common.framework.util.ObjectConstructUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.entity.NBOrderEntity;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

//import main.java.com.gw.common.framework.constant.UtilConstants.NB_TRANSFER_ENUM;
//import main.java.com.gw.common.system.entity.NBCreditEntity;
@Slf4j
public class NBOrderHandle {

//	public List<NBCreditEntity> getNBCreditRecord(String url, Map<String, Object> parameterMap) throws IOException {
//		HttpUtil http=new HttpUtil();
//		List<NBCreditEntity> list = new ArrayList<>();
//		String result = "";
//
//		result = http.doPost(url, parameterMap);
//		// Add interception to retrieve Response
//		if(ToolUtil.isNeedInterceptResponse(parameterMap.get(UtilConstants.ORDER_TASK_ID)+"")) {
//			log.info("Intercept:TaskId="+parameterMap.get(UtilConstants.ORDER_TASK_ID)+",Url="+url+",Response="+result);
//		}
//		if(StringUtils.isEmpty(result)){
//			log.info("request nb log, resonse empty, request params:" + parameterMap);
//			return list;
//		}
//		log.info(">> NB >> get nb crecdit record result:" + result);
//		JSONObject object = JsonUtil.StringToJSONOBject(result);
//
//		JSONArray dataList = object.getJSONArray("data");
//		if(dataList == null || dataList.isEmpty()){
//			log.info("getNBCreditRecord nb log, resonse no data, request params:" + parameterMap);
//			return list;
//		}
//		for (int i = 0; i < dataList.size(); i++) {
//			JSONObject object2 = dataList.getJSONObject(i);
//			NBCreditEntity bean = (NBCreditEntity) JSONObject.toBean(object2, NBCreditEntity.class);
//			String name = bean.getLoginName();
//
//			String productId = bean.getProductId();
//			String prefix = name.substring(0, productId.length());
//			if(StringUtils.equals(productId, prefix)){
//				name = name.substring(productId.length(), name.length());
//				bean.setLoginName(name);
//			}
//			Date date = DateUtil.formatStr2Date(bean.getCreateTime());
//			if(date != null){
//				bean.setCreateDate(date);
//			}
//			if(bean.getCurrentBalance() == null){
//				bean.setCurrentBalance(BigDecimal.ZERO);
//			}
//
//			bean.setTransferType(NB_TRANSFER_ENUM.getDescById(bean.getRequestType()));
//			list.add(bean);
//		}
//
//		return list;
//	}

    public List<OrderEntity> getNBOrderRecord(String url, Map<String, Object> parameterMap) throws IOException {
        HttpUtil http = new HttpUtil();
        List<OrderEntity> list = new ArrayList<>();
        String result = "";
        result = http.doPost(url, parameterMap);
        // Add interception to retrieve Response
        if (ToolUtil.isNeedInterceptResponse(parameterMap.get(UtilConstants.ORDER_TASK_ID) + "")) {
            log.info("Intercept:TaskId=" + parameterMap.get(UtilConstants.ORDER_TASK_ID) + ",Url=" + url + ",Response=" + result);
        }
        if (StringUtils.isEmpty(result)) {
            log.info("getNBOrderRecord nb log, response no data, request params:" + parameterMap);
            return list;
        }
        log.info(">> NB >> get nb order record,Url[" + url + "], result:" + result);
        JSONObject object = JsonUtil.StringToJSONOBject(result);

        JSONArray dataList = object.getJSONArray("data");
        if (dataList == null || dataList.isEmpty()) {
            return list;
        }
        for (int i = 0; i < dataList.size(); i++) {
            JSONObject object2 = dataList.getJSONObject(i);
            NBOrderEntity bean = (NBOrderEntity) JSONObject.toBean(object2, NBOrderEntity.class);
            String name = bean.getUserId();
            if (StringUtils.isBlank(name) || StringUtils.isBlank(bean.getBetNo())) {
                log.error("getNBOrderRecord nb log, found data no name or no betNo, data str[{}]", object2);
                continue;
            }
            String productId = bean.getProductId();
            String prefix = name.substring(0, productId.length());
            if (StringUtils.equals(productId, prefix)) {
                name = name.substring(productId.length(), name.length());
                bean.setLoginName(name);
            }
            if (StringUtils.isBlank(bean.getPlatformId())) {
                bean.setPlatformId(UtilConstants.NB);
            }
            if (StringUtils.isBlank(bean.getGameKind())) {
                bean.setGameKind(UtilConstants.GAME_KIND_ENUM.BALL.getCode());
            }
            Date date = DateUtil.formatStr2Date(bean.getOrderDate());
            if (date != null) {
                bean.setCreateDate(date);
            }
            date = DateUtil.formatStr2Date(bean.getSettlementDate());
            if (date != null) {
                bean.setLastUpdate(date);
            }
            //统一化各个游戏的deviceType在平台这边的定义
            bean.setDeviceType(ToolUtil.unifyAllDeviceType(bean.getDeviceType(), bean.getCreateDate(), bean.getPlatformId()));
            bean.setOdds(bean.getOdds().setScale(2, RoundingMode.HALF_UP));

            /**NBOrderEntity转OrderEntity*/
            OrderEntity orderEntityTemp = transferEntityForNB(bean);
            //洗码投注额计算
            ObjectConstructUtil.calculateValidAndRemainAmountForSportGame(orderEntityTemp);
            list.add(orderEntityTemp);
        }
        return list;
    }

    /**
     * @Description:
     * @Author: Ziv.Y
     * @Date: 2018/5/21 21:06
     */
    public static OrderEntity transferEntityForNB(NBOrderEntity entity) {
        if (entity == null) {
            return null;
        }
        OrderEntity o = new OrderEntity();
        o.setProductId(entity.getProductId());
        o.setPlatId(entity.getPlatformId());
        o.setLoginName(entity.getLoginName());
        o.setBillNo(entity.getBetNo());
        o.setBillTime(entity.getCreateDate());
        o.setAccount(entity.getBetAmount());
        o.setValidAccount(entity.getValidAmount());
        o.setCusAccount(entity.getCusAmount());
        o.setGmCode(entity.getOrderNo());
        o.setGameType(entity.getGameType());
        try {
            o.setPlayType(Integer.parseInt(entity.getPlayType()));
        } catch (Exception e) {
            o.setPlayType(-1);
        }
        o.setGameKind(entity.getGameKind());
        o.setDeviceType(entity.getDeviceType());
        o.setCurrency(entity.getCurrency());
        o.setPreviosAmount(entity.getPreviousBalance());
        o.setFlag(entity.getFlag());
        if (entity.getFlag() == 1 && (new BigDecimal(BigInteger.ZERO)).compareTo(entity.getCusAmount()) == 0) {
            //和局，更新游戏结果，洗码时判断使用
            o.setResult("Tie");
        }
        o.setOddsType(entity.getOddsType());
        o.setOdds(entity.getOdds());
        o.setCreationDate(entity.getCreateDate());
        o.setReckonTime(entity.getLastUpdate());
        return o;
    }

}
