package main.java.com.gw.common.system.parse;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.exception.GWPersistenceException;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.common.framework.util.MD5;
import main.java.com.gw.common.system.parse.vo.OrderRes;
import main.java.com.gw.datacenter.allocation.dao.AllocationDao;
import main.java.com.gw.datacenter.order.dao.OrderDao;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.digester3.Digester;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class NETENTOrderHandle extends AbstractHandle {

    public String retrieveData(String url, Map<String, Object> paramaterMap) throws GWCallRemoteApiException {
        String content = "";
        try {
            log.info("url=" + url + "  parama=" + paramaterMap);
            content = new HttpUtil().httpGet(url, paramaterMap);
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new GWCallRemoteApiException("Failed to call remote interface!" + ex.getMessage(), ex);
        }
        return content;

    }
    
/*    public static AccountTransferEntity converOrderEntity2AccountTransferEntity(OrderEntity order){
        AccountTransferEntity transfer= new AccountTransferEntity();
    	transfer.setTransId(order.getBillNo());
    	transfer.setPlatformId(order.getPlatId());
    	transfer.setUserName(order.getLoginName());
    	transfer.setCreationTime(order.getBillTime());
    	transfer.setTransferType(IOM_BET_TYPE_ENUM.getCodeString(order.getPlayType()+""));
    	transfer.setTransferAmount(order.getAccount());
    	transfer.setPreviousAmount(order.getPreviosAmount());
    	transfer.setCurrentAmount(order.getCurrentAmount());
    	transfer.setCurrency(order.getCurrency());
    	transfer.setExchangeRate(order.getExchangeRate());
    	//transfer.setBalanceType();
    	transfer.setIP(order.getCurIp());
    	transfer.setProductId(order.getProductId());
    	transfer.setAgCode(order.getAgCode());
    	transfer.setTopAgCode(order.getTopAgCode());
    	transfer.setTradeNo(order.getBillNo());
    	transfer.setOrignalCreationTime(order.getOrignalBillTime());
    	return transfer;
    }*/

    public static void main(String[] args) throws GWCallRemoteApiException, GWPersistenceException {
        Map<String, Object> paramaterMap = new HashMap<String, Object>();
        String baseUrl = "http://localhost:8080/cw/NetEntBetRecord";
        String productid = "C01";// "0";
        paramaterMap.put("productId", productid);
        String starttime = "2017-09-23 16:05:00";
        String endtime = "2017-10-06 16:09:59";
        paramaterMap.put("starttime", starttime);
        paramaterMap.put("endtime", endtime);
        String page = "1";
        paramaterMap.put("page", page);
        String num = "500";
        paramaterMap.put("num", num);
        String gameCode = "65";
        paramaterMap.put("gameCode", gameCode);
        String key = MD5.md5Encoding("12").toUpperCase();
        paramaterMap.put("key", key);
        AbstractHandle handle = new NETENTOrderHandle();


        String result = handle.retrieveData(baseUrl, paramaterMap);
        //String result="<Data Page=\"1\" PageLimit=\"20\" TotalNumber=\"2\" TotalPage=\"1\" sattus=\"0\" desc=\"\"  > <Record>       <amount>0.02</amount>        <bonusAmount>0</bonusAmount>        <createdDate>2017-09-27 13:40:10</createdDate>        <currency>CNY</currency>        <currentbalance>8826.18</currentbalance>        <gameCode>52</gameCode>        <gameTypeid>53</gameTypeid>        <gameid>53</gameid>        <gamesessionid>png_session_1</gamesessionid>        <isfreegame>1</isfreegame>        <loginname>A02crndtest</loginname>        <previousbalance>8826.2</previousbalance>        <productid>A02</productid>        <remark>VIP</remark>        <requestid>43211</requestid>        <requesttype>700</requesttype>        <roundid>87654322</roundid>        <transactionid>323</transactionid>    </Record>   <Record>       <amount>0.02</amount>        <bonusAmount>0</bonusAmount>        <createdDate>2017-09-27 13:40:46</createdDate>        <currency>CNY</currency>        <currentbalance>8826.2</currentbalance>        <gameCode>52</gameCode>        <isfreegame>1</isfreegame>        <loginname>A02crndtest</loginname>        <previousbalance>8826.18</previousbalance>        <productid>A02</productid>        <requestid>43211</requestid>        <requesttype>702</requesttype>        <roundid>87654322</roundid>        <transactionid>324</transactionid>    </Record>  <Record>       <amount>0.22</amount>        <bonusAmount>0</bonusAmount>        <createdDate>2017-09-27 13:40:46</createdDate>        <currency>CNY</currency>        <currentbalance>8826.2</currentbalance>        <gameCode>52</gameCode>        <isfreegame>1</isfreegame>        <loginname>A02crndtest</loginname>        <previousbalance>8826.18</previousbalance>        <productid>A02</productid>        <requestid>43212</requestid>        <requesttype>700</requesttype>        <roundid>87654323</roundid>        <transactionid>324</transactionid>    </Record> <Record>       <amount>0.44</amount>        <bonusAmount>0</bonusAmount>        <createdDate>2017-09-27 13:40:46</createdDate>        <currency>CNY</currency>        <currentbalance>8826.2</currentbalance>        <gameCode>52</gameCode>        <isfreegame>1</isfreegame>        <loginname>A02crndtest</loginname>        <previousbalance>8826.18</previousbalance>        <productid>A02</productid>        <requestid>43212</requestid>        <requesttype>710</requesttype>        <roundid>87654323</roundid>        <transactionid>324</transactionid>    </Record>   </Data>";
        System.out.println(result);
        List<Object> orderLit = handle.parse(result).getOrderList();
        System.out.println(orderLit);

        String confDir = File.separator + System.getProperty("user.dir") + File.separator + "conf";
        FileSystemXmlApplicationContext factory = new FileSystemXmlApplicationContext(confDir + "/spring/applicationContext.xml");
        OrderDao orderDao = (OrderDao) factory.getBean("orderDao");
        AllocationDao allocationDao = (AllocationDao) factory.getBean("allocationDao");
        SqlSessionFactory myBatisSessionFactory = (SqlSessionFactory) factory.getBean("myBatisSessionFactory");
        SqlSession session = myBatisSessionFactory.openSession();
//		ToolUtil.initSpecialGames(productid,"065", allocationDao);

        orderDao.insertOrder4NETENT(orderLit, session, false, "2018-04-10 10:10:10");


    }

    public void parseRules(Digester d) {
        d.addObjectCreate("Data", OrderRes.class);
        d.addSetProperties("Data", "sattus", "code");
        d.addSetProperties("Data", "desc", "comment");
        d.addSetProperties("Data", "Page", "numpage");
        d.addSetProperties("Data", "PageLimit", "perpage");
        d.addSetProperties("Data", "TotalNumber", "total");
        d.addSetProperties("Data", "TotalPage", "totalPages");
        d.addObjectCreate("Data/Record", OrderEntity.class);
        d.addSetNext("Data/Record", "addOrder");
        d.addBeanPropertySetter("Data/Record/transactionid", "billNo");
        d.addBeanPropertySetter("Data/Record/previousbalance", "previosAmount");
        d.addBeanPropertySetter("Data/Record/currentbalance", "currentAmount");
        d.addBeanPropertySetter("Data/Record/transactionSubtypeid", "playType");
        d.addBeanPropertySetter("0", "bonusAmount");
        //d.addCallMethod("Data/Record/amount", "setBetSoftBetAmount",1);
        //d.addCallParam("Data/Record/Amount", 0);
        d.addBeanPropertySetter("Data/Record/amount", "account");
        d.addBeanPropertySetter("Data/Record/amount", "validAccount");
        d.addBeanPropertySetter("Data/Record/gameid", "round");
        d.addBeanPropertySetter("Data/Record/gameid", "gmCode");
        d.addBeanPropertySetter("Data/Record/gameTypeid", "gameType");
        d.addBeanPropertySetter("Data/Record/currency", "currency");
        d.addCallMethod("Data/Record/createdDate", "setTime", 1);
        d.addCallParam("Data/Record/createdDate", 0);
        d.addBeanPropertySetter("Data/Record/productid", "productId");
        //d.addBeanPropertySetter("Data/Record/loginname","loginName");
        d.addCallMethod("Data/Record/loginname", "setLoginNameSubString3", 1);
        d.addCallParam("Data/Record/loginname", 0);
        d.addCallMethod("Data/Record/transactionSubtypeid", "setFlagAccordingRequesttype", 1);
        d.addCallParam("Data/Record/transactionSubtypeid", 0);
    }

    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        // TODO Auto-generated method stub
        return null;
    }

}
