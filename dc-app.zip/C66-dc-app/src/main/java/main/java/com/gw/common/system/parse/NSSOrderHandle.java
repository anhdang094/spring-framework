package main.java.com.gw.common.system.parse;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.CurrencyType;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.constant.UtilConstants.GAME_KIND_ENUM;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.common.framework.util.JsonUtil;
import main.java.com.gw.common.framework.util.ObjectConstructUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.parse.vo.Result;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.lang3.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

/**
 * NSS 订单拉取处理实现
 *
 * @author Ricardo.X
 */
@Slf4j
public class NSSOrderHandle extends AbstractHandle {

    private NSSOrderHandle() {
    }

    private static final class Instance {

        public static final NSSOrderHandle instance = new NSSOrderHandle();

    }

    /**
     * NSS 订单日期格式
     */
    public static final String NSS_DATE_FORMAT = "MM/dd/yyyy hh:mm:ss a";

    public static final String NSS_RESP_SUCCESS = "0";

    /// XXX -->> 添加URL参数组装逻辑 >>> [空实现]
    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        return null;
    }

    /// XXX -->> 添加订单数据拉取逻辑

    /**
     * paramaterMap --> OrderServiceImpl 调用传入
     */
    @Override
    public String retrieveData(String url, Map<String, Object> paramaterMap) throws GWCallRemoteApiException {

        String responseXML = null;

        try {
            responseXML = new HttpUtil().doPost(url, paramaterMap);
        } catch (Exception e) {
            String message = " >> NSS --> 在拉取投注記錄時發生異常! 請求URL[" + url + "] - 參數[" + JsonUtil.toJSONString(paramaterMap) + "]";
            log.error(message, e);
            throw new GWCallRemoteApiException(message, e);
        }

        return responseXML;
    }


    @Override
    public Result parse(String xml) throws GWCallRemoteApiException {

        Result result = null;

        try {
            result = this.nssXmlParseLogic(xml);
        } catch (Exception e) {
            log.error(" >> NSS -->> 订单拉取解析异常! 本次拉取的返回内容为:[" + xml + "]", e);
            throw e;
        }

        return result;
    }


    /***
     * 进行时区的转换
     * @param result
     * @param zoneIdStr
     * @return
     */
    public Result convertTimeZone(Result result, String zoneIdStr) {

        ToolUtil.convertOrderTimeZome(result.getOrderList(), zoneIdStr);

        return result;
    }


    /**
     * 进行币种的比例转换
     *
     * @param result
     * @param ratio
     * @return
     */
    public Result convertCurrencyRatio(Result result, BigDecimal ratio) {

        ToolUtil.convertCurrencyRatio(result.getOrderList(), ratio);

        return result;
    }


    /**
     * XML Parse to Result Object, It's may throw a exception in case content not expect format.
     *
     * @param xmlStr
     * @return
     */
    private Result nssXmlParseLogic(String xmlStr) {

        Document xmlDocument = Jsoup.parse(xmlStr);

        Result result = new Result();

        String code = this.getElementText(xmlDocument, "status_code");
        String msg = this.getElementText(xmlDocument, "status_text");

        if (!NSS_RESP_SUCCESS.equals(code)) {
            return result;
        }

        result.setCode(code);
        result.setComment(msg);
        result.setTotal(Integer.parseInt(this.getElementText(xmlDocument, "trans_count")));

        Elements orderElements = xmlDocument.select("row");

        for (Element orderElement : orderElements) {
            result.addOrder(this.xml2OrderMappingParse(orderElement));
        }

        return result;
    }


    /**
     * XML info parse each order object
     *
     * @param jsoupNode
     * @return
     */
    private OrderEntity xml2OrderMappingParse(Element jsoupNode) {

        OrderEntity order = new OrderEntity();

        // 游戏提供方的订单编号
        String trancId = this.getElementText(jsoupNode, "trans_id");
        if (StringUtils.isEmpty(trancId)) {
            // 未取得order id 在这里结束流程, 否则在入库时也会异常
            throw new RuntimeException(" >> NSS --> unable to get orderId from xml!");
        }
        order.setBillNo(trancId);


        // 下单时间 // billTime orignalBillTime  setTime
        String orderTime = this.getElementText(jsoupNode, "transaction_time");
        Date d = DateUtil.formatStr2Date(orderTime, NSS_DATE_FORMAT, Locale.ENGLISH);
        order.time(d);

        // 用户名
        String userName = this.getElementText(jsoupNode, "member_id");
        order.setLoginName(userName);


        // 体育编号，改为赛事局号 modified by ziv 2018-02-15
//		String sportType = this.getElementText(jsoupNode, "sports_type");
        String matchId = this.getElementText(jsoupNode, "match_id");
        order.setGmCode(matchId);

        // 玩法 playType
        String playType = this.getElementText(jsoupNode, "odds_type");
        if (StringUtils.isNumeric(playType)) {
            order.setPlayType(Integer.parseInt(playType));
        } else {
            order.setPlayType(-1);
        }

        //设置赔率及盘口
        order.setOddsType(playType);
        String odds = this.getElementText(jsoupNode, "odds");
        if (odds != null) {
            order.setOdds(new BigDecimal(odds));
        } else {
            order.setOdds(BigDecimal.ONE);
        }


        // 币种
        String currency = this.getElementText(jsoupNode, "currency");

        if (currency != null) {
            order.setCurrency(currency);
            order.setCurrencyType(CurrencyType.getCurrency(currency).getCurrencyCode());
        }

        // 桌号 或者 体育赛事ID
//		String tableCode = this.getElementText(jsoupNode, "match_id");
//		order.setTableCode(tableCode);


        // 体育名称
        String gameName = this.getElementText(jsoupNode, "sportname");
        order.setGameType(gameName);

        // 开赛时间
        String winlostDatetimeStr = this.getElementText(jsoupNode, "winlost_datetime");//修改为结算时间 modified by ziv 2018-09-10
        if (StringUtils.isNotBlank(winlostDatetimeStr)) {
            Date winlostDatetime = DateUtil.formatStr2Date(winlostDatetimeStr, NSS_DATE_FORMAT, Locale.ENGLISH);
            order.setReckonTime(winlostDatetime);
        }

        // 设备类型
        String drviceType = this.getElementText(jsoupNode, "txn_type");
        order.setDeviceType(drviceType.equalsIgnoreCase("int") ? "0" : "1");


        // 游戏类型
        order.setGameKind(GAME_KIND_ENUM.BALL.getCode());

        String homeTeamName = this.getElementText(jsoupNode, "homename");
        String awayTeamName = this.getElementText(jsoupNode, "awayname");

        order.setHomeTeam(homeTeamName);
        order.setAwayTeam(awayTeamName);

        // 注额
        String amount = this.getElementText(jsoupNode, "stake");
        // 投注额
        order.setAccount(new BigDecimal(amount));

        // 输赢金额 (输赢度字段)
        String winLost = this.getElementText(jsoupNode, "winlost_amount");
        BigDecimal winLostAmount = new BigDecimal(winLost);
        order.setCusAccount(winLostAmount);
        order.setPlatId(UtilConstants.NSS);

        order.setBonusAmount(BigDecimal.ZERO);
        order.setValidAccount(new BigDecimal(amount));

        //NSS输赢结果 add by Ziv.Y 2017-11-11
        String winOrLost = this.getElementText(jsoupNode, "winlost_status");
        if (StringUtils.isNotBlank(winOrLost)) {
            winOrLost = winOrLost.trim();
            winOrLost = winOrLost.toUpperCase();
        } else {
            winOrLost = this.getElementText(jsoupNode, "ticket_status");
            winOrLost = StringUtils.isBlank(winOrLost) ? StringUtils.EMPTY : winOrLost.toUpperCase();
        }
        order.setResultNSS(winOrLost);
        // 状态
        //String flag = this.getElementText(jsoupNode, "ticket_status");
        order.setResult(winOrLost);
        order.setFlag(this.flagParse(winOrLost));

        ObjectConstructUtil.calculateValidAndRemainAmountForSportGame(order);
        return order;
    }


    private int flagParse(String status) {
        if (StringUtils.isBlank(status)) {
            return 0;
        }
        switch (status.toLowerCase()) {
            case "void":
                return -9; // 订单取消
            case "processed":
                return 1; //已经处理
            case "draw":
                return 1;  // 和局, 但是订单已经结算
            case "w":
                return 1; //
            case "l":
                return 1;
            case "d":
                return 1;
            case "wh":
                return 1;
            case "lh":
                return 1;
            case "p":
                return 0;
            case "c":
                return -9; // 订单取消
            case "lost_half":
                return 1; //
            case "open":
                return 0;
            case "postponed":
                return 0; // 赛事延期, 已经下注,但是延期, 订单未结算
        }
        return 0;
    }


    /**
     * take the first dom element tag content
     *
     * @param jsoupNode
     * @param tagName
     * @return
     */
    private String getElementText(Element jsoupNode, String tagName) {

        Elements elements = jsoupNode.getElementsByTag(tagName);

        if (elements.size() != 1) {
            throw new RuntimeException(" >> NSS -->> Elements count not a expect value, expect is only one, but got : [" + elements.size() + "]");
        }
        return elements.get(0).text();
    }


    public static NSSOrderHandle getInstance() {
        return Instance.instance;
    }

    public enum TTC {
        tt(1),
        cc(2),;
        public int i;

        TTC(int q) {
            i = q;
        }
    }


}