package main.java.com.gw.common.system.parse;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.common.system.parse.vo.OrderRes;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.digester3.Digester;
import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@Slf4j
public class OpusOrderHandle extends AbstractHandle {

    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        return null;
    }

    @Override
    public String retrieveData(String url, Map<String, Object> paramaterMap) throws GWCallRemoteApiException {
        String content = "";
        try {
            content = new HttpUtil().httpGet(url, paramaterMap);
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new GWCallRemoteApiException("Failed to call remote interface!" + ex.getMessage(), ex);
        }
        return content;
    }

    public static void main(String[] args) {
        Map<String, Object> paramaterMap = new HashMap<String, Object>();
        // paramaterMap.put("baseUrl", "http://api.uat01.mansion888.com/TransactionDetail.API?");
        paramaterMap.put("baseUrl", "http://api.mansion888.net/TransactionDetail.API?");
        // secret_key:862B05FA0F62
        // OperatorID: C558A243-E109-4089-9C70-3F85D108DAC9
        // SiteCode: AG8
        // Product code: mcasino

        paramaterMap.put("start_time", "2015-03-16 19:15:00");
        paramaterMap.put("end_time", "2015-03-16 19:30:00");
        paramaterMap.put("secret_key", "862B05FA0F62");
        paramaterMap.put("operator_id", "C558A243-E109-4089-9C70-3F85D108DAC9");
        paramaterMap.put("site_code", "AG8");
        paramaterMap.put("product_code", "mcasino");
        // paramaterMap.put("secret_key", "aa");
        // paramaterMap.put("operator_id", "C558A243-E109-4089-9C70-3F85D108DAC9");
        // paramaterMap.put("site_code", "AG8");
        // paramaterMap.put("product_code", "mcasino");

        AbstractHandle handle = new OpusOrderHandle();
        try {
            String result = handle.retrieveData(paramaterMap.get("baseUrl").toString(), paramaterMap);
            // result = result.replace("", "");
            System.out.println(result);
            System.out.println(handle.parse(result).getOrderList());
        } catch (GWCallRemoteApiException e) {
            e.printStackTrace();
        }
    }

    public void parseRules(Digester d) {
        d.addObjectCreate("Transaction_Detail", OrderRes.class);
        d.addBeanPropertySetter("Transaction_Detail/status_code", "returnCode");
        d.addBeanPropertySetter("Transaction_Detail/status_text", "comment");
        d.addBeanPropertySetter("Transaction_Detail/trans_count", "total");
        // d.addBeanPropertySetter("status");
        d.addObjectCreate("Transaction_Detail/bets/row", OrderEntity.class);
        d.addSetNext("Transaction_Detail/bets/row", "addOrder");

        d.addCallMethod("Transaction_Detail/bets/row/transaction_date_time", "setTime", 1);
        d.addCallParam("Transaction_Detail/bets/row/transaction_date_time", 0);

        // d.addBeanPropertySetter("Transaction_Detail/bets/row/stamp_date", "orignalReckonTime");

        d.addBeanPropertySetter("Transaction_Detail/bets/row/member_code", "loginName");

        d.addBeanPropertySetter("Transaction_Detail/bets/row/bet_record_id", "billNo");
        d.addBeanPropertySetter("Transaction_Detail/bets/row/transaction_id", "gmCode");
        d.addBeanPropertySetter("Transaction_Detail/bets/row/bet", "account");
        d.addBeanPropertySetter("Transaction_Detail/bets/row/win", "cusAccount");// cusAccount-validAccount
        d.addBeanPropertySetter("Transaction_Detail/bets/row/bet", "validAccount");
        d.addBeanPropertySetter("Transaction_Detail/bets/row/currency", "currency");
        d.addBeanPropertySetter("Transaction_Detail/bets/row/balance_start", "previosAmount");

        // B7 = Baccarat 7Up
        // Ba = Baccarat
        // Bj = Black Jack
        // Dc = Sicbo
        // Dt = Dragon & Tiger
        // L3 = Live 3D
        // Pk = Texas Holdem
        // Ro = Roulette
        // Tp = Three Pictures
        d.addBeanPropertySetter("Transaction_Detail/bets/row/game_detail", "gameType");// 游戏种类

        // CTXM,gameKind=5
        // Casino,gameKind=3
        d.addBeanPropertySetter("Transaction_Detail/bets/row/vendor", "remark");

    }

    /**
     * @Description: 查询OPUS一天总投注额
     * @Author: Ziv.Y
     * @Date: 2018/7/26 11:47
     */
    public BigDecimal getTotalBetAmount(Map<String, Object> paramaterMap) throws Exception {
        BigDecimal totalBets = BigDecimal.ZERO;
        try {
            Map<String, Object> paramMapTemp = new HashMap<>();
            paramMapTemp.put("secret_key", paramaterMap.get("password"));
            paramMapTemp.put("operator_id", ((String) paramaterMap.get("agcode")).split("_")[1]);
            paramMapTemp.put("site_code", paramaterMap.get("username"));
            paramMapTemp.put("product_code", paramaterMap.get("website"));
            paramMapTemp.put("checkdate", paramaterMap.get("endtime").toString().substring(0, 10));
            log.info("getTotalBetAmount paramMapTemp:" + paramMapTemp);
            String responseXml = retrieveData((String) paramaterMap.get(UtilConstants.ORDER_BASE_URL), paramMapTemp);
//            String responseXml = "<?xml version=\"1.0\" ?><Transaction_Total><status_code>00</status_code><status_text>SUCCESS</status_text><trans_count>1</trans_count><datetime>2018-07-25 17:57:23</datetime><report name=\"data+checking\"><row currency=\"RMB\"><currency>RMB</currency><datestamp>2018-07-21</datestamp><stake_amount>339.00</stake_amount><winlose_amount>-15.95</winlose_amount><total_txn>27</total_txn></row></report></Transaction_Total>";
//            String responseXml = "<?xml version=\"1.0\" ?><transaction_total><status_code>20.01</status_code><status_text>ERR_CREATE_REPORT</status_text><currency></currency><datestamp></datestamp><stake_amount></stake_amount><winlose_amount></winlose_amount><total_txn></total_txn><datetime>2018-08-02 14:37:07</datetime></transaction_total>";
            log.info("getTotalBetAmount responseXml:" + responseXml);
            if (StringUtils.isNotBlank(responseXml)) {
                Document balanceXml = DocumentHelper.parseText(responseXml);
                Element rootElement = balanceXml.getRootElement();
                String statusCode = rootElement.element("status_code").getText();
                if ("20.01".equals(statusCode)) {
                    totalBets = BigDecimal.ZERO;//20.01表示厅方没有查到注单记录
                } else if ("00".equals(statusCode)) {
                    Element element = ((Element) (rootElement.element("report").elements("row").get(0))).element("stake_amount");
                    String balanceStr = element.getText();
                    totalBets = new BigDecimal(balanceStr);
                } else {
                    throw new Exception("OPUS厅方查询总投注额内部错误");
                }
            }
        } catch (Exception e) {
            log.error("getTotalBetAmount error", e);
            throw e;
        }
        return totalBets;
    }
}
