package main.java.com.gw.common.system.parse;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.*;
import main.java.com.gw.common.system.entity.PBOrderEntity;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Slf4j
public class PBOrderHandle {

    private static final Gson gson = new Gson();
    private static final SimpleDateFormat dateFormat = dateFormat();
    private static SimpleDateFormat dateFormat (){
        SimpleDateFormat dateFormat = new SimpleDateFormat(DateUtil.C_TIME_PATTON_DEFAULT);
        dateFormat.setTimeZone(TimeZone.getTimeZone("GMT-4:00")); // 厅方时区
        return dateFormat;
    }

    public static void main(String[] args) throws IOException {
        String loginname = "aga13qcon";
        String s1 = loginname.substring(0, 5);
        System.out.println(loginname.substring(5));

//        Map<String, Object> parameterMap = new HashMap<>();
//        parameterMap.put("password", "PSC34;6c9e222b-9001-46fc-91be-8ffd8a7350b7;bNAPnwXOU8KQQb2d");
//        parameterMap.put("userCode", "PSC34");
//        parameterMap.put("dateFrom", "2020-03-04 04:56:34");
//        parameterMap.put("dateTo", "2020-03-04 06:56:34");
//        parameterMap.put("filterBy", "update_date");
//        parameterMap.put(UtilConstants.ORDER_TASK_ID, "9201");
//        List<OrderEntity> orderEntityList = new PBOrderHandle().getPBOrderRecord("", parameterMap);
//        System.out.println(orderEntityList);
    }

    public List<OrderEntity> getPBOrderRecord(String url, Map<String, Object> parameterMap) throws IOException {
        log.info("trying to getPBOrderRecord, url: {}", url);
        List<OrderEntity> list = new ArrayList<>();

        Map<String, String> headers = new HashMap<>();
        String[] pbParam = ((String) parameterMap.get("password")).split(";");
        String agentCode = pbParam[0];
        String agentKey = pbParam[1];
        String aesKey = pbParam[2];
        String token = PBSignature.encode(agentCode, String.valueOf(System.currentTimeMillis()), agentKey, aesKey);
        headers.put("userCode", agentCode);
        headers.put("token", token);

        Map<String, String> requestParams = new HashMap<>();
        requestParams.put("dateFrom", (String) parameterMap.get("begintime"));
        requestParams.put("dateTo", (String) parameterMap.get("endtime"));
        requestParams.put("filterBy", "update_date");

        String result = HttpClientUtils.execGetWithHeader(url, requestParams, headers);
//        String result = "[{\"wagerId\":39034400,\"eventName\":\"密尔沃基雄鹿队 -vs- 印地安纳步行者队\",\"parentEventName\":null,\"headToHead\":null,\"wagerDateFm\":\"2020-03-04 04:56:34\",\"eventDateFm\":\"2020-03-04 20:05:00\",\"settleDateFm\":null,\"status\":\"OPEN\",\"homeTeam\":\"密尔沃基雄鹿队\",\"awayTeam\":\"印地安纳步行者队\",\"selection\":\"密尔沃基雄鹿队\",\"handicap\":0.00,\"odds\":1.177,\"oddsFormat\":1,\"betType\":1,\"league\":\"NBA\",\"leagueId\":487,\"stake\":10.00,\"sportId\":4,\"sport\":\"篮球\",\"currencyCode\":\"CNY\",\"inplayScore\":\"\",\"inPlay\":false,\"homePitcher\":null,\"awayPitcher\":null,\"homePitcherName\":null,\"awayPitcherName\":null,\"period\":0,\"cancellationStatus\":null,\"parlaySelections\":[],\"category\":null,\"toWin\":1.7700000,\"toRisk\":10.0000000,\"product\":\"SB\",\"parlayMixOdds\":1.1770000,\"competitors\":[],\"userCode\":\"PSC3400002\",\"loginId\":\"A04.mtestpb004\",\"scores\":[],\"result\":null,\"winLoss\":0.00,\"turnover\":0.00},{\"wagerId\":39034366,\"eventName\":\"Ignis -vs- Aim4R hasteka\",\"parentEventName\":null,\"headToHead\":null,\"wagerDateFm\":\"2020-03-04 04:53:04\",\"eventDateFm\":\"2020-03-04 05:00:00\",\"settleDateFm\":null,\"status\":\"OPEN\",\"homeTeam\":\"Ignis\",\"awayTeam\":\"Aim4R hasteka\",\"selection\":\"Ignis\",\"handicap\":0.00,\"odds\":1.225,\"oddsFormat\":1,\"betType\":1,\"league\":\"CS:GO - Asia Minor Rio East Asia Qualifier\",\"leagueId\":208214,\"stake\":10.00,\"sportId\":12,\"sport\":\"电子竞技\",\"currencyCode\":\"CNY\",\"inplayScore\":\"\",\"inPlay\":false,\"homePitcher\":null,\"awayPitcher\":null,\"homePitcherName\":null,\"awayPitcherName\":null,\"period\":1,\"cancellationStatus\":null,\"parlaySelections\":[],\"category\":null,\"toWin\":2.2500000,\"toRisk\":10.0000000,\"product\":\"SB\",\"parlayMixOdds\":1.2250000,\"competitors\":[],\"userCode\":\"PSC3400002\",\"loginId\":\"A04.mtestpb004\",\"scores\":[],\"result\":null,\"winLoss\":0.00,\"turnover\":0.00},{\"wagerId\":39034367,\"eventName\":\"D13 -vs- MVP PK战队\",\"parentEventName\":null,\"headToHead\":null,\"wagerDateFm\":\"2020-03-04 04:53:04\",\"eventDateFm\":\"2020-03-04 05:00:00\",\"settleDateFm\":null,\"status\":\"OPEN\",\"homeTeam\":\"D13\",\"awayTeam\":\"MVP PK战队\",\"selection\":\"MVP PK战队\",\"handicap\":0.00,\"odds\":1.787,\"oddsFormat\":1,\"betType\":1,\"league\":\"CS:GO - Asia Minor Rio East Asia Qualifier\",\"leagueId\":208214,\"stake\":10.00,\"sportId\":12,\"sport\":\"电子竞技\",\"currencyCode\":\"CNY\",\"inplayScore\":\"\",\"inPlay\":false,\"homePitcher\":null,\"awayPitcher\":null,\"homePitcherName\":null,\"awayPitcherName\":null,\"period\":3,\"cancellationStatus\":null,\"parlaySelections\":[],\"category\":null,\"toWin\":7.8700000,\"toRisk\":10.0000000,\"product\":\"SB\",\"parlayMixOdds\":1.7870000,\"competitors\":[],\"userCode\":\"PSC3400002\",\"loginId\":\"A04.mtestpb004\",\"scores\":[],\"result\":null,\"winLoss\":0.00,\"turnover\":0.00},{\"wagerId\":39034357,\"eventName\":\"Ignis -vs- Aim4R hasteka\",\"parentEventName\":null,\"headToHead\":null,\"wagerDateFm\":\"2020-03-04 04:52:38\",\"eventDateFm\":\"2020-03-04 05:00:00\",\"settleDateFm\":null,\"status\":\"OPEN\",\"homeTeam\":\"Ignis\",\"awayTeam\":\"Aim4R hasteka\",\"selection\":\"Ignis\",\"handicap\":0.00,\"odds\":1.162,\"oddsFormat\":1,\"betType\":1,\"league\":\"CS:GO - Asia Minor Rio East Asia Qualifier\",\"leagueId\":208214,\"stake\":1.00,\"sportId\":12,\"sport\":\"电子竞技\",\"currencyCode\":\"CNY\",\"inplayScore\":\"\",\"inPlay\":false,\"homePitcher\":null,\"awayPitcher\":null,\"homePitcherName\":null,\"awayPitcherName\":null,\"period\":0,\"cancellationStatus\":null,\"parlaySelections\":[],\"category\":null,\"toWin\":0.1600000,\"toRisk\":1.0000000,\"product\":\"SB\",\"parlayMixOdds\":1.1620000,\"competitors\":[],\"userCode\":\"PSC3400002\",\"loginId\":\"A04.mtestpb004\",\"scores\":[],\"result\":null,\"winLoss\":0.00,\"turnover\":0.00},{\"wagerId\":39034358,\"eventName\":\"D13 -vs- MVP PK战队\",\"parentEventName\":null,\"headToHead\":null,\"wagerDateFm\":\"2020-03-04 04:52:38\",\"eventDateFm\":\"2020-03-04 05:00:00\",\"settleDateFm\":null,\"status\":\"OPEN\",\"homeTeam\":\"D13\",\"awayTeam\":\"MVP PK战队\",\"selection\":\"D13\",\"handicap\":0.00,\"odds\":2.190,\"oddsFormat\":1,\"betType\":1,\"league\":\"CS:GO - Asia Minor Rio East Asia Qualifier\",\"leagueId\":208214,\"stake\":10.00,\"sportId\":12,\"sport\":\"电子竞技\",\"currencyCode\":\"CNY\",\"inplayScore\":\"\",\"inPlay\":false,\"homePitcher\":null,\"awayPitcher\":null,\"homePitcherName\":null,\"awayPitcherName\":null,\"period\":1,\"cancellationStatus\":null,\"parlaySelections\":[],\"category\":null,\"toWin\":11.9000000,\"toRisk\":10.0000000,\"product\":\"SB\",\"parlayMixOdds\":2.1900000,\"competitors\":[],\"userCode\":\"PSC3400002\",\"loginId\":\"A04.mtestpb004\",\"scores\":[],\"result\":null,\"winLoss\":0.00,\"turnover\":0.00},{\"wagerId\":39034353,\"eventName\":\"D13 -vs- MVP PK战队\",\"parentEventName\":null,\"headToHead\":null,\"wagerDateFm\":\"2020-03-04 04:52:18\",\"eventDateFm\":\"2020-03-04 05:00:00\",\"settleDateFm\":null,\"status\":\"OPEN\",\"homeTeam\":\"D13\",\"awayTeam\":\"MVP PK战队\",\"selection\":\"MVP PK战队\",\"handicap\":0.00,\"odds\":1.662,\"oddsFormat\":1,\"betType\":1,\"league\":\"CS:GO - Asia Minor Rio East Asia Qualifier\",\"leagueId\":208214,\"stake\":10.00,\"sportId\":12,\"sport\":\"电子竞技\",\"currencyCode\":\"CNY\",\"inplayScore\":\"\",\"inPlay\":false,\"homePitcher\":null,\"awayPitcher\":null,\"homePitcherName\":null,\"awayPitcherName\":null,\"period\":0,\"cancellationStatus\":null,\"parlaySelections\":[],\"category\":null,\"toWin\":6.6200000,\"toRisk\":10.0000000,\"product\":\"SB\",\"parlayMixOdds\":1.6620000,\"competitors\":[],\"userCode\":\"PSC3400002\",\"loginId\":\"A04.mtestpb004\",\"scores\":[],\"result\":null,\"winLoss\":0.00,\"turnover\":0.00}]";
        // Add interception to retrieve Response
        if (ToolUtil.isNeedInterceptResponse(parameterMap.get(UtilConstants.ORDER_TASK_ID) + "")) {
            log.info("Intercept:TaskId=" + parameterMap.get(UtilConstants.ORDER_TASK_ID) + ",Url=" + url + ",Response=" + result);
        }
        if (StringUtils.isEmpty(result)) {
            log.info("getPBOrderRecord pb log, response no data, request params:" + parameterMap);
            return list;
        }
        log.info(">> PB >> get pb order record,Url[" + url + "], result:" + result);
        List<PBOrderEntity> pbOrderEntityList = gson.fromJson(result, new TypeToken<List<PBOrderEntity>>(){}.getType());

        if (pbOrderEntityList == null || pbOrderEntityList.isEmpty()) {
            return list;
        }
        pbOrderEntityList.forEach(pbOrderEntity -> {
            String loginId = pbOrderEntity.getLoginId();
            if (StringUtils.isBlank(loginId)) {
                log.error("getPBOrderRecord pb log, found data no name, data str[{}]", pbOrderEntity);
                return;
            }
            String productId = loginId.split("\\.")[0];
            String loginname = loginId.split("\\.")[1];
            pbOrderEntity.setProductId(productId);
            pbOrderEntity.setLoginname(loginname);
            pbOrderEntity.setOddsFormat(this.convertOddType(pbOrderEntity.getOddsFormat()));
            /**PBOrderEntity转OrderEntity*/
            OrderEntity orderEntityTemp = transferEntityForPB(pbOrderEntity);
            orderEntityTemp.setOrignalTimezone((String) parameterMap.get(UtilConstants.NSS_TIMEZONE));
            //洗码投注额计算
            ObjectConstructUtil.calculateValidAndRemainAmountForSportGame(orderEntityTemp);
            list.add(orderEntityTemp);
        });
        return list;
    }

    private static OrderEntity transferEntityForPB(PBOrderEntity entity) {
        if (entity == null) {
            return null;
        }
        OrderEntity o = new OrderEntity();
        o.setProductId(entity.getProductId());
        o.setPlatId(UtilConstants.PB);
        o.setLoginName(entity.getLoginname());
        o.setBillNo(entity.getWagerId());

        String wagerDate = entity.getWagerDateFm();
        o.setBillTime(transferDate(wagerDate));
        o.setOrignalBillTime(DateUtil.formatStr2Date(entity.getWagerDateFm()));
        if (StringUtils.isNotBlank(entity.getSettleDateFm())){
            o.setReckonTime(transferDate(entity.getSettleDateFm()));
            o.setOrignalReckonTime(DateUtil.formatStr2Date(entity.getSettleDateFm()));
        }
//        o.setOrignalTimezone("");
        o.setCreationDate(new Date());

        o.setAccount(new BigDecimal(entity.getStake()));
        o.setOdds(new BigDecimal(entity.getOdds()).setScale(2, RoundingMode.HALF_UP));
        o.setOddsType(entity.getOddsFormat());
        o.setPlayType(Integer.parseInt(entity.getBetType()));
        o.setGmCode(entity.getWagerId());
        if (StringUtils.isBlank(entity.getSport())){
            o.setGameType("Mix");
        } else {
            o.setGameType(entity.getSport());
        }
        if (Objects.equals("PENDING", entity.getStatus()) || Objects.equals("OPEN", entity.getStatus())){
            o.setFlag(0);
            o.setValidAccount(BigDecimal.ZERO);
        } else if (Objects.equals("SETTLED", entity.getStatus())){
            o.setFlag(1);
            o.setValidAccount(new BigDecimal(entity.getStake()));
            if (Objects.equals("DRAW", entity.getResult())){
                o.setCusAccount(BigDecimal.ZERO);
                o.setResult("Tie");
            } else {
                o.setCusAccount(new BigDecimal(entity.getWinLoss()));
            }
        } else if (Objects.equals("CANCELLED", entity.getStatus()) || Objects.equals("DELETED", entity.getStatus())){
            o.setFlag(-9);
            o.setValidAccount(BigDecimal.ZERO);
        } else {
            //正常不会走这个分支
            o.setFlag(0);
            o.setValidAccount(new BigDecimal(0));
        }
        o.setGameKind(UtilConstants.GAME_KIND_ENUM.BALL.getCode());
        o.setDeviceType("0");
        return o;
    }

    private static Date transferDate (String date){
        try {
            return new Date(dateFormat.parse(date).getTime());
        } catch (ParseException e) {
            log.error("pbOrderHandler parse time error!!!!");
            return null;
        }
    }

    /**
     * 轉換pb的盤口代碼為DC的盤口代碼，for DC-API(ObjectConstructUtil.washIndonesiaForSportGame)的洗碼公用API判斷
     */
    private String convertOddType(String oddsFormat) {
        switch (oddsFormat) {
            case "0":
                return UtilConstants.OddsTypeEnum.AMERICAN.getValueStr();
            case "1":
                return UtilConstants.OddsTypeEnum.DECIMAL.getValueStr();
            case "2":
                return UtilConstants.OddsTypeEnum.HK.getValueStr();
            case "3":
                return UtilConstants.OddsTypeEnum.SHABA_INDO.getValueStr();
            case "4":
                return UtilConstants.OddsTypeEnum.MALAY.getValueStr();
            default:
                return UtilConstants.OddsTypeEnum.MP.getValueStr();
        }
    }

//    public List<OrderEntity> getPBOrderRecord(String url, Map<String, Object> parameterMap) throws IOException {
//        HttpUtil https = new HttpUtil();
//        List<OrderEntity> list = new ArrayList<>();
//        String result = "";
//        result = http.doPost(url, parameterMap);
////        result = "{\"code\":\"success\",\"data\":[{\"betAmount\":22,\"betDate\":\"2020-02-04T16:29:15\",\"betType\":\"3\",\"currency\":\"CNY\",\"cusAmount\":null,\"flag\":0,\"loginName\":\"tjohnsogood\",\"odds\":1.909,\"oddsType\":\"3\",\"orderNo\":\"725417694\",\"previousAmount\":351.00,\"productId\":\"A04\",\"realSettlementDate\":null,\"settlementDate\":null,\"status\":0,\"type\":\"SINGLE\",\"updatedDate\":\"2020-02-04T16:29:15\",\"userId\":\"A04tjohnsogood\",\"validAmount\":0,\"winAmount\":0}]}";
//        // Add interception to retrieve Response
//        if (ToolUtil.isNeedInterceptResponse(parameterMap.get(UtilConstants.ORDER_TASK_ID) + "")) {
//            log.info("Intercept:TaskId=" + parameterMap.get(UtilConstants.ORDER_TASK_ID) + ",Url=" + url + ",Response=" + result);
//        }
//        if (StringUtils.isEmpty(result)) {
//            log.info("getPBOrderRecord pb log, response no data, request params:" + parameterMap);
//            return list;
//        }
//        log.info(">> PB >> get pb order record,Url[" + url + "], result:" + result);
//        JSONObject object = JSONObject.parseObject(result);
//        JSONArray dataList = object.getJSONArray("data");
//        if (dataList == null || dataList.isEmpty()) {
//            return list;
//        }
//        for (int i = 0; i < dataList.size(); i++) {
//            JSONObject object2 = dataList.getJSONObject(i);
//            PBOrderEntity bean = JSONObject.toJavaObject(object2, PBOrderEntity.class);
//            String name = bean.getUserId();
//            if (StringUtils.isBlank(name)) {
//                log.error("getPBOrderRecord pb log, found data no name, data str[{}]", object2);
//                continue;
//            }
//            String productId = bean.getProductId();
//            String prefix = name.substring(0, productId.length());
//            if (StringUtils.equals(productId, prefix)) {
//                name = name.substring(productId.length());
//                bean.setLoginName(name);
//            }
//            //统一化各个游戏的deviceType在平台这边的定义
//            bean.setOdds(bean.getOdds().setScale(2, RoundingMode.HALF_UP));
//
//            /**PBOrderEntity转OrderEntity*/
//            OrderEntity orderEntityTemp = transferEntityForPB(bean);
//            //洗码投注额计算
//            ObjectConstructUtil.calculateValidAndRemainAmountForSportGame(orderEntityTemp);
//            list.add(orderEntityTemp);
//        }
//        return list;
//    }
//
//    private static OrderEntity transferEntityForPB(PBOrderEntity entity) {
//        if (entity == null) {
//            return null;
//        }
//        OrderEntity o = new OrderEntity();
//        o.setProductId(entity.getProductId());
//        o.setPlatId(UtilConstants.PB);
//        o.setLoginName(entity.getLoginName());
//        o.setBillNo(entity.getOrderNo());
//        o.setBillTime(entity.getBetDate());
//        o.setAccount(entity.getBetAmount());
//        o.setValidAccount(entity.getValidAmount());
//        o.setCusAccount(entity.getCusAmount());
//        o.setGmCode(entity.getOrderNo());
//        o.setGameType(entity.getGameType());
//        o.setGameKind(UtilConstants.GAME_KIND_ENUM.BALL.getCode());
//        o.setDeviceType("0");
//        o.setCurrency(entity.getCurrency());
//        o.setPreviosAmount(entity.getPreviousAmount());
//        o.setFlag(entity.getFlag());
//        if (entity.getFlag() == 1 && (new BigDecimal(BigInteger.ZERO)).compareTo(entity.getCusAmount()) == 0) {
//            //和局，更新游戏结果，洗码时判断使用
//            o.setResult("Tie");
//        }
//        o.setOddsType(entity.getOddsType());
//        o.setOdds(entity.getOdds());
//        o.setCreationDate(entity.getBetDate());
//        o.setReckonTime(entity.getUpdatedDate());
//        o.setPlayType(Integer.parseInt(entity.getPlayType()));
//        return o;
//    }

}
