package main.java.com.gw.common.system.parse;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.*;
import main.java.com.gw.common.system.entity.PBOrderEntity;
import main.java.com.gw.common.system.parse.vo.PBTransferData;
import main.java.com.gw.datacenter.accounttransfer.entity.AccountTransferEntity;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
public class PBTransHandle {

    private static final Gson gson = new Gson();
    private static final SimpleDateFormat dateFormat = dateFormat();
    private static SimpleDateFormat dateFormat (){
        SimpleDateFormat dateFormat = new SimpleDateFormat(DateUtil.C_TIME_PATTON_DEFAULT);
        dateFormat.setTimeZone(TimeZone.getTimeZone("GMT-4:00")); // 厅方时区
        return dateFormat;
    }

    public List<AccountTransferEntity> getPBTransferRecords (String url, Map<String, Object> parameterMap) throws IOException {
        Map<String, String> headers = new HashMap<>();
        String[] pbParam = ((String) parameterMap.get("password")).split(";");
        String agentCode = pbParam[0];
        String agentKey = pbParam[1];
        String aesKey = pbParam[2];
        String token = PBSignature.encode(agentCode, String.valueOf(System.currentTimeMillis()), agentKey, aesKey);
        headers.put("userCode", agentCode);
        headers.put("token", token);

        Map<String, String> requestParams = new HashMap<>();
        requestParams.put("dateFrom", (String) parameterMap.get("begintime"));
        requestParams.put("dateTo", (String) parameterMap.get("endtime"));

        String result = HttpClientUtils.execGetWithHeader(url, requestParams, headers);
        List<PBTransferData> pbTransferDataList = gson.fromJson(result, new TypeToken<List<PBTransferData>>(){}.getType());

        String productId = parameterMap.get("productId").toString();
        String currency = parameterMap.get("currency").toString();
        List<AccountTransferEntity> accountTransferEntityList =  pbTransferDataList.stream().map(pbTransferData -> {
            Date originTransferDate = DateUtil.formatStr2Date(pbTransferData.getTransferDate());
            String loginname = pbTransferData.getLoginId().split("\\.")[1];

            AccountTransferEntity accountTransferEntity = new AccountTransferEntity();
            accountTransferEntity.setTransId(pbTransferData.getUserCode() + "." + originTransferDate.getTime());
            accountTransferEntity.setCreationTime(transferDate(pbTransferData.getTransferDate()));
            accountTransferEntity.setOrignalCreationTime(originTransferDate);
            accountTransferEntity.setProductId(productId);
            accountTransferEntity.setPlatformId(UtilConstants.PB);
            accountTransferEntity.setCurrency(currency);
            accountTransferEntity.setTransferAmount(new BigDecimal(pbTransferData.getAmount()));
            accountTransferEntity.setUserName(loginname);
            if(Objects.equals("DEPOSIT", pbTransferData.getTransferType())){
                accountTransferEntity.setTransferType(UtilConstants.TRANSFER_TYPE_IN);
            } else {
                accountTransferEntity.setTransferType(UtilConstants.TRANSFER_TYPE_OUT);
            }
            return accountTransferEntity;
        }).collect(Collectors.toList());
        return accountTransferEntityList;
    }

    private static Date transferDate (String date){
        try {
            return new Date(dateFormat.parse(date).getTime());
        } catch (ParseException e) {
            log.error("pbOrderHandler parse time error!!!!");
            return null;
        }
    }

    public static void main(String[] args) throws IOException {
        Map<String, Object> parameterMap = new HashMap<>();
        parameterMap.put("password", "PSC34;6c9e222b-9001-46fc-91be-8ffd8a7350b7;bNAPnwXOU8KQQb2d");
        parameterMap.put("userCode", "PSC34");
        parameterMap.put("begintime", "2020-03-02 04:56:34");
        parameterMap.put("endtime", "2020-03-02 06:56:34");
        parameterMap.put("productId", "A04");
        parameterMap.put("currency", "CNY");
        parameterMap.put(UtilConstants.ORDER_TASK_ID, "9201");
        List<AccountTransferEntity> accountTransferEntityList = new PBTransHandle().getPBTransferRecords("https://paapistg.oreo88.com/b2b/report/transactions", parameterMap);
        System.out.println(accountTransferEntityList);
    }

}
