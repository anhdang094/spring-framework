package main.java.com.gw.common.system.parse;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;

/**
 * PG bet records fetch
 *
 * @author Claud
 * @createTime 2021-03-15
 */
@Slf4j
public class PGOrderHandle {


    public static List<OrderEntity> getPGOrderRecord(String url, Map<String, Object> parameterMap) throws IOException, GWCallRemoteApiException {
        Map<String, String> requestParameters = new HashMap<>(5);
        String[] tokenAndKey = parameterMap.get(UtilConstants.ACCOUNT_TRANSFER_AGCODE).toString().split(",");
        String count = parameterMap.get(UtilConstants.ORDER_PAGE_NUMBER).toString();
        String rowVersion = parameterMap.get("rowVersion").toString();
        // Unique identity of operator
        requestParameters.put("operator_token", tokenAndKey[0]);
        // Shared passphrase between PGSoft and operator
        requestParameters.put("secret_key", tokenAndKey[1]);
        // Number of records for each batch: value rang 1500~5000
        requestParameters.put("count", count);
        // Bet types of bet record: 1.Real game
        requestParameters.put("bet_type", "1");
        // Updated time of data
        requestParameters.put("row_version", rowVersion);

        String response = doPost(url, requestParameters);
        log.debug("getPGOrderRecord => {}", response);
        JSONObject jsonObject = JSON.parseObject(response);
        if (jsonObject.get("error") != null && !jsonObject.getString("error").equals("null")) {
            log.warn("PG-注单抓取-结果异常, error:{}", jsonObject.getString("error"));
            throw new GWCallRemoteApiException("PG-注单抓取-结果异常, error:" + jsonObject.getString("error"));
        }
        JSONArray jsonArray = jsonObject.getJSONArray("data");
        if (jsonArray == null || jsonArray.isEmpty()) return new ArrayList<>();
        int size = jsonArray.size();
        String productId = parameterMap.get(UtilConstants.GLOBAL_PRODUCTID_KEY).toString();
        String platformId = UtilConstants.PG;
        int prefixLength = productId.length();
        List<OrderEntity> list = new ArrayList<>(size);
        JSONObject jsonOrder;
        OrderEntity orderEntity;
        BigDecimal betAmount;
        BigDecimal winAmount;
        BigDecimal winloseAmount;
        Long betTime;
        Long betEndTime;
        String loginName;
        for (int i = 0; i < size; i++) {
            orderEntity = new OrderEntity();
            orderEntity.setProductId(productId);
            orderEntity.setPlatId(platformId);
            orderEntity.setAgCode(productId + platformId);
            orderEntity.setTopAgCode(platformId);
            orderEntity.setGameKind(UtilConstants.GAME_KIND_ENUM.ELECTRONIC.getCode());

            jsonOrder = jsonArray.getJSONObject(i);
            orderEntity.setParentBetId(jsonOrder.getLong("parentBetId"));
            orderEntity.setBillNo(jsonOrder.getString("betId"));
            loginName = jsonOrder.getString("playerName");
            if (loginName.startsWith(productId))
                loginName = loginName.substring(prefixLength);
            orderEntity.setLoginName(loginName);
            orderEntity.setGameType(jsonOrder.getString("gameId"));
            orderEntity.setBetType(jsonOrder.getInteger("betType"));
            orderEntity.setTransactionType(jsonOrder.getInteger("transactionType"));
            orderEntity.setDeviceType(convertToDeviceType(jsonOrder.getInteger("platform")));
            orderEntity.setCurrency(jsonOrder.getString("currency"));

            betAmount = jsonOrder.getBigDecimal("betAmount");
            orderEntity.setAccount(betAmount);
            orderEntity.setValidAccount(betAmount);
            winAmount = jsonOrder.getBigDecimal("winAmount");
            winloseAmount = winAmount.subtract(betAmount);
            orderEntity.setCusAccount(winloseAmount);
            orderEntity.setPreviosAmount(jsonOrder.getBigDecimal("balanceBefore"));
            orderEntity.setCurrentAmount(jsonOrder.getBigDecimal("balanceAfter"));

            betTime = jsonOrder.getLong("betTime");
            orderEntity.setBillTime(new Date(betTime));
            orderEntity.setOrignalBillTime(new Date(betTime));
            betEndTime = jsonOrder.getLong("betEndTime");
            orderEntity.setReckonTime(new Date(betEndTime));
            orderEntity.setOrignalReckonTime(new Date(betEndTime));

            orderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.SETTLED.getFalg());// 电子游戏的注单都是已结算的
            orderEntity.setBonusAmount(BigDecimal.ZERO);
            orderEntity.setRemainAmount(orderEntity.getValidAccount().setScale(6, RoundingMode.HALF_UP));

            orderEntity.setRowVersion(jsonOrder.getLong("rowVersion"));
            list.add(orderEntity);
        }
        // 将最后一笔数据的row_version取出作为下次抓单的起始参数
        parameterMap.put("rowVersion", list.get(size - 1).getRowVersion().toString());
        return list;
    }

    private static String doPost(String requestUrl, Map<String, String> requestParameters) throws IOException, GWCallRemoteApiException {
        log.debug("PG doPost url => {}", requestUrl);
        log.debug("PG doPost parameters => {}", requestParameters);
        // generate NameValuePair
        int i = 0;
        NameValuePair[] parameters = new NameValuePair[requestParameters.size()];
        for (Map.Entry<String, String> entry : requestParameters.entrySet()) {
            parameters[i++] = new NameValuePair(entry.getKey(), entry.getValue());
        }
        // init post method
        PostMethod postMethod = new PostMethod(requestUrl);
        postMethod.setRequestHeader("Cache-Control", "no-cache");
        postMethod.getParams().setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET, UtilConstants.ENCODING_UTF8);
        postMethod.setRequestBody(parameters);
        // execute post
        HttpClient httpClient = new HttpClient();
        httpClient.getHttpConnectionManager().getParams().setConnectionTimeout(1000 * 5);
        httpClient.getHttpConnectionManager().getParams().setSoTimeout(1000 * 30);
        try {
            int httpStatus = httpClient.executeMethod(postMethod);
            String response = IOUtils.toString(postMethod.getResponseBodyAsStream(), UtilConstants.ENCODING_UTF8);
            if (HttpStatus.SC_OK == httpStatus) {
                return response;
            } else {
                log.warn("PG-注单抓取-HTTP请求异常, http-status:{}, response:{}", httpStatus, response);
                throw new GWCallRemoteApiException("PG-注单抓取-HTTP请求异常, http-status:" + httpStatus + ", response:" + response);
            }
        } finally {
            postMethod.releaseConnection();
        }
    }

    /**
     * Convert the platform to the deviceType
     * deviceType: 0-电脑 1-手机
     *
     * @param platform
     * @return
     */
    private static String convertToDeviceType(Integer platform) {
        if (platform == null) return "0";
        switch (platform) {
            case 1: // Web-Windows
            case 2: // Web-MacOS
            case 5: // Web-Other
            case 8: // Electron-Windows
            case 9: // Electron-MacOS
            case 10: // Native-Window
            case 11: // Native-MacOS
                return "0";
            case 3: // Web-Android
            case 4: // Web-IOS
            case 6: // Cordova-Andorid
            case 7: // Cordova-IOS
            case 12: // Native-Android
            case 13: // Native-IOS
                return "1";
            default:
                return "0";
        }
    }
}