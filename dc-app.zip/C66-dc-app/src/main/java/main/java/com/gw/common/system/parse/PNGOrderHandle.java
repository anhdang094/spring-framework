package main.java.com.gw.common.system.parse;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.exception.GWPersistenceException;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.common.framework.util.MD5;
import main.java.com.gw.common.system.parse.vo.OrderRes;
import main.java.com.gw.datacenter.allocation.dao.AllocationDao;
import main.java.com.gw.datacenter.order.dao.OrderDao;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.digester3.Digester;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class PNGOrderHandle extends AbstractHandle {

    public String retrieveData(String url, Map<String, Object> paramaterMap) throws GWCallRemoteApiException {
        String content = "";
        try {
            log.info("url=" + url + "  parama=" + paramaterMap);
            content = new HttpUtil().httpGet(url, paramaterMap);
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new GWCallRemoteApiException("Failed to call remote interface!" + ex.getMessage(), ex);
        }

        return content;

    }
    
/*    public static AccountTransferEntity converOrderEntity2AccountTransferEntity(OrderEntity order){
        AccountTransferEntity transfer= new AccountTransferEntity();
    	transfer.setTransId(order.getBillNo());
    	transfer.setPlatformId(order.getPlatId());
    	transfer.setUserName(order.getLoginName());
    	transfer.setCreationTime(order.getBillTime());
    	transfer.setTransferType(IOM_BET_TYPE_ENUM.getCodeString(order.getPlayType()+""));
    	transfer.setTransferAmount(order.getAccount());
    	transfer.setPreviousAmount(order.getPreviosAmount());
    	transfer.setCurrentAmount(order.getCurrentAmount());
    	transfer.setCurrency(order.getCurrency());
    	transfer.setExchangeRate(order.getExchangeRate());
    	//transfer.setBalanceType();
    	transfer.setIP(order.getCurIp());
    	transfer.setProductId(order.getProductId());
    	transfer.setAgCode(order.getAgCode());
    	transfer.setTopAgCode(order.getTopAgCode());
    	transfer.setTradeNo(order.getBillNo());
    	transfer.setOrignalCreationTime(order.getOrignalBillTime());
    	return transfer;
    }*/

    public static void main(String[] args) throws GWCallRemoteApiException, GWPersistenceException {
        Map<String, Object> paramaterMap = new HashMap<String, Object>();
        String baseUrl = "http://localhost:8082/commonwallet_datacenter/PNGBetRecord.do";
        String productid = "A02";// "0";
        paramaterMap.put("productId", productid);
        String starttime = "2017-09-23 16:05:00";
        String endtime = "2017-09-29 16:09:59";
        paramaterMap.put("starttime", starttime);
        paramaterMap.put("endtime", endtime);
        String page = "1";
        paramaterMap.put("page", page);
        String num = "500";
        paramaterMap.put("num", num);
        String gameCode = "52";
        paramaterMap.put("gameCode", gameCode);
        String key = MD5.md5Encoding("12").toUpperCase();
        paramaterMap.put("key", key);
        AbstractHandle handle = new PNGOrderHandle();


        String result = handle.retrieveData(baseUrl, paramaterMap);

        System.out.println(result);
        List<Object> orderLit = handle.parse(result).getOrderList();
        System.out.println(orderLit);

        String confDir = File.separator + System.getProperty("user.dir") + File.separator + "conf";
        FileSystemXmlApplicationContext factory = new FileSystemXmlApplicationContext(confDir + "/spring/applicationContext.xml");
        OrderDao orderDao = (OrderDao) factory.getBean("orderDao");
        AllocationDao allocationDao = (AllocationDao) factory.getBean("allocationDao");
        SqlSessionFactory myBatisSessionFactory = (SqlSessionFactory) factory.getBean("myBatisSessionFactory");
        SqlSession session = myBatisSessionFactory.openSession();
//		ToolUtil.initSpecialGames(productid,"052", allocationDao);

        orderDao.insertOrder4PNG(orderLit, session, false, "052", "2018-05-24 12:12:12");


    }

    public void parseRules(Digester d) {
        d.addObjectCreate("Data", OrderRes.class);
        d.addSetProperties("Data", "sattus", "code");
        d.addSetProperties("Data", "desc", "comment");
        d.addSetProperties("Data", "Page", "numpage");
        d.addSetProperties("Data", "PageLimit", "perpage");
        d.addSetProperties("Data", "TotalNumber", "total");
        d.addSetProperties("Data", "TotalPage", "totalPages");
        d.addObjectCreate("Data/Record", OrderEntity.class);
        d.addSetNext("Data/Record", "addOrder");
        d.addBeanPropertySetter("Data/Record/requestid", "billNo");
        d.addBeanPropertySetter("Data/Record/previousbalance", "previosAmount");
        d.addBeanPropertySetter("Data/Record/currentbalance", "currentAmount");
        d.addBeanPropertySetter("Data/Record/requesttype", "playType");
        d.addBeanPropertySetter("Data/Record/bonusAmount", "bonusAmount");
        //d.addCallMethod("Data/Record/amount", "setBetSoftBetAmount",1);
        //d.addCallParam("Data/Record/Amount", 0);
        d.addBeanPropertySetter("Data/Record/amount", "account");
        d.addBeanPropertySetter("Data/Record/amount", "validAccount");
        d.addBeanPropertySetter("Data/Record/roundid", "round");
        d.addBeanPropertySetter("Data/Record/roundid", "gmCode");
        d.addBeanPropertySetter("Data/Record/gameid", "gameType");
        d.addBeanPropertySetter("Data/Record/currency", "currency");
        d.addCallMethod("Data/Record/createdDate", "setTime", 1);
        d.addCallParam("Data/Record/createdDate", 0);
        d.addBeanPropertySetter("Data/Record/productid", "productId");
        //d.addBeanPropertySetter("Data/Record/loginname","loginName");
        d.addCallMethod("Data/Record/loginname", "setLoginNameSubString3", 1);
        d.addCallParam("Data/Record/loginname", 0);
        d.addCallMethod("Data/Record/requesttype", "setFlagAccordingRequesttype", 1);
        d.addCallParam("Data/Record/requesttype", 0);
        d.addBeanPropertySetter("Data/Record/isfreegame", "isFreeGame");

    }

    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        // TODO Auto-generated method stub
        return null;
    }

}
