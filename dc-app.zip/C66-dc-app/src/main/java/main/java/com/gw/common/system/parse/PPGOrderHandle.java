package main.java.com.gw.common.system.parse;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.common.system.parse.vo.OrderRes;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.digester3.Digester;

import java.util.Map;

@Slf4j
public class PPGOrderHandle extends AbstractHandle {

    public String retrieveData(String url, Map<String, Object> paramaterMap) throws GWCallRemoteApiException {
        String content = "";
        try {
            log.info("url=" + url + "  parama=" + paramaterMap);
            content = new HttpUtil().httpGet(url, paramaterMap);
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new GWCallRemoteApiException("Failed to call remote interface!" + ex.getMessage(), ex);
        }

        return content;
    }

    public void parseRules(Digester d) {
        d.addObjectCreate("Data", OrderRes.class);
        d.addSetProperties("Data", "status", "code");
        d.addSetProperties("Data", "desc", "comment");
        d.addSetProperties("Data", "Page", "numpage");
        d.addSetProperties("Data", "PageLimit", "perpage");
        d.addSetProperties("Data", "TotalNumber", "total");
        d.addSetProperties("Data", "TotalPage", "totalPages");
        d.addObjectCreate("Data/Record", OrderEntity.class);
        d.addSetNext("Data/Record", "addOrder");
        d.addBeanPropertySetter("Data/Record/username", "loginName");
        d.addBeanPropertySetter("Data/Record/roundNumber", "billNo");
        d.addBeanPropertySetter("Data/Record/roundNumber", "gmCode");
        d.addCallMethod("Data/Record/wagersDate", "setTimeBillTime", 1);
        d.addCallParam("Data/Record/wagersDate", 0);
        d.addCallMethod("Data/Record/modifiedDate", "setTimeReckonTime", 1);
        d.addCallParam("Data/Record/modifiedDate", 0);
        d.addBeanPropertySetter("Data/Record/gameType", "gameType");
        d.addBeanPropertySetter("Data/Record/result", "result");
        d.addBeanPropertySetter("Data/Record/resultType", "resultType");
        d.addBeanPropertySetter("Data/Record/betAmount", "account");
        d.addBeanPropertySetter("Data/Record/validAmount", "validAccount");
        d.addBeanPropertySetter("Data/Record/payoff", "cusAccount");
        d.addBeanPropertySetter("Data/Record/currency", "currency");
        d.addBeanPropertySetter("Data/Record/previousBalance", "previosAmount");
        d.addBeanPropertySetter("Data/Record/currentBalance", "currentAmount");
        d.addBeanPropertySetter("Data/Record/productId", "productId");
        d.addBeanPropertySetter("Data/Record/bonusAmount", "bonusAmount");
        d.addBeanPropertySetter("Data/Record/deviceType", "deviceType");
        d.addCallMethod("Data/Record/resultType", "setFlagAccordingRequesttype", 1);
        d.addCallParam("Data/Record/resultType", 0);
    }

    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        // TODO Auto-generated method stub
        return null;
    }
}
