package main.java.com.gw.common.system.parse;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.apollo.LoggerConfiguration;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.util.AmIRunningInDocker;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.system.parse.vo.OrderRes;
import main.java.com.gw.datacenter.order.dao.OrderDao;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.cookie.Cookie;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.util.EntityUtils;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.security.KeyStore;
import java.util.*;

@Slf4j
public class PTOrderHandle extends AbstractHandle {

	static {
		log.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>> P12_path: {}", File.separator + System.getProperty("user.dir") + File.separator + PT_KEY_DIR);
	}

    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        String baseUrl = (String) paramaterMap.get(UtilConstants.ORDER_BASE_URL);
        String begintimeStr = (String) paramaterMap.get(UtilConstants.ORDER_BEGIN_TIME);
        String endtimeStr = (String) paramaterMap.get(UtilConstants.ORDER_END_TIME);
        begintimeStr = URLEncoder.encode(begintimeStr);
        endtimeStr = URLEncoder.encode(endtimeStr);
        int page = Integer.valueOf((String) paramaterMap.get(UtilConstants.ORDER_PAGE));
        int numperpage = Integer.valueOf((String) paramaterMap.get(UtilConstants.ORDER_PAGE_NUMBER));
        String tmp_uri = "/customreport/getdata/reportname/PlayerGames/startdate/%s/enddate/%s/frozen/%s/page/%s/perPage/%s";
//        String tmp_uri = "/customreport/getdata/reportname/PlayerGames/startdate/%s/enddate/%s/frozen/%s";
        tmp_uri = String.format(tmp_uri, begintimeStr, endtimeStr, "all", page, numperpage);
        return baseUrl + tmp_uri;
    }


    static DefaultHttpClient newPtClient = new DefaultHttpClient();

    static {
        HttpConnectionParams.setConnectionTimeout(newPtClient.getParams(), 20 * 1000);
        HttpConnectionParams.setSoTimeout(newPtClient.getParams(), 20 * 1000);
       /* newPtClient.setHttpRequestRetryHandler((e, i, httpContext) -> {

            if(i>=5){
                return false;
            }
            if(e instanceof NoHttpResponseException){
                return true;
            }
            return true;
        });*/
    }

    public boolean checkLoginStatusInPTWeb(HttpHost host, String username, String password) throws IOException {

        boolean isLogin = false;
        //check login in or not
        HttpUriRequest index = new HttpGet("/index.php");
        HttpResponse indexResponse = newPtClient.execute(host, index);
        if (indexResponse != null) {
            Optional<Cookie> kioskadmin_secret = newPtClient.getCookieStore().getCookies().parallelStream().filter(x -> x.getName().equals("kioskadmin_secret")).findFirst();
            if (kioskadmin_secret.isPresent()) {
                //己经登录
                isLogin = true;
            }
            IOUtils.closeQuietly(indexResponse.getEntity().getContent());
        }
        if (!isLogin) {
            //login first
            List<NameValuePair> pairList = new ArrayList<>();
            pairList.add(new BasicNameValuePair("username", username));
            pairList.add(new BasicNameValuePair("password", password));
            HttpPost post = new HttpPost("/login.php");
            try {
                UrlEncodedFormEntity urlEncodedFormEntity = new UrlEncodedFormEntity(pairList);
                post.setEntity(urlEncodedFormEntity);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            HttpResponse loginResponse = newPtClient.execute(host, post);
            if (loginResponse != null) {
                Optional<Cookie> kioskadmin_secret = newPtClient.getCookieStore().getCookies().parallelStream().filter(x -> x.getName().equals("kioskadmin_secret")).findFirst();
                if (kioskadmin_secret.isPresent()) {
                    //己经登录
                    isLogin = true;
                }
                IOUtils.closeQuietly(loginResponse.getEntity().getContent());
            }
        }
        return isLogin;
    }

    public String retrieveDataNew(String baseUrl, String startDate, String endDate, int pageIndex, int perPage) throws GWCallRemoteApiException {
        if (perPage <= 0) perPage = 50;
        HttpHost host = null;
        try {
            URL url = new URL(baseUrl);
            host = new HttpHost(url.getHost(), url.getDefaultPort(), url.getProtocol());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw new GWCallRemoteApiException("PT-WEB后台地址异常,地址=" + baseUrl + "," + e.getMessage(), e);
        }
           /* try {
                boolean logined = checkLoginStatusInPTWeb(host, username, password);
                if (!logined) {
                    log.error("登录PT Web后台失败");
                    throw new GWCallRemoteApiException("登录PT Web后台失败");
                }
            } catch (IOException e) {
                e.printStackTrace();
                throw new GWCallRemoteApiException("登录PT Web后台异常," + e.getMessage(), e);
            }*/
        /**获取PT后台 html查询游戏注单地址*/
        StringBuilder url = new StringBuilder("");
        String encodedStartDate = startDate;
        String encodedEndDate = endDate;
        try {
            encodedStartDate = URLEncoder.encode(startDate, "UTF-8");
            encodedEndDate = URLEncoder.encode(endDate, "UTF-8");
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        url.append("/custom_reports.php?action=getReportResult&reportname=PlayerGames&page=").append(pageIndex - 1).append("&timeperiod=specify&startdate=").append(encodedStartDate).append("&enddate=").append(encodedEndDate).append("&playername=&frozen=all&showinfo=0&excludezero=0&description=&simple=0&sortby=username&sortorder=0&sortorder=1&show=Show&perPage=").append(perPage);
        log.info("pt-web queryurl = " + url);
        HttpUriRequest query = new HttpGet(url.toString());
        HttpResponse queryResponse = null;
        String htmlStr = "";
        try {
            queryResponse = newPtClient.execute(host, query);
            if (queryResponse != null) {
                htmlStr = EntityUtils.toString(queryResponse.getEntity());
            } else {
                throw new GWCallRemoteApiException("requstturl = " + url.toString() + ",抓取PT Web后台数据异常,响应为空");
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw new GWCallRemoteApiException("requstturl = " + url.toString() + ",抓取PT Web后台数据异常," + e.getMessage(), e);
        } finally {
            newPtClient.getConnectionManager().closeExpiredConnections();
        }
        return htmlStr;
    }

    @Override
    public String retrieveData(Map<String, Object> paramaterMap) throws GWCallRemoteApiException {
        String requestUrl = getUrl(paramaterMap);
        return getData(requestUrl, paramaterMap);
    }

    private static KeyManagerFactory kmfVND = null;
    private static KeyManagerFactory kmfCNY = null;
    private static KeyManagerFactory kmfTHB = null;
    private static KeyManagerFactory kmfUSD = null;
    private static final String CURRENCY_VND = "VND"; // 越南盾 币种标示
    private static final String CURRENCY_CNY = "CNY";//人民币
    private static final String CURRENCY_THB = "THB";//泰铢
    private static final String CURRENCY_USD = "USD"; // 美元

    /**
     * 初始化加载Key
     */
    static {
        loadKey();
    }

    private static void loadKey() {
        InputStream vndfis = null;
        InputStream cnyfis = null;
        InputStream thbfis = null;
        InputStream usdfis = null;
        try {
            KeyStore ks = KeyStore.getInstance("PKCS12");
            /**
             * 越南盾币种
             */

            // PDATACENTER-845 证书文件位置调整 modify by walter 2018-10-29
            // PDATACENTER-933 Jar包方式执行时，文件读写方式修正 modify by walter 2019-02-21
            String confDir = AmIRunningInDocker.check()? LoggerConfiguration.p12_path_k8s : LoggerConfiguration.p12_path; //File.separator + System.getProperty("user.dir") + File.separator + PT_KEY_DIR;
            log.info(">>>>>am I in docker? {}  p12_path is {}", AmIRunningInDocker.check(), confDir);
            Resource vndfileResource = new FileSystemResource(confDir + "/pt_vnd.p12");
	        vndfis = new FileInputStream(vndfileResource.getFile());
            ks.load(vndfis, "vx11NeU3hxYc83XF".toCharArray());
            kmfVND = KeyManagerFactory.getInstance("SunX509");
            kmfVND.init(ks, "vx11NeU3hxYc83XF".toCharArray());
            /**
             * CNY币种
             */
	        Resource otherfileResource = new FileSystemResource(confDir + "/pt_cny.p12");
            //otherfis = PTOrderHandle.class.getResourceAsStream("/saconfig/secure/pt_cny.p12");
            cnyfis = new FileInputStream(otherfileResource.getFile());
            ks.load(cnyfis, "MCgtFB39qhSnVc1M".toCharArray());
            kmfCNY = KeyManagerFactory.getInstance("SunX509");
            kmfCNY.init(ks, "MCgtFB39qhSnVc1M".toCharArray());


            /**
             * 泰铢
             */
            Resource thbfileResource = new FileSystemResource(confDir + "/pt_thb.p12");
            thbfis = new FileInputStream(thbfileResource.getFile());
            ks.load(thbfis, "KbW2KKj2Q2NB4U8Q".toCharArray());
            kmfTHB = KeyManagerFactory.getInstance("SunX509");
            kmfTHB.init(ks, "KbW2KKj2Q2NB4U8Q".toCharArray());

            /** 美元 */
            Resource usdfileResource = new FileSystemResource(confDir + "/pt_usd.p12");
            usdfis = new FileInputStream(usdfileResource.getFile());
            ks.load(usdfis, "EMEDLhHPxmmVWkZe".toCharArray());
            kmfUSD = KeyManagerFactory.getInstance("SunX509");
            kmfUSD.init(ks, "EMEDLhHPxmmVWkZe".toCharArray());
        } catch (Exception e) {
            log.error("pt证书加载失败", e);
        } finally {
            if (vndfis != null) {
                try {
                    vndfis.close();
                } catch (Exception e) {
                    log.error("PTOrderHandle loadKey vndfis.close() error", e);
                }
            }
            if (cnyfis != null) {
                try {
                    cnyfis.close();
                } catch (Exception e) {
                    log.error("PTOrderHandle loadKey otherfis.close() error", e);
                }
            }
        }
    }

    public String getData(String requestUrl, Map<String, Object> paramaterMap) throws GWCallRemoteApiException {
        String result = "";
        InputStream in = null;
        // Begin C07 使用越南盾，所以证书和密码跟其他产品不一样，该字段单独存C07的密码    add by Miles on 2016-07-09
        String currency = (String) paramaterMap.get("currency");
        KeyManagerFactory kmf = null;
        if (CURRENCY_VND.equalsIgnoreCase(currency)) {
            kmf = kmfVND;
        } else if (CURRENCY_CNY.equalsIgnoreCase(currency)){
            kmf = kmfCNY;
        }else if(CURRENCY_THB.equalsIgnoreCase(currency)){
            kmf = kmfTHB;
        } else if (CURRENCY_USD.equalsIgnoreCase(currency)){
            kmf = kmfUSD;
        }else {
            log.error("-PT证书初始化-非支持的币种-currency-{}",currency);
        }
        // End C07 使用越南盾，所以证书和密码跟其他产品不一样，该字段单独存C07的密码    add by Miles on 2016-07-09

        String entity_key = (String) paramaterMap.get("x-entity-key");// x-entity-key
        URLConnection yc = null;
        try {
            URL pt = new URL(requestUrl);
            log.info("currency-{}-PTRequestUrl-{}", currency, requestUrl);
            SSLContext sc = SSLContext.getInstance("TLS");
            if( sc==null ){
                log.info("-PT证书SSLContext初始化为空-");
            }
            if( kmf==null ){
                log.info("-PT证书kmf值为空-");
            }else{
                log.info("-PT证书-kmf.getKeyManagers-{}",kmf.getKeyManagers());
            }
            sc.init(kmf.getKeyManagers(), null, null);

            yc = pt.openConnection();
            yc.setReadTimeout(timeOut_PT);
            yc.setConnectTimeout(timeOut_PT);
            yc.setRequestProperty("X_ENTITY_KEY", entity_key);
            ((HttpsURLConnection) yc).setSSLSocketFactory(sc.getSocketFactory());
            in = yc.getInputStream();
            result = IOUtils.toString(in, "UTF-8");

        } catch (Exception e) {
            log.error(e.getMessage() + ",url:" + requestUrl, e);
            throw new GWCallRemoteApiException(e.getMessage());
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (Exception e) {
                }
            }
            if (yc != null) {
                ((HttpsURLConnection) yc).disconnect();
            }
        }
        return result;
    }

    public static void main(String[] args) throws Exception {
        DateTime begin = DateTime.parse("2017-01-08 00:52:00", DateTimeFormat.forPattern(DateUtil.C_TIME_PATTON_DEFAULT));
        System.out.println(begin.getMinuteOfHour());

        String requestUrl = "https://kioskpublicapi.redhorse88.com/customreport/getdata/reportname/PlayerGames/startdate/2017-04-21+16%3A13%3A41/enddate/2017-04-21+16%3A26%3A41/frozen/all/page/1/perPage/1000";

        Map<String, Object> paramaterMap = new HashMap<>();
        paramaterMap.put("password", "MCgtFB39qhSnVc1M");
        paramaterMap.put("productId", "B79");
        paramaterMap.put("x-entity-key", "d03646e0eaec2e998645bd9fc5d2efb9de295ce60f1db6652dd9dad3acab372211af412cb410f1b6c0699d2a2bcf80a30ec68e0bb81dbadcd69897caf5caf245");
//    	
        PTOrderHandle handle = new PTOrderHandle();
//        String XML = handle.getData(requestUrl, paramaterMap);
        String XML = "{\"result\":[{\"PLAYERNAME\":\"AGB01KAIKO520\",\"WINDOWCODE\":\"0\",\"GAMEID\":\"427\",\"GAMECODE\":\"293258147054\",\"GAMETYPE\":\"Slot Machines\",\"GAMENAME\":\"Jin Qian Wa (jqw)\",\"SESSIONID\":\"917337314977\",\"BET\":\".8\",\"WIN\":\"0\",\"PROGRESSIVEBET\":\"0\",\"PROGRESSIVEWIN\":\"10.52\",\"BALANCE\":\"84.42\",\"CURRENTBET\":\"0\",\"GAMEDATE\":\"2017-09-07 16:51:40\",\"LIVENETWORK\":null,\"RNUM\":\"1\"},{\"PLAYERNAME\":\"AGB01KAIKO520\",\"WINDOWCODE\":\"0\",\"GAMEID\":\"428\",\"GAMECODE\":\"293258148089\",\"GAMETYPE\":\"Slot Machines\",\"GAMENAME\":\"Jin Qian Wa (jqw)\",\"SESSIONID\":\"917337314977\",\"BET\":\".8\",\"WIN\":\"0\",\"PROGRESSIVEBET\":\"0\",\"PROGRESSIVEWIN\":\"0\",\"BALANCE\":\"83.62\",\"CURRENTBET\":\"0\",\"GAMEDATE\":\"2017-09-07 16:51:40\",\"LIVENETWORK\":null,\"RNUM\":\"2\"},{\"PLAYERNAME\":\"AGB01KAIKO520\",\"WINDOWCODE\":\"0\",\"GAMEID\":\"429\",\"GAMECODE\":\"293258148771\",\"GAMETYPE\":\"Slot Machines\",\"GAMENAME\":\"Jin Qian Wa (jqw)\",\"SESSIONID\":\"917337314977\",\"BET\":\".8\",\"WIN\":\"0\",\"PROGRESSIVEBET\":\"0\",\"PROGRESSIVEWIN\":\"0\",\"BALANCE\":\"82.82\",\"CURRENTBET\":\"0\",\"GAMEDATE\":\"2017-09-07 16:51:40\",\"LIVENETWORK\":null,\"RNUM\":\"3\"},{\"PLAYERNAME\":\"AGB01KLUJUN7575\",\"WINDOWCODE\":\"0\",\"GAMEID\":\"191\",\"GAMECODE\":\"293258147512\",\"GAMETYPE\":\"Slot Machines\",\"GAMENAME\":\"Samba Brazil (gtssmbr)\",\"SESSIONID\":\"917349184716\",\"BET\":\"6.25\",\"WIN\":\"3.5\",\"PROGRESSIVEBET\":\"0\",\"PROGRESSIVEWIN\":\"0\",\"BALANCE\":\"2728.17\",\"CURRENTBET\":\"0\",\"GAMEDATE\":\"2017-09-07 16:51:40\",\"LIVENETWORK\":null,\"RNUM\":\"4\"},{\"PLAYERNAME\":\"AGB01KXJY747319\",\"WINDOWCODE\":\"0\",\"GAMEID\":\"303\",\"GAMECODE\":\"293258147358\",\"GAMETYPE\":\"Progressive Slot Machines\",\"GAMENAME\":\"Age of the Gods Jackpot (mrj)\",\"SESSIONID\":\"917355779813\",\"BET\":\"0\",\"WIN\":\"0\",\"PROGRESSIVEBET\":\".0396\",\"PROGRESSIVEWIN\":\"0\",\"BALANCE\":\"2008.43\",\"CURRENTBET\":\"0\",\"GAMEDATE\":\"2017-09-07 16:51:40\",\"LIVENETWORK\":null,\"RNUM\":\"5\"}], \"pagination\":{\"currentPage\":1,\"totalPages\":122,\"itemsPerPage\":5,\"totalCount\":609}}";
        System.out.println(XML);
        OrderRes orders = handle.parse(XML);
        System.out.println(orders.getOrderList());

        String confDir = File.separator + System.getProperty("user.dir") + File.separator + "conf";
        FileSystemXmlApplicationContext factory = new FileSystemXmlApplicationContext(confDir + "/spring/applicationContext.xml");
        OrderDao orderDao = (OrderDao) factory.getBean("orderDao");
        SqlSessionFactory myBatisSessionFactory = (SqlSessionFactory) factory.getBean("myBatisSessionFactory");
        SqlSession session = myBatisSessionFactory.openSession();
        List<Object> orderLit = orders.getOrderList();
        for (int i = 0; i < orderLit.size(); i++) {
            OrderEntity _order = (OrderEntity) orderLit.get(i);
            //_order.setGameKind("5");
            //_order.setBillNo("0");
            //_order.setAgCode("0");
            //_order.setGmCode("0");
            // _order.setBillTime(_order.getReckonTime());
            //_order.setOrignalBillTime(_order.getBillTime());
            //_order.setOrignalReckonTime(_order.getBillTime());
        }

        orderDao.insertOrder4PT(orderLit, session, false);

    }


    @Override
    public OrderRes parse(String content) {
        JSONObject obj = JSONObject.fromObject(content);
        OrderRes res = new OrderRes();
        JSONObject p_obj = obj.optJSONObject("pagination");
        res.setPerpage(p_obj.optInt("itemsPerPage"));
        res.setTotal(p_obj.optInt("totalCount"));
        JSONArray arr = obj.optJSONArray("result");
        JSONObject order_obj = null;
        String pidLoginname = "";
        for (int i = 0; i < arr.size(); i++) {
            order_obj = arr.optJSONObject(i);
            OrderEntity order = new OrderEntity();
            pidLoginname = order_obj.optString("PLAYERNAME", "");
            String prefix = pidLoginname.substring(0, 5);
            order.setCurrency(String.valueOf(UtilConstants.CURRENCY.CNY.ordinal()));
            if (prefix.toLowerCase().contains("w66")) {
                order.setLoginName(pidLoginname.substring(3).toLowerCase());
                order.setProductId(UtilConstants.PRODUCT_ENUM.A05.toString());
            } else if (prefix.toLowerCase().contains("kb88")) {
                order.setLoginName(pidLoginname.substring(4).toLowerCase());
                order.setProductId(UtilConstants.PRODUCT_ENUM.A06.toString());
            } else if (prefix.toLowerCase().contains("am8")) {
                order.setLoginName(pidLoginname.substring(3).toLowerCase());
                order.setProductId(UtilConstants.PRODUCT_ENUM.C01.toString());
            } else if (prefix.toLowerCase().contains("d88")) {
                order.setLoginName(pidLoginname.substring(3).toLowerCase());
                order.setProductId(UtilConstants.PRODUCT_ENUM.A04.toString());
            } else if (prefix.toLowerCase().contains("f66")) {
                order.setLoginName(pidLoginname.substring(3).toLowerCase());
                order.setProductId(UtilConstants.PRODUCT_ENUM.E03.toString());
            } else if (prefix.toLowerCase().contains("h88")) {
                order.setLoginName(pidLoginname.substring(3).toLowerCase());
                order.setProductId(UtilConstants.PRODUCT_ENUM.E04.toString());
            } else if (prefix.toLowerCase().contains("k8s")) {
                order.setLoginName(pidLoginname.substring(3).toLowerCase());
                order.setProductId(UtilConstants.PRODUCT_ENUM.B06.toString());
            } else if (prefix.toLowerCase().contains("p02")) {
                order.setLoginName(pidLoginname.substring(3).toLowerCase());
                order.setProductId(UtilConstants.PRODUCT_ENUM.P02.toString());
            } else if (prefix.toLowerCase().contains("b79")) {
                order.setLoginName(pidLoginname.substring(3).toLowerCase());
                order.setProductId(UtilConstants.PRODUCT_ENUM.B79.toString());
            } else if (prefix.toLowerCase().contains("vk8")) {
                order.setLoginName(pidLoginname.substring(3).toLowerCase());
                order.setProductId(UtilConstants.PRODUCT_ENUM.C07.toString());
                order.setCurrency(String.valueOf(UtilConstants.CURRENCY.VND.ordinal()));
            } else if (prefix.toLowerCase().contains("b07")) {
                order.setLoginName(pidLoginname.substring(3).toLowerCase());
                order.setProductId(UtilConstants.PRODUCT_ENUM.B07.toString());
            } else if (prefix.toLowerCase().contains("v84")){
                order.setLoginName(pidLoginname.substring(3).toLowerCase());
                order.setProductId(UtilConstants.PRODUCT_ENUM.V84.toString());
                order.setCurrency(String.valueOf(UtilConstants.CURRENCY.VND.ordinal()));
            } else if (prefix.toLowerCase().contains("av66")){
                order.setLoginName(pidLoginname.substring(4).toLowerCase());
                order.setProductId(UtilConstants.PRODUCT_ENUM.V66.toString());
                order.setCurrency(String.valueOf(UtilConstants.CURRENCY.THB.ordinal()));
            } else if (prefix.toLowerCase().contains("aga13")) {
                order.setLoginName(pidLoginname.substring(5).toLowerCase());
                order.setProductId(UtilConstants.PRODUCT_ENUM.A04.toString());
            } else if (prefix.toLowerCase().contains("aga15")) {
                order.setLoginName(pidLoginname.substring(5).toLowerCase());
                order.setProductId(UtilConstants.PRODUCT_ENUM.A05.toString());
            } else if (prefix.toLowerCase().contains("aga11")) {
                order.setLoginName(pidLoginname.substring(5).toLowerCase());
                order.setProductId(UtilConstants.PRODUCT_ENUM.A01.toString());
            } else if (prefix.toLowerCase().contains("aga08")) {
                order.setLoginName(pidLoginname.substring(5).toLowerCase());
                order.setProductId(UtilConstants.PRODUCT_ENUM.A03.toString());
            } else if (prefix.toLowerCase().contains("aga12")) {
                order.setLoginName(pidLoginname.substring(5).toLowerCase());
                order.setProductId(UtilConstants.PRODUCT_ENUM.A02.toString());
            } else if (prefix.toLowerCase().contains("aga09")) {
                order.setLoginName(pidLoginname.substring(5).toLowerCase());
                order.setProductId(UtilConstants.PRODUCT_ENUM.A06.toString());
            } else if (prefix.toLowerCase().contains("aga16")) {
                order.setLoginName(pidLoginname.substring(5).toLowerCase());
                order.setProductId(UtilConstants.PRODUCT_ENUM.B01.toString());
            } else if (prefix.toLowerCase().contains("aga19")) {
                order.setLoginName(pidLoginname.substring(5).toLowerCase());
                order.setProductId(UtilConstants.PRODUCT_ENUM.C01.toString());
            } else {
                order.setLoginName(pidLoginname.substring(5).toLowerCase());
                order.setProductId(pidLoginname.substring(2, 5));
            }
            order.setGmCode(order_obj.optString("GAMECODE", ""));
            order.setPlatId(UtilConstants.PT);
            order.setRemark(order_obj.optString("WINDOWCODE", ""));//pt中将用户打开的页面数放到remark字段中

            String gameName = order_obj.optString("GAMENAME", "");
            if (gameName.indexOf("(") != -1 && gameName.indexOf(")") != -1) {
                /*gameName = gameName.substring(gameName.indexOf("(") + 1, gameName.indexOf(")"));*/
                //PT 去gamename的最后一个挂号中的值，作为GameType
                gameName = gameName.substring(gameName.lastIndexOf("(") + 1, gameName.lastIndexOf(")"));
                order.setGameType(gameName);
            } else {
                order.setGameType(gameName);
                log.info("GameType未获取到截取的：" + order_obj);
            }

            String amountStr = order_obj.optString("BET", "0");
            String winStr = order_obj.optString("WIN", "0");
            String jackpot = order_obj.optString("PROGRESSIVEWIN", "0");
            BigDecimal amount = new BigDecimal(amountStr);
            BigDecimal jackpotWinAmount = new BigDecimal(jackpot);
            order.setAccount(amount);
            order.setValidAccount(amount);

            // =客户派彩额度-投注额
            order.setCusAccount(new BigDecimal(winStr).subtract(amount).add(jackpotWinAmount));
            order.setBillTime(DateUtil.formatStr2Date(order_obj.optString("GAMEDATE", "")));
            order.setPreviosAmount(new BigDecimal(order_obj.optString("BALANCE", "0")).subtract(order.getCusAccount()));
            order.setAgCode(jackpot);//记录PT厅彩池 add by ziv 2018-07-13

            // order.setRemark(order_obj.optString("GAMENAME", ""));
            // System.out.println(order_obj.optString("LIVENETWORK", ""));
            String gameKindFlag = order_obj.optString("LIVENETWORK", "");
            // !=null和0为真人,其他为电子游艺
//            if (!gameKindFlag.equalsIgnoreCase("null") && !gameKindFlag.equalsIgnoreCase("0")) {
//                order.setGameKind(UtilConstants.LIVE_GAME_KIND);
//            } else {
                order.setGameKind(UtilConstants.ELECT_GAME_KIND);
//            }
            order.setBillNo(order_obj.optString("GAMECODE", ""));
            order.setFlag(1);
            if (amountStr.equals("0") && winStr.equals("0") && jackpot.equals("0"))
                continue;
            res.addOrder(order);
        }
        return res;
    }


    public OrderRes parseNew(String content) throws GWCallRemoteApiException {
        OrderRes res = new OrderRes();
        Document document = Jsoup.parse(content);

        Element logintable = document.getElementById("logintable");
        if (logintable != null) {
            throw new GWCallRemoteApiException("后台PT WEB 后台未登录或强制登出");
        }

        Element msgDiv = document.getElementById("flash_error_container");
        boolean error = false;
        String style = msgDiv.attr("style");
        error = style.contains("block");
        String total = "";
        String lastPage = "0";
        if (error) {
            res.setComment(msgDiv.html());
            throw new RuntimeException(msgDiv.html());
        } else {
            String totalStr = msgDiv.nextElementSibling().html();
            if (totalStr.indexOf("Total rows:") > -1) {
                total = totalStr.replaceAll("Total rows:", "").trim();
            } else {
                res.setComment(totalStr);
                total = "0";
                res.setComment(totalStr);
                res.setTotalPages(0);
                return res;
            }
        }
        Elements table = document.body().select("table[class='result']");
        Elements lastTr = table.select("tr:last-child");
        Element lastInSide = Jsoup.parse(lastTr.select("td").html()).body().children().last();
        String lastInSideTagName = lastInSide.tagName();
        if (lastInSideTagName.equalsIgnoreCase("strong")) {
            //当前页是最后一页
            lastPage = lastInSide.text();
        } else {
            //非最后一页
            lastPage = lastInSide.val();
        }
        res.setTotalPages(Integer.parseInt(lastPage));
        res.setTotal(Integer.parseInt(total));
        Elements allTr = table.select("tr");
        if (allTr != null && allTr.size() > 0) {
            for (int i = 1; i < allTr.size() - 1; i++) {
                Element element = allTr.get(i);
                OrderEntity orderEntity = parseRowRecord(element);
                if (orderEntity != null) {
                    res.addOrder(orderEntity);
                }
            }
        }
        return res;
    }

    public OrderEntity parseRowRecord(Element tr) {
        OrderEntity orderEntity = null;
        Elements tds = tr.select("td");
        if (tds == null || tds.size() == 0) {
            return null;
        } else {
            //Username-0
            // Window ID-1
            // Game ID-2
            // Game code-3
            // Game type-4
            // Game name (code)-5
            // Session Id-6
            // Bet-7
            // Win-8
            // Progressive Bet(9)
            // Progressive Win(10)
            // Balance(11)
            // Currentbet(12)
            // Game date(13)
            // Live network(14)
            orderEntity = new OrderEntity();
            String productId = "";
            String fullLoginName = tds.get(0).text();
            String profName = "";
            if (fullLoginName.startsWith("K8S")) {
                profName = "K8S";
                productId = UtilConstants.PRODUCT_ENUM.B06.toString();
            } else if (fullLoginName.startsWith("AGA03")) {
                profName = "AGA03";
                productId = UtilConstants.PRODUCT_ENUM.A03.toString();
            } else if (fullLoginName.startsWith("B07")) {
                profName = "B07";
                productId = UtilConstants.PRODUCT_ENUM.B07.toString();
            } else {
                return null;
            }
            String windowCount = String.valueOf(Integer.parseInt(tds.get(1).text()) + 1);
            String username = fullLoginName.replace(profName, "").toLowerCase();
            String billno = tds.get(3).text();
            String gameName = tds.get(5).text().trim();
            if (gameName.indexOf("(") != -1 && gameName.indexOf(")") != -1) {
                gameName = gameName.substring(gameName.indexOf("(") + 1, gameName.indexOf(")"));
            }
            String gmCode = tds.get(6).text();
            String amountStr = tds.get(7).text().substring(3).replaceAll(",", "");
            String winStr = tds.get(8).text().substring(3).replaceAll(",", "");
            String jackpot = tds.get(10).text().substring(3).replaceAll(",", "");

            BigDecimal betAmount = new BigDecimal(amountStr);
            BigDecimal winAmount = new BigDecimal(winStr);
            BigDecimal jackpotAmount = new BigDecimal(jackpot);
            if (betAmount.compareTo(BigDecimal.ZERO) == 0 && winAmount.compareTo(BigDecimal.ZERO) == 0 && jackpotAmount.compareTo(BigDecimal.ZERO) == 0) {
                return null;
            }
            String balance = tds.get(11).text().substring(3).replaceAll(",", "");
            String gameDate = tds.get(13).text();

            String liveNetwork = tds.get(14).text();

            orderEntity.setLoginName(username);
            orderEntity.setProductId(productId);
            orderEntity.setGmCode(gmCode);
            orderEntity.setPlatId(UtilConstants.PT);
            orderEntity.setRemark(windowCount);
            orderEntity.setGameType(gameName);

            orderEntity.setAccount(betAmount);
            orderEntity.setValidAccount(betAmount);

            orderEntity.setCusAccount(new BigDecimal(winStr).subtract(betAmount).add(jackpotAmount));
            orderEntity.setBillTime(DateUtil.formatStr2Date(gameDate));

            orderEntity.setPreviosAmount(new BigDecimal(balance).subtract(orderEntity.getCusAccount()));
            if (StringUtils.isNotBlank(liveNetwork)) {
                orderEntity.setGameKind(UtilConstants.LIVE_GAME_KIND);
            } else {
                orderEntity.setGameKind(UtilConstants.ELECT_GAME_KIND);
            }
            orderEntity.setBillNo(billno);
            orderEntity.setFlag(1);
        }
        return orderEntity;
    }

    public String getPlayerStatsUrl(Map<String, Object> paramaterMap) {
        String baseUrl = (String) paramaterMap.get(UtilConstants.ORDER_BASE_URL);
        String begintimeStr = (String) paramaterMap.get(UtilConstants.ORDER_BEGIN_TIME);
        String endtimeStr = (String) paramaterMap.get(UtilConstants.ORDER_END_TIME);
        begintimeStr = URLEncoder.encode(begintimeStr);
        endtimeStr = URLEncoder.encode(endtimeStr);
        int page = Integer.valueOf((String) paramaterMap.get(UtilConstants.ORDER_PAGE));
        int numperpage = Integer.valueOf((String) paramaterMap.get(UtilConstants.ORDER_PAGE_NUMBER));
        String tmp_uri = "/customreport/getdata/reportname/PlayerStats/startdate/%s/enddate/%s/page/%s/perPage/%s";
        tmp_uri = String.format(tmp_uri, begintimeStr, endtimeStr, page, numperpage);
        return baseUrl + tmp_uri;
    }

    public BigDecimal getTotalBetAmount(Map<String, Object> paramaterMap) throws GWCallRemoteApiException {
        log.info("PTOrderHandle getTotalBetAmount paramaterMap=" + paramaterMap);
        String content = "";
        BigDecimal totalBets = null;
        String requestUrl = getPlayerStatsUrl(paramaterMap);
        log.info("PTOrderHandle getTotalBetAmount requestUrl=" + requestUrl);
        content = getData(requestUrl, paramaterMap);
        log.info("PTOrderHandle getTotalBetAmount getData content=" + content);
        if (StringUtils.isNotBlank(content)) {
            JSONObject resultJson = JSONObject.fromObject(content);
            JSONArray array = resultJson.optJSONArray("result");
            if (array != null && array.size() > 0) {
                JSONObject playerReport = (JSONObject) array.get(0);
                totalBets = BigDecimal.valueOf(playerReport.optDouble("BETS", 0.0));
            }
        }
        return totalBets;
    }

}
