package main.java.com.gw.common.system.parse;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.apollo.LoggerConfiguration;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.util.AmIRunningInDocker;
import main.java.com.gw.common.system.parse.vo.TransRes;
import main.java.com.gw.datacenter.accounttransfer.entity.AccountTransferEntity;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.io.IOUtils;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import java.io.FileInputStream;
import java.io.InputStream;
import java.math.BigDecimal;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.security.KeyStore;
import java.util.HashMap;
import java.util.Map;

@Slf4j
public class PTTransHandle extends AbstractHandle {

    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        String baseUrl = (String) paramaterMap.get(UtilConstants.ORDER_BASE_URL);
        String begintimeStr = (String) paramaterMap.get(UtilConstants.ORDER_BEGIN_TIME);
        String endtimeStr = (String) paramaterMap.get(UtilConstants.ORDER_END_TIME);
        begintimeStr = URLEncoder.encode(begintimeStr);
        endtimeStr = URLEncoder.encode(endtimeStr);
        int page = Integer.valueOf((String) paramaterMap.get(UtilConstants.ORDER_PAGE));
        int numperpage = Integer.valueOf((String) paramaterMap.get(UtilConstants.ORDER_PAGE_NUMBER));
        //"/status/approved"，只查询成功的转账   modified by ziv 2018-04-03
        String tmp_uri = "/customreport/getdata/reportname/PlayerTransactions/status/approved/startdate/%s/enddate/%s/page/%s/perPage/%s";
        tmp_uri = String.format(tmp_uri, begintimeStr, endtimeStr, page, numperpage);
        return baseUrl + tmp_uri;
    }

    private static KeyManagerFactory kmfVND = null;
    private static KeyManagerFactory kmfCNY = null;
    private static KeyManagerFactory kmfTHB = null;
    private static KeyManagerFactory kmfUSD = null;
    private static final String CURRENCY_VND = "VND"; // 越南盾 币种标示
    private static final String CURRENCY_CNY = "CNY";//人民币
    private static final String CURRENCY_THB = "THB";//泰铢
    private static final String CURRENCY_USD = "USD";//泰铢
    /**
     * 初始化加载Key
     */
    static {
        loadKey();
    }

    private static void loadKey() {
	    // PDATACENTER-933 Jar包方式执行时，文件读写方式修正 modify by walter 2019-02-21
        InputStream vndfis = null;
        InputStream cnyfis = null;
        InputStream thbfis = null;
        InputStream usdfis = null;
        try {
            KeyStore ks = KeyStore.getInstance("PKCS12");
            /**
             * 越南盾币种
             */
            // PDATACENTER-845 证书文件位置调整 modify by walter 2018-10-29
            String confDir = AmIRunningInDocker.check()? LoggerConfiguration.p12_path_k8s : LoggerConfiguration.p12_path; // File.separator + System.getProperty("user.dir") + File.separator + PT_KEY_DIR;

            log.info(">>>>>am I in docker? {}  p12_path is {}", AmIRunningInDocker.check(), confDir);
            Resource vndfileResource = new FileSystemResource(confDir + "/pt_vnd.p12");
            // vndfis = PTTransHandle.class.getResourceAsStream("/saconfig/secure/pt_vnd.p12");
	        vndfis = new FileInputStream(vndfileResource.getFile());
            ks.load(vndfis, "vx11NeU3hxYc83XF".toCharArray());
            kmfVND = KeyManagerFactory.getInstance("SunX509");
            kmfVND.init(ks, "vx11NeU3hxYc83XF".toCharArray());
            /**
             * CNY币种
             */
            Resource otherfileResource = new FileSystemResource(confDir + "/pt_cny.p12");
            // otherfis = PTTransHandle.class.getResourceAsStream("/saconfig/secure/pt_cny.p12");
	        cnyfis = new FileInputStream(otherfileResource.getFile());
            ks.load(cnyfis, "MCgtFB39qhSnVc1M".toCharArray());
            kmfCNY = KeyManagerFactory.getInstance("SunX509");
            kmfCNY.init(ks, "MCgtFB39qhSnVc1M".toCharArray());


            /**
             * 泰铢
             */
            Resource thbfileResource = new FileSystemResource(confDir + "/pt_thb.p12");
            thbfis = new FileInputStream(thbfileResource.getFile());
            ks.load(thbfis, "KbW2KKj2Q2NB4U8Q".toCharArray());
            kmfTHB = KeyManagerFactory.getInstance("SunX509");
            kmfTHB.init(ks, "KbW2KKj2Q2NB4U8Q".toCharArray());

            /** 美元 */
            Resource usdfileResource = new FileSystemResource(confDir + "/pt_usd.p12");
            usdfis = new FileInputStream(usdfileResource.getFile());
            ks.load(usdfis, "EMEDLhHPxmmVWkZe".toCharArray());
            kmfUSD = KeyManagerFactory.getInstance("SunX509");
            kmfUSD.init(ks, "EMEDLhHPxmmVWkZe".toCharArray());
        } catch (Exception e) {
            log.error("PT正式加载失败", e);
        } finally {
            if (vndfis != null) {
                try {
                    vndfis.close();
                } catch (Exception e) {
                    log.error("PTTransHandle loadKey vndfis.close() error" + e.getMessage(), e);
                }
            }
            if (cnyfis != null) {
                try {
                    cnyfis.close();
                } catch (Exception e) {
                    log.error("PTTransHandle loadKey otherfis.close() error" + e.getMessage(), e);
                }
            }
        }
    }

    @Override
    public String retrieveData(Map<String, Object> paramaterMap) throws GWCallRemoteApiException {
        String requestUrl = getUrl(paramaterMap);
        log.info("pt trans requestUrl" + requestUrl);
        InputStream in = null;
        String result = "";

        // Begin C07 使用越南盾，所以证书和密码跟其他产品不一样，该字段单独存C07的密码    add by Miles on 2016-07-09
        String currency = (String) paramaterMap.get("currency");
        KeyManagerFactory kmf = null;
        if (CURRENCY_VND.equalsIgnoreCase(currency)) {
            kmf = kmfVND;
        } else if (CURRENCY_CNY.equalsIgnoreCase(currency)){
            kmf = kmfCNY;
        }else if(CURRENCY_THB.equalsIgnoreCase(currency)){
            kmf = kmfTHB;
        }else if (CURRENCY_USD.equalsIgnoreCase(currency)){
            kmf = kmfUSD;
        }
        // End C07 使用越南盾，所以证书和密码跟其他产品不一样，该字段单独存C07的密码    add by Miles on 2016-07-09

        String entity_key = (String) paramaterMap.get("x-entity-key");
        URLConnection yc = null;
        try {
            URL pt = new URL(requestUrl);
            log.info("PT transfer requestUrl:" + requestUrl);
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(kmf.getKeyManagers(), null, null);

            yc = pt.openConnection();
            yc.setReadTimeout(timeOut_PT);
            yc.setConnectTimeout(timeOut_PT);
            yc.setRequestProperty("X_ENTITY_KEY", entity_key);

            ((HttpsURLConnection) yc).setSSLSocketFactory(sc.getSocketFactory());
            in = yc.getInputStream();
            result = IOUtils.toString(in, "UTF-8");
        } catch (Exception e) {
            log.error(e.getMessage() + ",transfer url:" + requestUrl, e);
            throw new GWCallRemoteApiException(e.getMessage());
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (Exception e) {
                }
            }
            if (yc != null) {
                ((HttpsURLConnection) yc).disconnect();
            }
        }
        return result;

    }

    public static void main(String[] args) {
        Map<String, Object> paramaterMap = new HashMap<String, Object>();
        paramaterMap.put("baseUrl", "https://kioskpublicapi.redhorse88.com");
        paramaterMap.put("begintime", "2015-02-12 12:00:00");
        paramaterMap.put("endtime", "2015-02-12 00:00:00");
        paramaterMap.put("page", "1");
        paramaterMap.put("num", "400");
        paramaterMap.put("password", "TGX8BU20");
        paramaterMap.put("agcode",
                "460aea217ec9cddfd0484d35f467f0874c1ce0596db799de63cdf92640eebd6d95b4e21941a0d0bb710420504933a03c0117d41d3a35306c69d0867d1fa3a660");

        AbstractHandle handle = new PTTransHandle();
        try {
            String result = handle.retrieveData(paramaterMap);
            System.out.println(result);
            // System.out.println(handle.parse(result).getOrderList());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public TransRes parse(String content) {
        JSONObject obj = JSONObject.fromObject(content);
        TransRes res = new TransRes();
        JSONObject p_obj = obj.optJSONObject("pagination");
        res.setPerpage(p_obj.optInt("itemsPerPage"));
        res.setTotal(p_obj.optInt("totalCount"));
        JSONArray arr = obj.optJSONArray("result");
        JSONObject trans_obj = null;
        String pidLoginname = "";
        for (int i = 0; i < arr.size(); i++) {
            trans_obj = arr.optJSONObject(i);
            AccountTransferEntity trans = new AccountTransferEntity();
            pidLoginname = trans_obj.optString("PLAYERNAME", "");
            String transferTime = trans_obj.optString("TRANSACTIONTIME", "");

            String prefix = pidLoginname.substring(0, 5);
            if (prefix.toLowerCase().contains("w66")) {
                trans.setUserName(pidLoginname.substring(3).toLowerCase());
                trans.setProductId(UtilConstants.PRODUCT_ENUM.A05.toString());
            } else if (prefix.toLowerCase().contains("kb88")) {
                trans.setUserName(pidLoginname.substring(4).toLowerCase());
                trans.setProductId(UtilConstants.PRODUCT_ENUM.A06.toString());
            } else if (prefix.toLowerCase().contains("am8")) {
                trans.setUserName(pidLoginname.substring(3).toLowerCase());
                trans.setProductId(UtilConstants.PRODUCT_ENUM.C01.toString());
            } else if (prefix.toLowerCase().contains("d88")) {
                trans.setUserName(pidLoginname.substring(3).toLowerCase());
                trans.setProductId(UtilConstants.PRODUCT_ENUM.A04.toString());
            } else if (prefix.toLowerCase().contains("f66")) {
                trans.setUserName(pidLoginname.substring(3).toLowerCase());
                trans.setProductId(UtilConstants.PRODUCT_ENUM.E03.toString());
            } else if (prefix.toLowerCase().contains("h88")) {
                trans.setUserName(pidLoginname.substring(3).toLowerCase());
                trans.setProductId(UtilConstants.PRODUCT_ENUM.E04.toString());
            } else if (prefix.toLowerCase().contains("k8s")) {
                trans.setUserName(pidLoginname.substring(3).toLowerCase());
                trans.setProductId(UtilConstants.PRODUCT_ENUM.B06.toString());
            } else if (prefix.toLowerCase().contains("vk8")) {
                trans.setUserName(pidLoginname.substring(3).toLowerCase());
                trans.setProductId(UtilConstants.PRODUCT_ENUM.C07.toString());
                trans.setCurrency(String.valueOf(UtilConstants.CURRENCY.VND.ordinal()));
            } else if (prefix.toLowerCase().contains("b07")) {
                trans.setUserName(pidLoginname.substring(3).toLowerCase());
                trans.setProductId(UtilConstants.PRODUCT_ENUM.B07.toString());
            } else if (prefix.toLowerCase().contains("v84")){
                trans.setUserName(pidLoginname.substring(3).toLowerCase());
                trans.setProductId(UtilConstants.PRODUCT_ENUM.V84.toString());
                trans.setCurrency(String.valueOf(UtilConstants.CURRENCY.VND.ordinal()));
            } else if (prefix.toLowerCase().contains("av66")){
                trans.setUserName(pidLoginname.substring(4).toLowerCase());
                trans.setProductId(UtilConstants.PRODUCT_ENUM.V66.toString());
                trans.setCurrency(String.valueOf(UtilConstants.CURRENCY.THB.ordinal()));
            } else if (prefix.toLowerCase().contains("aga13")) {
                trans.setUserName(pidLoginname.substring(5).toLowerCase());
                trans.setProductId(UtilConstants.PRODUCT_ENUM.A04.toString());
            } else if (prefix.toLowerCase().contains("aga15")) {
                trans.setUserName(pidLoginname.substring(5).toLowerCase());
                trans.setProductId(UtilConstants.PRODUCT_ENUM.A05.toString());
            } else if (prefix.toLowerCase().contains("aga11")) {
                trans.setUserName(pidLoginname.substring(5).toLowerCase());
                trans.setProductId(UtilConstants.PRODUCT_ENUM.A01.toString());
            } else if (prefix.toLowerCase().contains("aga08")) {
                trans.setUserName(pidLoginname.substring(5).toLowerCase());
                trans.setProductId(UtilConstants.PRODUCT_ENUM.A03.toString());
            } else if (prefix.toLowerCase().contains("aga12")) {
                trans.setUserName(pidLoginname.substring(5).toLowerCase());
                trans.setProductId(UtilConstants.PRODUCT_ENUM.A02.toString());
            } else if (prefix.toLowerCase().contains("aga09")) {
                trans.setUserName(pidLoginname.substring(5).toLowerCase());
                trans.setProductId(UtilConstants.PRODUCT_ENUM.A06.toString());
            } else if (prefix.toLowerCase().contains("aga16")) {
                trans.setUserName(pidLoginname.substring(5).toLowerCase());
                trans.setProductId(UtilConstants.PRODUCT_ENUM.B01.toString());
            } else if (prefix.toLowerCase().contains("aga19")) {
                trans.setUserName(pidLoginname.substring(5).toLowerCase());
                trans.setProductId(UtilConstants.PRODUCT_ENUM.C01.toString());
            } else {
                trans.setUserName(pidLoginname.substring(5).toLowerCase());
                trans.setProductId(pidLoginname.substring(2, 5));
            }

            trans.setAgCode(trans_obj.optString("KIOSKNAME", ""));
            trans.setTime(transferTime);
            trans.setTransferAmount(new BigDecimal(trans_obj.optString("AMOUNT", "0")));
            trans.setIP(trans_obj.optString("REMOTEIP", "0"));
            trans.setTransferType(trans_obj.optString("TYPE", "0"));
//            trans.setTransId(pidLoginname + transferTime.replace("-", "").replace(":", "").replace(" ", ""));
            //transId使用ws的billno    modified by ziv 2018-04-03
            trans.setTransId(trans_obj.optString("EXTERNALTRANSACTIONID", ""));
            res.addOrder(trans);
        }
        return res;
    }

}
