package main.java.com.gw.common.system.parse;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.HttpClientUtils;
import main.java.com.gw.common.framework.util.MD5;
import main.java.com.gw.common.system.parse.vo.Result;
import main.java.com.gw.common.system.parse.vo.TransRes;
import main.java.com.gw.datacenter.accounttransfer.entity.AccountTransferEntity;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;
import java.util.UUID;

@Slf4j
public class QGHandleUtil {

    public static Result<AccountTransferEntity> getQGTransferRecords(String response, String productId, String platformId) {
        Result<AccountTransferEntity> result = new TransRes<>();
        JSONObject json = null;
        if (StringUtils.isNotBlank(response)) {
            try {
                json = JSONObject.parseObject(response);
                String code = json.getString("code");

                if ("200".equals(code)) {
                    JSONObject dataj = json.getJSONObject("data");
                    result.setCode("0");
                    result.setCurrentPage(dataj.getInteger("pageNo"));
                    result.setPerpage(dataj.getInteger("pageSize"));
                    result.setTotal(dataj.getInteger("total"));
                    result.setTotalPages(dataj.getInteger("totalPage"));

                    JSONArray data = dataj.getJSONArray("transferList");
                    if (CollectionUtils.isEmpty(data)) {
                        result.setOrderList(null);
                        return result;
                    }
                    for (int i = 0; i < data.size(); i++) {
                        JSONObject meta = data.getJSONObject(i);
                        // meta为空的不抓
                        if (meta == null || meta.isEmpty()) {
                            continue;
                        }
                        //state不正常的不抓，不为success表明转账还未成功  转账状态:1正常|0无效
                        Integer state = meta.getInteger("transferStatus");
                        if (1 != state) {
                            continue;
                        }
                        Integer transactionType = meta.getInteger("transferType");
                        AccountTransferEntity entity = new AccountTransferEntity();
                        entity.setTransId(meta.getString("clientSn"));   //dc的订单号
                        entity.setTradeNo(meta.getString("serverSn")); //厅方的订单号
                        entity.setCreationTime(new Date(meta.getLong("transferTime")));
                        entity.setProductId(productId);
                        entity.setPlatformId(platformId);
                        entity.setTransferAmount(new BigDecimal(meta.getString("amount")));
                        entity.setPreviousAmount(new BigDecimal(meta.getString("beforeAmount")));
                        entity.setCurrentAmount(new BigDecimal(meta.getString("afterAmount")));
                        if (1 == transactionType || 7 == transactionType) {
                            entity.setTransferType(UtilConstants.TRANSFER_TYPE_IN);
                            entity.setUserName(meta.getString("playerName"));
                        } else if (2 == transactionType || 8 == transactionType) {
                            entity.setTransferType(UtilConstants.TRANSFER_TYPE_OUT);
                            entity.setUserName(meta.getString("playerName"));
                        }
                        result.getOrderList().add(entity);
                    }
                } else {
                    log.info("请求qg转账 getQGTransferData  in HTTP Post,转账记录返回响应code:" + code);
                    result.setCode("-1");
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
                result.setCode("-1");
            }
        } else {
            log.info("请求qg转账 getQGTransferData  in HTTP Post,返回转账记录数据为空:" + response);
        }
        return result;
    }

    public static String getQGTransferData(Map<String, Object> parameterMap, String baseUrl) {
        String response = "";
        //拼接请求参数
        JSONObject json = new JSONObject();
        String merchantCode = (String) parameterMap.get("merchantCode");
        String version = (String) parameterMap.get("version");
        String seqId = UUID.randomUUID().toString(); //用户请求id--时间戳+随机4位小数
        String timestamp = DateUtil.formatDate2Str(new Date());
        json.put("merchantCode", merchantCode);//商户号
        json.put("seqId", seqId);
        json.put("timestamp", timestamp);
        json.put("version", version);
        JSONObject data = new JSONObject();
        data.put("startTime", parameterMap.get("startTime"));
        data.put("endTime", parameterMap.get("endTime"));
        data.put("pageNo", parameterMap.get("pageNo"));
        data.put("pageSize", parameterMap.get("pageSize"));
        data.put("transferTypes", "1,2,7,8"); //转账类型:1用户转入刮刮卡,2玩家转出刮刮卡,7第三方调用转入,8第三方调用转出,多个类型逗号分隔,
        json.put("data", data);

        //加密  1-拼接data，2-拼接非data，3-拼接全部，
        StringBuffer sb = new StringBuffer();
        sb.append("endTime").append(parameterMap.get("endTime"))
                .append("pageNo").append(parameterMap.get("pageNo"))
                .append("pageSize").append(parameterMap.get("pageSize"))
                .append("startTime").append(parameterMap.get("startTime"))
                .append("transferTypes").append("1,2,7,8")
                .append("merchantCode").append(merchantCode)
                .append("seqId").append(seqId)
                .append("timestamp").append(timestamp)
                .append("version").append(version)
                .append(parameterMap.get("key"));
        String sign = MD5.MD5Encode(sb.toString());
        json.put("mac", sign);

        try {
            log.info("qg getQGOrders betApiUrl[" + baseUrl + "] params[" + JSONObject.toJSONString(json));
            response = HttpClientUtils.postJson(baseUrl, null, JSONObject.toJSONString(json));
            log.info(" qg api request to[" + baseUrl + "] with param[ " + JSONObject.toJSONString(json) + " ], got response[" + response + "] ");
        } catch (Exception e) {
            log.info(" 请求qg转账数据出现异常 getQGOrders ERROR in HTTP Post: " + e.getMessage(), e);
        }
        return response;
    }

    public static String getQGAccountDetailData(Map<String, Object> parameterMap, String baseUrl) {
        String response = "";
        //拼接请求参数
        JSONObject json = new JSONObject();
        String merchantCode = (String) parameterMap.get("merchantCode");
        String version = (String) parameterMap.get("version");
        String seqId = UUID.randomUUID().toString();
        String timestamp = DateUtil.formatDate2Str(new Date());
        json.put("merchantCode", merchantCode);
        json.put("seqId", seqId);
        json.put("timestamp", timestamp);
        json.put("version", version);
        JSONObject data = new JSONObject();
        data.put("startTime", parameterMap.get("startTime"));
        data.put("endTime", parameterMap.get("endTime"));
        data.put("pageNo", parameterMap.get("pageNo"));
        data.put("pageSize", parameterMap.get("pageSize"));
        json.put("data", data);
        //加密  1-拼接data，2-拼接非data，3-拼接全部，
        StringBuffer sb = new StringBuffer();
        sb.append("endTime").append(parameterMap.get("endTime"))
                .append("pageNo").append(parameterMap.get("pageNo"))
                .append("pageSize").append(parameterMap.get("pageSize"))
                .append("startTime").append(parameterMap.get("startTime"))
                .append("merchantCode").append(merchantCode)
                .append("seqId").append(seqId)
                .append("timestamp").append(timestamp)
                .append("version").append(version)
                .append(parameterMap.get("key"));
        String sign = MD5.MD5Encode(sb.toString());
        json.put("mac", sign);
        try {
            log.info("qg getActivityRecordData Url:" + baseUrl + " params: " + JSONObject.toJSONString(json));
            response = HttpClientUtils.postJson(baseUrl, null, JSONObject.toJSONString(json));
//            response = "{\"code\":\"200\",\"data\":{\"activityDataRecords\":[{\"afterAmount\":115932,\"beforeAmount\":115432,\"bonus\":500,\"captureTime\":1561963503000,\"player\":\"matt188\",\"playerId\":\"nR0cLCZRBzCBeJvVwAdRvyqn0RUokBFh\",\"transferDate\":1561946732000,\"transferId\":\"JnuJHW98DfXTLixsr15jOzSSlvaFaw7C\"}],\"pageNo\":0,\"pageSize\":500,\"total\":0,\"totalPage\":0},\"describe\":\"\",\"seqId\":\"07267e4d-ba15-4130-87e0-fa58fbf432c0\",\"timestamp\":\"2019-07-2611:13:07\"}";
            log.info(" qg getActivityRecordData request to " + baseUrl + " with param " + JSONObject.toJSONString(json) + " , got response " + response);
        } catch (Exception e) {
            log.info(" getActivityRecordData ERROR in HTTP Post: " + e.getMessage(), e);
        }
        return response;
    }

    public static Result<AccountTransferEntity> getQGActivityPoolRecords(String response, String productId, String platformId) {
        Result<AccountTransferEntity> result = new TransRes<>();
        JSONObject json = null;
        if (StringUtils.isNotBlank(response)) {
            try {
                json = JSONObject.parseObject(response);
                String code = json.getString("code");
                if ("200".equals(code)) {
                    JSONObject dataj = json.getJSONObject("data");
                    result.setCode("0");
                    result.setCurrentPage(dataj.getInteger("pageNo"));
                    result.setPerpage(dataj.getInteger("pageSize"));
                    result.setTotal(dataj.getInteger("total"));
                    result.setTotalPages(dataj.getInteger("totalPage"));
                    JSONArray data = dataj.getJSONArray("activityDataRecords");
                    if (CollectionUtils.isEmpty(data)) {
                        result.setOrderList(null);
                        return result;
                    }
                    for (int i = 0; i < data.size(); i++) {
                        JSONObject meta = data.getJSONObject(i);
                        // meta为空的不抓
                        if (meta == null || meta.isEmpty()) {
                            continue;
                        }
                        AccountTransferEntity entity = new AccountTransferEntity();
                        entity.setTransId(meta.getString("transferId"));
                        entity.setPlatformId(platformId);
                        entity.setUserName(meta.getString("player"));
                        entity.setTransferType("LOTTERY_WIN");
                        entity.setCreationTime(new Date(meta.getLong("transferDate")));
                        entity.setProductId(productId);
                        entity.setTransferAmount(new BigDecimal(meta.getString("bonus")));
                        entity.setPreviousAmount(new BigDecimal(meta.getString("beforeAmount")));
                        entity.setCurrentAmount(new BigDecimal(meta.getString("afterAmount")));
                        entity.setOrignalCreationTime(DateUtil.formatStr2Date(meta.getString("captureTime"), DateUtil.C_TIME_PATTON_DEFAULT));
                        entity.setTransferAccountId(meta.getString("playerId"));
                        result.getOrderList().add(entity);
                    }
                } else {
                    log.info(" qg getActivityRecordData response code:" + code);
                    result.setCode("-1");
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
                result.setCode("-1");
            }
        } else {
            log.info(" qg getActivityRecordData response null :" + response);
        }
        return result;
    }
}
