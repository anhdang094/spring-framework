package main.java.com.gw.common.system.parse;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.common.system.parse.vo.OrderRes;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.digester3.Digester;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

@Slf4j
public class RGSOrderHandle extends AbstractHandle {

    @Override
    public String getUrl(Map<String, Object> paramaterMap) {

        String baseUrl = (String) paramaterMap.get("baseUrl");
        String begintime = (String) paramaterMap.get("begintime");
        String endtime = (String) paramaterMap.get("endtime");
        String rounddate = begintime.substring(0, 10);
        String page = (String) paramaterMap.get("page");
        String pagelimit = (String) paramaterMap.get("num");
        String productId = (String) paramaterMap.get("productId");
        Map<String, String> pMap = new HashMap<String, String>();
        pMap.put("rounddate", rounddate);
        pMap.put("starttime", begintime.substring(11, begintime.length()));
        pMap.put("endtime", endtime.substring(11, endtime.length()));
        pMap.put("page", page);
        pMap.put("pagelimit", pagelimit);
        pMap.put("key", "123456");
        pMap.put("productId", productId);

        StringBuilder sb = new StringBuilder();
        for (Iterator<String> iterator = pMap.keySet().iterator(); iterator.hasNext(); ) {
            String key = iterator.next();
            sb.append("&" + key + "=" + pMap.get(key));
        }

        String uri = sb.substring(1, sb.length());
        return baseUrl + "?" + uri;
    }

    @Override
    public String retrieveData(String url, Map<String, Object> paramaterMap) throws GWCallRemoteApiException {
        String content = "";
        try {
            String tUrl = getUrl(paramaterMap);
            log.info("retrieve rgs data url:" + tUrl);
            content = new HttpUtil().doGet(tUrl);
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new GWCallRemoteApiException("Failed to call remote interface!" + ex.getMessage(), ex);
        }
        return content;

    }

    public static void main(String[] args) {
        Map<String, Object> paramaterMap = new HashMap<String, Object>();
        String baseUrl = "http://10.5.5.76:8080/commonwallet_datacenter/RGSBetRecord.do?";
        String begintime = "2015-09-29 00:00:00";
        String endtime = "2015-09-29 23:59:59";
        String rounddate = "2015-09-29";
        paramaterMap.put("baseUrl", baseUrl);
        paramaterMap.put("rounddate", rounddate);
        paramaterMap.put("begintime", begintime);
        paramaterMap.put("endtime", endtime);
        String page = "1";
        paramaterMap.put("page", page);
        String num = "20";
        paramaterMap.put("num", num);
        paramaterMap.put("key", "121");
        AbstractHandle handle = new RGSOrderHandle();
        try {
            String result = handle.retrieveData(baseUrl, paramaterMap);
            OrderRes res = (OrderRes) handle.parse(result);
            System.out.println(res.getOrderList());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void parseRules(Digester d) {
        d.addObjectCreate("Data", OrderRes.class);
        d.addSetProperties("Data", "PageLimit", "perpage");
        d.addSetProperties("Data", "TotalNumber", "total");
        d.addSetProperties("Data", "Page", "numpage");
        d.addObjectCreate("Data/Record", OrderEntity.class);
        d.addSetNext("Data/Record", "addOrder");
        d.addBeanPropertySetter("Data/Record/WagersID", "billNo");
        d.addBeanPropertySetter("Data/Record/BeforeBalance", "previosAmount");
        d.addBeanPropertySetter("Data/Record/Commissionable", "validAccount");
        d.addBeanPropertySetter("Data/Record/BetAmount", "account");
        d.addBeanPropertySetter("Data/Record/CurrentBalance", "currentAmount");
        d.addBeanPropertySetter("Data/Record/Payoff", "cusAccount");
        d.addBeanPropertySetter("Data/Record/ProductID", "productId");
        d.addBeanPropertySetter("Data/Record/UserName", "loginName");
        d.addBeanPropertySetter("Data/Record/Currency", "currency");
        d.addBeanPropertySetter("Data/Record/GameCode", "gameType");
        d.addBeanPropertySetter("Data/Record/ResultType", "resultType");
        d.addBeanPropertySetter("Data/Record/Result", "result");
        //API抓取的数据是北京时间
        d.addCallMethod("Data/Record/WagersDate", "setTime", 1);
        d.addCallParam("Data/Record/WagersDate", 0);
    }
//	

}
