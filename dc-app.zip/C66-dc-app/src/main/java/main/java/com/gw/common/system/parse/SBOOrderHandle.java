package main.java.com.gw.common.system.parse;

import com.google.gson.Gson;
import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.HttpClientUtils;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.entity.SBOOrderEntity;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.lang3.StringUtils;


import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Slf4j
public class SBOOrderHandle {

    private static final Gson gson = new Gson();

    public static void main(String[] args) throws IOException {
        /*
        String result = "{\"data\":{\"action_result\":\"Success\",\"betlogs\":[],\"total\":0,\"start_time\":\"1612519210000\",\"end_time\":\"1612519220000\",\"page\":1,\"page_count\":0},\"error\":null}";
        SBOOrderEntity sboOrderEntity = gson.fromJson(result, SBOOrderEntity.class);
        System.out.println(sboOrderEntity);
         */
/*
        Map<String, Object> parameterMap = new HashMap<>();
        parameterMap.put("password", "77a0e4a4d52f5623d38f36bebd04082f;33a4314139d66af0aca6b614872d1ad2");
        parameterMap.put("productId", "C07");
//        parameterMap.put("row_version", "0");
        parameterMap.put("count", "20000");
//        parameterMap.put(UtilConstants.ALLOCATION_WEBSITE, "0");
        parameterMap.put(UtilConstants.ALLOCATION_WEBSITE, "1583828454000");
        Map<String, List<Object>> sboOrderMap = new SBOOrderHandle().getSBOOrderRecord("http://k8v.test.gf-gaming.com/gf/Bet/Record/Get", parameterMap);
        System.out.println(sboOrderMap);
 */
    }

    public Map<String, List<Object>> getSBOOrderRecord(String url, Map<String, Object> parameterMap) throws IOException {
        log.info("trying to getSBOOrderRecord, url: {}", url);
        Map<String, List<Object>> sboOrderMap = new HashMap<>();
        log.info("sbo getSBOOrderRecord parameter Map = {}", gson.toJson(parameterMap));
        String[] sboParam = ((String) parameterMap.get("password")).split(";");
        String operator_token = sboParam[0];
        String secret_key = sboParam[1];
        String row_version = (String)parameterMap.get(UtilConstants.ALLOCATION_WEBSITE);
        if (StringUtils.isBlank(row_version)){
            row_version = "0";
        }

        Map<String, String> requestParams = new HashMap<>();
        requestParams.put("operator_token", operator_token);
        requestParams.put("secret_key", secret_key);
        requestParams.put("row_version", row_version);
        requestParams.put("count", (String) parameterMap.get("num"));
        requestParams.put("vendor_code", "SBO");

        log.info("sbo getSBOOrderRecord request Params = {}", requestParams);
        String result = HttpClientUtils.execPost(url, requestParams);
        if (ToolUtil.isNeedInterceptResponse(parameterMap.get(UtilConstants.ORDER_TASK_ID) + "")) {
            log.info("Intercept:TaskId=" + parameterMap.get(UtilConstants.ORDER_TASK_ID) + ",Url=" + url + ",Response=" + result);
        }
        if (StringUtils.isEmpty(result)) {
            log.info("getSBOOrderRecord sbo log, response no data, request params:" + parameterMap);
            return sboOrderMap;
        }
//        String result = "{\"data\":{\"action_result\":\"Success\",\"betlogs\":[{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003059\",\"bet_id\":\"4003059\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":54,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454057,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003059-1583828454054\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003052\",\"bet_id\":\"4003052\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":74.25,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454292,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003052-1583828454290\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003045\",\"bet_id\":\"4003045\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":80.1,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454113,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003045-1583828454110\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003048\",\"bet_id\":\"4003048\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":45,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454769,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003048-1583828454767\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003058\",\"bet_id\":\"4003058\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":45.9,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454382,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003058-1583828454379\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003057\",\"bet_id\":\"4003057\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":66.6,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454743,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003057-1583828454741\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003061\",\"bet_id\":\"4003061\",\"trans_type\":\"Stake\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":80,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454303,\"traceId\":\"nnhungv_K8V::SBO::STAKE::4003061-1583828454300\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003062\",\"bet_id\":\"4003062\",\"trans_type\":\"Stake\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":80,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454220,\"traceId\":\"nnhungv_K8V::SBO::STAKE::4003062-1583828454217\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003054\",\"bet_id\":\"4003054\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454845,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003054-1583828454841\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003056\",\"bet_id\":\"4003056\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454078,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003056-1583828454071\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003046\",\"bet_id\":\"4003046\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":76.5,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454780,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003046-1583828454776\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003047\",\"bet_id\":\"4003047\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454211,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003047-1583828454206\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003053\",\"bet_id\":\"4003053\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":78.75,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454664,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003053-1583828454662\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003060\",\"bet_id\":\"4003060\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454800,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003060-1583828454797\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003062\",\"bet_id\":\"4003062\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454077,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003062-1583828454073\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003055\",\"bet_id\":\"4003055\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454082,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003055-1583828454079\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003061\",\"bet_id\":\"4003061\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454961,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003061-1583828454955\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003050\",\"bet_id\":\"4003050\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":79.2,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454412,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003050-1583828454409\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003038\",\"bet_id\":\"4003038\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":42.9,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454134,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003038-1583828454130\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003033\",\"bet_id\":\"4003033\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":52.8,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454217,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003033-1583828454215\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003036\",\"bet_id\":\"4003036\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454636,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003036-1583828454633\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003037\",\"bet_id\":\"4003037\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454755,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003037-1583828454753\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003035\",\"bet_id\":\"4003035\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454655,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003035-1583828454651\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003049\",\"bet_id\":\"4003049\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454783,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003049-1583828454780\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003034\",\"bet_id\":\"4003034\",\"trans_type\":\"Stake\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":-30,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454418,\"traceId\":\"nnhungv_K8V::SBO::CANCELBET::4003034-1583828454418\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003046\",\"bet_id\":\"4003046\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":-76.5,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454732,\"traceId\":\"nnhungv_K8V::SBO::ROLLBACK::4003046-1583828454732\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003051\",\"bet_id\":\"4003051\",\"trans_type\":\"Stake\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":-45,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454382,\"traceId\":\"nnhungv_K8V::SBO::CANCELBET::4003051-1583828454382\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003046\",\"bet_id\":\"4003046\",\"trans_type\":\"Stake\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":-45,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454394,\"traceId\":\"nnhungv_K8V::SBO::CANCELBET::4003046-1583828454394\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003047\",\"bet_id\":\"4003047\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454535,\"traceId\":\"nnhungv_K8V::SBO::ROLLBACK::4003047-1583828454535\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003061\",\"bet_id\":\"4003061\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454675,\"traceId\":\"nnhungv_K8V::SBO::ROLLBACK::4003061-1583828454675\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003047\",\"bet_id\":\"4003047\",\"trans_type\":\"Stake\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":-45,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454565,\"traceId\":\"nnhungv_K8V::SBO::CANCELBET::4003047-1583828454565\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003061\",\"bet_id\":\"4003061\",\"trans_type\":\"Stake\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":-80,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454742,\"traceId\":\"nnhungv_K8V::SBO::CANCELBET::4003061-1583828454742\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003061\",\"bet_id\":\"4003061\",\"trans_type\":\"Stake\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":80,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454634,\"traceId\":\"nnhungv_K8V::SBO::ROLLBACK::4003061-1583828454634\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003047\",\"bet_id\":\"4003047\",\"trans_type\":\"Stake\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":45,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454376,\"traceId\":\"nnhungv_K8V::SBO::ROLLBACK::4003047-1583828454376\"}],\"last_record_time\":1583828454000},\"error\":null}";
        log.info(">> SBO >> get sbo order record,Url[" + url + "], result:" + result);
        SBOOrderEntity sboOrderEntity = gson.fromJson(result, SBOOrderEntity.class);

        if (sboOrderEntity.getError() != null){
            log.error(">> SBO >> get sbo order record response contains error, code: {}, message: {}", sboOrderEntity.getError().getCode(), sboOrderEntity.getError().getMessage());
            return sboOrderMap;
        }

        sboOrderEntity.getData().getBetlogs().sort(new Comparator<SBOOrderEntity.BetLog>() {
            @Override
            public int compare(SBOOrderEntity.BetLog o1, SBOOrderEntity.BetLog o2) {
                return Long.valueOf(o1.getCreated_at()).compareTo(Long.valueOf(o2.getCreated_at()));
            }
        });

        List<Object> stakeOrderEntityList = new ArrayList<>();
        List<Object> updateOrderEntityList = new ArrayList<>();
        sboOrderEntity.getData().getBetlogs().forEach(betLog -> {
            betLog.setProduct_id(parameterMap.get("productId").toString());

            OrderEntity orderEntity = this.transfer(betLog);
            if (Objects.equals("Stake", betLog.getTrans_type()) && Objects.equals("Pending", orderEntity.getResult())){
                stakeOrderEntityList.add(orderEntity);
            } else {
                updateOrderEntityList.add(orderEntity);
            }
        });
        sboOrderMap.put("stake", stakeOrderEntityList);
        sboOrderMap.put("update", updateOrderEntityList);

        if (sboOrderEntity.getData().getLast_record_time() != null){
            parameterMap.put(UtilConstants.ALLOCATION_WEBSITE, sboOrderEntity.getData().getLast_record_time());
        }
        return sboOrderMap;
    }

    private OrderEntity transfer (SBOOrderEntity.BetLog betLog){
        OrderEntity orderEntity = new OrderEntity();
        orderEntity.setLoginName(betLog.getPlayer_name());
        orderEntity.setBillNo(betLog.getBet_id());
        orderEntity.setProductId(betLog.getProduct_id());
        orderEntity.setPlatId(UtilConstants.SBO);
        orderEntity.setCurrency(betLog.getCurrency());
        orderEntity.setGmCode(betLog.getBet_id());
        orderEntity.setGameKind(UtilConstants.GAME_KIND_ENUM.BALL.getCode());
        orderEntity.setDeviceType("0");
        orderEntity.setCreationDate(new Date());

        BigDecimal betAmount = new BigDecimal(betLog.getBet_amount());
        BigDecimal winAmount = new BigDecimal(betLog.getWin_amount());
        orderEntity.setAccount(betAmount);
        long timestamp = Long.parseLong(betLog.getCreated_at());
        String trans_type = betLog.getTrans_type();
        if (Objects.equals("Stake", trans_type)){
            if (betAmount.compareTo(BigDecimal.ZERO) > 0){ // 投注
                orderEntity.setBillTime(new Date(timestamp));
                orderEntity.setResult("Pending");
                orderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.UNSETTLED.getFalg());
                orderEntity.setValidAccount(BigDecimal.ZERO);
                orderEntity.setRemainAmount(BigDecimal.ZERO);
            } else { // 取消投注
                orderEntity.setResult("Cancelled");
                orderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.CANCELED.getFalg());
                orderEntity.setValidAccount(BigDecimal.ZERO);
                orderEntity.setRemainAmount(BigDecimal.ZERO);
            }
        } else if (Objects.equals("Payoff", trans_type)){
            if (winAmount.compareTo(BigDecimal.ZERO) >= 0){
                orderEntity.setReckonTime(new Date(timestamp));
                orderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.SETTLED.getFalg());
                orderEntity.setCusAccount(winAmount);
            } else {
                orderEntity.setReckonTime(null);
                orderEntity.setResult("Pending");
                orderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.UNSETTLED.getFalg());
                orderEntity.setValidAccount(BigDecimal.ZERO);
                orderEntity.setRemainAmount(BigDecimal.ZERO);
            }
        } else {
            //正常不会走这个分支
            orderEntity.setFlag(0);
            orderEntity.setValidAccount(BigDecimal.ZERO);
        }

        return orderEntity;
    }

    public static int cacul(BigDecimal winLoseAmount, BigDecimal betAmount) {
        return winLoseAmount.divide(betAmount, 2, RoundingMode.DOWN).setScale(2, RoundingMode.DOWN).compareTo(new BigDecimal("0.5"));
    }

    /**
     * 使用新的SBO廳方抓注單接口, /v3/Bet/Record/Get
     * @param url
     * @param parameterMap
     * @return
     * @throws IOException
     */
    public Map<String, List<Object>> getSBOOrderRecordV3(String url, Map<String, Object> parameterMap) throws IOException {
        log.info("trying to getSBOOrderRecordV3, url: {}", url);
        Map<String, List<Object>> sboOrderMap = new HashMap<>();
        log.info(parameterMap.get(UtilConstants.ORDER_TASK_ID) + "sbo getSBOOrderRecordV3 parameter Map = {}", gson.toJson(parameterMap));
        String[] sboParam = ((String) parameterMap.get("password")).split(";");
        String operator_token = sboParam[0];
        String secret_key = sboParam[1];
        Integer page = 1;
        String pageSize = getPageSize(parameterMap);

        Map<String, String> requestParams = new HashMap<>();
        requestParams.put("secret_key", secret_key);
        requestParams.put("operator_token", operator_token);
        requestParams.put("vendor_code", "SBO");
        requestParams.put("start_time", parseDateTime(String.valueOf(parameterMap.get(UtilConstants.ORDER_BEGIN_TIME))));
        requestParams.put("end_time", parseDateTime(String.valueOf(parameterMap.get(UtilConstants.ORDER_END_TIME))));
        requestParams.put("page", page.toString());
        requestParams.put("page_size", pageSize); // 1000-2000
        log.info(parameterMap.get(UtilConstants.ORDER_TASK_ID) + " sbo getSBOOrderRecordV3 request Params = {}", requestParams);
        String result = HttpClientUtils.execPost(url, requestParams);
        if (ToolUtil.isNeedInterceptResponse(parameterMap.get(UtilConstants.ORDER_TASK_ID) + "")) {
            log.info("Intercept:TaskId=" + parameterMap.get(UtilConstants.ORDER_TASK_ID) + ",Url=" + url + ",Response=" + result);
        }
        if (StringUtils.isEmpty(result)) {
            log.info("getSBOOrderRecordV3 sbo log, response no data, request params:" + parameterMap);
            return sboOrderMap;
        }
//        String result = "{\"data\":{\"action_result\":\"Success\",\"betlogs\":[{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003059\",\"bet_id\":\"4003059\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":54,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454057,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003059-1583828454054\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003052\",\"bet_id\":\"4003052\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":74.25,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454292,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003052-1583828454290\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003045\",\"bet_id\":\"4003045\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":80.1,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454113,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003045-1583828454110\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003048\",\"bet_id\":\"4003048\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":45,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454769,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003048-1583828454767\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003058\",\"bet_id\":\"4003058\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":45.9,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454382,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003058-1583828454379\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003057\",\"bet_id\":\"4003057\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":66.6,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454743,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003057-1583828454741\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003061\",\"bet_id\":\"4003061\",\"trans_type\":\"Stake\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":80,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454303,\"traceId\":\"nnhungv_K8V::SBO::STAKE::4003061-1583828454300\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003062\",\"bet_id\":\"4003062\",\"trans_type\":\"Stake\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":80,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454220,\"traceId\":\"nnhungv_K8V::SBO::STAKE::4003062-1583828454217\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003054\",\"bet_id\":\"4003054\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454845,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003054-1583828454841\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003056\",\"bet_id\":\"4003056\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454078,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003056-1583828454071\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003046\",\"bet_id\":\"4003046\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":76.5,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454780,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003046-1583828454776\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003047\",\"bet_id\":\"4003047\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454211,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003047-1583828454206\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003053\",\"bet_id\":\"4003053\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":78.75,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454664,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003053-1583828454662\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003060\",\"bet_id\":\"4003060\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454800,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003060-1583828454797\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003062\",\"bet_id\":\"4003062\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454077,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003062-1583828454073\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003055\",\"bet_id\":\"4003055\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454082,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003055-1583828454079\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003061\",\"bet_id\":\"4003061\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454961,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003061-1583828454955\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003050\",\"bet_id\":\"4003050\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":79.2,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454412,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003050-1583828454409\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003038\",\"bet_id\":\"4003038\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":42.9,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454134,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003038-1583828454130\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003033\",\"bet_id\":\"4003033\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":52.8,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454217,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003033-1583828454215\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003036\",\"bet_id\":\"4003036\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454636,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003036-1583828454633\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003037\",\"bet_id\":\"4003037\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454755,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003037-1583828454753\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003035\",\"bet_id\":\"4003035\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454655,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003035-1583828454651\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003049\",\"bet_id\":\"4003049\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454783,\"traceId\":\"nnhungv_K8V::SBO::PAYOFF::4003049-1583828454780\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003034\",\"bet_id\":\"4003034\",\"trans_type\":\"Stake\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":-30,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454418,\"traceId\":\"nnhungv_K8V::SBO::CANCELBET::4003034-1583828454418\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003046\",\"bet_id\":\"4003046\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":-76.5,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454732,\"traceId\":\"nnhungv_K8V::SBO::ROLLBACK::4003046-1583828454732\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003051\",\"bet_id\":\"4003051\",\"trans_type\":\"Stake\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":-45,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454382,\"traceId\":\"nnhungv_K8V::SBO::CANCELBET::4003051-1583828454382\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003046\",\"bet_id\":\"4003046\",\"trans_type\":\"Stake\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":-45,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454394,\"traceId\":\"nnhungv_K8V::SBO::CANCELBET::4003046-1583828454394\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003047\",\"bet_id\":\"4003047\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454535,\"traceId\":\"nnhungv_K8V::SBO::ROLLBACK::4003047-1583828454535\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003061\",\"bet_id\":\"4003061\",\"trans_type\":\"Payoff\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":0,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454675,\"traceId\":\"nnhungv_K8V::SBO::ROLLBACK::4003061-1583828454675\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003047\",\"bet_id\":\"4003047\",\"trans_type\":\"Stake\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":-45,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454565,\"traceId\":\"nnhungv_K8V::SBO::CANCELBET::4003047-1583828454565\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003061\",\"bet_id\":\"4003061\",\"trans_type\":\"Stake\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":-80,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454742,\"traceId\":\"nnhungv_K8V::SBO::CANCELBET::4003061-1583828454742\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003061\",\"bet_id\":\"4003061\",\"trans_type\":\"Stake\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":80,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454634,\"traceId\":\"nnhungv_K8V::SBO::ROLLBACK::4003061-1583828454634\"},{\"player_name\":\"nnhungv\",\"parent_bet_id\":\"4003047\",\"bet_id\":\"4003047\",\"trans_type\":\"Stake\",\"game_code\":\"sbo_1\",\"currency\":\"VND\",\"bet_amount\":45,\"win_amount\":0,\"vendor_code\":\"SBO\",\"wallet_code\":\"gf_sport_wallet\",\"created_at\":1583828454376,\"traceId\":\"nnhungv_K8V::SBO::ROLLBACK::4003047-1583828454376\"}],\"last_record_time\":1583828454000},\"error\":null}";
        log.info(parameterMap.get(UtilConstants.ORDER_TASK_ID) + " >> SBO getSBOOrderRecordV3 >> get sbo order record,Url[" + url + "], result:" + result);
        SBOOrderEntity sboOrderEntity = gson.fromJson(result, SBOOrderEntity.class);

        if (sboOrderEntity.getError() != null){
            log.error(parameterMap.get(UtilConstants.ORDER_TASK_ID) + " >> SBO getSBOOrderRecordV3 >> get sbo order record response contains error, code: {}, message: {}", sboOrderEntity.getError().getCode(), sboOrderEntity.getError().getMessage());
            return sboOrderMap;
        }

        if (sboOrderEntity.getData().getPage_count().compareTo(page) == 1) {
            Integer totalPage = sboOrderEntity.getData().getPage_count();
            while (page.compareTo(totalPage) == -1) {
                page++;
                requestParams.put("page", page.toString());
                result = HttpClientUtils.execPost(url, requestParams);
                SBOOrderEntity sboOrderEntityByPage = gson.fromJson(result, SBOOrderEntity.class);
                if (sboOrderEntityByPage.getError() != null) {
                    log.error(parameterMap.get(UtilConstants.ORDER_TASK_ID) + " >> SBO getSBOOrderRecordV3 >> get sbo order record By page response contains error, code: {}, message: {}", sboOrderEntityByPage.getError().getCode(), sboOrderEntityByPage.getError().getMessage());
                    throw new IOException("TASK_ID = " + parameterMap.get(UtilConstants.ORDER_TASK_ID) +  "get sbo order record fail.");
                }
                sboOrderEntity.getData().getBetlogs().addAll(sboOrderEntityByPage.getData().getBetlogs());
            }
        }

        sboOrderEntity.getData().getBetlogs().sort(new Comparator<SBOOrderEntity.BetLog>() {
            @Override
            public int compare(SBOOrderEntity.BetLog o1, SBOOrderEntity.BetLog o2) {
                return Long.valueOf(o1.getCreated_at()).compareTo(Long.valueOf(o2.getCreated_at()));
            }
        });

        List<Object> stakeOrderEntityList = new ArrayList<>();
        List<Object> updateOrderEntityList = new ArrayList<>();
        sboOrderEntity.getData().getBetlogs().forEach(betLog -> {
            betLog.setProduct_id(parameterMap.get("productId").toString());

            OrderEntity orderEntity = this.transfer(betLog);
            if (Objects.equals("Stake", betLog.getTrans_type()) && Objects.equals("Pending", orderEntity.getResult())){
                stakeOrderEntityList.add(orderEntity);
            } else {
                updateOrderEntityList.add(orderEntity);
            }
        });
        sboOrderMap.put("stake", stakeOrderEntityList);
        sboOrderMap.put("update", updateOrderEntityList);

        if (sboOrderEntity.getData().getLast_record_time() != null){
            parameterMap.put(UtilConstants.ALLOCATION_WEBSITE, sboOrderEntity.getData().getLast_record_time());
        }
        return sboOrderMap;
    }

    private String parseDateTime(String datetime) {
        // DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        // return String.valueOf(Date.from(LocalDateTime.parse(datetime, dateTimeFormatter).atZone(ZoneId.of("+8")).toInstant()).getTime());

        return String.valueOf(DateUtil.formatStr2Date(datetime).getTime());
    }

    private String getPageSize(Map<String, Object> parameterMap) {
        // SBO接口限制1000-2000
        final String defaultMax = "2000";
        final String defaultMin = "1000";
        if (Objects.isNull(parameterMap.get("pageSize"))) return defaultMax;

        String size = String.valueOf(parameterMap.get("pageSize"));
        if (Integer.valueOf(defaultMax).compareTo(Integer.valueOf(size)) == -1) return defaultMax;
        if (Integer.valueOf(defaultMin).compareTo(Integer.valueOf(size)) == 1) return defaultMin;

        return size;
    }
}
