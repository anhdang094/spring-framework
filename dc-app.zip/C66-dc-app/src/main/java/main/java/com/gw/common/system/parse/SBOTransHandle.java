package main.java.com.gw.common.system.parse;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.HttpClientUtils;
import main.java.com.gw.common.framework.util.PBSignature;
import main.java.com.gw.common.system.entity.SBOOrderEntity;
import main.java.com.gw.common.system.parse.vo.PBTransferData;
import main.java.com.gw.common.system.parse.vo.SBOTransferData;
import main.java.com.gw.datacenter.accounttransfer.entity.AccountTransferEntity;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
public class SBOTransHandle {

    private static final Gson gson = new Gson();

    public static void main(String[] args) throws IOException {
        Map<String, Object> parameterMap = new HashMap<>();
        parameterMap.put("password", "77a0e4a4d52f5623d38f36bebd04082f;33a4314139d66af0aca6b614872d1ad2");
        parameterMap.put("productId", "C07");
//        parameterMap.put("row_version", "0");
        parameterMap.put("count", "20000");
        parameterMap.put("num", "20000");
//        parameterMap.put(UtilConstants.ALLOCATION_WEBSITE, "0");
        parameterMap.put(UtilConstants.ALLOCATION_WEBSITE, "1583829513018");
        List<AccountTransferEntity> accountTransferEntityList = new SBOTransHandle().getSBOTransferRecords("http://k8v.test.gf-gaming.com/gf/Transaction/Record/Get", parameterMap);
        System.out.println(accountTransferEntityList);
    }

    public List<AccountTransferEntity> getSBOTransferRecords (String url, Map<String, Object> parameterMap) throws IOException {
        String[] sboParam = ((String) parameterMap.get("password")).split(";");
        String operator_token = sboParam[0];
        String secret_key = sboParam[1];
        String start_time = (String)parameterMap.get(UtilConstants.ALLOCATION_WEBSITE);
        if (StringUtils.isBlank(start_time)){
            start_time = "0";
        }

        Map<String, String> requestParams = new HashMap<>();
        requestParams.put("operator_token", operator_token);
        requestParams.put("secret_key", secret_key);
        requestParams.put("start_time", start_time);
        requestParams.put("count", (String) parameterMap.get("num"));
        requestParams.put("wallet_code", "gf_sport_wallet");

        String result = HttpClientUtils.execPost(url, requestParams);
        SBOTransferData sboTransferData = gson.fromJson(result, SBOTransferData.class);

        List<AccountTransferEntity> accountTransferEntityList = new ArrayList<>();
        if (sboTransferData.getError() != null){
            log.error(">> SBO >> get sbo transfer record response contains error, code: {}, message: {}", sboTransferData.getError().getCode(), sboTransferData.getError().getMessage());
            return accountTransferEntityList;
        }

        String productId = parameterMap.get("productId").toString();
        accountTransferEntityList = sboTransferData.getData().getTranslogs().stream()
                .filter(sboTransferLog -> Objects.equals("transferIn", sboTransferLog.getType()) || Objects.equals("transferOut", sboTransferLog.getType()))
                .map(sboTransferLog -> {
            AccountTransferEntity accountTransferEntity = new AccountTransferEntity();
            accountTransferEntity.setTransId(sboTransferLog.getTraceId());
            accountTransferEntity.setUserName(sboTransferLog.getPlayer_name());
            accountTransferEntity.setCreationTime(new Date(Long.parseLong(sboTransferLog.getCreated_at())));
            accountTransferEntity.setProductId(productId);
            accountTransferEntity.setPlatformId(UtilConstants.SBO);
            accountTransferEntity.setCurrency(sboTransferLog.getCurrency());
            accountTransferEntity.setTransferAmount(new BigDecimal(sboTransferLog.getAmount()));
            accountTransferEntity.setPreviousAmount(new BigDecimal(sboTransferLog.getBefore_balance()));
            accountTransferEntity.setCurrentAmount(new BigDecimal(sboTransferLog.getBalance()));
            if (Objects.equals("transferIn", sboTransferLog.getType())){
                accountTransferEntity.setTransferType(UtilConstants.TRANSFER_TYPE_IN);
            } else {
                accountTransferEntity.setTransferType(UtilConstants.TRANSFER_TYPE_OUT);
            }
            return accountTransferEntity;
        }).collect(Collectors.toList());

        if (sboTransferData.getData().getLast_record_time() != null){
            parameterMap.put(UtilConstants.ALLOCATION_WEBSITE, sboTransferData.getData().getLast_record_time());
        }
        return accountTransferEntityList;
    }

}
