package main.java.com.gw.common.system.parse;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.constant.UtilConstants.SBT_TRANSFER_ENUM;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.common.framework.util.JsonUtil;
import main.java.com.gw.common.framework.util.ObjectConstructUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.entity.SBTCreditEntity;
import main.java.com.gw.common.system.entity.SBTOrderEntity;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Slf4j
public class SBTOrderHandle {


    public static void main(String args[]) {
//		 SBTOrderHandle sbt=new SBTOrderHandle();
//		 String url="http://localhost:8080/commonwallet_datacenter/SBTRecord.do";
//		 Map<String, Object> param=new HashMap<>();
//		 param.put("begintime", "2016-09-10 00:00:00");
//		 param.put("endtime", "2017-06-05 00:00:00");
//		 param.put("collectionType", "GROUP_SBT_CREDIT");
//		 param.put("productId", "C07");
//		 try {
//			sbt.getSBTCreditRecord(url, param);
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		 
//		 System.out.println("-------------");

        checkData();
    }


    public static void checkData() {
        String tt = "{\"code\":\"success\",\"data\":[{\"createTime\":\"2017-05-10 15:41:34\",\"currency\":\"CNY\","
                + "\"currentBalance\":95,\"loginName\":\"A01gtina\",\"previousBalance\":95,\"productId\":\"A01\",\"tran"
                + "sId\":\"67943713\",\"transactionId\":\"85\",\"transferAmount\":0},{\"createTime\":\"2017-05-10 15:55:11\",\"cur"
                + "rency\":\"CNY\",\"currentBalance\":85,\"loginName\":\"A01gtina\",\"previousBalance\":95.6,\"productId\":\"A01\",\"tr"
                + "ansId\":\"67945189\",\"transactionId\":\"86\",\"transferAmount\":-10.5},{\"creat"
                + "eTime\":\"2017-05-10 15:55:33\",\"currency\":\"CNY\",\"currentBalance\":85,\"loginName\":\"A01g"
                + "tina\",\"previousBalance\":85,\"productId\":\"A01\",\"transId\":\"67945189\",\"transactionId\":\"88\",\"transferA"
                + "mount\":0},{\"createTime\":\"2017-05-10 15:41:08\",\"currency\":\"CNY\",\"currentBalance\":95,\"loginName\":\"A01gtina\",\"pre"
                + "viousBalance\":100,\"productId\":\"A01\",\"transId\":\"67943713\",\"transactionId\":\"83\",\"transferAmount\":-5}]}";
        System.out.println(tt);
//		 
//		 JSONObject object = JsonUtil.StringToJSONOBject(tt);
//			
//			JSONArray dataList = object.getJSONArray("data");
//			if(dataList == null || dataList.isEmpty()){
//				return;
//			}
//			for (int i = 0; i < dataList.size(); i++) {
//				JSONObject object2 = dataList.getJSONObject(i);
//				SBTCreditEntity bean = (SBTCreditEntity) JSONObject.toBean(object2, SBTCreditEntity.class);
//				String name = bean.getLoginName();
//				String productId = bean.getProductId();
//				String prefix = name.substring(0, productId.length());
//				if(StringUtils.equals(productId, prefix)){
//					name = name.substring(productId.length(), name.length());
//					bean.setLoginName(name);
//				}
//				Date date = DateUtil.formatStr2Date(bean.getCreateTime());
//				if(date != null){
//					bean.setCreateDate(date);
//				}
//				if(bean.getCurrentBalance() == null){
//					bean.setCurrentBalance(BigDecimal.ZERO);
//				}
//				System.out.println(bean.getCurrency());
//				System.out.println(bean.getCurrentBalance());
//				System.out.println(bean.getPreviousBalance());
//				System.out.println(bean.getTransferAmount());
//				System.out.println(bean.getLoginName());
//			}
    }


    public List<SBTCreditEntity> getSBTCreditRecord(String url, Map<String, Object> parameterMap) throws IOException {

        HttpUtil http = new HttpUtil();
        List<SBTCreditEntity> list = new ArrayList<>();
        String result = "";

        result = http.doPost(url, parameterMap);
        // Add interception to retrieve Response
        if (ToolUtil.isNeedInterceptResponse(parameterMap.get(UtilConstants.ORDER_TASK_ID) + "")) {
            log.info("Intercept:TaskId=" + parameterMap.get(UtilConstants.ORDER_TASK_ID) + ",Url=" + url + ",Response=" + result);
        }
        if (StringUtils.isEmpty(result)) {
            log.info("request sbt log, resonse empty, request params:" + parameterMap);
            return list;
        }
        log.info(">> SBT >> get sbt crecdit record result:" + result);
        JSONObject object = JsonUtil.StringToJSONOBject(result);

        JSONArray dataList = object.getJSONArray("data");
        if (dataList == null || dataList.isEmpty()) {
            log.info("getSBTCreditRecord sbt log, resonse no data, request params:" + parameterMap);
            return list;
        }
        for (int i = 0; i < dataList.size(); i++) {
            JSONObject object2 = dataList.getJSONObject(i);
            SBTCreditEntity bean = (SBTCreditEntity) JSONObject.toBean(object2, SBTCreditEntity.class);
            String name = bean.getLoginName();

            String productId = bean.getProductId();
            String prefix = name.substring(0, productId.length());
            if (StringUtils.equals(productId, prefix)) {
                name = name.substring(productId.length(), name.length());
                bean.setLoginName(name);
            }
            Date date = DateUtil.formatStr2Date(bean.getCreateTime());
            if (date != null) {
                bean.setCreateDate(date);
            }
            if (bean.getCurrentBalance() == null) {
                bean.setCurrentBalance(BigDecimal.ZERO);
            }

            bean.setTransferType(SBT_TRANSFER_ENUM.getDescById(bean.getRequestType()));
            list.add(bean);
        }

        return list;
    }

    /**
     * SBT获取数据接口
     *
     * @param url
     * @param parameterMap
     * @return
     * @throws IOException
     */
    public List<SBTOrderEntity> getSBTOrderRecord(String url, Map<String, Object> parameterMap) throws IOException {
        HttpUtil http = new HttpUtil();
        List<SBTOrderEntity> list = new ArrayList<>();//定义一个集合对象把返回的数据存放到这里
        String result = "";
                /*"{\"code\":\"success\",\n" +
                "\"data\":[\n" +
				"{\n" +
				"\"amount\":25,\n" +
				"\"betId\":\"636705146978328982\",\n" +
				"\"betTypeName\":\"Single bets\",\n" +
				"\"branchName\":\"Tennis\",\n" +
				"\"createTime\":\"2018-08-22 14:05:03\",\n" +
				"\"currency\":\"CNY\",\n" +
				"\"deviceType\":\"1\",\n" +
				"\"flag\":1,\n" +
				"\"lastUpdateTime\":\"2018-08-22 14:11:29\",\n" +
				"\"loginName\":\"A06cgyy1984\",\n" +
				"\"odds\":350,\n" +
				"\"oddsType\":\"5\",\n" +
				"\"payOffAmount\":-25,\n" +
				"\"previousBalance\":0.12,\n" +
				"\"productId\":\"A06\",\n" +
				"\"reserveId\":\"341039600\",\n" +
				"\"validAmount\":25,\n" +
				"\"winAmount\":0},\n" +
				"{\"amount\":74,\"betId\":\"636705150753203913\",\"betTypeName\":\"Single bets\",\"branchName\":\"Table Tennis\",\"createTime\":\"2018-08-22 14:11:18\",\"currency\":\"CNY\",\"deviceType\":\"1\",\"flag\":0,\"lastUpdateTime\":\"2018-08-22 14:11:18\",\"loginName\":\"A06cgyy1984\",\"odds\":100,\"oddsType\":\"5\",\"payOffAmount\":null,\"previousBalance\":74.12,\"productId\":\"A06\",\"reserveId\":\"341040857\",\"validAmount\":0,\"winAmount\":0},{\"amount\":3,\"betId\":\"636705151575287765\",\"betTypeName\":\"Combo Bets\",\"branchName\":null,\"createTime\":\"2018-08-22 14:12:44\",\"currency\":\"CNY\",\"deviceType\":\"0\",\"flag\":0,\"lastUpdateTime\":\"2018-08-22 14:12:44\",\"loginName\":\"A01gtcy888\",\"odds\":61703,\"oddsType\":\"5\",\"payOffAmount\":null,\"previousBalance\":1537.15,\"productId\":\"A01\",\"reserveId\":\"341041124\",\"validAmount\":0,\"winAmount\":0},{\"amount\":4,\"betId\":\"636705151575287764\",\"betTypeName\":\"System Bet (7\\/8)\",\"branchName\":null,\"createTime\":\"2018-08-22 14:12:43\",\"currency\":\"CNY\",\"deviceType\":\"0\",\"flag\":0,\"lastUpdateTime\":\"2018-08-22 14:12:43\",\"loginName\":\"A01gtcy888\",\"odds\":231297,\"oddsType\":\"5\",\"payOffAmount\":null,\"previousBalance\":1537.15,\"productId\":\"A01\",\"reserveId\":\"341041124\",\"validAmount\":0,\"winAmount\":0}]}";*/
        //result="{\"code\":\"success\",\"data\":[{\"amount\":25,\"betId\":\"636686862228787279\",\"betTypeName\":\"QA Bet\",\"branchName\":\"Soccer\",\"createTime\":\"2018-08-01 10:10:29\",\"currency\":\"CNY\",\"deviceType\":\"1\",\"flag\":1,\"lastUpdateTime\":\"2018-08-01 10:13:20\",\"loginName\":\"A06cbocaijiqi\",\"odds\":105,\"oddsType\":\"LineType1\",\"payOffAmount\":26.25,\"previousBalance\":25,\"productId\":\"A06\",\"reserveId\":\"321246031\",\"validAmount\":25,\"winAmount\":51.25},{\"amount\":130,\"betId\":\"636686670985326844\",\"betTypeName\":\"QA Bet\",\"branchName\":\"Soccer\",\"createTime\":\"2018-08-01 04:51:40\",\"currency\":\"CNY\",\"deviceType\":\"1\",\"flag\":1,\"lastUpdateTime\":\"2018-08-01 10:12:53\",\"loginName\":\"A06chjz888\",\"odds\":1100,\"oddsType\":\"Exact Score\",\"payOffAmount\":706.72,\"previousBalance\":878.15,\"productId\":\"A06\",\"reserveId\":\"321096236\",\"validAmount\":130,\"winAmount\":836.72},{\"amount\":4,\"betId\":\"636686864611155994\",\"betTypeName\":\"System Bet (4\\/7)\",\"branchName\":null,\"createTime\":\"2018-08-01 10:14:23\",\"currency\":\"CNY\",\"deviceType\":\"0\",\"flag\":0,\"lastUpdateTime\":\"2018-08-01 10:14:23\",\"loginName\":\"A01g846343648\",\"odds\":528953,\"oddsType\":null,\"payOffAmount\":null,\"previousBalance\":75.62,\"productId\":\"A01\",\"reserveId\":\"321248545\",\"validAmount\":0,\"winAmount\":0},{\"amount\":444,\"betId\":\"636686864426606206\",\"betTypeName\":\"Single bets\",\"branchName\":\"Soccer\",\"createTime\":\"2018-08-01 10:14:10\",\"currency\":\"CNY\",\"deviceType\":\"1\",\"flag\":0,\"lastUpdateTime\":\"2018-08-01 10:14:10\",\"loginName\":\"A06cxiexian007\",\"odds\":107,\"oddsType\":\"Asian Handicap\",\"payOffAmount\":null,\"previousBalance\":2937.97,\"productId\":\"A06\",\"reserveId\":\"321248219\",\"validAmount\":0,\"winAmount\":0},{\"amount\":100,\"betId\":\"636686864309165380\",\"betTypeName\":\"Single bets\",\"branchName\":\"Soccer\",\"createTime\":\"2018-08-01 10:13:55\",\"currency\":\"CNY\",\"deviceType\":\"1\",\"flag\":0,\"lastUpdateTime\":\"2018-08-01 10:13:55\",\"loginName\":\"A06cmumu0526\",\"odds\":2.28,\"oddsType\":\"OU\",\"payOffAmount\":null,\"previousBalance\":270.41,\"productId\":\"A06\",\"reserveId\":\"321248036\",\"validAmount\":0,\"winAmount\":0},{\"amount\":50,\"betId\":\"636686864393051664\",\"betTypeName\":\"QA Bet\",\"branchName\":\"Soccer\",\"createTime\":\"2018-08-01 10:14:02\",\"currency\":\"CNY\",\"deviceType\":\"1\",\"flag\":0,\"lastUpdateTime\":\"2018-08-01 10:14:02\",\"loginName\":\"A06cmcming\",\"odds\":1925,\"oddsType\":\"Exact Score\",\"payOffAmount\":null,\"previousBalance\":300.35,\"productId\":\"A06\",\"reserveId\":\"321248090\",\"validAmount\":0,\"winAmount\":0},{\"amount\":250,\"betId\":\"636686864728596826\",\"betTypeName\":\"Single bets\",\"branchName\":\"Soccer\",\"createTime\":\"2018-08-01 10:14:40\",\"currency\":\"CNY\",\"deviceType\":\"1\",\"flag\":0,\"lastUpdateTime\":\"2018-08-01 10:14:40\",\"loginName\":\"A06cmcming\",\"odds\":305,\"oddsType\":\"1X2\",\"payOffAmount\":null,\"previousBalance\":250.35,\"productId\":\"A06\",\"reserveId\":\"321248619\",\"validAmount\":0,\"winAmount\":0}]}";
        result = http.doPost(url, parameterMap);//调用接口获取数据
        // Add interception to retrieve Response
        if (ToolUtil.isNeedInterceptResponse(parameterMap.get(UtilConstants.ORDER_TASK_ID) + "")) {
            log.info("Intercept:TaskId=" + parameterMap.get(UtilConstants.ORDER_TASK_ID) + ",Url=" + url + ",Response=" + result);
        }
        if (StringUtils.isEmpty(result)) {
            log.info("getSBTOrderRecord sbt log, resonse no data, request params:" + parameterMap);
            return list;
        }
        log.info(">> SBT >> get sbt order record result:" + result);
        JSONObject object = JsonUtil.StringToJSONOBject(result);//返回对象转换成JSONObject对象
        JSONArray dataList = object.getJSONArray("data");//转换成JSONArray
        if (dataList == null || dataList.isEmpty()) {
            return list;
        }
        for (int i = 0; i < dataList.size(); i++) {//循环JSONArray数据
            JSONObject object2 = dataList.getJSONObject(i);
            SBTOrderEntity bean = (SBTOrderEntity) JSONObject.toBean(object2, SBTOrderEntity.class);
            String name = bean.getLoginName();//获取名字
            if (StringUtils.isEmpty(name) || StringUtils.isEmpty(bean.getBetId())) {
                log.error("getSBTOrderRecord sbt log, found data no name or no betId, resutl String:" + result);
                continue;
            }
            String productId = bean.getProductId();//产品名称
            String prefix = name.substring(0, productId.length());
            if (StringUtils.equals(productId, prefix)) {
                name = name.substring(productId.length(), name.length());
                bean.setLoginName(name);
            }
            Date date = DateUtil.formatStr2Date(bean.getCreateTime());
            if (date != null) {
                bean.setCreateDate(date);
            }
            date = DateUtil.formatStr2Date(bean.getLastUpdateTime());
            if (date != null) {
                bean.setLastUpdate(date);
            }
            if (StringUtils.isEmpty(bean.getBetId())) {
                log.warn("get sbt order log found betid is empty, data str[{}]", object2.toString());
                continue;
            }
            bean.setPlatformId((String) parameterMap.get("platformId"));//设置平台ID号
            /**SBTOrderEntity转OrderEntity*/
            OrderEntity orderEntityTemp = transSBTOrderEntityOrder(bean);
            //洗码投注额重新计算
            ObjectConstructUtil.calculateValidAndRemainAmountForSportGame(orderEntityTemp);
            bean.setRemainAmount(orderEntityTemp.getRemainAmount());//洗码)返水投注额
            bean.setPayOffAmount(bean.getPayOffAmount() == null ? BigDecimal.ZERO : bean.getPayOffAmount());//add by ziv 2018-11-01
            if (StringUtils.equals(bean.getBetTypeName(), "Combo Bets")) {//串关时gametype显示Combo add by ziv 2018-12-05
                bean.setBranchName("Combo");
            }
            list.add(bean);
        }
        return list;
    }


    /**
     * transSBTOrderEntityOrder
     *
     * @Description: 把SBTOrderEntity对象转换成OrderEntity
     * @Author: Wythe
     * @Date: 2018/8/22 21:06
     */
    public static OrderEntity transSBTOrderEntityOrder(SBTOrderEntity entity) {
        if (entity == null) {
            return null;
        }
        OrderEntity orderEntity = new OrderEntity();
        orderEntity.setProductId(entity.getProductId());//产品ID号
        orderEntity.setLoginName(entity.getLoginName());//登陆名称
        orderEntity.setOdds(entity.getOdds());//赔率
        orderEntity.setOddsType(entity.getOddsType());//盘口
        orderEntity.setPlatId(entity.getPlatformId());// 平台id号
        orderEntity.setFlag(entity.getFlag());//注单状态
        orderEntity.setAccount(entity.getAmount());//投注额
        orderEntity.setCusAccount(entity.getPayOffAmount());//客户输赢额度
        orderEntity.setValidAccount(entity.getValidAmount());//有效投注额
        orderEntity.setRemainAmount(entity.getRemainAmount());//返回投注额
        orderEntity.setStatus(entity.getStatus());
        return orderEntity;
    }
}
