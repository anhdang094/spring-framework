package main.java.com.gw.common.system.parse;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.system.parse.vo.OrderRes;
import main.java.com.gw.common.system.timer.TGPTimerTask;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
public class TGPOrderHandle extends AbstractHandle {
    static String ERROR = "error";
    static volatile Map<String, Object> cacheData = new HashMap<String, Object>();

    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        String baseUrl = (String) paramaterMap.get(UtilConstants.ORDER_BASE_URL);
        String begintimeStr = (String) paramaterMap.get(UtilConstants.ORDER_BEGIN_TIME);
        String endtimeStr = (String) paramaterMap.get(UtilConstants.ORDER_END_TIME);
        begintimeStr = (begintimeStr.replace(" ", "T")) + UtilConstants.HTTP_PARM_PLUS + "08:00";
        endtimeStr = (endtimeStr.replace(" ", "T")) + UtilConstants.HTTP_PARM_PLUS + "08:00";
        if (baseUrl.indexOf("?") >= 0) {
            baseUrl = baseUrl + "startdate" + "=" + begintimeStr + "&enddate" + "=" + endtimeStr + "&issettled" + "=" + false;//issettled为false表示抓取已结算和未结算的数据
        } else {
            baseUrl = baseUrl + "?startdate" + "=" + begintimeStr + "&enddate" + "=" + endtimeStr + "&issettled" + "=" + false;
        }
        return baseUrl;
    }

    public String retrieveData(Map<String, Object> paramaterMap) throws GWCallRemoteApiException {
        String content = null;
        String requestUrl = getUrl(paramaterMap);//获取返回的url地址
        try {
            String clientId = (String) paramaterMap.get("clientId");//辨识吗
            String clientSecret = (String) paramaterMap.get("clientSecret");//营运商秘钥
            String tokenUrl = (String) paramaterMap.get("tokenUrl");//访问令牌的地址
            log.info("TGP 注单 请求令牌参数：clientId=" + clientId + ",clientSecret=" + clientSecret + ",tokenUrl=" + tokenUrl);
            String token = TGPTimerTask.cacheToken(clientId, clientSecret, tokenUrl);
            log.info("TGP 注单 获取返回令牌和调用抓取数据url：token=" + token + ",requestUrl=" + requestUrl);

            //requestUrl="http://staging.tgpaccess.com/api/history/bets?startdate=2017-01-06T14:45:00%2B08:00&enddate=2017-01-06T14:55:00%2B08:00&includetestplayers=true&issettled="+false;
            content = TGPTimerTask.doGet(requestUrl, token);
            log.debug("TGP 注单返回参数 content=" + content);
        } catch (Exception e) {
            log.info("TGP 抓取注单信息失败 ：ErrorMessage=" + e.getMessage(), e);
            throw new GWCallRemoteApiException("TGP 注单抓取数据异常：" + e.getMessage());
        }
        return content;
    }

    @Override
    public OrderRes parse(String content) throws GWCallRemoteApiException {
        OrderRes res = new OrderRes();
        // res.setPerpage(p_obj.optInt("itemsPerPage"));
        String[] rowArray = content.split("\n");
        res.setTotal(rowArray.length - 1);         // 总数据,减去表头
        log.info("注单返回数据量为：" + (rowArray.length - 1));
        for (int x = 1; x < rowArray.length; x++) {// 抓取的时候跳过表头,所以x=1开始
            String[] dataArray = rowArray[x].split(",");
            OrderEntity order = new OrderEntity();
            BigDecimal account = minusToPositive(new BigDecimal(dataArray[11]));//投注额和有效投注额
            /* 返回数据列
             * ugsbetid,txid,betid,beton,betclosedon,betupdatedon,timestamp,
             * roundid,roundstatus,userid,username,riskamt,winamt,winloss,
             * beforebal,postbal,cur,gameprovider,gameprovidercode,gamename,
             * gameid,platformtype,ipaddress,bettype,playtype,playertype
             */
            order.setBillNo(dataArray[0]);                  // ugsbetid 内部投注标示码 保证唯一
            order.setBillTime(TGPTimerTask.modification(dataArray[3]));  // beton 注单时间
            order.setReckonTime(TGPTimerTask.modification(dataArray[5]));// betupdatedon 投注更新时间
            order.setRound(dataArray[7]);                   // roundid 回合id
            order.setGmCode(dataArray[7]);                  // roundid 回合id
            order.setLoginName(dataArray[10]);              // username 用户名
            String roundstatus = dataArray[8];                      // roundstatus结算标示： Open表示未结算，Closed表示已结算
            String gameprovidercod = dataArray[18];//游戏供应商名称：SB(Sunbet)表示真人， TGP(Red Tiger) 中只有百家乐是电子游戏其他都是老虎机 单在我们数据中心里老虎机也是电子游戏
            order.setCusAccount(new BigDecimal(dataArray[13]));   // winloss(投注的净总金额)
            order.setAccount(account);      // riskamt 投注风险总金额
            order.setValidAccount(getValidAccount(gameprovidercod, roundstatus, order.getCusAccount(), account)); // riskamt 投注风险总金额
            order.setPreviosAmount(new BigDecimal(dataArray[14]));// beforebal(投注前玩家余额),
            order.setCurrency(dataArray[16].equals("RMB") ? UtilConstants.CNY : dataArray[16]);// cur(货币类型)

            if (StringUtils.isNotBlank(gameprovidercod)) {
                if ("SB".equals(gameprovidercod) || "GD".equals(gameprovidercod)) {//表示真人
                    order.setGameKind(UtilConstants.GAME_KIND_ENUM.VIDEO.getCode());
                } else if ("TGP".equals(gameprovidercod) || "GB".equals(gameprovidercod) || "FC".equals(gameprovidercod) || "LAX".equals(gameprovidercod)) {//电子游戏
                    order.setGameKind(UtilConstants.GAME_KIND_ENUM.ELECTRONIC.getCode());//表示电子游戏
                } else {
                    log.info("--------存入游戏种类错误：GameKind=" + gameprovidercod);
                    throw new GWCallRemoteApiException("TGP注单存入GameKind错误,不属于电子游戏和真人");
                }
            }
            order.setGameType(gameprovidercod + "_" + dataArray[20]);   //gameid(游戏提供商的唯独游戏辨识吗)
            order.setDeviceType(DeviceType(dataArray[21]));         // platformtype(游戏平台类型，电脑手机登)
            order.setCurIp(dataArray[22]);                          // ipaddress(游戏提供商ip)
            order.setResult(dataArray[23]);                         // bettype(游戏动作种类，目前这个值永远是“PlaceBet”)
            order.setPlayType(replaceBlank(dataArray[25]));         // playertype 表示是否是试玩:1真钱,2试玩，该字段原是存储玩法类型的现在玩法类型用remark存储
            order.setRemark(dataArray[24]);                         // playtype 表示是玩法类型理论是要存储在playtype这个字段里面的但是这里返回为字符串，为了方便就存储到rmark

            if (StringUtils.isNotBlank(roundstatus)) {
                if ("Open".equalsIgnoreCase(roundstatus)) {
                    order.setFlag(UtilConstants.ORDERS_FLAG_ENUM.UNSETTLED.getFalg());// 未结算
                } else if ("Closed".equalsIgnoreCase(roundstatus)) {
                    order.setFlag(UtilConstants.ORDERS_FLAG_ENUM.SETTLED.getFalg());  // 已结算
                } else {
                    log.info("--------存入结算标示错误：Flag=" + roundstatus);
                    throw new GWCallRemoteApiException("TGP注单存入Flag错误,不属于未结算和已结算");
                }
            }
            order.setProductId(UtilConstants.PRODUCT_ENUM.P02.toString());
            order.setPlatId(UtilConstants.TGP);
            res.addOrder(order);
        }
        return res;
    }

    /**
     * Richard.c YT-30  【P02】亚太数据中心申博TGP数据有效投注额统计方式:
     * 未结算的数据一律返回0
     * 电子游戏，直接返回投注额作为有效投注额
     * 真人视讯，已结算,但是输赢度为0的返回0
     * 真人视讯，输赢度小于0,返回投注额
     * 真人视讯，输赢度大于0且大于投注额返回投注额
     * 真人视讯，输赢度大于0且小于等于投注额返回输赢度
     *
     * @param gameprovidercod 游戏类型
     * @param roundstatus     结算状态
     * @param cusAccount      输赢度
     * @param account         投注额
     * @return BigDecimal      有效投注额
     */
    private BigDecimal getValidAccount(String gameprovidercod, String roundstatus, BigDecimal cusAccount, BigDecimal account) {
        if (StringUtils.isNotBlank(roundstatus) && "Open".equalsIgnoreCase(roundstatus)) {
            return new BigDecimal(0);
        }
        if (StringUtils.isNotBlank(gameprovidercod)) {
            if ("TGP".equals(gameprovidercod) || "GB".equals(gameprovidercod) || "FC".equals(gameprovidercod) || "LAX".equals(gameprovidercod)) {//电子游戏
                return account;
            } else if ("SB".equals(gameprovidercod) || "GD".equals(gameprovidercod)) {//表示真人
                //真人视讯，已结算,但是输赢度为0的返回0
                if (StringUtils.isNotBlank(roundstatus) && "Closed".equalsIgnoreCase(roundstatus) && cusAccount.compareTo(new BigDecimal(0)) == 0) {
                    return new BigDecimal(0);
                }
                if (cusAccount.compareTo(new BigDecimal(0)) < 0) { //真人视讯，输赢度小于0,返回投注额
                    return account;
                } else if (cusAccount.compareTo(new BigDecimal(0)) > 0) {
                    if (cusAccount.compareTo(account) > 0) {
                        return account;
                    }
                    if (cusAccount.compareTo(account) < 0 || cusAccount.compareTo(account) == 0) {
                        return cusAccount;
                    }
                }
            }
        }
        return account;
    }


    //将返回终端类型转换为数据中心数据插入
    public String DeviceType(String date) {
        if (StringUtils.isNotBlank(date) && "Desktop".equals(date)) {//电脑
            date = "0";
        } else if (StringUtils.isNotBlank(date) && "Mobile".equals(date)) {//移动设备
            date = "1";
        } else if (StringUtils.isNotBlank(date) && "Mini Game".equals(date)) {//mini game
            date = "4";
        } else {
            date = "-1";
        }
        return date;
    }

    //判断数据是不是负数负数就要转正
    public static BigDecimal minusToPositive(BigDecimal amount) {
        return amount.abs();
    }


    //去除返回数据空格，换行等
    public int replaceBlank(String date) {
        if (date != null) {
            Pattern p = Pattern.compile("\\s*|\t|\r|\n");
            Matcher m = p.matcher(date);
            date = m.replaceAll("");
        }
        return Integer.parseInt(date);
    }

    public static void main(String[] args) {
        Map<String, Object> paramaterMap = new HashMap<String, Object>();
        paramaterMap.put("baseUrl", "http://staging.tgpaccess.com/api/history/bets");
        paramaterMap.put("begintime", "2017-01-06 14:45:00");
        paramaterMap.put("endtime", "2017-01-06 14:55:00");

        AbstractHandle handle = new TGPOrderHandle();
        try {
            String result = handle.retrieveData(paramaterMap);
            String[] split = result.split("\n");
            for (int x = 0; x < split.length; x++) {
                String[] split2 = split[x].split(",");
                System.out.println(split2);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
