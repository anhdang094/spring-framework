package main.java.com.gw.common.system.parse;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.system.parse.vo.TransRes;
import main.java.com.gw.common.system.timer.TGPTimerTask;
import main.java.com.gw.datacenter.accounttransfer.entity.AccountTransferEntity;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
public class TGPTransHandle extends AbstractHandle {
    static String ERROR = "error";
    static volatile Map<String, Object> cacheData = new HashMap<String, Object>();

    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        String baseUrl = (String) paramaterMap.get(UtilConstants.ORDER_BASE_URL);
        String begintimeStr = (String) paramaterMap.get(UtilConstants.ORDER_BEGIN_TIME);
        String endtimeStr = (String) paramaterMap.get(UtilConstants.ORDER_END_TIME);
        begintimeStr = (begintimeStr.replace(" ", "T")) + UtilConstants.HTTP_PARM_PLUS + "08:00";
        endtimeStr = (endtimeStr.replace(" ", "T")) + UtilConstants.HTTP_PARM_PLUS + "08:00";
        if (baseUrl.indexOf("?") >= 0) {
            baseUrl = baseUrl + "startdate" + "=" + begintimeStr + "&enddate" + "=" + endtimeStr;
        } else {
            baseUrl = baseUrl + "?startdate" + "=" + begintimeStr + "&enddate" + "=" + endtimeStr;
        }
        return baseUrl;
    }

    public String retrieveData(Map<String, Object> paramaterMap) throws Exception {

        String requestUrl = getUrl(paramaterMap);//获取返回的url地址

        String clientId = (String) paramaterMap.get("clientId");//辨识吗
        String clientSecret = (String) paramaterMap.get("clientSecret");//营运商秘钥
        String tokenUrl = (String) paramaterMap.get("tokenUrl");//访问令牌的地址
        log.info("TGP 转账 请求令牌参数：clientId=" + clientId + ",clientSecret=" + clientSecret + ",tokenUrl=" + tokenUrl);
        String token = TGPTimerTask.cacheToken(clientId, clientSecret, tokenUrl);
        log.info("TGP 转账  获取返回令牌和调用抓取数据url：token=" + token + ",requestUrl=" + requestUrl);

        //requestUrl="http://staging.tgpaccess.com/api/history/transfers?startdate=2017-01-05T11:05:00%2B08:00&enddate=2017-01-05T11:30:00%2B08:00&includetestplayers=true";
        return TGPTimerTask.doGet(requestUrl, token);

    }


    @Override
    public TransRes parse(String content) {
        TransRes res = new TransRes();
        String[] rowArray = content.split("\n");// 对换好进行切割
        res.setTotal(rowArray.length);// 总数据
        log.info("转账返回数据量为：" + (rowArray.length - 1));
        for (int x = 1; x < rowArray.length; x++) {// 抓取的时候跳过表头,所以从1开始
            String[] dataArray = rowArray[x].split(",");
            AccountTransferEntity trans = new AccountTransferEntity();
            /*
             * 返回的表头数据列
             * txid,timestamp,userid,username,playertype,amt,postbal,cur
             */
            trans.setTransId(dataArray[0]);               //转载id
            trans.setTradeNo(dataArray[0]);               //交易编号
            // trans.setCurrency(String.valueOf(UtilConstants.CURRENCY.RMB.ordinal()));
            trans.setCurrency(replaceBlank(dataArray[7]));//货币类型
            trans.setUserName(dataArray[3]);              //用户名
            Date creationTime = TGPTimerTask.modification(dataArray[1]);
            trans.setCreationTime(creationTime);          //时间戳转换
            trans.setOrignalCreationTime(creationTime);   //原始时间
            trans.setWagerId(dataArray[4]);               //是否是试玩账户 1：真实玩家 2：试玩
            String transferAmount = dataArray[5];         //转账额度 有"-"号
            String currentAmount = dataArray[6];          //余额
            BigDecimal PreviousAmount = null;
            if (transferAmount.indexOf("-") >= 0) {       //当获取的字符串数据有"-" 表示转出的钱（从游戏转出的）
                trans.setTransferType(UtilConstants.TRANSFER_TYPE_OUT);// 转出
                PreviousAmount = new BigDecimal(currentAmount).add(new BigDecimal(transferAmount).abs());// 转账前的额度 =余额+转账额度(负数要转正)
            } else {
                trans.setTransferType(UtilConstants.TRANSFER_TYPE_IN);// 转入
                PreviousAmount = new BigDecimal(currentAmount).subtract(new BigDecimal(transferAmount));// 转账前的额度
            }
            trans.setTransferAmount(new BigDecimal(transferAmount));// 转账金额
            trans.setPreviousAmount(PreviousAmount);       //转账前额度
            trans.setCurrentAmount(new BigDecimal(currentAmount));// 余额
            trans.setExchangeRate(new BigDecimal(1));       //汇率
            trans.setProductId(UtilConstants.PRODUCT_ENUM.P02.toString());
            trans.setPlatformId(UtilConstants.TGP);
            res.addOrder(trans);
        }
        return res;
    }

    //去除返回数据空格，换行等
    public static String replaceBlank(String date) {
        if (date != null) {
            Pattern p = Pattern.compile("\\s*|\t|\r|\n");
            Matcher m = p.matcher(date);
            date = m.replaceAll("");
            if (date.equals("RMB")) {//TGP传过来的是RMB需要转换为我们数据中心的CNY写法
                date = UtilConstants.CNY;
            }
        }
        return date;
    }

    public static void main(String[] args) {
        Map<String, Object> paramaterMap = new HashMap<String, Object>();
        paramaterMap.put("baseUrl", "http://staging.tgpaccess.com/api/history/transfers");
        paramaterMap.put("begintime", "2017-01-02 17:47:14");
        paramaterMap.put("endtime", "2017-01-02 17:16:14");
        AbstractHandle handle = new TGPTransHandle();
        try {
            String result = handle.retrieveData(paramaterMap);
            String[] split = result.split("\n");
            for (int x = 0; x < split.length; x++) {
                String[] split2 = split[x].split(",");
                System.out.println(split2);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
