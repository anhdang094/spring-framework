package main.java.com.gw.common.system.parse;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.HttpClientUtils;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Slf4j
public class TPGOrderHandle {

    public static List<OrderEntity> getTPGBetRecords(String url, Map<String, Object> parameterMap) throws GWCallRemoteApiException, IOException, ParseException {
        String operatorId = (String) parameterMap.get(UtilConstants.ORDER_AG_CODE);
        String startTime = (String) parameterMap.get(UtilConstants.ORDER_BEGIN_TIME);
        String endTime = (String) parameterMap.get(UtilConstants.ORDER_END_TIME);
        int limit = (int) parameterMap.get(UtilConstants.ORDER_PAGE_NUMBER);
        int offset = (int) parameterMap.get(UtilConstants.ORDER_PAGE_NO);
        // TPG 注单时间参数格式 yyyy-MM-ddTHH:mm:ss
        startTime = startTime.replace(' ', 'T');
        endTime = endTime.replace(' ', 'T');
        String requestUrl = MessageFormat.format(url, operatorId, startTime, endTime, limit, offset);
        log.info("TPGOrderHandle.getTPGBetRecord(), requestUrl: {}", requestUrl);
        String response = HttpClientUtils.execGet(requestUrl, null);
        if (StringUtils.isBlank(response)) {
            log.error("TPGOrderHandle.getTPGBetRecord(), response is null");
            throw new GWCallRemoteApiException("TPG-注单抓取-结果异常, response is null");
        }
        log.debug("TPGOrderHandle.getTPGBetRecord(), response: {}", response);
        JSONObject jsonResult = JSON.parseObject(response);
        int status = jsonResult.getIntValue("status");
        if (status == 63) return new ArrayList<>();
        else if (status != 1) {
            log.error("TPGOrderHandle.getTPGBetRecord(), 抓取注单返回错误: {}", response);
            throw new GWCallRemoteApiException("TPG-注单抓取-结果异常, error: " + response);
        }
        // 获取总数
        int totalRow = jsonResult.getIntValue("totalRows");
        parameterMap.put(UtilConstants.ORDER_PAGE, totalRow);
        parameterMap.put(UtilConstants.ORDER_PAGE_NO, offset + limit);

        JSONArray dataArray = jsonResult.getJSONArray("data");
        int size = dataArray.size();
        String productId = (String) parameterMap.get(UtilConstants.GLOBAL_PRODUCTID_KEY);
        String platformId = UtilConstants.TPG;
        int prefixLength = productId.length();
        List<OrderEntity> list = new ArrayList<>(size);
        JSONObject data;
        JSONObject betDetail;
        OrderEntity orderEntity;
        int gameType;
        BigDecimal betAmount;
        BigDecimal payoutAmount;
        SimpleDateFormat dateFormat = new SimpleDateFormat(DateUtil.C_TIME_PATTON_DEFAULT);
        for (int i = 0; i < size; i++) {
            data = dataArray.getJSONObject(i);
            // log_type为1表示转账数据，跳过
            if (data.getIntValue("log_type") == 1) continue;

            orderEntity = new OrderEntity();
            orderEntity.setProductId(productId);
            orderEntity.setPlatId(platformId);
            orderEntity.setAgCode(data.getString("operator_id"));
            orderEntity.setTopAgCode(platformId);

            gameType = data.getIntValue("game_type");
            orderEntity.setBillNo(data.getString("transaction_id"));
            orderEntity.setLoginName(data.getString("username").substring(prefixLength));
            orderEntity.setGameKind(UtilConstants.GAME_KIND_ENUM.ELECTRONIC.getCode());
            orderEntity.setGameType(gameType + "_" + data.getIntValue("game_theme"));
            orderEntity.setDeviceType(convertToDeviceType(data.getIntValue("game_client_platform")));
            orderEntity.setCurrency(data.getString("currency"));
            orderEntity.setBillTime(dateFormat.parse(data.getString("created_at")));
            orderEntity.setOrignalBillTime(orderEntity.getBillTime());
            orderEntity.setReckonTime(dateFormat.parse(data.getString("updated_at")));
            orderEntity.setOrignalReckonTime(orderEntity.getReckonTime());

            betDetail = JSON.parseObject(data.getString("transaction_detail"));
            // 类型3的游戏是桌面游戏，会有有效投注额
            if (gameType == 3) betAmount = betDetail.getBigDecimal("total_valid_bet_amount");
            else betAmount = betDetail.getBigDecimal("total_bet_amount");
            payoutAmount = betDetail.getBigDecimal("total_payout_amount");
            orderEntity.setAccount(betAmount);
            orderEntity.setValidAccount(betAmount);
            orderEntity.setCusAccount(payoutAmount.subtract(betAmount));

            orderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.SETTLED.getFalg());// 电子游戏的注单都是已结算的
            orderEntity.setBonusAmount(BigDecimal.ZERO);
            orderEntity.setRemainAmount(orderEntity.getValidAccount().setScale(6, RoundingMode.HALF_UP));
            // TPG注单没有投注前后的余额，所以用0表示
            orderEntity.setCurrentAmount(BigDecimal.ZERO);
            orderEntity.setPreviosAmount(BigDecimal.ZERO);

            list.add(orderEntity);
        }
        return list;
    }

    /**
     * 将TPG的设备类型转换为C66系统的设备类型
     *
     * @param gameClientPlatform
     * @return
     */
    private static String convertToDeviceType(int gameClientPlatform) {
        switch (gameClientPlatform) {
            case 2:
            case 3:
            case 5:
            case 6:
                return "1";
            default:
                return "0";
        }
    }
}