package main.java.com.gw.common.system.parse;

import com.brian.item.GameRecordItem;
import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.framework.util.VNLotoPostUtility;
import main.java.com.gw.datacenter.order.entity.OrderEntity;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by peter.munsayac on 3/25/2019.
 * edited by lily.y on 07/17/2019
 */
@Slf4j
public class VNLOTOOrderHandle extends AbstractHandle {
    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        return null;
    }

    public static List<Object> getOrderList(String url, String startTime, String endTime, String productId) {

        List<Object> resultList = new ArrayList<>();
        List<Object> gameParams = new ArrayList<>();

        gameParams.add("ITBetSearch"); //method name  for get all transactions，old:SMgBetAynlse
        gameParams.add(startTime);
        gameParams.add(endTime);
        log.info("VNloto get transaction records , vnloto request params: method=ITBetSearch,startTime={},endTime={}", startTime, endTime);
        try {
            List<Object> result = VNLotoPostUtility.post(url, gameParams, 2);
            if (result != null && !result.isEmpty()) {
                int status = Integer.valueOf(result.get(0).toString());
                if (status == 0) {
                    List<GameRecordItem> items = (List<GameRecordItem>) ((List) result.get(1)).get(0);
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    for (GameRecordItem item : items) {
                        BigDecimal betAmount = new BigDecimal(item.getAmount());
                        OrderEntity entity = new OrderEntity();
                        entity.setAccount(betAmount);
                        entity.setBillNo(item.getId());
                        entity.setBillTime(sdf.parse(item.getBettime()));
                        entity.setCreationDate(sdf.parse(item.getInserttime()));
                        entity.setCusAccount(new BigDecimal(item.getBonus()).subtract(betAmount));
                        entity.setRemainAmount(betAmount);
                        entity.setValidAccount(betAmount);
                        entity.setLoginName(item.getLoginname());
                        entity.setPlatId(UtilConstants.VNLOTO);
                        entity.setGmCode(String.valueOf(item.getLotteryid()));
                        entity.setReckonTime(item.getFinishtime() != null ? sdf.parse(item.getFinishtime()) : sdf.parse(item.getBettime()));
//                        entity.setReckonTime(ToolUtil.convertTimeByTimeDifference(DateUtil.formatStr2Date(sdf1.format(sdf.parse(object.getString("createTime"))),"yyyy/MM/dd HH:mm:ss"),1));
//                        log.info("billno={}, bettime={},finishtime={}",entity.getBillNo(), DateUtil.formatDate2Str(entity.getBillTime()), DateUtil.formatDate2Str(entity.getReckonTime()));
                        entity.setBillTime(ToolUtil.convertTimeByTimeDifference(DateUtil.parse(DateUtil.formatDate2Str(entity.getBillTime()).replace("-","/"),"yyyy/MM/dd HH:mm:ss"),1));
                        entity.setReckonTime(ToolUtil.convertTimeByTimeDifference(DateUtil.parse(DateUtil.formatDate2Str(entity.getReckonTime()).replace("-","/"),"yyyy/MM/dd HH:mm:ss"),1));
//                        log.info("billno={}, bettime={},finishtime={}",entity.getBillNo(), DateUtil.formatDate2Str(entity.getBillTime()), DateUtil.formatDate2Str(entity.getReckonTime()));
                        entity.setRemark(item.getWinnumber());
                        entity.setGameType(String.valueOf(item.getLotteryid()));
                        entity.setPlayType(item.getMethodid());
                        entity.setPlayTypeStr(item.getMethodname());
                        entity.setCurrency(UtilConstants.VND);
                        entity.setBonusAmount(BigDecimal.ZERO);
                        entity.setCurIp(item.getIp());
                        entity.setDeviceType(item.getBetfrom() == 0 ? "0" : "1");
                        entity.setGameKind(UtilConstants.GAME_KIND_ENUM.LOTTERY.getCode());
                        entity.setProductId(productId);
                        switch (item.getBetfrom()) {
                            case 0:
                                entity.setTermType("1");
                                break;
                            case 1:
                                entity.setTermType("27");
                                break;
                            case 2:
                                entity.setTermType("28");
                                break;
                            case 3:
                                entity.setTermType("2");
                                break;
                        }
                        if (item.getFinishtime() != null) {
                            if (entity.getBonusAmount().compareTo(BigDecimal.ZERO) > 0) {
                                entity.setResult("Win");
                            } else {
                                entity.setResult("Lose");
                            }
                        } else {
                            entity.setResult("Bet");
                        }
                        int flag = item.getStatus(); //厅方的注单结果 0-已下注，3输 4赢 5不需要care等待派奖 6cancel bet 7cancel lottery issue
                        if (flag == 3 || flag == 4) {  //3输 4赢
                            entity.setFlag(1);
                            entity.setCusAccount(new BigDecimal(item.getBonus()).subtract(betAmount).setScale(2));
                            if (BigDecimal.ZERO.compareTo(entity.getCusAccount()) == 0) {
                                entity.setRemainAmount(BigDecimal.ZERO.setScale(2));
                                entity.setValidAccount(BigDecimal.ZERO.setScale(2));
                            } else {
                                entity.setRemainAmount(betAmount);
                                entity.setValidAccount(betAmount);
                            }
                        } else if (flag == 6 || flag == 7) {  //6 取消下注，即撤销注单，7：撤销lottery issue（相关联的注单都取消）
                            entity.setFlag(-9);
                            entity.setCusAccount(BigDecimal.ZERO.setScale(2));
                            entity.setValidAccount(BigDecimal.ZERO.setScale(2));
                            entity.setRemainAmount(BigDecimal.ZERO.setScale(2));
                        } else {  //已下注，未结算  其他情况均归类为 未结算
                            entity.setFlag(0);
                            entity.setCusAccount(BigDecimal.ZERO.setScale(2));
                            entity.setValidAccount(BigDecimal.ZERO.setScale(2));
                            entity.setRemainAmount(BigDecimal.ZERO.setScale(2));
                        }
                        resultList.add(entity);
                    }
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return resultList;
        }
        return resultList;
    }

//    public static void main(String[] args)throws Exception{
//        String url = "http://47.244.149.83:8081/UI.cfm";
//        String startTime = ("2019-07-12 18:10:00");
//        String endTime = ("2019-07-12 18:20:00");
//
//        Map<String, Object> parameterMap = new HashMap<>();
//        List<Object> result = getOrderList(url, startTime, endTime, "C07");
//  }


}
