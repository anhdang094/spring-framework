package main.java.com.gw.common.system.parse;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.util.CipherUtilsForVR;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.datacenter.accounttransfer.entity.AccountTransferEntity;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author Dominik.X
 * @description
 * @date 2019/10/24 16:13
 */
@Slf4j
public class VRHandle {
    public static final SimpleDateFormat sdf = DateUtil.getSimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
    public static final SimpleDateFormat sdf1 = DateUtil.getSimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    public static JSONObject getVRTransfer(String betApiUrl, Map<String, Object> params,Integer taskId,String cryptKey) throws GWCallRemoteApiException {
        HttpUtil http = new HttpUtil();
        String response = null;
        JSONObject baseJsonObject = null;

        try {
            log.info("vr-transfer-url:[{}],params:[{}]", betApiUrl, JSONObject.toJSON(params).toString());
            response = http.doPost(betApiUrl, params);
            if (ToolUtil.isNeedInterceptResponse(String.valueOf(taskId))) {
                log.info("Intercept:TaskId=" + params.get(UtilConstants.ORDER_TASK_ID) + ",Url=" + betApiUrl + ",Response=" + response);
            }
        } catch (IOException e) {
            log.error("getVROrder ERROR in HTTP Post: ", e);
            throw new GWCallRemoteApiException("请求vr转账出现异常");
        }

        if (StringUtils.isNotBlank(response)) {
            String decResponse = CipherUtilsForVR.decrypt(cryptKey, response);
            baseJsonObject = JSONObject.parseObject(decResponse);
        }

        return baseJsonObject;
    }


    public static List<AccountTransferEntity> getVRTransferRecords(JSONObject json, String productId, String platformId, String currency) {
        List<AccountTransferEntity> result = new ArrayList<>();
        try {
            JSONArray data = json.getJSONArray("records");
            if (CollectionUtils.isEmpty(data)) {
                return result;
            }
            for (int i = 0; i < data.size(); i++) {
                JSONObject meta = data.getJSONObject(i);
                // meta为空的不抓
                if (meta == null || meta.isEmpty()) {
                    continue;
                }
                //state不正常的不抓，不为success表明转账还未成功  转账状态:1正常|0无效
                Integer state = meta.getInteger("state");
                if (0 != state) {
                    continue;
                }
                Integer transactionType = meta.getInteger("type");
                AccountTransferEntity entity = new AccountTransferEntity();
                entity.setTransId(meta.getString("serialNumber"));
                //厅方确定返回的额度记录是北京时间
                entity.setCreationTime(DateUtil.formatStr2Date(sdf1.format(sdf.parse(meta.getString("createTime"))), "yyyy/MM/dd HH:mm:ss"));
//                entity.setCreationTime(ToolUtil.convertTimeByTimeDifference(DateUtil.formatStr2Date(sdf1.format(sdf.parse(meta.getString("createTime"))), "yyyy/MM/dd HH:mm:ss"), 8));
                entity.setProductId(productId);
                entity.setPlatformId(platformId);
                entity.setTransferAmount(meta.getBigDecimal("amount"));
                entity.setCurrentAmount(meta.getBigDecimal("balance"));
                entity.setCurrency(currency);
                entity.setUserName(meta.getString("playerName"));
                if (0 == transactionType) {
                    entity.setPreviousAmount(meta.getBigDecimal("balance").subtract(meta.getBigDecimal("amount")));
                    entity.setTransferType(UtilConstants.TRANSFER_TYPE_IN);
                } else if (1 == transactionType) {
                    entity.setPreviousAmount(meta.getBigDecimal("amount").add(meta.getBigDecimal("balance")));
                    entity.setTransferType(UtilConstants.TRANSFER_TYPE_OUT);
                }
                result.add(entity);
            }

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        return result;
    }
}
