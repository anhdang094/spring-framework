package main.java.com.gw.common.system.parse;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.common.system.parse.vo.OrderRes;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.digester3.Digester;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.Map;

/**
 * Created by Span on 2016/5/31.
 */
@Slf4j
public class W88LotteryOrderHandle extends AbstractHandle {

    private String url = "";

    public W88LotteryOrderHandle(String url) {
        this.url = url;
    }


    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        return getFinalURL();
    }

    public String getFinalURL() {
        StringBuilder fullUrl = new StringBuilder();
        this.params.forEach((k, v) -> {
            String encodedVal = v.toString();
            try {
                encodedVal = URLEncoder.encode(v.toString(), "UTF-8");
            } catch (Exception e) {
                log.error("生成调度任务的url地址出错", e);
            }
            fullUrl.append(k).append("=").append(encodedVal).append("&");
        });
        fullUrl.insert(0, "?").insert(0, url);
        return fullUrl.toString();
    }

    public String retrieveData() {
        String content = "";
        String fullUrl = getFinalURL();
        log.info("retrieve W88 Lottery data url:" + fullUrl);
        try {
            content = new HttpUtil().doGet(fullUrl);
        } catch (IOException e) {
            log.error("HttpGet url={} exception {}", fullUrl, e.getMessage());
            log.error("W88LotteryOrderHandle retrieveData error ", e);
            throw new RuntimeException(e.getMessage(), e);
        }
        return content;
    }


    public void parseRules(Digester d) {
        d.addObjectCreate("resp", OrderRes.class);
        d.addBeanPropertySetter("resp/error_code", "returnCode");

        d.addSetProperties("resp/items", "page_size", "perpage");

        d.addSetProperties("resp/items", "total_row", "total");
        d.addSetProperties("resp/items", "page_num", "numpage");
        d.addObjectCreate("resp/items/item", OrderEntity.class);
        d.addSetNext("resp/items/item", "addOrder");
        d.addSetProperties("resp/items/item", "bet_id", "billNo");
        d.addSetProperties("resp/items/item", "user_id", "loginName");
        d.addSetProperties("resp/items/item", "bet_amount", "account");
        d.addSetProperties("resp/items/item", "bet_amount", "validAccount");
        d.addSetProperties("resp/items/item", "winlose", "cusAccount");
        d.addSetProperties("resp/items/item", "bet_type", "gameType");
        d.addSetProperties("resp/items/item", "bet_time", "time");

        /*
        d.addBeanPropertySetter("Data/Record/ProductID","productId");
        d.addBeanPropertySetter("Data/Record/Currency","currency");
        d.addBeanPropertySetter("Data/Record/GameCode","gameType");
        d.addBeanPropertySetter("Data/Record/ResultType","resultType");
        d.addBeanPropertySetter("Data/Record/Result","result");*/
    }

}
