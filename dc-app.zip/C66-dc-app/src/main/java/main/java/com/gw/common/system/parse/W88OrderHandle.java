package main.java.com.gw.common.system.parse;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.common.system.parse.vo.OrderRes;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

@Slf4j
public class W88OrderHandle extends AbstractHandle {

    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        return null;
    }

    @Override
    public String retrieveData(String url, Map<String, Object> paramaterMap) throws GWCallRemoteApiException {
        String content = "";
        try {
//        	// 改为json
//        	JSONObject obj = new JSONObject();
//        	if (paramaterMap != null && !paramaterMap.isEmpty()) {
//                Iterator<Entry<String, Object>> itr = paramaterMap.entrySet().iterator();
//                while (itr.hasNext()) {
//                    Map.Entry<String, Object> entry = (Map.Entry<String, Object>) itr.next();
//                    if (entry.getValue() != null) {
//                    	obj.element(entry.getKey(), entry.getValue());
//                    }
//                }
//            }
//        	
//        	paramaterMap.clear();
//        	paramaterMap.put("param", obj.toString());
            content = new HttpUtil().doPost(url, paramaterMap);
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new GWCallRemoteApiException("Failed to call remote interface!" + ex.getMessage(), ex);
        }

        return content;

    }

    public static void main(String[] args) {

    }

    @Override
    public OrderRes parse(String content) {
        OrderRes res = new OrderRes();
        JSONArray arr = JSONArray.fromObject(content);
        res.setPerpage(999999);

        // TODO 缺错误的场景判断

        if (arr == null || arr.size() == 0) {
            return res;
        }
        res.setTotal(arr.size());
        if (res.getTotal() > 0) {
            res.setReturnCode("00");
        }
        JSONObject order_obj = null;

        String pidLoginname = "";
        for (int i = 0; i < arr.size(); i++) {
            order_obj = arr.optJSONObject(i);

            OrderEntity order = new OrderEntity();
            pidLoginname = order_obj.optString("memberId", "");
            order.setLoginName(pidLoginname);

            order.setBillNo(order_obj.optString("betNo", ""));
            order.setPlatId(UtilConstants.W88);
            String amountStr = order_obj.optString("betAmount", "0");

            String winStr = order_obj.optString("winAmount", "0");
            String vailAmountStr = order_obj.optString("betAmount", "0");
            order.setAccount(new BigDecimal(amountStr));
            order.setValidAccount(new BigDecimal(vailAmountStr));

            if (!order_obj.optBoolean("isWin", false)) {
                order.setCusAccount(order.getAccount().multiply(new BigDecimal(-1)));
            } else {
                // 实际输赢度需减去本金
                order.setCusAccount(new BigDecimal(winStr).subtract(order.getAccount()));
            }

            String actionTime = null;
            actionTime = order_obj.optString("actionTime");
            // 转换GT
            if (actionTime != null && actionTime.contains("T")) {
                actionTime = actionTime.replace("T", " ");
                if (actionTime.contains(".")) {
                    actionTime = actionTime.substring(0, actionTime.lastIndexOf("."));
                }
                if (actionTime.contains("Z")) {
                    actionTime = actionTime.replace("Z", "");
                }
            }

            String orderTime = order_obj.optString("timeBet", "");
            if (orderTime != null && orderTime.contains("T")) {
                orderTime = orderTime.replace("T", " ");
                if (orderTime.contains(".")) {
                    orderTime = orderTime.substring(0, orderTime.lastIndexOf("."));
                }
                if (orderTime.contains("Z")) {
                    orderTime = orderTime.replace("Z", "");
                }
            }

            // 该接口使用的是北京时间
//			order.setBillTime(ToolUtil.transferUSEsternDateToCNEsternDate( DateUtil.formatStr2Date(orderTime)));
            order.setBillTime(DateUtil.formatStr2Date(orderTime));
            order.setOrignalBillTime(order.getBillTime());

//			order.setReckonTime(ToolUtil.transferUSEsternDateToCNEsternDate( DateUtil.formatStr2Date(actionTime)));
            order.setReckonTime(DateUtil.formatStr2Date(actionTime));
            order.setOrignalReckonTime(order.getReckonTime());

            String status = order_obj.optString("status");
            if (status != null && "unsettled".equals(status.toLowerCase())) {
                order.setFlag(0);
            } else if (status != null && "settled".equals(status.toLowerCase())) {
                order.setFlag(1);
            } else if (status != null && ("void".equals(status.toLowerCase()) || "cancel".equals(status.toLowerCase()))) {
                order.setFlag(-9);
            } else {
                continue;
            }

            // 都为彩票游戏游戏
            order.setGameKind(UtilConstants.LOTTERY_GAME_KIND);
            order.setCurrency(order_obj.optString("currency"));
            // 统一使用CNY
            if (UtilConstants.RMB.equals(order.getCurrency())) {
                order.setCurrency(UtilConstants.CNY);
            }
            order.setGameType(order_obj.optString("betType", ""));
            order.setCreationDate(new Date());

            if (amountStr.equals("0") && vailAmountStr.equals("0")) {
                continue;
            }
            res.addOrder(order);
        }
        return res;
    }

    public JSONObject getJsonObject(String jsonStr) {
        JSONObject baseJsonObject = null;

        try {
            baseJsonObject = JSONObject.fromObject(jsonStr);
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
        }

        return baseJsonObject;
    }
}
