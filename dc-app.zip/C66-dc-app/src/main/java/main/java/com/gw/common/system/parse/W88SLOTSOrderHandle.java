package main.java.com.gw.common.system.parse;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.common.system.parse.vo.OrderRes;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.digester3.Digester;

import java.io.StringReader;
import java.util.List;
import java.util.Map;

@Slf4j
public class W88SLOTSOrderHandle extends AbstractHandle {

    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        return null;
    }

    @Override
    public String retrieveData(String url, Map<String, Object> paramaterMap) throws GWCallRemoteApiException {
        String content = "";
        try {
            content = new HttpUtil().doPost(url, paramaterMap);
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new GWCallRemoteApiException("Failed to call remote interface!" + ex.getMessage(), ex);
        }
        return content;

    }

    public static void main(String[] args) {
        String str = "<?xml version=\"1.0\" encoding=\"utf-8\"?> <historyinfo pageNum=\"1\" pageSize=\"1\" totalPage=\"0\" currentRows=\"0\" totalRows=\"0\">" +
                "<history operationCode=\"883888\" userId=\"680450\" changeTime=\"29-12-2014 9:40:11\" changeType=\"Bonus\" gameName=\"FreedomFighter\" " +
                " bet=\"0\" ret=\"0\" changes=\"0.00\" endBalance=\"0.00\" operator=\"w88\" jcon=\"0\" jwin=\"0\" platform=\"3\" ver=\"1\"/>" +
                "<history operationCode=\"893888\" userId=\"680450\" changeTime=\"29-12-2014 9:40:17\" changeType=\"Bonus\" gameName=\"FreedomFighter\" " +
                " bet=\"0\" ret=\"0\" changes=\"0.00\" endBalance=\"0.00\" operator=\"w88\" jcon=\"0\" jwin=\"0\" platform=\"3\" ver=\"1\"/></historyinfo> ";

        Digester d = new Digester();
        d.setValidating(false);

        d.addObjectCreate("historyinfo", OrderRes.class);
        d.addObjectCreate("historyinfo/history", OrderEntity.class);
        d.addSetNext("historyinfo/history", "addOrder");

        d.addCallMethod("historyinfo/history", "setTime_8", 1);
        d.addCallParam("historyinfo/history", 0, "changeTime");
        d.addSetProperties("historyinfo/history", "userId", "loginName");

//        d.addSetProperties("historyinfo/history", "changeTime", "setTime");

//	  	d.addCallMethod("historyinfo/history", "setBillNo",1);
//	  	d.addCallParam("historyinfo/history", 0, "operationCode");


//	  	d.addCallMethod("historyinfo/history", "setOrignalBillTime",1);
//	  	d.addCallParam("historyinfo/history", 0,"changeTime");

//		d.addSetProperties("historyinfo/history", "changeTime", "orignalBillTime");

//	  	d.addSetProperties("historyinfo/history", "operationCode", "billNo");
//	  	d.addSetProperties("historyinfo/history", "userId", "loginName");
//	  	d.addSetProperties("historyinfo/history", "changeTime", "agCode");
//	  	d.addSetProperties("historyinfo/history", "changeType", "agCode");
//	  	d.addSetProperties("historyinfo/history", "gameName", "agCode");
//	  	d.addSetProperties("historyinfo/history", "bet", "agCode");
//	  	d.addSetProperties("historyinfo/history", "ret", "agCode");
//	  	d.addSetProperties("historyinfo/history", "changes", "agCode");
//	  	d.addSetProperties("historyinfo/history", "endBalance", "agCode");
//	  	d.addSetProperties("historyinfo/history", "operator", "agCode");
//	  	d.addSetProperties("historyinfo/history", "jcon", "agCode");
//	  	d.addSetProperties("historyinfo/history", "jwin", "agCode");
//	  	d.addSetProperties("historyinfo/history", "platform", "agCode");
//	  	d.addSetProperties("historyinfo/history", "ver", "agCode");


        try {
            OrderRes res = d.parse(new StringReader(str));
            List<Object> list = res.getOrderList();
            for (Object object : list) {
                OrderEntity order = (OrderEntity) object;
                System.out.println(order.getOrignalBillTime());
                System.out.println(order.getLoginName());
//				System.out.println(order.getAgCode());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    public void parseRules(Digester d) {
        d.setValidating(false);
        d.addObjectCreate("historyinfo", OrderRes.class);
        d.addObjectCreate("historyinfo/history", OrderEntity.class);
        d.addSetNext("historyinfo/history", "addOrder");

        d.addSetProperties("historyinfo", "totalRows", "total");

        d.addSetProperties("historyinfo/history", "operationCode", "billNo");
        d.addSetProperties("historyinfo/history", "userId", "loginName");

        d.addCallMethod("historyinfo/history", "setTime_8", 1);
        d.addCallParam("historyinfo/history", 0, "changeTime");

//	  	d.addSetProperties("historyinfo/history", "changeTime", "orignalBillTime");
//	  	d.addSetProperties("historyinfo/history", "changeTime", "orignalReckonTime");
//	  	d.addSetProperties("historyinfo/history", "changeTime", "creationDate");

        d.addSetProperties("historyinfo/history", "changeType", "resultType");
        d.addSetProperties("historyinfo/history", "gameName", "gameType");
        //Bet: Bet amount
        d.addSetProperties("historyinfo/history", "bet", "account");
        d.addSetProperties("historyinfo/history", "bet", "validAccount");
        //Ret: Return amount
//	  	d.addSetProperties("historyinfo/history", "ret", "cusAccount");
        //Changes: Changes amount to system
        d.addSetProperties("historyinfo/history", "changes", "cusAccount");
        //endBalance: Ending Balance after this transaction
        d.addSetProperties("historyinfo/history", "endBalance", "previosAmount");

        d.addSetProperties("historyinfo/history", "operator", "agCode");
        //Amount of jackpot contribution
//	  	d.addSetProperties("historyinfo/history", "jcon", ""); //累计赌注损失金额
        //jwin: Amount of jackpot win
//	  	d.addSetProperties("historyinfo/history", "jwin", ""); //累计赌注获利金额
        d.addSetProperties("historyinfo/history", "platform", "platId");
        //ver: this history version
//	  	d.addSetProperties("historyinfo/history", "ver", ""); //版本号


        //flag?
    }

}
