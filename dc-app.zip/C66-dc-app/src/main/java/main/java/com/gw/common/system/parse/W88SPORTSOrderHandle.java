package main.java.com.gw.common.system.parse;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.exception.GWCallRemoteApiException;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.common.system.parse.vo.OrderRes;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.digester3.Digester;

import java.util.Map;

@Slf4j
public class W88SPORTSOrderHandle extends AbstractHandle {

    @Override
    public String getUrl(Map<String, Object> paramaterMap) {
        return null;
    }

    @Override
    public String retrieveData(String url, Map<String, Object> paramaterMap)
            throws GWCallRemoteApiException {
        String content = "";
        try {
            content = new HttpUtil().doPost(url, paramaterMap);
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new GWCallRemoteApiException(
                    "Failed to call remote interface!" + ex.getMessage(), ex);
        }
        return content;

    }

    public void parseRules(Digester d) {
        d.setValidating(false);

        d.addObjectCreate("resp/items", OrderRes.class);
        d.addObjectCreate("resp/items/betsfeed", OrderEntity.class);
        d.addSetNext("resp/items/betsfeed", "addOrder");

        /*<items total_page="1" total_row="2" page_size="100" page_num="1">*/

        //totalPage  总页数
        d.addSetProperties("resp/items", "total_page", "totalPages");

        //currentPage 当前页
        d.addSetProperties("resp/items", "page_num", "currentPage");

        d.addBeanPropertySetter("resp/items/betsfeed/betId", "billNo");

        // loginName
        d.addBeanPropertySetter("resp/items/betsfeed/merchantCustomerId",
                "loginName");

        // product_id
        // platform_id 047
        d.addBeanPropertySetter("resp/items/betsfeed/stake", "account");
        d.addBeanPropertySetter("resp/items/betsfeed/stake", "validAccount");
        d.addBeanPropertySetter("resp/items/betsfeed/stake", "validAccountStr");

        d.addBeanPropertySetter("resp/items/betsfeed/stake", "cusAccount");
        d.addBeanPropertySetter("resp/items/betsfeed/stake", "cusAccountStr");

        // previosAmount

        d.addCallMethod("resp/items/betsfeed/creationDate",
                "formatDateForW88Sports", 1);
        d.addCallParam("resp/items/betsfeed/creationDate", 0);

        // FLAG
        // betTypeId=2 Combo bet
        // betTypeId=1 Single Bet
        d.addBeanPropertySetter("resp/items/betsfeed/betTypeId", "playType");
        d.addBeanPropertySetter("resp/items/betsfeed/betTypeName",
                "playTypeStr");

        // currency TODO

        // GameTYPE

        // Remark

        // result
        d.addBeanPropertySetter("resp/items/betsfeed/status", "result");

        // d.setProperty("gameKind",
        // UtilConstants.GAME_KIND_ENUM.BALL.getCode());

        d.addBeanPropertySetter("resp/items/betsfeed/webProviderName",
                "deviceType");
    }

}
