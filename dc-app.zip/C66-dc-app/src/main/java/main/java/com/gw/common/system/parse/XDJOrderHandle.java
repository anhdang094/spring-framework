package main.java.com.gw.common.system.parse;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.HttpUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.entity.XDJOrderEntity;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Slf4j
public class XDJOrderHandle {


    public List<Object> getXDJOrderRecords(String url, Map<String,Object> parameterMap) throws Exception{
        List<Object> orderEntityList = new ArrayList<>();
        HttpUtil httpUtil = new HttpUtil();

        String result = httpUtil.doPost(url, parameterMap);
//        String result = "{\"code\":\"success\",\"data\":[{\"betAmount\":10,\"betDate\":\"2019-04-09T14:48:14\",\"betType\":\"1\",\"checkOdds\":null,\"odds\":\"1.56\",\"orderNo\":\"B0620190409144814567807\",\"productId\":\"B06\",\"realSettlementDate\":\"2019-04-09T14:48:14\",\"settlementDate\":\"2019-04-09T14:48:14\",\"status\":0,\"userId\":\"B06pmob14\",\"winAmount\":0}]}";

        if (ToolUtil.isNeedInterceptResponse(parameterMap.get(UtilConstants.ORDER_TASK_ID) + "")) {
            log.info("Intercept:TaskId=" + parameterMap.get(UtilConstants.ORDER_TASK_ID) + ",Url=" + url + ",Response=" + result);
        }
        if (StringUtils.isEmpty(result)) {
            log.info("XDJ Response empty. Params:" + parameterMap);
            return orderEntityList;
        }
        log.info(">> XDJ >> get xdj order record result:" + result);
        JSONObject object = JSONObject.parseObject(result);
        JSONArray dataList = object.getJSONArray("data");

        if (dataList == null || dataList.isEmpty()) {
            return orderEntityList;
        }
        for(int i=0;i<dataList.size();i++){
            JSONObject jsonObject =  dataList.getJSONObject(i);
            XDJOrderEntity xdjOrderEntity = JSON.toJavaObject(jsonObject,XDJOrderEntity.class);
            OrderEntity orderEntity = new OrderEntity();
            orderEntity.setAccount(xdjOrderEntity.getBetAmount());
            orderEntity.setBillNo(xdjOrderEntity.getOrderNo());
            orderEntity.setBillTime(xdjOrderEntity.getBetDate());
            orderEntity.setCreationDate(xdjOrderEntity.getBetDate());
            orderEntity.setCusAccount(xdjOrderEntity.getWinAmount());
            orderEntity.setRemainAmount(xdjOrderEntity.getBetAmount());
            orderEntity.setValidAccount(xdjOrderEntity.getBetAmount());
            orderEntity.setOdds(xdjOrderEntity.getCheckOdds() == null ? BigDecimal.ZERO : new BigDecimal(xdjOrderEntity.getCheckOdds()));
            String productId = xdjOrderEntity.getProductId();
            if (StringUtils.isNotBlank(xdjOrderEntity.getUserId())&&xdjOrderEntity.getUserId().startsWith(productId)) {
                String name = xdjOrderEntity.getUserId().substring(productId.length(), xdjOrderEntity.getUserId().length());
                orderEntity.setLoginName(name);
            }else {
                orderEntity.setLoginName(xdjOrderEntity.getUserId());
            }
            orderEntity.setPlatId(UtilConstants.XDJ);
            orderEntity.setGmCode(String.valueOf(xdjOrderEntity.getOrderNo()));
            orderEntity.setReckonTime(xdjOrderEntity.getRealSettlementDate() != null ? xdjOrderEntity.getRealSettlementDate() : xdjOrderEntity.getBetDate());
            orderEntity.setRemark(xdjOrderEntity.getCheckOdds());
            orderEntity.setGameType(xdjOrderEntity.getBetType());
            orderEntity.setCurrency(UtilConstants.CNY);
            orderEntity.setBonusAmount(BigDecimal.ZERO);
            //orderEntity.setCurIp(item.getIp());
            orderEntity.setDeviceType("0");


            orderEntity.setProductId(xdjOrderEntity.getProductId());

            if("A06".equals(orderEntity.getProductId())) {
                orderEntity.setGameKind(UtilConstants.GAME_KIND_ENUM.BALL.getCode());
            }else {
                orderEntity.setGameKind(UtilConstants.GAME_KIND_ENUM.E_SPORT.getCode());
            }

            orderEntity.setPreviosAmount(xdjOrderEntity.getPreviousAmount());

            switch(xdjOrderEntity.getStatus()){
                case -1 : orderEntity.setResult("Lose");
                           orderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.SETTLED.getFalg());
                            break;
                case 0 : orderEntity.setResult("Pending");
                         orderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.UNSETTLED.getFalg());
                         orderEntity.setRemainAmount(BigDecimal.ZERO);
                    orderEntity.setValidAccount(BigDecimal.ZERO);

                    break;
                case 1 : orderEntity.setResult("Cancelled");
                            orderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.CANCELED.getFalg());
                        orderEntity.setRemainAmount(BigDecimal.ZERO);
                    orderEntity.setValidAccount(BigDecimal.ZERO);

                    break;
                case 2 : orderEntity.setResult("Win");
                        orderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.SETTLED.getFalg());
                        break;
                case 3 : orderEntity.setResult("Tie");
                        orderEntity.setFlag(UtilConstants.ORDERS_FLAG_ENUM.SETTLED.getFalg());
                        orderEntity.setRemainAmount(BigDecimal.ZERO);
                    orderEntity.setValidAccount(BigDecimal.ZERO);

                    break;
            }

            orderEntityList.add(orderEntity);
        }
        return orderEntityList;
    }

//    public static void main(String[] args) {
//        String result = "{\"code\":\"success\",\"data\":[{\"betAmount\":10,\"betDate\":\"2019-04-09T14:48:14\",\"betType\":\"1\",\"checkOdds\":null,\"odds\":\"1.56\",\"orderNo\":\"B0620190409144814567807\",\"productId\":\"B06\",\"realSettlementDate\":\"2019-04-09T14:48:14\",\"settlementDate\":\"2019-04-09T14:48:14\",\"status\":0,\"userId\":\"B06pmob14\",\"winAmount\":0}]}";
//        JSONObject object = JSONObject.parseObject(result);;
//        JSONArray dataList = object.getJSONArray("data");
//        for(int i=0;i<dataList.size();i++){
//            JSONObject jsonObject =  dataList.getJSONObject(i);
//            XDJOrderEntity bean = JSON.toJavaObject(jsonObject,XDJOrderEntity.class);
//            System.out.println(bean.getBetDate());
//        }
//    }
}
