package main.java.com.gw.common.system.parse;

import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.*;
import main.java.com.gw.common.system.entity.Xj188OrderDetailEntity;
import main.java.com.gw.common.system.entity.Xj188OrderEntity;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * @author eagle
 */
@Slf4j
public class Xj188OrderHandle {

    public static void main(String[] args) {

        try {
//        String result = "0gESd8S940SQu9bu3JUqb2JEQRCXY6qeou4w8N+DI1M2rZRfnlAWCMyeGXVRlnv/kr24xG5SAJCn48Z6ob0Z8+Ow7pTUWdzQz9gRBPnrIQeyY24lH66+dv/XpUATyjQR/MdCNph4eOc7Irysf844/YUFkYvihvf1VGGvUX6i6sVFCg6uJBeb5CV3armfqF/I9KM7L+5k52Z2LenisdqfZg==";
//        String key = "55+5)w[g%i-f5WXb43iS^U$qf%LaDM+B";
//        String iv = "nU(qMPx/V/~57i!6";
//        System.out.println(AesCryptUtil.decryptAES256(result,key,iv));

//        Date date = new Date(1503544630000L);  // 对应的北京时间是2017-08-24 11:17:10
//        SimpleDateFormat bjSdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");     // 北京
//        bjSdf.setTimeZone(TimeZone.getTimeZone("Etc/GMT+4"));  // 设置北京时区
//        System.out.println("北京时间:" + bjSdf.format(date));

            DateTimeFormatter pattern = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            pattern.withZone(ZoneId.of("Etc/GMT+4"));
            LocalDateTime dt = LocalDateTime.parse(DateUtil.formatDate2Str(new Date(), DateUtil.C_TIME_PATTON_DEFAULT), pattern);
            System.out.println(ZonedDateTime.of(dt, ZoneId.of("Etc/GMT+4")).format(DateTimeFormatter.ISO_OFFSET_DATE_TIME));
            String encryptResult = AesCryptUtil.decryptAES256("0gESd8S940SQu9bu3JUqbzZLBe1hYJEzX3Sm7hMYwODs2HtPtwyEp+1E0UBwfVdKC6WcKKHfBAsD19xlrBzDgtcDRrY4trlFj+Bw58afeJH9Ku2P+hTyKJVh7txsfignFZ1blfrDoXAYiahS9dY4YccRwCuePYtuxvWcVYAosQrh/mENydcWIKUsMa69XVnoYm8pW3dc41YXGMugx3uKbaXaxmJrHxhhmHsotnrj2MyXyHdF9QBQlIgEyQSRPw9I0Oo17O8i6aVmSL8yOB0CFhCSJkYZlLCXHFrQ5UOiABmfllci65rvrJxoBfxJqZGxecle9tL4I0efjRhJtVPAV0vVeCFtP3Y2ji4m0wM+x9EvLUF0SLMtMtrOzYOtU4wtIHF8BzIGg7YEdfcb410qweWy8eGrsqDv/DhEXH8/bwu9BGeKMF7CJvIDeTpYDH8IkEGyH413hK2SXqiAfcpm/g2QICpyMAp+5AukD9vAejSFmchqYp1gTxpLA/erZW32HY8OWuPjCWADzBJ5+DW9QUHngsGC23paruhg6UGodRdxoUm9orEnDdtnnA62G23bHBIj7CFSe4b40ph7kJ0afdlE5K7gUO8hQCXMRS2YeuDptLSoLtjfL3CwByUNaLYifucco+sBmKnGvyEsuo9h9zuHxkIfiz2b3+d3TUfdRMr/nLHgxRRHrb19SnTVZXyycJ51i4jfG4JaiS/so13YhKVPKd8iwJradYr0iCakya8K/dxYrdnRuGGC7iz8pNMcveZO6MyXsfVfcFGFlK8pVQZ19KraupkQbDIFWTFAAnPR4vcTyUjJmaJs4d4gQB1fuyXi6aaHUCGlgyI08wL3xnp3emiQboFwyKVBOWwdhXxsPCVlx1k9LRZhvFGbsLzYWe1SJ/ztHgSA2tj+sl6DX3Gp+tEHa5Ql128inRI+0i2NQnIjQoYQMwZkQ50SypQghYm6niU+DCGVqka8OfYS/QYuwuumQ83Mehr89A7bEFIAZDGZK7xAJ33jQMRrhKX1NQ+7yce1r2WMTgA37anbxp0KQVtQHekVUiTcjh/Xcc6+ZHVjODHOEKCVe4bUOLeiIPVkfXt8+6IsfD+gFPbSjs4XvHOWRFFyiVhC6visdfPlijKhgK4PNzbffzD1SKMoT7E2o82XQo/ni4GvYN5i8Iwnc3kI21WRvLSJvrhIWdVdgYQgdm6lIqgaIRjxuXAA2ojsD6l/iyeb77txSKDDroCZcOmxfGcALLZcGw8fg8K1aLnckm9rLYCm62i6lnIcjki4qTXQveGtORlFCuOMjnT28701ObnIGqCWRMyCTIu271YAGzl6ho+q2Wtij+1tyXDSrB3nInuBJhhfE19IC7172Nh0xgj2NsfjeLcsqo3esU3/M96S++83Ei4hNsYbNAq8uw71WMwItMubQ0wOotye2Us/pLO7AJcu+FzONZC2iEu+1qWaLkEXvyXPvNIf04Rk/vNQvlSGU0cMw664p6G/WW3eODLapMfZeiCqSA/HcvS93mcFfSwMrpz8bTz3O6SrM2dgunY8k2eTzjUxkJx/nR+UcNmhN0FlRIWjGPGvY7RS9IIhjI/DkZ7noz7QpsYmUf3R3lSBo5lwCiMhsaedeI2i8B6Z6m4RnyYJPZ9D8iZc1+eOsFzFlwPDufYakvlYvDQhPgNCFgK7qiAYNuOn3WB/HiBkWptue762vOm4aECA96Btcm/wP9q5U6JM5WOkGl4f8KfxZt0o2B0WB6pwSkF1MmgvkByL2y6Eb1VqWpmqOSPMFbBZbYV+4sSE/pHrwr9D6euv+nphxhf5ua1/GpdqxQGFL10V+RXWnKmW/mfpFmm5/KfzNHA9Y1a3At8dZAUO5UmJIfxW7w0OIZur8p9KZwVEs/PiMknMZyf2IRLWB1eOLc+IIk+5viOTU3PDZHBHJKDwy6G0Rj0IvA5V/c2bacwfpAZ3MQVPkKeCL3FMU6nNHGf/Zq+v6v8wiYoVUKcrvnXDjQzjh2mOao4VppmuiRshaPD3gfjIbWVMkAAvpYhmu9eBnfhJjlTfbErh/HtV+YKG15QU0GLFlg8YuLJ7hczSU0ikkxTERkyIt8ywwiyWUmSVqwfwTUyRsxC5Hr4uSQGa049llS/vFUC3R/x8Tpra1GJMAvj/OCzTG2JwmrMbqsTqbdlR8/Win6Cj3rdT9d+vizNXK0YqMMgeCwsT7cZMpxrwJk+DkGqTDiU2GyWS5KAu1D3VIXu4Ue91LWjjGkzYFPqbun/qQf3tNeg1T8txGH/GLkacd5QPIRjXW32g66xmYYI8pS45sZsTi7KVF6RxHOq/3x2C8OFoj8Dn/Bq40Efp78eQQ8B9nGrQEp5msqzeeJsqCgH6aAfkXpBzbOe5+aHkw0PrB3N2iYc0YZIC0TnUCdmiHlHttvslvVPiAbhYN1QxAk2GBx2123ckuu68qP9hf+hQUwsppzh9rgqpjQMiI+AWhTIBojee2dRyqJUoEs5vpwpUfewVeNujVR7ClxzkIztkYpIIdML22fcj7yxzWC+PXud//onIvchbYWKJIqTeu/p/3ajoMOArjTUBDtxcP4CmNbMvLSODthft1qtmaO3uSlHighkIs7CQu7snvu4cTBF3Dy/Hr4uRUbti82Wu+uqQxDHFVY/XS4JLEqFq1LTgQKILk7z5czaePCTFyhJZeQcFAGAWZWlJvtEELuc5HX4f1qMtSrhTbJLB6um7tDg4MUC8hnFmK3dJl/KNC75o8U5OQXWmuOq1/C479pfhggZ1UlrOcsYJrXreInNQFG195dNhYIz5dHuVuVy33tsZVwNKcbgwjdjRZbqzQhks/DWvIwoQlPI8TzcMXt6gQS+dDzVDnx2ZdL2/navDWRNXuDYp", "55+5)w[g%i-f5WXb43iS^U$qf%LaDM+B", "nU(qMPx/V/~57i!6");
            System.out.println(encryptResult);

            List<Xj188OrderDetailEntity> list = new ArrayList<>();
            Xj188OrderDetailEntity a = new Xj188OrderDetailEntity();
    //        a.setOdds(new BigDecimal(10));
            Xj188OrderDetailEntity b = new Xj188OrderDetailEntity();
    //        b.setOdds(new BigDecimal(20));
            Xj188OrderDetailEntity c = new Xj188OrderDetailEntity();
        //    c.setOdds(new BigDecimal(30));
            list.add(a);
            list.add(b);
            list.add(c);
            Xj188OrderEntity entity = new Xj188OrderEntity();
            entity.setBets(list);
            entity.setOdds(new BigDecimal(10));
            System.out.println(getMinOdds(entity));


//        System.out.println(ZonedDateTime.ofInstant((new Date()).toInstant(),ZoneId.of("Etc/GMT+4")).format(DateTimeFormatter.ISO_OFFSET_DATE_TIME));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<Object> getXj188OrderRecord(String url, Map<String, Object> parameterMap) throws Exception {
        List<Object> list = new ArrayList<>();
        //构建请求加密参数
        String encodeJson = generateReqParams(parameterMap);
        String opcode = parameterMap.get("opCode").toString();
        Map<String, String> heaaderMap = Maps.newHashMap();
        heaaderMap.put("x-opcode", opcode);
        String key = parameterMap.get("key").toString();
        String iv = parameterMap.get("iv").toString();
//        String result = "/aAIjIvZYpb2M5b/MlDfYfy8Hbyylc3fwM3tz+nId0uaKAbmSQ+ec63KZMqpGXYOReAGyJYVZbQRhchfRxY7sVEyp2A8pG83iJe7L66zs1M2mp9kxtbfSAsHVn6m8cFw";
//        String result = "0gESd8S940SQu9bu3JUqb0TNWNdtykx2pdKAmaZib7TxsRmjTVy3ntBoRzWP/66LVVdqfpzlWqQWDsQHQJWmo0bbW66n9In3ns+QvHRF4/tMW049RppQqsPWl4FYJOBGpoV77Ow/KEUrUEFbQG897grNBZwzyAEK+aAebJWeeUUMWO/y42HVr1FVh257dLR8InDQ8APqyVYLRlWt3ATxOXaJ/hzp/Xb1xjVvSCIEZbvHi0Dfjbl0XTyY3wwP91D/k6dKyNFuEzTh8jA8vfp+GQN+7HOfvX/18fiJudq+ZhtJViwrBwPM81VOAByZ8eLfY2eTud6TCHE7iyVpTkyphBXA9tkcVh+Prol2XPhCFWWxXUcGSnCy+OJpUGeMkB2CAcHzM/RNUgchedfaDcaeMTJR+9ZEjIT+OyKKYd8/6ihe5Ls9tmj219GTHaNJmAJ6Uk0f5I3UDinfuRhEl75Df6RqXITOmcCQLUyQrX14/6uvDpOLCbHwt7e9PGR4y+2TWO5aW/XfUZN4yAAzTYMd9NLoNunV7pN4aivwdNotKEEWaL4sugx4q9i4JhOVuONk26HxAXZ5Ibzu5RMsV6ne8rBguhPIVgo3jngfV6iH/xlYrXcTjsFnnOLf3sKaiwxNQPcCHS7vEd4N/9QEJ9M/d8jfYD7IuNPZ6IyriisXXKRDa2idKjJ5Qf5S6S3p6WWF1WKR6XlDGPpZKshzlqHh1DJgSfbqhUcHonbXTOXafEBDOiD7tsxv321HFcd9OExS84yteFRxHGtLYesgrwjlrJkYSGmdpLnntsislfgSRo3ZkkUTNGxtrQOBoXHAy00QIB8o7UnkIgIjkcGA6SBTmw5iTA0gMjSl8oVeIaiX0vzTjerpDiZ5VcXdyLxM/7h/e0oGF+yv91mY7LmnCbjpX2ij3DO1YVXRcORT+cY+qh3sdojPVcwCLJw+czhDxAK4/wppAbaWI+44s0ix1cverI+s/vdWTaEILbqcVRXt5KWiHiBgpq8SHH1iRMiXneKhCtGg18NokoyiW1Yz9YPEpA0Cgd69r6WxXF8ixa0wX6n3nY7Xm8Sst41iWbjdQo/2tUo5pLOi7p6PzEg+L6jLklO6Yro2zuEyHlQ8NK19XT/DtLB6NwjfbXOS0LIhwj63SoOwhKfsbPWKMhOgJKkU1k09EGFEkLcqui0qxYEnw1QZM4uXPmANDWvx0kWCRyZeTgVF01nq0bvRhu4+z9JmzMiM+S0RjlZLldQA0vhNz3gAD0b3pxBASuWar7JrSIXp";
        String result = HttpClientUtils.postText(url, heaaderMap, encodeJson);
        String encryptResult = AesCryptUtil.decryptAES256(result, key, iv);
        //String encryptResult=result;
        if (ToolUtil.isNeedInterceptResponse(parameterMap.get(UtilConstants.ORDER_TASK_ID) + "")) {
            log.info("Intercept:TaskId={},Url={},Response={}", parameterMap.get(UtilConstants.ORDER_TASK_ID), url, result);
        }
        if (StringUtils.isEmpty(result)) {
            log.info("getXj188OrderRecord log, response no data, request params:{}", parameterMap);
            return list;
        }
        JSONObject object = JsonUtil.StringToJSONOBject(encryptResult);
        if (!StringUtils.equals("COMM0000", object.getString("code"))) {
            throw new Exception("XJ体育获取注单厅方返回错误" + object.getString("code"));
        }
        JSONArray dataList = object.getJSONArray("data");
        if (dataList == null || dataList.isEmpty()) {
            return list;
        }
        String productId = parameterMap.get("productId").toString();
        String currency = parameterMap.get("currency").toString();
        String timeZone = parameterMap.get("timeZone").toString();
        for (int i = 0; i < dataList.size(); i++) {
            JSONObject object2 = dataList.getJSONObject(i);
//            Xj188OrderEntity bean = (Xj188OrderEntity) JSONObject.toBean(object2, Xj188OrderEntity.class,classMap);
            Xj188OrderEntity bean = com.alibaba.fastjson.JSONObject.parseObject(object2.toString(), Xj188OrderEntity.class);
            JSONArray jsonDataList = object2.getJSONArray("bets");
            Set<String> sportNameSet = Sets.newHashSet();
            if (!CollectionUtils.isEmpty(jsonDataList)) {
                jsonDataList.stream().forEach(jsonObj -> {
                    JSONObject jsonBet = (JSONObject) jsonObj;
                    JSONObject jsonEvent = jsonBet.getJSONObject("event");
                    sportNameSet.add(jsonEvent.getString("eventType"));
                });
            }
            OrderEntity orderEntityTemp = transferEntityForXJ(bean, timeZone);
            String gameType = sportNameSet.size() > 1 ? "1" : sportNameSet.stream().findFirst().get();
            if (bean.getCashoutStake() != null && bean.getCashoutStake().compareTo(BigDecimal.ZERO) > 0){
                OrderEntity cashoutOrderEntityTemp = transferCashoutEntityForXJ(bean, timeZone);
                //设置游戏类型，判断如果类型全部相同则去任意一个，否则则是混合为-1
                cashoutOrderEntityTemp.setGameType(gameType);
                cashoutOrderEntityTemp.setProductId(productId);
                cashoutOrderEntityTemp.setPlatId(UtilConstants.XJ);
                cashoutOrderEntityTemp.setCurrency(currency);
                cashoutOrderEntityTemp.setDeviceType("1");
                cashoutOrderEntityTemp.setGameKind(UtilConstants.GAME_KIND_ENUM.BALL.getCode());
                cashoutOrderEntityTemp.setOrignalTimezone(timeZone);
                //洗码投注额计算
                ObjectConstructUtil.calculateValidAndRemainAmountForSportGame(cashoutOrderEntityTemp);
                list.add(cashoutOrderEntityTemp);
            }
            //设置游戏类型，判断如果类型全部相同则去任意一个，否则则是混合为-1
            orderEntityTemp.setGameType(gameType);
            orderEntityTemp.setProductId(productId);
            orderEntityTemp.setPlatId(UtilConstants.XJ);
            orderEntityTemp.setCurrency(currency);
            orderEntityTemp.setDeviceType("1");
            orderEntityTemp.setGameKind(UtilConstants.GAME_KIND_ENUM.BALL.getCode());
            orderEntityTemp.setOrignalTimezone(timeZone);
            //洗码投注额计算
            ObjectConstructUtil.calculateValidAndRemainAmountForSportGame(orderEntityTemp);
            list.add(orderEntityTemp);
        }
        return list;
    }

    /**
     * 构建订单信息OrderEntity
     *
     * @param entity
     * @return
     */
    public static OrderEntity transferEntityForXJ(Xj188OrderEntity entity, String timeZone) {
        if (entity == null) {
            return null;
        }
        OrderEntity orderEntity = new OrderEntity();
        orderEntity.setLoginName(entity.getMemberCode());
        //订单单号
        orderEntity.setBillNo(entity.getId());
        Date createTime = LocalDateUtil.localDateTime2Date(ZonedDateTime.parse(entity.getCreateTime()).toLocalDateTime(), ZoneId.of(timeZone));
        orderEntity.setBillTime(createTime);

        BigDecimal stake;
        if (entity.getCashoutStake() != null && entity.getCashoutStake().compareTo(BigDecimal.ZERO) > 0){
            stake = entity.getRemainingStake();
        } else {
            stake = entity.getStake();
        }
        orderEntity.setAccount(stake);
        //获取注单的结算状态
        int flag = getFlag(entity);

        if (flag == 1) {
            orderEntity.setValidAccount(stake);
            orderEntity.setCusAccount(entity.getReturnAmount().subtract(stake));
            if (BigDecimal.ZERO.compareTo(orderEntity.getCusAccount()) == 0) {
                orderEntity.setValidAccount(BigDecimal.ZERO.setScale(2));
                orderEntity.setRemainAmount(BigDecimal.ZERO.setScale(2));
                //和局，更新游戏结果，洗码时判断使用
                orderEntity.setResult("Tie");
            } else {
                orderEntity.setValidAccount(stake);
                //和局的注单(输赢度为0)，洗码投注额为0
                orderEntity.setRemainAmount(stake);
            }
        } else {
            //取消的注單和未结算不计算有效投注额
            orderEntity.setCusAccount(BigDecimal.ZERO.setScale(2));
            orderEntity.setValidAccount(BigDecimal.ZERO.setScale(2));
            orderEntity.setRemainAmount(BigDecimal.ZERO.setScale(2));
        }
        orderEntity.setFlag(flag);
        Date settleTime = StringUtils.isNotBlank(entity.getSettleTime()) ? LocalDateUtil.localDateTime2Date(ZonedDateTime.parse(entity.getSettleTime()).toLocalDateTime(), ZoneId.of(timeZone)) : null;
        orderEntity.setOrignalBillTime(settleTime);
        orderEntity.setOrignalReckonTime(settleTime);
        //设置赔率和盘口类型信息
        orderEntity.setOdds(getMinOdds(entity));
        orderEntity.setOddsType(convertOddsType(entity));
        orderEntity.setCreationDate(createTime);
        orderEntity.setReckonTime(settleTime);
        return orderEntity;
    }

    public static OrderEntity transferCashoutEntityForXJ(Xj188OrderEntity entity, String timeZone) {
        if (entity == null) {
            return null;
        }
        OrderEntity orderEntity = new OrderEntity();
        BigDecimal cusAccount = entity.getCashoutStake().subtract(entity.getCashoutReturnAmount()).abs();

        orderEntity.setLoginName(entity.getMemberCode());
        //订单单号
        orderEntity.setBillNo("co" + entity.getId());
        Date createTime = LocalDateUtil.localDateTime2Date(ZonedDateTime.parse(entity.getCreateTime()).toLocalDateTime(), ZoneId.of(timeZone));
        orderEntity.setBillTime(createTime);
        orderEntity.setAccount(entity.getCashoutStake());
        //获取注单的结算状态
        int flag = getFlag(entity);
        orderEntity.setFlag(flag);
        orderEntity.setValidAccount(cusAccount);
        orderEntity.setCusAccount(cusAccount);
        orderEntity.setRemainAmount(cusAccount);
        Date settleTime = StringUtils.isNotBlank(entity.getSettleTime()) ? LocalDateUtil.localDateTime2Date(ZonedDateTime.parse(entity.getSettleTime()).toLocalDateTime(), ZoneId.of(timeZone)) : null;
        orderEntity.setOrignalBillTime(settleTime);
        orderEntity.setOrignalReckonTime(settleTime);
        //设置赔率和盘口类型信息
        orderEntity.setOdds(getMinOdds(entity));
        orderEntity.setOddsType(convertOddsType(entity));
        orderEntity.setCreationDate(createTime);
        orderEntity.setReckonTime(settleTime);
        return orderEntity;
    }

    private static BigDecimal getMinOdds(Xj188OrderEntity entity) {
        if(CollectionUtils.isEmpty(entity.getBets())) {
            return entity.getOdds();
        }
        BigDecimal minOdds = entity.getBets().stream().filter(bet -> null != bet.getOdds()).min(Comparator.comparing(Xj188OrderDetailEntity::getOdds)).get().getOdds();
        return entity.getOdds().compareTo(BigDecimal.ZERO) > 0 ? minOdds.compareTo(entity.getOdds()) > 0 ? entity.getOdds() : minOdds : minOdds;
    }


    /**
     * 赔率类型转换
     *
     * @param entity
     * @return
     */
    private static String convertOddsType(Xj188OrderEntity entity) {
        String oddsType = "";
        if (entity.getOddsType() == 1) {
            oddsType = UtilConstants.OddsTypeEnum.DECIMAL.getValueStr();
        }
        if (entity.getOddsType() == 3) {
            oddsType = UtilConstants.OddsTypeEnum.MALAY.getValueStr();
        }
        return oddsType;
    }

    /**
     * 获取注单的状态
     *
     * @param entity
     * @return
     */
    private static int getFlag(Xj188OrderEntity entity) {
        //默认未结算
        int flag = 0;
        //注单状态
        int status = entity.getWagerStatus();
        if (status == 2) {
            //已结算
            flag = UtilConstants.ORDERS_FLAG_ENUM.SETTLED.getFalg();
        } else if (status == 3 || status == 4) {
            flag = UtilConstants.ORDERS_FLAG_ENUM.CANCELED.getFalg();
        } else {
            //未结算
            flag = UtilConstants.ORDERS_FLAG_ENUM.UNSETTLED.getFalg();
        }
        return flag;
    }

    /**
     * 构建订单查询抓取参数
     *
     * @param parameterMap
     * @return
     */
    private String generateReqParams(Map<String, Object> parameterMap) {
        String key = parameterMap.get("key").toString();
        String iv = parameterMap.get("iv").toString();
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("isSettled", parameterMap.get("isSettled"));
        //体育类注单默认4000
        jsonObject.put("gameType", 4000);

        String timeZone = (String) (parameterMap.get("timeZone"));
        DateTimeFormatter pattern = DateTimeFormatter.ofPattern(DateUtil.C_TIME_PATTON_DEFAULT);
        pattern.withZone(ZoneId.of(timeZone));
        LocalDateTime dtBeginTime = LocalDateTime.parse((String) parameterMap.get("begintime"), pattern);
        LocalDateTime dtEndTime = LocalDateTime.parse((String) parameterMap.get("endtime"), pattern);
        jsonObject.put("startTime", ZonedDateTime.of(dtBeginTime, ZoneId.of(timeZone)).format(DateTimeFormatter.ISO_OFFSET_DATE_TIME));
        jsonObject.put("endTime", ZonedDateTime.of(dtEndTime, ZoneId.of(timeZone)).format(DateTimeFormatter.ISO_OFFSET_DATE_TIME));

        Map<String, Object> carrier = Maps.newHashMap();
        String requestId = UUID.randomUUID().toString();
        carrier.put("requestId", requestId);
        carrier.put("requestTimeStr", DateUtil.formatDate2Str(new Date(), "yyyy-MM-dd HH:mm:ss"));
        //对业务参数进行AES加密返回params
        Map<String, Object> paramsMap = Maps.newHashMap();
        paramsMap.put("data", jsonObject);
        paramsMap.put("carrier", carrier);
        String encodeJson = AesCryptUtil.encryptAES256(JsonUtil.toJSONString(paramsMap), key, iv);
        return encodeJson;
    }

    String result = "{\n" +
            "    \"carrier\": {},\n" +
            "    \"code\": \"COMM0000\",\n" +
            "    \"data\": [\n" +
            "        {\n" +
            "            \"bets\": [\n" +
            "                {\n" +
            "                    \"betStatus\": 0,\n" +
            "                    \"betType\": \"BigSmall\",\n" +
            "                    \"event\": {\n" +
            "                        \"endTime\": \"2016-05-21T12:30:52.4869690+08:00\",\n" +
            "                        \"eventType\": \"Football\",\n" +
            "                        \"gameType\": 2310,\n" +
            "                        \"id\": \"112231\",\n" +
            "                        \"name\": \"123456\",\n" +
            "                        \"results\": \"1,2,3,4,5\",\n" +
            "                        \"startTime\": \"2016-05-21T12:30:52.4869690+08:00\",\n" +
            "                        \"tag\": \"\"\n" +
            "                    },\n" +
            "                    \"group\": \"\",\n" +
            "                    \"handicap\": 0,\n" +
            "                    \"id\": \"ABC-123456\",\n" +
            "                    \"odds\": 2.00,\n" +
            "                    \"period\": \"\",\n" +
            "                    \"remark\": \"\",\n" +
            "                    \"returnAmount\": 200.00,\n" +
            "                    \"selection\": \"Small\",\n" +
            "                    \"seq\": 1,\n" +
            "                    \"stake\": 100.00\n" +
            "                },\n" +
            "                {\n" +
            "                    \"betStatus\": 0,\n" +
            "                    \"betType\": \"football\",\n" +
            "                    \"event\": {\n" +
            "                        \"endTime\": \"2016-05-21T12:30:52.4869690+08:00\",\n" +
            "                        \"eventType\": \"Football\",\n" +
            "                        \"gameType\": 2310,\n" +
            "                        \"id\": \"112232\",\n" +
            "                        \"name\": \"123456\",\n" +
            "                        \"results\": \"1,2,3,4,5\",\n" +
            "                        \"startTime\": \"2016-05-21T12:30:52.4869690+08:00\",\n" +
            "                        \"tag\": \"\"\n" +
            "                    },\n" +
            "                    \"group\": \"\",\n" +
            "                    \"handicap\": 0,\n" +
            "                    \"id\": \"ABC-123456\",\n" +
            "                    \"odds\": 2.00,\n" +
            "                    \"period\": \"\",\n" +
            "                    \"remark\": \"\",\n" +
            "                    \"returnAmount\": 200.00,\n" +
            "                    \"selection\": \"Small\",\n" +
            "                    \"seq\": 1,\n" +
            "                    \"stake\": 100.00\n" +
            "                },\n" +
            "                {\n" +
            "                    \"betStatus\": 0,\n" +
            "                    \"betType\": \"BigSmall\",\n" +
            "                    \"event\": {\n" +
            "                        \"endTime\": \"2016-05-21T12:30:52.4869690+08:00\",\n" +
            "                        \"eventType\": \"basketball\",\n" +
            "                        \"gameType\": 2310,\n" +
            "                        \"id\": \"112233\",\n" +
            "                        \"name\": \"123456\",\n" +
            "                        \"results\": \"1,2,3,4,5\",\n" +
            "                        \"startTime\": \"2016-05-21T12:30:52.4869690+08:00\",\n" +
            "                        \"tag\": \"\"\n" +
            "                    },\n" +
            "                    \"group\": \"\",\n" +
            "                    \"handicap\": 0,\n" +
            "                    \"id\": \"ABC-123456\",\n" +
            "                    \"odds\": 2.00,\n" +
            "                    \"period\": \"\",\n" +
            "                    \"remark\": \"\",\n" +
            "                    \"returnAmount\": 200.00,\n" +
            "                    \"selection\": \"Small\",\n" +
            "                    \"seq\": 1,\n" +
            "                    \"stake\": 100.00\n" +
            "                },\n" +
            "                {\n" +
            "                    \"betStatus\": 0,\n" +
            "                    \"betType\": \"BigSmall\",\n" +
            "                    \"event\": {\n" +
            "                        \"endTime\": \"2016-05-21T12:30:52.4869690+08:00\",\n" +
            "                        \"eventType\": \"Football\",\n" +
            "                        \"gameType\": 2310,\n" +
            "                        \"id\": \"123456\",\n" +
            "                        \"name\": \"123456\",\n" +
            "                        \"results\": \"1,2,3,4,5\",\n" +
            "                        \"startTime\": \"2016-05-21T12:30:52.4869690+08:00\",\n" +
            "                        \"tag\": \"\"\n" +
            "                    },\n" +
            "                    \"group\": \"\",\n" +
            "                    \"handicap\": 0,\n" +
            "                    \"id\": \"ABC-123456\",\n" +
            "                    \"odds\": 2.00,\n" +
            "                    \"period\": \"\",\n" +
            "                    \"remark\": \"\",\n" +
            "                    \"returnAmount\": 200.00,\n" +
            "                    \"selection\": \"Small\",\n" +
            "                    \"seq\": 1,\n" +
            "                    \"stake\": 100.00\n" +
            "                }\n" +
            "            ],\n" +
            "            \"channel\": 10,\n" +
            "            \"createTime\": \"2016-05-21T12:27:52.4869690+08:00\",\n" +
            "            \"currencyCode\": \"CNY\",\n" +
            "            \"id\": \"ABC-123456\",\n" +
            "            \"ipAddress\": \"192.168.1.1\",\n" +
            "            \"memberCode\": \"hello_9527\",\n" +
            "            \"odds\": 2.00,\n" +
            "            \"oddsType\": 1,\n" +
            "            \"returnAmount\": 200.00,\n" +
            "            \"settleTime\": \"2016-05-21T12:30:52.4869690+08:00\",\n" +
            "            \"stake\": 100.00,\n" +
            "            \"wagerStatus\": 1\n" +
            "        }\n" +
            "    ],\n" +
            "    \"msg\": \"Success\"\n" +
            "}";
}

