package main.java.com.gw.common.system.parse.vo;

import java.util.ArrayList;
import java.util.List;

public class BetFiles {
    private String errorCode;
    private List<FileInfo> betFiles = new ArrayList<FileInfo>();

    public void add(FileInfo obj) {
        betFiles.add(obj);
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public List<FileInfo> getBetFiles() {
        return betFiles;
    }

    public void setBetFiles(List<FileInfo> betFiles) {
        this.betFiles = betFiles;
    }


}
