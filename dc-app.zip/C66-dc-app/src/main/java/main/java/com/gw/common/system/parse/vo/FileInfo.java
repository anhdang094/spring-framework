package main.java.com.gw.common.system.parse.vo;

public class FileInfo implements Comparable<FileInfo> {
    private Integer fileID;
    private String periodFrom;
    private String periodTo;
    private String creationDate;
    private long rowIdFrom;
    private long rowIdTo;

    public Integer getFileID() {
        return fileID;
    }

    public void setFileID(Integer fileID) {
        this.fileID = fileID;
    }

    public String getPeriodFrom() {
        return periodFrom;
    }

    public void setPeriodFrom(String periodFrom) {
        this.periodFrom = periodFrom;
    }

    public String getPeriodTo() {
        return periodTo;
    }

    public void setPeriodTo(String periodTo) {
        this.periodTo = periodTo;
    }

    public String getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }

    public long getRowIdFrom() {
        return rowIdFrom;
    }

    public void setRowIdFrom(long rowIdFrom) {
        this.rowIdFrom = rowIdFrom;
    }

    public long getRowIdTo() {
        return rowIdTo;
    }

    public void setRowIdTo(long rowIdTo) {
        this.rowIdTo = rowIdTo;
    }

    @Override
    public int compareTo(FileInfo info) {
        return this.getFileID().compareTo(info.getFileID());
    }


}
