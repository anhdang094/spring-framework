package main.java.com.gw.common.system.parse.vo;

import java.io.Serializable;

public class OpenBetInfo implements Serializable {
    public String rowID;
    public String agentID;
    public String customerID;
    public String merchantCustomerID;
    public String betID;
    public String betTypeID;
    public String betTypeName;
    public String lineID;
    public String lineTypeID;
    public String lineTypeName;
    public String rowTypeID;
    public String branchId;
    public String branchName;
    public String leagueID;
    public String leagueName;
    public String creationDate;
    public String homeTeam;
    public String awayTeam;
    public String stake;
    public String odds;
    public String points;
    public String score;
    public String status;
    public String yourBet;
    public String isForEvent;
    public String eventTypeID;
    public String eventTypeName;
    public String orderID;
    public String updateDate;
    public String pL;
    public String teamMappingID;
    public String liveScore1;
    public String liveScore2;
    public String eventDate;
    public String masterEventID;
    public String commonStatusID;
    public String webProviderID;
    public String webProviderName;
    public String bonusamount;
    public String unknow;
    public String purchaseID;


    public String getRowID() {
        return rowID;
    }


    public void setRowID(String rowID) {
        this.rowID = rowID;
    }


    public String getAgentID() {
        return agentID;
    }


    public void setAgentID(String agentID) {
        this.agentID = agentID;
    }


    public String getCustomerID() {
        return customerID;
    }


    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }


    public String getMerchantCustomerID() {
        return merchantCustomerID;
    }


    public void setMerchantCustomerID(String merchantCustomerID) {
        this.merchantCustomerID = merchantCustomerID;
    }


    public String getBetID() {
        return betID;
    }


    public void setBetID(String betID) {
        this.betID = betID;
    }


    public String getBetTypeID() {
        return betTypeID;
    }


    public void setBetTypeID(String betTypeID) {
        this.betTypeID = betTypeID;
    }


    public String getBetTypeName() {
        return betTypeName;
    }


    public void setBetTypeName(String betTypeName) {
        this.betTypeName = betTypeName;
    }


    public String getLineID() {
        return lineID;
    }


    public void setLineID(String lineID) {
        this.lineID = lineID;
    }


    public String getLineTypeID() {
        return lineTypeID;
    }


    public void setLineTypeID(String lineTypeID) {
        this.lineTypeID = lineTypeID;
    }


    public String getLineTypeName() {
        return lineTypeName;
    }


    public void setLineTypeName(String lineTypeName) {
        this.lineTypeName = lineTypeName;
    }


    public String getRowTypeID() {
        return rowTypeID;
    }


    public void setRowTypeID(String rowTypeID) {
        this.rowTypeID = rowTypeID;
    }


    public String getBranchId() {
        return branchId;
    }


    public void setBranchId(String branchId) {
        this.branchId = branchId;
    }


    public String getBranchName() {
        return branchName;
    }


    public void setBranchName(String branchName) {
        this.branchName = branchName;
    }


    public String getLeagueID() {
        return leagueID;
    }


    public void setLeagueID(String leagueID) {
        this.leagueID = leagueID;
    }


    public String getLeagueName() {
        return leagueName;
    }


    public void setLeagueName(String leagueName) {
        this.leagueName = leagueName;
    }


    public String getCreationDate() {
        return creationDate;
    }


    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }


    public String getHomeTeam() {
        return homeTeam;
    }


    public void setHomeTeam(String homeTeam) {
        this.homeTeam = homeTeam;
    }


    public String getAwayTeam() {
        return awayTeam;
    }


    public void setAwayTeam(String awayTeam) {
        this.awayTeam = awayTeam;
    }


    public String getStake() {
        return stake;
    }


    public void setStake(String stake) {
        this.stake = stake;
    }


    public String getOdds() {
        return odds;
    }


    public void setOdds(String odds) {
        this.odds = odds;
    }


    public String getPoints() {
        return points;
    }


    public void setPoints(String points) {
        this.points = points;
    }


    public String getScore() {
        return score;
    }


    public void setScore(String score) {
        this.score = score;
    }


    public String getStatus() {
        return status;
    }


    public void setStatus(String status) {
        this.status = status;
    }


    public String getYourBet() {
        return yourBet;
    }


    public void setYourBet(String yourBet) {
        this.yourBet = yourBet;
    }


    public String getIsForEvent() {
        return isForEvent;
    }


    public void setIsForEvent(String isForEvent) {
        this.isForEvent = isForEvent;
    }


    public String getEventTypeID() {
        return eventTypeID;
    }


    public void setEventTypeID(String eventTypeID) {
        this.eventTypeID = eventTypeID;
    }


    public String getEventTypeName() {
        return eventTypeName;
    }


    public void setEventTypeName(String eventTypeName) {
        this.eventTypeName = eventTypeName;
    }


    public String getOrderID() {
        return orderID;
    }


    public void setOrderID(String orderID) {
        this.orderID = orderID;
    }


    public String getUpdateDate() {
        return updateDate;
    }


    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }


    public String getpL() {
        return pL;
    }


    public void setpL(String pL) {
        this.pL = pL;
    }


    public String getTeamMappingID() {
        return teamMappingID;
    }


    public void setTeamMappingID(String teamMappingID) {
        this.teamMappingID = teamMappingID;
    }


    public String getLiveScore1() {
        return liveScore1;
    }


    public void setLiveScore1(String liveScore1) {
        this.liveScore1 = liveScore1;
    }


    public String getLiveScore2() {
        return liveScore2;
    }


    public void setLiveScore2(String liveScore2) {
        this.liveScore2 = liveScore2;
    }


    public String getEventDate() {
        return eventDate;
    }


    public void setEventDate(String eventDate) {
        this.eventDate = eventDate;
    }


    public String getMasterEventID() {
        return masterEventID;
    }


    public void setMasterEventID(String masterEventID) {
        this.masterEventID = masterEventID;
    }


    public String getCommonStatusID() {
        return commonStatusID;
    }


    public void setCommonStatusID(String commonStatusID) {
        this.commonStatusID = commonStatusID;
    }


    public String getWebProviderID() {
        return webProviderID;
    }


    public void setWebProviderID(String webProviderID) {
        this.webProviderID = webProviderID;
    }


    public String getWebProviderName() {
        return webProviderName;
    }


    public void setWebProviderName(String webProviderName) {
        this.webProviderName = webProviderName;
    }


    public String getBonusamount() {
        return bonusamount;
    }


    public void setBonusamount(String bonusamount) {
        this.bonusamount = bonusamount;
    }


    public String getUnknow() {
        return unknow;
    }


    public void setUnknow(String unknow) {
        this.unknow = unknow;
    }


    public String getPurchaseID() {
        return purchaseID;
    }


    public void setPurchaseID(String purchaseID) {
        this.purchaseID = purchaseID;
    }


    @Override
    public String toString() {
        return "BetInfo [rowID=" + rowID + ", agentID=" + agentID + ", customerID=" + customerID
                + ", merchantCustomerID=" + merchantCustomerID + ", betID=" + betID + ", betTypeID=" + betTypeID
                + ", betTypeName=" + betTypeName + ", lineID=" + lineID + ", lineTypeID=" + lineTypeID
                + ", lineTypeName=" + lineTypeName + ", rowTypeID=" + rowTypeID + ", branchId=" + branchId
                + ", branchName=" + branchName + ", leagueID=" + leagueID + ", leagueName=" + leagueName
                + ", creationDate=" + creationDate + ", homeTeam=" + homeTeam + ", awayTeam=" + awayTeam + ", stake="
                + stake + ", odds=" + odds + ", points=" + points + ", score=" + score + ", status=" + status
                + ", yourBet=" + yourBet + ", isForEvent=" + isForEvent + ", eventTypeID=" + eventTypeID
                + ", eventTypeName=" + eventTypeName + ", orderID=" + orderID + ", updateDate=" + updateDate + ", pL="
                + pL + ", teamMappingID=" + teamMappingID + ", liveScore1=" + liveScore1 + ", liveScore2=" + liveScore2
                + ", eventDate=" + eventDate + ", masterEventID=" + masterEventID + ", commonStatusID=" + commonStatusID
                + ", webProviderID=" + webProviderID + ", webProviderName=" + webProviderName + ", bonusamount="
                + bonusamount + ", unknow=" + unknow + ", purchaseID=" + purchaseID + "]\n";
    }


}
