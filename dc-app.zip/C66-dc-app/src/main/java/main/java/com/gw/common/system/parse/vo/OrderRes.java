package main.java.com.gw.common.system.parse.vo;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

public class OrderRes<T> extends Result<T> {

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this);
    }

}
