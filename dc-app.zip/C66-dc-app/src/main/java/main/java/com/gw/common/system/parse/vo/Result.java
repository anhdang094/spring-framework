package main.java.com.gw.common.system.parse.vo;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

@Slf4j
public class Result<T> {

    private Integer perpage = 0;
    private Integer numpage = 0;
    private Integer TotalPage = 0;
    private Integer total = 0;
    private String returnCode;
    private String code;
    private String comment;
    private List<T> orderList = new ArrayList<>();

    public void addOrder(T bill) {
        orderList.add(bill);
    }

    public Integer getPerpage() {
        return perpage;
    }

    public void setPerpage(Integer perpage) {
        this.perpage = perpage;
    }

    public Integer getNumpage() {
        return numpage;
    }

    public void setNumpage(Integer numpage) {
        this.numpage = numpage;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public String getReturnCode() {
        return returnCode;
    }

    public void setReturnCode(String returnCode) {
        this.returnCode = returnCode;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public List<T> getOrderList() {
        return orderList;
    }

    public void setOrderList(List<T> orderList) {
        this.orderList = orderList;
    }

    public boolean isSuccessed() {
        return "0".equals(code) || "000".equals(returnCode);
    }

    /**
     * 指数返回錯誤代碼
     *
     * @return
     */
    public boolean codeError_Index() {
        if (StringUtils.equals(code, "#key_error#")) {
            return true;
        }
        if (StringUtils.equals(code, "#agent_error#")) {
            return true;
        }
        if (StringUtils.equals(code, "#agent_not_exist_error#")) {
            return true;
        }
        if (StringUtils.equals(code, "#agent_password_error#")) {
            return true;
        }
        if (StringUtils.equals(code, "#user_password_error#")) {
            return true;
        }
        if (StringUtils.equals(code, "#user_param_error#")) {
            return true;
        }
        if (StringUtils.equals(code, "#add_user_failed#")) {
            return true;
        }
        if (StringUtils.equals(code, "#pub_parameter_error#")) {
            return true;
        }
        if (StringUtils.equals(code, "#agent_level_less#")) {
            return true;
        }
        if (StringUtils.equals(code, "#customer_already_exist#")) {
            return true;
        }
        if (StringUtils.equals(code, "#agent_upagent_credit_lack#")) {
            return true;
        }
        if (StringUtils.equals(code, "#pub_trade_error#")) {
            return true;
        }
        if (StringUtils.equals(code, "#customer_not_exist#")) {
            return true;
        }
        if (StringUtils.equals(code, "#NO_USER#")) {
            return true;
        }
        if (StringUtils.equals(code, "#NO_PARENT#")) {
            return true;
        }
        if (StringUtils.equals(code, "#AGENT_UP_NOT_FOUND#")) {
            return true;
        }
        if (StringUtils.equals(code, "#pub_credit_no_change#")) {
            return true;
        }
        if (StringUtils.equals(code, "#pub_parameter_error#")) {
            return true;
        }
        if (StringUtils.equals(code, "#pub_trade_error#")) {
            return true;
        }
        if (StringUtils.equals(code, "#agent_pwd_wrong#")) {
            return true;
        }
        if (StringUtils.equals(code, "#agent_not_found#")) {
            return true;
        }
        if (StringUtils.equals(code, "#customer_not_found#")) {
            return true;
        }
        if (StringUtils.equals(code, "#agent_no_op#")) {
            return true;
        }
        if (StringUtils.equals(code, "#customer_not_agent#")) {
            return true;
        }
        if (StringUtils.equals(code, "#invalid_billno#")) {
            return true;
        }
        if (StringUtils.equals(code, "#No_Begin_Time#")) {
            return true;
        }
        return StringUtils.equals(code, "#No_End_Time#");
    }

    public boolean no_Record_Index() {
        return StringUtils.equals(code, "#No_Record#");
    }

    public boolean codeError_Gt1() {
        return StringUtils.equals(code, "GETS_SID_ERROR");
    }

    public boolean success_Gt1() {
        return StringUtils.equals(code, "AMS_OK");
    }

    public boolean no_Record_Gt1() {
        return false;
    }


    @Override
    public String toString() {
        Field[] fields = this.getClass().getDeclaredFields();
        StringBuffer strBuf = new StringBuffer();
        strBuf.append(this.getClass().getName());
        strBuf.append("(");
        for (int i = 0; i < fields.length; i++) {
            Field fd = fields[i];
            strBuf.append(fd.getName() + ":");
            try {
                strBuf.append(fd.get(this));
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            if (i != fields.length - 1) {
                strBuf.append("|");
            }
        }
        strBuf.append(")");
        return strBuf.toString();
    }

    /**
     * 总页数
     * added by Span
     */
    private int totalPages = 0;

    public int getTotalPages() {
        return totalPages;
    }

    public void setTotalPages(int totalPages) {
        this.totalPages = totalPages;
    }

    /**
     * 当前页
     * added by Span
     */
    private int currentPage = 0;

    public int getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(int currentPage) {
        this.currentPage = currentPage;
    }

}
