package main.java.com.gw.common.system.parse.vo;

import java.util.List;

public class SBOTransferData {

    private Data data;
    private Error error;

    public class Data {
        private List<TransferLog> translogs;
        private String last_record_time;

        public List<TransferLog> getTranslogs() {
            return translogs;
        }

        public void setTranslogs(List<TransferLog> translogs) {
            this.translogs = translogs;
        }

        public String getLast_record_time() {
            return last_record_time;
        }

        public void setLast_record_time(String last_record_time) {
            this.last_record_time = last_record_time;
        }
    }

    public class TransferLog {
        private String player_name;
        private String amount;
        private String currency;
        private String balance;
        private String before_balance;
        private String type;
        private String traceId;
        private String created_at;
        private String product_id;

        public String getPlayer_name() {
            return player_name;
        }

        public void setPlayer_name(String player_name) {
            this.player_name = player_name;
        }

        public String getAmount() {
            return amount;
        }

        public void setAmount(String amount) {
            this.amount = amount;
        }

        public String getCurrency() {
            return currency;
        }

        public void setCurrency(String currency) {
            this.currency = currency;
        }

        public String getBalance() {
            return balance;
        }

        public void setBalance(String balance) {
            this.balance = balance;
        }

        public String getBefore_balance() {
            return before_balance;
        }

        public void setBefore_balance(String before_balance) {
            this.before_balance = before_balance;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getTraceId() {
            return traceId;
        }

        public void setTraceId(String traceId) {
            this.traceId = traceId;
        }

        public String getCreated_at() {
            return created_at;
        }

        public void setCreated_at(String created_at) {
            this.created_at = created_at;
        }

        public String getProduct_id() {
            return product_id;
        }

        public void setProduct_id(String product_id) {
            this.product_id = product_id;
        }
    }

    public class Error {
        private String code;
        private String message;

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }
}
