package main.java.com.gw.common.system.props;

import java.util.Map;

public class CustomerPropertyholder {


    private static Map<String, String> propertiesMap;

    public static void setPropertiesMap(Map<String, String> propertiesMap) {
	    CustomerPropertyholder.propertiesMap = propertiesMap;
    }

    public static String getProperty(String key) {
        return propertiesMap.get(key);
    }


}
