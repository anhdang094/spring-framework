package main.java.com.gw.common.system.redis;

import com.google.common.base.MoreObjects;
import org.apache.commons.lang.StringUtils;

/**
 * project: GWDataCenterApp
 * author: Walter
 * create: 2019/4/22
 **/
public class Rlock implements AutoCloseable {

    private String key;
    private Boolean isLock;
    private String lockId;

    public Rlock(String key, String lockId, Boolean isLock) {
        this.isLock = MoreObjects.firstNonNull(isLock, Boolean.FALSE);
        if (StringUtils.isEmpty(key)) {
            this.isLock = Boolean.FALSE;
            this.key = "";
            this.lockId = "";
        }
        else {
            this.key = key;
            this.lockId = lockId;
        }
    }

    @Override
    public void close() throws Exception {
        if (!StringUtils.isEmpty(key)) {
            TaskLock.tryUnlock(this);
        }
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public Boolean getLock() {
        return isLock;
    }

    public void setLock(Boolean lock) {
        isLock = lock;
    }

    public String getLockId() {
        return lockId;
    }

    public void setLockId(String lockId) {
        this.lockId = lockId;
    }
}