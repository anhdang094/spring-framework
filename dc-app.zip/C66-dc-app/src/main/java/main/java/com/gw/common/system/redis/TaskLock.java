package main.java.com.gw.common.system.redis;

import main.java.com.gw.common.framework.util.SpringContext;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * project: GWDataCenterApp
 * author: Walter
 * create: 2019/4/22
 **/
@Component
public class TaskLock {
    private static Logger logger = LoggerFactory.getLogger(TaskLock.class);

    private static StringRedisTemplate redisTemplate;

    /**
     * 增加key前缀和特殊标记，防止干扰
     */
    public static final String LOCK_KEY_PREFIX = "DC-APP:LOCK:";

    /**
     * 默认锁的有效时间:2min
     * 针对特定taskId，只要上锁成功，未来再次执行该taskId任务*至多*2min后
     */
    private static final int EXPIRE = 60 * 2;

    public TaskLock(@Autowired StringRedisTemplate redisTemplate) {
        TaskLock.redisTemplate = redisTemplate;
        init();
    }

    public static void init() {
        logger.info("TaskLock init {}", redisTemplate);
        logger.warn("start validate redisClient in TaskLock");
        String key = LOCK_KEY_PREFIX + "test";
        String value = "test";
        logger.warn("redisClient set {} {}", key, value);
        redisTemplate.opsForValue().set(LOCK_KEY_PREFIX + "test", "test", 60L, TimeUnit.SECONDS);
        String cachedValue = redisTemplate.opsForValue().get(key);
        logger.warn("redisClient get {} {}", key, cachedValue);
        logger.warn("redisClient delete {}", key);
        redisTemplate.delete(key);
        cachedValue = redisTemplate.opsForValue().get(key);
        logger.warn("redisClient get deleted {} {}", key, cachedValue);
        logger.warn("finish validate redisClient in TaskLock");
    }

    public static Rlock tryAcquireLock(String key) {
        if (StringUtils.isEmpty(key)) {
            return new Rlock(key, "", false);
        }
        final String realKey = LOCK_KEY_PREFIX + key;
        // lockId作为value写入redis中，解锁就是删除key的过程，要解锁必须先校验lockId。
        // 因此两种情况可能导致解锁失败：
        // 1. 知道key，不知道lockId，那么无法解锁，防止没有该锁对象的线程也可以释放锁
        // 2. 老线程要释放锁时，该key在redis中已经过期，而此时一个新线程刚刚为该key上锁，如果不校验lockId，就会出现老线程错误的解锁了新线程的锁的情况
        final String lockId = UUID.randomUUID().toString().replace("-", "");
        // 当且仅当该key在redis中不存在，且key-value写入redis成功时，返回TRUE
        Boolean result = set(realKey, lockId, EXPIRE);
        if (null == result? false : result) {
            logger.info("acquire one lock for key {}", realKey);
        }
        else {
            logger.warn("acquire no lock for key {}", realKey);
        }
        return new Rlock(key, lockId, result);
    }

    static void tryUnlock(Rlock lock) {
        if (null != lock && lock.getLock()) {
            final String realKey = LOCK_KEY_PREFIX + lock.getKey();
            if (get(realKey).equals(lock.getLockId())) {
                redisTemplate.delete(realKey);
            }
        }
    }

    public static Boolean set(final String key, final String value, Integer expireTimeInSeconds) {
        Boolean result = false;
        try {
            ValueOperations<String, String> operations = redisTemplate.opsForValue();
            result = operations.setIfAbsent(key, value, expireTimeInSeconds, TimeUnit.SECONDS);
        } catch (Exception e) {
            logger.error("Redis设置过期写入异常{}", e.getMessage(), e);
        }
        return result;
    }

    public static String get(final String key) {
        String value = "";
        try {
            ValueOperations<String, String> operations = redisTemplate.opsForValue();
            value = operations.get(key);
        } catch (Exception e) {
            logger.error("Redis取值异常{}", e.getMessage(), e);
        }
        return value;
    }
}