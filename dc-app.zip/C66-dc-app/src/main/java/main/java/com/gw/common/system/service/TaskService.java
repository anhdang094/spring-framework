package main.java.com.gw.common.system.service;

import main.java.com.gw.datacenter.allocation.entity.Task;

import java.util.List;

/**
 * Created by Span on 2016/6/6.
 */
public interface TaskService {

    /**
     * 获取可执行的Task
     */
    List<Task> getAllTask();
}

