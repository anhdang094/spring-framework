package main.java.com.gw.common.system.service.impl;

import main.java.com.gw.common.system.service.TaskService;
import main.java.com.gw.datacenter.allocation.entity.Task;

import java.util.List;

/**
 * Created by Span on 2016/6/6.
 */
public class TaskServiceImpl implements TaskService {


    /**
     * 获取可执行的Task
     */
    @Override
    public List<Task> getAllTask() {
        return null;
    }
}
