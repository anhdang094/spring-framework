package main.java.com.gw.common.system.timer;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.redis.Rlock;
import main.java.com.gw.common.system.redis.TaskLock;
import main.java.com.gw.datacenter.allocation.entity.AllocationEntity;
import org.apache.commons.collections.CollectionUtils;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.MDC;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @author Lily.Y
 * @date 2019/5/29
 * */
@Slf4j
public class AccountTransfer4QGTimer extends AllAbstractTimer{
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
        log.info(context.toString());
        String taskId;
        Long endSeconds = 0L;
        Long beginSeconds = 0L;
        JobDataMap jobDataMap = context.getJobDetail().getJobDataMap();
        taskId = jobDataMap.getString("taskId");
        log.info("--DC定时任务日志-TaskID-{}-",taskId);
        try(Rlock lock = TaskLock.tryAcquireLock(taskId)) {
            if (lock.getLock()) {
                Map<String, Object> parameterMap = new HashMap<>();
                List<AllocationEntity> allocationEntityList = allocationDao.getAllocationList(new String[]{taskId});
                if (CollectionUtils.isNotEmpty(allocationEntityList)) {
                    Integer taskInteger = Integer.valueOf(taskId);
                    AllocationEntity allocationEntity = allocationEntityList.get(0);
                    if (allocationEntity != null && taskInteger.equals(allocationEntity.getTaskId())) {
                        parameterMap.put(UtilConstants.ORDER_BEGIN_TIME, DateUtil.formatDate2Str(allocationEntity.getTaskBeginTime()));
                        parameterMap.put(UtilConstants.ORDER_END_TIME, DateUtil.formatDate2Str(allocationEntity.getTaskEndTime()));
                        parameterMap.put(UtilConstants.ORDER_PAGE_NUMBER, String.valueOf(allocationEntity.getPageSize()));
                        parameterMap.put(UtilConstants.GLOBAL_PLATFORMID_KEY, allocationEntity.getPlatformId());
                        parameterMap.put("instanceId", allocationEntity.getAgCode());
                        parameterMap.put("timeZone", allocationEntity.getTimeZone());
                        parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                        parameterMap.put("baseUrl", allocationEntity.getUrl());
                        String beginTime = DateUtil.formatDate2Str(allocationEntity.getTaskBeginTime());
                        String endTime = DateUtil.formatDate2Str(allocationEntity.getTaskEndTime());
                        parameterMap.put("startTime", beginTime);
                        parameterMap.put("endTime", endTime);
                        parameterMap.put("begintime", beginTime);
                        parameterMap.put("endtime", endTime);
                        beginSeconds = Long.valueOf(allocationEntity.getIncrementBegintime());
                        endSeconds = Long.valueOf(allocationEntity.getIncrementEndtime());
                        parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                        parameterMap.put("endSeconds", String.valueOf(endSeconds));
                        parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                        parameterMap.put(UtilConstants.ORDER_PRODUCT_ID, allocationEntity.getProductionId());
                        parameterMap.put("currency", allocationEntity.getCurrency() == null ? "CNY" : allocationEntity.getCurrency());//获取币种类型
                        parameterMap.put("version", allocationEntity.getOrderField());
                        parameterMap.put("id", allocationEntity.getOrderWay());
                        parameterMap.put("key", allocationEntity.getPassword());
                        parameterMap.put("merchantCode", allocationEntity.getAccountName());
                        parameterMap.put("pageSize", String.valueOf(allocationEntity.getPageSize()));
                        log.info("qg AccountTransfer4QGTimer.execute(), Get the task:id=" + allocationEntity.getTaskId() + ",beginTime=" + allocationEntity.getTaskBeginTime() + ",endTime=" + allocationEntity.getTaskEndTime());
                    }
                }
                parameterMap = ToolUtil.updateTimeForParameterMap(parameterMap, beginSeconds, endSeconds);
                String timeZone = (String) parameterMap.get("timeZone");
                int dataDelay = (int) parameterMap.get("dataDelay");
                boolean isWait = ToolUtil.isWaitXMins(parameterMap, timeZone, dataDelay);
                if (!isWait) {
                    String baseUrl = (String) parameterMap.get("baseUrl");
                    accountTransferService.insertAccountTransferForQG(parameterMap, baseUrl, null, false);

                }
            }
        } catch (Exception e) {
            log.error("qg AccountTransfer4QGTimer Failed to parse json:" + e.getMessage(), e);
        }
    }
}
