package main.java.com.gw.common.system.timer;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.redis.Rlock;
import main.java.com.gw.common.system.redis.TaskLock;
import main.java.com.gw.datacenter.allocation.entity.AllocationEntity;
import org.apache.commons.collections.CollectionUtils;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.MDC;

import java.util.*;

@Slf4j
public class AccountTransfer4SBOTimer extends AllAbstractTimer {

    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
        log.info(context.toString());
        long beginSeconds = 0L;
        long endSeconds = 0L;
        JobDataMap jobDataMap = context.getJobDetail().getJobDataMap();
        String taskId = jobDataMap.getString("taskId");
        log.info("--DC定时任务日志-TaskID-{}-",taskId);
        try (Rlock lock = TaskLock.tryAcquireLock(taskId)) {
            if (lock.getLock()) {
                Map<String, Object> parameterMap = new HashMap<>();
                List<AllocationEntity> allocationEntityList = allocationDao.getAllocationList(new String[]{taskId});
                if (CollectionUtils.isNotEmpty(allocationEntityList)) {
                    Integer taskInteger = Integer.valueOf(taskId);
                    if (!org.springframework.util.CollectionUtils.isEmpty(allocationEntityList)) {
                        Optional<AllocationEntity> optional = allocationEntityList.stream()
                                .filter(entity -> Objects.equals(entity.getTaskId(), taskInteger)).findFirst();
                        if (optional.isPresent()) {
                            AllocationEntity allocationEntity = optional.get();
                            parameterMap = buildParamMap(allocationEntity);
                            beginSeconds = allocationEntity.getIncrementBegintime();
                            endSeconds = allocationEntity.getIncrementEndtime();
                            parameterMap.put("beginSeconds", beginSeconds);
                            parameterMap.put("endSeconds", endSeconds);
                            parameterMap.put("allocation", allocationEntity);
                            parameterMap.put(UtilConstants.ALLOCATION_WEBSITE, allocationEntity.getWebSite());
                            parameterMap = ToolUtil.updateTimeForParameterMap(parameterMap, beginSeconds, endSeconds);
                            String timeZone = (String) parameterMap.get("timeZone");
                            int dataDelay = (int) parameterMap.get("dataDelay");
                            boolean isWait = ToolUtil.isWaitXMins(parameterMap, timeZone, dataDelay);
                            if (!isWait) {
                                String baseUrl = (String) parameterMap.get("baseUrl");
                                accountTransferService.insertAccountTransferForSBO(parameterMap, baseUrl, null, false);
                            }
                        } else {
                            log.error("查询taskId->{}任务配置表获取该任务的信息不存在:", taskId);
                        }
                    }
                }
            }
        } catch (Exception ex) {
            log.error("执行AccountTransfer4SBOTimer出现异常:", ex);
        }

    }

    /**
     * 构建参数map
     *
     * @param entity
     * @return
     */
    private Map<String, Object> buildParamMap(AllocationEntity entity) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("startTime", entity.getTaskBeginTime().getTime());
        paramMap.put("endTime", entity.getTaskEndTime().getTime());
        paramMap.put(UtilConstants.ORDER_TASK_ID, entity.getTaskId());
        String begin_time = DateUtil.formatDate2Str(entity.getTaskBeginTime());
        String end_time = DateUtil.formatDate2Str(entity.getTaskEndTime());
        paramMap.put("begintime", begin_time);
        paramMap.put("endtime", end_time);
        paramMap.put("pageSize", entity.getPageSize());
        paramMap.put(UtilConstants.ORDER_PAGE_NUMBER, String.valueOf(entity.getPageSize()));
        paramMap.put("timeZone", entity.getTimeZone());
        paramMap.put("dataDelay", entity.getDataDelay());
        paramMap.put("baseUrl", entity.getUrl());
        paramMap.put("platformid", entity.getPlatformId());
        paramMap.put("productId", entity.getProductionId());
        paramMap.put("currency", entity.getCurrency() == null ? UtilConstants.CNY : entity.getCurrency());
        paramMap.put("id", entity.getOrderWay());
        paramMap.put("agcode", entity.getAgCode());
        paramMap.put("model", entity.getModel());
        paramMap.put("app_id", entity.getOrderField());//数据库ORDER_FIELD存放appId
        paramMap.put("public_key", entity.getAgCode());
        paramMap.put("password", entity.getPassword());
        return paramMap;
    }

}
