package main.java.com.gw.common.system.timer;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.redis.Rlock;
import main.java.com.gw.common.system.redis.TaskLock;
import main.java.com.gw.datacenter.allocation.entity.AllocationEntity;
import org.apache.commons.lang3.StringUtils;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Dominik.X
 * @description vr彩票抓取转账记录
 * @date 2019/10/24 15:53
 */
@Slf4j
public class AccountTransfer4VRTimer extends AllAbstractTimer {
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        log.info(context.toString());

        JobDataMap jobDataMap = context.getJobDetail().getJobDataMap();
        String taskId = jobDataMap.getString("taskId");
        log.info("--DC定时任务日志-TaskID-{}-",taskId);
        try (Rlock lock = TaskLock.tryAcquireLock(taskId)) {
            if (lock.getLock()) {
                long beginSeconds = 0L;
                long endSeconds = 0L;

                Map<String, Object> paramMap = new HashMap<>();

                List<AllocationEntity> allocationEntityList = allocationDao.getAllocationList(new String[]{taskId});

                if (StringUtils.isNotBlank(taskId)) {
                    Integer taskInteger = Integer.parseInt(taskId);

                    if (allocationEntityList != null && !allocationEntityList.isEmpty()) {
                        for (AllocationEntity entity : allocationEntityList) {
                            if (taskInteger.equals(entity.getTaskId())) {
                                String starTime = DateUtil.formatDate2Str(entity.getTaskBeginTime(), "yyyy-MM-dd'T'HH:mm:ss'Z'");
                                String endTime = DateUtil.formatDate2Str(entity.getTaskEndTime(), "yyyy-MM-dd'T'HH:mm:ss'Z'");
                                paramMap.put("startTime", starTime);
                                paramMap.put("endTime", endTime);
                                paramMap.put(UtilConstants.ORDER_TASK_ID, entity.getTaskId());
                                paramMap.put("timeZone", entity.getTimeZone());
                                paramMap.put("dataDelay", entity.getDataDelay());
                                paramMap.put("baseUrl", entity.getUrl());
                                paramMap.put("platformid", entity.getPlatformId());
                                paramMap.put("productId", entity.getProductionId());
                                paramMap.put("currency", entity.getCurrency() == null ? "CNY" : entity.getCurrency());
                                paramMap.put("version", entity.getOrderField());
                                paramMap.put("id", entity.getOrderWay());
                                paramMap.put("cryptKey", entity.getAccountName());
                                paramMap.put("model", entity.getModel());
                                paramMap.put("num", String.valueOf(entity.getPageSize() == null ? 1000 : entity.getPageSize()));
                                beginSeconds = Long.valueOf(entity.getIncrementBegintime());
                                endSeconds = Long.valueOf(entity.getIncrementEndtime());
                                paramMap.put("beginSeconds", String.valueOf(beginSeconds));
                                paramMap.put("endSeconds", String.valueOf(endSeconds));
                                paramMap.put("begintime", DateUtil.formatDate2Str(entity.getTaskBeginTime()));
                                paramMap.put("endtime", DateUtil.formatDate2Str(entity.getTaskEndTime()));
                            }
                        }
                    }
                }

                paramMap = ToolUtil.updateTimeForParameterMap(paramMap, beginSeconds, endSeconds);
                String timeZone = (String) paramMap.get("timeZone");
                int dataDelay = (int) paramMap.get("dataDelay");

                boolean isWait = ToolUtil.isWaitXMins(paramMap, timeZone, dataDelay);
                if (!isWait) {
                    String baseUrl = (String) paramMap.get("baseUrl");
                    accountTransferService.insertAccountTransferForVR(paramMap, baseUrl, null, false);
                }
            }
        } catch (Exception ex) {
            log.error("Fail to parse order json:" + ex.getMessage(), ex);
        }
    }
}
