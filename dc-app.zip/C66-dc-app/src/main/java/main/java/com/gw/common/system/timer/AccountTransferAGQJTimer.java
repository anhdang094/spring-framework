package main.java.com.gw.common.system.timer;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.redis.Rlock;
import main.java.com.gw.common.system.redis.TaskLock;
import main.java.com.gw.datacenter.allocation.entity.AllocationEntity;
import org.apache.commons.lang3.StringUtils;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * AGQJ 电子钱包模式的转账记录
 */
@Slf4j
public class AccountTransferAGQJTimer extends AllAbstractTimer {
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        log.info("AGQJ AccountTransfer {}", context.toString());
        JobDataMap jobDataMap = context.getJobDetail().getJobDataMap();
        String taskId = jobDataMap.getString("taskId");
        log.info("--DC定时任务日志-TaskID-{}-",taskId);
        try (Rlock lock = TaskLock.tryAcquireLock(taskId)) {
            if (lock.getLock()) {
                long beginSeconds = 0L;
                long endSeconds = 0L;
                Map<String, Object> parameterMap = new HashMap<>();
                List<AllocationEntity> allocationEntityList = allocationDao.getAllocationList(new String[]{taskId});
                if (StringUtils.isNotBlank(taskId)) {
                    Integer taskInteger = Integer.parseInt(taskId);
                    if (allocationEntityList != null && !allocationEntityList.isEmpty()) {
                        for (AllocationEntity allocationEntity : allocationEntityList) {
                            if (taskInteger.equals(allocationEntity.getTaskId())) {
                                parameterMap.put("begintime", DateUtil.formatDate2Str(allocationEntity.getTaskBeginTime()));
                                parameterMap.put("endtime", DateUtil.formatDate2Str(allocationEntity.getTaskEndTime()));
                                parameterMap.put("num", String.valueOf(allocationEntity.getPageSize()));
                                parameterMap.put("platformid", allocationEntity.getPlatformId());
                                parameterMap.put("agcode", allocationEntity.getProductionId());
                                parameterMap.put("productId", allocationEntity.getProductionId());
                                parameterMap.put("website", allocationEntity.getWebSite());
                                parameterMap.put("model", allocationEntity.getModel());
                                parameterMap.put("gamekind", allocationEntity.getGameKind());
                                parameterMap.put("username", allocationEntity.getAccountName());
                                parameterMap.put("password", allocationEntity.getPassword());
                                parameterMap.put("gameCode", allocationEntity.getGameCode());//MG:2,MGVIP:82
                                parameterMap.put("timeZone", allocationEntity.getTimeZone());
                                parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                                parameterMap.put("baseUrl", allocationEntity.getUrl());
                                beginSeconds = allocationEntity.getIncrementBegintime();
                                endSeconds = allocationEntity.getIncrementEndtime();
                                parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                                parameterMap.put("endSeconds", String.valueOf(endSeconds));
                                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                                parameterMap.put("remark", allocationEntity.getRemark());
                                parameterMap.put("currency", allocationEntity.getCurrency() == null ? "CNY" : allocationEntity.getCurrency());//获取币种类型
                                parameterMap.put("gameType", allocationEntity.getGameType());
                            }
                        }
                    }
                }
                log.info("Taskid {} 当前Task参数 {}", taskId, parameterMap);
                parameterMap = ToolUtil.updateTimeForK8SbtParameterMap(parameterMap, beginSeconds, endSeconds);
                String timeZone = (String) parameterMap.get("timeZone");
                int dataDelay = (int) parameterMap.get("dataDelay");

                boolean isWait = ToolUtil.isWaitXMins(parameterMap, timeZone, dataDelay);
                if (!isWait) {
                    String baseUrl = (String) parameterMap.get("baseUrl");
                    accountTransferService.insertAccountTransfer(parameterMap, baseUrl, null, false);
                }
            }
        } catch (Exception ex) {
            log.error("AGQJ AccountTransfer Fail to parse order json:" + ex.getMessage(), ex);
        }
    }
}
