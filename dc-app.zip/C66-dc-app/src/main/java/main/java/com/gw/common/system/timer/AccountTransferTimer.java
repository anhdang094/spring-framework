package main.java.com.gw.common.system.timer;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.redis.Rlock;
import main.java.com.gw.common.system.redis.TaskLock;
import main.java.com.gw.datacenter.allocation.entity.AllocationEntity;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.MDC;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Slf4j
public class AccountTransferTimer extends AllAbstractTimer {

    @Override
    public void execute(JobExecutionContext arg0) throws JobExecutionException {
        MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
        log.info(arg0.toString());
        JobDataMap jobDataMap = arg0.getJobDetail().getJobDataMap();
        String taskId = jobDataMap.getString("taskId");
        log.info("--DC定时任务日志-TaskID-{}-",taskId);
        Map<String, Object> parameterMap = new HashMap<String, Object>();
        try(Rlock lock = TaskLock.tryAcquireLock(taskId)) {
            if (lock.getLock()) {
                long endSeconds = 0L;
                long beginSeconds = 0L;
                List<AllocationEntity> allocationEntityList = allocationDao.getAllocationList(new String[]{taskId});
                if (allocationEntityList != null && allocationEntityList.size() > 0) {
                    for (AllocationEntity allocationEntity : allocationEntityList) {
                        String platformId = allocationEntity.getPlatformId();
                        parameterMap.put(UtilConstants.GAME_TYPE_KEY_IOM, allocationEntity.getGameType());
                        if (UtilConstants.ACCOUNT_TRANSFER_AG.equals(platformId)) {//AGQJ转账
                            parameterMap.put("begintime", DateUtil.formatDate2Str(allocationEntity.getTaskBeginTime()));
                            parameterMap.put("endtime", DateUtil.formatDate2Str(allocationEntity.getTaskEndTime()));
                            parameterMap.put("num", String.valueOf(allocationEntity.getPageSize()));
                            parameterMap.put("platformid", allocationEntity.getPlatformId());
                            parameterMap.put("agcode", allocationEntity.getAgCode());
                            parameterMap.put("action", allocationEntity.getAction());
                            parameterMap.put("timeZone", allocationEntity.getTimeZone());
                            parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                            parameterMap.put("baseUrl", allocationEntity.getUrl());
                            beginSeconds = allocationEntity.getIncrementBegintime();
                            endSeconds = allocationEntity.getIncrementEndtime();
                            parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                            parameterMap.put("endSeconds", String.valueOf(endSeconds));
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                        } else if (UtilConstants.ACCOUNT_TRANSFER_AGSTAR.equals(platformId) && allocationEntity.getTaskId() == 832) {//AGSTAR转账
                            parameterMap.put("begintime", DateUtil.formatDate2Str(allocationEntity.getTaskBeginTime()));
                            parameterMap.put("endtime", DateUtil.formatDate2Str(allocationEntity.getTaskEndTime()));
                            parameterMap.put("num", String.valueOf(allocationEntity.getPageSize()));
                            parameterMap.put("platformid", allocationEntity.getPlatformId());
                            parameterMap.put("agcode", allocationEntity.getAgCode());
                            parameterMap.put("action", allocationEntity.getAction());
                            parameterMap.put("timeZone", allocationEntity.getTimeZone());
                            parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                            parameterMap.put("baseUrl", allocationEntity.getUrl());
                            beginSeconds = allocationEntity.getIncrementBegintime();
                            endSeconds = allocationEntity.getIncrementEndtime();
                            parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                            parameterMap.put("endSeconds", String.valueOf(endSeconds));
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                        } else if (UtilConstants.ACCOUNT_TRANSFER_AG2.equals(platformId) && allocationEntity.getTaskId() == 228) {//AG2_transfer
                            parameterMap.put("begintime", DateUtil.formatDate2Str(allocationEntity.getTaskBeginTime()));
                            parameterMap.put("endtime", DateUtil.formatDate2Str(allocationEntity.getTaskEndTime()));
                            parameterMap.put("num", String.valueOf(allocationEntity.getPageSize()));
                            parameterMap.put("platformid", allocationEntity.getPlatformId());
                            parameterMap.put("agcode", allocationEntity.getAgCode());
                            parameterMap.put("action", allocationEntity.getAction());
                            parameterMap.put("timeZone", allocationEntity.getTimeZone());
                            parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                            parameterMap.put("baseUrl", allocationEntity.getUrl());
                            beginSeconds = allocationEntity.getIncrementBegintime();
                            endSeconds = allocationEntity.getIncrementEndtime();
                            parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                            parameterMap.put("endSeconds", String.valueOf(endSeconds));
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                        } else if (UtilConstants.ACCOUNT_TRANSFER_AGIN.equals(platformId)) {
                            parameterMap.put("begintime", DateUtil.formatDate2Str(allocationEntity.getTaskBeginTime()));
                            parameterMap.put("endtime", DateUtil.formatDate2Str(allocationEntity.getTaskEndTime()));
                            parameterMap.put("num", String.valueOf(allocationEntity.getPageSize()));
                            parameterMap.put("platformid", allocationEntity.getPlatformId());
                            //update by pacy.g ---- begin
                            parameterMap.put("cagent", allocationEntity.getProductionId());
                            parameterMap.put("mingmakey", allocationEntity.getPassword());
                            parameterMap.put("productId", allocationEntity.getProductionId());
                            //update by pacy.g ---- end
                            parameterMap.put("agcode", allocationEntity.getAgCode());
                            parameterMap.put("action", allocationEntity.getAction());
                            parameterMap.put("timeZone", allocationEntity.getTimeZone());
                            parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                            parameterMap.put("baseUrl", allocationEntity.getUrl());
                            beginSeconds = allocationEntity.getIncrementBegintime();
                            endSeconds = allocationEntity.getIncrementEndtime();
                            parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                            parameterMap.put("endSeconds", String.valueOf(endSeconds));
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                        } else if (UtilConstants.ACCOUNT_TRANSFER_K8.equals(platformId)) {//KENO转账
                            parameterMap.put("begintime", DateUtil.formatDate2Str(allocationEntity.getTaskBeginTime()));
                            parameterMap.put("endtime", DateUtil.formatDate2Str(allocationEntity.getTaskEndTime()));
                            parameterMap.put("num", String.valueOf(allocationEntity.getPageSize()));
                            parameterMap.put("platformid", allocationEntity.getPlatformId());
                            parameterMap.put("agcode", allocationEntity.getAgCode());
                            parameterMap.put("action", allocationEntity.getAction());
                            parameterMap.put("timeZone", allocationEntity.getTimeZone());
                            parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                            parameterMap.put("baseUrl", allocationEntity.getUrl());
                            beginSeconds = allocationEntity.getIncrementBegintime();
                            endSeconds = allocationEntity.getIncrementEndtime();
                            parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                            parameterMap.put("endSeconds", String.valueOf(endSeconds));
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                        } else if (UtilConstants.ACCOUNT_TRANSFER_BBIN_BLM.equals(platformId)
                                || UtilConstants.ACCOUNT_TRANSFER_BBIN_MT.equals(platformId)
                                || UtilConstants.ACCOUNT_TRANSFER_BBIN_ZL.equals(platformId)
                                || UtilConstants.ACCOUNT_TRANSFER_BBIN_LL.equals(platformId)
                                || UtilConstants.ACCOUNT_TRANSFER_BBIN_WH.equals(platformId)
                                || UtilConstants.ACCOUNT_TRANSFER_BBIN_HWX.equals(platformId)
                                || UtilConstants.ACCOUNT_TRANSFER_BBIN_KB.equals(platformId)
                                || UtilConstants.ACCOUNT_TRANSFER_BBIN_HJHA.equals(platformId)
                                || UtilConstants.ACCOUNT_TRANSFER_BBIN_E02.equals(platformId)
                                || UtilConstants.ACCOUNT_TRANSFER_BBIN_E03.equals(platformId)
                                || UtilConstants.ACCOUNT_TRANSFER_BBIN_E04.equals(platformId)
                                || UtilConstants.ACCOUNT_TRANSFER_BBIN_B01.equals(platformId)
                                || UtilConstants.ACCOUNT_TRANSFER_BBIN_B79.equals(platformId)) {
                            parameterMap.put("target", allocationEntity.getLoginName());
                            parameterMap.put("website", allocationEntity.getWebSite());
                            parameterMap.put("username", allocationEntity.getAccountName());
                            parameterMap.put("password", allocationEntity.getPassword());
                            parameterMap.put("begintime", DateUtil.formatDate2Str(allocationEntity.getTaskBeginTime()));
                            parameterMap.put("endtime", DateUtil.formatDate2Str(allocationEntity.getTaskEndTime()));
                            parameterMap.put("num", String.valueOf(allocationEntity.getPageSize()));
                            parameterMap.put("platformid", allocationEntity.getPlatformId());
                            parameterMap.put("agcode", allocationEntity.getProductionId());
                            parameterMap.put("productId", allocationEntity.getProductionId());
                            parameterMap.put("action", allocationEntity.getAction());
                            parameterMap.put("timeZone", allocationEntity.getTimeZone());
                            parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                            parameterMap.put("baseUrl", allocationEntity.getUrl());
                            if (null != allocationEntity.getCurrencyType()) {
                                parameterMap.put("currencyType", allocationEntity.getCurrencyType());
                            }
                            beginSeconds = allocationEntity.getIncrementBegintime();
                            endSeconds = allocationEntity.getIncrementEndtime();
                            parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                            parameterMap.put("endSeconds", String.valueOf(endSeconds));
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                        } else if (UtilConstants.ACCOUNT_TRANSFER_AMAYA_FCLRC.equals(platformId)) {
                            parameterMap.put("target", allocationEntity.getLoginName());
                            parameterMap.put("website", allocationEntity.getWebSite());
                            parameterMap.put("username", allocationEntity.getAccountName());
                            parameterMap.put("password", allocationEntity.getPassword());
                            parameterMap.put("begintime", DateUtil.formatDate2Str(allocationEntity.getTaskBeginTime()));
                            parameterMap.put("endtime", DateUtil.formatDate2Str(allocationEntity.getTaskEndTime()));
                            parameterMap.put("num", String.valueOf(allocationEntity.getPageSize()));
                            parameterMap.put("platformid", allocationEntity.getPlatformId());
                            parameterMap.put("agcode", allocationEntity.getProductionId());
                            parameterMap.put("productId", allocationEntity.getProductionId());
                            parameterMap.put("action", allocationEntity.getAction());
                            parameterMap.put("timeZone", allocationEntity.getTimeZone());
                            parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                            parameterMap.put("baseUrl", allocationEntity.getUrl());
                            beginSeconds = allocationEntity.getIncrementBegintime();
                            endSeconds = allocationEntity.getIncrementEndtime();
                            parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                            parameterMap.put("endSeconds", String.valueOf(endSeconds));
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());

                        } else if (UtilConstants.ACCOUNT_TRANSFER_NETENT.equals(platformId)) {
                            parameterMap.put("target", allocationEntity.getLoginName());
                            parameterMap.put("website", allocationEntity.getWebSite());
                            parameterMap.put("username", allocationEntity.getAccountName());
                            parameterMap.put("password", allocationEntity.getPassword());
                            parameterMap.put("begintime", DateUtil.formatDate2Str(allocationEntity.getTaskBeginTime()));
                            parameterMap.put("endtime", DateUtil.formatDate2Str(allocationEntity.getTaskEndTime()));
                            parameterMap.put("num", String.valueOf(allocationEntity.getPageSize()));
                            parameterMap.put("platformid", allocationEntity.getPlatformId());
                            parameterMap.put("agcode", allocationEntity.getProductionId());
                            parameterMap.put("productId", allocationEntity.getProductionId());
                            parameterMap.put("action", allocationEntity.getAction());
                            parameterMap.put("timeZone", allocationEntity.getTimeZone());
                            parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                            parameterMap.put("baseUrl", allocationEntity.getUrl());
                            beginSeconds = allocationEntity.getIncrementBegintime();
                            endSeconds = allocationEntity.getIncrementEndtime();
                            parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                            parameterMap.put("endSeconds", String.valueOf(endSeconds));
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                        } else if (UtilConstants.ACCOUNT_TRANSFER_MG.equals(platformId)) {
                            parameterMap.put("target", allocationEntity.getLoginName());
                            parameterMap.put("website", allocationEntity.getWebSite());
                            parameterMap.put("username", allocationEntity.getAccountName());
                            parameterMap.put("password", allocationEntity.getPassword());
                            parameterMap.put("begintime", DateUtil.formatDate2Str(allocationEntity.getTaskBeginTime()));
                            parameterMap.put("endtime", DateUtil.formatDate2Str(allocationEntity.getTaskEndTime()));
                            parameterMap.put("num", String.valueOf(allocationEntity.getPageSize()));
                            parameterMap.put("platformid", allocationEntity.getPlatformId());
                            parameterMap.put("agcode", allocationEntity.getProductionId());
                            parameterMap.put("productId", allocationEntity.getProductionId());
                            parameterMap.put("action", allocationEntity.getAction());
                            parameterMap.put("timeZone", allocationEntity.getTimeZone());
                            parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                            parameterMap.put("baseUrl", allocationEntity.getUrl());
                            beginSeconds = allocationEntity.getIncrementBegintime();
                            endSeconds = allocationEntity.getIncrementEndtime();
                            parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                            parameterMap.put("endSeconds", String.valueOf(endSeconds));
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                        }
                    }
                }

                parameterMap = ToolUtil.updateTimeForParameterMap(parameterMap, beginSeconds, endSeconds);
                String timeZone = (String) parameterMap.get("timeZone");
                int dataDelay = (int) parameterMap.get("dataDelay");
                boolean isWait = ToolUtil.isWaitXMins(parameterMap, timeZone, dataDelay);
                if (!isWait) {
                    String baseUrl = (String) parameterMap.get("baseUrl");
                    accountTransferService.insertAccountTransfer(parameterMap, baseUrl, null, false);

                }
            }
        } catch (Exception e) {
            log.error("Failed to parse xml:" + e.getMessage(), e);
        }
    }
}
