package main.java.com.gw.common.system.timer;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWPersistenceException;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.redis.Rlock;
import main.java.com.gw.common.system.redis.TaskLock;
import main.java.com.gw.datacenter.allocation.entity.AllocationEntity;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.MDC;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * AGIN电子游戏注单数据检测
 */
@Slf4j
public class AginComputerGameTimer extends AllAbstractTimer {

    @Override
    public void execute(JobExecutionContext cxt) throws JobExecutionException {
        MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
        log.info("AGIN电子游戏注单数据检测开始" + cxt.toString());
        JobDataMap jobDataMap = cxt.getJobDetail().getJobDataMap();
        String taskId = jobDataMap.getString("taskId");//任务Id号
        log.info("--DC定时任务日志-TaskID-{}-",taskId);
        AllocationEntity taskContext = null;
        try {
            taskContext = orderLogService.getAllocationById(taskId);//当前数据检测ID号
        } catch (GWPersistenceException e1) {
            e1.printStackTrace();
        }
        if (null == taskContext) {
            log.info(String.format("can not find task %s in the taskList", taskId));
            return;
        }
        try(Rlock lock = TaskLock.tryAcquireLock(taskId)) {
            if (lock.getLock()) {
                long endSeconds = 0L;
                long beginSeconds = 0L;
                Map<String, Object> parameterMap = new HashMap<String, Object>();
                parameterMap.put("begintime", DateUtil.formatDate2Str(taskContext.getTaskBeginTime()));//开始时间
                parameterMap.put("endtime", DateUtil.formatDate2Str(taskContext.getTaskEndTime()));//结束时间
                parameterMap.put("num", String.valueOf(taskContext.getPageSize()));//个数
                parameterMap.put("platformid", taskContext.getPlatformId());//平台ID
                parameterMap.put("productId", taskContext.getProductionId());//产品ID号
                //update by pacy.g ---- begin
                parameterMap.put("mingmakey", taskContext.getPassword());//密码
                parameterMap.put(UtilConstants.ORDER_PRODUCT_ID, taskContext.getProductionId());//产品ID号
                //update by pacy.g ---- end
                parameterMap.put("agcode", taskContext.getAgCode());//代理编号
                parameterMap.put(UtilConstants.ORDER_BBIN_GAMEKIND, taskContext.getGameKind());//游戏类型
                parameterMap.put("timeZone", taskContext.getTimeZone());//时区
                parameterMap.put("dataDelay", taskContext.getDataDelay());//等待时间
                parameterMap.put("baseUrl", taskContext.getUrl());//URL地址
                beginSeconds = taskContext.getIncrementBegintime();//开始时间增量
                endSeconds = taskContext.getIncrementEndtime();//结束时间增量
                parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                parameterMap.put("endSeconds", String.valueOf(endSeconds));
                parameterMap.put("check_task_id", taskContext.getAgCode());//被检查的ID号
                parameterMap.put(UtilConstants.ORDER_TASK_ID, taskContext.getTaskId());//任务ID号
                parameterMap.put(UtilConstants.ORDER_CAGENT, (String) taskContext.getProductionId());

                String timeZone = (String) parameterMap.get("timeZone");//时区
                int dataDelay = (int) parameterMap.get("dataDelay");//间隔时间

                parameterMap = ToolUtil.updateTimeForParameterMap(parameterMap, beginSeconds, endSeconds);//重新设置开始开始时间和结束时间

                boolean isWait = ToolUtil.isWaitXMins(parameterMap, timeZone, dataDelay);//判断时间
                if (!isWait) {
                    this.orderService.checkAginComputerGameTimer(parameterMap);//检测AGIN游戏注单信息

                }
            }
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
        }
    }

}
