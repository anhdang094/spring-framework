package main.java.com.gw.common.system.timer;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.redis.Rlock;
import main.java.com.gw.common.system.redis.TaskLock;
import main.java.com.gw.datacenter.allocation.entity.AllocationEntity;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.MDC;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * AG捕鱼注单数据检测
 */
@Slf4j
public class AginDataTimer extends AllAbstractTimer {

    @Override
    public void execute(JobExecutionContext cxt) throws JobExecutionException {
        MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
        log.info(cxt.toString());
        JobDataMap jobDataMap = cxt.getJobDetail().getJobDataMap();
        String taskId = jobDataMap.getString("taskId");//任务Id号
        log.info("--DC定时任务日志-TaskID-{}-",taskId);
        AllocationEntity taskContext = null;
        try {
            taskContext = orderLogService.getAllocationById(taskId);//当前数据检测ID号
        } catch (Exception e1) {
            log.error(e1.getMessage(), e1);
        }
        if (null == taskContext) {
            log.info(String.format("can not find task %s in the taskList", taskId));
            return;
        }
        AllocationEntity allocation;
        Map<String, Object> parameterMap = new HashMap<String, Object>();
        try(Rlock lock = TaskLock.tryAcquireLock(taskId)) {
            if (lock.getLock()) {
                long endSeconds = 0L;
                long beginSeconds = 0L;
                if (parameterMap.isEmpty()) {
                    allocation = orderLogService.getAllocationById(taskContext.getAgCode());//通过代理编号查询信息
                    parameterMap.put("username", taskContext.getAccountName());//用户名称
                    parameterMap.put("act", allocation.getAction());//act
                    parameterMap.put("pidtoken", allocation.getPassword());//pidtoken
                    parameterMap.put("baseUrl", taskContext.getUrl());//URL 地址
                    parameterMap.put("page", 1);//
                    parameterMap.put("num", String.valueOf(taskContext.getPageSize()));//页码数
                    beginSeconds = taskContext.getIncrementBegintime();//开始时间增量
                    endSeconds = taskContext.getIncrementEndtime();//结束时间增量
                    parameterMap.put("begintime", DateUtil.formatDate2Str(taskContext.getTaskBeginTime()));//任务开始时间
                    parameterMap.put("endtime", DateUtil.formatDate2Str(taskContext.getTaskEndTime()));//任务结束时间
                    parameterMap.put("beginSeconds", beginSeconds);
                    parameterMap.put("endSeconds", endSeconds);
                    parameterMap.put("timeZone", taskContext.getTimeZone());//时区
                    parameterMap.put("dataDelay", taskContext.getDataDelay());//间隔时间
                    parameterMap.put(UtilConstants.ORDER_TASK_ID, taskContext.getTaskId());//任务ID号
                    parameterMap.put("productId", allocation.getProductionId());//产品ID号
                    parameterMap.put("check_task_id", taskContext.getAgCode());
                }
                String timeZone = (String) parameterMap.get("timeZone");//时区
                int dataDelay = (int) parameterMap.get("dataDelay");//间隔时间

                parameterMap = ToolUtil.updateTimeForParameterMap(parameterMap, beginSeconds, endSeconds);

                boolean isWait = ToolUtil.isWaitXMins(parameterMap, timeZone, dataDelay);//判断时间
                if (!isWait) {
                    this.orderService.checkAgin(parameterMap);//检测AGIN注单信息
                }
            }
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
        }
    }
}
