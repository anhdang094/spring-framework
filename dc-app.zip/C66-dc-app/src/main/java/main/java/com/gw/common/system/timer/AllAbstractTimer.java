package main.java.com.gw.common.system.timer;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.Main;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.redis.Rlock;
import main.java.com.gw.common.system.redis.TaskLock;
import main.java.com.gw.datacenter.accounttransfer.service.AccountTransferService;
import main.java.com.gw.datacenter.accounttransferlog.service.AccountTransferLogService;
import main.java.com.gw.datacenter.allocation.dao.AllocationDao;
import main.java.com.gw.datacenter.allocation.entity.AllocationEntity;
import main.java.com.gw.datacenter.gameresult.service.BaGameService;
import main.java.com.gw.datacenter.gameresultlog.service.GameResultLogService;
import main.java.com.gw.datacenter.order.service.GatherOrderSyncService;
import main.java.com.gw.datacenter.order.service.OrderService;
import main.java.com.gw.datacenter.orderlog.service.OrderLogService;
import org.quartz.StatefulJob;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public abstract class AllAbstractTimer implements StatefulJob {
    protected OrderLogService orderLogService = (OrderLogService) Main.factory.getBean("orderLogService");
    protected OrderService orderService = (OrderService) Main.factory.getBean("orderService");
    protected AllocationDao allocationDao = (AllocationDao) Main.factory.getBean("allocationDao");
    protected AccountTransferService accountTransferService = (AccountTransferService) Main.factory.getBean("accountTransferService");
    protected AccountTransferLogService accountTransferLogService = (AccountTransferLogService) Main.factory.getBean("accountTransferLogService");
    protected GameResultLogService gameResultLogService = (GameResultLogService) Main.factory.getBean("gameResultLogService");
    protected BaGameService baGameService = (BaGameService) Main.factory.getBean("baGameService");

    protected GatherOrderSyncService gatherOrderSyncService = (GatherOrderSyncService) Main.factory.getBean("gatherOrderSyncService");


    protected AllocationEntity updateTimeForAllocation(AllocationEntity mainAllocation) {
        Date begin = mainAllocation.getTaskBeginTime();
        Date end = mainAllocation.getTaskEndTime();
        long timeIncrement = mainAllocation.getIncrementEndtime();
        mainAllocation.setTaskBeginTime(getNewTimeByOldTime(begin, timeIncrement));
        mainAllocation.setTaskEndTime(getNewTimeByOldTime(end, timeIncrement));
        return mainAllocation;
    }

    protected Date getNewTimeByOldTime(Date oldTime, long timeIncrement) {
        if (timeIncrement == 0) {
            return oldTime;
        }
        long old = oldTime.getTime();
        long newMillSeconds = old + timeIncrement;
        return new Date(newMillSeconds);
    }

    /**
     * 获取AllocationEntity对象
     * @param taskId
     * @return
     */
    public AllocationEntity getAllocationEntity(String taskId){
        List<AllocationEntity> allocationList = null;
        AllocationEntity allocationEntity = null;
        try{
            allocationList = allocationDao.getAllocationList(new String[]{taskId});
            if(allocationList!=null && allocationList.size()>0) {
                allocationEntity = allocationList.get(0);
            }
        }catch (Exception e){
            e.printStackTrace();;
        }

        return allocationEntity;
    }


    public void doOrderSyncTask(String flatFormType,String taskId){
        AllocationEntity allocationEntity = this.getAllocationEntity(taskId);
        if(allocationEntity==null){
            log.error("【{}】AllocationEntity无配置信息",flatFormType);
            return;
        }
        try(Rlock lock = TaskLock.tryAcquireLock(taskId)) {
            if (lock.getLock()) {
                Map<String, Object> parameterMap = new HashMap<String, Object>();
                String beginTime = DateUtil.formatDate2Str(allocationEntity.getTaskBeginTime());
                String endTime = DateUtil.formatDate2Str(allocationEntity.getTaskEndTime());
                parameterMap.put("begintime", beginTime);
                parameterMap.put("endtime", endTime);
                parameterMap.put("task_id",allocationEntity.getTaskId());
                int beginSeconds = allocationEntity.getIncrementBegintime();
                int endSeconds = allocationEntity.getIncrementEndtime();
                parameterMap.put("timeZone", allocationEntity.getTimeZone());
                parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                parameterMap.put("endSeconds", String.valueOf(endSeconds));
                parameterMap = ToolUtil.updateTimeForBBINParameterMap(parameterMap, beginSeconds, endSeconds);
                String timeZone = (String) parameterMap.get("timeZone");
                int dataDelay = (int) parameterMap.get("dataDelay");
                log.info("【{}】时间段 ： {} ~  {} ",flatFormType,parameterMap.get(UtilConstants.ORDER_BEGIN_TIME),parameterMap.get(UtilConstants.ORDER_END_TIME));
                boolean isWait = ToolUtil.isWaitXMins(parameterMap, timeZone, dataDelay);
                if (!isWait) {
                    while(true){
                        boolean isStop = this.gatherOrderSyncService.syncGameOrder(flatFormType,allocationEntity);
                        if(!isStop){
                            break;
                        }
                    }

                    this.allocationDao.updateAllocationBeginTimeEndTimeById(parameterMap);

                }
            }
        } catch (Exception ex) {
            log.error("AllAbstractTimer.doOrderSyncTask fail:" + ex.getMessage(), ex);
        }
    }

    /**
     * @Description: 事前风控推送补偿定时任务
     * @Author: Ziv.Y
     * @Date: 2019/12/19 13:33
     */
    public void doOrderSyncCompensateTask(String flatFormType,String taskId){
        AllocationEntity allocationEntity = this.getAllocationEntity(taskId);
        if(allocationEntity==null){
            log.error("【{}】AllocationEntity无配置信息",flatFormType);
            return;
        }
        try(Rlock lock = TaskLock.tryAcquireLock(taskId)) {
            if (lock.getLock()) {
                Map<String, Object> parameterMap = new HashMap<String, Object>();
                String beginTime = DateUtil.formatDate2Str(allocationEntity.getTaskBeginTime());
                String endTime = DateUtil.formatDate2Str(allocationEntity.getTaskEndTime());
                parameterMap.put("begintime", beginTime);
                parameterMap.put("endtime", endTime);
                parameterMap.put("task_id",allocationEntity.getTaskId());
                int beginSeconds = allocationEntity.getIncrementBegintime();
                int endSeconds = allocationEntity.getIncrementEndtime();
                parameterMap.put("timeZone", allocationEntity.getTimeZone());
                parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                parameterMap.put("endSeconds", String.valueOf(endSeconds));
                //这里把时间增加去掉，为的是判断当前时间离上次执行时间是否已过delay间隔时间，
//                parameterMap = ToolUtil.updateTimeForBBINParameterMap(parameterMap, beginSeconds, endSeconds);
                String timeZone = (String) parameterMap.get("timeZone");
                int dataDelay = (int) parameterMap.get("dataDelay");
                log.info("doOrderSyncCompensateTask【{}】时间段 ： {} ~  {} ",flatFormType,parameterMap.get(UtilConstants.ORDER_BEGIN_TIME),parameterMap.get(UtilConstants.ORDER_END_TIME));
                boolean isWait = ToolUtil.isWaitXMins(parameterMap, timeZone, dataDelay);
                if (!isWait) {
                    gatherOrderSyncService.syncGameOrderCompensate(allocationEntity);

                    //每次补偿执行完成后，起始、截止时间都更新为当前时间
                    parameterMap.put("begintime", DateUtil.formatDate2Str(new Date()));
                    parameterMap.put("endtime", DateUtil.formatDate2Str(new Date()));
                    allocationDao.updateAllocationBeginTimeEndTimeById(parameterMap);
                }
            }
        } catch (Exception ex) {
            log.error("AllAbstractTimer.doOrderSyncCompensateTask fail:" + ex.getMessage(), ex);
        }
    }
}
