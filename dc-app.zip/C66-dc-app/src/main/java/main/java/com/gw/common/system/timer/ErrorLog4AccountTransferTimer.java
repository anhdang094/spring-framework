package main.java.com.gw.common.system.timer;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.GameType;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.system.redis.Rlock;
import main.java.com.gw.common.system.redis.TaskLock;
import main.java.com.gw.datacenter.accounttransferlog.entity.AccountTransferLogEntity;
import main.java.com.gw.datacenter.allocation.entity.AllocationEntity;
import org.apache.commons.lang3.StringUtils;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.MDC;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 转账错误日志
 */
@Slf4j
public class ErrorLog4AccountTransferTimer extends AllAbstractTimer {

    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
        log.info(context.toString());
        JobDataMap jobDataMap = context.getJobDetail().getJobDataMap();
        AllocationEntity mainAllocation = null;
        try {
            mainAllocation = orderLogService.getAllocationById(jobDataMap.getString("taskId"));
        } catch (Exception e1) {
            log.error(e1.getMessage(), e1);
        }
        if (null == mainAllocation) {
            log.info(String.format("can not find task %s in the taskList", jobDataMap.getString("taskId")));
            return;
        }
        String baseUrl = null;
        String platformId = null;
        AllocationEntity allocationEntity = null;
        log.info("--DC定时任务日志-TaskID-{}-",mainAllocation.getTaskId());
        try(Rlock lock = TaskLock.tryAcquireLock(String.valueOf(mainAllocation.getTaskId()))) {
            if (lock.getLock()) {
                Map<String, Object> parameterMapForLock = new HashMap<String, Object>();
                parameterMapForLock.put(UtilConstants.ORDER_TASK_ID, mainAllocation.getTaskId());
                parameterMapForLock.put(UtilConstants.ORDER_BEGIN_TIME, mainAllocation.getTaskBeginTime());
                parameterMapForLock.put(UtilConstants.ORDER_END_TIME, mainAllocation.getTaskEndTime());

                List<AccountTransferLogEntity> accountTransferLogEntityList = accountTransferLogService.getAllErrorAccountTransferLog();
                if (accountTransferLogEntityList != null && accountTransferLogEntityList.size() > 0) {
                    for (AccountTransferLogEntity accountTransferLogEntity : accountTransferLogEntityList) {
                        try {
                            MDC.put("uuid", MDC.get("uuid").split("_")[0] + "_" + UUID.randomUUID().toString().replace("-", ""));//每个错误日志打印不同uuid，不然不好排查错误
                            baseUrl = accountTransferLogEntity.getUrl();
                            platformId = accountTransferLogEntity.getPlatId();
                            Integer currencyType = accountTransferLogEntity.getCurrencyType();
                            allocationEntity = allocationDao.getAllocationById(accountTransferLogEntity.getTaskId().toString());//查询货币类型
                            if (currencyType == null) {
                                currencyType = 1;
                            }
                            Integer gameType = allocationEntity.getGameType();
                            Map<String, Object> parameterMap = new HashMap<String, Object>();
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());//add by ziv 2018-12-06
                            parameterMap.put("begintime", DateUtil.formatDate2Str(accountTransferLogEntity.getBeginTime()));
                            parameterMap.put("endtime", DateUtil.formatDate2Str(accountTransferLogEntity.getEndTime()));
                            parameterMap.put("num", String.valueOf(accountTransferLogEntity.getPageSize()));
                            parameterMap.put("agcode", accountTransferLogEntity.getAgentCode());
                            parameterMap.put("platformid", platformId);
                            parameterMap.put("currencyType", currencyType);
                            parameterMap.put("gameType", gameType);
                            parameterMap.put("currency", allocationEntity.getCurrency() == null ? "CNY" : allocationEntity.getCurrency());//获取币种类型
                            if (UtilConstants.AGQJ.equals(platformId) && gameType == GameType.IOM_WALLET.getType()) {
                                parameterMap.put("productId", accountTransferLogEntity.getProductId());
                                parameterMap.put("platformid", "trans_ag");
                                accountTransferService.insertAccountTransfer(parameterMap, baseUrl, accountTransferLogEntity, true);
                            } else if (UtilConstants.AGQJ.equals(platformId)) {
                                parameterMap.put("platformid", UtilConstants.ACCOUNT_TRANSFER_AG);
                                accountTransferService.insertAccountTransfer(parameterMap, baseUrl, accountTransferLogEntity, true);
                            } else if (UtilConstants.AGSTAR.equals(platformId)) {
                                if (StringUtils.isNotBlank(mainAllocation.getAgCode())) {
                                    parameterMap.put("platformid", UtilConstants.ACCOUNT_TRANSFER_AGSTAR);
                                    accountTransferService.insertAccountTransfer(parameterMap, baseUrl, accountTransferLogEntity, true);
                                } else {
                                    //agstar新接口
                                    parameterMap.put("num", String.valueOf(allocationEntity.getPageSize()));
                                    parameterMap.put("platformid", allocationEntity.getPlatformId());
                                    parameterMap.put("agcode", allocationEntity.getAgCode());
                                    parameterMap.put("action", allocationEntity.getAction());
                                    parameterMap.put("timeZone", allocationEntity.getTimeZone());
                                    parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                                    parameterMap.put("baseUrl", allocationEntity.getUrl());
                                    parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                                    parameterMap.put("password", allocationEntity.getPassword());//加密key
                                    parameterMap.put("agent", allocationEntity.getAccountName());//代理名
                                    parameterMap.put("currency", allocationEntity.getCurrency() == null ? "CNY" : allocationEntity.getCurrency());//获取币种类型
                                    parameterMap.put("productid", allocationEntity.getProductionId());
                                    accountTransferService.insertAccountTransferForAS(parameterMap, baseUrl, accountTransferLogEntity, true);
                                }
                            } else if (UtilConstants.AG2.equals(platformId)) {
                                parameterMap.put("platformid", UtilConstants.ACCOUNT_TRANSFER_AG2);
                                accountTransferService.insertAccountTransfer(parameterMap, baseUrl, accountTransferLogEntity, true);
                            } else if (UtilConstants.AGIN.equals(platformId)) {

                            allocationEntity = accountTransferLogService.getAllocationById(String.valueOf(accountTransferLogEntity.getTaskId()));
                            parameterMap.put("platformid", UtilConstants.ACCOUNT_TRANSFER_AGIN);
                            //add AGIN begin
                            parameterMap.put("cagent", allocationEntity.getProductionId());
                            parameterMap.put("mingmakey", allocationEntity.getPassword());
                            parameterMap.put("productId", allocationEntity.getProductionId());
                            //add AGIN end
                            if (UtilConstants.ACCOUNT_TRANSFER_AGIN_EXT.equals(allocationEntity.getPlatformId())) {
                                //防止数据错误引起原来的业务出错，加在if 块里面
                                parameterMap.put("platformid", allocationEntity.getPlatformId());//平台ID
                                parameterMap.put("begintime", DateUtil.formatDate2Str(accountTransferLogEntity.getBeginTime()));//任务开始时间
                                parameterMap.put("endtime", DateUtil.formatDate2Str(accountTransferLogEntity.getEndTime()));//任务结束时间
                                parameterMap.put("num", String.valueOf(allocationEntity.getPageSize()));//每页显示条数
                                parameterMap.put("agcode", allocationEntity.getAgCode());//代理编号
                                parameterMap.put("baseUrl", allocationEntity.getUrl());//调用url
                                baseUrl = allocationEntity.getUrl();
                                parameterMap.put("str", allocationEntity.getWebSite());//在该方法中意思是明文串
                                parameterMap.put("pidtoken", allocationEntity.getPassword());//產品ID的密匙
                                parameterMap.put("productId", accountTransferLogEntity.getProductId());//產品ID 如:E03
                                parameterMap.put("act", allocationEntity.getAction());//Api名称
                                parameterMap.put("gamekind", allocationEntity.getGameKind());//游戏种类
                                parameterMap.put("billtypes", allocationEntity.getGameCode());//账单类型billtypes
                                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());//任务编号
                                accountTransferService.insertAccountTransferFish(parameterMap, baseUrl, accountTransferLogEntity, true);
                            } else {
                                accountTransferService.insertAccountTransfer(parameterMap, baseUrl, accountTransferLogEntity, true);
                            }
                        } else if (UtilConstants.BBIN_BLM.equals(platformId)) {
                            Integer task_id = accountTransferLogEntity.getTaskId();
                            allocationEntity = accountTransferLogService.getAllocationById(task_id.toString());
                            parameterMap.put("platformid", allocationEntity.getPlatformId());
                            parameterMap.put("website", allocationEntity.getWebSite());
                            parameterMap.put("username", allocationEntity.getAccountName());
                            parameterMap.put("password", allocationEntity.getPassword());
                            parameterMap.put("agcode", allocationEntity.getProductionId());
                            parameterMap.put("productId", allocationEntity.getProductionId());
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                            accountTransferService.insertAccountTransfer(parameterMap, baseUrl, accountTransferLogEntity, true);

                        } else if (UtilConstants.BBIN_MT.equals(platformId)) {
                            Integer task_id = accountTransferLogEntity.getTaskId();
                            allocationEntity = accountTransferLogService.getAllocationById(task_id.toString());
                            parameterMap.put("platformid", UtilConstants.ACCOUNT_TRANSFER_BBIN_MT);
                            parameterMap.put("website", allocationEntity.getWebSite());
                            parameterMap.put("username", allocationEntity.getAccountName());
                            parameterMap.put("password", allocationEntity.getPassword());
                            parameterMap.put("agcode", allocationEntity.getProductionId());
                            parameterMap.put("productId", allocationEntity.getProductionId());
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                            accountTransferService.insertAccountTransfer(parameterMap, baseUrl, accountTransferLogEntity, true);
                        } else if (UtilConstants.BBIN_ZL.equals(platformId)) {
                            Integer task_id = accountTransferLogEntity.getTaskId();
                            allocationEntity = accountTransferLogService.getAllocationById(task_id.toString());
                            parameterMap.put("platformid", UtilConstants.ACCOUNT_TRANSFER_BBIN_ZL);
                            parameterMap.put("website", allocationEntity.getWebSite());
                            parameterMap.put("username", allocationEntity.getAccountName());
                            parameterMap.put("password", allocationEntity.getPassword());
                            parameterMap.put("agcode", allocationEntity.getProductionId());
                            parameterMap.put("productId", allocationEntity.getProductionId());
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                            accountTransferService.insertAccountTransfer(parameterMap, baseUrl, accountTransferLogEntity, true);
                        } else if (UtilConstants.BBIN_LL.equals(platformId)) {
                            Integer task_id = accountTransferLogEntity.getTaskId();
                            allocationEntity = accountTransferLogService.getAllocationById(task_id.toString());
                            parameterMap.put("platformid", UtilConstants.ACCOUNT_TRANSFER_BBIN_LL);
                            parameterMap.put("website", allocationEntity.getWebSite());
                            parameterMap.put("username", allocationEntity.getAccountName());
                            parameterMap.put("password", allocationEntity.getPassword());
                            parameterMap.put("agcode", allocationEntity.getProductionId());
                            parameterMap.put("productId", allocationEntity.getProductionId());
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                            accountTransferService.insertAccountTransfer(parameterMap, baseUrl, accountTransferLogEntity, true);
                        } else if (UtilConstants.BBIN_WH.equals(platformId)) {
                            Integer task_id = accountTransferLogEntity.getTaskId();
                            allocationEntity = accountTransferLogService.getAllocationById(task_id.toString());
                            parameterMap.put("platformid", UtilConstants.ACCOUNT_TRANSFER_BBIN_WH);
                            parameterMap.put("website", allocationEntity.getWebSite());
                            parameterMap.put("username", allocationEntity.getAccountName());
                            parameterMap.put("password", allocationEntity.getPassword());
                            parameterMap.put("agcode", allocationEntity.getProductionId());
                            parameterMap.put("productId", allocationEntity.getProductionId());
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                            accountTransferService.insertAccountTransfer(parameterMap, baseUrl, accountTransferLogEntity, true);
                        } else if (UtilConstants.BBIN_HWX.equals(platformId)) {
                            Integer task_id = accountTransferLogEntity.getTaskId();
                            allocationEntity = accountTransferLogService.getAllocationById(task_id.toString());
                            parameterMap.put("platformid", UtilConstants.ACCOUNT_TRANSFER_BBIN_HWX);
                            parameterMap.put("website", allocationEntity.getWebSite());
                            parameterMap.put("username", allocationEntity.getAccountName());
                            parameterMap.put("password", allocationEntity.getPassword());
                            parameterMap.put("agcode", allocationEntity.getProductionId());
                            parameterMap.put("productId", allocationEntity.getProductionId());
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                            accountTransferService.insertAccountTransfer(parameterMap, baseUrl, accountTransferLogEntity, true);
                        } else if (UtilConstants.BBIN_KB.equals(platformId)) {
                            Integer task_id = accountTransferLogEntity.getTaskId();
                            allocationEntity = accountTransferLogService.getAllocationById(task_id.toString());
                            parameterMap.put("platformid", UtilConstants.ACCOUNT_TRANSFER_BBIN_KB);
                            parameterMap.put("website", allocationEntity.getWebSite());
                            parameterMap.put("username", allocationEntity.getAccountName());
                            parameterMap.put("password", allocationEntity.getPassword());
                            parameterMap.put("agcode", allocationEntity.getProductionId());
                            parameterMap.put("productId", allocationEntity.getProductionId());
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                            accountTransferService.insertAccountTransfer(parameterMap, baseUrl, accountTransferLogEntity, true);
                        } else if (UtilConstants.BBIN_HJHA.equals(platformId)) {
                            allocationEntity = accountTransferLogService.getAllocationById("230");
                            parameterMap.put("platformid", UtilConstants.ACCOUNT_TRANSFER_BBIN_HJHA);
                            parameterMap.put("website", allocationEntity.getWebSite());
                            parameterMap.put("username", allocationEntity.getAccountName());
                            parameterMap.put("password", allocationEntity.getPassword());
                            parameterMap.put("agcode", allocationEntity.getProductionId());
                            parameterMap.put("productId", allocationEntity.getProductionId());
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                            accountTransferService.insertAccountTransfer(parameterMap, baseUrl, accountTransferLogEntity, true);
                        } else if (UtilConstants.K8.equals(platformId)) {
                            allocationEntity = accountTransferLogService.getAllocationById("205");
                            parameterMap.put("platformid", UtilConstants.ACCOUNT_TRANSFER_K8);
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                            accountTransferService.insertAccountTransfer(parameterMap, baseUrl, accountTransferLogEntity, true);
                        } else if (UtilConstants.HOGAME.equals(platformId)) {
                            Integer task_id = accountTransferLogEntity.getTaskId();
                            allocationEntity = accountTransferLogService.getAllocationById(task_id.toString());
                            parameterMap.put("platformid", UtilConstants.ACCOUNT_TRANSFER_HG);
                            parameterMap.put("agcode", allocationEntity.getProductionId());
                            parameterMap.put("productId", allocationEntity.getProductionId());
                            parameterMap.put("website", allocationEntity.getWebSite());
                            parameterMap.put("username", allocationEntity.getAccountName());
                            parameterMap.put("password", allocationEntity.getPassword());
                            parameterMap.put("UserId", UtilConstants.BLANK);
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                            accountTransferService.insertAccountTransferForHogaing(parameterMap, baseUrl, accountTransferLogEntity, true);
                        } else if (UtilConstants.TLB.equals(platformId)) {
                            allocationEntity = accountTransferLogService.getAllocationById("231");
                            parameterMap.put("platformid", UtilConstants.TLB);
                            parameterMap.put("website", allocationEntity.getWebSite());
                            parameterMap.put("username", allocationEntity.getAccountName());
                            parameterMap.put("password", allocationEntity.getPassword());
                            parameterMap.put("agcode", allocationEntity.getProductionId());
                            parameterMap.put("productId", allocationEntity.getProductionId());
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                            accountTransferService.insertAccountTransferForTLB(parameterMap, baseUrl, accountTransferLogEntity, true);
                        } else if (UtilConstants.AMAYA_FCLRC.equals(platformId)) {
                            String taskId = accountTransferLogEntity.getTaskId().toString();
                            allocationEntity = accountTransferLogService.getAllocationById(taskId);
                            parameterMap.put("platformid", UtilConstants.ACCOUNT_TRANSFER_AMAYA_FCLRC);

                            parameterMap.put("website", allocationEntity.getWebSite());
                            parameterMap.put("username", allocationEntity.getAccountName());
                            parameterMap.put("password", allocationEntity.getPassword());
                            parameterMap.put("agcode", allocationEntity.getProductionId());
                            parameterMap.put("productId", allocationEntity.getProductionId());
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                            accountTransferService.insertAccountTransfer(parameterMap, baseUrl, accountTransferLogEntity, true);
                        } else if (UtilConstants.MG.equals(platformId)) {
                            String taskId = accountTransferLogEntity.getTaskId().toString();
                            allocationEntity = accountTransferLogService.getAllocationById(taskId);
                            parameterMap.put("platformid", UtilConstants.ACCOUNT_TRANSFER_MG);
                            parameterMap.put("website", allocationEntity.getWebSite());
                            parameterMap.put("username", allocationEntity.getAccountName());
                            parameterMap.put("password", allocationEntity.getPassword());
                            parameterMap.put("agcode", allocationEntity.getProductionId());
                            parameterMap.put("productId", allocationEntity.getProductionId());
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                            accountTransferService.insertAccountTransfer(parameterMap, baseUrl, accountTransferLogEntity, true);
                        } else if (UtilConstants.INDEX.equals(platformId)) {
                            allocationEntity = accountTransferLogService.getAllocationById("631");
                            parameterMap.put("baseUrl", allocationEntity.getUrl());
                            parameterMap.put("platformid", allocationEntity.getPlatformId());
                            parameterMap.put("agcode", allocationEntity.getAgCode());
                            parameterMap.put("productId", allocationEntity.getProductionId());
                            parameterMap.put("website", allocationEntity.getWebSite());
                            parameterMap.put("model", allocationEntity.getModel());
                            parameterMap.put("gamekind", allocationEntity.getGameKind());
                            parameterMap.put("username", allocationEntity.getAccountName());
                            parameterMap.put("password", allocationEntity.getPassword());
                            parameterMap.put("task_id", allocationEntity.getTaskId());
                            parameterMap.put("currencyType", allocationEntity.getCurrencyType());
                            parameterMap.put("page", 1 + "");
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                            accountTransferService.insertAccountTransfer4Index(parameterMap, baseUrl, accountTransferLogEntity, true);
                        } else if (UtilConstants.GT1.equals(platformId)) {
                            allocationEntity = accountTransferLogService.getAllocationById("621");
                            parameterMap.put("baseUrl", allocationEntity.getUrl());
                            parameterMap.put("platformid", allocationEntity.getPlatformId());
                            parameterMap.put("agcode", allocationEntity.getAgCode());
                            parameterMap.put("productId", allocationEntity.getProductionId());
                            parameterMap.put("website", allocationEntity.getWebSite());
                            parameterMap.put("model", allocationEntity.getModel());
                            parameterMap.put("gamekind", allocationEntity.getGameKind());
                            parameterMap.put("username", allocationEntity.getAccountName());
                            parameterMap.put("password", allocationEntity.getPassword());
                            parameterMap.put("task_id", allocationEntity.getTaskId());
                            parameterMap.put("currencyType", allocationEntity.getCurrencyType());
                            parameterMap.put("page", 1 + "");
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                            accountTransferService.insertAccountTransfer4GT1(parameterMap, baseUrl, accountTransferLogEntity, true);
                        } else if (UtilConstants.PT.equals(platformId)) {
                            allocationEntity = accountTransferLogService.getAllocationById("260");
                            parameterMap.put("baseUrl", allocationEntity.getUrl());
                            parameterMap.put("platformid", allocationEntity.getPlatformId());
                            parameterMap.put("agcode", allocationEntity.getAgCode());
                            parameterMap.put("productId", allocationEntity.getProductionId());
                            parameterMap.put("website", allocationEntity.getWebSite());
                            parameterMap.put("model", allocationEntity.getModel());
                            parameterMap.put("gamekind", allocationEntity.getGameKind());
                            parameterMap.put("username", allocationEntity.getAccountName());
                            parameterMap.put("password", allocationEntity.getPassword());
                            parameterMap.put("c07password", allocationEntity.getOrderField()); // C07 使用越南盾，所以证书和密码跟其他产品不一样，该字段单独存C07的密码    add by Miles on 2016-07-09
                            parameterMap.put("page", "1");
                            parameterMap.put("baseUrl", allocationEntity.getUrl());
                            baseUrl = allocationEntity.getUrl();
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                            accountTransferService.insertAccountTransferForPT(parameterMap, baseUrl, accountTransferLogEntity, true);
                        } else if (UtilConstants.BO.equals(platformId)) {
                            allocationEntity = accountTransferLogService.getAllocationById("261");
                            parameterMap.put(UtilConstants.COMMAND, UtilConstants.COMMAND_VIEW);
                            parameterMap.put("api_username", allocationEntity.getAccountName());
                            parameterMap.put("api_password", allocationEntity.getPassword());
                            parameterMap.put("api_whiteLabel", allocationEntity.getWebSite());
                            parameterMap.put("num", String.valueOf(allocationEntity.getPageSize()));
                            parameterMap.put("page", "1");
                            parameterMap.put("baseUrl", allocationEntity.getUrl());
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                            accountTransferService.insertAccountTransferForBO(parameterMap, accountTransferLogEntity, true);
                        } else if (UtilConstants.AP.equals(platformId)) {
                            allocationEntity = accountTransferLogService.getAllocationById("262");
                            parameterMap.put("baseUrl", allocationEntity.getUrl());
                            parameterMap.put("platformid", allocationEntity.getPlatformId());
                            parameterMap.put("agcode", allocationEntity.getAgCode());
                            parameterMap.put("productId", allocationEntity.getProductionId());
                            parameterMap.put("website", allocationEntity.getWebSite());
                            parameterMap.put("model", allocationEntity.getModel());
                            parameterMap.put("gamekind", allocationEntity.getGameKind());
                            parameterMap.put("username", allocationEntity.getAccountName());
                            parameterMap.put("password", allocationEntity.getPassword());
                            parameterMap.put("page", "1");
                            parameterMap.put("baseUrl", allocationEntity.getUrl());
                            baseUrl = allocationEntity.getUrl();
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                            accountTransferService.insertAccountTransferForAP(parameterMap, baseUrl, accountTransferLogEntity, true);
                        } else if (UtilConstants.NAP.equals(platformId)) {
                            allocationEntity = accountTransferLogService.getAllocationById("1035");
                            parameterMap.put("model", allocationEntity.getModel());
                            parameterMap.put(UtilConstants.ORDER_BBIN_PAGENUM, 1);
                            parameterMap.put(UtilConstants.GAME_RESULT_PAGE_NUMBER, String.valueOf(allocationEntity.getPageSize()));
                            parameterMap.put(UtilConstants.ORDER_BBIN_PASSWORD, allocationEntity.getPassword());
                            parameterMap.put(UtilConstants.ORDER_BBIN_GAMEKIND, allocationEntity.getGameKind());
                            parameterMap.put(UtilConstants.ORDER_BASE_URL, allocationEntity.getUrl());
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                            parameterMap.put(UtilConstants.ORDER_PRODUCT_ID, allocationEntity.getProductionId());
                            parameterMap.put(UtilConstants.GLOBAL_PLATFORMID_KEY, allocationEntity.getPlatformId());
                            parameterMap.put("accountName", allocationEntity.getAccountName());
                            parameterMap.put("baseUrl", allocationEntity.getUrl());
                            baseUrl = allocationEntity.getUrl();
                            accountTransferService.insertAccountTransferForNAP(parameterMap, baseUrl, accountTransferLogEntity, true);
                        } else if (UtilConstants.TGP.equals(platformId)) {
                            Integer task_id = accountTransferLogEntity.getTaskId();
                            allocationEntity = accountTransferLogService.getAllocationById(task_id.toString());
                            parameterMap.put("clientId", allocationEntity.getAccountName());//辨识吗
                            parameterMap.put("clientSecret", allocationEntity.getPassword());//营运商秘钥
                            parameterMap.put("tokenUrl", allocationEntity.getAgCode());//访问令牌的地址
                            parameterMap.put("baseUrl", allocationEntity.getUrl());
                            parameterMap.put("platformid", allocationEntity.getPlatformId());
                            parameterMap.put("productId", allocationEntity.getProductionId());
                            baseUrl = allocationEntity.getUrl();
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                            accountTransferService.insertAccountTransferForTGP(parameterMap, baseUrl, accountTransferLogEntity, true);
                        } else if (gameType.intValue() == GameType.IOM_WALLET.getType()) {
                            String taskId = accountTransferLogEntity.getTaskId().toString();
                            allocationEntity = accountTransferLogService.getAllocationById(taskId);

                            parameterMap.put("productId", allocationEntity.getProductionId());
                            parameterMap.put("platformid", allocationEntity.getPlatformId());
                            parameterMap.put("website", allocationEntity.getWebSite());
                            parameterMap.put("model", allocationEntity.getModel());
                            parameterMap.put("gamekind", allocationEntity.getGameKind());
                            parameterMap.put("username", allocationEntity.getAccountName());
                            parameterMap.put("password", allocationEntity.getPassword());
                            if (UtilConstants.SBT.equals(platformId)) {
                                parameterMap.put("gameCode", "8");
                            } else if (UtilConstants.BSG.equals(platformId)) {
                                parameterMap.put("gameCode", "5");
                            } else {
                                parameterMap.put("gameCode", allocationEntity.getGameCode());
                            }
                            parameterMap.put("agcode", allocationEntity.getProductionId());
                            parameterMap.put("timeZone", allocationEntity.getTimeZone());
                            parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                            parameterMap.put("baseUrl", allocationEntity.getUrl());
                            Integer beginSeconds = allocationEntity.getIncrementBegintime();
                            Integer endSeconds = allocationEntity.getIncrementEndtime();
                            parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                            parameterMap.put("endSeconds", String.valueOf(endSeconds));
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                            accountTransferService.insertAccountTransfer(parameterMap, baseUrl, accountTransferLogEntity, true);
                        } else if (UtilConstants.CQ9.equals(platformId)) {
                            String taskId = accountTransferLogEntity.getTaskId().toString();
                            allocationEntity = accountTransferLogService.getAllocationById(taskId);

                            parameterMap.put("productId", allocationEntity.getProductionId());
                            parameterMap.put("platformid", UtilConstants.ACCOUNT_TRANSFER_CQ9);
                            parameterMap.put("website", allocationEntity.getWebSite());
                            parameterMap.put("model", allocationEntity.getModel());
                            parameterMap.put("gamekind", allocationEntity.getGameKind());
                            parameterMap.put("username", allocationEntity.getAccountName());
                            parameterMap.put("password", allocationEntity.getPassword());
                            parameterMap.put("gameCode", allocationEntity.getGameCode());//CQ9 73
                            parameterMap.put("timeZone", allocationEntity.getTimeZone());
                            parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                            parameterMap.put("baseUrl", allocationEntity.getUrl());
                            Integer beginSeconds = allocationEntity.getIncrementBegintime();
                            Integer endSeconds = allocationEntity.getIncrementEndtime();
                            parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                            parameterMap.put("endSeconds", String.valueOf(endSeconds));
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                            accountTransferService.insertAccountTransfer(parameterMap, baseUrl, accountTransferLogEntity, true);
                        } else if (UtilConstants.YSB.equals(platformId)) {
                            String taskId = accountTransferLogEntity.getTaskId().toString();
                            allocationEntity = accountTransferLogService.getAllocationById(taskId);

                                parameterMap.put("productId", allocationEntity.getProductionId());
                                parameterMap.put("platformid", UtilConstants.ACCOUNT_TRANSFER_YSB);
                                parameterMap.put("website", allocationEntity.getWebSite());
                                parameterMap.put("model", allocationEntity.getModel());
                                parameterMap.put("gamekind", allocationEntity.getGameKind());
                                parameterMap.put("username", allocationEntity.getAccountName());
                                parameterMap.put("password", allocationEntity.getPassword());
                                parameterMap.put("gameCode", allocationEntity.getGameCode());//PNG 52
                                parameterMap.put("timeZone", allocationEntity.getTimeZone());
                                parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                                parameterMap.put("baseUrl", allocationEntity.getUrl());
                                Integer beginSeconds = allocationEntity.getIncrementBegintime();
                                Integer endSeconds = allocationEntity.getIncrementEndtime();
                                parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                                parameterMap.put("endSeconds", String.valueOf(endSeconds));
                                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                                accountTransferService.insertAccountTransfer(parameterMap, baseUrl, accountTransferLogEntity, true);
                            } else if (UtilConstants.NB.equals(platformId)) {
                                String taskId = accountTransferLogEntity.getTaskId().toString();
                                allocationEntity = accountTransferLogService.getAllocationById(taskId);
                                parameterMap.put("platformid", UtilConstants.ACCOUNT_TRANSFER_NB);
                                parameterMap.put("website", allocationEntity.getWebSite());
                                parameterMap.put("username", allocationEntity.getAccountName());
                                parameterMap.put("password", allocationEntity.getPassword());
                                parameterMap.put("agcode", allocationEntity.getProductionId());
                                parameterMap.put("productId", allocationEntity.getProductionId());
                                parameterMap.put("gameCode", "69");
                                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                                accountTransferService.insertAccountTransfer(parameterMap, baseUrl, accountTransferLogEntity, true);
                            } else if (UtilConstants.ESP.equals(platformId)) {
                                String taskId = accountTransferLogEntity.getTaskId().toString();
                                allocationEntity = accountTransferLogService.getAllocationById(taskId);
                                parameterMap.put("instanceId", allocationEntity.getAgCode());
                                parameterMap.put("token", allocationEntity.getOrderField());
                                parameterMap.put("timeZone", allocationEntity.getTimeZone());
                                parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                                parameterMap.put(UtilConstants.ORDER_PRODUCT_ID, allocationEntity.getProductionId());
                                accountTransferService.insertAccountTransferForESP(parameterMap, baseUrl, accountTransferLogEntity, true);
                            } else if(UtilConstants.QG.equals(platformId)){
                                String taskId = accountTransferLogEntity.getTaskId().toString();
                                allocationEntity = accountTransferLogService.getAllocationById(taskId);
                                parameterMap.put(UtilConstants.ORDER_BEGIN_TIME, DateUtil.formatDate2Str(allocationEntity.getTaskBeginTime()));
                                parameterMap.put(UtilConstants.ORDER_END_TIME, DateUtil.formatDate2Str(allocationEntity.getTaskEndTime()));
                                parameterMap.put(UtilConstants.ORDER_PAGE_NUMBER, String.valueOf(allocationEntity.getPageSize()));
                                parameterMap.put(UtilConstants.GLOBAL_PLATFORMID_KEY, allocationEntity.getPlatformId());
                                parameterMap.put("instanceId", allocationEntity.getAgCode());
                                parameterMap.put("token", allocationEntity.getOrderField());
                                parameterMap.put("timeZone", allocationEntity.getTimeZone());
                                parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                                parameterMap.put("baseUrl", allocationEntity.getUrl());
                                parameterMap.put("begintime", DateUtil.formatDate2Str(allocationEntity.getTaskBeginTime()));
                                parameterMap.put("endtime", DateUtil.formatDate2Str(allocationEntity.getTaskEndTime()));
                                Long beginSeconds = Long.valueOf(allocationEntity.getIncrementBegintime());
                                Long endSeconds = Long.valueOf(allocationEntity.getIncrementEndtime());
                                parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                                parameterMap.put("endSeconds", String.valueOf(endSeconds));
                                parameterMap.put("startTime", parameterMap.get("begintime"));
                                parameterMap.put("endTime", parameterMap.get("endtime"));
                                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                                parameterMap.put(UtilConstants.ORDER_PRODUCT_ID, allocationEntity.getProductionId());
                                parameterMap.put("currency", allocationEntity.getCurrency() == null ? "CNY" : allocationEntity.getCurrency());//获取币种类型
                                parameterMap.put("version",allocationEntity.getOrderField());
                                parameterMap.put("id",allocationEntity.getOrderWay());
                                parameterMap.put("key", allocationEntity.getPassword());
                                parameterMap.put("merchantCode", allocationEntity.getAccountName());
                                parameterMap.put("pageSize", String.valueOf(allocationEntity.getPageSize()));
                                if (baseUrl.contains("prizePoolActivityRecord")) {
                                    //奖池数据
                                    accountTransferService.insertPrizeDetailTransferForQG(parameterMap, baseUrl, accountTransferLogEntity, true);
                                } else {
                                    //转账数据
                                    accountTransferService.insertAccountTransferForQG(parameterMap, baseUrl, accountTransferLogEntity, true);
                                }
                            } else if (UtilConstants.VR.equals(platformId)){
                                allocationEntity = accountTransferLogService.getAllocationById(accountTransferLogEntity.getTaskId().toString());
                                String starTime = DateUtil.formatDate2Str(accountTransferLogEntity.getBeginTime(), "yyyy-MM-dd'T'HH:mm:ss'Z'");
                                String endTime = DateUtil.formatDate2Str(accountTransferLogEntity.getEndTime(), "yyyy-MM-dd'T'HH:mm:ss'Z'");
                                parameterMap.put("startTime", starTime);
                                parameterMap.put("endTime", endTime);
                                parameterMap.put(UtilConstants.ORDER_TASK_ID, accountTransferLogEntity.getTaskId());
                                parameterMap.put("timeZone", allocationEntity.getTimeZone());
                                parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                                parameterMap.put("baseUrl", allocationEntity.getUrl());
                                parameterMap.put("platformid", allocationEntity.getPlatformId());
                                parameterMap.put("productId", allocationEntity.getProductionId());
                                parameterMap.put("currency", allocationEntity.getCurrency() == null ? "CNY" : allocationEntity.getCurrency());
                                parameterMap.put("version", allocationEntity.getOrderField());
                                parameterMap.put("id", allocationEntity.getOrderWay());
                                parameterMap.put("cryptKey", allocationEntity.getAccountName());
                                parameterMap.put("model", allocationEntity.getModel());
                                parameterMap.put("num", String.valueOf(allocationEntity.getPageSize() == null ? 1000 : allocationEntity.getPageSize()));
                                accountTransferService.insertAccountTransferForVR(parameterMap, baseUrl, accountTransferLogEntity, true);
                            } else if (UtilConstants.CS.equals(platformId)){
                                allocationEntity = accountTransferLogService.getAllocationById(accountTransferLogEntity.getTaskId().toString());
                                parameterMap.put("startTime", accountTransferLogEntity.getBeginTime().getTime());
                                parameterMap.put("endTime", accountTransferLogEntity.getEndTime().getTime());
                                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                                String begin_time = DateUtil.formatDate2Str(accountTransferLogEntity.getBeginTime());
                                String end_time = DateUtil.formatDate2Str(accountTransferLogEntity.getEndTime());
                                parameterMap.put("begintime", begin_time);
                                parameterMap.put("endtime", end_time);
                                parameterMap.put("pageSize", allocationEntity.getPageSize());
                                parameterMap.put(UtilConstants.ORDER_PAGE_NUMBER, String.valueOf(allocationEntity.getPageSize()));
                                parameterMap.put("timeZone", allocationEntity.getTimeZone());
                                parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                                parameterMap.put("baseUrl", allocationEntity.getUrl());
                                parameterMap.put("platformid", allocationEntity.getPlatformId());
                                parameterMap.put("productId", allocationEntity.getProductionId());
                                parameterMap.put("currency", allocationEntity.getCurrency() == null ? UtilConstants.CNY : allocationEntity.getCurrency());
                                parameterMap.put("id", allocationEntity.getOrderWay());
                                parameterMap.put("agcode", allocationEntity.getAgCode());
                                parameterMap.put("model", allocationEntity.getModel());
                                parameterMap.put("app_id", allocationEntity.getOrderField());//数据库ORDER_FIELD存放appId
                                parameterMap.put("public_key", allocationEntity.getAgCode());
                                accountTransferService.insertAccountTransferForCS(parameterMap, baseUrl, accountTransferLogEntity, true);
                            } else if (UtilConstants.PB.equals(platformId)) {
                                allocationEntity = accountTransferLogService.getAllocationById(accountTransferLogEntity.getTaskId().toString());
                                parameterMap.put("startTime", accountTransferLogEntity.getBeginTime().getTime());
                                parameterMap.put("endTime", accountTransferLogEntity.getEndTime().getTime());
                                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                                String begin_time = DateUtil.formatDate2Str(accountTransferLogEntity.getBeginTime());
                                String end_time = DateUtil.formatDate2Str(accountTransferLogEntity.getEndTime());
                                parameterMap.put("begintime", begin_time);
                                parameterMap.put("endtime", end_time);
                                parameterMap.put("timeZone", allocationEntity.getTimeZone());
                                parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                                parameterMap.put("baseUrl", allocationEntity.getUrl());
                                parameterMap.put("platformid", allocationEntity.getPlatformId());
                                parameterMap.put("password", allocationEntity.getPassword());
                                parameterMap.put("agcode", allocationEntity.getProductionId());
                                parameterMap.put("productId", allocationEntity.getProductionId());
                                parameterMap.put("gameCode", "92");
                                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                                accountTransferService.insertAccountTransferForPB(parameterMap, baseUrl, accountTransferLogEntity, true);
                            }
                        } catch (Exception e) {
                            log.error("ErrorLog4AccountTransferTimer:Fail to trigger error log for account transfer!", e);
                        }
                    }
                }
                allocationDao.updateAllocation(mainAllocation); // 更新最后执行时间和任务开始结束时间
            }
        } catch (Exception ex) {
            log.error("ErrorLog4AccountTransferTimer:Fail to trigger error log for account transfer!", ex);
        }
        log.debug("Excuting Error Log Handler Timer - end.");


    }
}
