package main.java.com.gw.common.system.timer;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWFTPAccessException;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.FTPUtil;
import main.java.com.gw.common.system.redis.Rlock;
import main.java.com.gw.common.system.redis.TaskLock;
import main.java.com.gw.datacenter.allocation.entity.AllocationEntity;
import main.java.com.gw.datacenter.gameresultlog.entity.GameResultLogEntity;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.MDC;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 游戏结果错误日志
 */
@Slf4j
public class ErrorLog4GameResultTimer extends AllAbstractTimer {
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
        log.info(context.toString());
        JobDataMap jobDataMap = context.getJobDetail().getJobDataMap();
        AllocationEntity mainAllocation = null;
        try {
            mainAllocation = orderLogService.getAllocationById(jobDataMap.getString("taskId"));
        } catch (Exception e1) {
            log.error(e1.getMessage(), e1);
        }
        if (null == mainAllocation) {
            log.info(String.format("can not find task %s in the taskList", jobDataMap.getString("taskId")));
            return;
        }
        String baseUrl = null;
        String platformId = null;
        AllocationEntity allocationEntity = null;
        try(Rlock lock = TaskLock.tryAcquireLock(String.valueOf(mainAllocation.getTaskId()))) {
            if (lock.getLock()) {
                Map<String, Object> parameterMapForLock = new HashMap<String, Object>();
                parameterMapForLock.put(UtilConstants.ORDER_TASK_ID, mainAllocation.getTaskId());
                parameterMapForLock.put(UtilConstants.ORDER_BEGIN_TIME, mainAllocation.getTaskBeginTime());
                parameterMapForLock.put(UtilConstants.ORDER_END_TIME, mainAllocation.getTaskEndTime());

                List<GameResultLogEntity> gameResultLogEntityList = gameResultLogService.getAllErrorGameResultLog();
                if (gameResultLogEntityList != null && gameResultLogEntityList.size() > 0) {
                    for (GameResultLogEntity gameResultLogEntity : gameResultLogEntityList) {
                        MDC.put("uuid", MDC.get("uuid").split("_")[0] + "_" + UUID.randomUUID().toString().replace("-", ""));//每个错误日志打印不同uuid，不然不好排查错误
                        try {
                            baseUrl = gameResultLogEntity.getUrl();
                            platformId = gameResultLogEntity.getPlatId();
                            Map<String, Object> parameterMap = new HashMap<String, Object>();
                            parameterMap.put("begintime", DateUtil.formatDate2Str(gameResultLogEntity.getBeginTime()));
                            parameterMap.put("endtime", DateUtil.formatDate2Str(gameResultLogEntity.getEndTime()));
                            parameterMap.put("num", String.valueOf(gameResultLogEntity.getPageSize()));
                            parameterMap.put("agcode", null);

                            if (UtilConstants.AGQJ.equals(platformId)) {
                                parameterMap.put("platformid", UtilConstants.GAMERESULT_AG);
                                baGameService.insertGameResult(parameterMap, baseUrl, gameResultLogEntity, true);
                            } else if (UtilConstants.AGSTAR.equals(platformId)) {
                                parameterMap.put("platformid", UtilConstants.GAMERESULT_AGSTAR);
                                baGameService.insertGameResult(parameterMap, baseUrl, gameResultLogEntity, true);
                            } else if (UtilConstants.AG2.equals(platformId)) {
                                parameterMap.put("platformid", UtilConstants.GAMERESULT_AG2);
                                baGameService.insertGameResult(parameterMap, baseUrl, gameResultLogEntity, true);
                            } else if (UtilConstants.AGIN.equals(platformId)) {
                                parameterMap.put("platformid", UtilConstants.GAMERESULT_AGIN);
                                baGameService.insertGameResult(parameterMap, baseUrl, gameResultLogEntity, true);
                            } else if (UtilConstants.K8.equals(platformId) || UtilConstants.K8_EH.equals(platformId)) {
                                parameterMap.put("platformid", UtilConstants.GAMERESULT_K8);
                                baGameService.insertGameResult(parameterMap, baseUrl, gameResultLogEntity, true);
                            } else if (UtilConstants.HOGAME.equals(platformId) && UtilConstants.PRODUCTID_MT.equals(gameResultLogEntity.getProductId())) {
                                allocationEntity = gameResultLogService.getAllocationById("107");
                                parameterMap.put("productId", allocationEntity.getProductionId());
                                parameterMap.put("website", allocationEntity.getWebSite());
                                parameterMap.put("username", allocationEntity.getAccountName());
                                parameterMap.put("password", allocationEntity.getPassword());
                                parameterMap.put("UserId", UtilConstants.BLANK);
                                parameterMap.put("platformid", UtilConstants.GAMERESULT_HOGAME);
                                baGameService.insertGameResult(parameterMap, baseUrl, gameResultLogEntity, true);
                            } else if (UtilConstants.HOGAME.equals(platformId) && UtilConstants.PRODUCTID_KB.equals(gameResultLogEntity.getProductId())) {
                                allocationEntity = gameResultLogService.getAllocationById("108");
                                parameterMap.put("productId", allocationEntity.getProductionId());
                                parameterMap.put("website", allocationEntity.getWebSite());
                                parameterMap.put("username", allocationEntity.getAccountName());
                                parameterMap.put("password", allocationEntity.getPassword());
                                parameterMap.put("UserId", UtilConstants.BLANK);
                                parameterMap.put("platformid", UtilConstants.GAMERESULT_HOGAME);
                                baGameService.insertGameResult(parameterMap, baseUrl, gameResultLogEntity, true);
                            } else if (UtilConstants.HOGAME.equals(platformId) && UtilConstants.PRODUCT_ENUM.E02.toString().equals(gameResultLogEntity.getProductId())) {
                                allocationEntity = gameResultLogService.getAllocationById("126");
                                parameterMap.put("productId", allocationEntity.getProductionId());
                                parameterMap.put("website", allocationEntity.getWebSite());
                                parameterMap.put("username", allocationEntity.getAccountName());
                                parameterMap.put("password", allocationEntity.getPassword());
                                parameterMap.put("UserId", UtilConstants.BLANK);
                                parameterMap.put("platformid", UtilConstants.GAMERESULT_HOGAME);
                                baGameService.insertGameResult(parameterMap, baseUrl, gameResultLogEntity, true);
                            } else if (UtilConstants.EA.equals(platformId)) {
                                parameterMap.put("platformid", UtilConstants.GAMERESULT_EA);
                                FTPUtil ftpClient = new FTPUtil();
                                try {
                                    allocationEntity = gameResultLogService.getAllocationById("106");
                                    ftpClient.setIp(allocationEntity.getWebSite());
                                    ftpClient.setUser(allocationEntity.getAccountName());
                                    ftpClient.setPwd(allocationEntity.getPassword());
                                    baGameService.insertGameResult4EA(ftpClient, parameterMap, baseUrl, gameResultLogEntity, true);
                                } catch (GWFTPAccessException e) {
                                    log.error("Fail to call insertGameResult4EA by manual way.", e);
                                } finally {
                                    try {
                                        if (ftpClient.getFtpClient() != null) {
                                            ftpClient.getFtpClient().close();
                                            ftpClient.isConnection = false;
                                        }
                                    } catch (Exception e) {
                                        log.error(e.getMessage(), e);
                                    }
                                }
                            }
                        } catch (Exception e) {
                            log.error("ErrorLog4GameResultTimer:Fail to trigger error log for game result!", e);
                        } finally {
                        }
                    }
                }
                allocationDao.updateAllocation(mainAllocation); // 更新最后执行时间和任务开始结束时间
            }
        } catch (Exception ex) {
            log.error("ErrorLog4GameResultTimer:Fail to trigger error log for game result!", ex);
        }
        log.debug("Excuting ErrorLog4GameResultTimer - end.");
    }
}
