package main.java.com.gw.common.system.timer;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.system.redis.Rlock;
import main.java.com.gw.common.system.redis.TaskLock;
import main.java.com.gw.datacenter.allocation.entity.AllocationEntity;
import main.java.com.gw.datacenter.orderlog.entity.OrderLogEntity;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.MDC;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 错误日志注单
 */
@Slf4j
public class ErrorLog4OrderTimer extends AllAbstractTimer {

    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
        log.info(context.toString());

        JobDataMap jobDataMap = context.getJobDetail().getJobDataMap();
        AllocationEntity mainAllocation = null;
        try {
            mainAllocation = orderLogService.getAllocationById(jobDataMap.getString("taskId"));
        } catch (Exception e1) {
            log.error(e1.getMessage(), e1);
        }
        if (null == mainAllocation) {
            log.info(String.format("can not find task %s in the taskList", jobDataMap.getString("taskId")));
            return;
        }
        int minTaskid = mainAllocation.getIncrementBegintime();
        int maxTaskid = mainAllocation.getIncrementEndtime();
        int pageSize = mainAllocation.getPageSize();//在查询错误日志中该字段表示查询错误数据的条数 0表示查询所有 1及其以上表示查询出对应行数

        log.info("Excuting Error Log Handler Timer - begin.minTaskId:" + minTaskid + " maxTaskid:" + maxTaskid);
//        try(Rlock lock = TaskLock.tryAcquireLock(String.valueOf(mainAllocation.getTaskId()))) {
        try {
//            if (lock.getLock()) {
                List<OrderLogEntity> errorLogList = null;
                if (minTaskid == 0 && maxTaskid == 0) {
                    errorLogList = orderLogService.getAllErrorOrderLog("bbin");
                } else {
                    errorLogList = orderLogService.getErrorOrderLogByTaskId(minTaskid, maxTaskid, pageSize);
                }
                if (errorLogList != null && errorLogList.size() > 0) {
                    for (OrderLogEntity orderLogEntity : errorLogList) {
                        MDC.put("uuid", MDC.get("uuid").split("_")[0] + "_" + UUID.randomUUID().toString().replace("-", ""));//每个错误日志打印不同uuid，不然不好排查错误
                        Integer taskId = orderLogEntity.getTaskId();
                        AllocationEntity allocationEntity = allocationDao.getAllocationById(taskId.toString());//查询货币类型
                        orderLogEntity.setCurrency(allocationEntity.getCurrency());//设置货币类型
                        OrderMethodInvokerUtils.invoke(orderLogEntity, orderLogService, orderService);
                    }
                }
                allocationDao.updateAllocation(mainAllocation); // 更新最后执行时间和任务开始结束时间
//            }
        } catch (Exception ex) {
            log.error("ErrorLog4OrderTimer:Fail to trigger error log for order!", ex);
        }
        log.info("Excuting Error Log Handler Timer - end.minTaskId:" + minTaskid + " maxTaskid:" + maxTaskid);

    }
}
