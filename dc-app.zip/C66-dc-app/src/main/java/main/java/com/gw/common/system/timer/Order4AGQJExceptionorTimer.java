package main.java.com.gw.common.system.timer;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.redis.Rlock;
import main.java.com.gw.common.system.redis.TaskLock;
import main.java.com.gw.datacenter.allocation.entity.AllocationEntity;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.MDC;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * CAP-2480 AGQJ篡改注单 20190108
 */
@Slf4j
public class Order4AGQJExceptionorTimer extends AllAbstractTimer {

    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
        log.info(context.toString());
        JobDataMap jobDataMap = context.getJobDetail().getJobDataMap();
        String taskId = jobDataMap.getString("taskId");
        log.info("--DC定时任务日志-TaskID-{}-",taskId);
        try(Rlock lock = TaskLock.tryAcquireLock(taskId)) {
            if (lock.getLock()) {
                long endSeconds = 0L;
                long beginSeconds = 0L;
                Map<String, Object> parameterMap = new HashMap<>();
                List<AllocationEntity> allocationEntityList = allocationDao.getAllocationList(new String[]{taskId});
                if (allocationEntityList != null && allocationEntityList.size() > 0) {
                    for (AllocationEntity allocationEntity : allocationEntityList) {
                        parameterMap.put("begintime", DateUtil.formatDate2Str(allocationEntity.getTaskBeginTime()));
                        parameterMap.put("endtime", DateUtil.formatDate2Str(allocationEntity.getTaskEndTime()));
                        parameterMap.put("num", String.valueOf(allocationEntity.getPageSize()));
                        parameterMap.put(UtilConstants.GLOBAL_PRODUCTID_KEY, allocationEntity.getProductionId());
                        parameterMap.put(UtilConstants.GLOBAL_PLATFORMID_KEY, allocationEntity.getPlatformId());
                        parameterMap.put(UtilConstants.ORDER_BBIN_GAMEKIND, allocationEntity.getGameKind());
                        parameterMap.put("timeZone", allocationEntity.getTimeZone());
                        parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                        parameterMap.put("baseUrl", allocationEntity.getUrl());
                        beginSeconds = allocationEntity.getIncrementBegintime();
                        endSeconds = allocationEntity.getIncrementEndtime();
                        parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                        parameterMap.put("endSeconds", String.valueOf(endSeconds));
                        parameterMap.put("password", allocationEntity.getPassword());
                        parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                    }
                    log.info("end set parameter to maps,maps==>" + parameterMap);
                }
                parameterMap = ToolUtil.updateTimeForParameterMap(parameterMap, beginSeconds, endSeconds);

                String timeZone = (String) parameterMap.get("timeZone");
                int dataDelay = (int) parameterMap.get("dataDelay");
                boolean isWait = ToolUtil.isWaitXMins(parameterMap, timeZone, dataDelay);
                if (!isWait) {
                    String baseUrl = (String) parameterMap.get("baseUrl");
                    orderService.insertOrderAGQJExceptionor(parameterMap, UtilConstants.AGQJ, baseUrl, null, false , taskId);
                }
            }
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
        }
    }
}	
