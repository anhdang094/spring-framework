package main.java.com.gw.common.system.timer;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWPersistenceException;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.redis.Rlock;
import main.java.com.gw.common.system.redis.TaskLock;
import main.java.com.gw.datacenter.allocation.entity.AllocationEntity;
import org.apache.commons.lang3.StringUtils;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.MDC;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @Description: 自动配置抓注单定时任务
 * @Author: twJim.j
 * @Date: 2018/6/13 12:00
 */
@Slf4j
public class Order4AutoTimer extends AllAbstractTimer {

    @Override
    public void execute(JobExecutionContext arg0) throws JobExecutionException {
        MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
        log.info("Enter Order4AutoTimer.execute()");
        log.info(arg0.toString());

        JobDataMap jobDataMap = arg0.getJobDetail().getJobDataMap();
        long endSeconds = 0L;
        long beginSeconds = 0L;
        log.info("--DC定时任务日志-TaskID-{}-",jobDataMap.getString("taskId") );
        try(Rlock lock = TaskLock.tryAcquireLock(jobDataMap.getString("taskId"))) {
            if (lock.getLock()) {
                Map<String, Object> parameterMap = getParameterMap(jobDataMap);

                beginSeconds = Long.parseLong(parameterMap.get("beginSeconds").toString());
                endSeconds = Long.parseLong(parameterMap.get("endSeconds").toString());

                parameterMap = ToolUtil.updateTimeForParameterMap(parameterMap, beginSeconds, endSeconds, null);

                boolean isWait = getWaitStatus(parameterMap);
                log.info("Order4AutoTimer.execute()-isWait:" + isWait);
                if (!isWait) {
                    String baseUrl = (String) parameterMap.get("baseUrl");
                    log.info("Order4AutoTimer.execute()-baseUrl:" + baseUrl);

                    this.orderService.insertOrder4Auto(parameterMap, baseUrl, null, false , "0");
                }
            }
        } catch (Exception ex) {
            log.error(ex.getLocalizedMessage(), ex);
        }
    }

    private boolean getWaitStatus(Map<String, Object> parameterMap) {
        String timeZone = (String) parameterMap.get("timeZone");
        int dataDelay = (int) parameterMap.get("dataDelay");
        return ToolUtil.isWaitXMins(parameterMap, timeZone, dataDelay);
    }

    /**
     * get  parameterMap  from jobDataMap,if null get from DB config
     *
     * @param jobDataMap
     * @return
     * @throws GWPersistenceException
     */
    private Map<String, Object> getParameterMap(JobDataMap jobDataMap) throws GWPersistenceException {
        String taskId = jobDataMap.getString("taskId");
        return fillParameterMapByConfig(taskId);
    }

    /**
     * get AllocationEntity from DB and fill into ParameterMap
     *
     * @throws GWPersistenceException
     */
    private Map<String, Object> fillParameterMapByConfig(String taskId) throws GWPersistenceException {
        Map<String, Object> parameterMap = new HashMap<String, Object>();
        if (!StringUtils.isBlank(taskId)) {
            List<AllocationEntity> allocationEntityList = this.allocationDao.getAllocationList(new String[]{taskId});
            Integer taskInteger = Integer.valueOf(taskId);
            if (allocationEntityList != null && allocationEntityList.size() > 0) {
                AllocationEntity allocationEntity = allocationEntityList.get(0);
                if (allocationEntity != null && taskInteger.equals(allocationEntity.getTaskId())) {
                    parameterMap = setupParameter(parameterMap, allocationEntity);
                }
            }
        }

        return parameterMap;
    }

    private Map<String, Object> setupParameter(Map<String, Object> parameterMap, AllocationEntity allocationEntity) {
        parameterMap.put("begintime", DateUtil.formatDate2Str(allocationEntity.getTaskBeginTime()));
        //CW_dc的参数判断中有个奇怪的判断，不是NT厅必须有starttime，所以在这里把begintime复制一遍。
        parameterMap.put("starttime", parameterMap.get("begintime"));
        parameterMap.put("endtime", DateUtil.formatDate2Str(allocationEntity.getTaskEndTime()));
        parameterMap.put("num", String.valueOf(allocationEntity.getPageSize()));
        parameterMap.put("platformid", allocationEntity.getPlatformId());
        parameterMap.put("agcode", allocationEntity.getProductionId());
        parameterMap.put("productId", allocationEntity.getProductionId());
        parameterMap.put("website", allocationEntity.getWebSite());
        parameterMap.put("model", allocationEntity.getModel());
        parameterMap.put("targetTable", allocationEntity.getTargetTable());
        parameterMap.put("gamekind", allocationEntity.getGameKind());
        parameterMap.put("username", allocationEntity.getAccountName());
        parameterMap.put("password", allocationEntity.getPassword());
        parameterMap.put("gameCode", allocationEntity.getGameCode());
        parameterMap.put("timeZone", allocationEntity.getTimeZone());
        parameterMap.put("dataDelay", allocationEntity.getDataDelay());
        parameterMap.put("baseUrl", allocationEntity.getUrl());
        int beginSeconds = allocationEntity.getIncrementBegintime();
        int endSeconds = allocationEntity.getIncrementEndtime();
        parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
        parameterMap.put("endSeconds", String.valueOf(endSeconds));
        parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
        parameterMap.put("key", "123456");//key可以随意赋值，CW_dc只做了非空判断
        log.info("Order4AutoTimer.execute(), Get the task:id=" + allocationEntity.getTaskId() + ",beginTime=" + allocationEntity.getTaskBeginTime() + ",endTime=" + allocationEntity.getTaskEndTime());
        return parameterMap;
    }
}	
