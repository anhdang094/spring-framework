package main.java.com.gw.common.system.timer;

import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.redis.Rlock;
import main.java.com.gw.common.system.redis.TaskLock;
import main.java.com.gw.datacenter.allocation.entity.AllocationEntity;
import org.apache.commons.lang3.StringUtils;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.MDC;

import java.text.SimpleDateFormat;
import java.util.*;

@Slf4j
@SuppressWarnings("deprecation")
public class Order4CGTimer extends AllAbstractTimer {
    @Override
    public void execute(JobExecutionContext arg0) throws JobExecutionException {
        MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
        log.info(arg0.toString());
        JobDataMap jobDataMap = arg0.getJobDetail().getJobDataMap();
        String taskId = jobDataMap.getString("taskId");
        log.info("--DC定时任务日志-TaskID-{}-",taskId);
        try(Rlock lock = TaskLock.tryAcquireLock(taskId)) {
            if (lock.getLock()) {
                long endSeconds = 0L;
                long beginSeconds = 0L;

                Map<String, Object> parameterMap = new HashMap<String, Object>();
                List<AllocationEntity> allocationEntityList = allocationDao.getAllocationList(new String[]{taskId});
                if (!StringUtils.isBlank(taskId)) {
                    Integer taskInteger = Integer.valueOf(taskId);
                    if (allocationEntityList != null && allocationEntityList.size() > 0) {
                        for (AllocationEntity allocationEntity : allocationEntityList) {
                            if (taskInteger.equals(allocationEntity.getTaskId())) {
                                parameterMap.put("begintime", DateUtil.formatDate2Str(allocationEntity.getTaskBeginTime()));
                                parameterMap.put("endtime", DateUtil.formatDate2Str(allocationEntity.getTaskEndTime()));
                                parameterMap.put(UtilConstants.ORDER_PAGE_NUMBER, String.valueOf(allocationEntity.getPageSize()));
                                parameterMap.put(UtilConstants.GLOBAL_PRODUCTID_KEY, allocationEntity.getProductionId());
                                parameterMap.put("timeZone", allocationEntity.getTimeZone());
                                parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                                parameterMap.put(UtilConstants.ORDER_BASE_URL, allocationEntity.getUrl());
                                beginSeconds = allocationEntity.getIncrementBegintime();
                                endSeconds = allocationEntity.getIncrementEndtime();
                                parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                                parameterMap.put("endSeconds", String.valueOf(endSeconds));
                                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                                parameterMap.put("remark", allocationEntity.getRemark());
                                parameterMap.put( UtilConstants.ORDER_BBIN_GAMEKIND , allocationEntity.getGameKind());
                                //平台商名称
                                parameterMap.put("agentName", allocationEntity.getAccountName());
                                parameterMap.put("currency", allocationEntity.getCurrency());
                                parameterMap.put("loginName", allocationEntity.getLoginName());
                                parameterMap.put("action", allocationEntity.getAction());
                            }
                        }
                    }
                }
                parameterMap = ToolUtil.updateTimeForBBINParameterMap(parameterMap, beginSeconds, endSeconds);
                log.info("--DC定时任务参数:{}-TaskID-{}-", JSON.toJSONString(parameterMap),taskId);
                String timeZone = (String) parameterMap.get("timeZone");
                int dataDelay = (int) parameterMap.get("dataDelay");
                boolean isWait = ToolUtil.isWaitXMins(parameterMap, timeZone, dataDelay);
                log.info("--DC定时任务 isWait:{}-TaskID-{}-", isWait,taskId);
                if (!isWait) {
                    String baseUrl = (String) parameterMap.get(UtilConstants.ORDER_BASE_URL);
                    orderService.insertOrder4CG(parameterMap, baseUrl, null, false,taskId);
                }
            }
        } catch (Exception ex) {
            log.error("-注单抓取-DC定时任务日志-execute-异常信息-TaskId-{}-detail-{}",taskId, ex);
        }
        log.info("Excuting Order4CGTimer Timer - end.");
    }

    public static void main(String[] args) {
        Date date = DateUtil.formatStr2Date("2021-02-19T02:01:45+00:00",DateUtil.C_DATE_T_PATTON_DDMMYYYY);
        Calendar bjTime = Calendar.getInstance();
        bjTime.setTime(date);
        bjTime.add(Calendar.HOUR_OF_DAY,8);
        System.err.println(bjTime.getTime());
    }
}	
