package main.java.com.gw.common.system.timer;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.Main;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.exception.GWFTPAccessException;
import main.java.com.gw.common.framework.exception.GWPersistenceException;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.FTPUtil;
import main.java.com.gw.common.system.redis.Rlock;
import main.java.com.gw.common.system.redis.TaskLock;
import main.java.com.gw.datacenter.allocation.dao.AllocationDao;
import main.java.com.gw.datacenter.allocation.entity.AllocationEntity;
import main.java.com.gw.datacenter.order.service.OrderService;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.StatefulJob;
import org.slf4j.MDC;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Slf4j
@SuppressWarnings("deprecation")
public class Order4EATimer implements StatefulJob {
    private String taskId;
    private OrderService orderService;
    private AllocationDao allocationDao;
    private String fileNameFromLog = "";
    private String latestFileName = "";
    private FTPUtil ftpUtil = new FTPUtil();
    private Map<String, Object> parameterMap = new HashMap<String, Object>();

    @Override
    public void execute(JobExecutionContext arg0) throws JobExecutionException {
        MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
        log.info(arg0.toString());
        JobDataMap jobDataMap = arg0.getJobDetail().getJobDataMap();
        taskId = jobDataMap.getString("taskId");
        log.info("--DC定时任务日志-TaskID-{}-",taskId);
        log.debug("Excuting Order4EATimer - begin.");
        if (jobDataMap.containsKey("parameterMap")) {
            parameterMap = (Map<String, Object>) jobDataMap.get("parameterMap");
            fileNameFromLog = (String) jobDataMap.get("fileNameFromLog");
            latestFileName = (String) jobDataMap.get("latestFileName");
            ftpUtil.setIp(parameterMap.get("ip").toString());
            ftpUtil.setUser(parameterMap.get("user").toString());
            ftpUtil.setPwd(parameterMap.get("pwd").toString());
        }
        this.allocationDao = (AllocationDao) Main.factory.getBean("allocationDao");
        this.orderService = (OrderService) Main.factory.getBean("orderService");

        boolean isExist = false;
        String beforeLatestFileName = null;
        try(Rlock lock = TaskLock.tryAcquireLock(taskId)) {
            if (lock.getLock()) {
                if (parameterMap.isEmpty()) {
                    List<AllocationEntity> allocationEntityList = this.allocationDao.getAllocationList(new String[]{taskId});
                    if (allocationEntityList != null && allocationEntityList.size() > 0) {


                        AllocationEntity mainAllocation = allocationEntityList.get(0);
                        Map<String, Object> parameterMapForLock = new HashMap<String, Object>();
                        parameterMapForLock.put(UtilConstants.ORDER_TASK_ID, mainAllocation.getTaskId());
                        parameterMapForLock.put(UtilConstants.ORDER_BEGIN_TIME, mainAllocation.getTaskBeginTime());
                        parameterMapForLock.put(UtilConstants.ORDER_END_TIME, mainAllocation.getTaskEndTime());

                        this.fileNameFromLog = allocationEntityList.get(0).getUrl();
                        this.parameterMap.put("platformid", allocationEntityList.get(0).getPlatformId());
                        this.parameterMap.put("agcode", allocationEntityList.get(0).getProductionId());
                        this.parameterMap.put("productId", allocationEntityList.get(0).getProductionId());
                        this.parameterMap.put("num", String.valueOf(allocationEntityList.get(0).getPageSize()));
                        this.parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntityList.get(0).getTaskId());
                        String ip = allocationEntityList.get(0).getWebSite();
                        String user = allocationEntityList.get(0).getAccountName();
                        String pwd = allocationEntityList.get(0).getPassword();
                        this.parameterMap.put("ip", ip);
                        this.parameterMap.put("user", user);
                        this.parameterMap.put("pwd", pwd);
                        ftpUtil.setIp(ip);
                        // ftpClient.setPort(UtilConstants.FTP_EA_PORT); //use theFTP default port
                        ftpUtil.setUser(user);
                        ftpUtil.setPwd(pwd);
                    }
                }
                if (!ftpUtil.isConnection) {
                    try {
                        ftpUtil.connectServer(ftpUtil.getIp(), 21, ftpUtil.getUser(), ftpUtil.getPwd());
                    } catch (Exception e) {
                        log.error("Can not connection FTP Server! The server will reconnect later...", e);
                        throw new GWFTPAccessException("Can not connection FTP Server! " + e.getMessage());
                    }
                }
                List<String> fileNameList = ftpUtil.getFileNameList(UtilConstants.FTP_EA_DIRECTORY_REMOTE, UtilConstants.FTP_EA_FILENAME);
                if (fileNameList.size() > 0) {
                    String latestFileName = fileNameList.get(fileNameList.size() - 1);
                    // for normal case,only one new file in FTP server.
                    if (fileNameList.size() >= 2) {
                        beforeLatestFileName = fileNameList.get(fileNameList.size() - 2);
                    }
                    if (fileNameFromLog.equalsIgnoreCase(latestFileName)) {
                        this.latestFileName = latestFileName;
                        // if no new file,return.
                    } else if (fileNameFromLog.equalsIgnoreCase(beforeLatestFileName)) {
                        this.fileNameFromLog = latestFileName;
                        this.latestFileName = latestFileName;
                        // down load the latest file
                        this.orderService.insertOrder4EA(ftpUtil, parameterMap, latestFileName, null, false , taskId);
                    } else {
                        for (int i = 0; i < fileNameList.size(); i++) {
                            if (!isExist && fileNameFromLog.equalsIgnoreCase(fileNameList.get(i))) {
                                isExist = true;
                                continue;
                            }
                            if (isExist) {
                                // set file name if there is an exception was happened.
                                this.latestFileName = fileNameList.get(i);
                                this.orderService.insertOrder4EA(ftpUtil, parameterMap, fileNameList.get(i), null, false , taskId);
                            }
                        }
                        // if can not find the file in file list,and then down load
                        // all the files from FTP server.
                        if (!isExist) {
                            List<String> oldFileNameList = null;
                            List<String> folderNameList = ftpUtil.getFolderNameList(UtilConstants.FTP_EA_DIRECTORY_REMOTE);
                            for (String folderName : folderNameList) {
                                int lastDate = Integer.parseInt(DateUtil.formatDate2Str(DateUtil.dayBefore2Date(-3),
                                        DateUtil.C_DATE_PATTON_YYYYMMDD));
                                if (Integer.valueOf(folderName) >= lastDate) {
                                    oldFileNameList = this.ftpUtil.getFileNameList(folderName);
                                    for (String fileName : oldFileNameList) {
                                        try {
                                            this.fileNameFromLog = fileName;
                                            this.latestFileName = fileName;
                                            this.orderService.insertOrder4EA(ftpUtil, parameterMap, fileName, null,
                                                    false , taskId);
                                        } catch (GWFTPAccessException ex) {
                                            this.ftpUtil.isConnection = false;
                                            try {
                                                if (this.ftpUtil.getFtpClient() != null) {
                                                    this.ftpUtil.getFtpClient().close();
                                                }
                                            } catch (IOException ioe) {
                                            }
                                            log.error(ex.getMessage(), ex);
                                        } catch (GWPersistenceException ex) {
                                            this.ftpUtil.isConnection = false;
                                            try {
                                                if (this.ftpUtil.getFtpClient() != null) {
                                                    this.ftpUtil.getFtpClient().close();
                                                }
                                            } catch (IOException ioe) {
                                            }
                                            log.error(ex.getMessage(), ex);
                                        }
                                    }
                                }
                            }
                        } else {
                            this.fileNameFromLog = fileNameList.get(fileNameList.size() - 1);
                        }
                    }
                }
            }
        } catch (Exception ex) {
            this.fileNameFromLog = this.latestFileName;
            log.error("Fail to insert order for EA:" + ex.getMessage(), ex);
        } finally {
            this.ftpUtil.isConnection = false;
            jobDataMap.put("parameterMap", parameterMap);
            jobDataMap.put("fileNameFromLog", fileNameFromLog);
            jobDataMap.put("latestFileName", latestFileName);
            try {
                if (this.ftpUtil.getFtpClient() != null) {
                    this.ftpUtil.getFtpClient().close();
                }
            } catch (IOException e) {
                log.error(e.getMessage(), e);
            }
        }
        log.debug("Excuting Order4EATimer - end.");
    }

}	
