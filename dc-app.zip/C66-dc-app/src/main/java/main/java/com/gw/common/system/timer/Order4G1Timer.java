package main.java.com.gw.common.system.timer;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.redis.Rlock;
import main.java.com.gw.common.system.redis.TaskLock;
import main.java.com.gw.datacenter.allocation.entity.AllocationEntity;
import org.apache.commons.lang3.StringUtils;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.MDC;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @author Dominik.X
 * @description
 *  g1彩票注单抓取
 * @date 2019/6/18 19:45
 */
@Slf4j
public class Order4G1Timer extends AllAbstractTimer {
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
        log.info(context.toString());
        JobDataMap jobDataMap = context.getJobDetail().getJobDataMap();
        String taskId = jobDataMap.getString("taskId");
        log.info("--DC定时任务日志-TaskID-{}-",taskId);
        try(Rlock lock = TaskLock.tryAcquireLock(taskId)) {
            if (lock.getLock()) {
                long beginSeconds = 0L;
                long endSeconds = 0L;
                Map<String,Object> paramMap = new HashMap<>();
                List<AllocationEntity> allocationEntityList = allocationDao.getAllocationList(new String[] {taskId});
                if(StringUtils.isNotBlank(taskId)){
                    Integer taskInteger = Integer.parseInt(taskId);
                    if(allocationEntityList != null && !allocationEntityList.isEmpty()){
                        for(AllocationEntity entity:allocationEntityList){
                            if(taskInteger.equals(entity.getTaskId())){
                                String starTime = DateUtil.formatDate2Str(entity.getTaskBeginTime());
                                String endTime = DateUtil.formatDate2Str(entity.getTaskEndTime());
                                paramMap.put("startTime", starTime);
                                paramMap.put("endTime", endTime);
                                paramMap.put(UtilConstants.ORDER_TASK_ID, entity.getTaskId());

                                String begin_time = DateUtil.formatDate2Str(entity.getTaskBeginTime());
                                String end_time = DateUtil.formatDate2Str(entity.getTaskEndTime());
                                paramMap.put("begintime", begin_time);
                                paramMap.put("endtime", end_time);

                                beginSeconds = entity.getIncrementBegintime();
                                endSeconds = entity.getIncrementEndtime();
                                paramMap.put("beginSeconds", String.valueOf(beginSeconds));
                                paramMap.put("endSeconds", String.valueOf(endSeconds));
                                paramMap.put("pageSize", String.valueOf(entity.getPageSize()));
                                paramMap.put("timeZone", entity.getTimeZone());
                                paramMap.put("dataDelay", entity.getDataDelay());
                                paramMap.put("baseUrl", entity.getUrl());
                                paramMap.put("platformid", entity.getPlatformId());
                                paramMap.put("productId", entity.getProductionId());
                                paramMap.put("currency", entity.getCurrency() == null ? "CNY" : entity.getCurrency());
                                paramMap.put("version",entity.getOrderField());
                                paramMap.put("id",entity.getOrderWay());
                                paramMap.put("merchantKey",entity.getPassword());
                                paramMap.put("model", entity.getModel());

                            }
                        }
                    }
                }

                paramMap = ToolUtil.updateTimeForParameterMap(paramMap, beginSeconds, endSeconds);
                String timeZone = (String) paramMap.get("timeZone");
                int dataDelay = (int) paramMap.get("dataDelay");

                boolean isWait = ToolUtil.isWaitXMins(paramMap, timeZone, dataDelay);
                if (!isWait) {
                    String baseUrl = (String) paramMap.get("baseUrl");
                    orderService.insertOrder4G1(paramMap, baseUrl, null, false , taskId);
                }
            }
        } catch (Exception ex) {
            log.error("Fail to parse order json" , ex);
        }
    }
}
