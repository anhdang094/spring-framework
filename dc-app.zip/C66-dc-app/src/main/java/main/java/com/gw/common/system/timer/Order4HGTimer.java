package main.java.com.gw.common.system.timer;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.redis.Rlock;
import main.java.com.gw.common.system.redis.TaskLock;
import main.java.com.gw.datacenter.allocation.entity.AllocationEntity;
import org.apache.commons.lang3.StringUtils;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.MDC;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Slf4j
public class Order4HGTimer extends AllAbstractTimer {

    @Override
    public void execute(JobExecutionContext arg0) throws JobExecutionException {
        MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
        log.info(arg0.toString());
        JobDataMap jobDataMap = arg0.getJobDetail().getJobDataMap();
        String taskId = jobDataMap.getString("taskId");
        log.info("--DC定时任务日志-TaskID-{}-",taskId);
        try(Rlock lock = TaskLock.tryAcquireLock(taskId)) {
            if (lock.getLock()) {
                long endSeconds = 0L;
                long beginSeconds = 0L;

                Map<String, Object> parameterMap = new HashMap<>();
                List<AllocationEntity> allocationEntityList = allocationDao.getAllocationList(new String[]{taskId});
                if (!StringUtils.isBlank(taskId)) {
                    Integer taskInteger = Integer.valueOf(taskId);
                    if (allocationEntityList != null && allocationEntityList.size() > 0) {
                        for (AllocationEntity allocationEntity : allocationEntityList) {
                            if (taskInteger.equals(allocationEntity.getTaskId())) {
                                String beginTime = DateUtil.formatDate2Str(allocationEntity.getTaskBeginTime());
                                String endTime = DateUtil.formatDate2Str(allocationEntity.getTaskEndTime());
                                parameterMap.put("begintime", beginTime);
                                parameterMap.put("endtime", endTime);
                                parameterMap.put("num", String.valueOf(allocationEntity.getPageSize()));
                                parameterMap.put(UtilConstants.GLOBAL_PLATFORMID_KEY, allocationEntity.getPlatformId());
                                parameterMap.put("agcode", allocationEntity.getProductionId());
                                parameterMap.put("productId", allocationEntity.getProductionId());
                                parameterMap.put("website", allocationEntity.getWebSite());
                                parameterMap.put("username", allocationEntity.getAccountName());
                                parameterMap.put("password", allocationEntity.getPassword());
                                parameterMap.put("UserId", UtilConstants.BLANK);
                                parameterMap.put("page", "1");
                                parameterMap.put("baseUrl", allocationEntity.getUrl());
                                beginSeconds = allocationEntity.getIncrementBegintime();
                                endSeconds = allocationEntity.getIncrementEndtime();
                                parameterMap.put("timeZone", allocationEntity.getTimeZone());
                                parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                                parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                                parameterMap.put("endSeconds", String.valueOf(endSeconds));
                                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                                parameterMap.put("currency", allocationEntity.getCurrency() == null ? "CNY" : allocationEntity.getCurrency());//获取币种类型
                            }
                        }
                    }
                }
                parameterMap = ToolUtil.updateTimeForBBINParameterMap(parameterMap, beginSeconds, endSeconds);

                String timeZone = (String) parameterMap.get("timeZone");
                int dataDelay = (int) parameterMap.get("dataDelay");
                //boolean isWait = ToolUtil.isWait10Mins(parameterMap);
                boolean isWait = ToolUtil.isWaitXMins(parameterMap, timeZone, dataDelay);
                if (!isWait) {
                    String baseUrl = (String) parameterMap.get("baseUrl");
                    orderService.insertOrder4HoGame(parameterMap, baseUrl, null, false , taskId);
                }
            }
        } catch (Exception ex) {
            log.error("Fail to parse order xml:" + ex.getMessage(), ex);
        }
        log.debug("Excuting Order Timer - end.");


    }
}
