package main.java.com.gw.common.system.timer;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.redis.Rlock;
import main.java.com.gw.common.system.redis.TaskLock;
import main.java.com.gw.datacenter.allocation.entity.AllocationEntity;
import org.apache.commons.lang3.StringUtils;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.MDC;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * LC抓注单、额度定时任务
 */
@Slf4j
@SuppressWarnings("deprecation")
public class Order4LCTimer extends AllAbstractTimer {

    @Override
    @SuppressWarnings("unchecked")
    public void execute(JobExecutionContext arg0) throws JobExecutionException {
        MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
        JobDataMap jobDataMap = arg0.getJobDetail().getJobDataMap();
        String taskId = jobDataMap.getString("taskId");
        log.info("--DC定时任务日志-TaskID-{}-",taskId);
        try(Rlock lock = TaskLock.tryAcquireLock(taskId)) {
            if (lock.getLock()) {
                long endSeconds = 0L;
                long beginSeconds = 0L;
                String collectionType = null;
                Map<String, Object> parameterMap = new HashMap<>();
                List<AllocationEntity> allocationEntityList = allocationDao.getAllocationList(new String[]{taskId});
                if (!StringUtils.isBlank(taskId)) {
                    Integer id = Integer.parseInt(taskId);
                    if (allocationEntityList != null && allocationEntityList.size() > 0) {
                        for (AllocationEntity allocationEntity : allocationEntityList) {
                            if (id.equals(allocationEntity.getTaskId())) {
                                collectionType = allocationEntity.getAgCode();
                                parameterMap.put(UtilConstants.ORDER_BEGIN_TIME, DateUtil.formatDate2Str(allocationEntity.getTaskBeginTime()));
                                parameterMap.put(UtilConstants.ORDER_END_TIME, DateUtil.formatDate2Str(allocationEntity.getTaskEndTime()));
                                parameterMap.put(UtilConstants.NSS_TIMEZONE, allocationEntity.getTimeZone());
                                parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                                parameterMap.put(UtilConstants.ORDER_BASE_URL, allocationEntity.getUrl());
                                beginSeconds = allocationEntity.getIncrementBegintime();
                                endSeconds = allocationEntity.getIncrementEndtime();
                                parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                                parameterMap.put("endSeconds", String.valueOf(endSeconds));
                                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                                parameterMap.put("collectionType", collectionType);
                                parameterMap.put(UtilConstants.GLOBAL_PRODUCTID_KEY, allocationEntity.getProductionId());
                                parameterMap.put("password", allocationEntity.getPassword());
                                //下面这些参数在normallog里要用
                                parameterMap.put(UtilConstants.ORDER_PAGE_NUMBER, "20");
                                parameterMap.put(UtilConstants.ORDER_AG_CODE, collectionType);
                                parameterMap.put(UtilConstants.ORDER_BBIN_GAMEKIND, allocationEntity.getGameKind());
                                parameterMap.put(UtilConstants.ORDER_BBIN_MODEL, "");
                                parameterMap.put(UtilConstants.ACCOUNT_TRANSFER_PLATFORMID, allocationEntity.getPlatformId());
                                parameterMap.put("currency", allocationEntity.getCurrency() == null ? "CNY" : allocationEntity.getCurrency());//获取币种类型
                            }
                        }
                    }
                }
                parameterMap = ToolUtil.updateTimeForBBINParameterMap(parameterMap, beginSeconds, endSeconds);

                String timeZone = (String) parameterMap.get("timeZone");
                int dataDelay = (int) parameterMap.get("dataDelay");
                boolean isWait = ToolUtil.isWaitXMins(parameterMap, timeZone, dataDelay);
                if (!isWait) {
                    orderService.insertRecord4LC(parameterMap, false, null , taskId);
                }
            }
        } catch (Exception ex) {
            log.error("Fail to parse PB data:" + ex.getMessage(), ex);
        }
    }

}
