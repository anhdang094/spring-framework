package main.java.com.gw.common.system.timer;

import com.google.gson.Gson;
import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.redis.Rlock;
import main.java.com.gw.common.system.redis.TaskLock;
import main.java.com.gw.datacenter.allocation.entity.AllocationEntity;
import org.apache.commons.lang3.StringUtils;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.MDC;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Slf4j
@SuppressWarnings("deprecation")
public class Order4PTTimer extends AllAbstractTimer {

    @Override
    public void execute(JobExecutionContext arg0) throws JobExecutionException {
        MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
        log.info(arg0.toString());
        JobDataMap jobDataMap = arg0.getJobDetail().getJobDataMap();
        String taskId = jobDataMap.getString("taskId");
        log.info("--DC定时任务日志-TaskID-{}-",taskId);
        try(Rlock lock = TaskLock.tryAcquireLock(taskId)) {
            if (lock.getLock()) {
                long endSeconds = 0L;
                long beginSeconds = 0L;

                Map<String, Object> parameterMap = new HashMap<String, Object>();
                List<AllocationEntity> allocationEntityList = allocationDao.getAllocationList(new String[]{taskId});
                if (!StringUtils.isBlank(taskId)) {
                    Integer taskInteger = Integer.valueOf(taskId);
                    if (allocationEntityList != null && allocationEntityList.size() > 0) {
                        for (AllocationEntity allocationEntity : allocationEntityList) {
                            if (taskInteger.equals(allocationEntity.getTaskId())) {
                                parameterMap.put("num", String.valueOf(allocationEntity.getPageSize()));
                                parameterMap.put("platformid", allocationEntity.getPlatformId());
                                parameterMap.put("agcode", allocationEntity.getAgCode());
                                parameterMap.put("productId", allocationEntity.getProductionId());
                                parameterMap.put("website", allocationEntity.getWebSite());
                                parameterMap.put("model", allocationEntity.getModel());
                                parameterMap.put("gamekind", allocationEntity.getGameKind());
                                parameterMap.put("username", allocationEntity.getAccountName());
                                parameterMap.put("password", allocationEntity.getPassword());
                                parameterMap.put("c07password", allocationEntity.getOrderField()); // C07 使用越南盾，所以证书和密码跟其他产品不一样，该字段单独存C07的密码    add by Miles on 2016-07-09
                                parameterMap.put("baseUrl", allocationEntity.getUrl());
                                parameterMap.put("page", "1");
                                parameterMap.put("timeZone", allocationEntity.getTimeZone());
                                parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                                beginSeconds = allocationEntity.getIncrementBegintime();
                                endSeconds = allocationEntity.getIncrementEndtime();
                                parameterMap.put("begintime", DateUtil.formatDate2Str(allocationEntity.getTaskBeginTime()));
                                parameterMap.put("endtime", DateUtil.formatDate2Str(allocationEntity.getTaskEndTime()));
                                parameterMap.put("beginSeconds", beginSeconds);
                                parameterMap.put("endSeconds", endSeconds);
                                parameterMap.put("timeZone", allocationEntity.getTimeZone());
                                parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                                parameterMap.put("currency", allocationEntity.getCurrency() == null ? "CNY" : allocationEntity.getCurrency());//获取币种类型
                            }
                        }
                    }
                }
                parameterMap = ToolUtil.updateTimeForBBINParameterMap(parameterMap, beginSeconds, endSeconds);

                String timeZone = (String) parameterMap.get("timeZone");
                int dataDelay = (int) parameterMap.get("dataDelay");
                // boolean isWait = ToolUtil.isWait2Mins4BeiJingTimeZone(parameterMap);
                boolean isWait = ToolUtil.isWaitXMins(parameterMap, timeZone, dataDelay);
                if (!isWait) {
                    log.info("--DC定时任务日志-Process-TaskID-{}-parameterMap-{}",taskId,new Gson().toJson(parameterMap));
                    String baseUrl = (String) parameterMap.get("baseUrl");
                    orderService.insertOrder4PT(parameterMap, baseUrl, null, false , taskId);
                }
            }
        } catch (Exception ex) {
            log.error("Fail to insert PT order:" + ex.getMessage(), ex);
        }
        log.debug("Excuting PT Order Timer - end.");
    }
}
