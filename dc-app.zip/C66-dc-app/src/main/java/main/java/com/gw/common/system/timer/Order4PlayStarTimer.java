package main.java.com.gw.common.system.timer;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.redis.Rlock;
import main.java.com.gw.common.system.redis.TaskLock;
import main.java.com.gw.datacenter.allocation.entity.AllocationEntity;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.MDC;
import org.springframework.util.StringUtils;

import java.util.*;

@Slf4j
public class Order4PlayStarTimer extends AllAbstractTimer {
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
        log.info(context.toString());
        JobDataMap jobDataMap = context.getJobDetail().getJobDataMap();
        String taskId = jobDataMap.getString("taskId");
        log.info("--DC定时任务日志-TaskID-{}-",taskId);
        try(Rlock lock = TaskLock.tryAcquireLock(taskId)) {
            if (lock.getLock()) {
                if(!StringUtils.isEmpty(taskId)) {
                    Map<String, Object> parameterMap = new HashMap<String, Object>();
                    //获取定时任务
                    AllocationEntity allocationEntity = allocationDao.getAllocationById(taskId);
                    if(allocationEntity!=null) {
                        DateTimeFormatter dateTimeFormatter = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss");
                        DateTimeFormatter dateTimeFormatter2 = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");
                        parameterMap.put("begintime", new DateTime(allocationEntity.getTaskEndTime()).toString(dateTimeFormatter2));
                        parameterMap.put("endtime", new DateTime(allocationEntity.getTaskEndTime()).plusMillis(allocationEntity.getIncrementEndtime()).toString(dateTimeFormatter2));
                        parameterMap.put("num", String.valueOf(allocationEntity.getPageSize()));
                        parameterMap.put("platformid", allocationEntity.getPlatformId());
                        parameterMap.put("agcode", allocationEntity.getProductionId());
                        parameterMap.put("productId", allocationEntity.getProductionId());
                        parameterMap.put("website", allocationEntity.getWebSite());
                        parameterMap.put("model", allocationEntity.getModel());
                        parameterMap.put("gamekind", allocationEntity.getGameKind());
                        parameterMap.put("username", allocationEntity.getAccountName());
                        parameterMap.put("password", allocationEntity.getPassword());
                        parameterMap.put("gameCode", allocationEntity.getGameCode());//PNG 5     PNG VIP 85
                        parameterMap.put("timeZone", allocationEntity.getTimeZone());
                        parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                        parameterMap.put("baseUrl", allocationEntity.getUrl());
                        parameterMap.put("beginSeconds", String.valueOf(allocationEntity.getIncrementBegintime()));
                        parameterMap.put("endSeconds", String.valueOf(allocationEntity.getIncrementEndtime()));
                        parameterMap.put("currency", allocationEntity.getCurrency() == null ? "CNY" : allocationEntity.getCurrency());//获取币种类型
                        parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());

                        //这个动作是为了设置map中的开始时间和结束时间.配置成本次去拉取厅方的时间段,是通过开始增量时间,和结束增量时间实现的.
                        parameterMap.put("psStart", new DateTime(allocationEntity.getTaskEndTime()).toString(dateTimeFormatter));
                        parameterMap.put("psEnd", new DateTime(allocationEntity.getTaskEndTime()).plusMillis(allocationEntity.getIncrementEndtime()).toString(dateTimeFormatter));
                        //判断上个动作设置抓取注单的结束时间,是不是在当前时间之前,如果在才开始.
                        boolean isWait = ToolUtil.isWaitXMins((String)parameterMap.get("endtime"), (String) parameterMap.get("timeZone"), (int) parameterMap.get("dataDelay"));
                        if (!isWait) {
                            orderService.insertOrder4PlayStar(allocationEntity,null,parameterMap,false , taskId);
                        }
                    }
                }
            }
        }catch (Exception ex) {
            log.error("executre PlayStar order:" + ex.getMessage(), ex);
        }
    }

    public static void main(String[] args) {
        JSONObject json = new JSONObject();
        json.put("2012",Arrays.asList("2","2"));
        json.put("2022",Arrays.asList("3","3"));

        System.out.println(json.toJSONString());
        Iterator<String> iterator = json.keySet().iterator();
       while (iterator.hasNext()){
           JSONArray a = json.getJSONArray(iterator.next());
           for(int i=0;i<a.size();i++) {
               System.out.println(a.getString(i));
           }
       }
       String startTime = "2020-02-22 11:11:11";
       DateTimeFormatter dateTimeFormatter = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss");
       System.out.println(new DateTime().toString(dateTimeFormatter));

       Date d = DateUtil.parse(startTime,"yyyy-MM-dd'T'HH:mm:ss");
        System.out.println(d);
    }
}
