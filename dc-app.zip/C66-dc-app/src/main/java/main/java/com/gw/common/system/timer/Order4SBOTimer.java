package main.java.com.gw.common.system.timer;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.redis.Rlock;
import main.java.com.gw.common.system.redis.TaskLock;
import main.java.com.gw.datacenter.allocation.entity.AllocationEntity;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.MDC;

import java.util.*;

@Slf4j
public class Order4SBOTimer extends AllAbstractTimer {

    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
        JobDataMap jobDataMap = context.getJobDetail().getJobDataMap();
        String taskId = jobDataMap.getString("taskId");
        log.info("--DC定时任务日志-TaskID-{}-",taskId);
        try(Rlock lock = TaskLock.tryAcquireLock(taskId)) {
            if (lock.getLock()) {
                long endSeconds = 0L;
                long beginSeconds = 0L;
                Map<String, Object> parameterMap = new HashMap<>();
                List<AllocationEntity> allocationEntityList = allocationDao.getAllocationList(new String[]{taskId});
                if (!StringUtils.isBlank(taskId)) {
                    Integer taskInteger = Integer.valueOf(taskId);
                    if (allocationEntityList != null && allocationEntityList.size() > 0) {
                        for (AllocationEntity allocationEntity : allocationEntityList) {
                            if (taskInteger.equals(allocationEntity.getTaskId())) {
                                String beginTime = DateUtil.formatDate2Str(allocationEntity.getTaskBeginTime());
                                String endTime = DateUtil.formatDate2Str(allocationEntity.getTaskEndTime());
                                parameterMap.put("begintime", beginTime);
                                parameterMap.put("endtime", endTime);
                                parameterMap.put("num", String.valueOf(allocationEntity.getPageSize()));
                                parameterMap.put(UtilConstants.GLOBAL_PLATFORMID_KEY, allocationEntity.getPlatformId());
                                parameterMap.put("agcode", allocationEntity.getAgCode());
                                parameterMap.put("productId", allocationEntity.getProductionId());
                                parameterMap.put("model", allocationEntity.getModel());
                                parameterMap.put("remark", allocationEntity.getRemark());
                                parameterMap.put(UtilConstants.ALLOCATION_WEBSITE, allocationEntity.getWebSite());
                                parameterMap.put("gamekind", allocationEntity.getGameKind());
                                parameterMap.put("username", allocationEntity.getAccountName());
                                parameterMap.put("password", allocationEntity.getPassword());
                                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                                parameterMap.put("baseUrl", allocationEntity.getUrl());
                                beginSeconds = allocationEntity.getIncrementBegintime();
                                endSeconds = allocationEntity.getIncrementEndtime();
                                parameterMap.put("timeZone", allocationEntity.getTimeZone());
                                parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                                parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                                parameterMap.put("endSeconds", String.valueOf(endSeconds));
                                parameterMap.put("allocation", allocationEntity);
                                parameterMap.put("currency", allocationEntity.getCurrency() == null ? "CNY" : allocationEntity.getCurrency());//获取币种类型
                                //用于区分定时任务；0标识抓未结算，1标识抓已结算
                                parameterMap.put("action",allocationEntity.getAction());
                            }
                        }
                    }
                }
                parameterMap = ToolUtil.updateTimeForParameterMap(parameterMap, beginSeconds, endSeconds);
                String timeZone = (String) parameterMap.get("timeZone");
                int dataDelay = (int) parameterMap.get("dataDelay");
                //当前时间大于（定时任务的结束时间+间隔时间），所以isWait为false
                boolean isWait = ToolUtil.isWaitXMins(parameterMap, timeZone, dataDelay);
                if (!isWait) {
                    orderService.insertRecord4SBO(parameterMap, false, null , taskId);
                }
            }
        } catch (Exception ex) {
            log.error("Fail to parse SBO order xml:" + ex.getMessage(), ex);
        }
    }
}
