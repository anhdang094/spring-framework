package main.java.com.gw.common.system.timer;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.redis.Rlock;
import main.java.com.gw.common.system.redis.TaskLock;
import main.java.com.gw.datacenter.allocation.entity.AllocationEntity;
import org.apache.commons.lang3.StringUtils;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.MDC;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Slf4j
public class Order4TPGTimer extends AllAbstractTimer {
    @Override
    public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
        log.info(jobExecutionContext.toString());
        JobDataMap jobDataMap = jobExecutionContext.getJobDetail().getJobDataMap();
        String taskId = jobDataMap.getString("taskId");
        log.info("--DC定时任务日志-TaskID-{}-", taskId);
        try (Rlock lock = TaskLock.tryAcquireLock(taskId)) {
            if (lock.getLock()) {
                long endSecondsIncrement = 0L;
                long beginSecondsIncrement = 0L;
                String orderDataTimeZone = "Etc/GMT-8";
                int orderDataDelay = 0;

                Map<String, Object> parameterMap = new HashMap<>();
                List<AllocationEntity> allocationEntityList = allocationDao.getAllocationList(new String[]{taskId});
                if (StringUtils.isNotBlank(taskId)) {
                    Integer taskInteger = Integer.valueOf(taskId);
                    if (allocationEntityList != null && !allocationEntityList.isEmpty()) {
                        for (AllocationEntity allocationEntity : allocationEntityList) {
                            if (taskInteger.equals(allocationEntity.getTaskId())) {
                                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());

                                parameterMap.put(UtilConstants.ORDER_BEGIN_TIME, DateUtil.formatDate2Str(allocationEntity.getTaskBeginTime()));
                                parameterMap.put(UtilConstants.ORDER_END_TIME, DateUtil.formatDate2Str(allocationEntity.getTaskEndTime()));

                                parameterMap.put(UtilConstants.ORDER_BASE_URL, allocationEntity.getUrl());
                                parameterMap.put(UtilConstants.ORDER_AG_CODE, allocationEntity.getAgCode());
                                parameterMap.put(UtilConstants.ORDER_PAGE_NUMBER, allocationEntity.getPageSize());

                                parameterMap.put(UtilConstants.GLOBAL_PLATFORMID_KEY, allocationEntity.getPlatformId());
                                parameterMap.put(UtilConstants.GLOBAL_PRODUCTID_KEY, allocationEntity.getProductionId());

                                endSecondsIncrement = allocationEntity.getIncrementEndtime();
                                beginSecondsIncrement = allocationEntity.getIncrementBegintime();
                                orderDataTimeZone = allocationEntity.getTimeZone();
                                orderDataDelay = allocationEntity.getDataDelay();
                                break;
                            }
                        }
                    }
                }
                parameterMap = ToolUtil.updateTimeForBBINParameterMap(parameterMap, beginSecondsIncrement, endSecondsIncrement);

                if (!ToolUtil.isWaitXMins(parameterMap, orderDataTimeZone, orderDataDelay)) {
                    String baseUrl = (String) parameterMap.get(UtilConstants.ORDER_BASE_URL);
                    orderService.insertOrder4TPG(parameterMap, baseUrl, null, false, taskId);
                }
            }
        } catch (Exception ex) {
            log.error("Fail to insert Micro Gaming order:" + ex.getMessage(), ex);
        }
        log.debug("Executing Order Timer - end.");
    }
}