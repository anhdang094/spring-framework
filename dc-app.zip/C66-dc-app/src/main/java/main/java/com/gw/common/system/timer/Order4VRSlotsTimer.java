package main.java.com.gw.common.system.timer;

import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.redis.Rlock;
import main.java.com.gw.common.system.redis.TaskLock;
import main.java.com.gw.datacenter.allocation.entity.AllocationEntity;
import org.apache.commons.lang3.StringUtils;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Description: VR电游注单抓取
 * @Author: Hopkin
 * @Date: 2019/6/25 15:09
 * @Version: 1.0
 */

@Slf4j
public class Order4VRSlotsTimer extends AllAbstractTimer{
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        log.info(context.toString());

        JobDataMap jobDataMap = context.getJobDetail().getJobDataMap();
        String taskId = jobDataMap.getString("taskId");
        log.info("--DC定时任务日志-TaskID-{}-",taskId);
        try(Rlock lock = TaskLock.tryAcquireLock(taskId)){
            if(lock.getLock()){
                long beginSeconds = 0L;
                long endSeconds = 0L;

                Map<String,Object> paramMap = new HashMap<>();

                /* 查询任务配置表获取该任务的信息 */
                List<AllocationEntity> allocationEntityList = allocationDao.getAllocationList(new String[] {taskId});

                if(StringUtils.isNotBlank(taskId)){
                    Integer taskInteger = Integer.parseInt(taskId);

                    if(allocationEntityList != null && !allocationEntityList.isEmpty()){
                        for(AllocationEntity entity:allocationEntityList){
                            if(taskInteger.equals(entity.getTaskId())){
                                String starTime = DateUtil.formatDate2Str(entity.getTaskBeginTime(),"yyyy-MM-dd'T'HH:mm:ss'Z'");
                                String endTime = DateUtil.formatDate2Str(entity.getTaskEndTime(),"yyyy-MM-dd'T'HH:mm:ss'Z'");
                                paramMap.put("startTime", starTime);
                                paramMap.put("endTime", endTime);
                                paramMap.put(UtilConstants.ORDER_TASK_ID, entity.getTaskId());

                                String begin_time = DateUtil.formatDate2Str(entity.getTaskBeginTime());
                                String end_time = DateUtil.formatDate2Str(entity.getTaskEndTime());
                                paramMap.put("begintime", begin_time);
                                paramMap.put("endtime", end_time);

                                beginSeconds = entity.getIncrementBegintime();
                                endSeconds = entity.getIncrementEndtime();

                                paramMap.put("beginSeconds", String.valueOf(beginSeconds));
                                paramMap.put("endSeconds", String.valueOf(endSeconds));

                                paramMap.put("timeZone", entity.getTimeZone());
                                paramMap.put("dataDelay", entity.getDataDelay());
                                paramMap.put("baseUrl", entity.getUrl());
                                paramMap.put("platformid", entity.getPlatformId());
                                paramMap.put("productId", entity.getProductionId());
                                paramMap.put("currency", entity.getCurrency() == null ? "CNY" : entity.getCurrency());
                                paramMap.put("type",entity.getPlayType());
                                paramMap.put("version",entity.getOrderField());
                                paramMap.put("id",entity.getOrderWay());
                                paramMap.put("cryptKey",entity.getAccountName());
                            }
                        }
                    }
                }

                paramMap = ToolUtil.updateTimeForParameterMap(paramMap, beginSeconds, endSeconds);
                String timeZone = (String) paramMap.get("timeZone");
                int dataDelay = (int) paramMap.get("dataDelay");

                boolean isWait = ToolUtil.isWaitXMins(paramMap, timeZone, dataDelay);
                if (!isWait) {
                    String baseUrl = (String) paramMap.get("baseUrl");
                    orderService.insertOrder4VRSlots(paramMap, baseUrl, null, false , taskId);
                }
            }
        }catch (Exception ex) {
            log.error("Fail to parse order json:" + ex.getMessage(), ex);
        }
    }
}
