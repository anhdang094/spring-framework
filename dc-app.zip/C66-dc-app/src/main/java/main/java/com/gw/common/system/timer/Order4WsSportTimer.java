package main.java.com.gw.common.system.timer;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.redis.Rlock;
import main.java.com.gw.common.system.redis.TaskLock;
import main.java.com.gw.datacenter.allocation.entity.AllocationEntity;
import org.apache.commons.lang3.StringUtils;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.MDC;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Slf4j
public class Order4WsSportTimer extends AllAbstractTimer {

    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
        log.info(context.toString());
        JobDataMap jobDataMap = context.getJobDetail().getJobDataMap();
        String taskId = jobDataMap.getString("taskId");
        log.info("--DC定时任务日志-TaskID-{}-",taskId);
        try(Rlock lock = TaskLock.tryAcquireLock(taskId)) {
            if (lock.getLock()) {
                long endSeconds = 0L;
                long beginSeconds = 0L;

                Map<String, Object> parameterMap = new HashMap<String, Object>();
                List<AllocationEntity> allocationEntityList = allocationDao.getAllocationList(new String[]{taskId});
                if (!StringUtils.isBlank(taskId)) {
                    Integer taskInteger = Integer.valueOf(taskId);
                    if (allocationEntityList != null && allocationEntityList.size() > 0) {
                        for (AllocationEntity allocationEntity : allocationEntityList) {
                            if (taskInteger.equals(allocationEntity.getTaskId())) {
                                //相关参数拼装
                                String beginTime = DateUtil.formatDate2Str(allocationEntity.getTaskBeginTime());
                                String endTime = DateUtil.formatDate2Str(allocationEntity.getTaskEndTime());
                                parameterMap.put("begintime", beginTime);
                                parameterMap.put("endtime", endTime);
                                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                                parameterMap.put("timeZone", allocationEntity.getTimeZone());
                                parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                                beginSeconds = allocationEntity.getIncrementBegintime();
                                endSeconds = allocationEntity.getIncrementEndtime();
                                parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                                parameterMap.put("endSeconds", String.valueOf(endSeconds));
                                parameterMap.put("allocation", allocationEntity);
                                parameterMap.put("baseUrl", allocationEntity.getUrl());
                                parameterMap.put("num", String.valueOf(allocationEntity.getPageSize()));
                                parameterMap.put("productId", allocationEntity.getProductionId());
                                parameterMap.put("username", allocationEntity.getAccountName());//
                                parameterMap.put("password", allocationEntity.getPassword());
                                parameterMap.put("currency", allocationEntity.getCurrency() == null ? "CNY" : allocationEntity.getCurrency());//获取币种类型

                            }
                        }
                    }
                }
                //将 begintime  endtime加上查询的时间增量
                parameterMap = ToolUtil.updateTimeForParameterMap(parameterMap, beginSeconds, endSeconds);

                String timeZone = (String) parameterMap.get("timeZone");
                int dataDelay = (int) parameterMap.get("dataDelay");
                //判断 当前任务 是否可以执行： 数据查询的时间段 是否小于当前时间
                boolean isWait = ToolUtil.isWaitXMins(parameterMap, timeZone, dataDelay);
                if (!isWait) {
                    String baseUrl = (String) parameterMap.get("baseUrl");
                    orderService.insertOrder4WsSport(parameterMap, baseUrl, null, false , taskId);
                }
            }
        } catch (Exception ex) {
            log.error("-WsSport定时任务执行失败-detail-{}" , ex);
        }
    }
}	
