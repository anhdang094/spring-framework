package main.java.com.gw.common.system.timer;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.redis.Rlock;
import main.java.com.gw.common.system.redis.TaskLock;
import main.java.com.gw.datacenter.allocation.entity.AllocationEntity;
import org.apache.commons.lang3.StringUtils;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.MDC;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * MG注单
 */
@Slf4j
@SuppressWarnings("deprecation")
public class Order4XDJTimer extends AllAbstractTimer {

    @Override
    public void execute(JobExecutionContext arg0) throws JobExecutionException {
        MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
        log.info(arg0.toString());
        JobDataMap jobDataMap = arg0.getJobDetail().getJobDataMap();
        String taskId = jobDataMap.getString("taskId");
        log.info("--DC定时任务日志-TaskID-{}-",taskId);
        try(Rlock lock = TaskLock.tryAcquireLock(taskId)) {
            if (lock.getLock()) {
                long endSeconds = 0L;
                long beginSeconds = 0L;

                Map<String, Object> parameterMap = new HashMap<>();
                List<AllocationEntity> allocationEntityList = allocationDao.getAllocationList(new String[]{taskId});
                if (!StringUtils.isBlank(taskId)) {
                    Integer taskInteger = Integer.valueOf(taskId);
                    if (allocationEntityList != null && allocationEntityList.size() > 0) {
                        for (AllocationEntity allocationEntity : allocationEntityList) {
                            if (taskInteger.equals(allocationEntity.getTaskId())) {
                                parameterMap.put("begintime", DateUtil.formatDate2Str(allocationEntity.getTaskBeginTime()));
                                parameterMap.put("endtime", DateUtil.formatDate2Str(allocationEntity.getTaskEndTime()));
                                parameterMap.put("num", String.valueOf(allocationEntity.getPageSize()));
                                parameterMap.put("platformid", allocationEntity.getPlatformId());
                                parameterMap.put("agcode", allocationEntity.getProductionId());
                                parameterMap.put("productId", allocationEntity.getProductionId());
                                parameterMap.put("website", allocationEntity.getWebSite());
                                parameterMap.put("model", allocationEntity.getModel());
                                parameterMap.put("gamekind", allocationEntity.getGameKind());
                                parameterMap.put("username", allocationEntity.getAccountName());
                                parameterMap.put("password", allocationEntity.getPassword());
                                parameterMap.put("gameCode", allocationEntity.getGameCode());//MG:2,MGVIP:82
                                parameterMap.put("timeZone", allocationEntity.getTimeZone());
                                parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                                parameterMap.put("baseUrl", allocationEntity.getUrl());
                                beginSeconds = allocationEntity.getIncrementBegintime();
                                endSeconds = allocationEntity.getIncrementEndtime();
                                parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                                parameterMap.put("endSeconds", String.valueOf(endSeconds));
                                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                                parameterMap.put("remark", allocationEntity.getRemark());
                                parameterMap.put("currency", allocationEntity.getCurrency() == null ? "CNY" : allocationEntity.getCurrency());//获取币种类型
                            }
                        }
                    }
                }

                String timeZone = (String) parameterMap.get("timeZone");
                int dataDelay = (int) parameterMap.get("dataDelay");
                parameterMap = ToolUtil.updateTimeForK8SbtParameterMap(parameterMap, beginSeconds, endSeconds);
                boolean isWait = ToolUtil.isWaitXMins(parameterMap, timeZone, dataDelay);
                if (!isWait) {
                    String baseUrl = (String) parameterMap.get("baseUrl");
                    orderService.insertOrder4XDJ(parameterMap, baseUrl, null, false , taskId);
                }
            }
        } catch (Exception ex) {
            log.error("Fail to insert XDJ order:" + ex.getMessage(), ex);
        } finally {
            // jobDataMap.put("parameterMap",parameterMap);
        }
        log.debug("Excuting Order Timer - end.");
    }
}	
