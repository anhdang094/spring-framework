package main.java.com.gw.common.system.timer;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.redis.Rlock;
import main.java.com.gw.common.system.redis.TaskLock;
import main.java.com.gw.datacenter.allocation.entity.AllocationEntity;
import org.apache.commons.lang3.StringUtils;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.MDC;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @Description: YSB抓注单定时任务
 * @Author: twAllen.c
 * @Date: 2018/4/16 12:00
 */
@Slf4j
public class Order4YSBTimer extends AllAbstractTimer {

    @Override
    public void execute(JobExecutionContext arg0) throws JobExecutionException {
        MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
        log.info("Enter Order4YSBTimer.execute()");
        log.info(arg0.toString());
        JobDataMap jobDataMap = arg0.getJobDetail().getJobDataMap();
        String taskId = jobDataMap.getString("taskId");
        log.info("--DC定时任务日志-TaskID-{}-",taskId);
        try(Rlock lock = TaskLock.tryAcquireLock(taskId)) {
            if (lock.getLock()) {
                long endSeconds = 0L;
                long beginSeconds = 0L;

                Map<String, Object> parameterMap = new HashMap<String, Object>();
                List<AllocationEntity> allocationEntityList = allocationDao.getAllocationList(new String[]{taskId});
                if (!StringUtils.isBlank(taskId)) {
                    Integer taskInteger = Integer.valueOf(taskId);
                    if (allocationEntityList != null && allocationEntityList.size() > 0) {
                        AllocationEntity allocationEntity = allocationEntityList.get(0);
                        if (allocationEntity != null && taskInteger.equals(allocationEntity.getTaskId())) {
                            parameterMap.put("begintime", DateUtil.formatDate2Str(allocationEntity.getTaskBeginTime()));
                            //CW_dc的参数判断中有个奇怪的判断，不是NT厅必须有starttime，所以在这里把begintime复制一遍。
                            parameterMap.put("starttime", parameterMap.get("begintime"));
                            parameterMap.put("endtime", DateUtil.formatDate2Str(allocationEntity.getTaskEndTime()));
                            parameterMap.put("num", String.valueOf(allocationEntity.getPageSize()));
                            parameterMap.put("platformid", allocationEntity.getPlatformId());
                            parameterMap.put("agcode", allocationEntity.getProductionId());
                            parameterMap.put("productId", allocationEntity.getProductionId());
                            parameterMap.put("website", allocationEntity.getWebSite());
                            parameterMap.put("model", allocationEntity.getModel());
                            parameterMap.put("gamekind", allocationEntity.getGameKind());
                            parameterMap.put("username", allocationEntity.getAccountName());
                            parameterMap.put("password", allocationEntity.getPassword());
                            parameterMap.put("gameCode", allocationEntity.getGameCode());
                            parameterMap.put("timeZone", allocationEntity.getTimeZone());
                            parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                            parameterMap.put("baseUrl", allocationEntity.getUrl());
                            beginSeconds = allocationEntity.getIncrementBegintime();
                            endSeconds = allocationEntity.getIncrementEndtime();
                            parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                            parameterMap.put("endSeconds", String.valueOf(endSeconds));
                            parameterMap.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                            parameterMap.put("key", "123456");//key可以随意赋值，CW_dc只做了非空判断
                            parameterMap.put("currency", allocationEntity.getCurrency() == null ? "CNY" : allocationEntity.getCurrency());//获取币种类型
                            log.info("Order4YSBTimer.execute(), Get the task:id=" + allocationEntity.getTaskId() + ",beginTime=" + allocationEntity.getTaskBeginTime() + ",endTime=" + allocationEntity.getTaskEndTime());
                        }
                    }
                }
                parameterMap = ToolUtil.updateTimeForParameterMap(parameterMap, beginSeconds, endSeconds);

                String timeZone = (String) parameterMap.get("timeZone");
                int dataDelay = (int) parameterMap.get("dataDelay");
                boolean isWait = ToolUtil.isWaitXMins(parameterMap, timeZone, dataDelay);
                log.info("Order4YSBTimer.execute()-isWait:" + isWait);
                if (!isWait) {
                    String baseUrl = (String) parameterMap.get("baseUrl");
                    log.info("Order4YSBTimer.execute-baseUrl:" + baseUrl);
                    orderService.insertOrder4YSB(parameterMap, baseUrl, null, false , taskId);
                }
            }
        } catch (Exception ex) {
            log.error("Fail to insert YSB order", ex);
        }
        log.info("Excuting Order4YSBTimer - end.");
    }
}	
