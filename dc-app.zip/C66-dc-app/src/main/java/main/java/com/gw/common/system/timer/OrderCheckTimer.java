package main.java.com.gw.common.system.timer;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.GetXmlByUrlUtil;
import main.java.com.gw.common.framework.util.SAXParseXml;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.redis.Rlock;
import main.java.com.gw.common.system.redis.TaskLock;
import main.java.com.gw.datacenter.allocation.entity.AllocationEntity;
import main.java.com.gw.datacenter.order.entity.OrderEntity;
import main.java.com.gw.datacenter.orderlog.entity.OrderLogEntity;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.MDC;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 检查注单丢失任务
 */
@Slf4j
public class OrderCheckTimer extends AllAbstractTimer {

    private static final String BEGIN_TIME = "beginTime";
    private static final String END_TIME = "endTime";

    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
        log.info("Excuting OrderCheckTimer.execute() - start.");
        JobDataMap jobDataMap = context.getJobDetail().getJobDataMap();
        String taskId = jobDataMap.getString("taskId");
        log.info("--DC定时任务日志-TaskID-{}-",taskId);
        int endIncrementSeconds;
        try(Rlock lock = TaskLock.tryAcquireLock(taskId)) {
            if (lock.getLock()) {
                Map<String, Object> parameterMap = new HashMap<>();
                AllocationEntity allocationEntity = allocationDao.getAllocationById(taskId);
                if (parameterMap.isEmpty()) {
                    parameterMap.put(BEGIN_TIME, DateUtil.formatDate2Str(allocationEntity.getTaskBeginTime()));
                    parameterMap.put(END_TIME, DateUtil.formatDate2Str(allocationEntity.getTaskEndTime()));
                    parameterMap.put("dataDelay", allocationEntity.getDataDelay());
                    parameterMap.put("timeZone", allocationEntity.getTimeZone());
                    parameterMap.put("beginSeconds", allocationEntity.getIncrementBegintime());
                    parameterMap.put("endSeconds", allocationEntity.getIncrementEndtime());
                }
                log.info(parameterMap.toString());
                endIncrementSeconds = (Integer) parameterMap.get("endSeconds");
                String timeZone = (String) parameterMap.get("timeZone");
                int dataDelay = (int) parameterMap.get("dataDelay");

                parameterMap = updateTimeForParameterMap(parameterMap, endIncrementSeconds);

                boolean isWait = ToolUtil.isWaitXMins((String) parameterMap.get(END_TIME), timeZone, dataDelay);
                if (isWait) {
                    log.info("上次检查结束时间与当前系统时间时间差少于等待时间，不执行任何操作结束退出");
                    return;
                }
                //需要重置的任务ID保存在代理编码字段里面
                String taskIds = allocationEntity.getAgCode();
                if (taskIds == null || taskIds.isEmpty()) {
                    log.error("重置的任务ID不能为空");
                    return;
                }
                log.info("taskIds=" + taskIds);
                String[] taskIdArray = taskIds.split(",");
                List<AllocationEntity> allocationList = allocationDao.getAllocationList(taskIdArray);
                log.info("allocationList.size=" + allocationList.size());
                List<String> orderIdList = new ArrayList<>();
                for (AllocationEntity entity : allocationList) {
                    String platformId = entity.getPlatformId();
                    log.info("platformId=" + platformId);
                    if (UtilConstants.ORDERS_AG.equals(platformId)) {
                        parameterMap.put("taskId", entity.getTaskId());
                        parameterMap.put("logType", 1);
                        //获取给定时间段所有执行成功的注单日志
                        List<OrderLogEntity> successOrderLogList = orderLogService.getSuccessOrderLogList(parameterMap);
                        log.info("successOrderLogList.size=" + successOrderLogList.size());
                        Map<String, Object> countOrderParams = new HashMap<>();
                        Map<String, Object> getOrdersParams = new HashMap<>();
                        for (OrderLogEntity logEntity : successOrderLogList) {
                            String beginTime = DateUtil.formatDate2Str(logEntity.getBeginTime());
                            String endTime = DateUtil.formatDate2Str(logEntity.getEndTime());
                            countOrderParams.put(BEGIN_TIME, beginTime);
                            countOrderParams.put(END_TIME, endTime);
                            //获取AGQJ注单表中给定时间段的数据
                            int count = orderService.getOrderCountByTime4AGQJ(countOrderParams);
                            log.info("从[" + beginTime + "]到[" + endTime + "],数据库中存在的AGQJ注单记录为" + count + "条");
                            getOrdersParams.put(UtilConstants.ORDER_BEGIN_TIME, beginTime);
                            getOrdersParams.put(UtilConstants.ORDER_END_TIME, endTime);
                            getOrdersParams.put(UtilConstants.ORDER_PAGE, "1");
                            getOrdersParams.put(UtilConstants.GLOBAL_PLATFORMID_KEY, platformId);
                            getOrdersParams.put("agcode", entity.getAgCode());
                            getOrdersParams.put("num", String.valueOf(entity.getPageSize()));
                            String baseUrl = logEntity.getUrl();
                            getOrdersParams.put("url", baseUrl);
                            log.info("baseUrl:" + baseUrl);
                            //调用厅方API，获取与上面相同时间段的注单数据
                            String xmlStr = GetXmlByUrlUtil.getXmlStream(baseUrl, getOrdersParams, UtilConstants.ENCODING_UTF8);
                            // Add interception to retrieve Response
                            if (ToolUtil.isNeedInterceptResponse(parameterMap.get(UtilConstants.ORDER_TASK_ID) + "")) {
                                log.info("Intercept:TaskId=" + parameterMap.get(UtilConstants.ORDER_TASK_ID) + ",Url=" + baseUrl + ",Response=" + xmlStr);
                            }
                            SAXParseXml saxParseXml = SAXParseXml.parse(xmlStr, getPlatformId(platformId), OrderEntity.class);
                            int apiTotal = saxParseXml.getApiTotal();
                            log.info("本次请求总条数为:" + apiTotal);
                            if (apiTotal > count) {
                                log.info("从[" + beginTime + "]到[" + endTime + "]AGQJ共漏抓了" + (apiTotal - count) + "条注单数据");
                                orderIdList.add(logEntity.getOrderLogId());
                            }
                        }
                    }
                }
                if (!orderIdList.isEmpty()) {
                    Map<String, Object> updateLogParams = new HashMap<>();
                    updateLogParams.put("idList", orderIdList);
                    updateLogParams.put("status", 0);
                    updateLogParams.put("operator", "System_DC_APP");
                    orderLogService.updateOrderLogStatus(updateLogParams);
                    String beginTime = (String) parameterMap.get(BEGIN_TIME);
                    String endTime = (String) parameterMap.get(END_TIME);
                    log.info("共重置了" + orderIdList.size() + " 条任务，任务区间为[" + beginTime + "]到[" + endTime + "]");
                    orderIdList.clear();
                }
                allocationEntity.setTaskBeginTime(DateUtil.formatStr2Date((String) parameterMap.get(BEGIN_TIME)));
                allocationEntity.setTaskEndTime(DateUtil.formatStr2Date((String) parameterMap.get(END_TIME)));
                allocationDao.updateAllocation(allocationEntity);
            }
        } catch (Exception e) {
            log.error("注单检查出错：", e);
        }
    }

    private String getPlatformId(String platStr) {
        String platFormId = "";
        if (UtilConstants.ORDERS_AG.equalsIgnoreCase(platStr)) {
            platFormId = UtilConstants.AGQJ;
        }
        if (UtilConstants.ORDERS_AGSTAR.equalsIgnoreCase(platStr)) {
            platFormId = UtilConstants.AGSTAR;
        } else if (UtilConstants.ORDERS_AG2.equalsIgnoreCase(platStr)) {
            platFormId = UtilConstants.AG2;
        } else if (UtilConstants.ORDERS_AGIN.equalsIgnoreCase(platStr)) {
            platFormId = UtilConstants.AGIN;
        } else if (UtilConstants.ORDERS_K8.equalsIgnoreCase(platStr)) {
            platFormId = UtilConstants.K8;
        }
        return platFormId;
    }

    private Map<String, Object> updateTimeForParameterMap(Map<String, Object> parameterMap, long endSeconds) {
        String beginTime = getNewTimeByOldTime((String) parameterMap.get(BEGIN_TIME), endSeconds);
        String endTime = getNewTimeByOldTime((String) parameterMap.get(END_TIME), endSeconds);
        parameterMap.put(BEGIN_TIME, beginTime);
        parameterMap.put(END_TIME, endTime);
        return parameterMap;
    }

    private String getNewTimeByOldTime(String oldEndTime, long timeIncreament) {
        if (timeIncreament == 0) {
            return oldEndTime;
        }
        String newTime;
        Date oldEndDate = DateUtil.formatStr2Date(oldEndTime, DateUtil.C_TIME_PATTON_DEFAULT);
        long old = oldEndDate.getTime();
        long newMillSeconds = old + timeIncreament;
        Date newDate = new Date(newMillSeconds);
        newTime = DateUtil.formatDate2Str(newDate, DateUtil.C_TIME_PATTON_DEFAULT);
        return newTime;
    }

}
