package main.java.com.gw.common.system.timer;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.GameType;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.FTPUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.datacenter.allocation.entity.AllocationEntity;
import main.java.com.gw.datacenter.allocation.entity.Task;
import main.java.com.gw.datacenter.order.service.OrderService;
import main.java.com.gw.datacenter.orderlog.entity.OrderLogEntity;
import main.java.com.gw.datacenter.orderlog.service.OrderLogService;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Slf4j
public class OrderMethodInvokerUtils {

    public static void invoke(OrderLogEntity orderLogEntity, OrderLogService orderLogService, OrderService orderService) {
        String taskId = orderLogEntity.getTaskId().toString();
        String platformId = orderLogEntity.getPlatFormId();
        String baseUrl = orderLogEntity.getUrl();
        String begintime = DateUtil.formatDate2Str(orderLogEntity.getBeginTime());
        String endtime = DateUtil.formatDate2Str(orderLogEntity.getEndTime());
        try {
            Integer currencyType = orderLogEntity.getCurrencyType();
            String gameKind = orderLogEntity.getGameKind();
            if (currencyType == null) {
                currencyType = 1;
            }
            Map<String, Object> parameterMap = new HashMap<String, Object>();
            // bug修复，添加task信息，防止无法打印厅方返回内容情况 -- add by walter 2018-11-09
            parameterMap.put(UtilConstants.ORDER_TASK_ID, orderLogEntity.getTaskId());
            parameterMap.put("begintime", begintime);
            parameterMap.put("endtime", endtime);
            parameterMap.put("agcode", orderLogEntity.getAgentCode());
            parameterMap.put("currencyType", currencyType);
            parameterMap.put("platformid", platformId);
            parameterMap.put("currency", orderLogEntity.getCurrency());//获取币种类型
            AllocationEntity allocation = orderLogService.getAllocationById(taskId);
            parameterMap.put("remark", allocation.getRemark());
            parameterMap.put("num", String.valueOf(allocation.getPageSize() == null ? 1000 : allocation.getPageSize()));
            log.info("OrderMethodInvokerUtils 执行错误日志重新抓取，taskId[{" + taskId + "}], platfromId[{"
                    + platformId + "}], baseUrl[{" + baseUrl + "}], agcode[{" + orderLogEntity.getAgentCode() + "}],begintime[{" + parameterMap.get("begintime") + "}],endtime[{" + parameterMap.get("endtime") + "}]");

            if ("order_ag".equals(platformId)) {//AGQJ的电子钱包模式
                parameterMap.put("productId", allocation.getProductionId());
                orderService.insertOrder4AGJQ(parameterMap, baseUrl, orderLogEntity, true , taskId);
            } else if (UtilConstants.SHABA_FCLRC.equals(platformId)) {//SHABA

                parameterMap.put("model", allocation.getModel());
                parameterMap.put("remark", allocation.getRemark());
                parameterMap.put("password", allocation.getPassword());
                parameterMap.put("agcode", allocation.getProductionId());
                parameterMap.put("productId", allocation.getProductionId());
                parameterMap.put("model", allocation.getModel());
                // website versionKey
                if (null == orderLogEntity.getOldVersionKey()) {
                    parameterMap.put(UtilConstants.ALLOCATION_WEBSITE, "0");
                } else {
                    parameterMap.put(UtilConstants.ALLOCATION_WEBSITE, orderLogEntity.getOldVersionKey());
                }
                parameterMap.put("gamekind", allocation.getGameKind());
                parameterMap.put("username", allocation.getAccountName());
                orderService.insertOrder4ShabaPh(parameterMap, baseUrl, orderLogEntity, true , taskId);
            } else if (UtilConstants.AGQJ.equals(platformId)) {//AGQJ
                if ("1".equals(gameKind)) {
                    //AGQJ世界杯注单

                    parameterMap.put(UtilConstants.ORDER_BBIN_GAMEKIND, orderLogEntity.getGameKind());
                    parameterMap.put(UtilConstants.GLOBAL_PLATFORMID_KEY, platformId); //这个必须是003，直接为值
                    parameterMap.put(UtilConstants.ORDER_AG_CODE, allocation.getAgCode());
                    parameterMap.put("timeZone", allocation.getTimeZone());
                    parameterMap.put("dataDelay", allocation.getDataDelay());
                    parameterMap.put("baseUrl", orderLogEntity.getUrl());
                    long beginSeconds = allocation.getIncrementBegintime();
                    long endSeconds = allocation.getIncrementEndtime();
                    parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                    parameterMap.put("endSeconds", String.valueOf(endSeconds));
                    parameterMap.put(UtilConstants.ORDER_TASK_ID, allocation.getTaskId());
                    orderService.insertOrderAGQJWorldCup(parameterMap, baseUrl, orderLogEntity, true , taskId);
                }else if("-1".equals(gameKind)){
                    //CAP-2480 AGQJ篡改注单 20190108
                    parameterMap.put(UtilConstants.GLOBAL_PRODUCTID_KEY, allocation.getProductionId());
                    parameterMap.put(UtilConstants.GLOBAL_PLATFORMID_KEY, UtilConstants.ORDERS_AGQJ_EXCEPTIONOR);
                    parameterMap.put("password", allocation.getPassword());
                    orderService.insertOrderAGQJExceptionor(parameterMap, platformId, baseUrl, orderLogEntity, true , taskId);
                }else{
                    parameterMap.put("platformid", UtilConstants.ORDERS_AG);
                    parameterMap.put(UtilConstants.ORDER_BBIN_GAMEKIND, orderLogEntity.getGameKind());
                    orderService.insertOrder(parameterMap, baseUrl, orderLogEntity, true , taskId);
                }
            }  else if (UtilConstants.AGSTAR.equals(platformId)) {//AGSTAR
                if("-1".equals(gameKind)) {
                    //CAP-2480 AGQJ篡改注单 20190108
                    parameterMap.put(UtilConstants.GLOBAL_PRODUCTID_KEY, allocation.getProductionId());
                    parameterMap.put(UtilConstants.GLOBAL_PLATFORMID_KEY, UtilConstants.ORDERS_AGQJ_EXCEPTIONOR);
                    parameterMap.put("password", allocation.getPassword());
                    orderService.insertOrderAGQJExceptionor(parameterMap, platformId, baseUrl, orderLogEntity, true , taskId);
                }else if ("3".equals(gameKind)){
                    parameterMap.put("platformid", UtilConstants.ORDERS_AGSTAR);
                    parameterMap.put(UtilConstants.ORDER_BBIN_GAMEKIND, orderLogEntity.getGameKind());
                    orderService.insertOrder(parameterMap, baseUrl, orderLogEntity, true , taskId);
                }else {
                    //新agstar注单抓取
                    parameterMap.put("num", String.valueOf(allocation.getPageSize()));
                    parameterMap.put("platformid", allocation.getPlatformId());
                    parameterMap.put("agcode", allocation.getAgCode());
                    parameterMap.put(UtilConstants.ORDER_BBIN_GAMEKIND, allocation.getGameKind());
                    parameterMap.put("timeZone", allocation.getTimeZone());
                    parameterMap.put("dataDelay", allocation.getDataDelay());
                    parameterMap.put("baseUrl", allocation.getUrl());
                    parameterMap.put(UtilConstants.ORDER_TASK_ID, allocation.getTaskId());
                    parameterMap.put("password", allocation.getPassword());//加密key
                    parameterMap.put("agent", allocation.getAgCode());//代理名
                    parameterMap.put("currency", allocation.getCurrency() == null ? "CNY" : allocation.getCurrency());//获取币种类型
                    parameterMap.put("productid", allocation.getProductionId());
                    parameterMap.put("byGameType",allocation.getWebSite());
                    parameterMap.put("qpGameType",allocation.getAccountName());
                    parameterMap.put("dyGameType",allocation.getOrderField());
                    orderService.insertOrder4AS(parameterMap, baseUrl, orderLogEntity, true , taskId);
                }
            } else if (UtilConstants.AG2.equals(platformId)) {
                parameterMap.put("platformid", UtilConstants.ORDERS_AG2);
                parameterMap.put(UtilConstants.ORDER_BBIN_GAMEKIND, orderLogEntity.getGameKind());
                orderService.insertOrder(parameterMap, baseUrl, orderLogEntity, true , taskId);
            } else if (UtilConstants.AGIN.equals(platformId) && gameKind != null && gameKind.equals("51")) {

                parameterMap.put("platformid", allocation.getPlatformId());
                parameterMap.put("agcode", allocation.getAgCode());
                parameterMap.put("baseUrl", allocation.getUrl());
                parameterMap.put("str", allocation.getWebSite());
                parameterMap.put("pidtoken", allocation.getPassword());
                parameterMap.put("productId", orderLogEntity.getProductId());
                parameterMap.put("act", allocation.getAction());
                parameterMap.put("gamekind", allocation.getGameKind());
                orderService.insertAginFishOrder(parameterMap, baseUrl, orderLogEntity, true , taskId);
            }
            //新捕鱼api
            else if (UtilConstants.AGIN.equals(platformId) && baseUrl.contains("gethunterorders.xml")) {

                parameterMap.put("platformid", allocation.getPlatformId());
                parameterMap.put("agcode", allocation.getAgCode());
                parameterMap.put("baseUrl", allocation.getUrl());
                parameterMap.put("str", allocation.getWebSite());
                parameterMap.put("pidtoken", allocation.getPassword());
                parameterMap.put("productId", orderLogEntity.getProductId());
                parameterMap.put("act", allocation.getAction());
                parameterMap.put("gamekind", allocation.getGameKind());
                orderService.insertAginFishOrder(parameterMap, baseUrl, orderLogEntity, true , taskId);
            }

            else if (UtilConstants.AGIN.equals(platformId) && baseUrl.contains("getredres.xml")) {
                parameterMap.put("gamekind", orderLogEntity.getGameKind());
                parameterMap.put("platformid", UtilConstants.ORDERS_AGIN);

                parameterMap.remove("begintime");
                parameterMap.remove("endtime");
                parameterMap.remove("num");
                parameterMap.put("startdate", DateUtil.formatDate2Str(orderLogEntity.getBeginTime(), DateUtil.C_TIME_PATTON_DEFAULT10));
                parameterMap.put("enddate", DateUtil.formatDate2Str(orderLogEntity.getEndTime(), DateUtil.C_TIME_PATTON_DEFAULT10));
                parameterMap.put("perpage", String.valueOf(orderLogEntity.getPageSize()));
                parameterMap.put("pageNo", String.valueOf(orderLogEntity.getPageNo()));
                parameterMap.put("productid", orderLogEntity.getProductId());
                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocation.getTaskId());
                if (orderLogEntity.getGameCode() != null) {
                    parameterMap.put("gameType", orderLogEntity.getGameCode());
                } else {
                    parameterMap.put("gameType", "red_pocket");
                }
                orderService.insertRedpocket4AGIN(parameterMap, baseUrl, orderLogEntity, true , taskId);
            } else if (UtilConstants.AGIN.equals(platformId) && !"51".equals(gameKind)) {

                parameterMap.put("gamekind", orderLogEntity.getGameKind());
                parameterMap.put("platformid", UtilConstants.ORDERS_AGIN);
                //update by pacy.g ---- begin
                parameterMap.put("mingmakey", allocation.getPassword());
                parameterMap.put(UtilConstants.ORDER_PRODUCT_ID, allocation.getProductionId());
                //update by pacy.g ---- end
                parameterMap.put(UtilConstants.ORDER_BBIN_GAMEKIND, allocation.getGameKind());
                orderService.insertOrder(parameterMap, baseUrl, orderLogEntity, true , taskId);
            } else if (UtilConstants.ORDERS_AGIN_SPORT.equals(platformId)) {

                parameterMap.put("mingmakey", allocation.getPassword());
                parameterMap.put(UtilConstants.ORDER_PRODUCT_ID, allocation.getProductionId());
                parameterMap.put(UtilConstants.ORDER_BBIN_GAMEKIND, allocation.getGameKind());
                parameterMap.put("timeZone", allocation.getTimeZone());
                parameterMap.put("dataDelay", allocation.getDataDelay());
                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocation.getTaskId());
                orderService.insertOrderAGINSport(parameterMap, baseUrl, orderLogEntity, true , taskId);
            } else if (UtilConstants.ESP.equals(platformId)) {
                parameterMap.put("instanceId", allocation.getAgCode());
                parameterMap.put("token", allocation.getOrderField());
                parameterMap.put("payoutFlag", allocation.getOrderWay());
                parameterMap.put("timeZone", allocation.getTimeZone());
                parameterMap.put("dataDelay", allocation.getDataDelay());
                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocation.getTaskId());
                parameterMap.put(UtilConstants.ORDER_PRODUCT_ID, allocation.getProductionId());

                orderService.insertOrder4ESP(parameterMap, baseUrl, orderLogEntity, true , taskId);
            } else if (UtilConstants.K8.equals(platformId)) {
                if("-1".equals(gameKind)) {
                    //CAP-2480 AGQJ篡改注单 20190108
                    parameterMap.put(UtilConstants.GLOBAL_PRODUCTID_KEY, allocation.getProductionId());
                    parameterMap.put(UtilConstants.GLOBAL_PLATFORMID_KEY, UtilConstants.ORDERS_AGQJ_EXCEPTIONOR);
                    parameterMap.put("password", allocation.getPassword());
                    orderService.insertOrderAGQJExceptionor(parameterMap, platformId, baseUrl, orderLogEntity, true , taskId);
                }else {
                    parameterMap.put("platformid", UtilConstants.ORDERS_K8);
                    //KENO注单抓取，请求参数增加未结算注单标识
                    parameterMap.put(UtilConstants.ORDER_PER_SEARCHALL,allocation.getOrderWay());
                    orderService.insertOrder(parameterMap, baseUrl, orderLogEntity, true , taskId);
                }
            } else if (UtilConstants.BBIN_BLM.equals(platformId)
                    || UtilConstants.BBIN_HJHA.equals(platformId)
                    || UtilConstants.BBIN_MT.equals(platformId)
                    || UtilConstants.BBIN_ZL.equals(platformId)
                    || UtilConstants.BBIN_LL.equals(platformId)
                    || UtilConstants.BBIN_WH.equals(platformId)
                    || UtilConstants.BBIN_BJH_NEW.equals(platformId)
                    || UtilConstants.BBIN_HWX.equals(platformId)
                    || UtilConstants.BBIN_KB.equals(platformId)
                    || UtilConstants.ORDERS_B79_BBIN.equals(platformId)) {

                parameterMap.put("platformid", allocation.getPlatformId());
                parameterMap.put("model", orderLogEntity.getModel());
                parameterMap.put("gamekind", orderLogEntity.getGameKind());
                parameterMap.put("website", allocation.getWebSite());
                parameterMap.put("username", allocation.getAccountName());
                parameterMap.put("password", allocation.getPassword());//捕鱼大师此值为KeyB值
                parameterMap.put("agcode", allocation.getAgCode());
                parameterMap.put("productId", allocation.getProductionId());
                //add 补齐捕鱼大师 注单接口WagersRecordBy38 需要的请求参数 --begin
                parameterMap.put("uppername", allocation.getLoginName());
                parameterMap.put("action", allocation.getAction());
                parameterMap.put("gametype", allocation.getProductType());//把ProductType里放置gametype
                parameterMap.put("orderField", allocation.getOrderField());//作为key=A+B+C中的A值(BBIN捕鱼)
                parameterMap.put("orderWay", allocation.getOrderWay());//作为key=A+B+C中的C值(BBIN捕鱼)
                //add 补齐捕鱼大师 注单接口WagersRecordBy38 需要的请求参数 --end
                String subgamekind = allocation.getAction();
                if (!StringUtils.isBlank(subgamekind)) {
                    subgamekind = subgamekind.substring(subgamekind.indexOf("=") + 1, subgamekind.length());
                } else {
                    subgamekind = "";
                }
                parameterMap.put("subgamekind", subgamekind);
                //BBIN捕鱼大师 捕鱼达人 抓取注单URL
                if (baseUrl.indexOf("WagersRecordBy38") > -1 || baseUrl.indexOf("WagersRecordBy30") > -1 || baseUrl.indexOf("WagersRecordBy31") > -1) {
                    orderService.insertOrderBBINBYDS(parameterMap, baseUrl, orderLogEntity, true , taskId);
                } else {
                    orderService.insertOrder4BBIN(parameterMap, baseUrl, orderLogEntity, true , taskId);
                }
            } else if (UtilConstants.BBIN_BTT_UPDATE.equals(platformId)
                    || UtilConstants.BBIN_LB_UPDATE.equals(platformId)
                    || UtilConstants.BBIN_HJ_UPDATE.equals(platformId)
                    || UtilConstants.BBIN_YJ_UPDATE.equals(platformId)) {

                parameterMap.put("platformid", allocation.getPlatformId());
                parameterMap.put("model", orderLogEntity.getModel());
                parameterMap.put("gamekind", orderLogEntity.getGameKind());
                parameterMap.put("website", allocation.getWebSite());
                parameterMap.put("username", allocation.getAccountName());
                parameterMap.put("password", allocation.getPassword());
                parameterMap.put("agcode", allocation.getAgCode());
                parameterMap.put("productId", allocation.getProductionId());
                orderService.insertOrder4BBIN(parameterMap, baseUrl, orderLogEntity, true , taskId);
            } else if (UtilConstants.HOGAME.equals(platformId)) {

                parameterMap.put("platformid", allocation.getPlatformId());
                parameterMap.put("agcode", allocation.getProductionId());
                parameterMap.put("productId", allocation.getProductionId());
                parameterMap.put("website", allocation.getWebSite());
                parameterMap.put("username", allocation.getAccountName());
                parameterMap.put("password", allocation.getPassword());
                parameterMap.put("UserId", UtilConstants.BLANK);
                parameterMap.put("num", "800");
                orderService.insertOrder4HoGame(parameterMap, baseUrl, orderLogEntity, true , taskId);
            } else if (UtilConstants.AMAYA_FCLRC.equals(platformId) || UtilConstants.AMAYA_VIP_FCLRC.equals(platformId)) {

                parameterMap.put("platformid", allocation.getPlatformId());
                parameterMap.put("model", orderLogEntity.getModel());
                parameterMap.put("gamekind", orderLogEntity.getGameKind());
                parameterMap.put("website", allocation.getWebSite());
                parameterMap.put("username", allocation.getAccountName());
                parameterMap.put("password", allocation.getPassword());
                parameterMap.put("agcode", allocation.getProductionId());
                parameterMap.put("productId", allocation.getProductionId());
                orderService.insertOrder4TTG(parameterMap, baseUrl, orderLogEntity, true , taskId);
            } else if (UtilConstants.TLB.equals(platformId)) {

                parameterMap.put("platformid", UtilConstants.TLB);
                parameterMap.put("model", orderLogEntity.getModel());
                parameterMap.put("gamekind", orderLogEntity.getGameKind());
                parameterMap.put("pageNum", allocation.getPageNo());
                parameterMap.put("pageSize", allocation.getPageSize());
                parameterMap.put("agentName", allocation.getAccountName());
                parameterMap.put("username", allocation.getAccountName());
                parameterMap.put("password", allocation.getPassword());
                parameterMap.put("agcode", allocation.getProductionId());
                parameterMap.put("productId", allocation.getProductionId());

                orderService.insertOrder4TLBGame(parameterMap, baseUrl, orderLogEntity, true , taskId);
            } else if (UtilConstants.MG.equals(platformId) || UtilConstants.MG_VIP.equals(platformId)) {

                parameterMap.put("platformid", allocation.getPlatformId());
                parameterMap.put("productId", allocation.getProductionId());
                parameterMap.put("website", allocation.getWebSite());
                parameterMap.put("model", allocation.getModel());
                parameterMap.put("gamekind", allocation.getGameKind());
                parameterMap.put("username", allocation.getAccountName());
                parameterMap.put("password", allocation.getPassword());
                parameterMap.put("gameCode", allocation.getGameCode());

                baseUrl = allocation.getUrl();
                orderService.insertOrder4MG(parameterMap, baseUrl, orderLogEntity, true , taskId);

            } else if (UtilConstants.EA.equals(platformId)) {
                parameterMap.put("platformid", UtilConstants.ORDERS_EA);
                FTPUtil ftpClient = new FTPUtil();
                try {
                    ftpClient.setIp(allocation.getWebSite());
                    ftpClient.setUser(allocation.getAccountName());
                    ftpClient.setPwd(allocation.getPassword());
                    parameterMap.put("agcode", allocation.getProductionId());
                    parameterMap.put("productId", allocation.getProductionId());
                    orderService.insertOrder4EA(ftpClient, parameterMap, baseUrl, orderLogEntity, true , taskId);
                } catch (Exception e) {
                    log.error(e.getLocalizedMessage(), e);
                } finally {
                    try {
                        if (ftpClient.getFtpClient() != null) {
                            ftpClient.getFtpClient().close();
                            ftpClient.isConnection = false;
                        }
                    } catch (Exception e) {
                        log.error(e.getLocalizedMessage(), e);
                    }
                }
            } else if (UtilConstants.INDEX.equals(platformId)) {

                parameterMap.put("baseUrl", allocation.getUrl());
                parameterMap.put("num", String.valueOf(allocation.getPageSize()));
                parameterMap.put("platformid", allocation.getPlatformId());
                parameterMap.put("agcode", allocation.getAgCode());
                parameterMap.put("productId", allocation.getProductionId());
                parameterMap.put("website", allocation.getWebSite());
                parameterMap.put("model", allocation.getModel());
                parameterMap.put("gamekind", allocation.getGameKind());
                parameterMap.put("username", allocation.getAccountName());
                parameterMap.put("password", allocation.getPassword());
                parameterMap.put("task_id", allocation.getTaskId());
                parameterMap.put("currencyType", allocation.getCurrencyType());
                parameterMap.put("page", 1 + "");
                parameterMap.put("timetype", allocation.getPlayType());
                orderService.insertOrder4Index(parameterMap, baseUrl, orderLogEntity, true , taskId);
            } else if (UtilConstants.GT1.equals(platformId)) {

                parameterMap.put("baseUrl", allocation.getUrl());
                parameterMap.put("num", String.valueOf(allocation.getPageSize()));
                parameterMap.put("platformid", allocation.getPlatformId());
                parameterMap.put("agcode", allocation.getAgCode());
                parameterMap.put("productId", allocation.getProductionId());
                parameterMap.put("website", allocation.getWebSite());
                parameterMap.put("model", allocation.getModel());
                parameterMap.put("gamekind", allocation.getGameKind());
                parameterMap.put("username", allocation.getAccountName());
                parameterMap.put("password", allocation.getPassword());
                parameterMap.put("task_id", allocation.getTaskId());
                parameterMap.put("currencyType", allocation.getCurrencyType());
                parameterMap.put("page", 1 + "");
                orderService.insertOrder4GT1(parameterMap, baseUrl, orderLogEntity, true , taskId);
            } else if (UtilConstants.PT.equals(platformId)) {

                parameterMap.put("model", orderLogEntity.getModel());
                parameterMap.put("gamekind", orderLogEntity.getGameKind());
                parameterMap.put("website", allocation.getWebSite());
                parameterMap.put("username", allocation.getAccountName());
                parameterMap.put("password", allocation.getPassword());//
                parameterMap.put("c07password", allocation.getOrderField()); // C07 使用越南盾，所以证书和密码跟其他产品不一样，该字段单独存C07的密码    add by Miles on 2016-07-09
                // parameterMap.put("agcode", allocation.getAgCode());//
                parameterMap.put("baseUrl", allocation.getUrl());
                parameterMap.put("page", "1");
                baseUrl = allocation.getUrl();
                if (allocation.getTaskId().toString().equals("758")) {
                    orderService.insertOrder4PTNew(parameterMap, baseUrl, orderLogEntity, true , taskId);
                } else {
                    orderService.insertOrder4PT(parameterMap, baseUrl, orderLogEntity, true , taskId);
                }
            } else if (UtilConstants.BO.equals(platformId)) {
                parameterMap.put(UtilConstants.COMMAND, UtilConstants.COMMAND_VIEW);
                parameterMap.put(UtilConstants.MODULE, UtilConstants.POSITION_MODULE);
                parameterMap.put("api_username", allocation.getAccountName());
                parameterMap.put("api_password", allocation.getPassword());
                parameterMap.put("api_whiteLabel", allocation.getWebSite());
                parameterMap.put("num", String.valueOf(allocation.getPageSize()));
                parameterMap.put("page", "1");
                parameterMap.put("baseUrl", allocation.getUrl());
                baseUrl = allocation.getUrl();
                orderService.insertOrder4BO(parameterMap, orderLogEntity, true , taskId);
            } else if (UtilConstants.OPUS.equals(platformId)) {

                parameterMap.put("model", orderLogEntity.getModel());
                parameterMap.put("gamekind", orderLogEntity.getGameKind());
                parameterMap.put("website", allocation.getWebSite());
                parameterMap.put("username", allocation.getAccountName());
                parameterMap.put("password", allocation.getPassword());//
                parameterMap.put("agcode", allocation.getAgCode());//
                //parameterMap.put("errorlog_agcode", orderLogEntity.getAgentCode());
                parameterMap.put("baseUrl", allocation.getUrl());
                parameterMap.put("page", "1");
                baseUrl = allocation.getUrl();
                orderService.insertOrder4OPUS(parameterMap, baseUrl, orderLogEntity, true , taskId);
            } else if (UtilConstants.AP.equals(platformId)) {

                parameterMap.put("model", orderLogEntity.getModel());
                parameterMap.put("gamekind", orderLogEntity.getGameKind());
                parameterMap.put("website", allocation.getWebSite());
                parameterMap.put("username", allocation.getAccountName());
                parameterMap.put("password", allocation.getPassword());//
                // parameterMap.put("agcode", allocation.getAgCode());//
                parameterMap.put("baseUrl", allocation.getUrl());
                parameterMap.put("page", "1");
                parameterMap.put("startid", orderLogEntity.getGameCode());  //开始的ID存在数据库的GameCode字段里
                parameterMap.put("recordsize", String.valueOf(allocation.getPageSize()));
                parameterMap.put("num", String.valueOf(allocation.getPageNo()));

                baseUrl = allocation.getUrl();
                orderService.insertOrder4AP(parameterMap, baseUrl, orderLogEntity, true , taskId);
            } else if (UtilConstants.NAP.equals(platformId)) {
                parameterMap.put(UtilConstants.ORDER_BBIN_PASSWORD, allocation.getPassword());
                parameterMap.put(UtilConstants.ORDER_BBIN_GAMEKIND, orderLogEntity.getGameKind());
                parameterMap.put(UtilConstants.ORDER_BASE_URL, allocation.getUrl());
                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocation.getTaskId());
                parameterMap.put(UtilConstants.ORDER_PRODUCT_ID, allocation.getProductionId());
                parameterMap.put(UtilConstants.GLOBAL_PLATFORMID_KEY, allocation.getPlatformId());
                parameterMap.put("model", orderLogEntity.getModel());
                parameterMap.put("accountName", allocation.getAccountName());
                parameterMap.put(UtilConstants.ORDER_BBIN_PAGENUM, 1);
                parameterMap.put(UtilConstants.GAME_RESULT_PAGE_NUMBER, String.valueOf(allocation.getPageSize()));
                baseUrl = allocation.getUrl();
                orderService.insertOrder4NAP(parameterMap, baseUrl, orderLogEntity, true , taskId);
            } else if (UtilConstants.RGS.equals(platformId)) {

                parameterMap.put("model", orderLogEntity.getModel());
                parameterMap.put("gamekind", orderLogEntity.getGameKind());
                parameterMap.put("baseUrl", allocation.getUrl());
                parameterMap.put("productId", allocation.getProductionId());
                parameterMap.put("page", "1");
                parameterMap.put(UtilConstants.GLOBAL_PLATFORMID_KEY, allocation.getPlatformId());
                baseUrl = allocation.getUrl();
                parameterMap.put("baseUrl", baseUrl);
                orderService.insertOrder4RGS(parameterMap, baseUrl, orderLogEntity, true , taskId);
            } else if (UtilConstants.SBT.equals(platformId)) {

                String collectionType = allocation.getAgCode();
                parameterMap.put(UtilConstants.NSS_TIMEZONE, allocation.getTimeZone());
                parameterMap.put("dataDelay", allocation.getDataDelay());
                parameterMap.put(UtilConstants.ORDER_BASE_URL, allocation.getUrl());
                long beginSeconds = allocation.getIncrementBegintime();
                long endSeconds = allocation.getIncrementEndtime();
                parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                parameterMap.put("endSeconds", String.valueOf(endSeconds));
                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocation.getTaskId());
                parameterMap.put("collectionType", collectionType);
                parameterMap.put(UtilConstants.GLOBAL_PRODUCTID_KEY, allocation.getProductionId());
                //下面这些参数在normallog里要用
                parameterMap.put(UtilConstants.ORDER_PAGE_NUMBER, "20");
                parameterMap.put(UtilConstants.ORDER_AG_CODE, collectionType);
                parameterMap.put(UtilConstants.ORDER_BBIN_GAMEKIND, "8");
                parameterMap.put(UtilConstants.ORDER_BBIN_MODEL, "");
                parameterMap.put(UtilConstants.ACCOUNT_TRANSFER_PLATFORMID, allocation.getPlatformId());
                orderService.insertRecord4SBT(parameterMap, true, collectionType, orderLogEntity , taskId);
            } else if (UtilConstants.BSG.equals(platformId) || UtilConstants.BSG_VIP.equals(platformId)) {
                parameterMap.put("num", String.valueOf(allocation.getPageSize()));
                parameterMap.put("agcode", allocation.getProductionId());
                parameterMap.put("productId", allocation.getProductionId());
                parameterMap.put("website", allocation.getWebSite());
                parameterMap.put("model", allocation.getModel());
                parameterMap.put("gamekind", allocation.getGameKind());
                parameterMap.put("username", allocation.getAccountName());
                parameterMap.put("password", allocation.getPassword());
                parameterMap.put("gameCode", allocation.getGameCode());//BSG 5     BSG VIP 85
                parameterMap.put("platformid", allocation.getPlatformId());//order_bsg  order_bsg_vip
                // baseUrl = allocation.getUrl();
                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocation.getTaskId());
                if (baseUrl.indexOf("newBSGBetRecord.do") > -1) {
                    orderService.insertNewOrder4BSG(parameterMap, baseUrl, orderLogEntity, true , taskId);
                } else {
                    orderService.insertOrder4BSG(parameterMap, baseUrl, orderLogEntity, true , taskId);
                }
            } else if (UtilConstants.PNG.equals(platformId)) {
                parameterMap.put("num", String.valueOf(allocation.getPageSize()));
                parameterMap.put("agcode", allocation.getProductionId());
                parameterMap.put("productId", allocation.getProductionId());
                parameterMap.put("website", allocation.getWebSite());
                parameterMap.put("model", allocation.getModel());
                parameterMap.put("gamekind", allocation.getGameKind());
                parameterMap.put("username", allocation.getAccountName());
                parameterMap.put("password", allocation.getPassword());
                parameterMap.put("gameCode", allocation.getGameCode());//BSG 5     BSG VIP 85
                parameterMap.put("platformid", allocation.getPlatformId());//order_bsg  order_bsg_vip
                baseUrl = allocation.getUrl();
                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocation.getTaskId());
                orderService.insertOrder4PNG(parameterMap, baseUrl, orderLogEntity, true , taskId);
            } else if (UtilConstants.NETENT.equals(platformId)) {
                parameterMap.put("num", String.valueOf(allocation.getPageSize()));
                parameterMap.put("agcode", allocation.getProductionId());
                parameterMap.put("productId", allocation.getProductionId());
                parameterMap.put("website", allocation.getWebSite());
                parameterMap.put("model", allocation.getModel());
                parameterMap.put("gamekind", allocation.getGameKind());
                parameterMap.put("username", allocation.getAccountName());
                parameterMap.put("password", allocation.getPassword());
                parameterMap.put("gameCode", allocation.getGameCode());//BSG 5     BSG VIP 85
                parameterMap.put("platformid", allocation.getPlatformId());//order_bsg  order_bsg_vip
                baseUrl = allocation.getUrl();
                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocation.getTaskId());
                orderService.insertOrder4NETENT(parameterMap, baseUrl, orderLogEntity, true , taskId);
            } else if (UtilConstants.VMG.equals(platformId)) {

                parameterMap.put("gamekind", orderLogEntity.getGameKind());
                parameterMap.put("num", String.valueOf(allocation.getPageSize()));
                parameterMap.put("gameCode", "6");// VMG = 6
                parameterMap.put("baseUrl", allocation.getUrl());
                parameterMap.put("productId", allocation.getProductionId());
                parameterMap.put("page", "1");
                baseUrl = allocation.getUrl();
                parameterMap.put("baseUrl", baseUrl);
                orderService.insertOrder4VMG(parameterMap, baseUrl, orderLogEntity, true , taskId);
            } else if (UtilConstants.EVO.equals(platformId)) {
                Task task = orderLogService.getTaskFromLog(orderLogEntity);
                if (task != null) {
                    orderService.insertOrder4EVO(task, orderLogEntity, true , taskId);
                }
            } else if (UtilConstants.TGP.equals(platformId)) {

                parameterMap.put("clientId", allocation.getAccountName());//辨识吗
                parameterMap.put("clientSecret", allocation.getPassword());//营运商秘钥
                parameterMap.put("tokenUrl", allocation.getAgCode());//访问令牌的地址
                parameterMap.put("baseUrl", allocation.getUrl());
                baseUrl = allocation.getUrl();
                orderService.insertOrder4TGP(parameterMap, baseUrl, orderLogEntity, true , taskId);

                // NSS 订单拉取重试
            } else if (UtilConstants.NSS.equals(platformId)) {

                parameterMap.put("baseUrl", allocation.getUrl());
                parameterMap.put(UtilConstants.NSS_PARAMKEY_PRODUCTID, allocation.getProductionId());
                parameterMap.put(UtilConstants.NSS_TIMEZONE, allocation.getTimeZone());
                orderService.insertOrder4NSS(parameterMap, baseUrl, orderLogEntity, true , taskId);

            } else if (UtilConstants.GLOBAL_PLATFORMID_WAGER.equals(platformId)) {//抓取用户第一次下注第一次赢钱的错误日志重跑

                parameterMap.put("baseUrl", allocation.getUrl());
                parameterMap.put("flag", 1);//改标示是提供查询的时候使用 1 表示为已结算的数据
                baseUrl = allocation.getUrl();
                orderService.insertOrder4WagerInfo(parameterMap, baseUrl, orderLogEntity, true , taskId);
            } else if (UtilConstants.EBET.equals(platformId)) {

                parameterMap.put("billno", allocation.getBillNo());//在ebet中billno表示渠道ID
                parameterMap.put("productId", allocation.getProductionId());
                parameterMap.put("page", "1");
                parameterMap.put("baseUrl", allocation.getUrl());
                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocation.getTaskId());
                baseUrl = allocation.getUrl();
                orderService.insertOrder4EBET(parameterMap, baseUrl, orderLogEntity, true , taskId);
            } else if (UtilConstants.K8_SPORT_SBT.equals(platformId)) {

                baseUrl = allocation.getUrl();

                parameterMap.put("pageSize", String.valueOf(allocation.getPageSize()));
                parameterMap.put("platformid", allocation.getPlatformId());
                //parameterMap.put("platformName", "SBT");
                parameterMap.put("productId", allocation.getProductionId());
                parameterMap.put("website", allocation.getWebSite());
                parameterMap.put("model", allocation.getModel());
                parameterMap.put("gamekind", allocation.getGameKind());
                parameterMap.put("username", allocation.getAccountName());
                parameterMap.put("password", allocation.getPassword());
                parameterMap.put("gameCode", allocation.getGameCode());//K8Sports 5     K8Sports VIP 85
                parameterMap.put("baseUrl", baseUrl);
                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocation.getTaskId());

                orderService.insertOrder4K8Sbt(parameterMap, baseUrl, orderLogEntity, true , taskId);
            } else if (UtilConstants.PPG.equals(platformId)) {
                /*PPG注单任务重跑 add by ziv 2018-02-13*/
                parameterMap.put("starttime", DateUtil.formatDate2Str(orderLogEntity.getBeginTime()));
                parameterMap.put("productId", allocation.getProductionId());
                parameterMap.put("gamekind", allocation.getGameKind());
                parameterMap.put("username", allocation.getAccountName());
                parameterMap.put("password", allocation.getPassword());
                parameterMap.put("gameCode", allocation.getGameCode());
                parameterMap.put("timeZone", allocation.getTimeZone());
                parameterMap.put("baseUrl", allocation.getUrl());
                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocation.getTaskId());
                parameterMap.put("key", "123456");
                orderService.insertOrder4PPG(parameterMap, baseUrl, orderLogEntity, true , taskId);
            } else if (UtilConstants.YSB.equals(platformId)) {
                /*YSb注单任务重跑 add by allen 2018-05-22*/
                parameterMap.put("starttime", DateUtil.formatDate2Str(orderLogEntity.getBeginTime()));
                parameterMap.put("productId", allocation.getProductionId());
                parameterMap.put("gameCode", allocation.getGameCode());
                parameterMap.put("baseUrl", allocation.getUrl());
                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocation.getTaskId());
                parameterMap.put("key", "123456"); //key可以随意赋值，CW_dc只做了非空判断
                orderService.insertOrder4YSB(parameterMap, baseUrl, orderLogEntity, true , taskId);
            } else if (UtilConstants.BBIN_LOTTERY_ORDER.equals(platformId)) {//BBIN 彩票

                long beginSeconds = allocation.getIncrementBegintime();
                long endSeconds = allocation.getIncrementEndtime();
                parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                parameterMap.put("endSeconds", String.valueOf(endSeconds));
                parameterMap.put(UtilConstants.ORDER_BBIN_WEBSITE, allocation.getWebSite());
                parameterMap.put("uppername", allocation.getAccountName());
                parameterMap.put(UtilConstants.ACCOUNT_TRANSFER_AGCODE, allocation.getAgCode());
                parameterMap.put(UtilConstants.ORDER_BBIN_PAGENUM, 1);
                parameterMap.put(UtilConstants.GAME_RESULT_PAGE_NUMBER, String.valueOf(allocation.getPageSize()));
                parameterMap.put(UtilConstants.ORDER_BBIN_PASSWORD, allocation.getPassword());
                parameterMap.put("orderField", allocation.getOrderField());
                parameterMap.put("orderWay", allocation.getOrderWay());
                parameterMap.put(UtilConstants.ORDER_BBIN_GAMEKIND, allocation.getGameKind());
                parameterMap.put(UtilConstants.ORDER_PRODUCT_ID, allocation.getProductionId());
                parameterMap.put(UtilConstants.ACCOUNT_TRANSFER_ACTION, allocation.getAction());//这里用这个字段存储platformId的实值
                parameterMap.put(UtilConstants.ORDER_BASE_URL, baseUrl);
                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocation.getTaskId());
                orderService.insertOrder4BBINLottery(parameterMap, baseUrl, orderLogEntity, true , taskId);
            } else if (UtilConstants.NB.equals(platformId)) {
                String collectionType = allocation.getAgCode();
                parameterMap.put(UtilConstants.NSS_TIMEZONE, allocation.getTimeZone());
                parameterMap.put("dataDelay", allocation.getDataDelay());
                parameterMap.put(UtilConstants.ORDER_BASE_URL, allocation.getUrl());
                long beginSeconds = allocation.getIncrementBegintime();
                long endSeconds = allocation.getIncrementEndtime();
                parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                parameterMap.put("endSeconds", String.valueOf(endSeconds));
                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocation.getTaskId());
                parameterMap.put("collectionType", collectionType);
                parameterMap.put(UtilConstants.GLOBAL_PRODUCTID_KEY, allocation.getProductionId());
                //下面这些参数在normallog里要用
                parameterMap.put(UtilConstants.ORDER_PAGE_NUMBER, "20");
                parameterMap.put(UtilConstants.ORDER_AG_CODE, collectionType);
                parameterMap.put(UtilConstants.ORDER_BBIN_GAMEKIND, "1");
                parameterMap.put(UtilConstants.ORDER_BBIN_MODEL, "");
                parameterMap.put(UtilConstants.ACCOUNT_TRANSFER_PLATFORMID, allocation.getPlatformId());
                orderService.insertRecord4NB(parameterMap, true, collectionType, orderLogEntity , taskId);
            } else if (UtilConstants.PB.equals(platformId)){
                String collectionType = allocation.getAgCode();
                parameterMap.put(UtilConstants.NSS_TIMEZONE, allocation.getTimeZone());
                parameterMap.put("dataDelay", allocation.getDataDelay());
                parameterMap.put(UtilConstants.ORDER_BASE_URL, allocation.getUrl());
                long beginSeconds = allocation.getIncrementBegintime();
                long endSeconds = allocation.getIncrementEndtime();
                parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                parameterMap.put("endSeconds", String.valueOf(endSeconds));
                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocation.getTaskId());
                parameterMap.put("password", allocation.getPassword());
                parameterMap.put("collectionType", collectionType);
                parameterMap.put(UtilConstants.GLOBAL_PRODUCTID_KEY, allocation.getProductionId());
                //下面这些参数在normallog里要用
                parameterMap.put(UtilConstants.ORDER_PAGE_NUMBER, "20");
                parameterMap.put(UtilConstants.ORDER_AG_CODE, collectionType);
                parameterMap.put(UtilConstants.ORDER_BBIN_GAMEKIND, "1");
                parameterMap.put(UtilConstants.ORDER_BBIN_MODEL, "");
                parameterMap.put(UtilConstants.ACCOUNT_TRANSFER_PLATFORMID, allocation.getPlatformId());
                orderService.insertRecord4PB(parameterMap, true, orderLogEntity , taskId);
            }  else if (UtilConstants.SBO.equals(platformId)) {
//                String collectionType = allocation.getAgCode();
//                parameterMap.put(UtilConstants.NSS_TIMEZONE, allocation.getTimeZone());
//                parameterMap.put("dataDelay", allocation.getDataDelay());
//                parameterMap.put(UtilConstants.ORDER_BASE_URL, allocation.getUrl());
//                long beginSeconds = allocation.getIncrementBegintime();
//                long endSeconds = allocation.getIncrementEndtime();
//                parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
//                parameterMap.put("endSeconds", String.valueOf(endSeconds));
//                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocation.getTaskId());
//                parameterMap.put("collectionType", collectionType);
//                parameterMap.put(UtilConstants.GLOBAL_PRODUCTID_KEY, allocation.getProductionId());
//                //下面这些参数在normallog里要用
//                parameterMap.put(UtilConstants.ORDER_PAGE_NUMBER, "20");
//                parameterMap.put(UtilConstants.ORDER_AG_CODE, collectionType);
//                parameterMap.put(UtilConstants.ORDER_BBIN_GAMEKIND, "1");
//                parameterMap.put(UtilConstants.ORDER_BBIN_MODEL, "");
//                parameterMap.put(UtilConstants.ACCOUNT_TRANSFER_PLATFORMID, allocation.getPlatformId());
//                orderService.insertRecord4PB(parameterMap, true, collectionType, orderLogEntity);

//                parameterMap.put("model", orderLogEntity.getModel());
//                parameterMap.put("gamekind", orderLogEntity.getGameKind());
//                parameterMap.put("website", allocation.getWebSite());
//                parameterMap.put("username", allocation.getAccountName());
//                parameterMap.put("password", allocation.getPassword());//
//                parameterMap.put("agcode", allocation.getAgCode());//
//                parameterMap.put("errorlog_agcode", orderLogEntity.getAgentCode());
//                parameterMap.put("baseUrl", allocation.getUrl());
//                parameterMap.put("page", "1");
//                baseUrl = allocation.getUrl();
//                orderService.insertOrder4SBO(parameterMap, baseUrl, orderLogEntity, true);
            } else if (UtilConstants.XDJ.equals(platformId)) {
                String collectionType = allocation.getAgCode();
                parameterMap.put(UtilConstants.NSS_TIMEZONE, allocation.getTimeZone());
                parameterMap.put("dataDelay", allocation.getDataDelay());
                parameterMap.put(UtilConstants.ORDER_BASE_URL, allocation.getUrl());
                long beginSeconds = allocation.getIncrementBegintime();
                long endSeconds = allocation.getIncrementEndtime();
                parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                parameterMap.put("endSeconds", String.valueOf(endSeconds));
                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocation.getTaskId());
                parameterMap.put("collectionType", collectionType);
                parameterMap.put(UtilConstants.GLOBAL_PRODUCTID_KEY, allocation.getProductionId());
                //下面这些参数在normallog里要用
                parameterMap.put(UtilConstants.ORDER_PAGE_NUMBER, "20");
                parameterMap.put(UtilConstants.ORDER_AG_CODE, collectionType);
                parameterMap.put(UtilConstants.ORDER_BBIN_GAMEKIND, "1");
                parameterMap.put(UtilConstants.ORDER_BBIN_MODEL, "");
                parameterMap.put(UtilConstants.ACCOUNT_TRANSFER_PLATFORMID, allocation.getPlatformId());
                orderService.insertOrder4XDJ(parameterMap, allocation.getUrl(), orderLogEntity, true , taskId);
            }
            else if (UtilConstants.IM.equals(platformId)) {
                String collectionType = allocation.getAgCode();
                parameterMap.put(UtilConstants.NSS_TIMEZONE, allocation.getTimeZone());
                parameterMap.put("dataDelay", allocation.getDataDelay());
                parameterMap.put(UtilConstants.ORDER_BASE_URL, allocation.getUrl());
                long beginSeconds = allocation.getIncrementBegintime();
                long endSeconds = allocation.getIncrementEndtime();
                parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                parameterMap.put("endSeconds", String.valueOf(endSeconds));
                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocation.getTaskId());
                parameterMap.put("collectionType", collectionType);
                parameterMap.put(UtilConstants.GLOBAL_PRODUCTID_KEY, allocation.getProductionId());
                //下面这些参数在normallog里要用
                parameterMap.put(UtilConstants.ORDER_PAGE_NUMBER, "20");
                parameterMap.put(UtilConstants.ORDER_AG_CODE, collectionType);
                parameterMap.put(UtilConstants.ORDER_BBIN_GAMEKIND, "1");
                parameterMap.put(UtilConstants.ORDER_BBIN_MODEL, "");
                parameterMap.put(UtilConstants.ACCOUNT_TRANSFER_PLATFORMID, allocation.getPlatformId());
                orderService.insertOrder4IM(parameterMap, allocation.getUrl(), orderLogEntity, true , taskId);
            }
            else if (UtilConstants.IMDJ.equals(platformId)) {
                String collectionType = allocation.getAgCode();
                parameterMap.put(UtilConstants.NSS_TIMEZONE, allocation.getTimeZone());
                parameterMap.put("dataDelay", allocation.getDataDelay());
                parameterMap.put(UtilConstants.ORDER_BASE_URL, allocation.getUrl());
                long beginSeconds = allocation.getIncrementBegintime();
                long endSeconds = allocation.getIncrementEndtime();
                parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                parameterMap.put("endSeconds", String.valueOf(endSeconds));
                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocation.getTaskId());
                parameterMap.put("collectionType", collectionType);
                parameterMap.put(UtilConstants.GLOBAL_PRODUCTID_KEY, allocation.getProductionId());
                //下面这些参数在normallog里要用
                parameterMap.put(UtilConstants.ORDER_PAGE_NUMBER, "20");
                parameterMap.put(UtilConstants.ORDER_AG_CODE, collectionType);
                parameterMap.put(UtilConstants.ORDER_BBIN_GAMEKIND, "1");
                parameterMap.put(UtilConstants.ORDER_BBIN_MODEL, "");
                parameterMap.put(UtilConstants.ACCOUNT_TRANSFER_PLATFORMID, allocation.getPlatformId());
                orderService.insertOrder4IMDJ(parameterMap, allocation.getUrl(), orderLogEntity, true , taskId);
            }
            else if (allocation.getGameType() != null && GameType.IOM_WALLET.getType() == allocation.getGameType().intValue()) {
//                parameterMap.put("begintime", DateUtil.formatDate2Str(orderLogEntity.getBeginTime()));
////                parameterMap.put("endtime", DateUtil.formatDate2Str(allocation.getTaskEndTime()));
////                parameterMap.put("num", String.valueOf(allocation.getPageSize()));
////                parameterMap.put("agcode", allocation.getProductionId());
////                parameterMap.put("platformid", allocation.getPlatformId());

                //CW_dc的参数判断中有个奇怪的判断，不是NT厅必须有starttime，所以在这里把begintime复制一遍。
                parameterMap.put("starttime", parameterMap.get("begintime"));
                parameterMap.put("productId", allocation.getProductionId());
                parameterMap.put("website", allocation.getWebSite());
                parameterMap.put("model", allocation.getModel());
                parameterMap.put("targetTable", allocation.getTargetTable());
                parameterMap.put("gamekind", allocation.getGameKind());
                parameterMap.put("username", allocation.getAccountName());
                parameterMap.put("password", allocation.getPassword());
                parameterMap.put("gameCode", allocation.getGameCode());
                parameterMap.put("timeZone", allocation.getTimeZone());
                parameterMap.put("dataDelay", allocation.getDataDelay());
                parameterMap.put("baseUrl", allocation.getUrl());
                long beginSeconds = allocation.getIncrementBegintime();
                long endSeconds = allocation.getIncrementEndtime();
                parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                parameterMap.put("endSeconds", String.valueOf(endSeconds));
                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocation.getTaskId());
                parameterMap.put("key", "123456");//key可以随意赋值，CW_dc只做了非空判断
                orderService.insertOrder4Auto(parameterMap, baseUrl, orderLogEntity, true , taskId);
            } else if (UtilConstants.CQ9.equals(platformId)) {
                parameterMap.put(UtilConstants.GLOBAL_PLATFORMID_KEY, allocation.getPlatformId());
                parameterMap.put(UtilConstants.GLOBAL_PRODUCTID_KEY, allocation.getProductionId());
                parameterMap.put("gamekind", allocation.getGameKind());
                parameterMap.put(UtilConstants.ORDER_GAME_CODE, allocation.getGameCode());//CQ=73
                parameterMap.put("timeZone", allocation.getTimeZone());
                parameterMap.put("dataDelay", allocation.getDataDelay());
                parameterMap.put(UtilConstants.ORDER_BBIN_PASSWORD, allocation.getPassword());
                parameterMap.put(UtilConstants.ORDER_BASE_URL, allocation.getUrl());
                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocation.getTaskId());
                parameterMap.put("remark", allocation.getRemark());
                orderService.insertOrder4CQ9(parameterMap, baseUrl, orderLogEntity, true , taskId);
            }else if (UtilConstants.VNLOTO.equals(platformId)) {
                parameterMap.put(UtilConstants.GLOBAL_PLATFORMID_KEY, allocation.getPlatformId());
                parameterMap.put(UtilConstants.GLOBAL_PRODUCTID_KEY, allocation.getProductionId());
                parameterMap.put(UtilConstants.ORDER_GAME_CODE, allocation.getGameCode());
                parameterMap.put("timeZone", allocation.getTimeZone());
                parameterMap.put("dataDelay", allocation.getDataDelay());
                parameterMap.put(UtilConstants.ORDER_BBIN_PASSWORD, allocation.getPassword());
                parameterMap.put(UtilConstants.ORDER_BASE_URL, allocation.getUrl());
                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocation.getTaskId());
                parameterMap.put("remark", allocation.getRemark());
                orderService.insertOrder4VNLoto(parameterMap, baseUrl, orderLogEntity, true , taskId);
            }else if(UtilConstants.VR.equals(platformId)){
                parameterMap.put("donate", allocation.getAgCode());
                String starTime = DateUtil.formatDate2Str(orderLogEntity.getBeginTime(),"yyyy-MM-dd'T'HH:mm:ss'Z'");
                String endTime = DateUtil.formatDate2Str(orderLogEntity.getEndTime(),"yyyy-MM-dd'T'HH:mm:ss'Z'");
                parameterMap.put("startTime", starTime);
                parameterMap.put("endTime", endTime);
                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocation.getTaskId());

                String begin_time = DateUtil.formatDate2Str(allocation.getTaskBeginTime());
                String end_time = DateUtil.formatDate2Str(allocation.getTaskEndTime());
                parameterMap.put("begintime", begin_time);
                parameterMap.put("endtime", end_time);

                long beginSeconds = allocation.getIncrementBegintime();
                long endSeconds = allocation.getIncrementEndtime();

                parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                parameterMap.put("endSeconds", String.valueOf(endSeconds));

                parameterMap.put("timeZone", allocation.getTimeZone());
                parameterMap.put("dataDelay", allocation.getDataDelay());
                parameterMap.put("baseUrl", allocation.getUrl());
                parameterMap.put("platformid", allocation.getPlatformId());
                parameterMap.put("productId", allocation.getProductionId());
                parameterMap.put("currency", allocation.getCurrency() == null ? "CNY" : allocation.getCurrency());
                parameterMap.put("version",allocation.getOrderField());
                parameterMap.put("id",allocation.getOrderWay());
                parameterMap.put("cryptKey",allocation.getAccountName());
                if (baseUrl.endsWith("/GameBet")){
                    //vr电游注单
                    parameterMap.put("type",allocation.getPlayType());
                    orderService.insertOrder4VRSlots(parameterMap, baseUrl, orderLogEntity, true , taskId);
                }else{
                    //vr彩票注单
                    parameterMap.put("model",allocation.getModel());
                    orderService.insertOrder4VR(parameterMap, baseUrl, orderLogEntity, true , taskId);
                }
            }else if(UtilConstants.QG.equals(platformId)){
                //TODO qg
                parameterMap.put(UtilConstants.GLOBAL_PLATFORMID_KEY, allocation.getPlatformId());
                parameterMap.put(UtilConstants.GLOBAL_PRODUCTID_KEY, allocation.getProductionId());
                parameterMap.put("gamekind", allocation.getGameKind());
                parameterMap.put(UtilConstants.ORDER_GAME_CODE, allocation.getGameCode());//
                parameterMap.put("startTime", parameterMap.get("begintime"));
                parameterMap.put("endTime", parameterMap.get("endtime"));
                parameterMap.put("timeZone", allocation.getTimeZone());
                parameterMap.put("dataDelay", allocation.getDataDelay());
                parameterMap.put("key", allocation.getPassword());
                parameterMap.put("merchantCode", allocation.getAccountName());
                parameterMap.put("version",allocation.getOrderField());
                parameterMap.put(UtilConstants.ORDER_BASE_URL, allocation.getUrl());
                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocation.getTaskId());
                parameterMap.put("remark", allocation.getRemark());
                orderService.insertOrder4QG(parameterMap, baseUrl, orderLogEntity, true , taskId);
            }else if(UtilConstants.G1.equals(platformId)){
                parameterMap.put(UtilConstants.GLOBAL_PLATFORMID_KEY, allocation.getPlatformId());
                parameterMap.put(UtilConstants.GLOBAL_PRODUCTID_KEY, allocation.getProductionId());
                parameterMap.put("gamekind", allocation.getGameKind());
                parameterMap.put("startTime", parameterMap.get("begintime"));
                parameterMap.put("endTime", parameterMap.get("endtime"));
                parameterMap.put(UtilConstants.ORDER_GAME_CODE, allocation.getGameCode());//
                parameterMap.put("timeZone", allocation.getTimeZone());
                parameterMap.put("dataDelay", allocation.getDataDelay());
                parameterMap.put("merchantKey", allocation.getPassword());
                parameterMap.put("version",allocation.getOrderField());
                parameterMap.put(UtilConstants.ORDER_BASE_URL, allocation.getUrl());
                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocation.getTaskId());
                parameterMap.put("remark", allocation.getRemark());
                parameterMap.put("pageSize", String.valueOf(allocation.getPageSize()));
                orderService.insertOrder4G1(parameterMap, baseUrl, orderLogEntity, true , taskId);
            }else if(UtilConstants.CS.equals(platformId)){
                parameterMap.put("platformid", allocation.getPlatformId());
                parameterMap.put("productId", allocation.getProductionId());
                parameterMap.put("gamekind", allocation.getGameKind());
                parameterMap.put("startTime", orderLogEntity.getBeginTime().getTime());
                parameterMap.put("endTime", orderLogEntity.getEndTime().getTime());
                parameterMap.put(UtilConstants.ORDER_GAME_CODE, allocation.getGameCode());//
                parameterMap.put("timeZone", allocation.getTimeZone());
                parameterMap.put("dataDelay", allocation.getDataDelay());
                parameterMap.put("version",allocation.getOrderField());
                parameterMap.put("baseUrl", allocation.getUrl());
                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocation.getTaskId());
                parameterMap.put("app_id", allocation.getOrderField());//数据库ORDER_FIELD存放appId
                parameterMap.put("currency", allocation.getCurrency()==null?UtilConstants.CNY: allocation.getCurrency());
                parameterMap.put("public_key", allocation.getAgCode());
                parameterMap.put("remark", allocation.getRemark());
                parameterMap.put("pageSize", String.valueOf(allocation.getPageSize()));
                orderService.insertOrder4CS(parameterMap, baseUrl, orderLogEntity, true , taskId);
            }else if(UtilConstants.XJ.equals(platformId)){
                String timeZone=allocation.getTimeZone();
                boolean isSettled= Objects.equals(allocation.getAction(),"isSettled");
                parameterMap.put("isSettled", isSettled);
                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocation.getTaskId());
                String begin_time = DateUtil.formatDate2Str(orderLogEntity.getBeginTime());
                String end_time = DateUtil.formatDate2Str(orderLogEntity.getEndTime());
                parameterMap.put("begintime", begin_time);
                parameterMap.put("endtime", end_time);
                parameterMap.put("timeZone", timeZone);
                parameterMap.put("dataDelay", allocation.getDataDelay());
                parameterMap.put("baseUrl", allocation.getUrl());
                parameterMap.put("platformid", allocation.getPlatformId());
                parameterMap.put("productId", allocation.getProductionId());
                parameterMap.put("currency", allocation.getCurrency()==null?UtilConstants.CNY: allocation.getCurrency());
                parameterMap.put("opCode",allocation.getAgCode());
                parameterMap.put("key",allocation.getAccountName());
                parameterMap.put("iv", allocation.getPassword());
                orderService.insertOrder4XJ188(parameterMap, baseUrl, orderLogEntity, true , taskId);
            }else if(UtilConstants.PS.equals(platformId)) {
                DateTimeFormatter dateTimeFormatter = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss");
                parameterMap.put("begintime", new DateTime(allocation.getTaskEndTime()).toString(dateTimeFormatter));
                parameterMap.put("endtime", new DateTime(allocation.getTaskEndTime()).plusMillis(allocation.getIncrementEndtime()).toString(dateTimeFormatter));
                parameterMap.put("num", String.valueOf(allocation.getPageSize()));
                parameterMap.put("platformid", allocation.getPlatformId());
                parameterMap.put("agcode", allocation.getProductionId());
                parameterMap.put("productId", allocation.getProductionId());
                parameterMap.put("website", allocation.getWebSite());
                parameterMap.put("model", allocation.getModel());
                parameterMap.put("gamekind", allocation.getGameKind());
                parameterMap.put("username", allocation.getAccountName());
                parameterMap.put("password", allocation.getPassword());
                parameterMap.put("gameCode", allocation.getGameCode());//PNG 5     PNG VIP 85
                parameterMap.put("timeZone", allocation.getTimeZone());
                parameterMap.put("dataDelay", allocation.getDataDelay());
                parameterMap.put("baseUrl", allocation.getUrl());
                parameterMap.put("beginSeconds", String.valueOf(allocation.getIncrementBegintime()));
                parameterMap.put("endSeconds", String.valueOf(allocation.getIncrementEndtime()));
                parameterMap.put("currency", allocation.getCurrency() == null ? "CNY" : allocation.getCurrency());//获取币种类型
                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocation.getTaskId());
                //这个动作是为了设置map中的开始时间和结束时间.配置成本次去拉取厅方的时间段,是通过开始增量时间,和结束增量时间实现的.
                parameterMap.put("psStart", new DateTime(orderLogEntity.getBeginTime()).toString(dateTimeFormatter));
                parameterMap.put("psEnd", new DateTime(orderLogEntity.getEndTime()).toString(dateTimeFormatter));

                orderService.insertOrder4PlayStar(allocation,orderLogEntity,parameterMap,true , taskId);
            }else if(UtilConstants.LC.equals(platformId)){
                String collectionType = allocation.getAgCode();
                parameterMap.put(UtilConstants.NSS_TIMEZONE, allocation.getTimeZone());
                parameterMap.put("dataDelay", allocation.getDataDelay());
                parameterMap.put(UtilConstants.ORDER_BASE_URL, allocation.getUrl());
                long beginSeconds = allocation.getIncrementBegintime();
                long endSeconds = allocation.getIncrementEndtime();
                parameterMap.put("beginSeconds", String.valueOf(beginSeconds));
                parameterMap.put("endSeconds", String.valueOf(endSeconds));
                parameterMap.put(UtilConstants.ORDER_TASK_ID, allocation.getTaskId());
                parameterMap.put("password", allocation.getPassword());
                parameterMap.put("collectionType", collectionType);
                parameterMap.put(UtilConstants.GLOBAL_PRODUCTID_KEY, allocation.getProductionId());
                //下面这些参数在normallog里要用
                parameterMap.put(UtilConstants.ORDER_PAGE_NUMBER, "20");
                parameterMap.put(UtilConstants.ORDER_AG_CODE, collectionType);
                parameterMap.put(UtilConstants.ORDER_BBIN_GAMEKIND, "1");
                parameterMap.put(UtilConstants.ORDER_BBIN_MODEL, "");
                parameterMap.put(UtilConstants.ACCOUNT_TRANSFER_PLATFORMID, allocation.getPlatformId());
                orderService.insertRecord4LC(parameterMap, true, orderLogEntity , taskId);
            }
        } catch (Exception e) {
            log.error("taskId:" + taskId + ",platformId:" + platformId + ",baseUrl:" + baseUrl);
            log.error(e.getMessage(), e);
        }
    }
}
