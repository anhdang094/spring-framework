package main.java.com.gw.common.system.timer;
import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.redis.Rlock;
import main.java.com.gw.common.system.redis.TaskLock;
import main.java.com.gw.datacenter.allocation.entity.AllocationEntity;
import org.apache.commons.lang3.StringUtils;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.MDC;
import org.springframework.util.CollectionUtils;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * @Description: 小金（XJ）188 体育注单抓取
 * @Author: EAGLE
 * @Date: 2019/4/15 15:49
 * @Version: 1.0
 */
@Slf4j
public class OrderXJ188SportTimer extends AllAbstractTimer {
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
        log.info(context.toString());
        JobDataMap jobDataMap = context.getJobDetail().getJobDataMap();
        String taskId = jobDataMap.getString("taskId");
        log.info("--DC定时任务日志-TaskID-{}-",taskId);
        try (Rlock lock = TaskLock.tryAcquireLock(taskId)) {
            if (lock.getLock()) {
                long beginSeconds = 0L;
                long endSeconds = 0L;
                Map<String, Object> paramMap = new HashMap<>();
                /* 查询任务配置表获取该任务的信息 */
                List<AllocationEntity> allocationEntityList = allocationDao.getAllocationList(new String[]{taskId});
                if (StringUtils.isNotBlank(taskId)) {
                    Integer taskInteger = Integer.parseInt(taskId);
                    if (!CollectionUtils.isEmpty(allocationEntityList)) {
                        Optional<AllocationEntity> optional = allocationEntityList.stream()
                                .filter(entity -> Objects.equals(entity.getTaskId(), taskInteger)).findFirst();
                        if (optional.isPresent()) {
                            AllocationEntity allocationEntity = optional.get();
                            paramMap = buildParamMap(allocationEntity);
                            beginSeconds = allocationEntity.getIncrementBegintime();
                            endSeconds = allocationEntity.getIncrementEndtime();
                            paramMap.put("beginSeconds", beginSeconds);
                            paramMap.put("endSeconds", endSeconds);
                            paramMap = ToolUtil.updateTimeForParameterMap(paramMap, beginSeconds,endSeconds);
                            String timeZone = (String) paramMap.get("timeZone");
                            int dataDelay = (int) paramMap.get("dataDelay");
                            boolean isWait = ToolUtil.isWaitXMins(paramMap, timeZone, dataDelay);
                            if (!isWait) {
                                String baseUrl = (String) paramMap.get("baseUrl");
                                orderService.insertOrder4XJ188(paramMap, baseUrl, null, false , taskId);
                            }
                         } else {
                            log.error("查询taskId->{}任务配置表获取该任务的信息不存在:", taskId);
                        }
                    }
                }
            }
        } catch (Exception ex) {
            log.error("Fail to parse order json:" + ex.getMessage(), ex);
        }
    }

    /**
     * 构建参数map
     * @param entity
     * @return
     */
    private Map<String, Object> buildParamMap(AllocationEntity entity) {
        Map<String, Object> paramMap = new HashMap<>();
        String timeZone=entity.getTimeZone();
        boolean isSettled=Objects.equals(entity.getAction(),"isSettled");
        paramMap.put("isSettled", isSettled);
        paramMap.put(UtilConstants.ORDER_TASK_ID, entity.getTaskId());
        String begin_time = DateUtil.formatDate2Str(entity.getTaskBeginTime());
        String end_time = DateUtil.formatDate2Str(entity.getTaskEndTime());
        paramMap.put("begintime", begin_time);
        paramMap.put("endtime", end_time);
        paramMap.put("timeZone", timeZone);
        paramMap.put("dataDelay", entity.getDataDelay());
        paramMap.put("baseUrl", entity.getUrl());
        paramMap.put("platformid", entity.getPlatformId());
        paramMap.put("productId", entity.getProductionId());
        paramMap.put("currency", entity.getCurrency()==null?UtilConstants.CNY: entity.getCurrency());
        paramMap.put("agcode", entity.getAgCode());
        paramMap.put("model", entity.getModel());
        paramMap.put("opCode",entity.getAgCode());
        paramMap.put("key",entity.getAccountName());
        paramMap.put("iv", entity.getPassword());
        return paramMap;
    }
}
