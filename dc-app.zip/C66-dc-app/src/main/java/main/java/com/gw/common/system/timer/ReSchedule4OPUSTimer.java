package main.java.com.gw.common.system.timer;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.framework.util.ToolUtil;
import main.java.com.gw.common.system.redis.Rlock;
import main.java.com.gw.common.system.redis.TaskLock;
import main.java.com.gw.datacenter.allocation.entity.AllocationEntity;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.MDC;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * @Description: OPUS数据检测定时任务
 * @Author: Ziv.Y
 * @Date: 2018/7/25 19:02
 */
@Slf4j
public class ReSchedule4OPUSTimer extends AllAbstractTimer {

    @Override
    public void execute(JobExecutionContext cxt) throws JobExecutionException {
        MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
        log.info(cxt.toString());
        JobDataMap jobDataMap = cxt.getJobDetail().getJobDataMap();
        String taskId = jobDataMap.getString("taskId");
        log.info("--DC定时任务日志-TaskID-{}-",taskId);
        try(Rlock lock = TaskLock.tryAcquireLock(taskId)) {
            if (lock.getLock()) {
                long endSeconds = 0L;
                long beginSeconds = 0L;

                Map<String, Object> parameterMap = new HashMap<String, Object>();
                AllocationEntity taskContext = null;
                taskContext = orderLogService.getAllocationById(taskId);

                AllocationEntity allocation = orderLogService.getAllocationById(taskContext.getAgCode());//根据原task_id找到被检测的定时任务
                if (allocation == null) {
                    log.error(String.format("ReSchedule4OPUSTimer can not find opus task %s in the taskList", taskId));
                    return;
                }
                //OPUS验证接口参数
                parameterMap.put("num", String.valueOf(allocation.getPageSize()));
                parameterMap.put("platformid", UtilConstants.OPUS);
                parameterMap.put("productId", allocation.getAgCode().split("_")[0]);
                parameterMap.put("model", allocation.getModel());
                parameterMap.put("gamekind", allocation.getGameKind());
                parameterMap.put("agcode", allocation.getAgCode());
                parameterMap.put("website", allocation.getWebSite());
                parameterMap.put("username", allocation.getAccountName());
                parameterMap.put("password", allocation.getPassword());
                parameterMap.put("page", "1");
                parameterMap.put("baseUrl", taskContext.getUrl());

                //检测任务参数
                beginSeconds = taskContext.getIncrementBegintime();
                endSeconds = taskContext.getIncrementEndtime();
                parameterMap.put("begintime", DateUtil.formatDate2Str(taskContext.getTaskBeginTime()));
                parameterMap.put("endtime", DateUtil.formatDate2Str(taskContext.getTaskEndTime()));
                parameterMap.put("beginSeconds", beginSeconds);
                parameterMap.put("endSeconds", endSeconds);
                parameterMap.put("timeZone", taskContext.getTimeZone());
                parameterMap.put("dataDelay", taskContext.getDataDelay());
                parameterMap.put(UtilConstants.ORDER_TASK_ID, taskContext.getTaskId());
                parameterMap.put("check_task_id", taskContext.getAgCode());
                parameterMap = ToolUtil.updateTimeForParameterMap(parameterMap, beginSeconds, endSeconds);

                String timeZone = (String) parameterMap.get("timeZone");
                int dataDelay = (int) parameterMap.get("dataDelay");
                boolean isWait = ToolUtil.isWaitXMins(parameterMap, timeZone, dataDelay);
                if (!isWait) {
                    orderService.checkOPUSBetHistory(parameterMap);
                }
            }
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
        }
    }

}
