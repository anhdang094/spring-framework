package main.java.com.gw.common.system.timer;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.framework.constant.UtilConstants;
import main.java.com.gw.common.framework.util.DateUtil;
import main.java.com.gw.common.system.redis.Rlock;
import main.java.com.gw.common.system.redis.TaskLock;
import main.java.com.gw.datacenter.allocation.entity.AllocationEntity;
import main.java.com.gw.datacenter.orderlog.entity.OrderLogEntity;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.MDC;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * <pre>
 * @Overview:
 * @author: Richard.C
 * @History:
 *              date         author     JIRA NO.  method  function
 *            -------------------------------------------------------------------
 *             2017年4月3日   Richard.C     PDATACENTER-251  A01的BBIN六合彩派彩在数据中心客户输赢度全部显示为0【平台】             exexute
 *
 *            -------------------------------------------------------------------
 */
@Slf4j
public class ResetErrorLog4BBIN extends AllAbstractTimer {


    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
        log.info("Excuting  ResetErrorLog4BBIN Log Handler Timer " + "- begin.");
        log.info(context.toString());
        JobDataMap jobDataMap = context.getJobDetail().getJobDataMap();
        AllocationEntity allocationEntity = null;
        try(Rlock lock = TaskLock.tryAcquireLock(jobDataMap.getString("taskId"))) {
            if (lock.getLock()) {
                allocationEntity = allocationDao.getAllocationById(jobDataMap.getString("taskId"));
                //billNo存的是每周周几运行此任务
                String dayOfWeek = Calendar.getInstance().get(Calendar.DAY_OF_WEEK) - 1 + "";
                String schedualTime = allocationEntity.getTableCode();
                Date now = new Date();
                if (allocationEntity.getBillNo() == null) {
                    log.error("任务执行日期必须不能为空");
                    return;
                }
                if (schedualTime == null) {
                    log.error("任务执行时间必须不能为空");
                    return;
                }
                if (!allocationEntity.getBillNo().contains(dayOfWeek)) {
                    log.info("今日不需要执行任务，任务调度日=" + allocationEntity.getBillNo() + "，当前是星期" + dayOfWeek);
                    return;
                }

                Map<String, Object> parameterMapForLock = new HashMap<String, Object>();
                parameterMapForLock.put(UtilConstants.ORDER_TASK_ID, allocationEntity.getTaskId());
                parameterMapForLock.put(UtilConstants.ORDER_BEGIN_TIME, allocationEntity.getTaskBeginTime());
                parameterMapForLock.put(UtilConstants.ORDER_END_TIME, allocationEntity.getTaskEndTime());

                String schedualDateTimeStr = DateUtil.formatDate2Str(now, DateUtil.C_DATE_PATTON_DEFAULT) + " " + schedualTime;
                Date schedualDateTime = DateUtil.formatStr2Date(schedualDateTimeStr);
                long timeDiffSeconds = (now.getTime() - schedualDateTime.getTime()) / 1000;
                if (!(now.after(schedualDateTime) && timeDiffSeconds <= allocationEntity.getPeriod())) {
                    log.info("未到执行时间，任务调度时间=" + schedualTime + "，当前时间：" + DateUtil.formatDate2Str());
                    return;
                } else {
                    log.info("满足执行时间条件，任务调度时间=" + schedualTime + "，当前时间：" + DateUtil.formatDate2Str());
                }
                //需要重置的任务ID保存在代理编码字段里面
                String taskIds = allocationEntity.getAgCode();
                if (taskIds == null) {
                    log.error("重置的任务ID不能为空");
                    return;
                }
                Calendar calendar = DateUtil.date2Calendar(schedualDateTime);
                if (dayOfWeek.equals("2") || dayOfWeek.equals("7")) { //周二重置  周六晚上21:30 到周二晚21:30的任务， 周日一日是重置3天的任务
                    calendar.add(Calendar.DATE, -3);
                } else {
                    calendar.add(Calendar.DATE, -2);
                }
                Date lastExecuteTime = DateUtil.calendar2Date(calendar);
                Map<String, Object> parameterMapOrderLog = new HashMap<String, Object>();
                parameterMapOrderLog.put("beginTime", DateUtil.formatDate2Str(lastExecuteTime));
                parameterMapOrderLog.put("endTime", DateUtil.formatDate2Str(schedualDateTime));
                parameterMapOrderLog.put("fromRowNum", "1");
                parameterMapOrderLog.put("toRowNum", "1000");

                String[] taskIdArray = taskIds.split(",");
                for (String taskId : taskIdArray) {
                    parameterMapOrderLog.put("taskId", taskId);
                    List<OrderLogEntity> errorLogList = orderLogService.getOrderLogList(parameterMapOrderLog);
                    List<String> orderIdList = new ArrayList<String>();
                    if (errorLogList != null && errorLogList.size() > 0) {
                        for (OrderLogEntity orderLogEntity : errorLogList) {
                            orderIdList.add(orderLogEntity.getOrderLogId());
                        }
                        Map<String, Object> parameterMap = new HashMap<String, Object>();
                        parameterMap.put("idList", orderIdList);
                        parameterMap.put("status", 0);
                        parameterMap.put("operator", "System_DC_APP");
                        orderLogService.updateOrderLogStatus(parameterMap);
                        log.info("任务ID：" + taskId + " 共重置了 " + errorLogList.size() + " 条任务，任务区间为：" + DateUtil.formatDate2Str(lastExecuteTime) + " 到 " + DateUtil.formatDate2Str(schedualDateTime));
                    }
                }
            }
        } catch (Exception ex) {
            log.error("ResetErrorLog4BBIN error to trigger error " + " log for order!", ex);
        }
        log.info("Excuting ResetErrorLog4BBIN Log Handler Timer " + " - end.");
    }

}
