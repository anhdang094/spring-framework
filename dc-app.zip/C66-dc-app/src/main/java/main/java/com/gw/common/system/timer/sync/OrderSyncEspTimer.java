package main.java.com.gw.common.system.timer.sync;

import lombok.extern.slf4j.Slf4j;
import main.java.com.gw.common.system.timer.AllAbstractTimer;
import main.java.com.gw.datacenter.constans.GatherOrderSyncConstants;
import org.apache.commons.lang3.StringUtils;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.MDC;

import java.util.UUID;


@Slf4j
public class OrderSyncEspTimer extends AllAbstractTimer {



    @Override
    public void execute(JobExecutionContext arg0) throws JobExecutionException {
        String flatFormType = GatherOrderSyncConstants.PLATFORM_TYPE_ESP;

        MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
        log.info(arg0.toString());
        JobDataMap jobDataMap = arg0.getJobDetail().getJobDataMap();
        String taskId = jobDataMap.getString("taskId");
        log.info("--DC定时任务日志-TaskID-{}-",taskId);
        if(StringUtils.isBlank(taskId)){
            log.error("【{}】taskId 为空",flatFormType);
            return;
        }
        this.doOrderSyncTask(flatFormType,taskId);

    }

}
