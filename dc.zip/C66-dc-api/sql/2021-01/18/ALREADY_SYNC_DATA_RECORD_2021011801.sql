

create table already_sync_data_record
(
  tb_name    VARCHAR2(3) not null,
  uuid    NUMBER(19) not null
)