

create table t_orders_statistics_2021011901
as select * from t_orders_statistics
where   PRODUCT='C07';

DELETE from t_orders_statistics where PRODUCT='C07';


create table t_customer_info_2021011901
as select * from t_customer_info
where   product_id='C07';

DELETE from t_customer_info where product_id='C07';

create table t_orders_change_log_2021011901
as select * from t_orders_change_log
where   product_id='C07';

DELETE from t_orders_change_log where product_id='C07';


create table t_orders_summary_2021011901
as select * from t_orders_summary
where   product='C07';

DELETE from t_orders_summary where product='C07';

DELETE from ALREADY_SYNC_DATA_RECORD ;