

update ORDERS_SHABA set flag=-9    where PRODUCT_ID='C07' and LOGINNAME='ntrungquyet8' and BILLNO in ('4344314','4344408','4344410' ,'4344505')