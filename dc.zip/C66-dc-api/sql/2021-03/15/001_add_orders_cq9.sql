-- Create table
create table ORDERS_CQ9
(
  billno             VARCHAR2(50) not null,
  loginname          VARCHAR2(18),
  agcode             VARCHAR2(18),
  top_agcode         VARCHAR2(3),
  product_id         VARCHAR2(10),
  platform_id        VARCHAR2(20) default 073  not null,
  account            NUMBER(22,6),
  valid_account      NUMBER(22,6),
  cus_account        NUMBER(20,6),
  previos_amount     NUMBER,
  gmcode             VARCHAR2(14),
  billtime           DATE,
  reckontime         DATE,
  flag               NUMBER(1),
  hashcode           VARCHAR2(40),
  playtype           NUMBER(4),
  currency           VARCHAR2(6),
  tablecode          VARCHAR2(16),
  round              VARCHAR2(16),
  gametype           VARCHAR2(30),
  cur_ip             VARCHAR2(16),
  remark             VARCHAR2(124),
  result             VARCHAR2(64),
  card_list          VARCHAR2(196),
  exchangerate       NUMBER,
  resulttype         VARCHAR2(20),
  game_kind          NUMBER,
  orignal_billtime   DATE,
  orignal_reckontime DATE,
  orignal_timezone   VARCHAR2(10),
  creation_time      DATE,
  currency_type      NUMBER(1),
  id                 NUMBER(22),
  home_team          VARCHAR2(50),
  away_team          VARCHAR2(50),
  winning_team       VARCHAR2(20),
  device_type        VARCHAR2(6),
  bonus_amount       NUMBER default 0  not null,
  is_special_game    NUMBER(1) default 0 not null,
  remain_amount      NUMBER,
  pro_flag           NUMBER default 0 not null,
  odds               NUMBER(18,2),
  oddstype           VARCHAR2(20),
  termtype           VARCHAR2(2) default -1 not null
);
-- Add comments to the columns
comment on column ORDERS_CQ9.billno
  is '注单号码betid';
comment on column ORDERS_CQ9.loginname
  is '会员账号';
comment on column ORDERS_CQ9.agcode
  is '代理编号';
comment on column ORDERS_CQ9.top_agcode
  is '顶级代理编号';
comment on column ORDERS_CQ9.product_id
  is '产品id';
comment on column ORDERS_CQ9.platform_id
  is '平台ID';
comment on column ORDERS_CQ9.account
  is 'BetAmount(投注额)';
comment on column ORDERS_CQ9.valid_account
  is '有效投注额';
comment on column ORDERS_CQ9.cus_account
  is '客户输赢额度Payoff';
comment on column ORDERS_CQ9.previos_amount
  is '投注前额度（原额度）';
comment on column ORDERS_CQ9.gmcode
  is '局号';
comment on column ORDERS_CQ9.billtime
  is '下注时间';
comment on column ORDERS_CQ9.reckontime
  is '更新时间';
comment on column ORDERS_CQ9.flag
  is '注单状态：
1已结算，
0未结算，
-1重置试玩额度，
-2注单被篡改，
-8取消指定局注单，
-9取消注单
';
comment on column ORDERS_CQ9.hashcode
  is '校验码';
comment on column ORDERS_CQ9.currency
  is '币别';
comment on column ORDERS_CQ9.tablecode
  is '桌号';
comment on column ORDERS_CQ9.round
  is '场次';
comment on column ORDERS_CQ9.gametype
  is '游戏种类';
comment on column ORDERS_CQ9.cur_ip
  is '客户当前IP';
comment on column ORDERS_CQ9.remark
  is '备注';
comment on column ORDERS_CQ9.result
  is '输赢/开牌结果';
comment on column ORDERS_CQ9.card_list
  is '纸牌列表';
comment on column ORDERS_CQ9.exchangerate
  is '汇率';
comment on column ORDERS_CQ9.resulttype
  is '结果类型';
comment on column ORDERS_CQ9.game_kind
  is '游戏种类';
comment on column ORDERS_CQ9.orignal_billtime
  is '注单产生时间';
comment on column ORDERS_CQ9.orignal_reckontime
  is '原始估算时间';
comment on column ORDERS_CQ9.orignal_timezone
  is '原来时区';
comment on column ORDERS_CQ9.creation_time
  is '创建时间（系统自己创建的时间）';
comment on column ORDERS_CQ9.currency_type
  is '货币类型：0 CNY，1 未知，2 BTC，3 GBP';
comment on column ORDERS_CQ9.device_type
  is '0-电脑客户端注单 1-手机';
comment on column ORDERS_CQ9.is_special_game
  is '0:参与洗码 1:不参与洗码';
comment on column ORDERS_CQ9.odds
  is '赔率';
comment on column ORDERS_CQ9.oddstype
  is '盘口';

  alter table ORDERS_CQ9 add constraint PK_ORDERS_CQ9_BN_LN primary key (BILLNO, LOGINNAME);