
-- Create sequence
create sequence seq_ORDERS_CQ9
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20
order;

