DELETE from T_ORDERS_CHANGE_LOG;
   DELETE from T_ORDERS_SUMMARY;

   DELETE from ORDERS_PG;
   DELETE from orders_cg;
   DELETE from ORDERS_CQ9;
   DELETE from orders_png;
   DELETE from orders_agqj;
   DELETE from orders_shaba;