package com.gw;

import com.intech.config.MonitorFilterAutoConfiguration;
import com.intech.tracing.ZipkinServerTracingAutoConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;

@Slf4j
@SpringBootApplication
@ImportAutoConfiguration(value = {ZipkinServerTracingAutoConfiguration.class, MonitorFilterAutoConfiguration.class})
public class DataApiApplication extends SpringBootServletInitializer {

    //	private static final Log logger = LogFactory.getLog(DataApiApplication.class);
//	private static Logger log = LoggerFactory.getLogger(DataApiApplication.class);
    public static void main(String[] args) {
        SpringApplication.run(DataApiApplication.class, args);
    }

    @Bean
    public CommandLineRunner runner() {
        return args -> {
            log.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        };
    }

}

