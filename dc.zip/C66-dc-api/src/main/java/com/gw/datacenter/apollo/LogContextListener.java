package com.gw.datacenter.apollo;

import com.alibaba.fastjson.JSON;
import com.gw.datacenter.common.constants.UtilConstants;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.info.GitProperties;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static java.util.regex.Pattern.compile;

/**
 * project: gameInterface_code
 * author: Walter
 * create: 2019/3/14
 **/
@Component
public class LogContextListener {
    private static final Logger logger = LoggerFactory.getLogger(LogContextListener.class);

    @Value("${productId:ALL}")
    private String productId;
    @Autowired
    private GitProperties gitProperties;


    @PostConstruct
    void printProjectInfo() {
        try {
            logger.info("############################ 当前产品为：" + productId + " ############################");
            logger.info("\n" + JSON.toJSONString(gitProperties, true));
            String fileName = "git.properties";
            logger.info("============================Print project version start.============================");
            String gitInfo = IOUtils.toString(this.getClass().getClassLoader().getResourceAsStream(fileName), "UTF-8");
            logger.info("\n" + unicodeToString(gitInfo));
            String version = gitProperties.get("commit.id");
            UtilConstants.PROJECT_INFO.put("version", version);
            logger.info("============================Print project version end.==============================");
        } catch (Exception e) {
            logger.error("can't read file git.properties,error msg:{}", e.getMessage(), e);
        }
    }

    public static String unicodeToString(String str) {
        Pattern pattern = compile("(\\\\u(\\p{XDigit}{4}))");
        Matcher matcher = pattern.matcher(str);
        char ch;
        while (matcher.find()) {
            ch = (char) Integer.parseInt(matcher.group(2), 16);
            str = str.replace(matcher.group(1), ch + "");
        }
        return str;
    }
}