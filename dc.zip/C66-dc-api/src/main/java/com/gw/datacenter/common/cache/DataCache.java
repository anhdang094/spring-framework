package com.gw.datacenter.common.cache;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.exception.GWPersistenceException;
import com.gw.datacenter.common.util.DataUtil;
import com.gw.datacenter.service.DictionaryService;
import com.gw.datacenter.service.GameTypePlayTypeService;
import com.gw.datacenter.vo.dictionary.DictionaryEntity;
import com.gw.datacenter.vo.gametypeplaytype.GameTypePlayTypeEntity;
import com.gw.datacenter.vo.system.ConditionMap;
import com.gw.datacenter.vo.system.PlatformCondition;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * title: DataCacheServiceImpl
 * description: TODO
 * author: Jair.H
 * date: 2018/10/30 19:37
 */

@Component
@Slf4j
public class DataCache {
    //产品|PLATFORM=》平台列表（A01|PLATFORM=>platforms）
    private static Map<String, List<DictionaryEntity>> dictionaryCache = new ConcurrentHashMap<>();
    //平台=>注单表(010=>ORDERS_BBIN)
    @Getter
    private static Map<String, String> orderPlatformCache = new ConcurrentHashMap<>();
    private static Map<String, GameTypePlayTypeEntity> gameTypeEntityCache = new ConcurrentHashMap();
    private static Map<String, GameTypePlayTypeEntity> playTypeEntityCache = new ConcurrentHashMap();

    private static final String[] arrFlix = {"g", "p"};

    @Resource
    private DictionaryService dictionaryService;
    @Resource
    private GameTypePlayTypeService gameTypePlayTypeService;

    @PostConstruct
    public void init() {
        loadDataCache();
        Thread t = new Thread(() -> {
            while (true) {
                try {
                    loadDataCache();
                    Thread.sleep(2 * 60 * 1000);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        });
        t.start();
    }

    public void loadDataCache() {
        try {
            log.info("start load");
            loadDictionaryCache();
            loadOrderPlatformCache();
            loadGameTypePlayCache();
            log.info("end load");
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }


    private void loadDictionaryCache() {
        List<DictionaryEntity> products = null;
        try {
            products = dictionaryService.getDictionaryByDictName("PRODUCT");
        } catch (GWPersistenceException e) {
            log.error(e.getMessage(), e);
        }
        Map<String, List<DictionaryEntity>> dictionaryMap = new ConcurrentHashMap<>();
        for (DictionaryEntity product : products) {
            Map<String, Object> pramater = new HashMap<>();
            pramater.put("dictValue", product.getDictValueEN());
            pramater.put("dictName", "PLATFORM");
            try {
                List<DictionaryEntity> result = dictionaryService.getDictionaryByRelation(pramater);
                if (CollectionUtils.isNotEmpty(result)) {
                    dictionaryMap.put(product.getDictValueEN() + "|PLATFORM", result);
                }
            } catch (GWPersistenceException e) {
                log.error(e.getMessage(), e);
            }
        }
        if (dictionaryMap.size() > 0) {
            dictionaryCache = dictionaryMap;
        }
        log.info("end loadDictionaryCache cache,size:" + dictionaryCache.size());
    }

    public static String getTableMapByPlatFormId(String productId, String platformId) {
        String platform = DataUtil.getPlatform(productId, platformId);
        String tableName = orderPlatformCache.get(platform);
        return tableName;
    }

    private void loadOrderPlatformCache() {
        try {
            Map<String, Object> paramaterMap = new HashMap<>();
            paramaterMap.put("leftName", "ORDERS_TABLE");
            paramaterMap.put("rightName", "PLATFORM");
            List<DictionaryEntity> dictList = dictionaryService.getDictionaryByRelationParent(paramaterMap);
            Map<String, String> orderPlatformMap = new ConcurrentHashMap<>();
            for (DictionaryEntity dictionaryEntity : dictList) {
                orderPlatformMap.put(dictionaryEntity.getDictValueZH(), dictionaryEntity.getDictValueEN());
            }
            if (orderPlatformMap.size() > 0) {
                orderPlatformCache = orderPlatformMap;
            }
        } catch (GWPersistenceException e) {
            log.error(e.getMessage(), e);
        }
        log.info("end loadOrderPlatformCache cache,size:" + orderPlatformCache.size());
    }

    private void loadGameTypePlayCache() {
        try {
            List<GameTypePlayTypeEntity> list = gameTypePlayTypeService.getGameTypePlayTypeListAll(null);
            for (GameTypePlayTypeEntity entity : list) {
                StringBuilder key = new StringBuilder(entity.getPlatformId());
                if (entity.getType() == 1) {//"003|gBAC"
                    key.append(UtilConstants.VERTICAL).append(arrFlix[0]).append(entity.getGameType());
                    gameTypeEntityCache.put(key.toString(), entity);
                } else if (entity.getType() == 2) {
                    if (StringUtils.isBlank(entity.getGameType())) {
                        key.append(UtilConstants.VERTICAL).append(arrFlix[0]).append(StringUtils.EMPTY);
                    } else {
                        key.append(UtilConstants.VERTICAL).append(arrFlix[0]).append(entity.getGameType());
                    }
                    if (StringUtils.isBlank(entity.getPlayType())) {
                        key.append(UtilConstants.VERTICAL).append(arrFlix[1]).append(StringUtils.EMPTY);
                    } else {
                        key.append(UtilConstants.VERTICAL).append(arrFlix[1]).append(entity.getPlayType());
                    }
                    playTypeEntityCache.put(key.toString(), entity);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        log.info("end loadGameTypePlayCache cache,gameTypeEntityCache size:" + gameTypeEntityCache.size() + ",playTypeEntityCache size:" + playTypeEntityCache.size());
    }

    public static ConditionMap getTableMap(String productId, String platformId) {
        ConditionMap tabMap = new ConditionMap();
        if (StringUtils.isBlank(platformId)) {
            List<DictionaryEntity> dictionarys = dictionaryCache.get(productId + "|PLATFORM");
            if (CollectionUtils.isNotEmpty(dictionarys)) {
                for (DictionaryEntity dictionaryEntity : dictionarys) {
                    String pid = dictionaryEntity.getDictValueEN();
                    tabMap.put(pid, orderPlatformCache.get(pid));
                }
            } else {
                for (Iterator iterator = orderPlatformCache.keySet().iterator(); iterator.hasNext(); ) {
                    String mKey = (String) iterator.next();
                    tabMap.put(mKey, orderPlatformCache.get(mKey));
                }
            }
        } else {
            String platform = DataUtil.getPlatform(productId, platformId);
            if (orderPlatformCache.get(platform) != null) {
                tabMap.put(platform, orderPlatformCache.get(platform));
            }
        }
        return tabMap;
    }

    public static ConditionMap getTableMapByPlatFormIds(String productId, String[] platformIds) {
        if (platformIds == null) {
            return getTableMap(productId, null);
        } else {
            ConditionMap tabMap = new ConditionMap();
            for (int i = 0; i < platformIds.length; i++) {
                String platform = DataUtil.getPlatform(productId, platformIds[i]);
                if (orderPlatformCache.get(platform) != null) {
                    tabMap.put(platform, orderPlatformCache.get(platform));
                }
            }
            return tabMap;
        }
    }

    /**
     * 根据产品名、平台（多选）、游戏大类（多选）、游戏类型确定需要查询大类、类型的数据库表信息集合
     *
     * @param parameterMap 页面请求
     * @return ConditionMap 包括哪些平台和表壳进行Union,每个表哪些游戏大类（1-多）和游戏类型（1-多）可查询
     */
    public static ConditionMap getTabMap(Map<String, Object> parameterMap) {
        String[] platformIdArr = (String[]) parameterMap.get(UtilConstants.GLOBAL_PLATFORMID_KEY);
        String productId = (String) parameterMap.get("productId");
        String isSport = (String) parameterMap.get("isSport");
        String isVideo = (String) parameterMap.get("isVideo");
        String isSlots = (String) parameterMap.get("isSlots");
        String islottery = (String) parameterMap.get("islottery");
        String exportFlag = (String) parameterMap.get(UtilConstants.EXPORT_FLAG);
        ConditionMap tabMap = new ConditionMap();

        // 针对直接使用一个参数保存多个id的情况
        if (platformIdArr != null && platformIdArr.length == 1) {
            if (StringUtils.isBlank(platformIdArr[0])) {
                platformIdArr = null;
            } else if (platformIdArr[0].contains(",")) {
                platformIdArr = platformIdArr[0].split(",");
            }
        }
        if (platformIdArr == null || platformIdArr.length == 0) {
            if (StringUtils.isNotBlank(isSport)) {
                if (productId != null) {
                    platformIdArr = new String[9];
                    platformIdArr[0] = "068";//ysb add by ziv 2018-06-13
                    platformIdArr[1] = "069";//nb add by ziv 2018-06-13
                    platformIdArr[2] = "031";//shaba add by ziv 2018-06-13
                    if ("A01".equals(productId)) {//BBIN  add by ziv 2018-06-13
                        platformIdArr[3] = "006";
                    } else if ("A02".equals(productId)) {
                        platformIdArr[3] = "007";
                    } else if ("A03".equals(productId)) {
                        platformIdArr[3] = "017";
                    } else if ("A04".equals(productId)) {
                        platformIdArr[3] = "010";
                    } else if ("A05".equals(productId)) {
                        platformIdArr[3] = "012";
                    } else if ("A06".equals(productId)) {
                        platformIdArr[3] = "024";
                    } else if ("C01".equals(productId)) {
                        platformIdArr[3] = "013";
                    } else if ("C02".equals(productId)) {
                        platformIdArr[3] = "020";
                    } else if ("D01".equals(productId)) {
                        platformIdArr[3] = "011";
                    } else if ("D07".equals(productId)) {
                        platformIdArr[3] = "014";
                    } else if ("D08".equals(productId)) {
                        platformIdArr[3] = "015";
                    } else if ("D12".equals(productId)) {
                        platformIdArr[3] = "019";
                    } else if ("D13".equals(productId)) {
                        platformIdArr[3] = "021";
                    } else {
                        platformIdArr[3] = "006";
                    }
                    platformIdArr[4] = "070";//AGIN_SPORT add by ziv 2018-06-13
                    platformIdArr[5] = "003";//AGQJ体育 add by ziv 2018-06-13
                    platformIdArr[6] = "061";//nss add by ziv 2018-06-13
                    platformIdArr[7] = "062";//sbt add by ziv 2018-06-13
                    platformIdArr[8] = "066";//SPORTSBT add by ziv 2018-06-13
                } else {//无产品ID号就默认初始这些平台
                    platformIdArr = new String[16];
                    platformIdArr[0] = "068";//ysb add by ziv 2018-06-13
                    platformIdArr[1] = "069";//nb add by ziv 2018-06-13
                    platformIdArr[2] = "031";//shaba add by ziv 2018-06-13
                    platformIdArr[3] = "006";//BBIN_A01
                    platformIdArr[4] = "007";//BBIN_A02
                    platformIdArr[5] = "017";//BBIN_A03
                    platformIdArr[6] = "010";//BBIN_A04
                    platformIdArr[7] = "012";//BBIN_A05
                    platformIdArr[8] = "024";//BBIN_A06
                    platformIdArr[9] = "013";//BBIN_C01
                    platformIdArr[10] = "020";//BBIN_C02
                    platformIdArr[11] = "070";//AGIN_SPORT add by ziv 2018-06-13
                    platformIdArr[12] = "003";//AGQJ体育 add by ziv 2018-06-13
                    platformIdArr[13] = "061";//nss add by ziv 2018-06-13
                    platformIdArr[14] = "062";//sbt add by ziv 2018-06-13
                    platformIdArr[15] = "066";//SPORTSBT add by ziv 2018-06-13
                }
            } else {
                List<DictionaryEntity> dictionarys = dictionaryCache.get(productId + "|PLATFORM");
                if (dictionarys.size() > 0) {
                    platformIdArr = new String[dictionarys.size()];
                    for (int index = 0; index < dictionarys.size(); index++) {
                        DictionaryEntity dictionaryEntity = dictionarys.get(index);
                        String pid = dictionaryEntity.getDictValueEN();
                        platformIdArr[index] = pid;
                    }
                } else {
                    platformIdArr = new String[orderPlatformCache.keySet().size()];
                    int index = 0;
                    for (Iterator iterator = orderPlatformCache.keySet().iterator(); iterator.hasNext(); ) {
                        String mKey = (String) iterator.next();
                        platformIdArr[index] = mKey;
                        index++;
                    }
                }
            }
        }
        if (StringUtils.isNotBlank(isSlots) || StringUtils.isNotBlank(islottery) || StringUtils.isNotBlank(isVideo)) {
            for (int i = 0; i < platformIdArr.length; i++) {
                if ("006".equals(platformIdArr[i])) {
                    if ("A01".equals(productId)) {
                        platformIdArr[i] = "006";
                    } else if ("A02".equals(productId)) {
                        platformIdArr[i] = "007";
                    } else if ("A03".equals(productId)) {
                        platformIdArr[i] = "017";
                    } else if ("A04".equals(productId)) {
                        platformIdArr[i] = "010";
                    } else if ("A05".equals(productId)) {
                        platformIdArr[i] = "012";
                    } else if ("A06".equals(productId)) {
                        platformIdArr[i] = "024";
                    } else if ("C01".equals(productId)) {
                        platformIdArr[i] = "013";
                    } else if ("C02".equals(productId)) {
                        platformIdArr[i] = "020";
                    } else if ("D01".equals(productId)) {
                        platformIdArr[i] = "011";
                    } else if ("D07".equals(productId)) {
                        platformIdArr[i] = "014";
                    } else if ("D08".equals(productId)) {
                        platformIdArr[i] = "015";
                    } else if ("D12".equals(productId)) {
                        platformIdArr[i] = "019";
                    } else if ("D13".equals(productId)) {
                        platformIdArr[i] = "021";
                    } else {
                        platformIdArr[i] = "006";
                    }
                }
            }
        }
        // 将特殊的平台类型展开
        List<String> platformIdList = new ArrayList<>();
        for (int index = 0; index < platformIdArr.length; index++) {
            String platformId = platformIdArr[index];
            if (StringUtils.isBlank(platformId)) {
                continue;
            }
            if (platformId.equals("financial")) {
                // All金融 金融类平台
                if (!platformIdList.contains("040")) {
                    platformIdList.add("040");
                }
                if (!platformIdList.contains("041")) {
                    platformIdList.add("041");
                }
                if (!platformIdList.contains("042")) {
                    platformIdList.add("042");
                }

            } else if (platformId.equals("casino")) {
                // All娱乐，除金融类平台外的平台为赌场类平台
                List<DictionaryEntity> dictionarys = dictionaryCache.get(productId + "|PLATFORM");
                if (dictionarys.size() > 0) {
                    for (DictionaryEntity dictionaryEntity : dictionarys) {
                        String pid = dictionaryEntity.getDictValueEN();
                        if (!pid.equals("040") && !pid.equals("041") && !pid.equals("042")) {
                            if (!platformIdList.contains(pid)) {
                                platformIdList.add(pid);
                            }
                        }
                    }
                } else {
                    for (Iterator iterator = orderPlatformCache.keySet().iterator(); iterator.hasNext(); ) {
                        String mKey = (String) iterator.next();
                        if (!mKey.equals("040") && !mKey.equals("041") && !mKey.equals("042")) {
                            if (!platformIdList.contains(mKey)) {
                                platformIdList.add(mKey);
                            }
                        }
                    }
                }
            } else {
                if (!platformIdList.contains(platformId)) {
                    platformIdList.add(platformId);
                }
            }
        }
        for (int index = 0; index < platformIdList.size(); index++) {
            String platformId = platformIdList.get(index);
            if (StringUtils.isBlank(platformId)) {
                continue;
            }
            String gameKindStr; //游戏大类
            String gameType;//	游戏种类
            List<String> gameKindList = new ArrayList<String>();
            List<String> gameTypeList = new ArrayList<String>();
            if (parameterMap.containsKey("gameType")) {
                gameType = (String) parameterMap.get("gameType");
                gameTypeList.add(gameType);
            }
            // 没有gameKind，则直接添加平台，如有gameKind限制，需筛选
            if (parameterMap.containsKey(UtilConstants.GAME_KIND) && StringUtils.isNotBlank((String) parameterMap.get(UtilConstants.GAME_KIND))) {
                gameKindStr = (String) parameterMap.get(UtilConstants.GAME_KIND);
                String[] gameKindArr = gameKindStr.split(",");
                for (String gameKind : gameKindArr) {
                    // 体育是特殊的
                    if (StringUtils.isBlank(isSport) && StringUtils.isBlank(isSlots) && StringUtils.isBlank(islottery) && StringUtils.isBlank(isVideo)) {
                        if (StringUtils.isBlank(gameKind)) {
                            continue;
                        } else {
                            gameKind = gameKind.substring(gameKind.lastIndexOf("_") + 1);
                        }
                    } else {
                        gameKind = gameKind.substring(gameKind.lastIndexOf("_") + 1);

                    }
                    if (UtilConstants.AGIN.equalsIgnoreCase(platformId) || UtilConstants.HOGAME.equalsIgnoreCase(platformId)) {
                        if ("5".equals(gameKind)) {// 电子游艺
                            gameTypeList.add("SL%");
                        } else if ("3".equals(gameKind)) {
                            gameTypeList.add("LC");
                        } else if ("8".equals(gameKind)) {
                            gameTypeList.add("FISH");
                            gameTypeList.add("RAISEFISH");
                        } else if ("1".equals(gameKind)) {//AG球类的类型
                            gameTypeList.add("FIFA");
                        }
                    }
                    if (StringUtils.isNotBlank(gameKind)) {
                        gameKindList.add(gameKind);
                    }
                }
                // 有限制大类，但平台没有选择对应大类的，将过滤
                if (gameKindList == null || gameKindList.size() == 0) {
                    continue;
                }
                if (exportFlag != null && !exportFlag.equals(UtilConstants.ONE_STR)) {
                    // 清洗虚拟的gameKind,则表中没有gameKind信息，但整体默认为一个大类
                    if ("003, 001, 002, 036, 009, 025, 032".indexOf(platformId) > -1) {
                        if (gameKindList.contains("3")) {
                            gameKindList.remove("3");
                        }
                    }
                    if ("027".indexOf(platformId) > -1) {
                        if (gameKindList.contains("5")) {
                            gameKindList.remove("5");
                        }
                    }
                    if ("004".indexOf(platformId) > -1) {
                        if (gameKindList.contains("12")) {
                            gameKindList.remove("12");
                        }
                    }
                    if ("034, 031, 018".indexOf(platformId) > -1) {
                        if (gameKindList.contains("1")) {
                            gameKindList.remove("1");
                        }
                    }
                    if (StringUtils.isNotBlank(isSlots)) {
                        if (gameKindList.contains("3")) {
                            gameKindList.remove("3");
                        }
                    }
                    if (StringUtils.isNotBlank(islottery)) {
                        if (gameKindList.contains("3")) {
                            gameKindList.remove("3");
                        }
                    }
                }
                if (gameKindList.size() == 0) {
                    gameKindList = null;
                }
                if (gameTypeList.size() == 0) {
                    gameTypeList = null;
                }
                PlatformCondition con = new PlatformCondition();
                con.setKey(platformId);
                con.setValue(orderPlatformCache.get(platformId));
                con.setGameKindList(gameKindList);
                con.setGameTypeList(gameTypeList);
                tabMap.putPlatForm(con);
            } else {
                if (gameTypeList.size() == 0) {
                    gameTypeList = null;
                }
                PlatformCondition con = new PlatformCondition();
                con.setKey(platformId);
                con.setValue(orderPlatformCache.get(platformId));
                con.setGameTypeList(gameTypeList);
                tabMap.putPlatForm(con);
            }
        }
        return tabMap;
    }

    public static ConditionMap getCustomerBetTimeTableMap() {
        ConditionMap tabMap = new ConditionMap();
        for (Iterator iterator = orderPlatformCache.keySet().iterator(); iterator.hasNext(); ) {
            String mKey = (String) iterator.next();
            if (!"018".equals(mKey)) {
                tabMap.put(mKey, orderPlatformCache.get(mKey));
            }
        }
        return tabMap;
    }

    public static GameTypePlayTypeEntity getCacheGameTypeEntity(String playformId, String gameType) {
        if (StringUtils.isBlank(playformId)) {
            return null;
        }
        StringBuilder key = new StringBuilder(playformId);
        key.append(UtilConstants.VERTICAL).append(arrFlix[0]).append(gameType);
        return gameTypeEntityCache.get(key.toString());
    }

}
