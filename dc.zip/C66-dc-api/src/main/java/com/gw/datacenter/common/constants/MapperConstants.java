/**
 *
 */
package com.gw.datacenter.common.constants;

/**
 * @author alex.l
 */
public class MapperConstants {

    public static final String ORDER_GET_ORDER_LIST_4ALL = "mybatis.Order4K8Mapper.getOrderList4All";
    public static final String ORDER_GET_ORDER_LIST_SIZE_4ALL = "mybatis.Order4K8Mapper.getOrderList4AllSize";
    public static final String ORDER_GET_BOWIN_LIST = "mybatis.Order4K8Mapper.getBowinList";
    public static final String ORDER_GET_BOWIN_COUNT = "mybatis.Order4K8Mapper.getBowinCount";
    public static final String ORDER_GET_VALIDAMOUNT_LIST = "mybatis.WebServiceMapper.getValidAmountList";
    public static final String ORDER_GET_FIRST_BITORWIN_LIST = "mybatis.WebServiceMapper.getFirstBetWinList";
    public static final String ORDER_GET_FIRST_BITORWIN_COUNT = "mybatis.WebServiceMapper.getFirstBetWinCount";
    public static final String ORDER_GET_VALIDAMOUNT_LIST_IN_STATISTICS = "mybatis.WebServiceMapper.getValidAmountListByStatistics";
    public static final String ORDER_GET_VALIDAMOUNT_LIST_BY_TYPE_IN_STATISTICS = "mybatis.WebServiceMapper.getValidAmountListByTypeByStatistics";
    public static final String ORDER_GET_VALIDAMOUNT_LIST_BY_TYPE_IN_STATISTICS_RECORD = "mybatis.WebServiceMapper.getValidAmountListByTypeByStatisticsTotalRecords";
    public static final String ORDER_GET_VALIDAMOUNT_LIST_BY_TYPE = "mybatis.WebServiceMapper.getValidAmountListByType";
    public static final String ORDER_GET_ORDERENTITY = "mybatis.WebServiceMapper.getOrderentity";
    public static final String ORDER_GET_ORDERENTITY_RECORD = "mybatis.WebServiceMapper.getOrderentityRecord";
    public static final String ORDER_GET_VALIDAMOUNT_RECORD = "mybatis.WebServiceMapper.getValidAmountListTotalRecords";
    public static final String ORDER_GET_EFFECTIVE_BETTING_AMOUNT_LIST_IN_STATISTICS = "mybatis.WebServiceMapper.getMaxEffectiveBettingAmountListByStatistics";
    public static final String ORDER_GET_EFFECTIVE_BETTING_AMOUNT_RECORD_IN_STATISTICS = "mybatis.WebServiceMapper.getMaxEffectiveBettingAmounTotalRecordsByStatistics";
    public static final String ORDER_GET_EFFECTIVE_BETTING_AMOUNT_LIST = "mybatis.WebServiceMapper.getMaxEffectiveBettingAmountList";
    public static final String ORDER_GET_EFFECTIVE_BETTING_AMOUNT_RECORD = "mybatis.WebServiceMapper.getMaxEffectiveBettingAmounTotalRecords";
    public static final String ORDER_GET_EFFECTIVE_BETTING_AMOUNT_LIST_BY_GAMEKIND = "mybatis.WebServiceMapper.getMaxEffectiveBettingAmountListByGameKind";
    public static final String ORDER_GET_EFFECTIVE_BETTING_AMOUNT_RECORD_BY_GAMEKIND = "mybatis.WebServiceMapper.getMaxEffectiveBettingAmounTotalRecordsByGameKind";
    public static final String ORDER_GET_WEEKLY_MONTHLY_VALID_AMOUNT = "mybatis.WebServiceMapper.getMonthlyAndWeeklyValidAmount";
    public static final String ORDER_GET_WEEKLY_MONTHLY_VALID_AMOUNT_BY_STATISTICS = "mybatis.WebServiceMapper.getMonthlyAndWeeklyValidAmountByStatistics";
    public static final String ORDER_GET_CUSTOMER_BET_TIME = "mybatis.WebServiceMapper.getCustomerBetTime";
    public static final String ORDER_GET_CONTINUOUS_LIST = "mybatis.WebServiceMapper.getContinuousOrder";
    public static final String ORDER_GET_LIST_BY_PROFIT = "mybatis.WebServiceMapper.getOrderListByProfit";
    public static final String ORDER_GET_LIST_BY_HIGH_PROFIT = "mybatis.WebServiceMapper.getHighProfitOrderList";
    public static final String ORDER_GET_RECORD = "mybatis.WebServiceMapper.getRecord";
    public static final String ORDER_GET_RECORDCOUNT = "mybatis.WebServiceMapper.getRecordCount";
    public static final String ORDER_GET_RECORDSUMMARY = "mybatis.WebServiceMapper.getRecordSummary";
    public static final String ORDER_GET_RECORDSUMMARYGROUP = "mybatis.WebServiceMapper.getRecordSummaryGroup";
    public static final String ORDER_GET_RECORDMAXGROUPBY = "mybatis.WebServiceMapper.getRecordMaxGroupBy";
    public static final String ORDER_GET_PLAYERWINS = "mybatis.WebServiceMapper.getPlayerWins";
    public static final String ORDER_GET_TOPWINNERS = "mybatis.WebServiceMapper.getTopWinners";
    public static final String ORDER_GET_SUPERWINS = "mybatis.WebServiceMapper.getSuperWins";
    public static final String ORDER_GET_BETRANK = "mybatis.WebServiceMapper.getBetRank";
    public static final String ORDER_GET_BETRANKBYLOGINNAME = "mybatis.WebServiceMapper.getBetRankByLoginName";
    public static final String ORDER_GET_RECORDMAXANDSUMMARYGROUPBY = "mybatis.WebServiceMapper.getRecordMaxAndSummaryGroupBy";
    public static final String ORDER_GET_LIST = "mybatis.WebServiceMapper.getBetHistory";
    public static final String ORDER_GET_BESTWIN = "mybatis.WebServiceMapper.getBestWin";
    public static final String ORDER_GET_LIST_BY_MULTIPLE_PROFIT = "mybatis.WebServiceMapper.getBetHistoryByMultipleProfit";
    public static final String ORDER_GETORDERBYMULTIPLEANDVALIDACCOUNT2 = "mybatis.WebServiceMapper.getOrderByMultipleAndValidAccount2";
    //add by ziv 2018-05-10
    public static final String ORDER_GET_VALIDAMOUNTLIST_BYTYPE_FROMSTATISTICS = "mybatis.WebServiceMapper.getValidAmountListByTypeFromStatisticsPagination";
    //add by ziv 2018-05-10
    public static final String ORDER_GET_VALIDAMOUNTLIST_BYTYPE_FROMSTATISTICS_TOTALRECORDS = "mybatis.WebServiceMapper.getValidAmountListByTypeFromStatisticsTotalRecords";
    //add by ziv 2018-07-28
    public static final String ORDER_GET_ORDERSUMMARY_GROUPBY_PID_USERNAME = "mybatis.WebServiceMapper.getOrderSummaryGroupByPidUsernamePagination";
    public static final String ORDER_GET_ORDERSUMMARY_GROUPBY_DAY = "mybatis.WebServiceMapper.getOrderSummaryGroupByDay";
    //add by ziv 2019-09-26
    public static final String ORDER_GET_ORDERSUMMARY_GROUPBY_PID_USERNAME_4_ACTIVITYLIST = "mybatis.WebServiceMapper.getOrderSummaryGroupByPidUsername4ActivityList";
    //add by ziv 2018-07-28
    public static final String ORDER_GET_ORDERSUMMARY_GROUPBY_PID_USERNAME_TOTALRECORDS = "mybatis.WebServiceMapper.getOrderSummaryGroupByPidUsernameTotalRecords";
    //add by ziv 2018-08-10
    public static final String ORDER_GET_ORDERSUMMARY_GROUPBY_PID_PLATID_UN = "mybatis.WebServiceMapper.getOrderSummaryGroupByPidPlatIdUnPagination";
    public static final String ORDER_GET_ORDERSUMMARY_GROUPBY_PLATID_GameType_UN = "mybatis.WebServiceMapper.getOrderSummaryGroupByPlatGameUnPagination";
    public static final String ORDER_GET_ORDERSUMMARY_GROUPBY_PLATID_GameType_UN_Total = "mybatis.WebServiceMapper.getOrderSummaryGroupByPlatGameUnTotal";
    public static final String ORDER_GET_ORDERSUMMARY_TotalUserNum = "mybatis.WebServiceMapper.getOrderSummaryGroupByPlatGameUnTotalUserNum";
    //add by ziv 2018-08-10
    public static final String ORDER_GET_ORDERSUMMARY_GROUPBY_PID_PLATID_UN_TOTALRECORDS = "mybatis.WebServiceMapper.getOrderSummaryGroupByPidPlatIdUnTotalRecords";
    public static final String GET_ORDER_BONUS_LIST = "mybatis.WebServiceMapper.getOrdersSumGroupByLoginName";
    public static final String GET_ORDER_BONUS_ACOUNT = "mybatis.WebServiceMapper.getOrdersSumGroupByLoginNameCount";
    public static final String ORDER_GET_EFFECTIVE_BETTING_LIST_GAMEKIND = "mybatis.WebServiceMapper.orderGetBettingListGameKind";
    public static final String ORDER_GET_EFFECTIVE_BETTING_LIST_GAMEKIND_COUNT = "mybatis.WebServiceMapper.orderGetBettingListGameKindCount";
    public static final String GET_ORDER_REMAIN_GROUP_LIST ="mybatis.WebServiceMapper.getOrderRemainGroupList";

    //C01新增
    public static final String GET_STATISTIC_AGQJDESKINFOS = "mybatis.WebServiceMapper.getAGQJDeskInfos";
    public static final String ORDER_GET_MG_AND_TTG_ABNORMAL_LIST = "mybatis.WebServiceMapper.getMGAndTTGAbnormalList";

    /**
     * -------------------------------------BaGame-----------------------------------------------------
     */
    //Get game result list
    public static final String GAMERESULT_GET_GAME_RESULT_LIST = "mybatis.WebServiceMapper.getBaGameRsultList";
    //Get total number
    public static final String GAMERESULT_GET_GAME_RESULT_TOTAL = "mybatis.WebServiceMapper.getToalGameResult";
    public static final String ORDER_GET_MAXVALUE_GROUPBY_SHOECODE = "mybatis.WebServiceMapper.getMaxValueGroupByShoecode";//for casino


    /**
     * -------------------------------------task allocation manager---------------------------------------
     */
    public static final String DICTIONARY_LIST_BY_DICTNAME = "mybatis.DictionaryMapper.getDictionaryListByDictName";
    public static final String DICTIONARY_LIST_BY_RELATION = "mybatis.DictionaryMapper.getDictionaryByRelation";
    public static final String DICTIONARY_LIST_BY_RELATION_PARENT = "mybatis.DictionaryMapper.getDictionaryByRelationParent";

    /**
     * ---- 游戏类型、玩法 add by ziv 2018-03-02 ----
     */
    public static final String GET_GAMETYPE_PLAYTYPE_LIST = "mybatis.GameTypePlayTypeMapper.getGameTypePlayTypeList";
    public static final String GET_GAMETYPE_PLAYTYPE_LIST_ALL = "mybatis.GameTypePlayTypeMapper.getGameTypePlayTypeListALL";

    /**
     * ---- risk ----
     **/
    public static final String GET_MOST_POPULAR_GAME_RANK = "mybatis.WebServiceMapper.getMostPopularGameRank";
    public static final String GET_BET_RECORD = "mybatis.WebServiceMapper.getBetRecord";
    public static final String GET_GAME_ORDER = "mybatis.WebServiceMapper.getGameOrder";
    public static final String GET_GAME_ORDER_COUNT = "mybatis.WebServiceMapper.getGameOrderCount";
    public static final String GET_ORDER_SUMMARY = "mybatis.WebServiceMapper.getOrderSummary";
    public static final String GET_ORDER_SUMMARY_COUNT = "mybatis.WebServiceMapper.getOrderSummaryCount";
    public static final String GET_GAMES = "mybatis.WebServiceMapper.getGames";
    public static final String GET_GAMES_PALYWAYS = "mybatis.WebServiceMapper.getGameTypeAndPlayType";
    public static final String GET_ORDER_BY_VIDEO = "mybatis.WebServiceMapper.getOrderByVideo";
    public static final String GET_TRANSFER_SUM_GROUP = "mybatis.WebServiceMapper.getTransferAmountGroup";
    /**
     * DB TEST
     */
    public static final String TEST_READ_CONNECTION = "mybatis.WebServiceMapper.testReadConnection";
    public static final String TEST_WRITE_CONNECTION = "mybatis.WebServiceMapper.testWriteConnection";

    /**
     * AGQJ串改注单
     */
    public static final String GET_ORDER_AGQJ_EXCEPTIONOR = "mybatis.WebServiceMapper.getAGQJExceptionorList";

    public static final String GET_CUSTOMER_BY_PLATFORM_AND_GAMEKIND = "mybatis.WebServiceMapper.getCustomerByPlatformAndGameKind";
    public static final String ORDER_GET_ATTENDANCEPROMO_LIST = "mybatis.WebServiceMapper.getAttendancePromoList";
    public static final String GET_ACTIVITY_ENTITY_LIST = "mybatis.WebServiceMapper.getActivityEntityList";
    public static final String GET_ACTIVITY_ENTITY_TOTAL_RECORDS = "mybatis.WebServiceMapper.getActivityToalRecords";
    public static final String ORDER_GET_LIST_BY_DEVICE_TYPE ="mybatis.WebServiceMapper.getHighProfitOrderListByDeviceType";
    public static final String GET_ELIGIBILITY_BY_CONCESSIONS = "mybatis.WebServiceMapper.getEligibilityOrderByConcessions";
    public static final String GET_CUSTOMER_DYNAMIC ="mybatis.WebServiceMapper.getCustomerDynamic";
    public static final String ORDER_GET_WAGER_SUMMARY ="mybatis.WebServiceMapper.getWagerSummary";

    /**
     * 修改主账号信息
     */
    public static final String UPDATE_CUSTOMER_MAIN_LOGIN_NAME ="mybatis.CustomerMapper.updateCustomerMainLoginName";

    public static final String ORDER_GET_PLAYER_PLATFORM_PROFIT = "mybatis.WebServiceMapper.getPlayerPlatformProfit";

    /**
     * 旗舰厅注单列表
     */
    public static final String GET_AG_LIS_ORDER = "mybatis.WebServiceMapper.getAgListOrder";

    /**
     * 注单排行榜Top20
     */
    public static final String ORDER_GET_PROFIGS = "mybatis.WebServiceMapper.getProfits";
}
