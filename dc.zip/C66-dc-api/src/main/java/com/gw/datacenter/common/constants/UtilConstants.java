package com.gw.datacenter.common.constants;


import java.util.LinkedHashMap;
import java.util.Map;

public class UtilConstants {
    public static final int ONE = 1;
    public static final int PAGE_SIEZE = 25;
    public static final String FROM_ROWNUMBER = "fromRowNum";
    public static final String TO_ROWNUMBER = "toRowNum";
    public static final String COMMA_SYMBOL = ",";
    public static final String ONE_STR = "1";
    public static final String VERTICAL = "|";
    public static final String SUFFIX = "feas!#%";
    public static final String GLOBAL_PLATFORMID_KEY = "platformid";
    public static final String DATA_FLAG = "flag";
    public static final String AGIN = "026";
    public static final String CB = "030";
    public static final String AP = "044";
    public static final String AG = "003";
    public static final String HOGAME = "008";
    public static final String GAME_KIND = "gameKind";
    public static final String GAME_NAME = "gameName";
    public static final String TIMEZONE_GMT_E8 = "Etc/GMT-8"; // BeiJing Time
    public static final String EXPORT_FLAG = "exportFlag";//导出类型
    public final static int DATA_QUERY_DAYS_LIMIT = 63;//跨日限制63天(两个月，防止临界点)
    public final static int XM_DELAY_THRESHOLD = 30000;//接口数据延迟时间
    public static final String PREFIX_TIME_STRING = " 00:00:00";
    public static final String SUFFIX_TIME_STRING = " 23:59:59";
    public static Map<String, String> PROJECT_INFO = new LinkedHashMap<>();

}
