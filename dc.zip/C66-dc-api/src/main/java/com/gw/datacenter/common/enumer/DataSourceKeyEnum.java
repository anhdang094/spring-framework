package com.gw.datacenter.common.enumer;


public enum DataSourceKeyEnum {
    /**
     * read data source key.
     */
    read,
    /**
     * write data source key.
     */
    write

}
