package com.gw.datacenter.common.enumer;

import lombok.Getter;

/**
 * title: ErrorCode
 * description: TODO
 * author: Jair.H
 * date: 2018/10/24 19:28
 */
public enum ErrorCode {
    FAIL(0,"FAIL"),
    SUCCESS(1,"SUCCESS");

    @Getter
    private int code;
    @Getter
    private String msg;

    ErrorCode(int code,String msg) {
        this.code = code;
        this.msg = msg;
    }

}
