
package com.gw.datacenter.common.exception;

/**
 * @author alex.l
 *
 */
public class GWDataCenterException extends Exception {

	private static final long serialVersionUID = -5269268491371483764L;

	/**
	 *  Constructs a new exception with <code>null</code> as its
     * detail message.
	 */
	public GWDataCenterException(){
		super();
	}
	
	/**
	 * Constructs a new exception with the specified detail message.
	 * @param message
	 */
	public GWDataCenterException(String message){
		super(message);
	}
	
	/**
	 * Constructs a new exception with the specified detail message and
     * cause
	 * @param message
	 * @param cause
	 */
	public GWDataCenterException(String message, Throwable cause){
		super(message,cause);
	}
	
	/**
	 * Constructs a new runtime exception with the specified cause.
	 * @param cause
	 */
	public GWDataCenterException(Throwable cause){
		super(cause);
	}
}
