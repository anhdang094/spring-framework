/**
 * 
 */
package com.gw.datacenter.common.exception;

/**
 * @author alex.l
 *
 */
public class GWKeyErrorException extends Exception {
	
	private static final long serialVersionUID = -7969706113224437405L;

	/**
	 * For Md5Util validation
	 * @param message
	 */
	public GWKeyErrorException(String message){
		super(message);
	}
}
