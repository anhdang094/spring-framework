/**
 * 
 */
package com.gw.datacenter.common.exception;

/**
 * @author alex.l
 *
 */
public class GWPersistenceException extends Exception {

	private static final long serialVersionUID = 890318760035132771L;
	
	/**
	 * 
	 * @param message
	 * @param cause
	 */
	public GWPersistenceException(String message, Throwable cause){
		super(message,cause);
	}
	
	/**
	 * 
	 * @param message
	 */
	public GWPersistenceException(String message){
		super(message);
	}
	
	public GWPersistenceException(){
		super();
	}	
}
