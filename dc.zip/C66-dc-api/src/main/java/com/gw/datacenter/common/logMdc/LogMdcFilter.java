package com.gw.datacenter.common.logMdc;

import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.UUID;

/**
 * title: Slf4jMDCFilter
 * description: TODO
 * author: Jair.H
 * date: 2018/11/19 12:40
 */
@Component
public class LogMdcFilter extends OncePerRequestFilter implements Filter {
    @Override
    protected void doFilterInternal(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, FilterChain filterChain) throws ServletException, IOException {
        try {
            MDC.put("ticket", UUID.randomUUID().toString().replace("-", ""));
            filterChain.doFilter(httpServletRequest, httpServletResponse);
        } finally {
            MDC.remove("ticket");
        }
    }
}