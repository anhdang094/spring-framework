package com.gw.datacenter.common.property;

import lombok.Data;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * title: TableListProperty
 * description: TODO
 * author: Jair.H
 * date: 2018/10/31 14:12
 */
@Component
@ConfigurationProperties
@Data
public class ReadTablesProperty {
	@Value("${readTables}")
    private String readTables;
    private List<String> readTablesList = new ArrayList<>();

    public List<String> getReadTablesList() {
        if (StringUtils.isNotBlank(readTables)) {
            readTablesList = Arrays.asList(readTables.split(","));
        }
        return readTablesList;
    }
}


