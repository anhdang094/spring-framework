package com.gw.datacenter.common.util;

import com.gw.datacenter.common.cache.DataCache;
import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.vo.gametypeplaytype.GameTypePlayTypeEntity;
import com.gw.datacenter.vo.order.OrderEntity;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * title: DataUtil
 * description: TODO
 * author: Jair.H
 * date: 2018/10/30 12:06
 */
@Slf4j
public class DataUtil {

    public static String getPlatform(String productionId, String pid) {
        String platformId = pid;
        if ("006".equals(pid)) {
            if ("A01".equalsIgnoreCase(productionId)) {
                platformId = "006";
            } else if ("A02".equalsIgnoreCase(productionId)) {
                platformId = "007";
            } else if ("A03".equalsIgnoreCase(productionId)) {
                platformId = "017";
            } else if ("A04".equalsIgnoreCase(productionId)) {
                platformId = "010";
            } else if ("A05".equalsIgnoreCase(productionId)) {
                platformId = "012";
            } else if ("A06".equalsIgnoreCase(productionId)) {
                platformId = "024";
            } else if ("C01".equalsIgnoreCase(productionId)) {
                platformId = "013";
            } else if ("C02".equalsIgnoreCase(productionId)) {
                platformId = "020";
            }
        }
        return platformId;
    }

    public static boolean isInQueryRange(String beginTime, String endTime) {
        if (StringUtils.isBlank(beginTime) || StringUtils.isBlank(endTime)) {
            log.error("beginTime or endTime is null or empty,beginTime-endTime:{}-{}", beginTime, endTime);
            return false;
        }
        long diff = DateUtil.calcDiffDays(beginTime, endTime);
        return diff <= UtilConstants.DATA_QUERY_DAYS_LIMIT;
    }

    public static String matchTimeZoneTime(String time, String pattern, String timeZoneId) {
        if (StringUtils.isBlank(timeZoneId) || UtilConstants.TIMEZONE_GMT_E8.equalsIgnoreCase(timeZoneId)) {
            return time;
        } else {
            return DateUtil.formatToSecond(DateUtil.parseTimeZone(time, pattern, timeZoneId));
        }
    }

    public static String getGameName(OrderEntity order) {
        String platfromId = order.getPlatformId();
        if (StringUtils.isBlank(platfromId)) {
            platfromId = order.getPlatId();
        }
        String gameType = order.getGameType();
        //playformId=004 或 005 时，gameType 是 orders_xxx表的gameCode字段值
        if ("004".equals(platfromId) || "005".equals(platfromId)) {
            gameType = order.getGmCode();
        }
        GameTypePlayTypeEntity cache = DataCache.getCacheGameTypeEntity(platfromId, gameType);
        return cache != null ? cache.getChineseName() : "";
    }
}
