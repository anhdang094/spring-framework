package com.gw.datacenter.common.util;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.FastDateFormat;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.ConcurrentHashMap;

/**
 * title: DateUtil
 * description: TODO
 * author: Jair.H
 * date: 2018/11/7 15:14
 */
public class DateUtil {
    public static final String UnitePattern_day = "yyyy-MM-dd";
    public static final String UnitePattern_minute = "yyyy-MM-dd HH:mm";
    public static final String UnitePattern_second = "yyyy-MM-dd HH:mm:ss";
    public static final String UnitePattern_nano = "yyyy-MM-dd HH:mm:ss.SSS";
    public static final String UnitePattern_time = UnitePattern_nano;
    public static final String UnitePattern_onlytime = "HH:mm:ss";
    public static final long Day_millis = 24 * 60 * 60 * 1000;
    public static final long Hour_millis = 60 * 60 * 1000;

    private static Map<String, FastDateFormat> dateFormatCache = new ConcurrentHashMap<>();



    public static String formatToDay(Date date) {
        return format(date, UnitePattern_day);
    }

    public static String formatToDay() {
        return formatToDay(new Date());
    }

    public static String formatToMinute(Date date) {
        return format(date, UnitePattern_minute);
    }

    public static String formatToMinute() {
        return formatToMinute(new Date());
    }

    public static String formatToSecond(Date date) {
        return format(date, UnitePattern_second);
    }

    public static String formatToSecond() {
        return formatToSecond(new Date());
    }

    public static String formatToUniteTime(Date date) {
        return format(date, UnitePattern_time);
    }

    public static String formatToUniteTime() {
        return formatToUniteTime(new Date());
    }

    public static String formatToOnlytime(Date date) {
        return format(date, UnitePattern_onlytime);
    }

    public static String formatToOnlytime() {
        return formatToOnlytime(new Date());
    }

    public static String format(Date date, String pattern) {
        if (date == null) {
            return null;
        }
        return getFormat(pattern).format(date);
    }

    private static FastDateFormat getFormat(String pattern) {
        FastDateFormat format = dateFormatCache.get(pattern);
        if (format == null) {
            format = FastDateFormat.getInstance(pattern);
            dateFormatCache.put(pattern, format);
        }
        return format;
    }

    private static FastDateFormat getFormatTimeZone(String pattern, String timeZoneId) {
        FastDateFormat format = dateFormatCache.get(pattern+timeZoneId);
        if (format == null) {
            format = FastDateFormat.getInstance(pattern,TimeZone.getTimeZone(timeZoneId));
            dateFormatCache.put(pattern+timeZoneId, format);
        }
        return format;
    }

    public static Date parse(String date, String pattern) {
        try {
            return getFormat(pattern).parse(date);
        } catch (ParseException e) {
            return null;
        }
    }

    public static Date parseSecond(String date) {
        try {
            return getFormat(UnitePattern_second).parse(date);
        } catch (ParseException e) {
            return null;
        }
    }

    public static Date parseTimeZone(String date, String pattern, String timeZoneId) {
        try {
            if(StringUtils.isBlank(timeZoneId)){
                return getFormat(pattern).parse(date);
            }
            return getFormatTimeZone(pattern,timeZoneId).parse(date);
        } catch (ParseException e) {
            return null;
        }
    }

    public static long calcDiffDays(String firstDate, String secondDate) {
        Date d1=parseSecond(firstDate);
        Date d2=parseSecond(secondDate);
        return Math.abs((d2.getTime()- d1.getTime())/Day_millis)+1;
    }

    public static int calcDiffHours(String firstDate) {
        Date d1=parseSecond(firstDate);
        return (int)((System.currentTimeMillis()- d1.getTime())/Hour_millis)+1;
    }
}
