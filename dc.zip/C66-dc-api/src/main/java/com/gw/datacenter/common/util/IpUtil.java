package com.gw.datacenter.common.util;

import javax.servlet.http.HttpServletRequest;

public class IpUtil {
    
    private static final String[] IP_HEADERS = { "x-forwarded-for", "X-Real-IP", "Proxy-Client-IP", "WL-Proxy-Client-IP" };

    public static String getIpAddr(HttpServletRequest request) {
        for(String header : IP_HEADERS) {
            String ip = request.getHeader(header);
            if("x-forwarded-for".equalsIgnoreCase(header) && ip != null && !"unknown".equalsIgnoreCase(ip)) {
            	String[] ips = ip.split(",");
            	for(String temp : ips) {
            		if(isValid(temp)) {
                        return temp;
                    }
            	}
            }
            if(isValid(ip)) {
                return ip;
            }
        }
        return request.getRemoteAddr();
    }
    
    private static boolean isValid(String ipAddr) {
        return !(ipAddr == null || ipAddr.length() == 0 || ipAddr.equalsIgnoreCase("unknown"));
    }
}
