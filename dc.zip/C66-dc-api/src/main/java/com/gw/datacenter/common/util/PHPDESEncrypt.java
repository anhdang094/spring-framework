package com.gw.datacenter.common.util;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.Random;

@Deprecated
public class PHPDESEncrypt {
    String key;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    /**
     * 根据类型实例化加密类
     *
     * @param productId
     * @param type
     * @param type      01:真实姓名 02:地址 03:电话 04:邮件 05:网络联系方式 06:帐户名 07:帐号 08:存款人
     *                  (预留校验码以真实姓名加密,身份证以电话加密,问题答案以地址加密)
     * @author sky.x
     */
    public PHPDESEncrypt(String productId, String type) {
        StringBuffer tempKey = new StringBuffer("");
        if (null == type || "".equals(type)) {
            tempKey.append(productId).append(productId).append(productId);
        }

        this.key = tempKey.toString();
    }

    public byte[] desEncrypt(byte[] plainText) throws Exception {
        SecureRandom sr = new SecureRandom();
        DESKeySpec dks = new DESKeySpec(key.getBytes());
        SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
        SecretKey key = keyFactory.generateSecret(dks);
        Cipher cipher = Cipher.getInstance("DES");
        cipher.init(Cipher.ENCRYPT_MODE, key, sr);
        byte data[] = plainText;
        byte encryptedData[] = cipher.doFinal(data);
        return encryptedData;
    }

    public byte[] desDecrypt(byte[] encryptText) throws Exception {
        SecureRandom sr = new SecureRandom();
        DESKeySpec dks = new DESKeySpec(key.getBytes());
        SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
        SecretKey key = keyFactory.generateSecret(dks);
        Cipher cipher = Cipher.getInstance("DES");
        cipher.init(Cipher.DECRYPT_MODE, key, sr);
        byte encryptedData[] = encryptText;
        byte decryptedData[] = cipher.doFinal(encryptedData);
        return decryptedData;
    }

    /**
     * 加密
     *
     * @param input
     * @return String
     * @author sky.x
     */
    public String encrypt(String input) throws Exception {
        if (null == input || "".equals(input.trim())) {
            return input;
        }
        String str1 = getRandomNum(1);
        String str2 = getRandomStr(str1, 2);
        String str3 = getRandomStr(str1, 3);
        StringBuffer sb = new StringBuffer(str2);
        sb.append(base64Encode(desEncrypt(input.getBytes())));
        sb.append(str3);
        return sb.toString();
    }

    /**
     * 解密
     *
     * @param input
     * @return String
     * @author sky.x
     */
    public String decrypt(String input) throws Exception {
        if (null == input || "".equals(input.trim())) {
            return input;
        }
        input = input.substring(3, input.length() - 4);
        byte[] result = base64Decode(input);
        return new String(desDecrypt(result));
    }

    public String base64Encode(byte[] s) {
        if (s == null)
            return null;
        BASE64Encoder b = new BASE64Encoder();
        return b.encode(s);
    }

    public byte[] base64Decode(String s) throws IOException {
        if (s == null) {
            return null;
        }
        BASE64Decoder decoder = new BASE64Decoder();
        byte[] b = decoder.decodeBuffer(s);
        return b;
    }


    /**
     * 生成随机字符串
     *
     * @param prefix     前缀
     * @param bodyLength 前缀后 字符串长度
     * @return 帐号
     */
    public String getRandomStr(String prefix, int bodyLength) {
        char[] c = {'1', '2', '3', '4', '5', '6', '7', '8', '9', '0', 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', 'a', 's', 'd', 'f', 'g',
                'h', 'j', 'k', 'l', 'z', 'x', 'c', 'b', 'n', 'm', 'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', 'A', 'S', 'D', 'F', 'G', 'H',
                'J', 'K', 'L', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', '='};
        Random random = new Random(); // 初始化随机数产生器
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < bodyLength; i++) {
            sb.append(c[Math.abs(random.nextInt(10000)) % c.length]);
        }
        return prefix + sb.toString();
    }

    /**
     * 生成随机由数字组成的字符串
     *
     * @param bodyLength 字符串长度
     * @return
     */
    public String getRandomNum(int bodyLength) {
        Random random = new Random();
        String sRand = "";
        for (int i = 0; i < bodyLength; i++) {
            String rand = String.valueOf(random.nextInt(10));
            sRand += rand;
        }
        return sRand;
    }

}
