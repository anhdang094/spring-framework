package com.gw.datacenter.common.util;

import com.gw.datacenter.common.exception.GWKeyErrorException;
import com.gw.datacenter.common.exception.GWPersistenceException;
import com.gw.datacenter.vo.order.PlatformGameKinds;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;

/**
 * title: ParamCheckUtil
 * description: TODO
 * author: Jair.H
 * date: 2018/11/14 14:30
 */
@Slf4j
public class ParamCheckUtil {

    private static final String WEBSERVICE_ERROR_PRODUCT = "invalid productId,the parameter productId can't be null!";
    private static final String WEBSERVICE_ERROR_PLATFORM = "invalid platformId,the parameter platformId can't be null!";
    private static final String WEBSERVICE_ERROR_PLATFORMGAMEKINDS = "invalid platform(PlatformGameKinds),the parameter platform can't be null!";
    private static final String WEBSERVICE_ERROR_GAMEKIND = "invalid gameKind,the parameter gameKind can't be null!";
    private static final String WEBSERVICE_ERROR_RESULTTYPE = "invalid resultType,the parameter resultType can't be null!";
    private static final String WEBSERVICE_ERROR_RANK = "invalid rank,the parameter rank can't be null!";
    private static final String WEBSERVICE_ERROR_BEGINTIME = "invalid beginTime,the parameter beginTime can't be null!";
    private static final String WEBSERVICE_ERROR_ENDTIME = "invalid endTime,the parameter endTime can't be null!";
    private static final String WEBSERVICE_ERROR_BEGINDATE = "invalid beginTime,the parameter beginDate can't be null!";
    private static final String WEBSERVICE_ERROR_ENDDATE = "invalid endTime,the parameter endDate can't be null!";
    private static final String WEBSERVICE_ERROR_WEEKBEGINTIME = "invalid weekBeginTime,the parameter weekBeginTime can't be null!";
    private static final String WEBSERVICE_ERROR_WEEKENDTIME = "invalid weekEndTime,the parameter weekEndTime can't be null!";
    private static final String WEBSERVICE_ERROR_GAMECODE = "invalid gameCode,the parameter gameCode can't be null!";
    private static final String WEBSERVICE_ERROR_LOGINNAME = "invalid loginName,the parameter loginName can't be null!";
    private static final String WEBSERVICE_ERROR_CURRENCY = "invalid currency,the parameter currency can't be null!";
    private static final String WEBSERVICE_ERROR_LOGINNAMEARRAY = "invalid loginNameArray,the parameter loginNameArray can't be null!";
    private static final String WEBSERVICE_ERROR_TYPE = "invalid type,the parameter type can't be null!";
    private static final String WEBSERVICE_ERROR_TIMES = "invalid times,the parameter times can't be null!";
    private static final String WEBSERVICE_ERROR_MINAMOUNT = "invalid minAmount,the parameter minAmount can't be null!";
    private static final String WEBSERVICE_ERROR_VALIDAMOUNT = "invalid validAmount,the parameter validAmount can't be null!";
    private static final String WEBSERVICE_ERROR_MULTIPLE = "invalid multiple,the parameter multiple can't be null!";
    private static final String WEBSERVICE_ERROR_CUSAMOUNT = "invalid cusAmount,the parameter cusAmount can't be null!";
    private static final String WEBSERVICE_ERROR_MAXRECODE = "invalid maxRecode,the parameter maxRecode can't be null!";
    private static final String WEBSERVICE_ERROR_LISTCOUNT = "invalid listCount,the parameter listCount can't be null!";
    private static final String WEBSERVICE_ERROR_MAXFIELD = "invalid maxField,the parameter maxField can't be null!";
    private static final String WEBSERVICE_ERROR_GROUPFIELD = "invalid groupField,the parameter groupField can't be null!";
    private static final String WEBSERVICE_ERROR_LIMIT = "invalid limit,the parameter limit can't be null!";
    private static final String WEBSERVICE_ERROR_TOP = "invalid top,the parameter top can't be null!";
    private static final String WEBSERVICE_ERROR_PAGENO = "invalid pageNo,the parameter pageNo can't be null!";
    private static final String WEBSERVICE_ERROR_PAGESIZE = "invalid pageSize,the parameter pageSize can't be null!";
    private static final String WEBSERVICE_ERROR_DATARANGE = "invalid date,endTime must greater or equal than beginTime!";
    private static final String WEBSERVICE_ERROR_FLAG = "invalid flag,flag must be 0 or 1!";
    private static final String WEBSERVICE_ERROR_SETTLEDTYPE = "invalid settledType,settledType can be null or 0 or 1!";
    private static final String WEBSERVICE_ERROR_KEY = "Key error while calling remote API! Kindly check your key please!";
    private static final String WEBSERVICE_ERROR_BETMIN= "invalid betMin,the parameter betMin can't be null!";
    private static final String WEBSERVICE_ERROR_WINMIN= "invalid winMin,the parameter winMin can't be null!";
    private static final String WEBSERVICE_ERROR_SIZE= "invalid size,the parameter size can't be null!";
    private static final String WEBSERVICE_ERROR_QUERYTYPE = "invalid queryType,the parameter top can't be null!";
    private static final String WEBSERVICE_ERROR_DATE_RANGE = "invalid date range,the date range must less than 32 days";
    public static final String WEBSERVICE_ERROR_FIELD_ORDER = "invalid field order,can't find specific column";

    public static void checkProductId(String productId) throws GWPersistenceException {
        if (StringUtils.isBlank(productId)) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_PRODUCT);
        }
    }

    public static void checkPlatformId(String platformId) throws GWPersistenceException {
        if (StringUtils.isBlank(platformId)) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_PLATFORM);
        }
    }

    public static void checkPlatformGameKinds(PlatformGameKinds[] platform) throws GWPersistenceException {
        if (platform==null || platform.length==0) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_PLATFORMGAMEKINDS);
        }
    }

    public static void checkBeginTime(String beginTime) throws GWPersistenceException {
        if (StringUtils.isBlank(beginTime)) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_BEGINTIME);
        }
    }

    public static void checkEndTime(String endTime) throws GWPersistenceException {
        if (StringUtils.isBlank(endTime)) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_ENDTIME);
        }
    }

    public static void checkBeginDate(String beginDate) throws GWPersistenceException {
        if (StringUtils.isBlank(beginDate)) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_BEGINDATE);
        }
    }

    public static void checkEndDate(String endDate) throws GWPersistenceException {
        if (StringUtils.isBlank(endDate)) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_ENDDATE);
        }
    }

    public static void checkWeekBeginTime(String beginTime) throws GWPersistenceException {
        if (StringUtils.isBlank(beginTime)) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_WEEKBEGINTIME);
        }
    }

    public static void checkWeekEndTime(String endTime) throws GWPersistenceException {
        if (StringUtils.isBlank(endTime)) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_WEEKENDTIME);
        }
    }

    public static void checkResultType(Integer resultType) throws GWPersistenceException {
        if (resultType == null) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_RESULTTYPE);
        }
    }

    public static void checkRank(Integer rank) throws GWPersistenceException {
        if (rank == null) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_RANK);
        }
    }

    public static void checkKey(String calcKey, String key) throws GWKeyErrorException {
        if (!calcKey.equalsIgnoreCase(key)) {
            log.error("MD5 key error,right key is:" + calcKey);
            throw new GWKeyErrorException(WEBSERVICE_ERROR_KEY);
        }
    }

    public static void checkGameCode(String gameCode) throws GWPersistenceException {
        if (StringUtils.isBlank(gameCode)) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_GAMECODE);
        }
    }

    public static void checkLoginName(String loginName) throws GWPersistenceException {
        if (StringUtils.isBlank(loginName)) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_LOGINNAME);
        }
    }

    public static void checkCurrency(String currency) throws GWPersistenceException {
        if (StringUtils.isBlank(currency)) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_CURRENCY);
        }
    }

    public static void checkDateRange(String beginTime, String endTime) throws GWPersistenceException {
        boolean isQueryInRange = DataUtil.isInQueryRange(beginTime, endTime);
        if (!isQueryInRange) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_DATE_RANGE);
        }
    }

    public static void checkLoginNameArray(String[] loginNameArray) throws GWPersistenceException {
        if (ArrayUtils.isEmpty(loginNameArray)) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_LOGINNAMEARRAY);
        }
    }

    public static void checkType(Integer type) throws GWPersistenceException {
        if (type == null) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_TYPE);
        }
    }

    public static void checkDataRange(long dataRange) throws GWPersistenceException {
        if (dataRange < 0) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_DATARANGE);
        }
    }

    public static void checkPlatforms(String[] platformId) throws GWPersistenceException {
        if (ArrayUtils.isEmpty(platformId)) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_PLATFORM);
        }
    }

    public static void checkGameKinds(String[] gameKind) throws GWPersistenceException {
        if (ArrayUtils.isEmpty(gameKind)) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_GAMEKIND);
        }
    }

    public static void checkTimes(Integer times) throws GWPersistenceException {
        if (times == null) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_TIMES);
        }
    }

    public static void checkMinAmount(Integer minAmount) throws GWPersistenceException {
        if (minAmount == null) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_MINAMOUNT);
        }
    }

    public static void checkValidAmount(Integer validAmount) throws GWPersistenceException {
        if (validAmount == null) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_VALIDAMOUNT);
        }
    }

    public static void checkMultiple(Integer multiple) throws GWPersistenceException {
        if (multiple == null) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_MULTIPLE);
        }
    }

    public static void checkCusAmount(Integer cusAmount) throws GWPersistenceException {
        if (cusAmount == null) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_CUSAMOUNT);
        }
    }

    public static void checkMaxRecode(Integer maxRecode) throws GWPersistenceException {
        if (maxRecode == null) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_MAXRECODE);
        }
    }

    public static void checkListCount(Integer listCount) throws GWPersistenceException {
        if (listCount == null) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_LISTCOUNT);
        }
    }

    public static void checkFlag(Integer flag) throws GWPersistenceException {
        if (flag == null || flag < 0 || flag > 1) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_FLAG);
        }
    }

    public static void checkSettledType(String settledType) throws GWPersistenceException {
        if (StringUtils.isNotBlank(settledType) && (!"1".equals(settledType) && !"0".equals(settledType))) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_SETTLEDTYPE);
        }
    }

    public static void checkMaxField(String maxField) throws GWPersistenceException {
        if (StringUtils.isEmpty(maxField)) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_MAXFIELD);
        }
    }

    public static void checkGroupField(String groupField) throws GWPersistenceException {
        if (StringUtils.isBlank(groupField)) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_GROUPFIELD);
        }
    }

    public static void checkLimit(String limit) throws GWPersistenceException {
        if (StringUtils.isBlank(limit)) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_LIMIT);
        }
    }

    public static void checkTop(Integer top) throws GWPersistenceException {
        if (top == null) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_TOP);
        }
    }

    public static void checkBetMin(BigDecimal betMin) throws GWPersistenceException {
        if (betMin == null) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_LISTCOUNT);
        }
    }

    public static void checkWinMin(BigDecimal winMin) throws GWPersistenceException {
        if (winMin == null) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_WINMIN);
        }
    }

    public static void checkSize(Integer size) throws GWPersistenceException {
        if (size == null) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_SIZE);
        }
    }

    public static void checkPageNo(Integer pageNo) throws GWPersistenceException {
        if (pageNo == null) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_PAGENO);
        }
    }

    public static void checkPageSize(Integer pageSize) throws GWPersistenceException {
        if (pageSize == null) {
            throw new GWPersistenceException(WEBSERVICE_ERROR_PAGESIZE);
        }
    }

    public static void checkQueryType(String queryType) throws GWPersistenceException{
        if(StringUtils.isBlank(queryType)){
            throw new GWPersistenceException(WEBSERVICE_ERROR_QUERYTYPE);
        }
    }
}
