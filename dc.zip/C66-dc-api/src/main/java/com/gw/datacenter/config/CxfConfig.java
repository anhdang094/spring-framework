package com.gw.datacenter.config;

import com.gw.datacenter.cxf.DataCenterApi;
import org.apache.cxf.Bus;
import org.apache.cxf.jaxws.EndpointImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.annotation.Resource;
import javax.xml.ws.Endpoint;

/**
 * title: CxfConfig
 * description: cxf webservice
 * author: Jair.H
 * date: 2018/10/25 14:53
 */
@Configuration
public class CxfConfig {
    @Resource
    private Bus bus;
    @Resource
    private DataCenterApi dataCenterApi;

    @Bean
    public Endpoint endpoint() {
        EndpointImpl endpoint = new EndpointImpl(bus, dataCenterApi);// 绑定要发布的服务实现类
        endpoint.publish("/GWDataCenterService"); // 接口访问地址
        return endpoint;
    }
}
