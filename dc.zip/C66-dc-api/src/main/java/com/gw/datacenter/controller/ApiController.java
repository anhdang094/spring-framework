package com.gw.datacenter.controller;

import com.google.common.base.Throwables;
import com.gw.datacenter.common.enumer.ErrorCode;
import com.gw.datacenter.controller.request.ApiRequest;
import com.gw.datacenter.controller.request.GetOrderSummaryGroupByPlatGameUnRequest;
import com.gw.datacenter.controller.result.ApiResult;
import com.gw.datacenter.controller.result.GetOrderSummaryGroupByPlatGameUnResponse;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.service.DataCenterApiService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * title: ApiController
 * description: TODO
 * author: Jair.H
 * date: 2018/11/5 14:08
 */
@RestController
@RequestMapping("/dcApi")
@Slf4j
public class ApiController {
    @Resource
    private DataCenterApi dataCenterApi;

    @Resource
    private DataCenterApiService dataCenterApiService;

    @RequestMapping("/getValidAmountByType")
    public ApiResult getValidAmountByType(@RequestParam(required = false) String[] gameType, ApiRequest request) {
        /*request.setProductId("A04");
        request.setLoginNameArray("mwh004");
        request.setBeginTime("2018-08-10");
        request.setEndTime("2018-10-25");
        request.setKey("8ff976148abc1df03f67e8799d2a5e0b");*/
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getValidAmountByType(request.getProductId(), request.getPlatformId(), request.getValidAccount(),
                    request.getTimeZoneId(), request.getLoginNameArray(), request.getBeginTime(), request.getEndTime(), StringUtils.isNotBlank(request.getGameKind()) ? Integer.valueOf(request.getGameKind()) : null, request.getType(),
                    request.getPageNo(), request.getPageSize(), request.getKey(), request.getOrderByField(), request.getRankLoginNameList(), gameType,
                    request.getMinBetTimes(), request.getCurrency(), request.getMinCustAmount(), request.getMinValidAmount()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getWagerSummary")
    public ApiResult getWagerSummary(@RequestParam(required = false) String settleFlag, ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getWagerSummary(request.getProductId(), request.getPlatformArray(), request.getGameKindArray(), request.getLoginNames(), request.getMinBetAmount() == null ? null : String.valueOf(request.getMinBetAmount()),
                    settleFlag, request.getBeginTime(), request.getEndTime(), request.getPageNo(), request.getPageSize(), request.getKey()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getValidAmountByTypeAndFlag")
    public ApiResult getValidAmountByTypeAndFlag(ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getValidAmountByTypeAndFlag(request.getProductId(), request.getPlatformId(), request.getValidAccount(),
                    request.getTimeZoneId(), request.getLoginNameArray(), request.getBeginTime(), request.getEndTime(), StringUtils.isNotBlank(request.getGameKind()) ? Integer.valueOf(request.getGameKind()) : null, request.getType(),
                    request.getPageNo(), request.getPageSize(), request.getKey()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getOrderEntity")
    public ApiResult getOrderEntity(@RequestParam(required = false) String[] platformId, ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getOrderEntity(request.getProductId(), platformId, request.getValidAccount(),
                    request.getTimeZoneId(), request.getLoginNameArray(), request.getBeginTime(), request.getEndTime(), StringUtils.isNotBlank(request.getGameKind()) ? Integer.valueOf(request.getGameKind()) : null,
                    request.getPageNo(), request.getPageSize(), request.getKey()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getMaxEffectiveBettingAmount")
    public ApiResult getMaxEffectiveBettingAmount(ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getMaxEffectiveBettingAmount(request.getProductId(), request.getLoginNameArray(), request.getResultType(),
                    request.getBeginTime(), request.getEndTime(), request.getPageNo(), request.getPageSize(), request.getKey()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getOrderDetailsByGmCode")
    public ApiResult getOrderDetailsByGmCode(ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getOrderDetailsByGmCode(request.getProductId(), request.getLoginName(), request.getGameCode(),
                    request.getBeginTime(), request.getEndTime(), request.getPageNo(), request.getPageSize(), request.getKey()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getOrderDetailsAndSummaryByGmCode")
    public ApiResult getOrderDetailsAndSummaryByGmCode(ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getOrderDetailsAndSummaryByGmCode(request.getProductId(), request.getLoginName(), request.getGameCode(),
                    request.getBeginTime(), request.getEndTime(), request.getPageNo(), request.getPageSize(), request.getKey()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getMonthlyAndWeeklyValidAmount")
    public ApiResult getMonthlyAndWeeklyValidAmount(ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getMonthlyAndWeeklyValidAmount(request.getProductId(), request.getLoginNameArray(), request.getAmount(),
                    request.getWeekBeginTime(), request.getWeekEndTime(), request.getMonthBeginTime(), request.getMonthEndTime(), request.getKey()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getCustomerBetTime")
    public ApiResult getCustomerBetTime(ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getCustomerBetTime(request.getProductId(), request.getLoginName(), request.getType(), request.getKey()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getContinuousOrder")
    public ApiResult getContinuousOrder(@RequestParam(required = false) String[] platformId, ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getContinuousOrder(request.getProductId(), platformId, request.getBeginTime(),
                    request.getEndTime(), request.getGameKind(), request.getTimes(), request.getMinAmount(), request.getKey()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getOrderListByProfit")
    public ApiResult getOrderListByProfit(@RequestParam(required = false) String[] platformId, ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getOrderListByProfit(request.getProductId(), platformId, request.getBeginTime(),
                    request.getEndTime(), request.getMultiple(), request.getPageNo(), request.getPageSize(), request.getKey()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }


    @RequestMapping("/getHighProfitOrderList")
    public ApiResult getHighProfitOrderList(@RequestParam(required = false) String[] platformId, @RequestParam(required = false) String[] gameKind, ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getHighProfitOrderList(request.getProductId(), platformId, gameKind, request.getBeginTime(),
                    request.getEndTime(), request.getCusAmount(), request.getMultiple(), request.getPageNo(), request.getPageSize(), request.getKey()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }


    @RequestMapping("/getBetHistory")
    public ApiResult getBetHistory(@RequestParam(required = false) String[] platformId, ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getBetHistory(request.getProductId(), platformId, request.getBeginTime(),
                    request.getEndTime(), request.getFlag(), request.getCusAmount(), request.getMultiple(), request.getMaxRecode(), request.getKey()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getBestWin")
    public ApiResult getBestWin(@RequestParam(required = false) String[] platformId, ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getBestWin(request.getProductId(), platformId, request.getBeginTime(),
                    request.getEndTime(), request.getCusAmount(), request.getListCount(), request.getKey()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getOrderByMultipleAndValidAccount2")
    public ApiResult getOrderByMultipleAndValidAccount2(@RequestParam(required = false) String[] platformId, ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getOrderByMultipleAndValidAccount2(request.getProductId(), platformId, request.getBeginTime(),
                    request.getEndTime(), request.getOrderEntity(), request.getMultiple(), request.getPageNo(), request.getPageSize()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getRecord")
    public ApiResult getRecord(@RequestParam(required = false) String[] loginName,
                               @RequestParam(required = false) String[] platformId,
                               @RequestParam(required = false) String[] gameKind,
                               @RequestParam(required = false) String[] gameCode,
                               ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getRecord(request.getProductId(), platformId, loginName, gameKind,
                    request.getBeginTime(), request.getEndTime(), request.getSettledType(), request.getMinBetAmount(), request.getMinCusAmount(),
                    request.getMinMultiple(), request.getFieldsOrder(), request.getPageNo(), request.getPageSize(), request.getKey(), request.getGameType(),
                    gameCode, request.getBillNo(), request.getCurrency(), request.getRemainAmount()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getRecordSummary")
    public ApiResult getRecordSummary(@RequestParam(required = false) String[] loginName,
                                      @RequestParam(required = false) String[] platformId, @RequestParam(required = false) String[] gameKind,
                                      @RequestParam(required = false) String[] gameCode, @RequestParam(required = false) String[] gameType, ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getRecordSummary(request.getProductId(), platformId, loginName, gameKind,
                    request.getBeginTime(), request.getEndTime(), request.getSettledType(), request.getMinBetAmount(), request.getMinCusAmount(),
                    request.getMinMultiple(), request.getFieldsOrder(), request.getPageNo(), request.getPageSize(), request.getKey(), gameType,
                    gameCode, request.getRemainAmount()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(e.getMessage());
        }
        return apiResult;
    }

    @RequestMapping("/getRecordAndSummary")
    public ApiResult getRecordAndSummary(@RequestParam(required = false) String[] loginName,
                                         @RequestParam(required = false) String[] platformId, @RequestParam(required = false) String[] gameKind,
                                         @RequestParam(required = false) String[] gameCode, @RequestParam(required = false) String[] gameType, ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getRecordAndSummary(request.getProductId(), platformId, loginName, gameKind,
                    request.getBeginTime(), request.getEndTime(), request.getSettledType(), request.getMinBetAmount(), request.getMinCusAmount(),
                    request.getMinMultiple(), request.getFieldsOrder(), request.getPageNo(), request.getPageSize(), request.getKey(), gameType,
                    gameCode, request.getRemainAmount(), request.getCurrency()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getRecordMaxBy")
    public ApiResult getRecordMaxBy(@RequestParam(required = false) String[] loginName, @RequestParam(required = false) String[] platformId,
                                    @RequestParam(required = false) String[] gameKind, ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getRecordMaxBy(request.getProductId(), platformId, loginName, gameKind,
                    request.getBeginTime(), request.getEndTime(), request.getSettledType(), request.getMinBetAmount(), request.getMinCusAmount(),
                    request.getMinMultiple(), request.getFieldsOrder(), request.getMaxField(), request.getGroupField(), request.getPageNo(), request.getPageSize(),
                    request.getKey(), request.getCurrency()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getBetRank")
    public ApiResult getBetRank(@RequestParam(required = false) String[] platformId, @RequestParam(required = false) String[] gameKind, @RequestParam(required = false) Integer winListType,
                                @RequestParam(required = false) Integer minWinLostCount, ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getBetRank(request.getProductId(), platformId, gameKind, request.getLoginName(),
                    request.getBeginTime(), request.getEndTime(), winListType, minWinLostCount, request.getMinBetAmount(),
                    request.getFieldsOrder(), request.getPageSize(), request.getKey(), request.getCurrency(), request.getMinValidAmount()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getPlayerWins")
    public ApiResult getPlayerWins(ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getPlayerWins(request.getProductId(), request.getLoginName(),
                    request.getBeginTime(), request.getEndTime(), request.getPageSize(), request.getKey()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getTopWinners")
    public ApiResult getTopWinners(ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getTopWinners(request.getProductId(), request.getBeginTime(), request.getEndTime(), request.getPageSize(), request.getKey()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getSuperWins")
    public ApiResult getSuperWins(Integer realMulti, Integer realAmount, Integer sportMulti, Integer sportAmount, Integer lotteryMulti, Integer lotteryAmount,
                                  Integer slotMulti, Integer slotAmount, Integer fishMulti, Integer fishAmount, ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getSuperWins(request.getProductId(), request.getBeginTime(), request.getEndTime(),
                    realMulti, realAmount, sportMulti, sportAmount, lotteryMulti, lotteryAmount, slotMulti, slotAmount, fishMulti, fishAmount,
                    request.getPageSize(), request.getKey()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }


    @RequestMapping("/getRecordMaxAndSummaryBy")
    public ApiResult getRecordMaxAndSummaryBy(@RequestParam(required = false) String[] loginName,
                                              @RequestParam(required = false) String[] platformId,
                                              @RequestParam(required = false) String[] gameKind,
                                              ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getRecordMaxAndSummaryBy(request.getProductId(), platformId, loginName, gameKind,
                    request.getBeginTime(), request.getEndTime(), request.getSettledType(), request.getMinBetAmount(), request.getMinCusAmount(),
                    request.getMinMultiple(), request.getFieldsOrder(), request.getMaxField(), request.getGroupField(), request.getPageNo(), request.getPageSize(),
                    request.getKey(), request.getCurrency()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getBoWinList")
    public ApiResult getBoWinList(ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getBoWinList(request.getProductId(), request.getLoginName(), request.getBeginTime(), request.getEndTime(),
                    request.getPageNo(), request.getPageSize(), request.getKey()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getFirstBetList")
    public ApiResult getFirstBetList(ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getFirstBetList(request.getProductId(), request.getBeginTime(), request.getEndTime(),
                    request.getPageNo(), request.getPageSize(), request.getKey()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getAGQJDeskInfos")
    public ApiResult getAGQJDeskInfos(ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getAGQJDeskInfos(request.getProductId(), request.getBeginTime(), request.getEndTime(),
                    request.getLimit(), request.getKey()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getMaxValueGroupByShoecode")
    public ApiResult getMaxValueGroupByShoecode(@RequestParam(required = false) String[] gameType, ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getMaxValueGroupByShoecode(request.getProductId(), request.getPlatformId(), request.getLoginName(),
                    request.getVideoId(), request.getShoeCode(), request.getBeginTime(), request.getEndTime(), request.getOrderBy(),
                    request.getPageNo(), request.getPageSize(), request.getKey(), gameType, request.getMinBetTimes()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getGameResult")
    public ApiResult getGameResult(@RequestParam(required = false) String[] gameCode, ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getGameResult(request.getProductId(), request.getPlatformId(), request.getLoginName(),
                    request.getVideoId(), request.getShoeCode(), request.getBeginTime(), request.getEndTime(), request.getOrderBy(),
                    request.getPageNo(), request.getPageSize(), request.getKey(), gameCode));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getMostPopularGameRank")
    public ApiResult getMostPopularGameRank(ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getMostPopularGameRank(request.getProductId(), request.getPlatforms(), request.getTop(),
                    request.getKey(), request.getGameKind(), request.getBeginTime(), request.getEndTime()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getBetRecord")
    public ApiResult getBetRecord(ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getBetRecord(request.getProductId(), request.getPlatformId(), request.getGameKind(),
                    request.getLoginName(), request.getBeginTime(), request.getEndTime(), request.getPageSize(), request.getPageNo(), request.getKey()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getGameOrderByPage")
    public ApiResult getGameOrderByPage(ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getGameOrderByPage(request.getProductId(), request.getPlatformId(), request.getGameKind(),
                    request.getLoginName(), request.getGameType(), request.getGameCode(), request.getBeginTime(), request.getEndTime(),
                    request.getPageSize(), request.getPageNo(), request.getOrderBy(), request.getKey()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getOrderSummary")
    public ApiResult getOrderSummary(ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getOrderSummary(request.getUpdateTime(), request.getPageSize(), request.getPageNo(), request.getKey()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getGames")
    public ApiResult getGames() {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getGames());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getTransferSumGroupByType")
    public ApiResult getTransferSumGroupByType(String[] platformArray, String[] platformArrayAG, String beginTime, String endTime, String productId, String userName) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getTransferSumGroupByType(platformArray, platformArrayAG, beginTime, endTime, productId, userName));
        } catch (Exception e) {
            log.error("getTransferSumGroupByType faild " + e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(e.getMessage());
        }
        return apiResult;
    }

    @RequestMapping("/getGameTypeAndPlayType")
    public ApiResult getGameTypeAndPlayType(@RequestParam(required = false) String[] platformArray,
                                            @RequestParam(required = false) Integer type,
                                            @RequestParam(required = false) String updateTime) {
        ApiResult apiResult = new ApiResult();
        try {

            apiResult.setObjs(dataCenterApi.getGameTypeAndPlayType(platformArray, type, updateTime));
        } catch (Exception e) {
            log.error("getGameTypeAndPlayType faild " + e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getOrderByVideo")
    public ApiResult getOrderByVideo(@RequestParam(required = false) String[] loginName, @RequestParam(required = false) String[] videoId, ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getOrderByVideo(request.getProductId(), request.getPlatformId(), loginName, videoId, request.getBeginTime(), request.getEndTime(), request.getKey()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getValidAmountFromStatisticsByType")
    public ApiResult getValidAmountFromStatisticsByType(ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getValidAmountFromStatisticsByType(request.getProductId(), request.getTimeZoneId(), request.getLoginNameArray(),
                    request.getBeginDate(), request.getEndDate(), StringUtils.isNotBlank(request.getGameKind()) ? Integer.valueOf(request.getGameKind()) : null, request.getType(), request.getPageNo(), request.getPageSize(),
                    request.getKey(), request.getOrderByField()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }


    @RequestMapping("/getOrderSummaryGroupByDay")
    public ApiResult getOrderSummaryGroupByDay(String productId, String[] loginNameList, String beginDate, String endDate) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getOrderSummaryGroupByDay(productId, loginNameList, beginDate, endDate));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(e.getMessage());
        }
        return apiResult;
    }

    @RequestMapping("/getOrderSummaryGroupByPidUsername")
    public ApiResult getOrderSummaryGroupByPidUsername(@RequestParam(required = false) String[] loginNameArray, ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getOrderSummaryGroupByPidUsername(request.getProductId(), loginNameArray,
                    request.getExcludePlatformArray(), request.getBeginDate(), request.getEndDate(), request.getPageNo(), request.getPageSize(),
                    request.getKey(), request.getCurrency()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getOrderSummaryGroupByPidPlatIdUn")
    public ApiResult getOrderSummaryGroupByPidPlatIdUn(@RequestParam(required = false) String[] loginNameArray, ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getOrderSummaryGroupByPidPlatIdUn(request.getProductId(), request.getPlatformArray(), loginNameArray,
                    request.getGameKindArray(), request.getBeginDate(), request.getEndDate(), request.getPageNo(), request.getPageSize(),
                    request.getKey(), request.getCurrency()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    /****
     *  分组查询 某一个产品，某一段时间内 ，按照平台/游戏类别/用户名  分组的订单信息
     * ****/
    @RequestMapping("/getOrderSummaryGroupByPlatGameUn")
    public Map<String,Object> getOrderSummaryGroupByPlatGameUn(  GetOrderSummaryGroupByPlatGameUnRequest request) {

        Map<String,Object> returnDataMap = new HashMap<>();
        try {
            returnDataMap    = dataCenterApi.getOrderSummaryGroupByPlatGameUn(request);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            returnDataMap.put("msg", "-error-detail:"+e.toString());
            returnDataMap.put("datas", new ArrayList<>());
            returnDataMap.put("summary", new GetOrderSummaryGroupByPlatGameUnResponse());
        }
        return returnDataMap;
    }

    /**
     * @Description: 新活动系统排行榜
     * @Author: Ziv.Y
     * @Date: 2019/9/27 10:13
     */
    @RequestMapping("/getOrderSummaryGroupByPidUsername4ActivityList")
    public ApiResult getOrderSummaryGroupByPidUsername4ActivityList(ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getOrderSummaryGroupByPidUsername4ActivityList(request.getProductId(), request.getPlatformArray(),
                    request.getGameKindArray(), request.getGameTypeArray(), request.getBeginDate(), request.getEndDate(), request.getMinSumAmount(), request.getCurrency(),
                    request.getRank(), request.getFieldsOrder(), request.getKey()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getOrdersSumGroupByLoginName")
    public ApiResult getOrdersSumGroupByLoginName(@RequestParam(required = false) String[] loginNameArray, ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getOrdersSumGroupByLoginName(request.getProductId(), loginNameArray, request.getPlatformArray(),
                    request.getGameKindArray(), request.getBeginTime(), request.getEndTime(), request.getPageNo(), request.getPageSize()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getMGAndTTGAbnormalData")
    public ApiResult getMGAndTTGAbnormalData(ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getMGAndTTGAbnormalData(request.getLoginName(), request.getProductId(), request.getBeginDate(),
                    request.getEndDate(), request.getPageNo(), request.getPageSize(), request.getKey()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getOrdersRemainGroupList")
    public ApiResult getOrdersRemainGroupList(@RequestParam(required = false) String[] loginNameArray, ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getOrdersRemainGroupList(request.getProductId(), loginNameArray, request.getPlatformAndGameKindList(),
                    request.getBeginTime(), request.getEndTime()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getOrdersAGQJExceptionor")
    public ApiResult getOrdersAGQJExceptionor(@RequestParam(required = false) String[] loginNameArray, ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getOrdersAGQJExceptionor(request.getProductId(), request.getLoginName(), request.getBeginTime(), request.getEndTime(), request.getKey()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getCustomerByPlatformAndGameKind")
    public ApiResult getCustomerByPlatformAndGameKind(ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getCustomerByPlatformAndGameKind(request.getLoginName(), request.getPlatform(), request.getBeginTime(), request.getEndTime(), request.getKey()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getAttendancePromoList")
    public ApiResult getAttendancePromoList(ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getAttendancePromoList(request.getProductId(), request.getPlatformId(), request.getLoginNameArray(),
                    request.getBeginTime(), request.getEndTime(), request.getPageNo(), request.getPageSize(), request.getKey()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getActivityOrderRecords")
    public ApiResult getActivityOrderRecords(ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getActivityOrderRecords(request.getProductId(), request.getPlatformId(), request.getLoginNameArray(), request.getGameType(),
                    request.getBeginTime(), request.getEndTime(), request.isWinBetOnly(), request.getPageNo(), request.getPageSize(), request.getKey()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getHighProfitOrderListByDeviceType")
    public ApiResult getHighProfitOrderListByDeviceType(@RequestParam(required = false) String[] platformId,
                                                        @RequestParam(required = false) String[] gameKind,
                                                        ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getHighProfitOrderListByDeviceType(request.getProductId(), platformId, gameKind,
                    request.getBeginTime(), request.getEndTime(), request.getMinBetAmount(), request.getCusAmount(), request.getMultiple(),
                    request.getPageNo(), request.getPageSize(), request.getKey(), request.getDeviceType()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getCustomerDynamic")
    public ApiResult getCustomerDynamic(ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getCustomerDynamic(request.getProductId(), request.getBeginTime(), request.getEndTime(), request.getBetMin(),
                    request.getWinMin(), request.getSize(), request.getCurrency(), request.getKey()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/getEligibilityOrderByConcessions")
    public ApiResult getEligibilityOrderByConcessions(@RequestParam(required = false) String[] platformId,
                                                      @RequestParam(required = false) String[] gameKind,
                                                      ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getEligibilityOrder(request.getProductId(), platformId, gameKind, request.getLoginNames(), request.getMinBetAmount(), request.getQueryType(), request.getKey(),
                    request.getBeginTime(), request.getEndTime(), request.getPageNo(), request.getPageSize()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/updateCustomerMainLoginName")
    public ApiResult updateCustomerMainLoginName(ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            dataCenterApi.updateCustomerMainLoginName(request.getProductId(), request.getLoginName(), request.getMainLoginName());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;

    }
    //-----------------------
    @RequestMapping("/getAgListOrder")
    public ApiResult getAgListOrder(@RequestParam(required = false) String[] gameKind,ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs( dataCenterApi.getAgListOrder(request.getProductId(), request.getLoginNames(),gameKind,
                    request.getCurrency(),request.getBeginTime(),request.getEndTime(),request.getLimit()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

    @RequestMapping("/profitRankings")
    public ApiResult profitRankings(@RequestParam(required = false) String[] gameKind,ApiRequest request) {
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.profitRankings(request.getProductId(), request.getPlatformId(),gameKind,
                    request.getBeginTime(), request.getEndTime(), request.getCurrency(),request.getLimit()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(ErrorCode.FAIL.getMsg());
        }
        return apiResult;
    }

//    @ApiOperation(value = "通过产品ID，查询配置的所有游戏厅", httpMethod = "POST", notes = "仅有一个参数productId", consumes = "x-www-form-urlencoded")
//    @ApiImplicitParams({
//            @ApiImplicitParam(name = "productId", value = "产品Id", required = true, paramType = "form", dataType = "String")
//    })
    @RequestMapping("/getProductPlatforms")
    public ApiResult getProductPlatforms(@RequestParam String productId){
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApi.getProductPlatforms(productId));
        } catch (Exception e) {
            log.error(Throwables.getStackTraceAsString(e));
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(e.getMessage());
        }
        return apiResult;
    }

//    @ApiOperation(value = "通过产品、平台，获取某用户某段时间的不同游戏类型盈利", httpMethod = "POST", consumes = "x-www-form-urlencoded")
//    @ApiImplicitParams({
//            @ApiImplicitParam(name = "productId", value = "产品Id", required = true, paramType = "form", dataType = "String"),
//            @ApiImplicitParam(name = "platformId", value = "平台Id(单个)", required = true, paramType = "form", dataType = "String", example = "003"),
//            @ApiImplicitParam(name = "loginName", value = "用户名", required = true, paramType = "form", dataType = "String"),
//            @ApiImplicitParam(name = "currency", value = "货币类型", required = false, paramType = "form", dataType = "String"),
//            @ApiImplicitParam(name = "beginTime", value = "开始时间", required = true, paramType = "form", dataType = "String", example = "2020-12-01 00:00:00"),
//            @ApiImplicitParam(name = "endTime", value = "结束时间", required = true, paramType = "form", dataType = "String", example = "2020-12-01 23:59:59")
//    })
    @RequestMapping("/getPlayerPlatformProfit")
    public ApiResult getPlayerPlatformProfit (@RequestParam String productId,
                                              @RequestParam String platformId,
                                              @RequestParam String loginName,
                                              @RequestParam(required = false) String currency,
                                              @RequestParam String beginTime,
                                              @RequestParam String endTime){
        ApiResult apiResult = new ApiResult();
        try {
            apiResult.setObjs(dataCenterApiService.getPlayerPlatformProfit(productId, platformId, loginName, currency, beginTime, endTime));
        } catch (Exception e) {
            log.error(Throwables.getStackTraceAsString(e));
            apiResult.setErrorCode(ErrorCode.FAIL.getCode());
            apiResult.setMsg(e.getMessage());
        }
        return apiResult;
    }



}
