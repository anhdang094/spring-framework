package com.gw.datacenter.controller;

import com.gw.datacenter.controller.result.ApiResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
@Slf4j
public class RestNotFoundController implements ErrorController {
    private static final String ERROR_PATH = "/error";


    @RequestMapping(value = ERROR_PATH)
    public ApiResult handleError(HttpServletRequest request) {
        ApiResult result = new ApiResult();
        HttpStatus status = getStatus(request);
        result.setErrorCode(status.value());
        result.setMsg(status.getReasonPhrase());
        log.info(result.toString());
        return result;
    }


    @Override
    public String getErrorPath() {
        return ERROR_PATH;
    }

    public HttpStatus getStatus(HttpServletRequest request) {
        Integer statusCode = (Integer) request.getAttribute("javax.servlet.error.status_code");
        if (statusCode == null) {
            return HttpStatus.INTERNAL_SERVER_ERROR;
        } else {
            try {
                return HttpStatus.valueOf(statusCode.intValue());
            } catch (Exception var4) {
                return HttpStatus.INTERNAL_SERVER_ERROR;
            }
        }
    }
}
