package com.gw.datacenter.controller.health;

import com.alibaba.fastjson.JSON;
import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.enumer.DataSourceKeyEnum;
import com.gw.datacenter.controller.health.annotation.RateLimitAspect;
import com.gw.datacenter.service.OrderService;
import com.intech.systeminfo.Application;
import com.intech.systeminfo.ApplicationInfo;
import com.intech.systeminfo.ServiceInfo;
import com.intech.systeminfo.SystemInfoUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.util.StopWatch;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;

@RestController
@Slf4j
public class HealthController {
    @Resource
    private OrderService orderService;

    @Value("${hikari.read.jdbc-url}")
    private String readUrl;
    @Value("${hikari.write.jdbc-url}")
    private String writeUrl;

    @Value("${server.model.name}")
    private String serviceName;

    //@RateLimitAspect
    @RequestMapping(value = "/health",method = {POST,GET}, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public String health() {
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        ApplicationInfo applicationInfo = ApplicationInfo.initApplicationInfoWithServiceName(serviceName);
        applicationInfo.setSysteminfo(SystemInfoUtil.getSystemInfo());
        applicationInfo.setVersion(StringUtils.isBlank(UtilConstants.PROJECT_INFO.get("version"))?"":UtilConstants.PROJECT_INFO.get("version"));
        stopWatch.stop();
        applicationInfo.setCost(stopWatch.getTotalTimeMillis());
        applicationInfo.setStatus(Application.STATUS.SUCCESS);
        return JSON.toJSONString(applicationInfo,true);
    }

    //@RateLimitAspect(limit = 30, minute = 1, disableLocal = true)
    @RequestMapping(value = "/systeminfo",method = {POST,GET}, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public String systeminfo() {
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        ApplicationInfo applicationInfo = ApplicationInfo.initApplicationInfoWithServiceName(serviceName);
        applicationInfo.setServiceName("PUBLIC_DATACENTER_API");
        applicationInfo.setSysteminfo(SystemInfoUtil.getSystemInfo());
        applicationInfo.setVersion(StringUtils.isBlank(UtilConstants.PROJECT_INFO.get("version"))?"":UtilConstants.PROJECT_INFO.get("version"));
        applicationInfo.setDetail(getOutSystemList());
        stopWatch.stop();
        applicationInfo.setCost(stopWatch.getTotalTimeMillis());
        applicationInfo.setStatus(Application.STATUS.SUCCESS);
        return JSON.toJSONString(applicationInfo,true);
    }


    private List<ServiceInfo> getOutSystemList() {
        List<ServiceInfo> infos = new ArrayList<>();
        try {
            infos.add(getDBInfo(readUrl, DataSourceKeyEnum.read.name()));
            infos.add(getDBInfo(writeUrl, DataSourceKeyEnum.write.name()));
        } catch (Exception e) {
            log.error("调用systeminfo接口的getOutSystemList方法异常" + e);
        }
        return infos;
    }

    private ServiceInfo getDBInfo(String url, String type) {
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        ServiceInfo service = new ServiceInfo();
        service.setServiceName(Application.MODULE.DB);
        try {
            if (url.contains("?")) {
                url = url.substring(0, url.indexOf("?"));
            }
            try {
                if(url.toLowerCase().contains("service_name")) {
                    int serviceNameIndex = url.toLowerCase().indexOf("service_name");
                    serviceNameIndex = url.toLowerCase().indexOf("=", serviceNameIndex);
                    url = url.substring(serviceNameIndex + 1, url.indexOf(")", serviceNameIndex)).trim();
                } else {
                    url = url.substring(url.lastIndexOf("/"));
                }
            } catch (Exception ex) {
                log.error("UserDaoImpl.testSlaveConnection() failure." + ex.getMessage(), ex);
            }
            service.setUrl(url);
            service.setStatus(Application.STATUS.FAILURE);
            if (DataSourceKeyEnum.read.name().equals(type)) {
                String ret = orderService.testReadConnection();
                if (StringUtils.isNotBlank(ret)) {
                    service.setStatus(Application.STATUS.SUCCESS);
                }
            } else {
                String ret = orderService.testWriteConnection();
                if (StringUtils.isNotBlank(ret)) {
                    service.setStatus(Application.STATUS.SUCCESS);
                }
            }
        } catch (Exception e) {
            log.error("getDBInfo test connection failure,type:" + type + ",error:" + e.getMessage(), e);
            service.setStatus(Application.STATUS.FAILURE);
            service.setMessage("SELECT " + type + " DB EXCEPTION");
        }
        stopWatch.stop();
        service.setCost(stopWatch.getTotalTimeMillis());
        return service;
    }


}
