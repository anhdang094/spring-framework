//package com.gw.datacenter.controller.health.annotation;
//
//import com.gw.datacenter.common.util.IpUtil;
//import lombok.extern.slf4j.Slf4j;
//import org.aspectj.lang.ProceedingJoinPoint;
//import org.aspectj.lang.Signature;
//import org.aspectj.lang.annotation.Around;
//import org.aspectj.lang.annotation.Aspect;
//import org.aspectj.lang.annotation.Pointcut;
//import org.aspectj.lang.reflect.MethodSignature;
//import org.springframework.stereotype.Component;
//import org.springframework.web.context.request.RequestContextHolder;
//import org.springframework.web.context.request.ServletRequestAttributes;
//
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import java.io.IOException;
//import java.io.PrintWriter;
//import java.lang.reflect.Method;
//import java.util.Map;
//import java.util.concurrent.ConcurrentHashMap;
//import java.util.concurrent.atomic.AtomicInteger;
//import java.util.concurrent.atomic.AtomicLong;
//
//@Aspect
//@Component
//@Slf4j
//public class RateLimitAop {
//
//    Map<String, Limit> rateLimiterMap = new ConcurrentHashMap<>();
//
//    @Pointcut("execution(* com.gw.datacenter.controller.health.HealthController.*(..))")
//    public void serviceLimit() {
//    }
//
//
//    @Around("serviceLimit()")
//    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
//        Signature signature = joinPoint.getSignature();
//        MethodSignature methodSignature = (MethodSignature) signature;
//        //获取目标方法
//        Method targetMethod = methodSignature.getMethod();
//        //获取目标方法的@RateLimitAspect注解
//        RateLimitAspect lxRateLimit = targetMethod.getAnnotation(RateLimitAspect.class);
//        if (limitMethod(targetMethod.getName(), lxRateLimit)) {
//            return output(targetMethod.getName());
//        } else {
//            return joinPoint.proceed();
//        }
//    }
//
//    private boolean limitMethod(String method, RateLimitAspect lxRateLimit) {
//        if(lxRateLimit.disableLocal()) {
//            HttpServletRequest request = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
//            String ip = IpUtil.getIpAddr(request);
//            if(!ip.equals("127.0.0.1") && !ip.equals("localhost") && !ip.equals("0:0:0:0:0:0:0:1")) {
//                return true;
//            }
//        }
//        if (!rateLimiterMap.containsKey(method)) {
//            Limit limit = new Limit();
//            rateLimiterMap.put(method, limit);
//        }
//
//        Limit limit = rateLimiterMap.get(method);
//        long currentTime = System.currentTimeMillis();
//        if (currentTime - limit.TIMER_BET_RECORD.get() > lxRateLimit.minute() * 60 * 1000) {
//            limit.TIMER_BET_RECORD.set(currentTime);
//            limit.COUNTER_BET_RECORD.set(0);
//        } else {
//            if (limit.COUNTER_BET_RECORD.incrementAndGet() > lxRateLimit.limit()) {
//                return true;
//            }
//        }
//        return false;
//    }
//
//    private class Limit {
//        AtomicLong TIMER_BET_RECORD = new AtomicLong(System.currentTimeMillis());
//        AtomicInteger COUNTER_BET_RECORD = new AtomicInteger(0);
//    }
//
//    public Object output(String msg){
//        HttpServletResponse response = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getResponse();
//        response.setContentType("application/json;charset=UTF-8");
//        PrintWriter outputStream = null;
//        try {
//            outputStream = response.getWriter();
//            outputStream.print("{\"status\":\"FAILURE\",\"message\":\"【" + msg + "】超流量限制\"}");
//        } catch (IOException e) {
//            e.printStackTrace();
//        } finally {
//            outputStream.flush();
//            outputStream.close();
//        }
//        return null;
//    }
//
//}
