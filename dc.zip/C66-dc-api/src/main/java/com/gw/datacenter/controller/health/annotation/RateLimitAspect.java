package com.gw.datacenter.controller.health.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.concurrent.TimeUnit;

@Inherited
@Documented
@Target({ElementType.METHOD, ElementType.FIELD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface RateLimitAspect {
    /**
     *
     * @return
     */
    String value() default "";

    /**
     * 每秒向桶中放入令牌的数量   默认最大即不做限流
     * @return
     */
    double perSecond() default Double.MAX_VALUE;

    /**
     * 获取令牌的等待时间  默认0
     * @return
     */
    int timeOut() default 0;

    /**
     * 超时时间单位,毫秒
     * @return
     */
    TimeUnit timeOutUnit() default TimeUnit.MILLISECONDS;

    /**
     * 请求次数，默认100次
     * @return
     */
    int limit() default 100;

    /**
     * 分钟，默认5分钟
     * @return
     */
    int minute() default 5;

    /**
     * 是否限制本机访问
     */
    boolean disableLocal() default false;

}
