package com.gw.datacenter.controller.request;

import com.gw.datacenter.vo.order.OrderEntity;
import com.gw.datacenter.vo.order.PlatformGameKinds;
import com.gw.datacenter.vo.order.PlatformGamekind;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

/**
 * title: ApiRequest
 * description: TODO
 * author: Jair.H
 * date: 2018/11/6 15:18
 */
@Data
public class ApiRequest {
    private String queryType;
    private String productId;
    private Integer remainAmount;
    private String validAccount;
    private String timeZoneId;
    private String loginName;
    private String[] loginNames;
    private String gameKind;
    private String platformId;
    private String loginNameArray;
    private String beginTime;
    private String endTime;
    private String beginDate;
    private String endDate;
    private Integer type;
    private Integer pageNo;
    private Integer pageSize;
    private String key;
    private String orderByField;
    private String[] rankLoginNameList;
    private String gameType;
    private String MinBetTimes;
    private String currency;
    private BigDecimal betMin;
    private BigDecimal winMin;
    private Integer size;
    private Integer resultType;
    private String gameCode;
    private BigDecimal amount;
    private String weekBeginTime;
    private String weekEndTime;
    private String monthBeginTime;
    private String monthEndTime;
    private Integer times;
    private Integer minAmount;
    private Integer multiple;
    private Integer flag;
    private Integer cusAmount;
    private Integer maxRecode;
    private Integer listCount;
    private OrderEntity orderEntity;
    private String settledType;
    private Integer minBetAmount;
    private Integer minCusAmount;
    private Integer minMultiple;
    private String fieldsOrder;
    private String billNo;
    private String maxField;
    private String groupField;
    private String limit;
    private String videoId;
    private String shoeCode;
    private String orderBy;
    private String[] platforms;
    private Integer top;
    private Integer rank;
    private Long updateTime;
    private String[] excludePlatformArray;
    private String[] platformArray;
    private String[] gameKindArray;
    private String[] gameTypeArray;
    private List<PlatformGamekind> platformAndGameKindList;
    private PlatformGameKinds[] platform;
    private boolean isWinBetOnly;
    private Integer deviceType;
    private BigDecimal minCustAmount;
    private Long minSumAmount;
    private BigDecimal minValidAmount;
    private String mainLoginName;
}
