package com.gw.datacenter.controller.request;

import lombok.Data;

/**
 * Created by Olivier on 2021/2/3.
 */
@Data
public class GetOrderSummaryGroupByPlatGameUnRequest {

    private String key;

    private String gameKind;
    private String gameType;
    private String platformId;

    private String beginTime;
    private String endTime;
    private String productId;
    private int pageNo=1;
    private int pageSize=100;

}
