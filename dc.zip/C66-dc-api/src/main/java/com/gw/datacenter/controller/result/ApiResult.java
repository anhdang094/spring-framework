package com.gw.datacenter.controller.result;

import com.gw.datacenter.common.enumer.ErrorCode;
import com.gw.datacenter.common.util.JacksonUtil;
import lombok.Data;

@Data
public class ApiResult {
    private int errorCode = ErrorCode.SUCCESS.getCode();
    private String msg = ErrorCode.SUCCESS.getMsg();
    private Object objs;

    @Override
    public String toString() {
        return "{errorCode=" + errorCode + ", msg=" + msg + ", objs=" + JacksonUtil.toJSon(objs) + "}";
    }

}
