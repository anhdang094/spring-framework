package com.gw.datacenter.controller.result;

import lombok.Data;

import java.util.List;

/**
 * Created by Olivier on 2021/2/3.
 */
@Data
public class GetOrderSummaryGroupByPlatGameUnResponse {


    private String gameKind;
    private String gameType;
    private String productId;
    private String platform;
    private String dataDate;

    //总的投注额
    private double totalBetAmount;
    //有效投注总额
    private double totalValidAmount;
    //洗码投注总额
    private double totalRemainAmount;
    //输赢总额
    private double totalWinLoseAmount;
    //总的投注次数
    private long totalBetTimes;

    //记录数
    private long count;
    private long totalUserNum=0;

}
