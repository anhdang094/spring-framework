package com.gw.datacenter.cxf;

import com.gw.datacenter.common.exception.GWKeyErrorException;
import com.gw.datacenter.common.exception.GWPersistenceException;
import com.gw.datacenter.controller.request.GetOrderSummaryGroupByPlatGameUnRequest;
import com.gw.datacenter.controller.result.GetOrderSummaryGroupByPlatGameUnResponse;
import com.gw.datacenter.vo.activity.ActivityEntity;
import com.gw.datacenter.vo.activity.AttendancePromoEntity;
import com.gw.datacenter.vo.dictionary.DictionaryEntity;
import com.gw.datacenter.vo.gameresult.BaGameEntity;
import com.gw.datacenter.vo.gameresult.PokerShoeStatisticEntity;
import com.gw.datacenter.vo.gametypeplaytype.GameTypePlayTypeEntity;
import com.gw.datacenter.vo.order.*;
import com.gw.datacenter.vo.pagainate.QueryResult;
import com.gw.datacenter.vo.pagainate.QueryResultWrapper;
import com.gw.datacenter.vo.transfer.TransferGroupByType;
import org.apache.cxf.common.util.ReflectionInvokationHandler;

import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;


@WebService(targetNamespace = "http://CXFServer.webservice.datacenter.gw.com.java.main/")
@SOAPBinding
public interface DataCenterApi {

    /**
     * //旗舰厅百家乐盈利排行榜接口
     *
     * @param
     * @param beginTime
     * @param endTime
     * @param
     * @return
     * @throws Exception
     */
    QueryResult<ProfitRanking> getAgListOrder(
            @WebParam(name = "productId") String productId,
            @WebParam(name = "loginNames") String [] loginNames,
            @WebParam(name = "gameKind") String [] gameKind,
            @WebParam(name = "currency") String currency,
            @WebParam(name = "beginTime") String beginTime,
            @WebParam(name = "endTime") String endTime,
            @WebParam(name = "limit") String limit)
            throws GWPersistenceException, GWKeyErrorException;

    /**
     * 个人盈利排行榜
     *
     * @param
     * @param beginTime
     * @param endTime
     * @param
     * @return
     * @throws Exception
     */
    List<ProfitEntity> profitRankings(@WebParam(name = "productId") String productId, // 产品id
                                      @WebParam(name = "platformId") String platformId, // 游戏平台id
                                      @WebParam(name = "gameKind") String [] gameKind, // 游戏大类id
                                      @WebParam(name = "beginTime") String beginTime, // YYYY-MM-DD HH:mm:ss
                                      @WebParam(name = "endTime") String endTime,
                                      @WebParam(name = "currency") String currency,
                                      @WebParam(name = "limit") String limit
    ) throws GWPersistenceException, GWKeyErrorException;


    List<DictionaryEntity> getProductPlatforms(@WebParam(name = "productId") String productId) throws GWPersistenceException;

    public QueryResult<AccountTotalEntity> getOrderSummaryGroupByDay(
            @WebParam(name = "productId") String productId,
            @WebParam(name = "loginNameList") String[] loginNameList,
            @WebParam(name = "beginDate") String beginDate,
            @WebParam(name = "endDate") String endDate) throws GWPersistenceException, GWKeyErrorException;


    List<TransferGroupByType> getTransferSumGroupByType(String[] platformArray, String[] platformArrayAG, String beginTime, String endTime, String productId, String userName) throws Exception;

    public QueryResult<GameTypePlayTypeEntity> getGameTypeAndPlayType(String[] platformArray, Integer type, String update) throws Exception;


    /**
     * 查询有效投注额(佣金)
     *
     * @param productId
     * @param timeZoneId
     * @param platformId
     * @param loginNameArray
     * @param beginTime
     * @param endTime
     * @param gameKind
     * @param type           ==0代表只返回有效投注额 ;type==1代表返回有效投注额，投注次数，投注额，输赢值信息
     * @param pageNo
     * @param pageSize
     * @param key
     * @return QueryResult
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    QueryResult<AccountTotalEntity> getValidAmountByType(@WebParam(name = "productId") String productId,
                                                         @WebParam(name = "platformId") String platformId, @WebParam(name = "validAccount") String validAccount,
                                                         @WebParam(name = "timeZoneId") String timeZoneId, @WebParam(name = "loginNameArray") String loginNameArray,
                                                         @WebParam(name = "beginTime") String beginTime, @WebParam(name = "endTime") String endTime,
                                                         @WebParam(name = "gameKind") Integer gameKind, @WebParam(name = "type") Integer type, @WebParam(name = "pageNo") Integer pageNo,
                                                         @WebParam(name = "pageSize") Integer pageSize, @WebParam(name = "key") String key, @WebParam(name = "orderByField") String orderByField,
                                                         @WebParam(name = "rankLoginNameList") String[] rankLoginNameList,
                                                         @WebParam(name = "gameType") String[] gameType,
                                                         @WebParam(name = "MinBetTimes") String MinBetTimes,
                                                         @WebParam(name = "currency") String currency,
                                                         @ReflectionInvokationHandler.Optional @WebParam(name = "minCustAmount") BigDecimal minCustAmount,
                                                         @ReflectionInvokationHandler.Optional @WebParam(name = "minValidAmount") BigDecimal minValidAmount

    ) throws GWPersistenceException, GWKeyErrorException;

    QueryResult<AccountTotalEntity> getValidAmountByTypeAndFlag(@WebParam(name = "productId") String productId,
                                                                @WebParam(name = "platformId") String platformId, @WebParam(name = "validAccount") String validAccount,
                                                                @WebParam(name = "timeZoneId") String timeZoneId, @WebParam(name = "loginNameArray") String loginNameArray,
                                                                @WebParam(name = "beginTime") String beginTime, @WebParam(name = "endTime") String endTime,
                                                                @WebParam(name = "gameKind") Integer gameKind, @WebParam(name = "type") Integer type, @WebParam(name = "pageNo") Integer pageNo,
                                                                @WebParam(name = "pageSize") Integer pageSize, @WebParam(name = "key") String key) throws GWPersistenceException, GWKeyErrorException;


    /**
     * 注单明细查询
     *
     * @param productId
     * @param platformId
     * @param validAccount
     * @param timeZoneId
     * @param loginNameArray
     * @param beginTime
     * @param endTime
     * @param gameKind
     * @param pageNo
     * @param pageSize
     * @param key
     * @return
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    QueryResult<OrderEntity> getOrderEntity(@WebParam(name = "productId") String productId,
                                            @WebParam(name = "platformId") String[] platformId, @WebParam(name = "validAccount") String validAccount,
                                            @WebParam(name = "timeZoneId") String timeZoneId, @WebParam(name = "loginNameArray") String loginNameArray,
                                            @WebParam(name = "beginTime") String beginTime, @WebParam(name = "endTime") String endTime,
                                            @WebParam(name = "gameKind") Integer gameKind, @WebParam(name = "pageNo") Integer pageNo,
                                            @WebParam(name = "pageSize") Integer pageSize, @WebParam(name = "key") String key) throws GWPersistenceException, GWKeyErrorException;

    /**
     * 获取单厅最大投注额
     *
     * @param productId
     * @param resultType
     * @param beginTime
     * @param endTime
     * @param key
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    QueryResult<AccountTotalEntity> getMaxEffectiveBettingAmount(@WebParam(name = "productId") String productId,
                                                                 @WebParam(name = "loginNameArray") String loginNameArray, @WebParam(name = "resultType") Integer resultType,
                                                                 @WebParam(name = "beginTime") String beginTime, @WebParam(name = "endTime") String endTime, @WebParam(name = "pageNo") Integer pageNo,
                                                                 @WebParam(name = "pageSize") Integer pageSize, @WebParam(name = "key") String key) throws GWPersistenceException, GWKeyErrorException;


    /**
     * 根据条件（包含场次等相关条件）获取注单列表
     *
     * @param productId
     * @param loginName
     * @param gameCode
     * @param beginTime
     * @param endTime
     * @param pageNo
     * @param pageSize
     * @param key
     * @return
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    QueryResult<OrderEntity> getOrderDetailsByGmCode(@WebParam(name = "productId") String productId, @WebParam(name = "loginName") String loginName,
                                                     @WebParam(name = "gameCode") String gameCode, @WebParam(name = "beginTime") String beginTime, @WebParam(name = "endTime") String endTime,
                                                     @WebParam(name = "pageNo") Integer pageNo, @WebParam(name = "pageSize") Integer pageSize, @WebParam(name = "key") String key) throws GWPersistenceException, GWKeyErrorException;

    /**
     * 与getOrderDetailsByGmCode 相同，返回值有统计数量
     *
     * @param productId
     * @param loginName
     * @param gameCode
     * @param beginTime
     * @param endTime
     * @param pageNo
     * @param pageSize
     * @param key
     * @return
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    QueryResultWrapper getOrderDetailsAndSummaryByGmCode(
            @WebParam(name = "productId") String productId,
            @WebParam(name = "loginName") String loginName,
            @WebParam(name = "gameCode") String gameCode,
            @WebParam(name = "beginTime") String beginTime,
            @WebParam(name = "endTime") String endTime,
            @WebParam(name = "pageNo") Integer pageNo,
            @WebParam(name = "pageSize") Integer pageSize,
            @WebParam(name = "key") String key) throws GWPersistenceException, GWKeyErrorException;

    /**
     * 根据条件获取周/月有效投注额（现只有周有用）
     *
     * @param productId
     * @param loginNameArray
     * @param weekBeginTime
     * @param weekEndTime
     * @param monthBeginTime
     * @param monthEndTime
     * @param amount
     * @param key
     * @return List<MonthlyWeeklyEffectiveBetAmountEntity>
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    List<MonthlyWeeklyEffectiveBetAmountEntity> getMonthlyAndWeeklyValidAmount(@WebParam(name = "productId") String productId,
                                                                               @WebParam(name = "loginNameArray") String loginNameArray, @WebParam(name = "amount") BigDecimal amount,
                                                                               @WebParam(name = "weekBeginTime") String weekBeginTime, @WebParam(name = "weekEndTime") String weekEndTime,
                                                                               @WebParam(name = "monthBeginTime") String monthBeginTime, @WebParam(name = "monthEndTime") String monthEndTime,
                                                                               @WebParam(name = "key") String key) throws GWPersistenceException, GWKeyErrorException;

    /**
     * Get customer bet begin time and end time.
     *
     * @param productId (A01,A02,A03...)
     * @param loginName
     * @param type=1    get begin bet time type=2 get end bet time
     * @param key
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    QueryResult<OrderEntity> getCustomerBetTime(@WebParam(name = "productId") String productId,
                                                @WebParam(name = "loginName") String loginName, @WebParam(name = "type") Integer type, @WebParam(name = "key") String key)
            throws GWPersistenceException, GWKeyErrorException;

    /**
     * 获取时间段内单注有效投注额>=minAmount 时间段内每天投注次数>=times的用户
     * 注:多平台时times的计算方式是SUM(平台1.次数+平台2.次数+...)>=times
     *
     * @param productId  产品ID
     * @param platformId 平台ID
     * @param beginTime  开始时间
     * @param endTime    结束时间
     * @param gameKind   用于BBIN区分游戏大类(1:球类游戏 3:视讯游戏 5:电子游戏 7:对战游戏 12:彩票 NULL:不区分)
     * @param times      投注次数
     * @param minAmount  有效投注额度
     * @param key        KEY
     * @return
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    QueryResult<ContinuousOrder> getContinuousOrder(
            @WebParam(name = "productId") String productId,
            @WebParam(name = "platformId") String[] platformId,
            @WebParam(name = "beginTime") String beginTime,
            @WebParam(name = "endTime") String endTime,
            @WebParam(name = "gameKind") String gameKind,
            @WebParam(name = "times") Integer times,
            @WebParam(name = "minAmount") Integer minAmount,
            @WebParam(name = "key") String key
    ) throws GWPersistenceException, GWKeyErrorException;

    /**
     * 获取时间段内盈利大余等于1000的注单数据
     *
     * @param productId  产品ID
     * @param platformId 平台ID
     * @param beginTime  开始时间
     * @param endTime    结束时间
     * @param multiple   倍数
     * @param pageNo     页数
     * @param pageSize   单页数据行数
     * @param key        KEY
     * @return
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    QueryResult<OrderEntity> getOrderListByProfit(
            @WebParam(name = "productId") String productId,
            @WebParam(name = "platformId") String[] platformId,
            @WebParam(name = "beginTime") String beginTime,
            @WebParam(name = "endTime") String endTime,
            @WebParam(name = "multiple") Integer multiple,
            @WebParam(name = "pageNo") Integer pageNo,
            @WebParam(name = "pageSize") Integer pageSize,
            @WebParam(name = "key") String key
    ) throws GWPersistenceException, GWKeyErrorException;

    /**
     * 获取时间段内盈利是下注额度multiple倍的注单数据
     *
     * @param productId
     * @param platformId
     * @param gameKind
     * @param beginTime
     * @param endTime
     * @param cusAmount
     * @param multiple
     * @param pageNo
     * @param pageSize
     * @param key
     * @return
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    QueryResult<OrderEntity> getHighProfitOrderList(
            @WebParam(name = "productId") String productId,
            @WebParam(name = "platformId") String[] platformId,
            @WebParam(name = "gameKind") String[] gameKind,
            @WebParam(name = "beginTime") String beginTime,
            @WebParam(name = "endTime") String endTime,
            @WebParam(name = "cusAmount") Integer cusAmount,
            @WebParam(name = "multiple") Integer multiple,
            @WebParam(name = "pageNo") Integer pageNo,
            @WebParam(name = "pageSize") Integer pageSize,
            @WebParam(name = "key") String key
    ) throws GWPersistenceException, GWKeyErrorException;

    /**
     * 获取盈利超过cusAmount 和 盈利倍数超过multiple的集合
     *
     * @param productId
     * @param platformId
     * @param beginTime
     * @param endTime
     * @param flag
     * @param cusAmount
     * @param multiple
     * @param maxRecode
     * @param key
     * @return
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     * @Method Name: getBetHistory
     * @Method Desc:获取时间段内注单记录
     * @Return QueryResult<OrderEntity>    返回类型
     * @Author：Sanco
     * @Crete_Time Dec 3, 2014 11:12:23 AM
     * @Las_Update_Time Dec 3, 2014 11:12:23 AM
     * @Version V1.1
     * @Exception
     */
    QueryResult<OrderEntity> getBetHistory(
            @WebParam(name = "productId") String productId,
            @WebParam(name = "platformId") String[] platformId,
            @WebParam(name = "beginTime") String beginTime,
            @WebParam(name = "endTime") String endTime,
            @WebParam(name = "flag") Integer flag,
            @WebParam(name = "cusAmount") Integer cusAmount,
            @WebParam(name = "multiple") Integer multiple,
            @WebParam(name = "maxRecode") Integer maxRecode,
            @WebParam(name = "key") String key
    ) throws GWPersistenceException, GWKeyErrorException;

    /**
     * 获取一天内单个游戏盈利超过cusAmount的信息，针对所有平台，按时间汇总
     *
     * @param productId
     * @param platformId
     * @param beginTime
     * @param endTime
     * @param cusAmount
     * @param key
     * @return
     * @Method Desc:获取一天内单个游戏盈利超过cusAmount的信息
     */
    QueryResult<OrderEntity> getBestWin(@WebParam(name = "productId") String productId,
                                        @WebParam(name = "platformId") String[] platformId,
                                        @WebParam(name = "beginTime") String beginTime,
                                        @WebParam(name = "endTime") String endTime,
                                        @WebParam(name = "cusAmount") Integer cusAmount,
                                        @WebParam(name = "listCount") Integer listCount,
                                        @WebParam(name = "key") String key) throws GWPersistenceException, GWKeyErrorException;

    /**
     * 获取 最小投注额大于minBetAmount 盈利超过cusAmount 和 盈利倍数超过multiple的集合，
     * 根据gamekind 获取不同平台数据，按下注时间倒序排列 ，粒度到注单
     *
     * @param productId
     * @param platformId
     * @param beginTime
     * @param endTime
     * @param orderEntity
     * @param multiple
     * @param pageNo
     * @param pageSize
     * @return
     * @throws GWPersistenceException
     */
    QueryResult<OrderEntity> getOrderByMultipleAndValidAccount2(
            @WebParam(name = "productId") String productId,
            @WebParam(name = "platformId") String[] platformId,
            @WebParam(name = "beginTime") String beginTime,
            @WebParam(name = "endTime") String endTime,
            @WebParam(name = "orderEntity") OrderEntity orderEntity,
            @WebParam(name = "multiple") Integer multiple,
            @WebParam(name = "pageNo") Integer pageNo,
            @WebParam(name = "pageSize") Integer pageSize) throws GWPersistenceException;

    /**
     * @param productId
     * @param platformId
     * @param loginName
     * @param gameKind
     * @param beginTime
     * @param endTime
     * @param settledType  是否结算 true己结算
     * @param minBetAmount 最低有效投注额
     * @param minCusAmount 最低盈利额度
     * @param minMultiple  盈利倍数
     * @param fieldsOrder  排序字符串 固定的格式[字段名-顺序or倒序,字段名-顺序or倒序]examples: billtime desc,cusAmount asc
     * @param pageNo
     * @param pageSize
     * @param key
     * @return
     */
    QueryResult<OrderEntity> getRecord(
            @WebParam(name = "productId") String productId,
            @WebParam(name = "platformId") String[] platformId,
            @WebParam(name = "loginName") String[] loginName,
            @WebParam(name = "gameKind") String[] gameKind,
            @WebParam(name = "beginTime") String beginTime,
            @WebParam(name = "endTime") String endTime,
            @WebParam(name = "settledType") String settledType,
            @WebParam(name = "minBetAmount") Integer minBetAmount,
            @WebParam(name = "minCusAmount") Integer minCusAmount,
            @WebParam(name = "minMultiple") Integer minMultiple,
            @WebParam(name = "fieldsOrder") String fieldsOrder,
            @WebParam(name = "pageNo") Integer pageNo,
            @WebParam(name = "pageSize") Integer pageSize,
            @WebParam(name = "key") String key,
            @WebParam(name = "gameType") String gameType,
            @WebParam(name = "gameCode") String[] gameCode,
            @WebParam(name = "billNo") String billNo,
            @WebParam(name = "currency") String currency,
            @WebParam(name = "remainAmount") Integer remainAmount
    ) throws GWPersistenceException, GWKeyErrorException;

    /**
     * 查找注单记录，并返回统计数据
     *
     * @param productId
     * @param platformId
     * @param loginName
     * @param gameKind
     * @param beginTime
     * @param endTime
     * @param settledType
     * @param minBetAmount
     * @param minCusAmount
     * @param minMultiple
     * @param fieldsOrder
     * @param pageNo
     * @param pageSize
     * @param key
     * @return
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    QueryResultWrapper getRecordAndSummary(
            @WebParam(name = "productId") String productId,
            @WebParam(name = "platformId") String[] platformId,
            @WebParam(name = "loginName") String[] loginName,
            @WebParam(name = "gameKind") String[] gameKind,
            @WebParam(name = "beginTime") String beginTime,
            @WebParam(name = "endTime") String endTime,
            @WebParam(name = "settledType") String settledType,
            @WebParam(name = "minBetAmount") Integer minBetAmount,
            @WebParam(name = "minCusAmount") Integer minCusAmount,
            @WebParam(name = "minMultiple") Integer minMultiple,
            @WebParam(name = "fieldsOrder") String fieldsOrder,
            @WebParam(name = "pageNo") Integer pageNo,
            @WebParam(name = "pageSize") Integer pageSize,
            @WebParam(name = "key") String key,
            @WebParam(name = "gameType") String[] gameType,
            @WebParam(name = "gameCode") String[] gameCode,
            @WebParam(name = "remainAmount") Integer remainAmount,
            @WebParam(name = "currency") String currency) throws GWPersistenceException, GWKeyErrorException;

    QueryResult<OrderSummary> getRecordSummary(@WebParam(name = "productId") String productId,
                                               @WebParam(name = "platformId") String[] platformId,
                                               @WebParam(name = "loginName") String[] loginName,
                                               @WebParam(name = "gameKind") String[] gameKind,
                                               @WebParam(name = "beginTime") String beginTime,
                                               @WebParam(name = "endTime") String endTime,
                                               @WebParam(name = "settledType") String settledType,
                                               @WebParam(name = "minBetAmount") Integer minBetAmount,
                                               @WebParam(name = "minCusAmount") Integer minCusAmount,
                                               @WebParam(name = "minMultiple") Integer minMultiple,
                                               @WebParam(name = "fieldsOrder") String fieldsOrder,
                                               @WebParam(name = "pageNo") Integer pageNo,
                                               @WebParam(name = "pageSize") Integer pageSize,
                                               @WebParam(name = "key") String key,
                                               @WebParam(name = "gameType") String[] gameType,
                                               @WebParam(name = "gameCode") String[] gameCode,
                                               @WebParam(name = "remainAmount") Integer remainAmount) throws GWPersistenceException, GWKeyErrorException;

    /**
     * 这个背景是这样的，A06要做一个捕鱼游戏的活动。
     * 需要每周统计大于5下注的赢了的注单统计每个人盈利条数最多的排名，然后派发奖品；目前dc没有接口符合这个要求，所以需要重新开发一个接口
     */
    List<BetRankEntity> getBetRank(@WebParam(name = "productId") String productId, // 产品id
                                   @WebParam(name = "platformId") String[] platformId, // 游戏平台id
                                   @WebParam(name = "gameKind") String[] gameKind, // 游戏大类id
                                   @WebParam(name = "loginName") String loginName, // 玩家账号，单个
                                   @WebParam(name = "beginTime") String beginTime, // YYYY-MM-DD HH:mm:ss
                                   @WebParam(name = "endTime") String endTime,
                                   @WebParam(name = "winListType") Integer winListType, // 1正盈利 -1负盈利
                                   @WebParam(name = "minWinLostCount") Integer minWinLostCount, // 符合条件的投注条数
                                   @WebParam(name = "minBetAmount") Integer minBetAmount, // 最小投注额
                                   @WebParam(name = "fieldsOrder") String fieldsOrder, // 排序字段 a总下注额度、b总有效下注额度、c总洗码投注额、d总盈利额度、e总盈利条数
                                   @WebParam(name = "pageSize") Integer pageSize, // 本次请求获取数量
                                   @WebParam(name = "key") String key,
                                   @WebParam(name = "currency") String currency,
                                   @WebParam(name = "minValidAmount") BigDecimal minValidAmount) throws GWPersistenceException, GWKeyErrorException;


    List<PlayerWinsEntity> getPlayerWins(@WebParam(name = "productId") String productId, // 产品id
                                         @WebParam(name = "loginName") String loginName, // 玩家账号，单个
                                         @WebParam(name = "beginTime") String beginTime, // YYYY-MM-DD HH:mm:ss
                                         @WebParam(name = "endTime") String endTime,
                                         @WebParam(name = "pageSize") Integer pageSize, // 本次请求获取数量
                                         @WebParam(name = "key") String key) throws GWPersistenceException, GWKeyErrorException;

    List<TopWinnerEntity> getTopWinners(@WebParam(name = "productId") String productId, // 产品id
                                        @WebParam(name = "beginTime") String beginTime, // YYYY-MM-DD HH:mm:ss
                                        @WebParam(name = "endTime") String endTime,
                                        @WebParam(name = "pageSize") Integer pageSize, // 本次请求获取数量
                                        @WebParam(name = "key") String key) throws GWPersistenceException, GWKeyErrorException;

    /**
     * 高倍盈利榜api
     */
    List<SuperWinEntity> getSuperWins(@WebParam(name = "productId") String productId, // 产品id
                                      @WebParam(name = "beginTime") String beginTime, // YYYY-MM-DD HH:mm:ss
                                      @WebParam(name = "endTime") String endTime,
                                      @WebParam(name = "realMulti") Integer realMulti,    // 最小真人盈利倍数   可以为null
                                      @WebParam(name = "realAmount") Integer realAmount,   // 最小真人盈利额度    可以为null
                                      @WebParam(name = "sportMulti") Integer sportMulti,
                                      @WebParam(name = "sportAmount") Integer sportAmount,
                                      @WebParam(name = "lotteryMulti") Integer lotteryMulti,
                                      @WebParam(name = "lotteryAmount") Integer lotteryAmount,
                                      @WebParam(name = "slotMulti") Integer slotMulti,
                                      @WebParam(name = "slotAmount") Integer slotAmount,
                                      @WebParam(name = "fishMulti") Integer fishMulti,
                                      @WebParam(name = "fishAmount") Integer fishAmount,
                                      @WebParam(name = "pageSize") Integer pageSize, // 本次请求获取数量
                                      @WebParam(name = "key") String key) throws GWPersistenceException, GWKeyErrorException;

    /**
     * 同一个客户，如果有多条记录都符合，返回最高一条 盈利 记录
     * 获取满足条件的最大值的记录 ，支持group by (loginname|game_kind), 最大值 支持(CUS_ACCOUNT|VALID_ACCOUNT) ,排序字段可选,支持
     * added By Span
     */
    QueryResult<OrderEntity> getRecordMaxBy(
            @WebParam(name = "productId") String productId,
            @WebParam(name = "platformId") String[] platformId,
            @WebParam(name = "loginName") String[] loginName,
            @WebParam(name = "gameKind") String[] gameKind,
            @WebParam(name = "beginTime") String beginTime,
            @WebParam(name = "endTime") String endTime,
            @WebParam(name = "settledType") String settledType,
            @WebParam(name = "minBetAmount") Integer minBetAmount,
            @WebParam(name = "minCusAmount") Integer minCusAmount,
            @WebParam(name = "minMultiple") Integer minMultiple,
            @WebParam(name = "fieldsOrder") String fieldsOrder,
            @WebParam(name = "maxField") String maxField,
            @WebParam(name = "groupField") String groupField,
            @WebParam(name = "pageNo") Integer pageNo,
            @WebParam(name = "pageSize") Integer pageSize,
            @WebParam(name = "key") String key,
            @WebParam(name = "currency") String currency) throws GWPersistenceException, GWKeyErrorException;

    /**
     * 与getRecordMaxBy 相同，返回值有统计数据
     *
     * @param productId
     * @param platformId
     * @param loginName
     * @param gameKind
     * @param beginTime
     * @param endTime
     * @param settledType
     * @param minBetAmount
     * @param minCusAmount
     * @param minMultiple
     * @param fieldsOrder
     * @param maxField
     * @param groupField
     * @param pageNo
     * @param pageSize
     * @param key
     * @return
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    QueryResultWrapper getRecordMaxAndSummaryBy(
            @WebParam(name = "productId") String productId,
            @WebParam(name = "platformId") String[] platformId,
            @WebParam(name = "loginName") String[] loginName,
            @WebParam(name = "gameKind") String[] gameKind,
            @WebParam(name = "beginTime") String beginTime,
            @WebParam(name = "endTime") String endTime,
            @WebParam(name = "settledType") String settledType,
            @WebParam(name = "minBetAmount") Integer minBetAmount,
            @WebParam(name = "minCusAmount") Integer minCusAmount,
            @WebParam(name = "minMultiple") Integer minMultiple,
            @WebParam(name = "fieldsOrder") String fieldsOrder,
            @WebParam(name = "maxField") String maxField,
            @WebParam(name = "groupField") String groupField,
            @WebParam(name = "pageNo") Integer pageNo,
            @WebParam(name = "pageSize") Integer pageSize,
            @WebParam(name = "key") String key,
            @WebParam(name = "currency") String currency) throws GWPersistenceException, GWKeyErrorException;


    /**
     * 天生赢家
     *
     * @param productId
     * @param loginName
     * @param beginTime
     * @param endTime
     * @param pageNo
     * @param pageSize
     * @param key
     * @return
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    QueryResultWrapper getBoWinList(
            @WebParam(name = "productId") String productId,
            @WebParam(name = "loginName") String loginName,
            @WebParam(name = "beginTime") String beginTime,
            @WebParam(name = "endTime") String endTime,
            @WebParam(name = "pageNo") Integer pageNo,
            @WebParam(name = "pageSize") Integer pageSize,
            @WebParam(name = "key") String key) throws GWPersistenceException, GWKeyErrorException;

    /**
     * 根据产品和最后更新时间查询用户第一次投注记录数据
     *
     * @param productId
     * @param beginTime
     * @param endTime
     * @param pageNo
     * @param pageSize
     * @param key
     * @return
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    QueryResult<UserWagerInfo> getFirstBetList(
            @WebParam(name = "productId") String productId,
            @WebParam(name = "beginTime") String beginTime,
            @WebParam(name = "endTime") String endTime,
            @WebParam(name = "pageNo") Integer pageNo,
            @WebParam(name = "pageSize") Integer pageSize,
            @WebParam(name = "key") String key)
            throws GWPersistenceException, GWKeyErrorException;

    // AGQJ 投注周期内投注人数最多的相关信息
    QueryResult<OrderEntity> getAGQJDeskInfos(
            @WebParam(name = "productId") String productId,
            @WebParam(name = "beginTime") String beginTime,
            @WebParam(name = "endTime") String endTime,
            @WebParam(name = "limit") String limit,
            @WebParam(name = "key") String key
    ) throws GWPersistenceException, GWKeyErrorException;


    /**
     * 按靴号查询 最大值  列表
     *
     * @param productId
     * @param platformId
     * @param loginName
     * @param videoId
     * @param shoeCode
     * @param beginTime
     * @param endTime
     * @param orderBy
     * @param pageNo
     * @param pageSize
     * @param key
     * @return List<PokerShoeStatisticEntity>
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    QueryResult<PokerShoeStatisticEntity> getMaxValueGroupByShoecode(
            @WebParam(name = "productId") String productId,
            @WebParam(name = "platformId") String platformId,
            @WebParam(name = "loginName") String loginName,
            @WebParam(name = "videoId") String videoId,
            @WebParam(name = "shoeCode") String shoeCode,
            @WebParam(name = "beginTime") String beginTime,
            @WebParam(name = "endTime") String endTime,
            @WebParam(name = "orderBy") String orderBy,
            @WebParam(name = "pageNo") Integer pageNo,
            @WebParam(name = "pageSize") Integer pageSize,
            @WebParam(name = "key") String key,
            @WebParam(name = "gameType") String[] gameType,
            @WebParam(name = "minBetTimes") String minBetTimes) throws GWPersistenceException, GWKeyErrorException;

    /**
     * queryGameResult
     *
     * @param productId
     * @param platformId
     * @param loginName
     * @param videoId
     * @param shoeCode
     * @param beginTime
     * @param endTime
     * @param orderBy
     * @param pageNo
     * @param pageSize
     * @param key
     * @return QueryResult<PokerShoeStatisticEntity>
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    QueryResult<BaGameEntity> getGameResult(@WebParam(name = "productId") String productId,
                                            @WebParam(name = "platformId") String platformId,
                                            @WebParam(name = "loginName") String loginName,
                                            @WebParam(name = "videoId") String videoId,
                                            @WebParam(name = "shoeCode") String shoeCode,
                                            @WebParam(name = "beginTime") String beginTime,
                                            @WebParam(name = "endTime") String endTime,
                                            @WebParam(name = "orderBy") String orderBy,
                                            @WebParam(name = "pageNo") Integer pageNo,
                                            @WebParam(name = "pageSize") Integer pageSize,
                                            @WebParam(name = "key") String key,
                                            @WebParam(name = "gameCode") String[] gameCode) throws GWPersistenceException, GWKeyErrorException;

    /**
     * 查询指定时间内玩家最多的游戏
     *
     * @param productId
     * @param platforms
     * @param top
     * @param key
     * @param gameKind
     * @param beginTime
     * @param endTime
     * @return
     * @throws GWPersistenceException
     */
    QueryResult<PopularGame> getMostPopularGameRank(
            @WebParam(name = "productId") String productId,
            @WebParam(name = "platforms") String[] platforms,
            @WebParam(name = "top") Integer top,
            @WebParam(name = "key") String key,
            @WebParam(name = "gameKind") String gameKind,
            @WebParam(name = "beginTime") String beginTime,
            @WebParam(name = "endTime") String endTime
    ) throws GWPersistenceException;


    /**
     * 查询用户投注记录(供前端使用)
     *
     * @param productId
     * @param platformId
     * @param gameKind
     * @param loginName
     * @param beginTime
     * @param endTime
     * @param pageSize
     * @param pageNo
     * @param key
     * @return
     * @throws Exception
     */
    QueryResult<BetRecord> getBetRecord(
            @WebParam(name = "productId") String productId,
            @WebParam(name = "platformId") String platformId,
            @WebParam(name = "gameKind") String gameKind,
            @WebParam(name = "loginName") String loginName,
            @WebParam(name = "beginTime") String beginTime,
            @WebParam(name = "endTime") String endTime,
            @WebParam(name = "pageSize") Integer pageSize,
            @WebParam(name = "pageNo") Integer pageNo,
            @WebParam(name = "key") String key
    ) throws Exception;

    /**
     * 查询用户投注记录(供风控使用)
     *
     * @param productId
     * @param platformId
     * @param gameKind
     * @param loginName
     * @param gameType
     * @param gameCode
     * @param beginTime
     * @param endTime
     * @param pageSize
     * @param pageNo
     * @param orderBy
     * @param key
     * @return
     * @throws Exception
     */
    QueryResult<GameOrder> getGameOrderByPage(
            @WebParam(name = "productId") String productId,
            @WebParam(name = "platformId") String platformId,
            @WebParam(name = "gameKind") String gameKind,
            @WebParam(name = "loginName") String loginName,
            @WebParam(name = "gameType") String gameType,
            @WebParam(name = "gameCode") String gameCode,
            @WebParam(name = "beginTime") String beginTime,
            @WebParam(name = "endTime") String endTime,
            @WebParam(name = "pageSize") Integer pageSize,
            @WebParam(name = "pageNo") Integer pageNo,
            @WebParam(name = "orderBy") String orderBy,
            @WebParam(name = "key") String key
    ) throws Exception;

    /**
     * 查询OrderSummary表中的数据
     *
     * @param updateTime
     * @param pageSize
     * @param pageNo
     * @param key
     * @return
     * @throws Exception
     */
    QueryResult<OrderSummary> getOrderSummary(
            @WebParam(name = "updateTime") Long updateTime,
            @WebParam(name = "pageSize") Integer pageSize,
            @WebParam(name = "pageNo") Integer pageNo,
            @WebParam(name = "key") String key
    ) throws Exception;

    /**
     * 查询游戏及游戏厅
     *
     * @return
     * @throws Exception
     */
    QueryResult<Game> getGames() throws Exception;

    /**
     * 根据用户和局号查询投注额
     *
     * @param platformId
     * @param loginName
     * @param videoId
     * @param beginTime
     * @param endTime
     * @param key
     * @return
     * @throws Exception
     */
    QueryResult<GameOrder> getOrderByVideo(
            @WebParam(name = "productId") String productId,
            @WebParam(name = "platformId") String platformId,
            @WebParam(name = "loginName") String[] loginName,
            @WebParam(name = "videoId") String[] videoId,
            @WebParam(name = "beginTime") String beginTime,
            @WebParam(name = "endTime") String endTime,
            @WebParam(name = "key") String key
    ) throws Exception;

    /**
     * @param productId      产品id，例：A03
     * @param timeZoneId     时区
     * @param loginNameArray 用户名（不带产品id的用户名，逗号分隔），例：fjohn
     * @param beginDate      开始日期（YYYY-MM-DD）
     * @param endDate        截止日期（YYYY-MM-DD）
     * @param gameKind       游戏大类
     * @param type           汇总的时间类型参数（1-按日  2-按月 ）
     * @param pageNo
     * @param pageSize
     * @param key
     * @param orderByField   排序字段
     * @Description: 电销系统按照时间汇总有效投注额，数据来源T_ORDERS_STATISTICS
     * @Author: Ziv.Y
     * @Date: 2018/5/10 16:45
     */
    QueryResult<AccountTotalEntity> getValidAmountFromStatisticsByType(
            @WebParam(name = "productId") String productId,
            @WebParam(name = "timeZoneId") String timeZoneId,
            @WebParam(name = "loginNameArray") String loginNameArray,
            @WebParam(name = "beginDate") String beginDate,
            @WebParam(name = "endDate") String endDate,
            @WebParam(name = "gameKind") Integer gameKind,
            @WebParam(name = "type") Integer type,
            @WebParam(name = "pageNo") Integer pageNo,
            @WebParam(name = "pageSize") Integer pageSize,
            @WebParam(name = "key") String key,
            @WebParam(name = "orderByField") String orderByField
    ) throws GWPersistenceException, GWKeyErrorException;

    /**
     * @Description: 统计用户一个时间段的T_ORDERS_SUMMARY表汇总数据
     * @Author: Ziv.Y
     * @Date: 2018/7/28 10:14
     */
    QueryResult<AccountTotalEntity> getOrderSummaryGroupByPidUsername(
            @WebParam(name = "productId") String productId,
            @WebParam(name = "loginNameArray") String[] loginNameArray,
            @WebParam(name = "excludePlatformArray") String[] excludePlatformArray,
            @WebParam(name = "beginDate") String beginDate,
            @WebParam(name = "endDate") String endDate,
            @WebParam(name = "pageNo") Integer pageNo,
            @WebParam(name = "pageSize") Integer pageSize,
            @WebParam(name = "key") String key,
            @WebParam(name = "currency") String currency
    ) throws GWPersistenceException, GWKeyErrorException;

    /**
     * @Description: 新活动系统排行榜
     * @Author: Ziv.Y
     * @Date: 2019/9/26 15:58
     */
    QueryResult<AccountTotalEntity> getOrderSummaryGroupByPidUsername4ActivityList(
            @WebParam(name = "productId") String productId,
            @WebParam(name = "platformArray") String[] platformArray,
            @WebParam(name = "gameKindArray") String[] gameKindArray,
            @WebParam(name = "gameTypeArray") String[] gameTypeArray,
            @WebParam(name = "beginDate") String beginDate,
            @WebParam(name = "endDate") String endDate,
            @WebParam(name = "minSumAmount") Long minSumAmount,
            @WebParam(name = "currency") String currency,
            @WebParam(name = "rank") Integer rank,
            @WebParam(name = "fieldsOrder") String fieldsOrder,
            @WebParam(name = "key") String key
    ) throws GWPersistenceException, GWKeyErrorException;

    /**
     * @Description: 按产品、平台、用户分组T_ORDERS_SUMMARY表汇总数据
     * @Author: Ziv.Y
     * @Date: 2018/8/10 10:47
     */
    QueryResult<AccountTotalEntity> getOrderSummaryGroupByPidPlatIdUn(
            @WebParam(name = "productId") String productId,
            @WebParam(name = "platformArray") String[] platformArray,
            @WebParam(name = "loginNameArray") String[] loginNameArray,
            @WebParam(name = "gameKindArray") String[] gameKindArray,
            @WebParam(name = "beginDate") String beginDate,
            @WebParam(name = "endDate") String endDate,
            @WebParam(name = "pageNo") Integer pageNo,
            @WebParam(name = "pageSize") Integer pageSize,
            @WebParam(name = "key") String key,
            @WebParam(name = "currency") String currency
    ) throws GWPersistenceException, GWKeyErrorException;

    Map<String,Object> getOrderSummaryGroupByPlatGameUn(GetOrderSummaryGroupByPlatGameUnRequest request) throws GWPersistenceException, GWKeyErrorException;
    /**
     * 三级分销使用从汇总表查提高效率
     * 根据 PRODUCT,loginname,PLATFORM,GAMEKIND 分组
     *
     * @param productId
     * @param loginNameArray
     * @param platformArray
     * @param gameKindArray
     * @param endTime
     * @param endTime
     * @param pageNo
     * @param pageSize
     * @return
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    QueryResult<AccountTotalEntity> getOrdersSumGroupByLoginName(@WebParam(name = "productId") String productId, @WebParam(name = "loginNameArray") String[] loginNameArray,
                                                                 @WebParam(name = "platformArray") String[] platformArray,
                                                                 @WebParam(name = "gameKindArray") String[] gameKindArray,
                                                                 @WebParam(name = "beginTime") String beginTime, @WebParam(name = "endTime") String endTime,
                                                                 @WebParam(name = "pageNo") Integer pageNo, @WebParam(name = "pageSize") Integer pageSize)
            throws GWPersistenceException, GWKeyErrorException;


    /**
     * Get MG and PPG abnormal data list by input parameters.
     *
     * @param loginName
     * @param productId
     * @param beginDate
     * @param endDate
     * @param pageNo
     * @param pageSize
     * @param key
     * @return
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    QueryResult<MGAndTTGAbnormalEntity> getMGAndTTGAbnormalData(@WebParam(name = "loginName") String loginName,
                                                                @WebParam(name = "productId") String productId,
                                                                @WebParam(name = "beginDate") String beginDate,
                                                                @WebParam(name = "endDate") String endDate,
                                                                @WebParam(name = "pageNo") Integer pageNo,
                                                                @WebParam(name = "pageSize") Integer pageSize,
                                                                @WebParam(name = "key") String key) throws GWPersistenceException, GWKeyErrorException;

    /**
     * 分类洗码接口，注单表，group by product_id,LOGINNAME,platform_id,game_kind
     *
     * @param productId
     * @param loginNameArray
     * @param platformAndGameKindList
     * @param beginTime
     * @param endTime
     * @return
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    List<AccountTotalEntity> getOrdersRemainGroupList(@WebParam(name = "productId") String productId, @WebParam(name = "loginNameArray") String[] loginNameArray,
                                                      @WebParam(name = "platformAndGameKindList") List<PlatformGamekind> platformAndGameKindList,
                                                      @WebParam(name = "beginTime") String beginTime, @WebParam(name = "endTime") String endTime)
            throws GWPersistenceException, GWKeyErrorException;

    /**
     * AGQJ篡改注单查询接口
     *
     * @param productId
     * @param loginName
     * @param beginTime
     * @param endTime
     * @param key
     * @return
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    List<OrderAGQJExceptionor> getOrdersAGQJExceptionor(@WebParam(name = "productId") String productId, @WebParam(name = "loginName") String loginName,
                                                        @WebParam(name = "beginTime") String beginTime, @WebParam(name = "endTime") String endTime, @WebParam(name = "key") String key)
            throws GWPersistenceException, GWKeyErrorException;

    /**
     * 按platformID|gameKind 查询下注用户
     *
     * @param platform
     * @param beginTime
     * @param endTime
     * @param key
     * @return
     * @throws Exception
     */
    QueryResult<String> getCustomerByPlatformAndGameKind(
            @WebParam(name = "productId") String productId,
            @WebParam(name = "platform") PlatformGameKinds[] platform,
            @WebParam(name = "beginTime") String beginTime,
            @WebParam(name = "endTime") String endTime,
            @WebParam(name = "key") String key
    ) throws Exception;

    /**
     * Get attendance promo list by input parameters.
     *
     * @param productId
     * @param platformId
     * @param loginNameArray
     * @param beginTime
     * @param endTime
     * @param pageNo
     * @param pageSize
     * @param key
     * @return List
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    List<AttendancePromoEntity> getAttendancePromoList(@WebParam(name = "productId") String productId,
                                                       @WebParam(name = "platformId") String platformId, @WebParam(name = "loginNameArray") String loginNameArray,
                                                       @WebParam(name = "beginTime") String beginTime, @WebParam(name = "endTime") String endTime, @WebParam(name = "pageNo") Integer pageNo,
                                                       @WebParam(name = "pageSize") Integer pageSize, @WebParam(name = "key") String key) throws GWPersistenceException, GWKeyErrorException;

    /**
     * Get valid activity entity list
     *
     * @param productId    (A01,A02,A03...)
     * @param platformId
     * @param gameType
     * @param beginTime
     * @param endTime
     * @param isWinBetOnly
     * @param pageNo
     * @param pageSize
     * @param key
     * @return QueryResult
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    QueryResult<ActivityEntity> getActivityOrderRecords(@WebParam(name = "productId") String productId,
                                                        @WebParam(name = "platformId") String platformId, @WebParam(name = "loginNameArray") String loginNameArray,
                                                        @WebParam(name = "gameType") String gameType, @WebParam(name = "beginTime") String beginTime, @WebParam(name = "endTime") String endTime,
                                                        @WebParam(name = "isWinBetOnly") boolean isWinBetOnly, @WebParam(name = "pageNo") Integer pageNo,
                                                        @WebParam(name = "pageSize") Integer pageSize, @WebParam(name = "key") String key) throws GWPersistenceException, GWKeyErrorException;

    QueryResult<OrderEntity> getHighProfitOrderListByDeviceType(@WebParam(name = "productId") String productId,
                                                                @WebParam(name = "platformId") String[] platformId,
                                                                @WebParam(name = "gameKind") String[] gameKind,
                                                                @WebParam(name = "beginTime") String beginTime,
                                                                @WebParam(name = "endTime") String endTime,
                                                                @WebParam(name = "minBetAmount") Integer minBetAmount,
                                                                @WebParam(name = "cusAmount") Integer cusAmount,
                                                                @WebParam(name = "multiple") Integer multiple,
                                                                @WebParam(name = "pageNo") Integer pageNo,
                                                                @WebParam(name = "pageSize") Integer pageSize,
                                                                @WebParam(name = "key") String key,
                                                                @WebParam(name = "deviceType") Integer deviceType) throws GWPersistenceException, GWKeyErrorException;


    List<CustomerDynamicEntity> getCustomerDynamic(@WebParam(name = "productId") String productId,
                                                   @WebParam(name = "beginTime") String beginTime,
                                                   @WebParam(name = "endTime") String endTime,
                                                   @WebParam(name = "betMin") BigDecimal betMin,
                                                   @WebParam(name = "winMin") BigDecimal winMin,
                                                   @WebParam(name = "size") Integer size,
                                                   @WebParam(name = "currency") String currency,
                                                   @WebParam(name = "key") String key) throws GWPersistenceException, GWKeyErrorException;

    //查询有效投注额
    QueryResult<AccountTotalEntity> getWagerSummary(
            @WebParam(name = "productId") String productId,
            @WebParam(name = "platformId") String[] platformId,
            @WebParam(name = "gameKind") String[] gameKind,
            @WebParam(name = "loginName") String[] loginName,
            @WebParam(name = "minBetAmount") String minBetAmount,
            @WebParam(name = "settleFlag") String settleFlag,//0//1//2//3
            @WebParam(name = "beginTime") String beginTime,
            @WebParam(name = "endTime") String endTime,
            @WebParam(name = "pageNo") Integer pageNo,
            @WebParam(name = "pageSize") Integer pageSize,
            @WebParam(name = "key") String key)
            throws GWPersistenceException, GWKeyErrorException;

    //查询符合体育类优惠活动的记录
    QueryResult<OrderEntity> getEligibilityOrder(
            @WebParam(name = "productId") String productId,
            @WebParam(name = "platformId") String[] platformId,
            @WebParam(name = "gameKind") String[] gameKind,
            @WebParam(name = "loginNames") String[] loginNames,
            @WebParam(name = "minBetAmount") Integer minBetAmount,
            @WebParam(name = "queryType") String queryType,
            @WebParam(name = "key") String key,
            @WebParam(name = "beginTime") String beginTime,
            @WebParam(name = "endTime") String endTime,
            @WebParam(name = "pageNo") Integer pageNo,
            @WebParam(name = "pageSize") Integer pageSize)
            throws GWPersistenceException, GWKeyErrorException;

    void updateCustomerMainLoginName(
            @WebParam(name = "productId") String productId,
            @WebParam(name = "loginName") String loginName,
            @WebParam(name = "mainLoginName") String mainLoginName)
            throws GWPersistenceException, GWKeyErrorException;


}
