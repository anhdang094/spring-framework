package com.gw.datacenter.cxf.impl;

import com.gw.datacenter.common.exception.GWDataCenterException;
import com.gw.datacenter.common.exception.GWKeyErrorException;
import com.gw.datacenter.common.exception.GWPersistenceException;
import com.gw.datacenter.common.util.DataUtil;
import com.gw.datacenter.controller.request.GetOrderSummaryGroupByPlatGameUnRequest;
import com.gw.datacenter.controller.result.GetOrderSummaryGroupByPlatGameUnResponse;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.service.*;
import com.gw.datacenter.vo.activity.ActivityEntity;
import com.gw.datacenter.vo.activity.AttendancePromoEntity;
import com.gw.datacenter.vo.dictionary.DictionaryEntity;
import com.gw.datacenter.vo.gameresult.BaGameEntity;
import com.gw.datacenter.vo.gameresult.PokerShoeStatisticEntity;
import com.gw.datacenter.vo.gametypeplaytype.GameTypePlayTypeEntity;
import com.gw.datacenter.vo.order.*;
import com.gw.datacenter.vo.pagainate.QueryResult;
import com.gw.datacenter.vo.pagainate.QueryResultWrapper;
import com.gw.datacenter.vo.transfer.TransferGroupByType;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.jws.WebService;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebService(endpointInterface = "com.gw.datacenter.cxf.DataCenterApi")
@Service
public class DataCenterApiImpl implements DataCenterApi {
    @Resource
    private OrderService orderService;
    @Resource
    private GameTypePlayTypeService gameTypePlayTypeService;
    @Resource
    private ActivityService activityService;
    @Resource
    private CustomerService customerService;

    @Resource
    private DictionaryService dictionaryService;

    @Override
    public List<TransferGroupByType> getTransferSumGroupByType(String[] platformArray, String[] platformArrayAG, String beginTime, String endTime, String productId, String userName) throws Exception {
        if (StringUtils.isBlank(beginTime) || StringUtils.isBlank(endTime) || StringUtils.isBlank(userName)) {
            throw new GWDataCenterException("参数不能为空");
        }
        if (null == platformArray && platformArrayAG == null) {
            throw new GWDataCenterException("platform不能都为空");
        }
        List<TransferGroupByType> result = new ArrayList<>();
        result = orderService.getTransferSumGroupByType(platformArray, platformArrayAG, beginTime, endTime, productId, userName);
        return result;
    }

    @Override
    public QueryResult<GameTypePlayTypeEntity> getGameTypeAndPlayType(String[] platformArray, Integer type, String updateTime) throws Exception {
        Map<String, Object> parameterMap = new HashMap<>();
        parameterMap.put("type", type);
        parameterMap.put("platformArray", platformArray);
        parameterMap.put("updateTime", updateTime);
        QueryResult<GameTypePlayTypeEntity> result = new QueryResult<>();
        List<GameTypePlayTypeEntity> listData = orderService.getGameTypeAndPlayType(parameterMap);
        result.setQueryResultList(listData);
        result.setTotalRecords(listData.size());
        return result;
    }

    @Override
    public QueryResult<AccountTotalEntity> getValidAmountByType(String productId, String platformId, String validAccount, String timeZoneId, String loginNameArray, String beginTime, String endTime, Integer gameKind, Integer type, Integer pageNo, Integer pageSize, String key, String orderByField, String[] rankLoginNameList, String[] gameType, String MinBetTimes, String currency, BigDecimal minCustAmount, BigDecimal minValidAmount) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getValidAmountQueryResultByType(productId, platformId, validAccount, timeZoneId, loginNameArray, beginTime, endTime,
                gameKind, type, pageNo, pageSize, key, orderByField, rankLoginNameList, gameType, MinBetTimes, currency, minCustAmount, minValidAmount);
    }

    @Override
    public QueryResult<AccountTotalEntity> getValidAmountByTypeAndFlag(String productId, String platformId, String validAccount, String timeZoneId, String loginNameArray, String beginTime, String endTime, Integer gameKind, Integer type, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getValidAmountQueryResultByTypeAndFlag(productId, platformId, validAccount, timeZoneId, loginNameArray, beginTime, endTime,
                gameKind, type, pageNo, pageSize, key);
    }

    @Override
    public QueryResult<OrderEntity> getOrderEntity(String productId, String[] platformId, String validAccount, String timeZoneId, String loginNameArray, String beginTime, String endTime, Integer gameKind, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getOrderEntity(productId, platformId, validAccount, timeZoneId, loginNameArray, beginTime, endTime, gameKind, pageNo, pageSize, key);
    }
    @Override
    public QueryResult<ProfitRanking> getAgListOrder(String productId, String [] loginNames, String []  gameKind, String currency, String beginTime, String endTime, String limit) throws GWPersistenceException, GWKeyErrorException {
        return  orderService.getAgListOrder(productId, loginNames, gameKind,currency,beginTime,endTime,limit);
    }

    public List<ProfitEntity> profitRankings(String productId, String platformId, String [] gameKind, String beginTime, String endTime, String currency, String limit) throws GWPersistenceException, GWKeyErrorException {
        return orderService.profitRankings(productId, platformId, gameKind, beginTime, endTime,  currency,limit);
    }

    @Override
    public List<DictionaryEntity> getProductPlatforms(String productId) throws GWPersistenceException {
        Map<String, Object> params = new HashMap<>();
        params.put("dictValue", productId);
        params.put("dictName", "PLATFORM");
        return dictionaryService.getDictionaryByRelation(params);
    }

    @Override
    public QueryResult<AccountTotalEntity> getMaxEffectiveBettingAmount(String productId, String loginNameArray, Integer resultType, String beginTime, String endTime, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getMaxEffectiveBettingAmount(productId, loginNameArray, resultType, beginTime, endTime, pageNo, pageSize, key);
    }

    @Override
    public QueryResult<OrderEntity> getOrderDetailsByGmCode(String productId, String loginName, String gameCode, String beginTime, String endTime, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getOrderDetailsByGmCode(productId, loginName, gameCode, beginTime, endTime, pageNo, pageSize, key);
    }

    @Override
    public QueryResultWrapper getOrderDetailsAndSummaryByGmCode(String productId, String loginName, String gameCode, String beginTime, String endTime, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getOrderDetailsAndSummaryByGmCode(productId, loginName, gameCode, beginTime, endTime, pageNo, pageSize, key);
    }

    @Override
    public List<MonthlyWeeklyEffectiveBetAmountEntity> getMonthlyAndWeeklyValidAmount(String productId, String loginNameArray, BigDecimal amount, String weekBeginTime, String weekEndTime, String monthBeginTime, String monthEndTime, String key) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getMonthlyAndWeeklyValidAmount(productId, loginNameArray, amount, weekBeginTime, weekEndTime, monthBeginTime, monthEndTime, key);
    }

    @Override
    public QueryResult<OrderEntity> getCustomerBetTime(String productId, String loginName, Integer type, String key) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getCustomerBetTime(productId, loginName, type, key);
    }

    @Override
    public QueryResult<ContinuousOrder> getContinuousOrder(String productId, String[] platformId, String beginTime, String endTime, String gameKind, Integer times, Integer minAmount, String key) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getContinuousOrder(productId, platformId, beginTime, endTime, gameKind, times, minAmount, key);
    }

    @Override
    public QueryResult<OrderEntity> getOrderListByProfit(String productId, String[] platformId, String beginTime, String endTime, Integer multiple, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getOrderListByProfit(productId, platformId, beginTime, endTime, multiple, pageNo, pageSize, key);
    }

    @Override
    public QueryResult<OrderEntity> getHighProfitOrderList(String productId, String[] platformId, String[] gameKind, String beginTime, String endTime, Integer cusAmount, Integer multiple, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getHighProfitOrderList(productId, platformId, gameKind, beginTime, endTime, cusAmount, multiple, pageNo, pageSize, key);
    }

    @Override
    public QueryResult<OrderEntity> getBetHistory(String productId, String[] platformId, String beginTime, String endTime, Integer flag, Integer cusAmount, Integer multiple, Integer maxRecode, String key) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getBetHistory(productId, platformId, beginTime, endTime, flag, cusAmount, multiple, maxRecode, key);
    }

    @Override
    public QueryResult<OrderEntity> getBestWin(String productId, String[] platformId, String beginTime, String endTime, Integer cusAmount, Integer listCount, String key) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getBestWin(productId, platformId, beginTime, endTime, cusAmount, listCount, key);
    }

    @Override
    public QueryResult<OrderEntity> getOrderByMultipleAndValidAccount2(String productId, String[] platformId, String beginTime, String endTime, OrderEntity orderEntity, Integer multiple, Integer pageNo, Integer pageSize) throws GWPersistenceException {
        return orderService.getOrderByMultipleAndValidAccount2(productId, platformId, beginTime, endTime, orderEntity, multiple, pageNo, pageSize);
    }

    @Override
    public QueryResult<OrderEntity> getRecord(String productId, String[] platformId, String[] loginName, String[] gameKind, String beginTime, String endTime, String settledType, Integer minBetAmount, Integer minCusAmount, Integer minMultiple, String fieldsOrder, Integer pageNo, Integer pageSize, String key, String gameType, String[] gameCode, String billNo, String currency, Integer remainAmount) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getRecord(productId, platformId, loginName, gameKind, beginTime, endTime, settledType, minBetAmount, minCusAmount, minMultiple, fieldsOrder, pageNo, pageSize, key, gameType, gameCode, billNo, currency, remainAmount);
    }

    @Override
    public QueryResultWrapper getRecordAndSummary(String productId, String[] platformId, String[] loginName, String[] gameKind, String beginTime, String endTime, String settledType, Integer minBetAmount, Integer minCusAmount, Integer minMultiple, String fieldsOrder, Integer pageNo, Integer pageSize, String key, String[] gameType, String[] gameCode, Integer remainAmount, String currency) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getRecordAndSummary(productId, platformId, loginName, gameKind, beginTime, endTime, settledType, minBetAmount, minCusAmount, minMultiple, fieldsOrder, pageNo, pageSize, key, gameType, gameCode, remainAmount, currency);
    }

    @Override
    public QueryResult<OrderSummary> getRecordSummary(String productId, String[] platformId, String[] loginName, String[] gameKind, String beginTime, String endTime, String settledType, Integer minBetAmount, Integer minCusAmount, Integer minMultiple, String fieldsOrder, Integer pageNo, Integer pageSize, String key, String[] gameType, String[] gameCode, Integer remainAmount) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getRecordSummary(productId, platformId, loginName, gameKind, beginTime, endTime, settledType, minBetAmount, minCusAmount, minMultiple, fieldsOrder, pageNo, pageSize, key, gameType, gameCode, remainAmount);
    }

    @Override
    public QueryResult<OrderEntity> getRecordMaxBy(String productId, String[] platformId, String[] loginName, String[] gameKind, String beginTime, String endTime, String settledType, Integer minBetAmount, Integer minCusAmount, Integer minMultiple, String fieldsOrder, String maxField, String groupField, Integer pageNo, Integer pageSize, String key, String currency) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getRecordMax(productId, platformId, loginName, gameKind, beginTime, endTime, settledType, minBetAmount, minCusAmount, minMultiple, fieldsOrder, maxField, groupField, pageNo, pageSize, key, currency);
    }

    public List<BetRankEntity> getBetRank(String productId, String[] platformId, String[] gameKind, String loginName, String beginTime, String endTime, Integer winListType, Integer minWinLostCount, Integer minBetAmount, String fieldsOrder, Integer pageSize, String key, String currency, BigDecimal minValidAmount) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getBetRank(productId, platformId, gameKind, loginName, beginTime, endTime, winListType, minWinLostCount, minBetAmount, fieldsOrder, pageSize, key, currency, minValidAmount);
    }

    @Override
    public List<PlayerWinsEntity> getPlayerWins(String productId, String loginName, String beginTime, String endTime, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getPlayerWins(productId, loginName, beginTime, endTime, pageSize, key);
    }

    @Override
    public List<TopWinnerEntity> getTopWinners(String productId, String beginTime, String endTime, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getTopWinners(productId, beginTime, endTime, pageSize, key);
    }

    @Override
    public List<SuperWinEntity> getSuperWins(String productId, String beginTime, String endTime, Integer realMulti, Integer realAmount, Integer sportMulti, Integer sportAmount, Integer lotteryMulti, Integer lotteryAmount, Integer slotMulti, Integer slotAmount, Integer fishMulti, Integer fishAmount, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getSuperWins(productId, beginTime, endTime, realMulti, realAmount, sportMulti, sportAmount, lotteryMulti, lotteryAmount, slotMulti, slotAmount, fishMulti, fishAmount, pageSize, key);
    }


    @Override
    public QueryResultWrapper getRecordMaxAndSummaryBy(String productId, String[] platformId, String[] loginName, String[] gameKind, String beginTime, String endTime, String settledType, Integer minBetAmount, Integer minCusAmount, Integer minMultiple, String fieldsOrder, String maxField, String groupField, Integer pageNo, Integer pageSize, String key, String currency) throws GWPersistenceException, GWKeyErrorException {
        QueryResult<OrderEntity> result = orderService.getRecordMax(productId, platformId, loginName, gameKind, beginTime, endTime, settledType, minBetAmount, minCusAmount, minMultiple, fieldsOrder, maxField, groupField, pageNo, pageSize, key, currency);
        List<OrderEntity> orderList = result.getQueryResultList();
        if (CollectionUtils.isNotEmpty(orderList)) {
            QueryResultWrapper wrapper = new QueryResultWrapper();
            wrapper.setQueryResult(result);
            //查询统计数据
            String[] recordMaxSummaryGroupBy = orderService.getRecordMaxSummary(productId, platformId, loginName, gameKind, beginTime, endTime, settledType, minBetAmount, minCusAmount, minMultiple, fieldsOrder, maxField, groupField, pageNo, pageSize, key, currency);
            if (recordMaxSummaryGroupBy != null) {
                result.setTotalRecords(Integer.parseInt(recordMaxSummaryGroupBy[0]));
            }
            wrapper.setUtilArray(recordMaxSummaryGroupBy);
            return wrapper;
        } else {
            return null;
        }
    }

    @Override
    public QueryResultWrapper getBoWinList(String productId, String loginName, String beginTime, String endTime, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getBoWinList(productId, loginName, beginTime, endTime, pageNo, pageSize, key);
    }

    @Override
    public QueryResult<UserWagerInfo> getFirstBetList(String productId, String beginTime, String endTime, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getFirstBetWinList(productId, beginTime, endTime, 1, pageNo, pageSize, key);
    }

    @Override
    public QueryResult<OrderEntity> getAGQJDeskInfos(String productId, String beginTime, String endTime, String limit, String key) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getAGQJDeskInfos(productId, beginTime, endTime, limit, key);
    }

    @Override
    public QueryResult<PokerShoeStatisticEntity> getMaxValueGroupByShoecode(String productId, String platformId, String loginName, String videoId, String shoeCode, String beginTime, String endTime, String orderBy, Integer pageNo, Integer pageSize, String key, String[] gameType, String minBetTimes) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getMaxValueGroupByShoecode(productId, platformId, loginName, videoId, shoeCode, beginTime, endTime, orderBy, pageNo, pageSize, key, gameType, minBetTimes);
    }

    @Override
    public QueryResult<BaGameEntity> getGameResult(String productId, String platformId, String loginName, String videoId, String shoeCode, String beginTime, String endTime, String orderBy, Integer pageNo, Integer pageSize, String key, String[] gameCode) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getGameResult(productId, platformId, loginName, videoId, shoeCode, beginTime, endTime, orderBy, pageNo, pageSize, key, gameCode);
    }

    @Override
    public QueryResult<PopularGame> getMostPopularGameRank(String productId, String[] platforms, Integer top, String key, String gameKind, String beginTime, String endTime) throws GWPersistenceException {
        return orderService.getMostPopularGameRank(productId, top, platforms, gameKind, beginTime, endTime, key);
    }

    @Override
    public QueryResult<BetRecord> getBetRecord(String productId, String platformId, String gameKind, String loginName, String beginTime, String endTime, Integer pageSize, Integer pageNo, String key) throws Exception {
        return orderService.getBetRecord(productId, platformId, gameKind, loginName, beginTime, endTime, pageSize, pageNo, key);
    }

    @Override
    public QueryResult<GameOrder> getGameOrderByPage(String productId, String platformId, String gameKind, String loginName, String gameType, String gameCode, String beginTime, String endTime, Integer pageSize, Integer pageNo, String orderBy, String key) throws Exception {
        return orderService.getGameOrderByPage(productId, platformId, gameKind, loginName, gameType, gameCode, beginTime, endTime, pageSize, pageNo, orderBy, key);
    }

    @Override
    public QueryResult<OrderSummary> getOrderSummary(Long updateTime, Integer pageSize, Integer pageNo, String key) throws Exception {
        return orderService.getOrderSummary(updateTime, pageSize, pageNo, key);
    }

    @Override
    public QueryResult<Game> getGames() throws Exception {
        return orderService.getGames();
    }

    @Override
    public QueryResult<GameOrder> getOrderByVideo(String productId, String platformId, String[] loginName, String[] videoId, String beginTime, String endTime, String key) throws Exception {
        return orderService.getOrderByVideo(productId, platformId, loginName, videoId, beginTime, endTime, key);
    }

    @Override
    public QueryResult<AccountTotalEntity> getValidAmountFromStatisticsByType(String productId, String timeZoneId, String loginNameArray, String beginDate, String endDate, Integer gameKind, Integer type, Integer pageNo, Integer pageSize, String key, String orderByField) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getValidAmountFromStatisticsByType(productId, timeZoneId, loginNameArray, beginDate, endDate,
                gameKind, type, pageNo, pageSize, key, orderByField);
    }

    @Override
    public QueryResult<AccountTotalEntity> getOrderSummaryGroupByPidUsername(String productId, String[] loginNameArray, String[] excludePlatformArray, String beginDate, String endDate, Integer pageNo, Integer pageSize, String key, String currency) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getOrderSummaryGroupByPidUsername(productId, loginNameArray, excludePlatformArray, beginDate, endDate, pageNo, pageSize, key, currency);
    }

    @Override
    public QueryResult<AccountTotalEntity> getOrderSummaryGroupByDay(String productId, String[] loginNameList, String beginDate, String endDate) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getOrderSummaryGroupByDay(productId, loginNameList, beginDate, endDate);
    }

    /**
     * @Description: 新活动系统排行榜
     * @Author: Ziv.Y
     * @Date: 2019/9/26 15:58
     */
    @Override
    public QueryResult<AccountTotalEntity> getOrderSummaryGroupByPidUsername4ActivityList(String productId, String[] platformArray, String[] gameKindArray, String[] gameTypeArray, String beginDate, String endDate,
                                                                                          Long minSumAmount, String currency, Integer rank, String fieldsOrder, String key) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getOrderSummaryGroupByPidUsername4ActivityList(productId, platformArray, gameKindArray, gameTypeArray, beginDate, endDate, minSumAmount, currency, rank, fieldsOrder, key);
    }

    @Override
    public QueryResult<AccountTotalEntity> getOrderSummaryGroupByPidPlatIdUn(String productId, String[] platformArray, String[] loginNameArray, String[] gameKindArray, String beginDate, String endDate, Integer pageNo, Integer pageSize, String key, String currency) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getOrderSummaryGroupByPidPlatIdUn(productId, platformArray, loginNameArray, gameKindArray, beginDate, endDate, pageNo, pageSize, key, currency);
    }

    @Override
    public Map<String,Object> getOrderSummaryGroupByPlatGameUn(GetOrderSummaryGroupByPlatGameUnRequest request) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getOrderSummaryGroupByPlatGameUn(request);
    }

    @Override
    public QueryResult<AccountTotalEntity> getOrdersSumGroupByLoginName(String productId, String[] loginNameArray, String[] platformArray, String[] gameKindArray, String beginTime, String endTime, Integer pageNo, Integer pageSize) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getOrdersSumGroupByLoginName(productId, loginNameArray, platformArray, gameKindArray, beginTime, endTime, pageNo, pageSize);
    }

    @Override
    public QueryResult<MGAndTTGAbnormalEntity> getMGAndTTGAbnormalData(String loginName, String productId, String beginDate, String endDate, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getMGAndTTGAbnormalData(loginName, productId, beginDate, endDate, pageNo, pageSize, key);
    }

    @Override
    public List<AccountTotalEntity> getOrdersRemainGroupList(String productId, String[] loginNameArray, List<PlatformGamekind> platformAndGameKindList, String beginTime, String endTime) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getOrdersRemainGroupList(productId, loginNameArray, platformAndGameKindList, beginTime, endTime);
    }

    @Override
    public List<OrderAGQJExceptionor> getOrdersAGQJExceptionor(String productId, String loginName, String beginTime, String endTime, String key) throws GWPersistenceException, GWKeyErrorException {
        List<OrderAGQJExceptionor> orderAGQJExceptionors = orderService.getOrdersAGQJExceptionor(productId, loginName, beginTime, endTime, key);
        Map<String, Object> pramater = new HashMap<>();
        pramater.put("type", 2);
        pramater.put("platformId", "003");
        List<GameTypePlayTypeEntity> playTypes = gameTypePlayTypeService.getGameTypePlayTypeListAll(pramater);
        orderAGQJExceptionors.stream().forEach(order -> {
            if (StringUtils.isNotEmpty(order.getOrigPlaytype())) {
                String playType = getPlayType(playTypes, order.getOrigPlaytype());
                if (StringUtils.isNotEmpty(playType)) {
                    order.setOrigPlaytypeZh(playType);
                }
            }
            if (StringUtils.isNotEmpty(order.getRecPlaytype())) {
                String playType = getPlayType(playTypes, order.getRecPlaytype());
                if (StringUtils.isNotEmpty(playType)) {
                    order.setRecPlaytypeZh(playType);
                }
            }
        });
        return orderAGQJExceptionors;
    }

    private String getPlayType(List<GameTypePlayTypeEntity> values, String playType) {
        StringBuffer sb = new StringBuffer();
        for (GameTypePlayTypeEntity gameTypePlayType : values) {
            if (StringUtils.isBlank(gameTypePlayType.getGameType())) {
                for (String play : playType.split(",")) {
                    if (StringUtils.equalsIgnoreCase(play, gameTypePlayType.getPlayType())) {
                        sb.append(gameTypePlayType.getChineseName() + " ");
                    }
                }
                if (sb.length() > 0) {
                    return sb.substring(0, sb.length() - 1);
                }
            }
        }
        return playType;
    }

    @Override
    public QueryResult<String> getCustomerByPlatformAndGameKind(String productId, PlatformGameKinds[] platform, String beginTime, String endTime, String key) throws Exception {
        return orderService.getCustomerByPlatformAndGameKind(productId, platform, beginTime, endTime, key);
    }

    /**
     * @Description: 这个活动全勤接口已经废弃，走活动系统了，这里加上只是为了office app那边不报错
     * @Author: Ziv.Y
     * @Date: 2019/1/31 14:29
     */
    public List<AttendancePromoEntity> getAttendancePromoList(String productId, String platformId, String loginNameArray, String beginTime,
                                                              String endTime, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException {
        return this.orderService.getAttendancePromoList(productId, platformId, loginNameArray, beginTime, endTime, pageNo, pageSize, key);
    }

    /**
     * @Description: 这个活动连赢接口已经废弃，走活动系统了，这里加上只是为了office app那边不报错
     * @Author: Ziv.Y
     * @Date: 2019/1/31 14:30
     */
    public QueryResult<ActivityEntity> getActivityOrderRecords(String productId, String platformId, String loginNameArray, String gameType,
                                                               String beginTime, String endTime, boolean isWinBetOnly, Integer pageNo, Integer pageSize,
                                                               String key) throws GWPersistenceException, GWKeyErrorException {
        return activityService.getActivityEntityList(productId, platformId, loginNameArray, gameType, beginTime, endTime, isWinBetOnly, pageNo, pageSize, key);
    }

    @Override
    public QueryResult<OrderEntity> getHighProfitOrderListByDeviceType(String productId, String[] platformId, String[] gameKind, String beginTime, String endTime,
                                                                       Integer minBetAmount, Integer cusAmount, Integer multiple, Integer pageNo, Integer pageSize,
                                                                       String key, Integer deviceType) throws GWPersistenceException, GWKeyErrorException {
        QueryResult<OrderEntity> result = orderService.getHighProfitOrderListByDeviceType(productId, platformId, gameKind, beginTime, endTime, minBetAmount, cusAmount, multiple, pageNo, pageSize, key, deviceType);
        if (result != null) {
            List<OrderEntity> orderList = result.getQueryResultList();
            if (orderList != null) {
                for (OrderEntity orderEntity : orderList) {
                    String gameName = DataUtil.getGameName(orderEntity);
                    orderEntity.setGameId(orderEntity.getGameType());
                    orderEntity.setGameType(gameName);
                }
            }
        }
        return result;
    }

    @Override
    public List<CustomerDynamicEntity> getCustomerDynamic(String productId, String beginTime, String endTime, BigDecimal betMin,
                                                          BigDecimal winMin, Integer size, String currency, String key) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getCustomerDynamic(productId, beginTime, endTime, betMin, winMin, size, currency, key);
    }

    @Override
    public QueryResult<AccountTotalEntity> getWagerSummary(String productId, String[] platformId, String[] gameKind, String[] loginName, String minBetAmount, String settleFlag, String beginTime, String endTime, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException {
        return orderService.getWagerSummary(productId, platformId, gameKind, loginName, minBetAmount, beginTime, endTime, pageNo, pageSize, key);
    }

    @Override
    public QueryResult<OrderEntity> getEligibilityOrder(String productId, String[] platformId, String[] gameKind, String[] loginNames, Integer minBetAmount, String queryType, String key, String beginTime, String endTime, Integer pageNo, Integer pageSize) throws GWPersistenceException, GWKeyErrorException {
        return this.orderService.getEligibilityOrder(productId, platformId, gameKind, loginNames, minBetAmount, queryType, key, beginTime, endTime, pageNo, pageSize);
    }

    @Override
    public void updateCustomerMainLoginName(String productId, String loginName, String mainLoginName) throws GWPersistenceException, GWKeyErrorException {
        customerService.updateCustomerMainLoginName(productId, loginName, mainLoginName);
    }


}
