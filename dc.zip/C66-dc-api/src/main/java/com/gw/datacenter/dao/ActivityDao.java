package com.gw.datacenter.dao;

import com.gw.datacenter.common.exception.GWPersistenceException;
import com.gw.datacenter.vo.activity.ActivityEntity;
import com.gw.datacenter.vo.pagainate.QueryResult;

import java.util.Map;

public interface ActivityDao {
    /**
     * Get consecutive win records
     * @param parameterMap
     * @return List<ActivityEntity>
     * @throws GWPersistenceException
     */
    QueryResult<ActivityEntity> getActivityEntityList(Map<String, Object> parameterMap) throws GWPersistenceException;
}
