package com.gw.datacenter.dao;

import com.gw.datacenter.common.exception.GWPersistenceException;

import java.util.Map;

public interface CustomerDao {

    void updateCustomerMainLoginName(Map<String, Object> parameterMap) throws GWPersistenceException;

}
