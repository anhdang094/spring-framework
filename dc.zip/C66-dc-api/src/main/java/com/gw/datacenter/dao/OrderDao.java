package com.gw.datacenter.dao;

import com.gw.datacenter.common.exception.GWPersistenceException;
import com.gw.datacenter.controller.result.GetOrderSummaryGroupByPlatGameUnResponse;
import com.gw.datacenter.vo.activity.AttendancePromoEntity;
import com.gw.datacenter.vo.gameresult.BaGameEntity;
import com.gw.datacenter.vo.gameresult.PokerShoeStatisticEntity;
import com.gw.datacenter.vo.gametypeplaytype.GameTypePlayTypeEntity;
import com.gw.datacenter.vo.order.*;
import com.gw.datacenter.vo.pagainate.QueryResult;
import com.gw.datacenter.vo.transfer.TransferGroupByType;

import java.util.List;
import java.util.Map;

public interface OrderDao {
    List<TransferGroupByType> getTransferSumGroupByType(Map<String, Object> params) throws GWPersistenceException;
    /**
     * 查询有效投注额(佣金)
     *
     * @param params
     * @return List<AccountTotalEntity>
     * @throws GWPersistenceException
     */
    List<AccountTotalEntity> getValidAmountListByType(Map<String, Object> params) throws GWPersistenceException;

    List<PlayerPlatformProfit> getPlayerPlatformProfit(Map<String, Object> params) throws GWPersistenceException;

    QueryResult<ProfitRanking> getAgListOrder(Map<String, Object> parameterMap) throws GWPersistenceException;

    List<ProfitEntity> profitRankings(Map<String,Object> params) throws GWPersistenceException;
    /**
     * 统计有效投注额条数(佣金)
     *
     * @param params
     * @return Integer
     * @throws GWPersistenceException
     */
    Integer countValidAmount(Map<String, Object> params) throws GWPersistenceException;

    /**
     * 查询注单明细
     *
     * @param params
     * @return
     * @throws GWPersistenceException
     */
    List<OrderEntity> getOrderEntity(Map<String, Object> params) throws GWPersistenceException;

    /**
     * 统计注单明细条数
     *
     * @param params
     * @return
     * @throws GWPersistenceException
     */
    Integer countOrderEntity(Map<String, Object> params) throws GWPersistenceException;

    /**
     * 获取最大投注额
     *
     * @param params
     * @return
     * @throws GWPersistenceException
     */
    List<AccountTotalEntity> getMaxEffectiveBettingAmountList(Map<String, Object> params) throws GWPersistenceException;

    /**
     * 统计最大投注额条数
     *
     * @param params
     * @return
     * @throws GWPersistenceException
     */
    Integer countMaxEffectiveBettingAmount(Map<String, Object> params) throws GWPersistenceException;

    List<AccountTotalEntity> getMaxEffectiveBettingByGameKind(Map<String, Object> params) throws GWPersistenceException;

    Integer countMaxEffectiveBettingByGameKind(Map<String, Object> params) throws GWPersistenceException;

    List<AccountTotalEntity> getMaxEffectiveBettingByAmountGameKind(Map<String, Object> params) throws GWPersistenceException;

    Integer countMaxEffectiveBettingByAmountGameKind(Map<String, Object> params) throws GWPersistenceException;

    List<OrderEntity> getOrderList(Map<String, Object> params) throws GWPersistenceException;

    String countTotalStrOrder(Map<String, Object> params) throws GWPersistenceException;

    List<OrderEntity> getBoWinList(Map<String, Object> params) throws GWPersistenceException;

    String countTotalStrBoWin(Map<String, Object> params) throws GWPersistenceException;

    List<MonthlyWeeklyEffectiveBetAmountEntity> getMonthlyAndWeeklyValidAmount(Map<String, Object> params) throws GWPersistenceException;

    List<OrderEntity> getCustomerBetTimeList(Map<String, Object> params) throws GWPersistenceException;

    List<ContinuousOrder> getContinuousOrder(Map<String, Object> params) throws GWPersistenceException;

    List<OrderEntity> getOrderListByProfit(Map<String, Object> params) throws GWPersistenceException;

    List<OrderEntity> getHighProfitOrderList(Map<String, Object> params) throws GWPersistenceException;

    List<OrderEntity> getBetHistory(Map<String, Object> params) throws GWPersistenceException;

    List<OrderEntity> getBetHistoryByMultipleProfit(Map<String, Object> params) throws GWPersistenceException;

    List<OrderEntity> getBestWin(Map<String, Object> params) throws GWPersistenceException;

    List<OrderEntity> getOrderByMultipleAndValidAccount2(Map<String, Object> params) throws GWPersistenceException;

    List<OrderEntity> getRecordList(Map<String, Object> params) throws GWPersistenceException;

    Integer countGetRecord(Map<String, Object> params) throws GWPersistenceException;

    String countTotalStrRecordAndSummary(Map<String, Object> params) throws GWPersistenceException;

    List<OrderSummary> getRecordSummay(Map<String,Object> params) throws GWPersistenceException;

    List<BetRankEntity> getBetRank(Map<String,Object> params) throws GWPersistenceException;

    List<PlayerWinsEntity> getPlayerWins(Map<String,Object> params) throws GWPersistenceException;

    List<TopWinnerEntity> getTopWinners(Map<String,Object> params) throws GWPersistenceException;

    List<SuperWinEntity> getSuperWins(Map<String,Object> params) throws GWPersistenceException;

    List<OrderEntity> getRecordMaxList(Map<String, Object> params) throws GWPersistenceException;

    String[] getRecordMaxSummary(Map<String, Object> params) throws GWPersistenceException;

    List<UserWagerInfo> getFirstBetWinList(Map<String, Object> params) throws GWPersistenceException;

    Integer countFirstBetWin(Map<String, Object> params) throws GWPersistenceException;

    List<OrderEntity> getAGQJDeskInfos(Map<String, Object> params) throws GWPersistenceException;

    List<PokerShoeStatisticEntity> getMaxValueGroupByShoecode(Map<String, Object> params) throws GWPersistenceException;

    List<BaGameEntity> queryGameResult(Map params) throws GWPersistenceException;

    Integer countGameResult(Map params) throws GWPersistenceException;

    List<PopularGame> getMostPopularGameRank(Map<String, Object> params) throws GWPersistenceException;

    List<BetRecord> getBetRecord(Map<String, Object> params) throws GWPersistenceException;

    /**
     * 查询投注记录(风控使用)
     *
     * @param params
     * @return
     * @throws GWPersistenceException
     */
    List<GameOrder> getGameOrderByPage(Map<String, Object> params) throws GWPersistenceException;

    /**
     * 查询投注记录总条数(风控使用)
     *
     * @param params
     * @return
     * @throws GWPersistenceException
     */
    GameOrder getGameOrderTotal(Map<String, Object> params) throws GWPersistenceException;

    /**
     * 查询注单汇总数据(风控使用)
     *
     * @param params
     * @return
     * @throws GWPersistenceException
     */
    List<OrderSummary> getOrderSummary(Map<String, Object> params) throws GWPersistenceException;

    /**
     * 查询注单汇总数据总条数(风控使用)
     *
     * @param params
     * @return
     * @throws GWPersistenceException
     */
    OrderSummary getOrderSummaryTotal(Map<String, Object> params) throws GWPersistenceException;

    /**
     * 获取游戏
     *
     * @return
     * @throws GWPersistenceException
     */
    List<Game> getGames() throws GWPersistenceException;

    /**
     * 根据用户和局号查询投注额
     *
     * @return
     * @throws GWPersistenceException
     */
    List<GameOrder> getOrderByVideo(Map<String, Object> params) throws GWPersistenceException;

    /**
     * 电销系统按照时间汇总有效投注额，数据来源T_ORDERS_STATISTICS
     *
     * @param params
     * @return
     * @throws GWPersistenceException
     */
    List<AccountTotalEntity> getValidAmountFromStatisticsByType(Map<String, Object> params) throws GWPersistenceException;

    Integer countValidAmountFromStatisticsByType(Map<String, Object> params) throws GWPersistenceException;

    /**
     * @Description: 统计用户一个时间段的T_ORDERS_SUMMARY表汇总数据
     * @Author: Ziv.Y
     * @Date: 2018/7/28 10:14
     */
    List<AccountTotalEntity> getOrderSummaryGroupByPidUsername(Map<String, Object> params) throws GWPersistenceException;

    List<AccountTotalEntity> getOrderSummaryGroupByDay(Map<String,Object> params) throws GWPersistenceException;
    /**
     * @Description: 
     * @Author: Ziv.Y
     * @Date: 2019/9/26 20:44
     */
    List<AccountTotalEntity> getOrderSummaryGroupByPidUsername4ActivityList(Map<String, Object> params) throws GWPersistenceException;

    Integer countOrderSummaryGroupByPidUsername(Map<String, Object> params) throws GWPersistenceException;

    /**
     * @Description: 按产品、平台、用户分组T_ORDERS_SUMMARY表汇总数据
     * @Author: Ziv.Y
     * @Date: 2018/8/10 10:47
     */
    List<AccountTotalEntity> getOrderSummaryGroupByPidPlatIdUn(Map<String, Object> params) throws GWPersistenceException;
    List<GetOrderSummaryGroupByPlatGameUnResponse> getOrderSummaryGroupByPlatGameUn(Map<String, Object> params) throws GWPersistenceException;
    GetOrderSummaryGroupByPlatGameUnResponse getOrderSummaryGroupByPlatGameUnTotal(Map<String, Object> params) throws GWPersistenceException;

    long getOrderSummaryGroupByPlatGameUnTotalUserNum(Map<String, Object> params) throws GWPersistenceException;

    Integer countOrderSummaryGroupByPidPlatIdUn(Map<String, Object> params) throws GWPersistenceException;

    /**
     * dc查询有效投注额
     *
     * @param params
     * @return
     * @throws GWPersistenceException
     */
    List<AccountTotalEntity> getOrdersSumGroupByLoginName(Map<String, Object> params) throws GWPersistenceException;

    Integer countOrdersSumGroupByLoginName(Map<String, Object> params) throws GWPersistenceException;

    String testReadConnection()throws GWPersistenceException;

    String testWriteConnection()throws GWPersistenceException;

    List<MGAndTTGAbnormalEntity> getMGAndTTGAbnormalData(Map<String, Object> params) throws GWPersistenceException;

    /**
     *  分类洗码列表
     * @param params
     * @return
     * @throws GWPersistenceException
     */
    List<AccountTotalEntity> getOrderRemainGroupList(Map<String, Object> params) throws GWPersistenceException;

    List<OrderAGQJExceptionor> getOrdersAGQJExceptionor(Map<String, Object> params) throws GWPersistenceException;

    /**
     *
     * @param params
     * @return
     * @throws GWPersistenceException
     */
    List<String> getCustomerByPlatformAndGameKind(Map<String, Object> params) throws GWPersistenceException;

    List<AttendancePromoEntity> getAttendancePromoList(Map<String, Object> parameterMap) throws GWPersistenceException;

    QueryResult<OrderEntity> getHighProfitOrderListByDeviceType(Map<String, Object> parameterMap) throws GWPersistenceException;

    List<CustomerDynamicEntity> getCustomerDynamic(Map<String, Object> parameterMap) throws GWPersistenceException;

    QueryResult<AccountTotalEntity> getWagerSummary(Map<String, Object> parameterMap) throws GWPersistenceException;

    QueryResult<OrderEntity> getEligibilityOrder(Map<String, Object> parameterMap) throws GWPersistenceException;

    List<GameTypePlayTypeEntity> getGameTypeAndPlayType(Map<String, Object> parameterMap) throws GWPersistenceException;
}
