package com.gw.datacenter.dao.impl;

import com.gw.datacenter.common.constants.MapperConstants;
import com.gw.datacenter.common.exception.GWPersistenceException;
import com.gw.datacenter.dao.ActivityDao;
import com.gw.datacenter.vo.activity.ActivityEntity;
import com.gw.datacenter.vo.pagainate.QueryResult;
import lombok.extern.slf4j.Slf4j;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Repository
@Slf4j
public class ActivityDaoImpl implements ActivityDao {

    @Resource
    private SqlSessionTemplate sqlSessionTemplate;

    /**
     * Get consecutive win records
     * @param params
     * @return List<ActivityEntity>
     * @throws GWPersistenceException
     */
    public QueryResult<ActivityEntity> getActivityEntityList(Map<String, Object> params) throws GWPersistenceException {
        QueryResult<ActivityEntity> queryResult = new QueryResult();
        try {
            List<ActivityEntity> queryResultList = sqlSessionTemplate.selectList(MapperConstants.GET_ACTIVITY_ENTITY_LIST, params);
            Integer totalRecords = sqlSessionTemplate.selectOne(MapperConstants.GET_ACTIVITY_ENTITY_TOTAL_RECORDS, params);
            queryResult.setQueryResultList(queryResultList);
            queryResult.setTotalRecords(totalRecords);
        } catch (Exception e) {
            log.error("call getActivityEntityList fail.", e);
            throw e;
        }
        return queryResult;
    }

}
