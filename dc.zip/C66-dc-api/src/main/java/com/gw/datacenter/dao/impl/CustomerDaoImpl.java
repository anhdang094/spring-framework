package com.gw.datacenter.dao.impl;

import com.gw.datacenter.common.constants.MapperConstants;
import com.gw.datacenter.common.exception.GWPersistenceException;
import com.gw.datacenter.dao.CustomerDao;
import lombok.extern.slf4j.Slf4j;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Map;

/**
 * title: CustomerDaoImpl
 * author: monty
 * date: 2020/9/26
 */
@Repository
@Slf4j
public class CustomerDaoImpl implements CustomerDao {
    @Resource
    private SqlSessionTemplate sqlSessionTemplate;


    @Override
    public void updateCustomerMainLoginName(Map<String, Object> parameterMap) throws GWPersistenceException {
        try {
            sqlSessionTemplate.update(MapperConstants.UPDATE_CUSTOMER_MAIN_LOGIN_NAME, parameterMap);
        } catch (Exception e) {
            log.error("call updateCustomerMainLoginName fail.", e);
            throw e;
        }
    }

}
