package com.gw.datacenter.dao.impl;

import com.gw.datacenter.common.constants.MapperConstants;
import com.gw.datacenter.common.exception.GWPersistenceException;
import com.gw.datacenter.dao.DictionaryDao;
import com.gw.datacenter.vo.dictionary.DictionaryEntity;
import lombok.extern.slf4j.Slf4j;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * title: DictionaryDaoImpl
 * description: TODO
 * author: Jair.H
 * date: 2018/11/2 13:38
 */
@Repository
@Slf4j
public class DictionaryDaoImpl implements DictionaryDao {
    @Resource
    private SqlSessionTemplate sqlSessionTemplate;

    @Override
    public List<DictionaryEntity> getDictionaryByRelation(Map<String, Object> parameterMap) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.DICTIONARY_LIST_BY_RELATION, parameterMap);
        } catch (Exception ex) {
            log.error("Fail to get dictionary list by inputted parameters:", ex);
            throw new GWPersistenceException("Fail to get dictionary  by inputted parameters:", ex);
        }
    }

    @Override
    public List<DictionaryEntity> getDictionaryByDictName(String dictName) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.DICTIONARY_LIST_BY_DICTNAME, dictName);
        } catch (Exception ex) {
            log.error("Fail to get dictionary list by inputted parameters:", ex);
            throw new GWPersistenceException("Fail to get dictionary  by inputted parameters:", ex);
        }
    }

    @Override
    public List<DictionaryEntity> getDictionaryByRelationParent(Map<String, Object> parameterMap) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.DICTIONARY_LIST_BY_RELATION_PARENT, parameterMap);
        } catch (Exception ex) {
            log.error("Fail to get dictionary list by inputted parameters:", ex);
            throw new GWPersistenceException("Fail to get dictionary  by inputted parameters:", ex);
        }
    }

}
