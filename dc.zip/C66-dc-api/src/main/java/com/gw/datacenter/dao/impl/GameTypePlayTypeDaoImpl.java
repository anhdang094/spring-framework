package com.gw.datacenter.dao.impl;

import com.gw.datacenter.common.constants.MapperConstants;
import com.gw.datacenter.common.exception.GWPersistenceException;
import com.gw.datacenter.dao.GameTypePlayTypeDao;
import lombok.extern.slf4j.Slf4j;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Repository
@Slf4j
public class GameTypePlayTypeDaoImpl implements GameTypePlayTypeDao {
    @Resource
    private SqlSessionTemplate sqlSessionTemplate;

    public List getGameTypePlayTypeList(Map<String, Object> parameters) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.GET_GAMETYPE_PLAYTYPE_LIST, parameters);
        } catch (Exception e) {
            log.error("getGameTypePlayTypeList -error", e);
            throw new GWPersistenceException("Failed to get getGameTypePlayTypeList!", e);
        }
    }

    public List getGameTypePlayTypeListAll(Map<String, Object> parameters) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.GET_GAMETYPE_PLAYTYPE_LIST_ALL, parameters);
        } catch (Exception e) {
            log.error("getGameTypePlayTypeList -error", e);
            throw new GWPersistenceException("Failed to get getGameTypePlayTypeList!", e);
        }
    }

}
