package com.gw.datacenter.dao.impl;

import com.google.common.base.Throwables;
import com.gw.datacenter.common.constants.MapperConstants;
import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.exception.GWPersistenceException;
import com.gw.datacenter.controller.result.GetOrderSummaryGroupByPlatGameUnResponse;
import com.gw.datacenter.dao.OrderDao;
import com.gw.datacenter.vo.activity.AttendancePromoEntity;
import com.gw.datacenter.vo.gameresult.BaGameEntity;
import com.gw.datacenter.vo.gameresult.PokerShoeStatisticEntity;
import com.gw.datacenter.vo.gametypeplaytype.GameTypePlayTypeEntity;
import com.gw.datacenter.vo.order.*;
import com.gw.datacenter.vo.pagainate.QueryResult;
import com.gw.datacenter.vo.transfer.TransferGroupByType;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.session.SqlSession;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * title: OrderDaoImpl
 * description: TODO
 * author: Jair.H
 * date: 2018/11/1 14:21
 */
@Repository
@Slf4j
public class OrderDaoImpl implements OrderDao {
    @Resource
    private SqlSessionTemplate sqlSessionTemplate;

    @Override
    public List<TransferGroupByType> getTransferSumGroupByType(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.GET_TRANSFER_SUM_GROUP, params);
        } catch (Exception e) {
            log.error("call getCustomerDynamic fail.", e);
            throw e;
        }
    }

    @Override
    public List<AccountTotalEntity> getValidAmountListByType(Map<String, Object> params) throws GWPersistenceException {
        try {
            Object obj = params.get("isQueryByDate");
            boolean isQueryByDate = obj != null ? (boolean) obj : false;
            Integer type = (Integer) params.get("type");
            List entityList;
            if (type == 0) {//有效投注额
                if (isQueryByDate) {
                    entityList = sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_VALIDAMOUNT_LIST_BY_TYPE_IN_STATISTICS, params);//查询数据
                } else {
                    entityList = sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_VALIDAMOUNT_LIST_BY_TYPE, params);//查询数据
                }
            } else {
                if (isQueryByDate) {
                    entityList = sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_VALIDAMOUNT_LIST_IN_STATISTICS, params);//查询数据
                } else {
                    entityList = sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_VALIDAMOUNT_LIST, params);//查询数据
                }
            }
            return entityList;
        } catch (Exception e) {
            String msg = "productId-platformId-gameKind-type:[{" + params.get("productId") + "}-{" + params.get("platformId") + "}-{" + params.get("gameKind") + "}-{" + params.get("type") + "}],call getValidAmountListByType fail.";
            log.error(msg, e);
            throw new GWPersistenceException("call getValidAmountListByType failed:" + e.getMessage());
        }
    }

    @Override
    public Integer countValidAmount(Map<String, Object> params) throws GWPersistenceException {
        try {
            Object obj = params.get("isQueryByDate");
            boolean isQueryByDate = obj != null ? (Boolean) obj : false;
            if (isQueryByDate) {
                return sqlSessionTemplate.selectOne(MapperConstants.ORDER_GET_VALIDAMOUNT_LIST_BY_TYPE_IN_STATISTICS_RECORD, params);
            } else {
                return sqlSessionTemplate.selectOne(MapperConstants.ORDER_GET_VALIDAMOUNT_RECORD, params);
            }
        } catch (Exception e) {
            String msg = "productId-platformId-gameKind-type:[{" + params.get("productId") + "}-{" + params.get("platformId") + "}-{" + params.get("gameKind") + "}-{" + params.get("type") + "}],call countValidAmount failure.";
            log.error(msg, e);
            throw new GWPersistenceException("call countValidAmount failed:" + e.getMessage());
        }
    }

    @Override
    public List<OrderEntity> getOrderEntity(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_ORDERENTITY, params);
        } catch (Exception e) {
            String msg = "productId-platformId-gameKind-gameType:[{" + params.get("productId") + "}-{" + params.get("platformId") + "}-{" + params.get("gameKind") + "}-{" + params.get("gameType") + "}],call getOrderEntity fail.";
            log.error(msg, e);
            throw new GWPersistenceException("call getOrderEntity failed:" + e.getMessage());
        }
    }

    @Override
    public Integer countOrderEntity(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectOne(MapperConstants.ORDER_GET_ORDERENTITY_RECORD, params);
        } catch (Exception e) {
            String msg = "productId-platformId-gameKind-gameType:[{" + params.get("productId") + "}-{" + params.get("platformId") + "}-{" + params.get("gameKind") + "}-{" + params.get("gameType") + "}],call countOrderEntity fail.";
            log.error(msg, e);
            throw new GWPersistenceException("call getOrderEntity failed:" + e.getMessage());
        }
    }

    @Override
    public List<AccountTotalEntity> getMaxEffectiveBettingAmountList(Map<String, Object> params) throws GWPersistenceException {
        try {
            Object obj = params.get("isQueryByDate");
            boolean isQueryByDate = obj != null ? (Boolean) obj : false;
            if (isQueryByDate) {
                return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_EFFECTIVE_BETTING_AMOUNT_LIST_IN_STATISTICS, params);
            } else {
                return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_EFFECTIVE_BETTING_AMOUNT_LIST, params);
            }
        } catch (Exception e) {
            log.error("call getMaxEffectiveBettingAmountList fail.", e);
            throw new GWPersistenceException("call getMaxEffectiveBettingAmountList failed:" + e.getMessage());
        }
    }

    @Override
    public Integer countMaxEffectiveBettingAmount(Map<String, Object> params) throws GWPersistenceException {
        try {
            Object obj = params.get("isQueryByDate");
            boolean isQueryByDate = obj != null ? (Boolean) obj : false;
            if (isQueryByDate) {
                return sqlSessionTemplate.selectOne(MapperConstants.ORDER_GET_EFFECTIVE_BETTING_AMOUNT_RECORD_IN_STATISTICS, params);
            } else {
                return sqlSessionTemplate.selectOne(MapperConstants.ORDER_GET_EFFECTIVE_BETTING_AMOUNT_RECORD, params);
            }
        } catch (Exception e) {
            log.error("call countMaxEffectiveBettingAmount fail.", e);
            throw new GWPersistenceException("call countMaxEffectiveBettingAmount failed:" + e.getMessage());
        }
    }

    @Override
    public List<AccountTotalEntity> getMaxEffectiveBettingByGameKind(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_EFFECTIVE_BETTING_AMOUNT_LIST_BY_GAMEKIND, params);
        } catch (Exception e) {
            log.error("call getMaxEffectiveBettingByGameKind fail.", e);
            throw new GWPersistenceException("call getMaxEffectiveBettingByGameKind failed:" + e.getMessage());
        }
    }

    @Override
    public Integer countMaxEffectiveBettingByGameKind(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectOne(MapperConstants.ORDER_GET_EFFECTIVE_BETTING_AMOUNT_RECORD_BY_GAMEKIND, params);
        } catch (Exception e) {
            log.error("call countMaxEffectiveBettingByGameKind fail.", e);
            throw new GWPersistenceException("call countMaxEffectiveBettingByGameKind failed:" + e.getMessage());
        }
    }

    @Override
    public List<AccountTotalEntity> getMaxEffectiveBettingByAmountGameKind(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_EFFECTIVE_BETTING_LIST_GAMEKIND, params);
        } catch (Exception e) {
            log.error("call getMaxEffectiveBettingByGameKind fail.", e);
            throw new GWPersistenceException("call getMaxEffectiveBettingByGameKind failed:" + e.getMessage());
        }
    }

    @Override
    public Integer countMaxEffectiveBettingByAmountGameKind(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectOne(MapperConstants.ORDER_GET_EFFECTIVE_BETTING_LIST_GAMEKIND_COUNT, params);
        } catch (Exception e) {
            log.error("call countMaxEffectiveBettingByGameKind fail.", e);
            throw new GWPersistenceException("call countMaxEffectiveBettingByGameKind failed:" + e.getMessage());
        }
    }

    @Override
    public List<OrderEntity> getOrderList(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_ORDER_LIST_4ALL, params);//查询数据
        } catch (Exception e) {
            log.error("call getOrderList fail.", e);
            throw new GWPersistenceException("call getOrderList failed:" + e.getMessage());
        }
    }

    @Override
    public String countTotalStrOrder(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectOne(MapperConstants.ORDER_GET_ORDER_LIST_SIZE_4ALL, params);
        } catch (Exception e) {
            log.error("call countTotalStrOrder fail.", e);
            throw new GWPersistenceException("call countTotalStrOrder failed:" + e.getMessage());
        }
    }

    @Override
    public List<OrderEntity> getBoWinList(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_BOWIN_LIST, params);
        } catch (Exception e) {
            log.error("call getBoWinList fail.", e);
            throw new GWPersistenceException("call getBoWinList failed:" + e.getMessage());
        }
    }

    @Override
    public String countTotalStrBoWin(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectOne(MapperConstants.ORDER_GET_BOWIN_COUNT, params);
        } catch (Exception e) {
            log.error("call countTotalStrOrder fail.", e);
            throw new GWPersistenceException("call countTotalStrOrder failed:" + e.getMessage());
        }
    }

    @Override
    public List<MonthlyWeeklyEffectiveBetAmountEntity> getMonthlyAndWeeklyValidAmount(Map<String, Object> params) throws GWPersistenceException {
        try {
            boolean isQueryByDate = (Boolean) params.get("isQueryByDate");
            if (isQueryByDate) {
                return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_WEEKLY_MONTHLY_VALID_AMOUNT_BY_STATISTICS, params);
            } else {
                return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_WEEKLY_MONTHLY_VALID_AMOUNT, params);
            }
        } catch (Exception e) {
            log.error("call getMonthlyAndWeeklyValidAmount fail.", e);
            throw new GWPersistenceException("call getMonthlyAndWeeklyValidAmount failed:" + e.getMessage());
        }
    }

    @Override
    public List<OrderEntity> getCustomerBetTimeList(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_CUSTOMER_BET_TIME, params);
        } catch (Exception e) {
            log.error("call getCustomerBetTimeList fail.", e);
            throw new GWPersistenceException("call getCustomerBetTimeList failed:" + e.getMessage());
        }
    }

    @Override
    public List<ContinuousOrder> getContinuousOrder(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_CONTINUOUS_LIST, params);
        } catch (Exception e) {
            log.error("call getContinuousOrder fail.", e);
            throw new GWPersistenceException("call getContinuousOrder failed:" + e.getMessage());
        }
    }

    @Override
    public List<OrderEntity> getOrderListByProfit(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_LIST_BY_PROFIT, params);
        } catch (Exception e) {
            log.error("call getOrderListByProfit fail.", e);
            throw new GWPersistenceException("call getOrderListByProfit failed:" + e.getMessage());
        }
    }

    @Override
    public List<OrderEntity> getHighProfitOrderList(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_LIST_BY_HIGH_PROFIT, params);
        } catch (Exception e) {
            log.error("call getHighProfitOrderList fail.", e);
            throw new GWPersistenceException("call getHighProfitOrderList failed:" + e.getMessage());
        }
    }

    @Override
    public List<OrderEntity> getBetHistory(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_LIST, params);
        } catch (Exception e) {
            log.error("call getBetHistory fail.", e);
            throw new GWPersistenceException("call getBetHistory failed:" + e.getMessage());
        }
    }

    @Override
    public List<OrderEntity> getBetHistoryByMultipleProfit(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_LIST_BY_MULTIPLE_PROFIT, params);
        } catch (Exception e) {
            log.error("call getBetHistoryByMultipleProfit fail.", e);
            throw new GWPersistenceException("call getBetHistoryByMultipleProfit failed:" + e.getMessage());
        }
    }

    @Override
    public List<OrderEntity> getBestWin(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_BESTWIN, params);
        } catch (Exception e) {
            log.error("call getBestWin fail.", e);
            throw new GWPersistenceException("call getBestWin failed:" + e.getMessage());
        }
    }

    @Override
    public List<OrderEntity> getOrderByMultipleAndValidAccount2(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.ORDER_GETORDERBYMULTIPLEANDVALIDACCOUNT2, params);
        } catch (Exception e) {
            log.error("call getOrderByMultipleAndValidAccount2 fail.", e);
            throw new GWPersistenceException("call getOrderByMultipleAndValidAccount2 failed:" + e.getMessage());
        }
    }

    @Override
    public List<OrderEntity> getRecordList(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_RECORD, params);
        } catch (Exception e) {
            log.error("call getRecordList fail.", e);
            throw new GWPersistenceException("call getRecordList failed:" + e.getMessage());
        }
    }

    @Override
    public Integer countGetRecord(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectOne(MapperConstants.ORDER_GET_RECORDCOUNT, params);
        } catch (Exception e) {
            log.error("call countGetRecord fail.", e);
            throw new GWPersistenceException("call countGetRecord failed:" + e.getMessage());
        }
    }


    @Override
    public String countTotalStrRecordAndSummary(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectOne(MapperConstants.ORDER_GET_RECORDSUMMARY, params);
        } catch (Exception e) {
            log.error("call countTotalStrOrder fail.", e);
            throw new GWPersistenceException("call countTotalStrOrder failed:" + e.getMessage());
        }
    }

    @Override
    public List<OrderSummary> getRecordSummay(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_RECORDSUMMARYGROUP, params);
        } catch (Exception e) {
            log.error("call countTotalStrOrder fail.", e);
            throw new GWPersistenceException("call countTotalStrOrder failed:" + e.getMessage());
        }
    }

    @Override
    public List<BetRankEntity> getBetRank(Map<String, Object> params) throws GWPersistenceException {
        try {
            if (params.get("loginName") == null || StringUtils.isBlank(params.get("loginName").toString())){
                return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_BETRANK, params);
            } else {
                return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_BETRANKBYLOGINNAME, params);
            }
        } catch (Exception e) {
            log.error("call getBetRank fail.", e);
            throw new GWPersistenceException("call getBetRank failed:" + e.getMessage());
        }
    }

    @Override
    public List<PlayerWinsEntity> getPlayerWins(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_PLAYERWINS, params);
        } catch (Exception e) {
            log.error("call getPlayerWins fail.", e);
            throw new GWPersistenceException("call getPlayerWins failed:" + e.getMessage());
        }
    }

    @Override
    public List<TopWinnerEntity> getTopWinners(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_TOPWINNERS, params);
        } catch (Exception e) {
            log.error("call getTopWinners fail.", e);
            throw new GWPersistenceException("call getTopWinners failed:" + e.getMessage());
        }
    }

    @Override
    public List<SuperWinEntity> getSuperWins(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_SUPERWINS, params);
        } catch (Exception e) {
            log.error("call getSuperWins fail.", e);
            throw new GWPersistenceException("call getSuperWins failed:" + e.getMessage());
        }
    }

    @Override
    public List<OrderEntity> getRecordMaxList(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_RECORDMAXGROUPBY, params);
        } catch (Exception e) {
            log.error("call getRecordMaxList fail.", e);
            throw new GWPersistenceException("call getRecordMaxList failed:" + e.getMessage());
        }
    }

    @Override
    public String[] getRecordMaxSummary(Map<String, Object> params) throws GWPersistenceException {
        try {
            String summary = sqlSessionTemplate.selectOne(MapperConstants.ORDER_GET_RECORDMAXANDSUMMARYGROUPBY, params);
            String[] items = StringUtils.isNotEmpty(summary) ? summary.split(UtilConstants.COMMA_SYMBOL) : null;
            return items;
        } catch (Exception e) {
            log.error("call getRecordMaxSummary fail.", e);
            throw new GWPersistenceException("call getRecordMaxSummary failed:" + e.getMessage());
        }
    }

    @Override
    public QueryResult<ProfitRanking> getAgListOrder(Map<String, Object> parameterMap) throws GWPersistenceException {
        log.info("Call OrderDaoImpl.getAgListOrder->begin");
        QueryResult<ProfitRanking> queryResult = new QueryResult<>();
        try {
            List<ProfitRanking> entityList = sqlSessionTemplate.selectList(MapperConstants.GET_AG_LIS_ORDER, parameterMap);
            queryResult.setQueryResultList(entityList);
            queryResult.setTotalRecords(entityList.size());
        } catch (Exception e) {
            log.error("Call OrderDaoImpl.getAgListOrder failure.", e);
            throw new GWPersistenceException("Fail to getAgListOrder：" + e.getMessage());
        }
        return queryResult;
    }

    @Override
    public List<ProfitEntity> profitRankings(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_PROFIGS, params);
        } catch (Exception e) {
            log.error("call profitRankings fail.", e);
            throw new GWPersistenceException("call profitRankings failed:" + e.getMessage());
        }
    }

    @Override
    public List<PlayerPlatformProfit> getPlayerPlatformProfit(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_PLAYER_PLATFORM_PROFIT, params);
        } catch (Exception e) {
            log.error(Throwables.getStackTraceAsString(e));
            throw new GWPersistenceException("call getPlayerPlatformProfit failed:" + e.getMessage());
        }
    }


    @Override
    public List<UserWagerInfo> getFirstBetWinList(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_FIRST_BITORWIN_LIST, params);
        } catch (Exception e) {
            log.error("call getFirstBetWinList fail.", e);
            throw new GWPersistenceException("call getFirstBetWinList failed:" + e.getMessage());
        }
    }

    @Override
    public Integer countFirstBetWin(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectOne(MapperConstants.ORDER_GET_FIRST_BITORWIN_COUNT, params);
        } catch (Exception e) {
            log.error("call countFirstBetWin fail.", e);
            throw new GWPersistenceException("call countFirstBetWin failed:" + e.getMessage());
        }
    }

    @Override
    public List<OrderEntity> getAGQJDeskInfos(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.GET_STATISTIC_AGQJDESKINFOS, params);
        } catch (Exception e) {
            log.error("call getAGQJDeskInfos fail.", e);
            throw new GWPersistenceException("call getAGQJDeskInfos failed:" + e.getMessage());
        }
    }

    @Override
    public List<PokerShoeStatisticEntity> getMaxValueGroupByShoecode(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_MAXVALUE_GROUPBY_SHOECODE, params);
        } catch (Exception e) {
            log.error("call getMaxValueGroupByShoecode fail.", e);
            throw new GWPersistenceException("call getMaxValueGroupByShoecode failed:" + e.getMessage());
        }
    }

    @Override
    public List<BaGameEntity> queryGameResult(Map params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.GAMERESULT_GET_GAME_RESULT_LIST, params);
        } catch (Exception e) {
            log.error("call queryGameResult fail.", e);
            throw new GWPersistenceException("call queryGameResult failed:" + e.getMessage());
        }
    }

    @Override
    public Integer countGameResult(Map params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectOne(MapperConstants.GAMERESULT_GET_GAME_RESULT_TOTAL, params);
        } catch (Exception e) {
            log.error("call countGameResult fail.", e);
            throw new GWPersistenceException("call countGameResult failed:" + e.getMessage());
        }
    }

    @Override
    public List<PopularGame> getMostPopularGameRank(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.GET_MOST_POPULAR_GAME_RANK, params);
        } catch (Exception e) {
            log.error("call getMostPopularGameRank fail.", e);
            throw new GWPersistenceException("call getMostPopularGameRank failed:" + e.getMessage());
        }
    }

    @Override
    public List<BetRecord> getBetRecord(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.GET_BET_RECORD, params);
        } catch (Exception e) {
            log.error("call getBetRecord fail.", e);
            throw new GWPersistenceException("call getBetRecord failed:" + e.getMessage());
        }
    }

    @Override
    public List<GameOrder> getGameOrderByPage(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.GET_GAME_ORDER, params);
        } catch (Exception e) {
            log.error("call getGameOrderByPage fail.", e);
            throw new GWPersistenceException("call getGameOrderByPage failed:" + e.getMessage());
        }
    }

    @Override
    public GameOrder getGameOrderTotal(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectOne(MapperConstants.GET_GAME_ORDER_COUNT, params);
        } catch (Exception e) {
            log.error("call getGameOrderTotal fail.", e);
            throw new GWPersistenceException("call getGameOrderTotal failed:" + e.getMessage());
        }
    }

    @Override
    public List<OrderSummary> getOrderSummary(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.GET_ORDER_SUMMARY, params);
        } catch (Exception e) {
            log.error("call getOrderSummary fail.", e);
            throw new GWPersistenceException("call getOrderSummary failed:" + e.getMessage());
        }
    }

    @Override
    public OrderSummary getOrderSummaryTotal(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectOne(MapperConstants.GET_ORDER_SUMMARY_COUNT, params);
        } catch (Exception e) {
            log.error("call getOrderSummaryTotal fail.", e);
            throw new GWPersistenceException("call getOrderSummaryTotal failed:" + e.getMessage());
        }
    }

    @Override
    public List<Game> getGames() throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.GET_GAMES);
        } catch (Exception e) {
            log.error("call getGames fail.", e);
            throw new GWPersistenceException("call getGames failed:" + e.getMessage());
        }
    }

    @Override
    public List<GameOrder> getOrderByVideo(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.GET_ORDER_BY_VIDEO, params);
        } catch (Exception e) {
            log.error("call getOrderByVideo fail.", e);
            throw new GWPersistenceException("call getOrderByVideo failed:" + e.getMessage());
        }
    }

    @Override
    public List<AccountTotalEntity> getValidAmountFromStatisticsByType(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_VALIDAMOUNTLIST_BYTYPE_FROMSTATISTICS, params);
        } catch (Exception e) {
            log.error("call getValidAmountFromStatisticsByType fail.", e);
            throw new GWPersistenceException("call getValidAmountFromStatisticsByType failed:" + e.getMessage());
        }
    }

    @Override
    public Integer countValidAmountFromStatisticsByType(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectOne(MapperConstants.ORDER_GET_VALIDAMOUNTLIST_BYTYPE_FROMSTATISTICS_TOTALRECORDS, params);
        } catch (Exception e) {
            log.error("call countValidAmountFromStatisticsByType fail.", e);
            throw new GWPersistenceException("call countValidAmountFromStatisticsByType failed:" + e.getMessage());
        }
    }

    @Override
    public List<AccountTotalEntity> getOrderSummaryGroupByPidUsername(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_ORDERSUMMARY_GROUPBY_PID_USERNAME, params);
        } catch (Exception e) {
            log.error("call getOrderSummaryGroupByPidUsername fail.", e);
            throw new GWPersistenceException("call getOrderSummaryGroupByPidUsername failed:" + e.getMessage());
        }
    }

    @Override
    public List<AccountTotalEntity> getOrderSummaryGroupByDay(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_ORDERSUMMARY_GROUPBY_DAY, params);
        } catch (Exception e) {
            log.error("call getOrderSummaryGroupByDay fail.", e);
            throw new GWPersistenceException("call getOrderSummaryGroupByDay failed:" + e.getMessage());
        }
    }

    @Override
    public List<AccountTotalEntity> getOrderSummaryGroupByPidUsername4ActivityList(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_ORDERSUMMARY_GROUPBY_PID_USERNAME_4_ACTIVITYLIST, params);
        } catch (Exception e) {
            log.error("call getOrderSummaryGroupByPidUsername4ActivityList fail.", e);
            throw new GWPersistenceException("call getOrderSummaryGroupByPidUsername4ActivityList failed:" + e.getMessage());
        }
    }

    @Override
    public Integer countOrderSummaryGroupByPidUsername(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectOne(MapperConstants.ORDER_GET_ORDERSUMMARY_GROUPBY_PID_USERNAME_TOTALRECORDS, params);
        } catch (Exception e) {
            log.error("call countOrderSummaryGroupByPidUsername fail.", e);
            throw new GWPersistenceException("call countOrderSummaryGroupByPidUsername failed:" + e.getMessage());
        }
    }

    @Override
    public List<AccountTotalEntity> getOrderSummaryGroupByPidPlatIdUn(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_ORDERSUMMARY_GROUPBY_PID_PLATID_UN, params);
        } catch (Exception e) {
            log.error("call getOrderSummaryGroupByPidPlatIdUn fail.", e);
            throw new GWPersistenceException("call getOrderSummaryGroupByPidPlatIdUn failed:" + e.getMessage());
        }
    }

    @Override
    public List<GetOrderSummaryGroupByPlatGameUnResponse> getOrderSummaryGroupByPlatGameUn(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_ORDERSUMMARY_GROUPBY_PLATID_GameType_UN, params);
        } catch (Exception e) {
            log.error("call getOrderSummaryGroupByPidPlatIdUn fail.", e);
            throw new GWPersistenceException("call getOrderSummaryGroupByPidPlatIdUn failed:" + e.getMessage());
        }
    }
    @Override
    public GetOrderSummaryGroupByPlatGameUnResponse getOrderSummaryGroupByPlatGameUnTotal(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectOne(MapperConstants.ORDER_GET_ORDERSUMMARY_GROUPBY_PLATID_GameType_UN_Total, params);
        } catch (Exception e) {
            log.error("call getOrderSummaryGroupByPidPlatIdUn fail.", e);
            throw new GWPersistenceException("call getOrderSummaryGroupByPidPlatIdUn failed:" + e.getMessage());
        }
    }
    @Override
    public long getOrderSummaryGroupByPlatGameUnTotalUserNum(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectOne(MapperConstants.ORDER_GET_ORDERSUMMARY_TotalUserNum, params);
        } catch (Exception e) {
            log.error("call getOrderSummaryGroupByPidPlatIdUn fail.", e);
            throw new GWPersistenceException("call getOrderSummaryGroupByPidPlatIdUn failed:" + e.getMessage());
        }
    }



    @Override
    public Integer countOrderSummaryGroupByPidPlatIdUn(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectOne(MapperConstants.ORDER_GET_ORDERSUMMARY_GROUPBY_PID_PLATID_UN_TOTALRECORDS, params);
        } catch (Exception e) {
            log.error("call countOrderSummaryGroupByPidPlatIdUn fail.", e);
            throw new GWPersistenceException("call countOrderSummaryGroupByPidPlatIdUn failed:" + e.getMessage());
        }
    }

    @Override
    public List<AccountTotalEntity> getOrdersSumGroupByLoginName(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.GET_ORDER_BONUS_LIST, params);
        } catch (Exception e) {
            log.error("call getOrdersSumGroupByLoginName fail.", e);
            throw new GWPersistenceException("call getOrdersSumGroupByLoginName failed:" + e.getMessage());
        }
    }

    @Override
    public Integer countOrdersSumGroupByLoginName(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectOne(MapperConstants.GET_ORDER_BONUS_ACOUNT, params);
        } catch (Exception e) {
            log.error("call countOrdersSumGroupByLoginName fail.", e);
            throw new GWPersistenceException("call countOrdersSumGroupByLoginName failed:" + e.getMessage());
        }
    }

    @Override
    public String testReadConnection() throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectOne(MapperConstants.TEST_READ_CONNECTION);
        } catch (Exception e) {
            log.error("call testReadConnection fail.", e);
            throw new GWPersistenceException("call testReadConnection failed:" + e.getMessage());
        }
    }

    @Override
    public String testWriteConnection() throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectOne(MapperConstants.TEST_WRITE_CONNECTION);
        } catch (Exception e) {
            log.error("call testWriteConnection fail.", e);
            throw new GWPersistenceException("call testWriteConnection failed:" + e.getMessage());
        }
    }

    @Override
    public List<MGAndTTGAbnormalEntity> getMGAndTTGAbnormalData(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_MG_AND_TTG_ABNORMAL_LIST, params);
        } catch (Exception e) {
            log.error("call getMGAndTTGAbnormalData fail.", e);
            throw new GWPersistenceException("call getMGAndTTGAbnormalData failed:" + e.getMessage());
        }
    }

    @Override
    public List<AccountTotalEntity> getOrderRemainGroupList(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.GET_ORDER_REMAIN_GROUP_LIST, params);
        } catch (Exception e) {
            log.error("call getOrderRemainGroupList fail.", e);
            throw new GWPersistenceException("call getOrderRemainGroupList failed:" + e.getMessage());
        }
    }

    @Override
    public List<OrderAGQJExceptionor> getOrdersAGQJExceptionor(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.GET_ORDER_AGQJ_EXCEPTIONOR, params);
        } catch (Exception e) {
            log.error("call getOrdersAGQJExceptionor fail.", e);
            throw new GWPersistenceException("call getOrdersAGQJExceptionor failed:" + e.getMessage());
        }
    }

    @Override
    public List<String> getCustomerByPlatformAndGameKind(Map<String, Object> params) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.GET_CUSTOMER_BY_PLATFORM_AND_GAMEKIND, params);
        } catch (Exception e) {
            log.error("call getCustomerByPlatformAndGameKind fail.", e);
            throw e;
        }
    }

    @Override
    public List<AttendancePromoEntity> getAttendancePromoList(Map<String, Object> params) throws GWPersistenceException {
        List<AttendancePromoEntity> resultList = null;
        try {
            resultList = sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_ATTENDANCEPROMO_LIST, params);
        } catch (Exception e) {
            log.error("call getAttendancePromoList fail.", e);
            throw e;
        }
        return resultList;
    }

    @Override
    public QueryResult<OrderEntity> getHighProfitOrderListByDeviceType(Map<String, Object> params) throws GWPersistenceException {
        log.info("Call OrderDaoImpl.getHighProfitOrderListByDeviceType() -begin");
        long startTime = System.currentTimeMillis();
        QueryResult<OrderEntity> queryResult = new QueryResult<OrderEntity>();
        try {
            List<OrderEntity> entityList = sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_LIST_BY_DEVICE_TYPE, params);

            queryResult.setQueryResultList(entityList);
            queryResult.setTotalRecords(entityList.size());
        } catch (Exception ex) {
            log.error("Call OrderDaoImpl.getHighProfitOrderListByDeviceType() failure.", ex);
            throw new GWPersistenceException("Fail to getHighProfitOrderListByDeviceType：" + ex.getMessage());
        }
        long endTime = System.currentTimeMillis();
        log.info("Call OrderDaoImpl.getHighProfitOrderListByDeviceType() -end cost time=" + (endTime - startTime));
        return queryResult;
    }

    @Override
    public List<CustomerDynamicEntity> getCustomerDynamic(Map<String, Object> parameterMap) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.GET_CUSTOMER_DYNAMIC, parameterMap);
        } catch (Exception e) {
            log.error("call getCustomerDynamic fail.", e);
            throw e;
        }
    }

    @Override
    public QueryResult<AccountTotalEntity> getWagerSummary(Map<String, Object> parameterMap) throws GWPersistenceException {
    	QueryResult<AccountTotalEntity> queryResult = new QueryResult<AccountTotalEntity>();
    	try {
            List<AccountTotalEntity> objects = sqlSessionTemplate.selectList(MapperConstants.ORDER_GET_WAGER_SUMMARY, parameterMap);
    		queryResult.setQueryResultList(objects);
    		queryResult.setTotalRecords(1);
    	} catch (Exception ex) {
    		log.info("ProductID: " + parameterMap.get("productId"));
    		log.info("PlatformId: " + parameterMap.get("platformId"));
    		log.info("GameKind: " + parameterMap.get("gameKind"));
    		log.info("type: " + parameterMap.get("type"));
    		log.error("Call OrderDaoImpl.getWagerSummary() failure.", ex);
    		throw new GWPersistenceException("Fail to get valid amount：" + ex.getMessage());
    	}
    	log.info("Call OrderDaoImpl.getWagerSummary() -end");
    	return queryResult;
    }

    @Override
    public QueryResult<OrderEntity> getEligibilityOrder(Map<String, Object> parameterMap) throws GWPersistenceException {
        log.info("Call OrderDaoImpl.getEligibilityOrder->begin");
        long startTime = System.currentTimeMillis();
        QueryResult<OrderEntity> queryResult = new QueryResult<>();
        try{
            List<OrderEntity> entityList = sqlSessionTemplate.selectList(MapperConstants.GET_ELIGIBILITY_BY_CONCESSIONS, parameterMap);
            queryResult.setQueryResultList(entityList);
            queryResult.setTotalRecords(entityList.size());
        }catch (Exception e){
            log.error("Call OrderDaoImpl.getEligibilityOrder failure.", e);
            throw new GWPersistenceException("Fail to getEligibilityOrder：" + e.getMessage());
        }

        long endTime = System.currentTimeMillis();
        log.info("Call OrderDaoImpl.getEligibilityOrder->end cost time=" + (endTime - startTime));
        return queryResult;
    }

    @Override
    public List<GameTypePlayTypeEntity> getGameTypeAndPlayType(Map<String, Object> parameterMap) throws GWPersistenceException {
        try {
            return sqlSessionTemplate.selectList(MapperConstants.GET_GAMES_PALYWAYS, parameterMap);
        } catch (Exception e) {
            log.error("call getCustomerDynamic fail.", e);
            throw e;
        }
    }
}
