package com.gw.datacenter.datasource;

import com.google.common.base.Throwables;
import com.gw.datacenter.common.enumer.DataSourceKeyEnum;
import com.intech.dbcryptor.Cryptor;
import com.zaxxer.hikari.HikariDataSource;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;


@Configuration
@EnableTransactionManagement
@Slf4j
public class DataSourceConfigurer {
    //读库
    @Value("${hikari.read.jdbc-url}")
    private String readJdbcUrl;
    @Value("${hikari.read.driver-class-name}")
    private String readDriverClass;
    @Value("${hikari.read.username}")
    private String readUserName;
    @Value("${hikari.read.password}")
    private String readPassword;
    @Value("${hikari.read.minimum-idle}")
    private int readMinPoolSize;
    @Value("${hikari.read.maximum-pool-size}")
    private int readMaxPoolSize;
    @Value("${hikari.read.data-source-properties.key}")
    private String readDataSourceKey;
    @Value("${hikari.read.data-source-properties.value}")
    private String readDataSourceValue;

    //写库
    @Value("${hikari.write.jdbc-url}")
    private String writeJdbcUrl;
    @Value("${hikari.write.driver-class-name}")
    private String writeDriverClass;
    @Value("${hikari.write.username}")
    private String writeUserName;
    @Value("${hikari.write.password}")
    private String writePassword;
    @Value("${hikari.write.minimum-idle}")
    private int writeMinPoolSize;
    @Value("${hikari.write.maximum-pool-size}")
    private int writeMaxPoolSize;
    @Value("${hikari.write.data-source-properties.key}")
    private String writeDataSourceKey;
    @Value("${hikari.write.data-source-properties.value}")
    private String writeDataSourceValue;

    @Value("${mybatis.type-aliases-package}")
    private String typeAliasesPackage;
    @Value("${mybatis.config-location}")
    private String configLocation;

    @Autowired
    private ApplicationContext applicationContext;

    @Bean
    public DataSource read() {
        boolean result = checkDatasourceConnect(readDriverClass, readJdbcUrl, readUserName, readPassword);
        if (!result){
            SpringApplication.exit(applicationContext);
        }
        return fetchDataSource(readJdbcUrl, readDriverClass, readUserName, readPassword, readMinPoolSize, readMaxPoolSize, readDataSourceKey, readDataSourceValue);
    }

    @Bean
    public DataSource write() {
        boolean result = checkDatasourceConnect(writeDriverClass, writeJdbcUrl, writeUserName, writePassword);
        if (!result){
            SpringApplication.exit(applicationContext);
        }
        return fetchDataSource(writeJdbcUrl, writeDriverClass, writeUserName, writePassword, writeMinPoolSize, writeMaxPoolSize, writeDataSourceKey, writeDataSourceValue);
    }

    private DataSource fetchDataSource(String jdbcUrl, String driverClass, String userName, String password, int minPoolSize, int maxPoolSize, String dataSourceKey, String dataSourceValue) {
        HikariDataSource dataSource = new HikariDataSource();
        dataSource.setJdbcUrl(jdbcUrl);
        dataSource.setDriverClassName(driverClass);
        dataSource.setUsername(resolvePropertyValue(userName));
        dataSource.setPassword(resolvePropertyValue(password));
        dataSource.setMinimumIdle(minPoolSize);
        dataSource.setMaximumPoolSize(maxPoolSize);
        Properties properties = new Properties();
        properties.setProperty(dataSourceKey, dataSourceValue);
        dataSource.setDataSourceProperties(properties);
        return dataSource;
    }

    private static String resolvePropertyValue(String value) {
        // PHPDESEncrypt db = new PHPDESEncrypt("DBA", "");
        try {
            value = Cryptor.decryptContent(value); //db.decrypt(value);
        } catch (Exception e) {
            log.error("resolvePropertyValue error:" + e.getMessage(), e);
        }
        return value;
    }

    @Bean
    public DataSource dynamicDataSource(DataSource read, DataSource write) {
        DynamicRoutingDataSource dynamicRoutingDataSource = new DynamicRoutingDataSource();
        Map<Object, Object> dataSourceMap = new HashMap<>(4);
        dataSourceMap.put(DataSourceKeyEnum.read.name(), read);
        dataSourceMap.put(DataSourceKeyEnum.write.name(), write);
        dynamicRoutingDataSource.setDefaultTargetDataSource(write);
        dynamicRoutingDataSource.setTargetDataSources(dataSourceMap);
        return dynamicRoutingDataSource;
    }

    @Bean
    @ConfigurationProperties(prefix = "mybatis")
    public SqlSessionFactory sqlSessionFactory(DataSource dynamicDataSource) throws Exception {
        try {
            SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
            sqlSessionFactoryBean.setDataSource(dynamicDataSource);
            sqlSessionFactoryBean.setTypeAliasesPackage(typeAliasesPackage);
            sqlSessionFactoryBean.setConfigLocation(new PathMatchingResourcePatternResolver().getResource(configLocation));
            return sqlSessionFactoryBean.getObject();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw e;
        }
    }

    @Bean
    public PlatformTransactionManager transactionManager(DataSource dynamicDataSource) {
        return new DataSourceTransactionManager(dynamicDataSource);
    }

    @Bean
    public SqlSessionTemplate sqlSessionTemplate(SqlSessionFactory sqlSessionFactory) {
        SqlSessionTemplate template = new SqlSessionTemplate(sqlSessionFactory);
        return template;
    }

    private static boolean checkDatasourceConnect (String driveClass, String url, String username, String password){
        Connection conn = null;
        try {
            Class.forName(driveClass);
            conn = DriverManager.getConnection(url, resolvePropertyValue(username), resolvePropertyValue(password));
            log.info("datasource connect successfully, url = {}", url);
            return true;
        } catch (Exception e){
            log.error("datasource connect occurs error, url = {}, exception = {}", url, Throwables.getStackTraceAsString(e));
            return false;
        } finally {
            try {
                if (conn != null){
                    conn.close();
                }
            } catch (Exception e){
                log.error(Throwables.getStackTraceAsString(e), e);
            }
        }
    }

    public static void main(String[] args) {
        String driveClass = "oracle.jdbc.OracleDriver";
        String url = "jdbc:oracle:thin:@//10.66.72.81:1521/webtest";
        String username = "tLI;JOo3ZGGy:ALLgmBJbqEqzVEqFEVdZ{@fq([eeDNJ";
        String password = "qP4aUwfMW6;LL3LQhK,4P3VGTOjfr@2DInFZ3o;t{GpJ";
        boolean result = checkDatasourceConnect(driveClass, url, username, password);
        System.out.println(result);
    }

}

