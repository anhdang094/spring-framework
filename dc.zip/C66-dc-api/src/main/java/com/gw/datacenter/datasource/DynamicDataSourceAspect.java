package com.gw.datacenter.datasource;

import com.gw.datacenter.common.enumer.DataSourceKeyEnum;
import com.gw.datacenter.common.property.ReadTablesProperty;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@Aspect
@Component
@Slf4j
public class DynamicDataSourceAspect {
    @Resource
    private ReadTablesProperty readTablesProperty;

    //切换放在mapper接口的方法上，所以这里要配置AOP切面的切入点
    @Pointcut("execution( * org.mybatis.spring.SqlSessionTemplate.select*(..))")
    public void dataSourcePointCut() {
    }

    @Before("dataSourcePointCut()")
    public void before(JoinPoint joinPoint) {
        try {
            SqlSessionTemplate sqlSessionTemplate = (SqlSessionTemplate)joinPoint.getTarget();
            Object[] args = joinPoint.getArgs();
            if(args!=null) {
                Object parameterObject = args.length > 1 ? args[1] : null;
                String sql = sqlSessionTemplate.getSqlSessionFactory().getConfiguration().getMappedStatement(String.valueOf(args[0])).getBoundSql(parameterObject).getSql();
                if (StringUtils.isNotBlank(sql)) {
                    if (isNeedReadDB(sql)) {
                        DynamicDataSourceContextHolder.setDataSourceType(DataSourceKeyEnum.read.name());
                    }
                }
            }
        } catch (Exception e) {
            log.error("current thread " + Thread.currentThread().getName() + " add data to ThreadLocal error", e);
        }
    }

    //执行完切面后，将线程共享中的数据源名称清空
    @After("dataSourcePointCut()")
    public void after(JoinPoint joinPoint) {
        DynamicDataSourceContextHolder.removeDataSource();
    }

    public boolean isNeedReadDB(String sql) {
        //非select开头，则使用写库
        sql = sql.toLowerCase();
        if(!sql.trim().startsWith("select")){
            return false;
        }
        //判断是否使用读库
        boolean isNeedReadDB;
        List tabList = new ArrayList();
        String[] tokens = sql.split("select");
        if (tokens != null) {
            String[] var6 = tokens;
            int var7 = tokens.length;
            for (int var8 = 0; var8 < var7; ++var8) {
                String t = var6[var8];
                t = t.replaceAll("\t", " ");
                t = t.replaceAll("\r", " ");
                t = t.replaceAll("\n", " ");
                t = t.replaceAll(" ", " ");
                if (t.contains("from")) {
                    t = t.substring(t.indexOf("from"), t.length());
                    String[] tmp = t.split(" ");
                    if (tmp != null) {
                        boolean nextTokenFlag = false;
                        String[] var12 = tmp;
                        int var13 = tmp.length;

                        for (int var14 = 0; var14 < var13; ++var14) {
                            String tableName = var12[var14];
                            tableName = tableName.trim();
                            if (!tableName.equals("")) {
                                if (nextTokenFlag) {
                                    if (!tableName.startsWith("(") && !tableName.isEmpty()) {
                                        tableName = tableName.toUpperCase();
                                        tabList.add(tableName);
                                    }
                                    nextTokenFlag = false;
                                }
                                if ("FROM".equalsIgnoreCase(tableName) || "JOIN".equalsIgnoreCase(tableName)) {
                                    nextTokenFlag = true;
                                }
                            }
                        }
                    }
                }
            }
        }
        List<String> readTablesList = readTablesProperty.getReadTablesList();
        if (CollectionUtils.isNotEmpty(readTablesList)) {
            if (CollectionUtils.isNotEmpty(tabList)) {
                isNeedReadDB = readTablesList.containsAll(tabList);
            } else {
                isNeedReadDB = false;
            }
        } else {
            isNeedReadDB = false;
        }
        return isNeedReadDB;
    }
}