package com.gw.datacenter.interceptor;

import com.gw.datacenter.common.exception.GWPersistenceException;
import com.gw.datacenter.common.util.IpUtil;
import com.gw.datacenter.common.util.JacksonUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.cxf.phase.PhaseInterceptorChain;
import org.apache.cxf.transport.http.AbstractHTTPDestination;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;

/**
 * @Description: CXF管理员操作日志拦截器
 * @Author: Ziv.Y
 * @Date: 2018/7/30 17:14
 */
@Aspect
@Component
@Slf4j
public class OperaterLogInterceptor {

    @Pointcut("execution(* com.gw.datacenter.cxf.impl.DataCenterApiImpl.*(..))")
    public void businessMethods() {
    }

    @Around("businessMethods()")
    public Object operaterCXFLog(ProceedingJoinPoint joinPoint) throws Throwable {
        String className = null;
        String methodName = null;
        String ip = null;
        String argsStr = null;
        boolean unsafe = false;
        try {
            HttpServletRequest request = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
            ip = IpUtil.getIpAddr(request);
            Method targetMethod = ((MethodSignature) joinPoint.getSignature()).getMethod();
            className = targetMethod.getDeclaringClass().getName();
            methodName = targetMethod.getName();
            Object[] args = joinPoint.getArgs();
            if (args != null) {
                for (Object arg : args) {
                    if (judgeSQInjection(arg)) {
                        unsafe = true;
                        break;
                    }
                }
            }
            argsStr = JacksonUtil.toJSon(args);
        } catch (Exception e) {
            log.error("OperaterLogInterceptor log error", e);
        }
        if (unsafe) {
            log.error("OperaterLogInterceptor unsafe ip[" + ip + "] call [" + className + "." + methodName + "],args[" + argsStr + "]");
            throw new GWPersistenceException("the parameters are illegal!");
        } else {
            long startTime = System.currentTimeMillis();
            Object result = joinPoint.proceed();
            long endTime = System.currentTimeMillis();
            log.info("OperaterLogInterceptor,exec time[" + (endTime - startTime) + "],ip[" + ip +
                    "] call [" + className + "." + methodName + "],args[" + argsStr + "]");
            return result;
        }
    }

    /**
     * 判断参数是否含有攻击串
     *
     * @param value
     * @return
     */
    private boolean judgeSQInjection(Object value) {
        try {
            if (value == null || "".equals(value.toString())) {
                return false;
            }
            String xssStr = "select |from |update |delete |drop |truncate ";
            String[] xssArr = xssStr.split("\\|");
            for (int i = 0; i < xssArr.length; i++) {
                if (value.toString().toLowerCase().indexOf(xssArr[i]) > -1) {
                    return true;
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return false;
    }
}