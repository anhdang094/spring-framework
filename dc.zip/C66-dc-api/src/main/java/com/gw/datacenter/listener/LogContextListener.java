package com.gw.datacenter.listener;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.joran.JoranConfigurator;
import com.gw.datacenter.common.constants.UtilConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

/**
 * Created by Angus.Z on 2018/7/19.
 *
 * @author Angus.Z
 */
@Deprecated
//@Component
@Slf4j
public class LogContextListener implements ServletContextListener {
    private final static String LOGBACK_CLASSPATH = "/saconfig/fixed/logback.xml";

    @Override
    public void contextInitialized(ServletContextEvent event) {
        loadLockBack();
        printProjectInfo(event);
    }

    /**
     * 为了处理web  war包启动时logging.config属性被覆盖，所以加了这个重载方法
     */
    private void loadLockBack() {
        try {
            LoggerContext context = (LoggerContext) LoggerFactory.getILoggerFactory();
            context.reset();
            JoranConfigurator configurator = new JoranConfigurator();
            File configFile = new ClassPathResource(LOGBACK_CLASSPATH).getFile();
            InputStream configStream = FileUtils.openInputStream(configFile);
            configurator.setContext(context);
            configurator.doConfigure(configStream);
            configStream.close();
        } catch (Exception e) {
            log.error("load logback error:" + e.getMessage(), e);
        }
    }

    public void printProjectInfo(ServletContextEvent context) {
        try {
            String basePath = context.getServletContext().getRealPath("/");
            String file = basePath + "version.txt";
            log.info("============================Print project version start.============================");
            File versionFile = new File(file);
            if (versionFile.exists()) {
                try {
                    List<String> lines = FileUtils.readLines(new File(file), "UTF-8");
                    if (CollectionUtils.isNotEmpty(lines)) {
                        for (String line : lines) {
                            log.info(line);
                            buildProjectInfo(line);
                        }
                    }
                } catch (IOException e) {
                    log.warn("File '" + file + "' does not exist.");
                }
            } else {
                log.warn("File '" + file + "' does not exist.");
            }
            log.info("============================Print project version end.==============================");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent servletContextEvent) {
    }

    private void buildProjectInfo(String str) {
        if (StringUtils.isNotBlank(str)) {
            String[] split = str.split(":");
            if (split.length == 2) {
                UtilConstants.PROJECT_INFO.put(split[0].trim(), split[1].trim());
            }
        }
    }


}
