package com.gw.datacenter.service;


import com.gw.datacenter.common.exception.GWKeyErrorException;
import com.gw.datacenter.common.exception.GWPersistenceException;
import com.gw.datacenter.vo.activity.ActivityEntity;
import com.gw.datacenter.vo.pagainate.QueryResult;

/**
 * @author alex.l
 */

public interface ActivityService {
    /**
     * Get valid activity entity list.
     * @param productId(A01,A02,A03...)
     * @param platformId
     * @param gameType
     * @param beginTime
     * @param endTime
     * @param pageNo
     * @param pageSize
     * @param key
     * @return QueryResult
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    QueryResult<ActivityEntity> getActivityEntityList(String productId, String platformId, String loginNameArray, String gameType,
                                                      String beginTime, String endTime, boolean isWinBetOnly, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException;

}
