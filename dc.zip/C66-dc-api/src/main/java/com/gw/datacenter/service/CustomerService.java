package com.gw.datacenter.service;

import com.gw.datacenter.common.exception.GWPersistenceException;


public interface CustomerService {

    void updateCustomerMainLoginName(String productId, String loginName, String mainLoginName) throws GWPersistenceException;
}
