package com.gw.datacenter.service;

import com.gw.datacenter.common.exception.GWPersistenceException;

import java.util.List;
import java.util.Map;

public interface DataCenterApiService {

    Map<String, Object> getPlayerPlatformProfit(String productId, String platformId, String loginName, String currency, String beginTime, String endTime) throws GWPersistenceException;

}
