package com.gw.datacenter.service;

import com.gw.datacenter.common.exception.GWPersistenceException;
import com.gw.datacenter.vo.dictionary.DictionaryEntity;

import java.util.List;
import java.util.Map;


public interface DictionaryService {
	List<DictionaryEntity> getDictionaryByDictName(String dictName) throws GWPersistenceException;

	List<DictionaryEntity> getDictionaryByRelation(Map<String, Object> parameterMap) throws GWPersistenceException;

	List<DictionaryEntity> getDictionaryByRelationParent(Map<String, Object> parameterMap) throws GWPersistenceException;
}
