package com.gw.datacenter.service;

import com.gw.datacenter.common.exception.GWPersistenceException;

import java.util.List;
import java.util.Map;

public interface GameTypePlayTypeService {

    List getGameTypePlayTypeList(Map<String, Object> parameters) throws GWPersistenceException;

    List getGameTypePlayTypeListAll(Map<String, Object> parameters) throws GWPersistenceException;

}
