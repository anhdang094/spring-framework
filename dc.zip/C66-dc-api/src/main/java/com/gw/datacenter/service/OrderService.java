package com.gw.datacenter.service;

import com.gw.datacenter.common.exception.GWKeyErrorException;
import com.gw.datacenter.common.exception.GWPersistenceException;
import com.gw.datacenter.controller.request.GetOrderSummaryGroupByPlatGameUnRequest;
import com.gw.datacenter.controller.result.GetOrderSummaryGroupByPlatGameUnResponse;
import com.gw.datacenter.vo.activity.AttendancePromoEntity;
import com.gw.datacenter.vo.gameresult.BaGameEntity;
import com.gw.datacenter.vo.gameresult.PokerShoeStatisticEntity;
import com.gw.datacenter.vo.gametypeplaytype.GameTypePlayTypeEntity;
import com.gw.datacenter.vo.order.*;
import com.gw.datacenter.vo.pagainate.QueryResult;
import com.gw.datacenter.vo.pagainate.QueryResultWrapper;
import com.gw.datacenter.vo.transfer.TransferGroupByType;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;


public interface OrderService {

    Map<String, Object> getPlayerPlatformProfit(String productId, String platformId, String loginName, String currency, String beginTime, String endTime) throws GWPersistenceException;

    List<TransferGroupByType> getTransferSumGroupByType(String[] platformArray,String[] platformArrayAG, String beginTime, String endTime, String productId, String userName) throws Exception;
    /**
     * 查询有效投注额(佣金)
     *
     * @param productId
     * @param platformId
     * @param validAccount
     * @param timeZoneId
     * @param loginNameArray
     * @param beginTime
     * @param endTime
     * @param gameKind
     * @param type
     * @param pageNo
     * @param pageSize
     * @param key
     * @param orderByField
     * @param rankLoginNameList
     * @param gameType
     * @param MinBetTimes
     * @param currency
     * @return
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    QueryResult<AccountTotalEntity> getValidAmountQueryResultByType(String productId, String platformId, String validAccount, String timeZoneId, String loginNameArray, String beginTime,
                                                                    String endTime, Integer gameKind, Integer type, Integer pageNo, Integer pageSize, String key, String orderByField,
                                                                    String[] rankLoginNameList, String[] gameType, String MinBetTimes, String currency,BigDecimal minCustAmount,BigDecimal minValidAmount) throws GWPersistenceException, GWKeyErrorException;

    QueryResult<AccountTotalEntity> getValidAmountQueryResultByTypeAndFlag(String productId, String platformId, String validAccount, String timeZoneId, String loginNameArray, String beginTime,
                                                                           String endTime, Integer gameKind, Integer type, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException;

    /**
     * 查询注单详细信息
     *
     * @param productId
     * @param platformIds
     * @param validAccount
     * @param timeZoneId
     * @param loginNameArray
     * @param beginTime
     * @param endTime
     * @param gameKind
     * @param pageNo
     * @param pageSize
     * @param key
     * @return
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    QueryResult<OrderEntity> getOrderEntity(String productId, String[] platformIds, String validAccount, String timeZoneId, String loginNameArray, String beginTime, String endTime,
                                            Integer gameKind, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException;

    QueryResult<ProfitRanking> getAgListOrder(String  productId, String[] loginNames, String [] gameKind,String currency,String beginTime,String endTime,String limit) throws GWPersistenceException, GWKeyErrorException ;

    List<ProfitEntity> profitRankings(String productId, String platformId, String []  gameKind, String beginTime, String endTime,
                                      String currency,String limit) throws GWPersistenceException, GWKeyErrorException;

    /**
     * Get max effective betting amount.
     *
     * @param productId(A01,A02,A03...)
     * @param loginNameArray
     * @param resultType
     * @param beginTime
     * @param endTime
     * @param key
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    QueryResult<AccountTotalEntity> getMaxEffectiveBettingAmount(String productId, String loginNameArray, Integer resultType, String beginTime, String endTime, Integer pageNo,
                                                                 Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException;

    /**
     * Get order details by input parameters, include gameCode and other.
     *
     * @param productId
     * @param loginName
     * @param gameCode
     * @param beginTime
     * @param endTime
     * @param pageNo
     * @param pageSize
     * @param key
     * @return
     * @throws GWKeyErrorException
     * @throws GWPersistenceException
     */
    QueryResult<OrderEntity> getOrderDetailsByGmCode(String productId, String loginName, String gameCode, String beginTime, String endTime, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException;

    /**
     * 同getOrderDetailsByGmCode，多了总记录数和统计数据
     */
    QueryResultWrapper getOrderDetailsAndSummaryByGmCode(String productId, String loginName, String gameCode, String beginTime, String endTime, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException;

    QueryResultWrapper getBoWinList(String productId, String loginName, String beginTime, String endTime, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException;

    /**
     * Get weekly/monthly valid amount by inputed parameters.
     *
     * @param productId
     * @param loginNameArray
     * @param weekBeginTime
     * @param weekEndTime
     * @param monthBeginTime
     * @param monthEndTime
     * @param amount
     * @param key
     * @return List<MonthlyWeeklyEffectiveBetAmountEntity>
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    List<MonthlyWeeklyEffectiveBetAmountEntity> getMonthlyAndWeeklyValidAmount(String productId, String loginNameArray, BigDecimal amount, String weekBeginTime, String weekEndTime,
                                                                               String monthBeginTime, String monthEndTime, String key) throws GWPersistenceException, GWKeyErrorException;

    /**
     * Get customer bet begin time and end time.
     *
     * @param productId(A01,A02,A03...)
     * @param loginName
     * @param key
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    QueryResult<OrderEntity> getCustomerBetTime(String productId, String loginName, Integer type, String key) throws GWPersistenceException, GWKeyErrorException;

    /**
     * 获取时间段内连续下注的数据
     *
     * @param productId
     * @param platformId
     * @param beginTime
     * @param endTime
     * @param times
     * @param minAmount
     * @param key
     * @return
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    QueryResult<ContinuousOrder> getContinuousOrder(String productId, String platformId[], String beginTime, String endTime, String gameKind, Integer times, Integer minAmount, String key) throws GWPersistenceException, GWKeyErrorException;

    /**
     * 获取时间段内盈利是投注额multiple倍的注单数据
     *
     * @param productId
     * @param platformId
     * @param beginTime
     * @param endTime
     * @param multiple
     * @param key
     * @return
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    QueryResult<OrderEntity> getOrderListByProfit(String productId, String[] platformId, String beginTime, String endTime, Integer multiple, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException;


    QueryResult<OrderEntity> getHighProfitOrderList(String productId, String[] platformId, String[] gameKind, String beginTime, String endTime, Integer cusAmount,
                                                    Integer multiple, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException;

    /**
     * @param productId
     * @param platformId
     * @param beginTime
     * @param endTime
     * @param flag
     * @param cusAmount
     * @param multiple
     * @param maxRecode
     * @param key
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     * @Method Name: getBetHistory
     * @Method Desc: 获取时间段内的注单信息
     * @Return QueryResult<OrderEntity>    返回类型
     * @Author：Sanco
     * @Crete_Time Dec 3, 2014 10:52:21 AM
     * @Las_Update_Time Dec 3, 2014 10:52:21 AM
     * @Version V1.1
     * @Exception
     */

    QueryResult<OrderEntity> getBetHistory(String productId, String[] platformId, String beginTime, String endTime, Integer flag, Integer cusAmount, Integer multiple,
                                           Integer maxRecode, String key) throws GWPersistenceException, GWKeyErrorException;

    /**
     * 获取一天内单个游戏盈利超过cusAmount的信息
     *
     * @param productId
     * @param platformId
     * @param beginTime
     * @param endTime
     * @param cusAmount
     * @param key
     * @return
     */
    QueryResult<OrderEntity> getBestWin(String productId, String[] platformId, String beginTime, String endTime, Integer cusAmount, Integer listCount, String key) throws GWPersistenceException, GWKeyErrorException;

    QueryResult<OrderEntity> getOrderByMultipleAndValidAccount2(String productId, String[] platformId, String beginTime, String endTime, OrderEntity orderEntity,
                                                                Integer multiple, Integer pageNo, Integer pageSize) throws GWPersistenceException;


    QueryResult<OrderEntity> getRecord(String productId, String[] platformId, String[] loginName, String[] gameKind, String beginTime, String endTime, String settledType, Integer minBetAmount,
                                       Integer minCusAmount, Integer minMultiple, String fieldsOrder, Integer pageNo, Integer pageSize, String key, String gameType,
                                       String[] gameCode, String billNo, String currency,Integer remainAmount) throws GWPersistenceException, GWKeyErrorException;

    QueryResultWrapper getRecordAndSummary(String productId, String[] platformId, String[] loginName, String[] gameKind, String beginTime, String endTime, String settledType,
                                           Integer minBetAmount, Integer minCusAmount, Integer minMultiple, String fieldsOrder, Integer pageNo, Integer pageSize, String key, String[] gameType,
                                           String[] gameCode,Integer remainAmount,String currency) throws GWPersistenceException, GWKeyErrorException;

    QueryResult<OrderSummary> getRecordSummary(String productId, String[] platformId, String[] loginName, String[] gameKind, String beginTime, String endTime, String settledType,
                                               Integer minBetAmount, Integer minCusAmount, Integer minMultiple, String fieldsOrder, Integer pageNo, Integer pageSize, String key, String[] gameType,
                                               String[] gameCode,Integer remainAmount) throws GWPersistenceException, GWKeyErrorException;

    List<BetRankEntity> getBetRank(String productId, String[] platformId, String[] gameKind, String loginName, String beginTime, String endTime, Integer winListType, Integer minWinLostCount,
                                   Integer minBetAmount, String fieldsOrder, Integer pageSize, String key, String currency, BigDecimal minValidAmount) throws GWPersistenceException, GWKeyErrorException;

    List<PlayerWinsEntity> getPlayerWins(String productId, String loginName, String beginTime, String endTime, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException;

    List<TopWinnerEntity> getTopWinners(String productId, String beginTime, String endTime, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException;

    List<SuperWinEntity> getSuperWins(String productId, String beginTime, String endTime,
                                      Integer realMulti, Integer realAmount, Integer sportMulti, Integer sportAmount, Integer lotteryMulti, Integer lotteryAmount,
                                      Integer slotMulti, Integer slotAmount, Integer fishMulti, Integer fishAmount,
                                      Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException;

    QueryResult<OrderEntity> getRecordMax(String productId, String[] platformId, String[] loginName, String[] gameKind, String beginTime, String endTime, String settledType,
                                          Integer minBetAmount, Integer minCusAmount, Integer minMultiple, String fieldsOrder, String maxField, String groupField, Integer pageNo,
                                          Integer pageSize, String key,String currency) throws GWPersistenceException, GWKeyErrorException;

    String[] getRecordMaxSummary(String productId, String[] platformId, String[] loginName, String[] gameKind, String beginTime, String endTime, String settledType, Integer minBetAmount,
                                 Integer minCusAmount, Integer minMultiple, String fieldsOrder, String maxField, String groupField, Integer pageNo, Integer pageSize, String key,String currency) throws GWPersistenceException, GWKeyErrorException;

    //根据产品和最后更新时间查询用户第一次投注记录数据
    QueryResult<UserWagerInfo> getFirstBetWinList(String productId, String beginTime, String endTime, Integer type, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException;

    /**
     * 按靴号查询统计信息
     *
     * @param productId
     * @param platformId
     * @param loginName
     * @param videoId    桌号
     * @param shoeCode   靴号
     * @param beginTime
     * @param endTime
     * @param orderBy
     * @param pageNo
     * @param pageSize
     * @param key
     * @return List<PokerShoeStatisticEntity>
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    QueryResult<PokerShoeStatisticEntity> getMaxValueGroupByShoecode(String productId, String platformId, String loginName, String videoId, String shoeCode, String beginTime, String endTime, String orderBy, Integer pageNo, Integer pageSize, String ke, String[] gameType,String minBetTimes) throws GWPersistenceException, GWPersistenceException, GWKeyErrorException;


    /**
     * queryGameResult
     *
     * @param productId
     * @param platformId
     * @param loginName
     * @param videoId
     * @param shoeCode
     * @param beginTime
     * @param endTime
     * @param orderBy
     * @param pageNo
     * @param pageSize
     * @param key
     * @return QueryResult<PokerShoeStatisticEntity>
     * @throws GWKeyErrorException
     * @throws GWPersistenceException
     */
    QueryResult<BaGameEntity> getGameResult(String productId, String platformId, String loginName, String videoId, String shoeCode, String beginTime, String endTime, String orderBy, Integer pageNo, Integer pageSize, String key, String[] gameCode) throws GWKeyErrorException, GWPersistenceException;

    /**
     * C01 查询投注周期内QJ厅信息
     *
     * @param productId
     * @param beginTime
     * @param endTime
     * @return
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    QueryResult<OrderEntity> getAGQJDeskInfos(String productId, String beginTime, String endTime, String limit, String key) throws GWPersistenceException, GWKeyErrorException;

    /**
     * 查询玩的用户最多的前几个游戏
     *
     * @param productId 产品ID
     * @param top       前XXX名
     * @param platforms 平台ID 可传多个
     * @param gameKind  游戏大类
     * @param beginTime 开始时间
     * @param endTime   结束时间
     * @param key       校验KEY
     * @return
     * @throws GWPersistenceException
     */
    QueryResult<PopularGame> getMostPopularGameRank(String productId, Integer top, String[] platforms, String gameKind, String beginTime, String endTime, String key) throws GWPersistenceException;

    /**
     * 查询投注记录
     *
     * @param productId
     * @param platformId
     * @param gameKind
     * @param loginName
     * @param beginTime
     * @param endTime
     * @param pageSize
     * @param pageNo
     * @param key
     * @return
     * @throws GWPersistenceException
     */
    QueryResult<BetRecord> getBetRecord(String productId, String platformId, String gameKind, String loginName, String beginTime, String endTime, Integer pageSize, Integer pageNo, String key) throws Exception;

    /**
     * 查询投注记录(风控使用)
     *
     * @param productId
     * @param platformId
     * @param gameKind
     * @param loginName
     * @param gameType
     * @param beginTime
     * @param endTime
     * @param pageSize
     * @param pageNo
     * @param orderBy
     * @param key
     * @return
     * @throws Exception
     */
    QueryResult<GameOrder> getGameOrderByPage(String productId, String platformId, String gameKind, String loginName, String gameType, String gameCode, String beginTime, String endTime, Integer pageSize, Integer pageNo, String orderBy, String key) throws Exception;

    /**
     * 抓取注单汇总
     *
     * @param updateTime
     * @param pageSize
     * @param pageNo
     * @param key
     * @return
     * @throws Exception
     */
    QueryResult<OrderSummary> getOrderSummary(Long updateTime, Integer pageSize, Integer pageNo, String key) throws Exception;

    /**
     * 获取游戏
     *
     * @return
     * @throws Exception
     */
    QueryResult<Game> getGames() throws Exception;

    List<GameTypePlayTypeEntity> getGameTypeAndPlayType(Map<String, Object> parameterMap) throws Exception;

    /**
     * 根据用户和局号查询投注额
     *
     * @param productId
     * @param platformId
     * @param loginName
     * @param videoId
     * @param beginTime
     * @param endTime
     * @param key
     * @return
     * @throws Exception
     */
    QueryResult<GameOrder> getOrderByVideo(String productId, String platformId, String[] loginName, String[] videoId, String beginTime, String endTime, String key) throws Exception;

    /**
     * @Description: 电销系统按照时间汇总有效投注额
     * @Author: Ziv.Y
     * @Date: 2018/5/10 16:53
     */
    QueryResult<AccountTotalEntity> getValidAmountFromStatisticsByType(String productId, String timeZoneId, String loginNameArray, String beginDate, String endDate, Integer gameKind, Integer type, Integer pageNo,
                                                                       Integer pageSize, String key, String orderByField) throws GWPersistenceException, GWKeyErrorException;

    /**
     * @Description: 统计用户一个时间段的T_ORDERS_SUMMARY表汇总数据
     * @Author: Ziv.Y
     * @Date: 2018/7/28 10:14
     */
    QueryResult<AccountTotalEntity> getOrderSummaryGroupByPidUsername(String productId, String[] loginNameArray, String[] excludePlatformArray,
                                                                      String beginDate, String endDate, Integer pageNo, Integer pageSize, String key, String currency) throws GWPersistenceException, GWKeyErrorException;


    QueryResult<AccountTotalEntity> getOrderSummaryGroupByDay(String productId,String []loginNameList,String beginDate,String endDate) throws GWPersistenceException, GWKeyErrorException ;

    /**
     * @Description: 
     * @Author: Ziv.Y
     * @Date: 2019/9/26 20:35
     */
    QueryResult<AccountTotalEntity> getOrderSummaryGroupByPidUsername4ActivityList(String productId, String[] platformArray, String[] gameKindArray,String[] gameTypeArray, String beginDate, String endDate,
                                                                                   Long minSumAmount, String currency, Integer rank, String fieldsOrder, String key) throws GWPersistenceException, GWKeyErrorException;
    
    /**
     * @Description: 按产品、平台、用户分组T_ORDERS_SUMMARY表汇总数据
     * @Author: Ziv.Y
     * @Date: 2018/8/10 10:47
     */
    QueryResult<AccountTotalEntity> getOrderSummaryGroupByPidPlatIdUn(String productId, String[] platformArray, String[] loginNameArray, String[] gameKindArray, String beginDate,
                                                                      String endDate, Integer pageNo, Integer pageSize, String key, String currency) throws GWPersistenceException, GWKeyErrorException;

    Map<String,Object> getOrderSummaryGroupByPlatGameUn(GetOrderSummaryGroupByPlatGameUnRequest request) throws GWPersistenceException, GWKeyErrorException;

    QueryResult<AccountTotalEntity> getOrdersSumGroupByLoginName(String productId, String[] loginNameArray, String[] platformArray, String[] gameKindArray, String beginTime, String endTime,
                                                                 Integer pageNo, Integer pageSize) throws GWPersistenceException, GWKeyErrorException;

    String testReadConnection()throws GWPersistenceException;

    String testWriteConnection()throws GWPersistenceException;

    /**
     * Get MG and PPG abnormal data list by input parameters.
     * @param loginName
     * @param productId
     * @param beginDate
     * @param endDate
     * @param pageNo
     * @param pageSize
     * @param key
     * @return
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    QueryResult<MGAndTTGAbnormalEntity> getMGAndTTGAbnormalData(String loginName, String productId, String beginDate, String endDate, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException;

    /**
     * 分类洗码列表
	 * @param productId
	 * @param loginNameArray
	 * @param platformAndGameKindList
	 * @param beginTime
	 * @param endTime
	 * @return
             * @throws GWPersistenceException
	 * @throws GWKeyErrorException
	 */
    List<AccountTotalEntity> getOrdersRemainGroupList(String productId, String[] loginNameArray, List<PlatformGamekind> platformAndGameKindList, String beginTime, String endTime) throws GWPersistenceException, GWKeyErrorException;

    /**
     * AGQJ篡改注单查询接口
     * @param productId
     * @param loginName
     * @param beginTime
     * @param endTime
     * @param key
     * @return
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    List<OrderAGQJExceptionor> getOrdersAGQJExceptionor(String productId, String loginName, String beginTime, String endTime, String key) throws GWPersistenceException, GWKeyErrorException;

    /**
     * 按platformID|gameKind 查询下注用户
     * @param platform
     * @param beginTime
     * @param endTime
     * @param key
     * @return
     * @throws Exception
     */
    QueryResult<String> getCustomerByPlatformAndGameKind(String productId, PlatformGameKinds[] platform, String beginTime, String endTime, String key) throws Exception;

    List<AttendancePromoEntity> getAttendancePromoList(String productId, String platformId, String loginNameArray, String beginTime, String endTime,
                                                       Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException;

    QueryResult<OrderEntity> getHighProfitOrderListByDeviceType(String productId, String[] platformId, String[] gameKind, String beginTime, String endTime,
                                                                Integer minBetAmount, Integer cusAmount, Integer multiple, Integer pageNo, Integer pageSize,
                                                                String key, Integer deviceType) throws GWPersistenceException, GWKeyErrorException;

    List<CustomerDynamicEntity> getCustomerDynamic(String productId, String beginTime, String endTime, BigDecimal betMin, BigDecimal winMin, Integer size,String currency,
                                                   String key) throws GWPersistenceException, GWKeyErrorException;

    QueryResult<AccountTotalEntity> getWagerSummary(String productId, String[] platformId, String[] gameKind, String[] loginName, String minBet, String beginTime, String endTime, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException,GWKeyErrorException;

    //查询符合体育类优惠活动的记录
    QueryResult<OrderEntity>  getEligibilityOrder( String productId,String[] platformId,String[] gameKind,String[] loginNames,Integer minBetAmount,String queryType,String key,String beginTime,String endTime,Integer pageNo, Integer pageSize) throws GWPersistenceException,GWKeyErrorException;
}
