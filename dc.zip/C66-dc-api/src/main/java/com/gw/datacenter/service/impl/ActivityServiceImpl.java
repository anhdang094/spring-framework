package com.gw.datacenter.service.impl;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.exception.GWKeyErrorException;
import com.gw.datacenter.common.exception.GWPersistenceException;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.common.util.ParamCheckUtil;
import com.gw.datacenter.dao.ActivityDao;
import com.gw.datacenter.service.ActivityService;
import com.gw.datacenter.vo.activity.ActivityEntity;
import com.gw.datacenter.vo.pagainate.PageUtil;
import com.gw.datacenter.vo.pagainate.QueryResult;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class ActivityServiceImpl implements ActivityService {

    @Resource
    private ActivityDao activityDao;

    /**
     * Get valid activity entity list.
     * 
     * @param productId
     *            (A01,A02,A03...)
     * @param platformId
     * @param gameType
     * @param beginTime
     * @param endTime
     * @param pageNo
     * @param pageSize
     * @param key
     * @return QueryResult
     * @throws GWPersistenceException
     * @throws GWKeyErrorException
     */
    public QueryResult<ActivityEntity> getActivityEntityList(String productId, String platformId, String loginNameArray, String gameType,
                                                             String beginTime, String endTime, boolean isWinBetOnly, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException,
            GWKeyErrorException {
        Map<String, Object> parameterMap = PageUtil.getParameterMap(pageNo, pageSize);
        ParamCheckUtil.checkBeginTime(beginTime);
        ParamCheckUtil.checkEndTime(endTime);

        List<String> loginNameList = new ArrayList<String>();
        if (loginNameArray != null) {
            String[] array = loginNameArray.split(UtilConstants.COMMA_SYMBOL);
            for (String name : array) {
                loginNameList.add(name);
            }
        }
        StringBuffer sb = new StringBuffer();
        if (!StringUtils.isBlank(productId)) {
            parameterMap.put("productId", productId);
            sb.append(productId);
        }
        if (!StringUtils.isBlank(platformId)) {
            parameterMap.put("platformId", platformId);
            sb.append(platformId);
        }
        if (!StringUtils.isBlank(loginNameArray)) {
            parameterMap.put("loginNameList", loginNameList);
            sb.append(loginNameArray);
        }
        if (!StringUtils.isBlank(gameType)) {
            parameterMap.put("gameType", gameType);
            sb.append(gameType);
        }
        if (!StringUtils.isBlank(beginTime)) {
            parameterMap.put("beginTime", beginTime);
            sb.append(beginTime);
        }
        if (!StringUtils.isBlank(endTime)) {
            parameterMap.put("endTime", endTime);
            sb.append(endTime);
        }
        parameterMap.put("isWinBetOnly", isWinBetOnly);
        sb.append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(sb.toString()), key);

        return this.activityDao.getActivityEntityList(parameterMap);
    }
}
