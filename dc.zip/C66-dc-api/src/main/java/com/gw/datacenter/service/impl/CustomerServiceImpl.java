package com.gw.datacenter.service.impl;///**


import com.gw.datacenter.common.exception.GWPersistenceException;
import com.gw.datacenter.common.util.JacksonUtil;
import com.gw.datacenter.dao.CustomerDao;
import com.gw.datacenter.service.CustomerService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
public class CustomerServiceImpl implements CustomerService {

    @Resource
    private CustomerDao customerDao;

    @Override
    public void updateCustomerMainLoginName(String productId, String loginName, String mainLoginName)
            throws GWPersistenceException {

        Map<String, Object> parameterMap = new HashMap<>();
        parameterMap.put("productId", productId);
        parameterMap.put("loginName", loginName);
        parameterMap.put("mainLoginName", mainLoginName);
        //返回结果
        log.info("updateCustomerMainLoginName parameter:" + JacksonUtil.toJSon(parameterMap));
        customerDao.updateCustomerMainLoginName(parameterMap);

    }

}
