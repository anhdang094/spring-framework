package com.gw.datacenter.service.impl;

import com.gw.datacenter.common.exception.GWPersistenceException;
import com.gw.datacenter.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class DataCenterApiServiceImpl implements DataCenterApiService {

    @Autowired
    private OrderService orderService;
    @Autowired
    private GameTypePlayTypeService gameTypePlayTypeService;
    @Autowired
    private ActivityService activityService;
    @Autowired
    private CustomerService customerService;
    @Autowired
    private DictionaryService dictionaryService;

    @Override
    public Map<String, Object> getPlayerPlatformProfit(String productId, String platformId, String loginName, String currency, String beginTime, String endTime) throws GWPersistenceException {
        return orderService.getPlayerPlatformProfit(productId, platformId, loginName, currency, beginTime, endTime);
    }

}