package com.gw.datacenter.service.impl;

import com.gw.datacenter.common.exception.GWPersistenceException;
import com.gw.datacenter.dao.DictionaryDao;
import com.gw.datacenter.service.DictionaryService;
import com.gw.datacenter.vo.dictionary.DictionaryEntity;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;


@Service
public class DictionaryServiceImpl implements DictionaryService {
	@Resource
	private DictionaryDao dictionaryDao;

	@Override
	public List<DictionaryEntity> getDictionaryByDictName(String dictName) throws GWPersistenceException {
		return dictionaryDao.getDictionaryByDictName(dictName);
	}

	@Override
	public List<DictionaryEntity> getDictionaryByRelation(Map<String, Object> parameterMap) throws GWPersistenceException {
		return dictionaryDao.getDictionaryByRelation(parameterMap);
	}

	@Override
	public List<DictionaryEntity> getDictionaryByRelationParent(Map<String, Object> parameterMap) throws GWPersistenceException {
		return dictionaryDao.getDictionaryByRelationParent(parameterMap);
	}

}
