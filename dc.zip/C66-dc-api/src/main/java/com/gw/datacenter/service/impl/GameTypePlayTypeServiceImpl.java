package com.gw.datacenter.service.impl;

import com.gw.datacenter.common.exception.GWPersistenceException;
import com.gw.datacenter.dao.GameTypePlayTypeDao;
import com.gw.datacenter.service.GameTypePlayTypeService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service
public class GameTypePlayTypeServiceImpl implements GameTypePlayTypeService {
    @Resource
    private GameTypePlayTypeDao gameTypePlayTypeDao;

    @Override
    public List getGameTypePlayTypeList(Map<String, Object> parameters) throws GWPersistenceException {
        return gameTypePlayTypeDao.getGameTypePlayTypeList(parameters);
    }

    @Override
    public List getGameTypePlayTypeListAll(Map<String, Object> parameters) throws GWPersistenceException {
        return gameTypePlayTypeDao.getGameTypePlayTypeListAll(parameters);
    }

}
