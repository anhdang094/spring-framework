package com.gw.datacenter.service.impl;///**


import com.gw.datacenter.common.cache.DataCache;
import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.exception.GWKeyErrorException;
import com.gw.datacenter.common.exception.GWPersistenceException;
import com.gw.datacenter.common.util.*;
import com.gw.datacenter.controller.request.GetOrderSummaryGroupByPlatGameUnRequest;
import com.gw.datacenter.controller.result.GetOrderSummaryGroupByPlatGameUnResponse;
import com.gw.datacenter.dao.OrderDao;
import com.gw.datacenter.service.OrderService;
import com.gw.datacenter.vo.activity.AttendancePromoEntity;
import com.gw.datacenter.vo.gameresult.BaGameEntity;
import com.gw.datacenter.vo.gameresult.PokerShoeStatisticEntity;
import com.gw.datacenter.vo.gametypeplaytype.GameTypePlayTypeEntity;
import com.gw.datacenter.vo.order.*;
import com.gw.datacenter.vo.pagainate.PageUtil;
import com.gw.datacenter.vo.pagainate.QueryResult;
import com.gw.datacenter.vo.pagainate.QueryResultWrapper;
import com.gw.datacenter.vo.system.ConditionMap;
import com.gw.datacenter.vo.system.PlatformCondition;
import com.gw.datacenter.vo.transfer.TransferGroupByType;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static java.util.regex.Pattern.CASE_INSENSITIVE;

@Service
@Slf4j
public class OrderServiceImpl implements OrderService {

    private static final AtomicInteger COUNTER_BET_RECORD = new AtomicInteger(0);
    private static final AtomicLong TIMER_BET_RECORD = new AtomicLong(System.currentTimeMillis());
    private static final int ACCESS_LIMIT_BET_RECORD = 2000;
    @Resource
    private OrderDao orderDao;

    @Override
    public List<TransferGroupByType> getTransferSumGroupByType(String[] platformArray,String[] platformArrayAG, String beginTime, String endTime, String productId, String userName) throws Exception{
        List<TransferGroupByType> result = new ArrayList<>();
        Map<String,Object> params = new HashMap<>();
        params.put("beginTime",beginTime);
        params.put("platformArray",platformArray);
        params.put("platformArrayAG",platformArrayAG);
        params.put("endTime",endTime);
        params.put("productId",productId);
        params.put("userName",userName);
        result = orderDao.getTransferSumGroupByType(params);
        return result;
    }

    @Override
    public QueryResult<AccountTotalEntity> getValidAmountQueryResultByType(String productId, String platformId, String validAccount, String timeZoneId, String loginNameArray, String beginTime, String endTime, Integer gameKind, Integer type, Integer pageNo, Integer pageSize, String key, String orderByField, String[] rankLoginNameList, String[] gameType, String MinBetTimes, String currency,BigDecimal minCustAmount,BigDecimal minValidAmount) throws GWPersistenceException, GWKeyErrorException {
        //参数校验
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkBeginTime(beginTime);
        ParamCheckUtil.checkEndTime(endTime);
        //构造请求参数
        Map<String, Object> parameterMap = PageUtil.getParameterMap(pageNo, pageSize);
        putValidAmountParam(productId, platformId, validAccount, timeZoneId, loginNameArray, beginTime, endTime, gameKind, type, key,parameterMap);
        if (!checkQueryByDataParam(beginTime, endTime, parameterMap)) {
            return null;
        }
        putExtraValidAmountParam(productId, platformId, orderByField, rankLoginNameList, gameType, MinBetTimes, currency, parameterMap,minCustAmount,minValidAmount);
        //返回结果
        log.info("getValidAmountQueryResultByType parameter:" + JacksonUtil.toJSon(parameterMap));
        QueryResult<AccountTotalEntity> queryResult = new QueryResult<>();
        queryResult.setQueryResultList(orderDao.getValidAmountListByType(parameterMap));
        queryResult.setTotalRecords(orderDao.countValidAmount(parameterMap));
        return queryResult;
    }

    private void putValidAmountParam(String productId, String platformId, String validAccount, String timeZoneId, String loginNameArray, String beginTime, String endTime, Integer gameKind, Integer type, String key, Map<String, Object> parameterMap) throws GWKeyErrorException {
        StringBuffer sb = new StringBuffer();
        parameterMap.put("productId", productId);
        sb.append(productId);
        if (StringUtils.isNotBlank(platformId)) {
            parameterMap.put("platformId", platformId);
            sb.append(platformId);
        }
        if (StringUtils.isNotBlank(validAccount)) {
            parameterMap.put("validAccount", validAccount);
            sb.append(validAccount);
        }
        if (StringUtils.isNotBlank(loginNameArray)) {
            parameterMap.put("loginNameList", Arrays.asList(loginNameArray.split(UtilConstants.COMMA_SYMBOL)));
            sb.append(loginNameArray);
        }
        parameterMap.put("beginTime", DataUtil.matchTimeZoneTime(beginTime, DateUtil.UnitePattern_second, timeZoneId));
        sb.append(beginTime);
        parameterMap.put("endTime", DataUtil.matchTimeZoneTime(endTime, DateUtil.UnitePattern_second, timeZoneId));
        sb.append(endTime);
        sb.append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(sb.toString()), key);

        type = type != null ? type : 0;
        parameterMap.put("type", type);
        if (gameKind != null) {
            parameterMap.put("gameKind", gameKind);
        }
    }

    private void putExtraValidAmountParam(String productId, String platformId, String orderByField, String[] rankLoginNameList, String[] gameType, String MinBetTimes, String currency, Map<String, Object> parameterMap,BigDecimal minCustAmount,BigDecimal minValidAmount) throws GWKeyErrorException {
        ConditionMap tabMap = DataCache.getTableMap(productId, platformId);
        if (tabMap.getConditionList().size() == 0) {
            throw new GWKeyErrorException("tabMap conditionList is empty!");
        }
        parameterMap.put("tableList", tabMap);

        StringBuilder orderByStr = putOrderByStr(orderByField, "\\s*(BETTINGTIMES|TOTALACCOUNT|TOTALVALIDACCOUNT|TOTALCUSACCOUNT|TOTALREMAINAMOUNT|TOTALWONTIMES|TOTALLOSETIMES|TOTALTIETIMES)\\s+((?:de|a)sc)\\s*");
        if (StringUtils.isNotBlank(orderByStr.toString())) {
            parameterMap.put("orderByField", orderByStr.toString());
        }
        if (rankLoginNameList != null && rankLoginNameList.length > 0) {
            parameterMap.put("rankLoginNameList", rankLoginNameList);
        }
        if (gameType != null && gameType.length > 0) {
            parameterMap.put("gameType", gameType);
        }
        if (StringUtils.isNotBlank(MinBetTimes)) {
            parameterMap.put("MinBetTimes", MinBetTimes);
        }
        if (StringUtils.isNotBlank(currency)) {
            parameterMap.put("currency", currency);//添加货币类型
        }
        if (minCustAmount != null) {
            parameterMap.put("minCustAmount", minCustAmount);//最小输赢值
        }
        if  (minValidAmount != null){
            parameterMap.put("minValidAmount", minValidAmount);//最小有效投注额
        }
    }

    private StringBuilder putOrderByStr(String orderByField, String regex) {
        StringBuilder orderByStr = new StringBuilder();
        if (StringUtils.isNotBlank(orderByField)) {
            String newFieldsOrder = orderByField.replace(UtilConstants.COMMA_SYMBOL, " ");
            Pattern pattern = Pattern.compile(regex, CASE_INSENSITIVE);
            Matcher matcher = pattern.matcher(newFieldsOrder);
            while (matcher.find()) {
                orderByStr.append(matcher.group().toUpperCase()).append(UtilConstants.COMMA_SYMBOL);
            }
        }
        if (orderByStr.length() > 0) {
            orderByStr.deleteCharAt(orderByStr.length() - 1);
        }
        return orderByStr;
    }

    private boolean checkQueryByDataParam(String beginTime, String endTime, Map<String, Object> parameterMap) {
        boolean isQueryByDate = beginTime.length() <= 10;
        if (beginTime.endsWith("00:00:00") && endTime.endsWith("23:59:59")) {
            if (DateUtil.calcDiffHours(endTime) >= UtilConstants.XM_DELAY_THRESHOLD) {
                beginTime = beginTime.substring(0, 10);
                endTime = endTime.substring(0, 10);
                isQueryByDate = true;
                parameterMap.put("beginTime", beginTime);
                parameterMap.put("endTime", endTime);
            }
        }
        if (!isQueryByDate) {
            boolean isQueryInRange = DataUtil.isInQueryRange(beginTime, endTime);
            if (!isQueryInRange) {
                log.error("getValidAmountQueryResultByType not in date range,params:" + parameterMap);
                return false;
            }
        }
        parameterMap.put("isQueryByDate", isQueryByDate);
        return true;
    }

    @Override
    public QueryResult<AccountTotalEntity> getValidAmountQueryResultByTypeAndFlag(String productId, String platformId, String validAccount, String timeZoneId, String loginNameArray, String beginTime, String endTime, Integer gameKind, Integer type, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException {
        //参数校验
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkBeginTime(beginTime);
        ParamCheckUtil.checkEndTime(endTime);
        //构造请求参数
        Map<String, Object> parameterMap = PageUtil.getParameterMap(pageNo, pageSize);
        putValidAmountParam(productId, platformId, validAccount, timeZoneId, loginNameArray, beginTime, endTime, gameKind, type, key, parameterMap);
        if (!checkQueryByDataParam(beginTime, endTime, parameterMap)) {
            return null;
        }
        parameterMap.put("tableList", DataCache.getTableMap(productId, platformId));
        parameterMap.put("flag01", "1");//ALL flag=1 or 0
        //返回结果
        log.info("getValidAmountQueryResultByTypeAndFlag parameter:" + JacksonUtil.toJSon(parameterMap));
        QueryResult<AccountTotalEntity> queryResult = new QueryResult<>();
        queryResult.setQueryResultList(orderDao.getValidAmountListByType(parameterMap));
        queryResult.setTotalRecords(orderDao.countValidAmount(parameterMap));
        return queryResult;
    }

    @Override
    public QueryResult<ProfitRanking> getAgListOrder(String productId, String [] loginNames, String [] gameKind, String currency, String beginTime, String endTime, String limit) throws GWPersistenceException, GWKeyErrorException {
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkBeginTime(beginTime);
        ParamCheckUtil.checkEndTime(endTime);
        if (StringUtils.isBlank(currency)) {
            currency = "CNY";
        }
        Map<String, Object> parameterMap = new HashMap<>();
        parameterMap.put("productId", productId);
        parameterMap.put("beginTime", beginTime);
        parameterMap.put("endTime", endTime);
        parameterMap.put("limit", limit);
        if (StringUtils.isNotBlank(productId)) {
            parameterMap.put("productId", productId);
        }

        if (gameKind != null) {
            parameterMap.put("gameKind", gameKind);
        }

        if (StringUtils.isNotBlank(beginTime)) {
            parameterMap.put("beginTime", beginTime);
        }

        if (StringUtils.isNotBlank(endTime)) {
            parameterMap.put("endTime", endTime);
        }

        if (StringUtils.isNotBlank(currency)) {
            parameterMap.put("currency", currency);
        }

        ConditionMap tabMap = new ConditionMap();
        for (int i = 0; i < loginNames.length; i++) {
            tabMap.put(null, loginNames[i]);
        }
        parameterMap.put("tableList", tabMap);
        return this.orderDao.getAgListOrder(parameterMap);
    }


    @Override
    public List<ProfitEntity> profitRankings(String productId, String platformId, String [] gameKind, String beginTime, String endTime, String currency,String limit) throws GWPersistenceException, GWKeyErrorException {
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkPlatformId(platformId);
        ParamCheckUtil.checkBeginTime(beginTime);
        ParamCheckUtil.checkEndTime(endTime);
        if (StringUtils.isBlank(currency)) {
            currency = "CNY";
        }
        Map<String, Object> parameterMap = new HashMap<>();
        parameterMap.put("productId", productId);
        if (gameKind != null) {
            parameterMap.put("gameKind", gameKind);
        }
        parameterMap.put("beginTime", beginTime);
        parameterMap.put("endTime", endTime);
        parameterMap.put("currency", currency);
        parameterMap.put("platformId", platformId);
        parameterMap.put("limit", limit);
        String[] tableName = platformId.split(UtilConstants.COMMA_SYMBOL);
        parameterMap.put("tableName", DataCache.getTableMapByPlatFormIds(productId, tableName).getConditionList().get(0).getValue());
        log.info("profitRankings parameter:" + JacksonUtil.toJSon(parameterMap));
        List<ProfitEntity> betRankEntityList = orderDao.profitRankings(parameterMap);
        return betRankEntityList;
    }


    @Override
    public QueryResult<OrderEntity> getOrderEntity(String productId, String[] platformIds, String validAccount, String timeZoneId, String loginNameArray, String beginTime, String endTime, Integer gameKind, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException {
        //参数校验
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkBeginTime(beginTime);
        ParamCheckUtil.checkEndTime(endTime);
        //构造请求参数
        Map<String, Object> parameterMap = PageUtil.getParameterMap(pageNo, pageSize);
        putOrderEntityParam(productId, platformIds, validAccount, timeZoneId, loginNameArray, beginTime, endTime, gameKind, key, parameterMap);
        boolean isQueryInRange = DataUtil.isInQueryRange(beginTime, endTime);
        if (!isQueryInRange) {
            log.error("getOrderEntity not in date range,params:" + parameterMap);
            return null;
        }
        //返回结果
        log.info("getOrderEntity parameter:" + JacksonUtil.toJSon(parameterMap));
        QueryResult<OrderEntity> queryResult = new QueryResult<>();
        List<OrderEntity> list = orderDao.getOrderEntity(parameterMap);
        list.parallelStream().forEach(order -> order.setGameType(DataUtil.getGameName(order)));
        queryResult.setQueryResultList(list);
        queryResult.setTotalRecords(orderDao.countOrderEntity(parameterMap));
        return queryResult;
    }

    private void putOrderEntityParam(String productId, String[] platformIds, String validAccount, String timeZoneId, String loginNameArray, String beginTime, String endTime, Integer gameKind, String key, Map<String, Object> parameterMap) throws GWKeyErrorException {
        StringBuffer sb = new StringBuffer();
        parameterMap.put("productId", productId);
        sb.append(productId);
        if (StringUtils.isNotBlank(validAccount)) {
            parameterMap.put("validAccount", validAccount);
            sb.append(validAccount);
        }
        if (StringUtils.isNotBlank(loginNameArray)) {
            parameterMap.put("loginNameList", Arrays.asList(loginNameArray.split(UtilConstants.COMMA_SYMBOL)));
            sb.append(loginNameArray);
        }
        parameterMap.put("beginTime", DataUtil.matchTimeZoneTime(beginTime, DateUtil.UnitePattern_second, timeZoneId));
        sb.append(beginTime);
        parameterMap.put("endTime", DataUtil.matchTimeZoneTime(endTime, DateUtil.UnitePattern_second, timeZoneId));
        sb.append(endTime);
        if (gameKind != null) {
            parameterMap.put("gameKind", gameKind);
        }
        sb.append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(sb.toString()), key);
        parameterMap.put("tableList", DataCache.getTableMapByPlatFormIds(productId, platformIds));
    }

    @Override
    public QueryResult<AccountTotalEntity> getMaxEffectiveBettingAmount(String productId, String loginNameArray, Integer resultType, String beginTime, String endTime, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException {
        //参数校验
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkResultType(resultType);
        ParamCheckUtil.checkBeginTime(beginTime);
        ParamCheckUtil.checkEndTime(endTime);
        //构造请求参数
        Map<String, Object> parameterMap = PageUtil.getParameterMap(pageNo, pageSize);
        putMaxEffectiveBettingAmountParam(productId, loginNameArray, resultType, beginTime, endTime, key, parameterMap);
        if (!checkQueryByDataParam(beginTime, endTime, parameterMap)) {
            return null;
        }
        //返回结果
        log.info("getMaxEffectiveBettingAmount parameter:" + JacksonUtil.toJSon(parameterMap));
        QueryResult<AccountTotalEntity> queryResult = new QueryResult<>();
        switch (resultType) {
            case 1:
                queryResult.setQueryResultList(orderDao.getMaxEffectiveBettingAmountList(parameterMap));
                queryResult.setTotalRecords(orderDao.countMaxEffectiveBettingAmount(parameterMap));
                return queryResult;
            case 2:
                parameterMap.put("type", 0);
                queryResult.setQueryResultList(orderDao.getValidAmountListByType(parameterMap));
                queryResult.setTotalRecords(orderDao.countValidAmount(parameterMap));
                return queryResult;
            case 3:
                queryResult.setQueryResultList(orderDao.getMaxEffectiveBettingByGameKind(parameterMap));
                queryResult.setTotalRecords(orderDao.countMaxEffectiveBettingByGameKind(parameterMap));
                return queryResult;
            case 4:
                queryResult.setQueryResultList(orderDao.getMaxEffectiveBettingByAmountGameKind(parameterMap));
                queryResult.setTotalRecords(orderDao.countMaxEffectiveBettingByAmountGameKind(parameterMap));
                return queryResult;
            default:
                return null;
        }
    }

    private void putMaxEffectiveBettingAmountParam(String productId, String loginNameArray, Integer resultType, String beginTime, String endTime, String key, Map<String, Object> parameterMap) throws GWKeyErrorException {
        StringBuffer sb = new StringBuffer();
        if (StringUtils.isNotBlank(productId)) {
            parameterMap.put("productId", productId);
            sb.append(productId);
        }
        if (StringUtils.isNotBlank(loginNameArray)) {
            parameterMap.put("loginNameList", Arrays.asList(loginNameArray.split(UtilConstants.COMMA_SYMBOL)));
            sb.append(loginNameArray);
        }
        if (resultType != null) {
            parameterMap.put("resultType", resultType);
            sb.append(resultType);
        }
        parameterMap.put("beginTime", beginTime);
        sb.append(beginTime);
        parameterMap.put("endTime", endTime);
        sb.append(endTime);
        sb.append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(sb.toString()), key);
        parameterMap.put("tableList", DataCache.getTableMap(productId, null));
    }

    @Override
    public QueryResult<OrderEntity> getOrderDetailsByGmCode(String productId, String loginName, String gameCode, String beginTime, String endTime, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException {
        QueryResultWrapper<OrderEntity> orderDetailsAndSummaryByGmCode = getOrderDetailsAndSummaryByGmCode(productId, loginName, gameCode, beginTime, endTime, pageNo, pageSize, key);
        if (orderDetailsAndSummaryByGmCode != null) {
            return orderDetailsAndSummaryByGmCode.getQueryResult();
        } else {
            return null;
        }
    }

    @Override
    public QueryResultWrapper getOrderDetailsAndSummaryByGmCode(String productId, String loginName, String gameCode, String beginTime, String endTime, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException {
        //参数校验
        ParamCheckUtil.checkGameCode(gameCode);
        ParamCheckUtil.checkBeginTime(beginTime);
        ParamCheckUtil.checkEndTime(endTime);
        //构造请求参数
        Map<String, Object> parameterMap = PageUtil.getParameterMap(pageNo, pageSize);
        putOrderDetailsAndSummaryParam(productId, loginName, gameCode, beginTime, endTime, key, parameterMap);
        QueryResultWrapper wrapper = new QueryResultWrapper();
        ConditionMap tableConditonMap = DataCache.getTabMap(parameterMap);
        if (tableConditonMap != null && tableConditonMap.getPlatFormConditionList() != null && tableConditonMap.getPlatFormConditionList().size() > 0) {
            //将注单状态set到tableConditonMap中去
            if (parameterMap.containsKey(UtilConstants.DATA_FLAG) && StringUtils.isNotBlank((String) parameterMap.get(UtilConstants.DATA_FLAG))) {
                List<String> gameOrderStatusList = new ArrayList<>();
                String gameOrderStatusStr = (String) parameterMap.get(UtilConstants.DATA_FLAG);//	注单状态
                String[] gameOrderStatusArr = gameOrderStatusStr.split(UtilConstants.COMMA_SYMBOL);
                for (String gameOrderStatus : gameOrderStatusArr) {
                    gameOrderStatusList.add(gameOrderStatus);
                }
                List<PlatformCondition> platFormConditionList = tableConditonMap.getPlatFormConditionList();
                for (PlatformCondition platFormConditions : platFormConditionList) {
                    platFormConditions.setGameOrderStatusList(gameOrderStatusList);
                }
            }
            //PDATACENTER-127要求查询电子游戏时，过滤掉捕鱼的数据，SL%的标记由方法getOrderListGroupByLoginName使用，查询getOrderList走'SL%_'标记
            List<PlatformCondition> clList = tableConditonMap.getPlatFormConditionList();
            if (clList != null && !clList.isEmpty()) {
                for (PlatformCondition pc : clList) {
                    if (!pc.getKey().equals("026")) {
                        continue;
                    }
                    List<String> gtl = pc.getGameTypeList();
                    //YT-43 【P02】数据中心--捕鱼数据，无法用游戏局/期号查询到信息【平台】,因为捕鱼的期号在round字段而不是 gmcode ---- 开始
                    if (pc.getKey().equals("026")) {
                        String gmCode = (String) parameterMap.get("gmCode");
                        String gamekindList = (String) parameterMap.get("gameKind");
                        if (gmCode != null) {
                            if (gamekindList != null && gamekindList.indexOf("026_8") != -1 || gtl != null && gtl.indexOf("%FISH") != -1) { //如果是捕鱼游戏,则根据round来查
                                parameterMap.put("round", gmCode);
                                parameterMap.remove("gmCode");
                            }
                        }
                    }
                    //YT-43 【P02】数据中心--捕鱼数据，无法用游戏局/期号查询到信息【平台】,因为捕鱼的期号在round字段而不是 gmcode  ---- 结束
                    if (gtl == null) {
                        break;
                    }
                    int indexOfSL = gtl.indexOf("SL%");
                    if (indexOfSL != -1) {
                        gtl.set(indexOfSL, "SL%_");
                    }
                }
            }
            parameterMap.put("tableList", tableConditonMap);
            //YT-104, LB-5537 allow search by game name for single platforms. if there is a game name, get the values from dictionary
            if (parameterMap.containsKey(UtilConstants.GAME_NAME) && StringUtils.isNotEmpty((String) parameterMap.get(UtilConstants.GAME_NAME))) {
                parameterMap.put("gameNameList", parameterMap.get(UtilConstants.GAME_NAME));
                //SLOT-1202 产品自助查询AGIN数据中心ID功能【平台】
            } else {
                parameterMap.put("gameType", parameterMap.get(UtilConstants.GAME_NAME));
            }
            //返回结果
            log.info("getOrderDetailsAndSummaryByGmCode parameter:" + JacksonUtil.toJSon(parameterMap));
            QueryResult<OrderEntity> queryResult = new QueryResult<>();
            List<OrderEntity> orderList = orderDao.getOrderList(parameterMap);
            orderList.parallelStream().forEach(order -> order.setGameType(DataUtil.getGameName(order)));
            queryResult.setQueryResultList(orderList);
            String totalStr = orderDao.countTotalStrOrder(parameterMap);
            String[] totalArray = StringUtils.isNotBlank(totalStr) ? totalStr.split(UtilConstants.COMMA_SYMBOL) : null;
            Integer totalRecords = ArrayUtils.isNotEmpty(totalArray) && StringUtils.isNotBlank(totalArray[0]) ? Double.valueOf(totalArray[0]).intValue() : 0;
            queryResult.setTotalRecords(totalRecords);
            wrapper.setQueryResult(queryResult);
            wrapper.setUtilArray(totalArray);
        }
        return wrapper;
    }

    private void putOrderDetailsAndSummaryParam(String productId, String loginName, String gameCode, String beginTime, String endTime, String key, Map<String, Object> parameterMap) throws GWKeyErrorException {
        StringBuffer sb = new StringBuffer();
        if (StringUtils.isNotBlank(productId)) {
            parameterMap.put("productId", productId);
            sb.append(productId);
        } else {
            parameterMap.put("productId", null);
        }
        if (StringUtils.isNotBlank(loginName)) {
            parameterMap.put("loginName", loginName);
            sb.append(loginName);
        }
        parameterMap.put("gmCode", gameCode);
        sb.append(gameCode);
        parameterMap.put("beginTime", beginTime);
        sb.append(beginTime);
        parameterMap.put("endTime", endTime);
        sb.append(endTime);
        sb.append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(sb.toString()), key);
    }

    @Override
    public QueryResultWrapper getBoWinList(String productId, String loginName, String beginTime, String endTime, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException {
        //参数校验
        ParamCheckUtil.checkBeginTime(beginTime);
        ParamCheckUtil.checkEndTime(endTime);
        //构造请求参数
        Map<String, Object> parameterMap = PageUtil.getParameterMap(pageNo, pageSize);
        putBoWinListParam(productId, loginName, beginTime, endTime, key, parameterMap);
        //返回结果
        log.info("getBoWinList parameter:" + JacksonUtil.toJSon(parameterMap));
        QueryResultWrapper wrapper = new QueryResultWrapper();
        QueryResult<OrderEntity> queryResult = new QueryResult<>();
        List<OrderEntity> orderList = orderDao.getBoWinList(parameterMap);
        orderList.parallelStream().forEach(order -> order.setGameType(DataUtil.getGameName(order)));
        queryResult.setQueryResultList(orderList);
        String totalStr = orderDao.countTotalStrBoWin(parameterMap);
        String[] totalArray = StringUtils.isNotBlank(totalStr) ? totalStr.split(UtilConstants.COMMA_SYMBOL) : null;
        Integer totalRecords = ArrayUtils.isNotEmpty(totalArray) && StringUtils.isNotBlank(totalArray[0]) ? Integer.parseInt(totalArray[0]) : 0;
        queryResult.setTotalRecords(totalRecords);
        wrapper.setQueryResult(queryResult);
        wrapper.setUtilArray(totalArray);
        return wrapper;
    }

    private void putBoWinListParam(String productId, String loginName, String beginTime, String endTime, String key, Map<String, Object> parameterMap) throws GWKeyErrorException {
        StringBuffer sb = new StringBuffer();
        if (StringUtils.isNotBlank(productId)) {
            parameterMap.put("productId", productId);
            sb.append(productId);
        } else {
            parameterMap.put("productId", null);
        }
        if (StringUtils.isNotBlank(loginName)) {
            parameterMap.put("loginName", loginName);
            sb.append(loginName);
        }
        parameterMap.put("beginTime", beginTime);
        sb.append(beginTime);
        parameterMap.put("endTime", endTime);
        sb.append(endTime);
        sb.append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(sb.toString()), key);
    }

    @Override
    public List<MonthlyWeeklyEffectiveBetAmountEntity> getMonthlyAndWeeklyValidAmount(String productId, String loginNameArray, BigDecimal amount, String weekBeginTime, String weekEndTime, String monthBeginTime, String monthEndTime, String key) throws GWPersistenceException, GWKeyErrorException {
        //参数校验
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkWeekBeginTime(weekBeginTime);
        ParamCheckUtil.checkWeekEndTime(weekEndTime);
        //构造请求参数
        Map<String, Object> parameterMap = putMonthlyAndWeeklyValidAmountParam(productId, loginNameArray, amount, weekBeginTime, weekEndTime, key);
        if (!checkQueryByWeekDataParam(weekBeginTime, weekEndTime, parameterMap)) {
            return null;
        }
        parameterMap.put("tableList", DataCache.getTableMap(productId, null).getConditionList());
        /*
         * parameterMap.put("monthBeginTime", monthBeginTime); parameterMap.put("monthEndTime", monthEndTime);
         */
        //返回结果
        log.info("getMonthlyAndWeeklyValidAmount parameter:" + JacksonUtil.toJSon(parameterMap));
        return orderDao.getMonthlyAndWeeklyValidAmount(parameterMap);
    }

    private Map<String, Object> putMonthlyAndWeeklyValidAmountParam(String productId, String loginNameArray, BigDecimal amount, String weekBeginTime, String weekEndTime, String key) throws GWKeyErrorException {
        Map<String, Object> parameterMap = new HashMap<>();
        StringBuffer sb = new StringBuffer();
        parameterMap.put("productId", productId);
        sb.append(productId);
        if (StringUtils.isNotBlank(loginNameArray)) {
            parameterMap.put("loginNameList", Arrays.asList(loginNameArray.split(UtilConstants.COMMA_SYMBOL)));
            sb.append(loginNameArray);
        }
        if (amount != null) {
            parameterMap.put("validAmountWeek", amount);
            sb.append(amount);
        }
        sb.append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(sb.toString()), key);
        parameterMap.put("weekBeginTime", weekBeginTime);
        parameterMap.put("weekEndTime", weekEndTime);
        return parameterMap;
    }

    private boolean checkQueryByWeekDataParam(String weekBeginTime, String weekEndTime, Map<String, Object> parameterMap) {
        boolean isQueryByDate = weekBeginTime.length() <= 10;
        if (weekBeginTime.endsWith("00:00:00") && weekEndTime.endsWith("23:59:59")) {
            if (DateUtil.calcDiffHours(weekEndTime) >= UtilConstants.XM_DELAY_THRESHOLD) {
                weekBeginTime = weekBeginTime.substring(0, 10);
                weekEndTime = weekEndTime.substring(0, 10);
                isQueryByDate = true;
                parameterMap.put("weekBeginTime", weekBeginTime);
                parameterMap.put("weekEndTime", weekEndTime);
            }
        }
        if (!isQueryByDate) {
            boolean isQueryInRange = DataUtil.isInQueryRange(weekBeginTime, weekEndTime);
            if (!isQueryInRange) {
                log.error("getValidAmountQueryResultByType not in date range,params:" + parameterMap);
                return false;
            }
        }
        parameterMap.put("isQueryByDate", isQueryByDate);
        return true;
    }

    @Override
    public QueryResult<OrderEntity> getCustomerBetTime(String productId, String loginName, Integer type, String key) throws GWPersistenceException, GWKeyErrorException {
        //参数校验
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkLoginName(loginName);
        ParamCheckUtil.checkType(type);
        //构造请求参数
        Map<String, Object> parameterMap = putCustomerBetTimeParam(productId, loginName, type, key);
        //返回结果
        log.info("getCustomerBetTime parameter:" + JacksonUtil.toJSon(parameterMap));
        QueryResult<OrderEntity> queryResult = new QueryResult<>();
        List<OrderEntity> entityList = orderDao.getCustomerBetTimeList(parameterMap);
        queryResult.setQueryResultList(entityList);
        queryResult.setTotalRecords(entityList.size());
        return queryResult;
    }

    private Map<String, Object> putCustomerBetTimeParam(String productId, String loginName, Integer type, String key) throws GWKeyErrorException {
        Map<String, Object> parameterMap = new HashMap<>();
        StringBuffer sb = new StringBuffer();
        parameterMap.put("productId", productId);
        sb.append(productId);
        parameterMap.put("loginName", loginName);
        sb.append(loginName);
        parameterMap.put("type", type);
        sb.append(type);
        sb.append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(sb.toString()), key);
        parameterMap.put("tableList", DataCache.getCustomerBetTimeTableMap());
        return parameterMap;
    }

    @Override
    public QueryResult<ContinuousOrder> getContinuousOrder(String productId, String[] platformId, String beginTime, String endTime, String gameKind, Integer times, Integer minAmount, String key) throws GWPersistenceException, GWKeyErrorException {
        //参数校验
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkBeginTime(beginTime);
        ParamCheckUtil.checkEndTime(endTime);
        ParamCheckUtil.checkPlatforms(platformId);
        ParamCheckUtil.checkTimes(times);
        ParamCheckUtil.checkMinAmount(minAmount);
        long dataRange = DateUtil.calcDiffDays(beginTime, endTime);
        ParamCheckUtil.checkDataRange(dataRange);
        checkContinuousOrderKey(productId, beginTime, endTime, times, minAmount, key);
        //构造请求参数
        Map<String, Object> parameterMap = putContinuousOrderParam(productId, platformId, beginTime, endTime, gameKind, times, minAmount, key, dataRange);
        //返回结果
        log.info("getContinuousOrder parameter:" + JacksonUtil.toJSon(parameterMap));
        QueryResult<ContinuousOrder> queryResult = new QueryResult<>();
        List<ContinuousOrder> entityList = orderDao.getContinuousOrder(parameterMap);
        queryResult.setQueryResultList(entityList);
        queryResult.setTotalRecords(entityList.size());
        return queryResult;
    }

    private Map<String, Object> putContinuousOrderParam(String productId, String[] platformId, String beginTime, String endTime, String gameKind, Integer times, Integer minAmount, String key, long dataRange) throws GWKeyErrorException {
        Map<String, Object> parameterMap = new HashMap<>();
        parameterMap.put("tableList", DataCache.getTableMapByPlatFormIds(productId, platformId));
        parameterMap.put("beginTime", beginTime);
        parameterMap.put("endTime", endTime);
        parameterMap.put("orderAmount", minAmount);
        parameterMap.put("productId", productId);
        parameterMap.put("times", times);
        parameterMap.put("gameKind", gameKind);
        parameterMap.put("dataRange", dataRange);
        return parameterMap;
    }

    private void checkContinuousOrderKey(String productId, String beginTime, String endTime, Integer times, Integer minAmount, String key) throws GWKeyErrorException {
        StringBuffer sb = new StringBuffer();
        sb.append(productId);
        sb.append(beginTime);
        sb.append(endTime);
        sb.append(times);
        sb.append(minAmount);
        sb.append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(sb.toString()), key);
    }

    @Override
    public QueryResult<OrderEntity> getOrderListByProfit(String productId, String[] platformId, String beginTime, String endTime, Integer multiple, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException {
        //参数校验
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkPlatforms(platformId);
        ParamCheckUtil.checkBeginTime(beginTime);
        ParamCheckUtil.checkEndTime(endTime);
        ParamCheckUtil.checkMultiple(multiple);
        ParamCheckUtil.checkPageNo(pageNo);
        ParamCheckUtil.checkPageSize(pageSize);
        checkOrderListByProfitKey(productId, beginTime, endTime, multiple, pageNo, pageSize, key);
        //构造请求参数
        Map<String, Object> parameterMap = putOrderListByProfitParam(productId, platformId, beginTime, endTime, multiple, pageNo, pageSize, key);
        //返回结果
        log.info("getOrderListByProfit parameter:" + JacksonUtil.toJSon(parameterMap));
        QueryResult<OrderEntity> queryResult = new QueryResult<>();
        List<OrderEntity> orderList = orderDao.getOrderListByProfit(parameterMap);
        orderList.parallelStream().forEach(order -> order.setGameType(DataUtil.getGameName(order)));
        queryResult.setQueryResultList(orderList);
        queryResult.setTotalRecords(orderList.size());
        return queryResult;
    }

    private Map<String, Object> putOrderListByProfitParam(String productId, String[] platformId, String beginTime, String endTime, Integer multiple, Integer pageNo, Integer pageSize, String key) throws GWKeyErrorException {
        Map<String, Object> parameterMap = PageUtil.getParameterMap(pageNo, pageSize);
        parameterMap.put("tableList", DataCache.getTableMapByPlatFormIds(productId, platformId));
        parameterMap.put("beginTime", beginTime);
        parameterMap.put("endTime", endTime);
        parameterMap.put("productId", productId);
        parameterMap.put("multiple", multiple);
        return parameterMap;
    }

    private void checkOrderListByProfitKey(String productId, String beginTime, String endTime, Integer multiple, Integer pageNo, Integer pageSize, String key) throws GWKeyErrorException {
        StringBuffer sb = new StringBuffer();
        sb.append(productId);
        sb.append(beginTime);
        sb.append(endTime);
        sb.append(multiple);
        sb.append(pageNo);
        sb.append(pageSize);
        sb.append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(sb.toString()), key);
    }

    @Override
    public QueryResult<OrderEntity> getHighProfitOrderList(String productId, String[] platformId, String[] gameKind, String beginTime, String endTime, Integer cusAmount, Integer multiple, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException {
        //参数校验
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkPlatforms(platformId);
        ParamCheckUtil.checkGameKinds(gameKind);
        ParamCheckUtil.checkBeginTime(beginTime);
        ParamCheckUtil.checkEndTime(endTime);
        ParamCheckUtil.checkMultiple(multiple);
        ParamCheckUtil.checkCusAmount(cusAmount);
        ParamCheckUtil.checkPageNo(pageNo);
        ParamCheckUtil.checkPageSize(pageSize);
        checkHighProfitOrderListKey(productId, beginTime, endTime, cusAmount, multiple, pageNo, pageSize, key);
        //构造请求参数
        Map<String, Object> parameterMap = putHighProfitOrderListParam(productId, platformId, gameKind, beginTime, endTime, cusAmount, multiple, pageNo, pageSize, key);
        //返回结果
        log.info("getHighProfitOrderList parameter:" + JacksonUtil.toJSon(parameterMap));
        QueryResult<OrderEntity> queryResult = new QueryResult<>();
        List<OrderEntity> orderList = orderDao.getHighProfitOrderList(parameterMap);
        orderList.parallelStream().forEach(order -> order.setGameType(DataUtil.getGameName(order)));
        queryResult.setQueryResultList(orderList);
        queryResult.setTotalRecords(orderList.size());
        return queryResult;
    }

    private Map<String, Object> putHighProfitOrderListParam(String productId, String[] platformId, String[] gameKind, String beginTime, String endTime, Integer cusAmount, Integer multiple, Integer pageNo, Integer pageSize, String key) throws GWKeyErrorException {
        Map<String, Object> parameterMap = PageUtil.getParameterMap(pageNo, pageSize);
        parameterMap.put("tableList", DataCache.getTableMapByPlatFormIds(productId, platformId));
        parameterMap.put("beginTime", beginTime);
        parameterMap.put("endTime", endTime);
        parameterMap.put("productId", productId);
        parameterMap.put("cusAmount", cusAmount);
        parameterMap.put("gameKind", gameKind);
        parameterMap.put("multiple", multiple);
        return parameterMap;
    }

    private void checkHighProfitOrderListKey(String productId, String beginTime, String endTime, Integer cusAmount, Integer multiple, Integer pageNo, Integer pageSize, String key) throws GWKeyErrorException {
        StringBuffer sb = new StringBuffer();
        sb.append(productId);
        sb.append(beginTime);
        sb.append(endTime);
        sb.append(cusAmount);
        sb.append(multiple);
        sb.append(pageNo);
        sb.append(pageSize);
        sb.append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(sb.toString()), key);
    }

    @Override
    public QueryResult<OrderEntity> getBetHistory(String productId, String[] platformId, String beginTime, String endTime, Integer flag, Integer cusAmount, Integer multiple, Integer maxRecode, String key) throws GWPersistenceException, GWKeyErrorException {
        //参数校验
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkBeginTime(beginTime);
        ParamCheckUtil.checkEndTime(endTime);
        ParamCheckUtil.checkCusAmount(cusAmount);
        ParamCheckUtil.checkMultiple(multiple);
        ParamCheckUtil.checkMaxRecode(maxRecode);
        ParamCheckUtil.checkFlag(flag);
        checkBetHistoryKey(productId, beginTime, endTime, flag, cusAmount, multiple, maxRecode, key);
        //构造请求参数
        Map<String, Object> parameterMap = putBetHistoryParam(productId, platformId, beginTime, endTime, flag, cusAmount, multiple, maxRecode, key);
        //返回结果
        log.info("getBetHistory parameter:" + JacksonUtil.toJSon(parameterMap));
        List<OrderEntity> result1 = orderDao.getBetHistory(parameterMap);
        List<OrderEntity> result2 = orderDao.getBetHistoryByMultipleProfit(parameterMap);
        List<OrderEntity> union = (List<OrderEntity>) CollectionUtils.union(result1, result2);
        QueryResult<OrderEntity> result = new QueryResult<>();
        union.parallelStream().forEach(order -> order.setGameType(DataUtil.getGameName(order)));
        result.setQueryResultList(union);
        result.setTotalRecords(union.size());
        return result;
    }

    private Map<String, Object> putBetHistoryParam(String productId, String[] platformId, String beginTime, String endTime, int flag, Integer cusAmount, Integer multiple, Integer maxRecode, String key) throws GWKeyErrorException {
        Map<String, Object> parameterMap = PageUtil.getParameterMap(1, maxRecode);
        parameterMap.put("tableList", DataCache.getTableMapByPlatFormIds(productId, platformId));
        parameterMap.put("beginTime", beginTime);
        parameterMap.put("endTime", endTime);
        parameterMap.put("productId", productId);
        parameterMap.put("flag", flag);
        parameterMap.put("cusAmount", cusAmount);
        parameterMap.put("multiple", multiple);
        parameterMap.put("maxRecode", maxRecode);
        return parameterMap;
    }

    private void checkBetHistoryKey(String productId, String beginTime, String endTime, int flag, Integer cusAmount, Integer multiple, Integer maxRecode, String key) throws GWKeyErrorException {
        StringBuffer sb = new StringBuffer();
        sb.append(productId);
        sb.append(beginTime);
        sb.append(endTime);
        sb.append(flag);
        sb.append(cusAmount);
        sb.append(multiple);
        sb.append(maxRecode);
        sb.append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(sb.toString()), key);
    }

    @Override
    public QueryResult<OrderEntity> getBestWin(String productId, String[] platformId, String beginTime, String endTime, Integer cusAmount, Integer listCount, String key) throws GWPersistenceException, GWKeyErrorException {
        //参数校验
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkPlatforms(platformId);
        ParamCheckUtil.checkBeginTime(beginTime);
        ParamCheckUtil.checkEndTime(endTime);
        ParamCheckUtil.checkCusAmount(cusAmount);
        ParamCheckUtil.checkListCount(listCount);
        checkBestWinKey(productId, beginTime, endTime, cusAmount, listCount, key);
        //构造请求参数
        Map<String, Object> parameterMap = putBestWinParam(productId, platformId, beginTime, endTime, cusAmount, listCount, key);
        //返回结果
        log.info("getBestWin parameter:" + JacksonUtil.toJSon(parameterMap));
        QueryResult<OrderEntity> queryResult = new QueryResult<>();
        List<OrderEntity> orderList = orderDao.getBestWin(parameterMap);
        orderList.parallelStream().forEach(order -> order.setGameType(DataUtil.getGameName(order)));
        queryResult.setQueryResultList(orderList);
        queryResult.setTotalRecords(orderList.size());
        return queryResult;
    }

    private Map<String, Object> putBestWinParam(String productId, String[] platformId, String beginTime, String endTime, Integer cusAmount, Integer listCount, String key) throws GWKeyErrorException {
        Map<String, Object> parameterMap = new HashMap<>();
        parameterMap.put("tableList", DataCache.getTableMapByPlatFormIds(productId, platformId));
        parameterMap.put("beginTime", beginTime);
        parameterMap.put("endTime", endTime);
        parameterMap.put("productId", productId);
        parameterMap.put("cusAmount", cusAmount);
        parameterMap.put("listCount", listCount);
        return parameterMap;
    }

    private void checkBestWinKey(String productId, String beginTime, String endTime, Integer cusAmount, Integer listCount, String key) throws GWKeyErrorException {
        StringBuffer sb = new StringBuffer();
        sb.append(productId);
        sb.append(beginTime);
        sb.append(endTime);
        sb.append(cusAmount);
        sb.append(listCount);
        sb.append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(sb.toString()), key);
    }

    @Override
    public QueryResult<OrderEntity> getOrderByMultipleAndValidAccount2(String productId, String[] platformId, String beginTime, String endTime, OrderEntity orderEntity, Integer multiple, Integer pageNo, Integer pageSize) throws GWPersistenceException {
        //参数校验
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkBeginTime(beginTime);
        ParamCheckUtil.checkEndTime(endTime);
        //构造请求参数
        Map<String, Object> parameterMap = putOrderByMultipleParam(productId, platformId, beginTime, endTime, orderEntity, multiple, pageNo, pageSize);
        //返回结果
        log.info("getOrderByMultipleAndValidAccount2 parameter:" + JacksonUtil.toJSon(parameterMap));
        QueryResult<OrderEntity> queryResult = new QueryResult<>();
        List<OrderEntity> orderList = orderDao.getOrderByMultipleAndValidAccount2(parameterMap);
        orderList.parallelStream().forEach(order -> order.setGameType(DataUtil.getGameName(order)));
        queryResult.setQueryResultList(orderList);
        queryResult.setTotalRecords(orderList.size());
        return queryResult;
    }

    private Map<String, Object> putOrderByMultipleParam(String productId, String[] platformId, String beginTime, String endTime, OrderEntity orderEntity, Integer multiple, Integer pageNo, Integer pageSize) {
        Map<String, Object> parameterMap = PageUtil.getParameterMap(pageNo, pageSize);
        parameterMap.put("productId", productId);
        parameterMap.put("beginTime", beginTime);
        parameterMap.put("endTime", endTime);
        if (StringUtils.isNotBlank(orderEntity.getLoginName())) {
            parameterMap.put("loginNameList", Arrays.asList(orderEntity.getLoginName().split(UtilConstants.COMMA_SYMBOL)));
        }
        if (orderEntity.getValidAccount() != null) {
            parameterMap.put("validAccount", orderEntity.getValidAccount());
        }
        if (orderEntity.getCusAccount() != null) {
            parameterMap.put("cusAmount", orderEntity.getCusAccount());
        }
        if (orderEntity.getAccount() != null) {
            parameterMap.put("amount", orderEntity.getAccount());
        }
        if (orderEntity.getGameKind() != null) {
            parameterMap.put("gameKind", orderEntity.getGameKind());
        }
        if (multiple != null) {
            parameterMap.put("multiple", multiple);
        }
        parameterMap.put("tableList", DataCache.getTableMapByPlatFormIds(productId, platformId));
        return parameterMap;
    }

    private void checkRecordParametes(String productId, String[] platformId, String[] gameKind, String beginTime, String endTime, String settledType, Integer pageNo, Integer pageSize) throws GWPersistenceException {
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkBeginTime(beginTime);
        ParamCheckUtil.checkEndTime(endTime);
        ParamCheckUtil.checkPlatforms(platformId);
        ParamCheckUtil.checkGameKinds(gameKind);
        ParamCheckUtil.checkPageNo(pageNo);
        ParamCheckUtil.checkPageSize(pageSize);
        ParamCheckUtil.checkSettledType(settledType);
    }

    @Override
    public QueryResult<OrderEntity> getRecord(String productId, String[] platformId, String[] loginName, String[] gameKind, String beginTime, String endTime, String settledType, Integer minBetAmount, Integer minCusAmount, Integer minMultiple, String fieldsOrder, Integer pageNo, Integer pageSize, String key, String gameType, String[] gameCode, String billNo, String currency,Integer remainAmount) throws GWPersistenceException, GWKeyErrorException {
        //参数校验
        checkRecordParametes(productId, platformId, gameKind, beginTime, endTime, settledType, pageNo, pageSize);
        checkRecordKey(productId, platformId, loginName, gameKind, beginTime, endTime, settledType, minBetAmount, minCusAmount, minMultiple, fieldsOrder, pageNo, pageSize, key);
        //构造请求参数
        Map<String, Object> parameterMap = putRecordParam(productId, platformId, loginName, gameKind, beginTime, endTime, settledType, minBetAmount, minCusAmount, remainAmount, minMultiple, fieldsOrder, pageNo, pageSize, "\\s*(VALID_ACCOUNT|CUS_ACCOUNT|BILLTIME|Multiple|BONUS_AMOUNT)\\s+((?:de|a)sc)\\s*");
        putExtraRecordParam(gameType, gameCode, billNo, currency, parameterMap);
        //返回结果
        log.info("getRecordList parameter:" + JacksonUtil.toJSon(parameterMap));
        QueryResult<OrderEntity> queryResult = new QueryResult<>();
        List<OrderEntity> orderList = orderDao.getRecordList(parameterMap);
        orderList.parallelStream().forEach(order -> order.setGameType(DataUtil.getGameName(order)));
        queryResult.setQueryResultList(orderList);
        queryResult.setTotalRecords(orderList.size() > 0 ? orderDao.countGetRecord(parameterMap) : 0);
        return queryResult;
    }

    private void putExtraRecordParam(String gameType, String[] gameCode, String billNo, String currency, Map<String, Object> parameterMap) {
        parameterMap.put("gameType", StringUtils.isNotBlank(gameType) ? gameType.split(UtilConstants.COMMA_SYMBOL) : null);
        parameterMap.put("billNo", billNo);
        if (StringUtils.isNotBlank(currency)) {
            parameterMap.put("currency", currency);//添加货币类型
        }
        if (ArrayUtils.isNotEmpty(gameCode)) {
            parameterMap.put("gameCode", gameCode);
        }
    }

    private Map<String, Object> putRecordParam(String productId, String[] platformId, String[] loginName, String[] gameKind, String beginTime, String endTime, String settledType, Integer minBetAmount, Integer minCusAmount, Integer remainAmount,Integer minMultiple, String fieldsOrder, Integer pageNo, Integer pageSize, String regex) {
        Map<String, Object> parameterMap = PageUtil.getParameterMap(pageNo, pageSize);
        parameterMap.put("tableList", DataCache.getTableMapByPlatFormIds(productId, platformId));
        parameterMap.put("beginTime", beginTime);
        parameterMap.put("endTime", endTime);
        parameterMap.put("loginName", loginName);
        parameterMap.put("gameKind", gameKind);
        parameterMap.put("productId", productId);
        parameterMap.put("settledType", StringUtils.isBlank(settledType) ? null : Integer.parseInt(settledType));
        parameterMap.put("minBetAmount", minBetAmount);
        parameterMap.put("minCusAmount", minCusAmount);
        parameterMap.put("remainAmount",remainAmount);
        parameterMap.put("minMultiple", minMultiple);

        StringBuilder orderByStr = putOrderByStr(fieldsOrder, regex);
        if (orderByStr.length() == 0) {
            orderByStr.append(" BILLTIME DESC ");
        }
        parameterMap.put("orderStr", orderByStr.toString());
        return parameterMap;
    }

    private void checkRecordKey(String productId, String[] platformId, String[] loginName, String[] gameKind, String beginTime, String endTime, String settledType, Integer minBetAmount, Integer minCusAmount, Integer minMultiple, String fieldsOrder, Integer pageNo, Integer pageSize, String key) throws GWKeyErrorException {
        StringBuilder paramStr = new StringBuilder().append(productId).append(StringUtils.join(platformId, UtilConstants.COMMA_SYMBOL));
        paramStr.append(loginName == null ? "" : StringUtils.join(loginName, UtilConstants.COMMA_SYMBOL)).append(StringUtils.join(gameKind, UtilConstants.COMMA_SYMBOL)).append(beginTime);
        paramStr.append(endTime).append(StringUtils.isNotBlank(settledType) ? settledType : "").append(minBetAmount == null ? "" : String.valueOf(minBetAmount.intValue()));
        paramStr.append(minCusAmount == null ? "" : String.valueOf(minCusAmount.intValue())).append(minMultiple == null ? "" : String.valueOf(minMultiple.intValue()));
        paramStr.append(StringUtils.isNotBlank(fieldsOrder) ? fieldsOrder : "").append(pageNo != null ? String.valueOf(pageNo.intValue()) : "").append(pageSize != null ? String.valueOf(pageSize.intValue()) : "");
        paramStr.append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(paramStr.toString()), key);
    }

    @Override
    public Map<String, Object> getPlayerPlatformProfit (String productId, String platformId, String loginName, String currency, String beginTime, String endTime) throws GWPersistenceException {
        //参数校验
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkPlatformId(platformId);
        ParamCheckUtil.checkLoginName(loginName);
        ParamCheckUtil.checkBeginTime(beginTime);
        ParamCheckUtil.checkEndTime(endTime);
        //构造请求参数
        Map<String, Object> parameterMap = new HashMap<>();
        parameterMap.put("productId", productId);
        parameterMap.put("platformId", platformId);
        parameterMap.put("loginName", loginName);
        parameterMap.put("beginTime", beginTime);
        parameterMap.put("endTime", endTime);
        if (StringUtils.isNotBlank(currency)){
            parameterMap.put("currency", currency);
        }
        parameterMap.put("tableName", DataCache.getTableMapByPlatFormId(productId, platformId));
        //返回结果
        log.info("getPlayerPlatformProfit parameter:" + JacksonUtil.toJSon(parameterMap));
        List<PlayerPlatformProfit> playerPlatformProfitList = orderDao.getPlayerPlatformProfit(parameterMap);
        BigDecimal totalBetAmount = BigDecimal.ZERO;
        BigDecimal totalValidBetAmount = BigDecimal.ZERO;
        BigDecimal totalCusAmount = BigDecimal.ZERO;
        for (PlayerPlatformProfit playerPlatformProfit : playerPlatformProfitList){
            totalBetAmount = totalBetAmount.add(new BigDecimal(playerPlatformProfit.getBetAmount()));
            totalValidBetAmount = totalValidBetAmount.add(new BigDecimal(playerPlatformProfit.getValidBetAmount()));
            totalCusAmount = totalCusAmount.add(new BigDecimal(playerPlatformProfit.getCusAmount()));
            GameTypePlayTypeEntity gameTypePlayTypeEntity = DataCache.getCacheGameTypeEntity(platformId, playerPlatformProfit.getGameType());
            if (gameTypePlayTypeEntity != null){
                playerPlatformProfit.setChineseName(gameTypePlayTypeEntity.getChineseName());
            } else {
                playerPlatformProfit.setChineseName("");
            }
            playerPlatformProfit.setProfitRate(new BigDecimal(playerPlatformProfit.getProfitRate()).multiply(new BigDecimal(100)).setScale(2, BigDecimal.ROUND_HALF_UP).toPlainString() + "%");
        }
        String totalProfitRate;
        if (totalValidBetAmount.compareTo(BigDecimal.ZERO) == 0){
            totalProfitRate = "0.00%";
        } else {
            totalProfitRate = totalCusAmount.divide(totalValidBetAmount, 2, BigDecimal.ROUND_HALF_UP).multiply(new BigDecimal(100)).toPlainString() + "%";
        }
        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("totalBetAmount", totalBetAmount);
        resultMap.put("totalValidBetAmount", totalValidBetAmount);
        resultMap.put("totalCusAmount", totalCusAmount);
        resultMap.put("totalProfitRate", totalProfitRate);
        resultMap.put("detailInfos", playerPlatformProfitList);
        return resultMap;
    }

    @Override
    public QueryResultWrapper getRecordAndSummary(String productId, String[] platformId, String[] loginName, String[] gameKind, String beginTime, String endTime, String settledType, Integer minBetAmount, Integer minCusAmount, Integer minMultiple, String fieldsOrder, Integer pageNo, Integer pageSize, String key, String[] gameType, String[] gameCode,Integer remainAmount,String currency) throws GWPersistenceException, GWKeyErrorException {
        //参数校验
        checkRecordParametes(productId, platformId, gameKind, beginTime, endTime, settledType, pageNo, pageSize);
        checkRecordKey(productId, platformId, loginName, gameKind, beginTime, endTime, settledType, minBetAmount, minCusAmount, minMultiple, fieldsOrder, pageNo, pageSize, key);
        //构造请求参数
        Map<String, Object> parameterMap = putRecordParam(productId, platformId, loginName, gameKind, beginTime, endTime, settledType, minBetAmount, minCusAmount, remainAmount,minMultiple, fieldsOrder, pageNo, pageSize, "\\s*(ACCOUNT|VALID_ACCOUNT|CUS_ACCOUNT|BILLTIME|Multiple|BONUS_AMOUNT)\\s+((?:de|a)sc)\\s*");
        putExtraRecordAndSummaryParam(gameType, gameCode, parameterMap);
        parameterMap.put("currency",currency);
        //返回结果
        log.info("getRecordAndSummary parameter:" + JacksonUtil.toJSon(parameterMap));
        QueryResultWrapper wrapper = new QueryResultWrapper();
        QueryResult<OrderEntity> queryResult = new QueryResult<>();
        List<OrderEntity> orderList = orderDao.getRecordList(parameterMap);
        orderList.parallelStream().forEach(order -> order.setGameType(DataUtil.getGameName(order)));
        queryResult.setQueryResultList(orderList);
        String totalStr = orderDao.countTotalStrRecordAndSummary(parameterMap);
        String[] totalArray = StringUtils.isNotBlank(totalStr) ? totalStr.split(UtilConstants.COMMA_SYMBOL) : null;
        Integer totalRecords = ArrayUtils.isNotEmpty(totalArray) && StringUtils.isNotBlank(totalArray[0]) ? Integer.parseInt(totalArray[0]) : 0;
        queryResult.setTotalRecords(totalRecords);
        wrapper.setQueryResult(queryResult);
        wrapper.setUtilArray(totalArray);
        log.info("getRecordAndSummary result : orderList size:{} totalStr:{}", orderList.size(), totalStr );
        return wrapper;
    }

    @Override
    public QueryResult<OrderSummary> getRecordSummary(String productId, String[] platformId, String[] loginName, String[] gameKind, String beginTime, String endTime, String settledType, Integer minBetAmount, Integer minCusAmount, Integer minMultiple, String fieldsOrder, Integer pageNo, Integer pageSize, String key, String[] gameType, String[] gameCode, Integer remainAmount) throws GWPersistenceException, GWKeyErrorException {
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkBeginTime(beginTime);
        ParamCheckUtil.checkEndTime(endTime);
        ParamCheckUtil.checkLoginNameArray(loginName);

        checkRecordKey(productId, platformId, loginName, gameKind, beginTime, endTime, settledType, minBetAmount, minCusAmount, minMultiple, fieldsOrder, pageNo, pageSize, key);

        Map<String,Object> parameterMap = new HashMap<>();
        parameterMap.put("tableList", DataCache.getTableMapByPlatFormIds(productId, platformId));
        parameterMap.put("beginTime", beginTime);
        parameterMap.put("endTime", endTime);
        parameterMap.put("loginName", loginName);
        parameterMap.put("gameKind", gameKind);
        parameterMap.put("productId", productId);
        parameterMap.put("settledType", StringUtils.isBlank(settledType) ? null : Integer.parseInt(settledType));
        parameterMap.put("minBetAmount", minBetAmount);
        parameterMap.put("minCusAmount", minCusAmount);
        parameterMap.put("remainAmount",remainAmount);
        parameterMap.put("minMultiple", minMultiple);
        parameterMap.put("gameType",gameType);
        parameterMap.put("gameCode",gameCode);

        List<OrderSummary> resultList = orderDao.getRecordSummay(parameterMap);
        QueryResult<OrderSummary> result = new QueryResult<>();
        result.setQueryResultList(resultList);
        result.setTotalRecords(resultList==null ? 0:resultList.size());

        return result;
    }

    private void putExtraRecordAndSummaryParam(String[] gameType, String[] gameCode, Map<String, Object> parameterMap) {
        if (ArrayUtils.isNotEmpty(gameType)) {
            parameterMap.put("gameType", gameType);
        }
        if (ArrayUtils.isNotEmpty(gameCode)) {
            parameterMap.put("gameCode", gameCode);
        }
    }

    @Override
    public List<SuperWinEntity> getSuperWins(String productId, String beginTime, String endTime, Integer realMulti, Integer realAmount, Integer sportMulti, Integer sportAmount,
                                             Integer lotteryMulti, Integer lotteryAmount, Integer slotMulti, Integer slotAmount, Integer fishMulti, Integer fishAmount, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException {
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkBeginTime(beginTime);
        ParamCheckUtil.checkEndTime(endTime);
        ParamCheckUtil.checkPageSize(pageSize);

        Map<String, Object> parameterMap = buildSuperWinsParam(productId, beginTime, endTime, pageSize, key);
        List<SuperWinEntity> superWinEntityList = new ArrayList<>();
        if (realMulti != null || realAmount != null){
            addGameKindParams(parameterMap, realMulti, realAmount, 3);
            log.info("getSuperWins realType parameter:" + JacksonUtil.toJSon(parameterMap));
            List<SuperWinEntity> realSuperWinEntityList = orderDao.getSuperWins(parameterMap);
            superWinEntityList.addAll(realSuperWinEntityList);
        }
        if (sportMulti != null || sportAmount != null){
            addGameKindParams(parameterMap, sportMulti, sportAmount, 1);
            log.info("getSuperWins sportType parameter:" + JacksonUtil.toJSon(parameterMap));
            List<SuperWinEntity> sportSuperWinEntityList = orderDao.getSuperWins(parameterMap);
            superWinEntityList.addAll(sportSuperWinEntityList);
        }
        if (lotteryMulti != null || lotteryAmount != null){
            addGameKindParams(parameterMap, lotteryMulti, lotteryAmount, 12);
            log.info("getSuperWins lotteryType parameter:" + JacksonUtil.toJSon(parameterMap));
            List<SuperWinEntity> lotterySuperWinEntityList = orderDao.getSuperWins(parameterMap);
            superWinEntityList.addAll(lotterySuperWinEntityList);
        }
        if (slotMulti != null || slotAmount != null){
            addGameKindParams(parameterMap, slotMulti, slotAmount, 5);
            log.info("getSuperWins slotType parameter:" + JacksonUtil.toJSon(parameterMap));
            List<SuperWinEntity> slotSuperWinEntityList = orderDao.getSuperWins(parameterMap);
            superWinEntityList.addAll(slotSuperWinEntityList);
        }
        if (fishMulti != null || fishAmount != null){
            addGameKindParams(parameterMap, fishMulti, fishAmount, 8);
            log.info("getSuperWins fishType parameter:" + JacksonUtil.toJSon(parameterMap));
            List<SuperWinEntity> fishSuperWinEntityList = orderDao.getSuperWins(parameterMap);
            superWinEntityList.addAll(fishSuperWinEntityList);
        }
        superWinEntityList = superWinEntityList.stream()
                .sorted((a, b) -> DateUtil.parseSecond(b.getBillTime()).compareTo(DateUtil.parseSecond(a.getBillTime())))
                .limit(pageSize)
                .collect(Collectors.toList());
        return superWinEntityList;
    }

    private Map<String, Object> buildSuperWinsParam (String productId, String beginTime, String endTime, Integer pageSize, String key) throws GWKeyErrorException {
        StringBuilder paramStr = new StringBuilder().append(productId);
        paramStr.append(beginTime).append(endTime);
        paramStr.append(pageSize != null ? String.valueOf(pageSize.intValue()) : "");
        paramStr.append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(paramStr.toString()), key);

        Map<String, Object> parameterMap = new HashMap<>();
        parameterMap.put("productId", productId);
        parameterMap.put("tableList", DataCache.getTableMapByPlatFormIds(productId, null));
        parameterMap.put("beginTime", beginTime);
        parameterMap.put("endTime", endTime);
        parameterMap.put("pageSize", pageSize);
        return parameterMap;
    }

    private void addGameKindParams (Map<String, Object> parameterMap, Integer multi, Integer winAmount, Integer gameKind){
        String multiAndWinAmount = "";
        if (multi != null && winAmount != null){
            multiAndWinAmount = " multi >= " + multi + " or cusAmount >= " + winAmount;
        } else if (multi != null){
            multiAndWinAmount = " multi >= " + multi;
        } else if (winAmount != null){
            multiAndWinAmount = " cusAmount >=" + winAmount;
        }
        parameterMap.put("gameKind", gameKind);
        parameterMap.put("multiAndWinAmount", multiAndWinAmount);
    }

    @Override
    public List<TopWinnerEntity> getTopWinners(String productId, String beginTime, String endTime, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException {
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkBeginTime(beginTime);
        ParamCheckUtil.checkEndTime(endTime);
        ParamCheckUtil.checkPageSize(pageSize);

        Map<String, Object> parameterMap = buildTopWinnersParam(productId, beginTime, endTime, pageSize, key);
        log.info("getTopWinners parameter:" + JacksonUtil.toJSon(parameterMap));
        List<TopWinnerEntity> topWinnerEntityList = orderDao.getTopWinners(parameterMap);
        return topWinnerEntityList;
    }

    private Map<String, Object> buildTopWinnersParam (String productId, String beginTime, String endTime, Integer pageSize, String key) throws GWKeyErrorException {
        StringBuilder paramStr = new StringBuilder().append(productId);
        paramStr.append(beginTime).append(endTime);
        paramStr.append(pageSize != null ? String.valueOf(pageSize.intValue()) : "");
        paramStr.append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(paramStr.toString()), key);

        Map<String, Object> parameterMap = new HashMap<>();
        parameterMap.put("productId", productId);
        parameterMap.put("tableList", DataCache.getTableMapByPlatFormIds(productId, null));
        parameterMap.put("beginTime", beginTime);
        parameterMap.put("endTime", endTime);
        parameterMap.put("pageSize", pageSize);
        return parameterMap;
    }

    @Override
    public List<PlayerWinsEntity> getPlayerWins(String productId, String loginName, String beginTime, String endTime, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException {
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkBeginTime(beginTime);
        ParamCheckUtil.checkEndTime(endTime);
        ParamCheckUtil.checkPageSize(pageSize);
        ParamCheckUtil.checkLoginName(loginName);

        Map<String, Object> parameterMap = buildPlayerWinsParam(productId, loginName, beginTime, endTime, pageSize, key);
        log.info("getPlayerWins parameter:" + JacksonUtil.toJSon(parameterMap));
        List<PlayerWinsEntity> PlayerWinsEntityList = orderDao.getPlayerWins(parameterMap);
        return PlayerWinsEntityList;
    }
    private Map<String, Object> buildPlayerWinsParam (String productId, String loginName, String beginTime, String endTime, Integer pageSize, String key) throws GWKeyErrorException {
        StringBuilder paramStr = new StringBuilder().append(productId);
        paramStr.append(loginName == null ? "" : loginName);
        paramStr.append(beginTime).append(endTime);
        paramStr.append(pageSize != null ? String.valueOf(pageSize.intValue()) : "");
        paramStr.append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(paramStr.toString()), key);

        Map<String, Object> parameterMap = new HashMap<>();
        parameterMap.put("productId", productId);
        parameterMap.put("tableList", DataCache.getTableMapByPlatFormIds(productId, null));
        parameterMap.put("loginName", loginName);
        parameterMap.put("beginTime", beginTime);
        parameterMap.put("endTime", endTime);
        parameterMap.put("pageSize", pageSize);
        return parameterMap;
    }

    @Override
    public List<BetRankEntity> getBetRank(String productId, String[] platformId, String[] gameKind, String loginName, String beginTime, String endTime, Integer winListType, Integer minWinLostCount, Integer minBetAmount, String fieldsOrder, Integer pageSize, String key, String currency, BigDecimal minValidAmount) throws GWPersistenceException, GWKeyErrorException {
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkBeginTime(beginTime);
        ParamCheckUtil.checkEndTime(endTime);
        ParamCheckUtil.checkPlatforms(platformId);
        ParamCheckUtil.checkGameKinds(gameKind);
        ParamCheckUtil.checkPageSize(pageSize);
        ParamCheckUtil.checkType(winListType);

        Map<String, Object> parameterMap = buildBetRankParam(productId, platformId, gameKind, loginName, beginTime, endTime, winListType, minWinLostCount, minBetAmount, fieldsOrder, pageSize, key, currency, minValidAmount);
        log.info("getRecordMaxGroupBy parameter:" + JacksonUtil.toJSon(parameterMap));
        List<BetRankEntity> betRankEntityList = orderDao.getBetRank(parameterMap);
        return betRankEntityList;
    }
    //A0602682020-05-20 00:00:002020-05-29 00:00:00150e,b30feas!#%
    //A0602682020-05-20 00:00:002020-05-29 00:00:00105e,b30feas!#%
    private Map<String, Object> buildBetRankParam (String productId, String[] platformId, String[] gameKind, String loginName, String beginTime, String endTime, Integer winListType, Integer minWinLostCount, Integer minBetAmount, String fieldsOrder, Integer pageSize, String key, String currency, BigDecimal minValidAmount) throws GWKeyErrorException {
        StringBuilder paramStr = new StringBuilder().append(productId).append(StringUtils.join(platformId, UtilConstants.COMMA_SYMBOL));
        paramStr.append(loginName == null ? "" : loginName).append(StringUtils.join(gameKind, UtilConstants.COMMA_SYMBOL)).append(beginTime);
        paramStr.append(endTime).append(winListType == null ? "" : winListType.toString()).append(minWinLostCount == null ? "" : minWinLostCount.toString());
        paramStr.append(minBetAmount == null ? "" : String.valueOf(minBetAmount.intValue()));
        paramStr.append(StringUtils.isNotBlank(fieldsOrder) ? fieldsOrder : "").append(pageSize != null ? String.valueOf(pageSize.intValue()) : "");
        paramStr.append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(paramStr.toString()), key);

        Map<String, Object> parameterMap = new HashMap<>();
        parameterMap.put("productId", productId);
        parameterMap.put("tableList", DataCache.getTableMapByPlatFormIds(productId, platformId));
        parameterMap.put("gameKind", gameKind);
        parameterMap.put("loginName", loginName);
        parameterMap.put("beginTime", beginTime);
        parameterMap.put("endTime", endTime);
        parameterMap.put("winListType", winListType);
        parameterMap.put("minWinLostCount", minWinLostCount);
        parameterMap.put("minBetAmount", minBetAmount);
        parameterMap.put("pageSize", pageSize);
        parameterMap.put("currency", currency);
        if (StringUtils.isNotBlank(loginName)){
            if (loginName.endsWith("usdt")){
                parameterMap.put("usdtPlayer", "1");
            } else {
                parameterMap.put("usdtPlayer", "0");
            }
        }
        if (minValidAmount != null){
            parameterMap.put("minBetAmount", minValidAmount);
        }
        String orderStr = "";
        for (String order : fieldsOrder.split(UtilConstants.COMMA_SYMBOL)){
            String column = "";
            if (Objects.equals(order, "a")){
                column = "betAmountSum";
            } else if (Objects.equals(order, "b")){
                column = "validBetAmountSum";
            } else if (Objects.equals(order, "c")){
                column = "remainAmountSum";
            } else if (Objects.equals(order, "d")){
                column = "cusAmountSum";
            } else if (Objects.equals(order, "e")){
                column = "winLostCount";
            } else {
                throw new GWKeyErrorException(ParamCheckUtil.WEBSERVICE_ERROR_FIELD_ORDER);
            }
            if (StringUtils.isBlank(orderStr)){
                orderStr = column + " desc";
            } else {
                orderStr = orderStr + ", " + column + " desc";
            }
        }
        orderStr = orderStr + ", " + "LOGINNAME" + " asc";
        parameterMap.put("orderStr", orderStr);
        return parameterMap;
    }

    @Override
    public QueryResult<OrderEntity> getRecordMax(String productId, String[] platformId, String[] loginName, String[] gameKind, String beginTime, String endTime, String settledType, Integer minBetAmount, Integer minCusAmount, Integer minMultiple, String fieldsOrder, String maxField, String groupField, Integer pageNo, Integer pageSize, String key,String currency) throws GWPersistenceException, GWKeyErrorException {
        Map<String, Object> parameterMap = builderRecordMaxParam(productId, platformId, loginName, gameKind, beginTime, endTime, settledType, minBetAmount, minCusAmount, minMultiple, fieldsOrder, maxField, groupField, pageNo, pageSize, key,currency);
        //返回结果
        log.info("getRecordMaxGroupBy parameter:" + JacksonUtil.toJSon(parameterMap));
        QueryResult<OrderEntity> queryResult = new QueryResult<>();
        List<OrderEntity> orderList = orderDao.getRecordMaxList(parameterMap);
        orderList.parallelStream().forEach(order -> order.setGameType(DataUtil.getGameName(order)));
        queryResult.setQueryResultList(orderList);
        queryResult.setTotalRecords(orderList.size());
        return queryResult;
    }

    private Map<String, Object> builderRecordMaxParam(String productId, String[] platformId, String[] loginName, String[] gameKind, String beginTime, String endTime, String settledType, Integer minBetAmount, Integer minCusAmount, Integer minMultiple, String fieldsOrder, String maxField, String groupField, Integer pageNo, Integer pageSize, String key,String currency) throws GWPersistenceException, GWKeyErrorException {
        //参数校验
        checkRecordParametes(productId, platformId, gameKind, beginTime, endTime, settledType, pageNo, pageSize);
        ParamCheckUtil.checkMaxField(maxField);
        ParamCheckUtil.checkGroupField(groupField);
        String maxLegalFiled = "CUS_ACCOUNT,VALID_ACCOUNT,Multiple";
        String groupLegalFiled = "loginname,game_kind";
        if (maxLegalFiled.split("(?i)" + maxField, 2).length == 1) {
            throw new GWPersistenceException("invalid maxField value,should be one of [" + maxLegalFiled + "]");
        }
        if (groupLegalFiled.split("(?i)" + groupField, 2).length == 1) {
            throw new GWPersistenceException("invalid groupField value,should be one of [" + groupLegalFiled + "]");
        }
        checkRecordMaxKey(productId, platformId, loginName, gameKind, beginTime, endTime, settledType, minBetAmount, minCusAmount, minMultiple, fieldsOrder, maxField, groupField, pageNo, pageSize, key);
        //构造请求参数
        Map<String, Object> parameterMap = putRecordParam(productId, platformId, loginName, gameKind, beginTime, endTime, settledType, minBetAmount, minCusAmount, null,minMultiple, fieldsOrder, pageNo, pageSize, "\\s*(VALID_ACCOUNT|CUS_ACCOUNT|BILLTIME|Multiple)\\s+((?:de|a)sc)\\s*");
        parameterMap.put("currency",currency);
        parameterMap.put("groupField", groupField);
        parameterMap.put("maxField", maxField);
        return parameterMap;
    }

    private void checkRecordMaxKey(String productId, String[] platformId, String[] loginName, String[] gameKind, String beginTime, String endTime, String settledType, Integer minBetAmount, Integer minCusAmount, Integer minMultiple, String fieldsOrder, String maxField, String groupField, Integer pageNo, Integer pageSize, String key) throws GWKeyErrorException {
        StringBuilder paramStr = new StringBuilder().append(productId).append(StringUtils.join(platformId, UtilConstants.COMMA_SYMBOL));
        paramStr.append(loginName == null ? "" : StringUtils.join(loginName, UtilConstants.COMMA_SYMBOL)).append(StringUtils.join(gameKind, UtilConstants.COMMA_SYMBOL)).append(beginTime);
        paramStr.append(endTime).append(StringUtils.isNotBlank(settledType) ? settledType : "").append(minBetAmount == null ? "" : String.valueOf(minBetAmount.intValue()));
        paramStr.append(minCusAmount == null ? "" : String.valueOf(minCusAmount.intValue())).append(minMultiple == null ? "" : String.valueOf(minMultiple.intValue()));
        paramStr.append(StringUtils.isNotBlank(fieldsOrder) ? fieldsOrder : "").append(maxField).append(groupField).append(pageNo != null ? String.valueOf(pageNo.intValue()) : "").append(pageSize != null ? String.valueOf(pageSize.intValue()) : "");
        paramStr.append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(paramStr.toString()), key);
    }


    @Override
    public String[] getRecordMaxSummary(String productId, String[] platformId, String[] loginName, String[] gameKind, String beginTime, String endTime, String settledType, Integer minBetAmount, Integer minCusAmount, Integer minMultiple, String fieldsOrder, String maxField, String groupField, Integer pageNo, Integer pageSize, String key,String currency) throws GWPersistenceException, GWKeyErrorException {
        Map<String, Object> parameterMap = builderRecordMaxParam(productId, platformId, loginName, gameKind, beginTime, endTime, settledType, minBetAmount, minCusAmount, minMultiple, fieldsOrder, maxField, groupField, pageNo, pageSize, key,currency);
        //返回结果
        log.info("getRecordMaxSummary parameter:" + JacksonUtil.toJSon(parameterMap));
        return orderDao.getRecordMaxSummary(parameterMap);
    }

    @Override
    public QueryResult<UserWagerInfo> getFirstBetWinList(String productId, String beginTime, String endTime, Integer type, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException {
        //参数校验
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkBeginTime(beginTime);
        ParamCheckUtil.checkEndTime(endTime);
        ParamCheckUtil.checkPageSize(pageSize);
        ParamCheckUtil.checkPageNo(pageNo);
        //构造请求参数
        Map<String, Object> parameterMap = PageUtil.getParameterMap(pageNo, pageSize);
        StringBuffer sb = new StringBuffer();
        parameterMap.put("productId", productId);
        sb.append(productId);
        parameterMap.put("beginTime", beginTime);
        sb.append(beginTime);
        parameterMap.put("endTime", endTime);
        sb.append(endTime);
        sb.append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(sb.toString()), key);
        parameterMap.put("type", type);//区分是第一次下注还是第一次赢钱 1下注 2赢钱
        boolean isQueryInRange = DataUtil.isInQueryRange(beginTime, endTime);
        if (!isQueryInRange) {
            log.error("getFirstBetWinList not in date range,params:" + parameterMap);
            return null;
        }
        //返回结果
        log.info("getFirstBetWinList parameter:" + JacksonUtil.toJSon(parameterMap));
        QueryResult<UserWagerInfo> queryResult = new QueryResult<>();
        queryResult.setQueryResultList(orderDao.getFirstBetWinList(parameterMap));
        queryResult.setTotalRecords(orderDao.countFirstBetWin(parameterMap));
        return queryResult;
    }

    @Override
    public QueryResult<PokerShoeStatisticEntity> getMaxValueGroupByShoecode(String productId, String platformId, String loginName, String videoId, String shoeCode, String beginTime, String endTime, String orderBy, Integer pageNo, Integer pageSize, String key, String[] gameType,String minBetTimes) throws GWPersistenceException, GWPersistenceException, GWKeyErrorException {
        //参数校验
        ParamCheckUtil.checkPlatformId(platformId);
        String[] gameKinds = {"0"};
        String[] platformIds = {platformId};
        checkRecordParametes(productId, platformIds, gameKinds, beginTime, endTime, "1", pageNo, pageSize);
        //构造请求参数
        Map<String, Object> parameterMap = putMaxValueGroupByShoecodeParam(productId, platformId, loginName, videoId, shoeCode, beginTime, endTime, orderBy, pageNo, pageSize, key, gameType,minBetTimes);
        //返回结果
        log.info("getMaxValueGroupByShoecode parameter:" + JacksonUtil.toJSon(parameterMap));
        QueryResult queryResult = new QueryResult();
        List<PokerShoeStatisticEntity> shoeList = orderDao.getMaxValueGroupByShoecode(parameterMap);
        queryResult.setQueryResultList(shoeList);
        return queryResult;
    }

    private Map<String, Object> putMaxValueGroupByShoecodeParam(String productId, String platformId, String loginName, String videoId, String shoeCode, String beginTime, String endTime, String orderBy, Integer pageNo, Integer pageSize, String key, String[] gameType,String minBetTimes) throws GWKeyErrorException {
        Map<String, Object> parameterMap = PageUtil.getParameterMap(pageNo, pageSize);
        StringBuilder sb = new StringBuilder();
        parameterMap.put("productId", productId);
        sb.append(productId);
        parameterMap.put("platformId", platformId);
        sb.append(platformId);
        if (StringUtils.isNotBlank(loginName)) {
            parameterMap.put("loginName", loginName);
            sb.append(loginName);
        }
        if (StringUtils.isNotBlank(videoId)) {
            parameterMap.put("videoId", videoId);
            sb.append(videoId);
        }
        if (StringUtils.isNotBlank(shoeCode)) {
            parameterMap.put("shoeCode", shoeCode);
            sb.append(shoeCode);
        }
        parameterMap.put("beginTime", beginTime);
        sb.append(beginTime);
        parameterMap.put("endTime", endTime);
        sb.append(endTime);
        parameterMap.put("pageNo", pageNo);
        sb.append(pageNo);
        parameterMap.put("pageSize", pageSize);
        sb.append(pageSize);
        sb.append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(sb.toString()), key);
        parameterMap.put("loginName", loginName);
        parameterMap.put("videoId", videoId);
        parameterMap.put("shoeCode", shoeCode);

        //加一个“最小下注次数”请求参数，如果不传，默认为5，如果传，使用这个参数
        if(StringUtils.isNotBlank(minBetTimes)){
            parameterMap.put("minBetTimes", minBetTimes);
        }else{
            parameterMap.put("minBetTimes", "5");
        }

        StringBuilder orderByStr = putOrderByStr(orderBy, "\\s*(totalAccount|totalValidAccount|totalCusAccount|winTimesRate|winAmountRate)\\s+((?:de|a)sc)\\s*");
        if (StringUtils.isNotBlank(orderByStr.toString())) {
            parameterMap.put("orderByField", orderByStr.toString());
        }
        if (ArrayUtils.isNotEmpty(gameType)) {
            parameterMap.put("gameType", gameType);
        }
        return parameterMap;
    }

    @Override
    public QueryResult<BaGameEntity> getGameResult(String productId, String platformId, String loginName, String videoId, String shoeCode, String beginTime, String endTime, String orderBy, Integer pageNo, Integer pageSize, String key, String[] gameCode) throws GWKeyErrorException, GWPersistenceException {
        //参数校验
        ParamCheckUtil.checkPlatformId(platformId);
        if (StringUtils.isBlank(shoeCode) && StringUtils.isBlank(beginTime) && StringUtils.isBlank(endTime)) {
            throw new GWPersistenceException("shoecode 和 起止时间不能同时为空");
        }
        //构造请求参数
        Map<String, Object> parameterMap = putGameResultParam(productId, platformId, loginName, videoId, shoeCode, beginTime, endTime, orderBy, pageNo, pageSize, key, gameCode);
        //返回结果
        log.info("getGameResult parameter:" + JacksonUtil.toJSon(parameterMap));
        QueryResult queryResult = new QueryResult();
        queryResult.setQueryResultList(orderDao.queryGameResult(parameterMap));
        queryResult.setTotalRecords(orderDao.countGameResult(parameterMap));
        return queryResult;
    }

    private Map<String, Object> putGameResultParam(String productId, String platformId, String loginName, String videoId, String shoeCode, String beginTime, String endTime, String orderBy, Integer pageNo, Integer pageSize, String key, String[] gameCode) throws GWPersistenceException, GWKeyErrorException {
        Map<String, Object> parameterMap = PageUtil.getParameterMap(pageNo, pageSize);
        StringBuilder sb = new StringBuilder();
        if (StringUtils.isNotBlank(productId)) {
            parameterMap.put("productId", productId);
            sb.append(productId);
        }
        parameterMap.put("platformId", platformId);
        sb.append(platformId);
        if (StringUtils.isNotBlank(loginName)) {
            parameterMap.put("loginName", loginName);
            sb.append(loginName);
        }
        if (StringUtils.isNotBlank(videoId)) {
            parameterMap.put("videoId", videoId);
            sb.append(videoId);
        }
        if (StringUtils.isNotBlank(shoeCode)) {
            parameterMap.put("shoeCode", shoeCode);
            sb.append(shoeCode);
        }
        if (StringUtils.isNotBlank(beginTime)) {
            parameterMap.put("beginTime", beginTime);
            sb.append(beginTime);
        }
        if (StringUtils.isNotBlank(endTime)) {
            parameterMap.put("endTime", endTime);
            sb.append(endTime);
        }
        if (pageNo != null) {
            parameterMap.put("pageNo", pageNo);
            sb.append(pageNo);
        }
        if (pageSize != null) {
            parameterMap.put("pageSize", pageSize);
            sb.append(pageSize);
        }
        sb.append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(sb.toString()), key);
        StringBuilder orderByStr = putOrderByStr(orderBy, "\\s*(begintime)\\s+((?:de|a)sc)\\s*");
        if (orderByStr.length() > 0) {
            parameterMap.put("orderBy", orderByStr.toString());
        }
        if (ArrayUtils.isNotEmpty(gameCode)) {
            parameterMap.put("gameCode", gameCode);
        }
        return parameterMap;
    }

    @Override
    public QueryResult<OrderEntity> getAGQJDeskInfos(String productId, String beginTime, String endTime, String limit, String key) throws GWPersistenceException, GWKeyErrorException {
        //参数校验
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkBeginTime(beginTime);
        ParamCheckUtil.checkEndTime(endTime);
        ParamCheckUtil.checkLimit(limit);
        checkAGQJDeskInfosKey(productId, beginTime, endTime, limit, key);
        //构造请求参数
        Map<String, Object> parameterMap = putAGQJDeskInfosParam(productId, beginTime, endTime, limit);
        //返回结果
        log.info("getAGQJDeskInfos parameter:" + JacksonUtil.toJSon(parameterMap));
        QueryResult<OrderEntity> queryResult = new QueryResult<>();
        List<OrderEntity> orderList = orderDao.getAGQJDeskInfos(parameterMap);
        queryResult.setQueryResultList(orderList);
        queryResult.setTotalRecords(orderList.size());
        return queryResult;

    }

    private Map<String, Object> putAGQJDeskInfosParam(String productId, String beginTime, String endTime, String limit) {
        Map<String, Object> parameterMap = new HashMap<>();
        parameterMap.put("productId", productId);
        parameterMap.put("beginTime", beginTime);
        parameterMap.put("endTime", endTime);
        parameterMap.put("limit", limit);
        return parameterMap;
    }

    private void checkAGQJDeskInfosKey(String productId, String beginTime, String endTime, String limit, String key) throws GWKeyErrorException {
        StringBuffer sb = new StringBuffer();
        sb.append(productId);
        sb.append(beginTime);
        sb.append(endTime);
        sb.append(limit);
        sb.append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(sb.toString()), key);
    }

    @Override
    public QueryResult<PopularGame> getMostPopularGameRank(String productId, Integer top, String[] platforms, String gameKind, String beginTime, String endTime, String key) throws GWPersistenceException {
        try {
            //参数校验
            Assert.notNull(productId, "productId is required!");
            Assert.notNull(top, "top is required!");
            Assert.notNull(platforms, "platform is required!");
            Assert.notNull(gameKind, "gameKind is required!");
            Assert.notNull(beginTime, "beginTime is required!");
            Assert.notNull(endTime, "endTime is required!");
            Assert.notNull(key, "key is required!");
            StringBuilder builder = new StringBuilder();
            builder.append(productId)
                    .append(top)
                    .append(StringUtils.join(platforms, ","))
                    .append(gameKind)
                    .append(beginTime)
                    .append(endTime)
                    .append(UtilConstants.SUFFIX);
            ParamCheckUtil.checkKey(Md5Util.MD5Encode(builder.toString()), key);
            //构造请求参数
            Map<String, Object> parameterMap = new HashMap<>();
            parameterMap.put("productId", productId);
            parameterMap.put("top", top);
            parameterMap.put("gameKind", gameKind);
            parameterMap.put("beginTime", beginTime);
            parameterMap.put("endTime", endTime);
            //返回结果
            log.info("getAGQJDeskInfos parameter:" + JacksonUtil.toJSon(parameterMap));
            QueryResult<PopularGame> popularGameQueryResult = new QueryResult<>();
            List<PopularGame> popularGameRank = new ArrayList<>();
            for (String platformId : platforms) {
                String tableName = DataCache.getOrderPlatformCache().get(DataUtil.getPlatform(productId, platformId));
                parameterMap.put("tableName", tableName);
                parameterMap.put("platformId", platformId);
                List<PopularGame> popularGames = orderDao.getMostPopularGameRank(parameterMap);
                popularGames.parallelStream().forEach(game -> {
                    GameTypePlayTypeEntity cache = DataCache.getCacheGameTypeEntity(game.getPlatformId(), game.getGameType());
                    if (Objects.nonNull(cache)) {
                        game.setGameName(cache.getChineseName());
                    }
                });
                popularGameRank.addAll(popularGames);
            }
            popularGameQueryResult.setQueryResultList(popularGameRank);
            popularGameQueryResult.setTotalRecords(popularGameRank.size());
            return popularGameQueryResult;
        } catch (Exception e) {
            log.error("getMostPopularGameRank fail! productId[" + productId + "] top[" + top + "] platforms[" + platforms + "] gameKind[" + gameKind + "] beginTime[" + beginTime + "] endTime[" + endTime + "] key[" + key + "]", e);
        }
        return null;
    }

    @Override
    public QueryResult<BetRecord> getBetRecord(String productId, String platformId, String gameKind, String loginName, String beginTime, String endTime, Integer pageSize, Integer pageNo, String key) throws Exception {
        String format = "productId=%s,platformId=%s,gameKind=%s,loginName=%s,beginTime=%s,endTime=%s,pageSize=%d,pageNo=%d,key=%s";
        log.info(String.format(format, productId, platformId, gameKind, loginName, beginTime, endTime, pageSize, pageNo, key));
        QueryResult<BetRecord> betRecordQueryResult = new QueryResult<>();
        try {
            //参数校验
            Assert.notNull(productId, "productId is required!");
            Assert.notNull(platformId, "platformId is required!");
            Assert.notNull(gameKind, "gameKind is required!");
            Assert.notNull(loginName, "loginName is required!");
            Assert.notNull(beginTime, "beginTime is required!");
            Assert.notNull(endTime, "endTime is required!");
            Assert.notNull(pageSize, "pageSize is required!");
            Assert.notNull(pageNo, "pageNo is required!");
            Assert.notNull(key, "key is required!");
            Date begin = DateUtil.parseSecond(beginTime);
            Date end = DateUtil.parseSecond(endTime);
            Assert.isTrue(begin.before(end), "beginTime must before endTime");
            Assert.isTrue(end.getTime() - begin.getTime() <= 604800000, "Time span mustn't more than 7 days");
            Assert.isTrue(System.currentTimeMillis() - begin.getTime() <= 2592000000L, "beginTime mustn't before 30 days ago");
            StringBuilder builder = new StringBuilder();
            builder.append(productId).append(platformId).append(gameKind).append(loginName).append(beginTime).append(endTime)
                    .append(pageSize).append(pageNo).append(UtilConstants.SUFFIX);
            ParamCheckUtil.checkKey(Md5Util.MD5Encode(builder.toString()), key);
            // Access limit: 200tpm
            long currentTime = System.currentTimeMillis();
            if (currentTime - TIMER_BET_RECORD.get() > 60000) {
                TIMER_BET_RECORD.set(currentTime);
                COUNTER_BET_RECORD.set(0);
            } else {
                log.info("WebService getBetRecord: Server is busy");
                Assert.isTrue(COUNTER_BET_RECORD.incrementAndGet() < ACCESS_LIMIT_BET_RECORD, "Server is busy");
            }
            //构造请求参数
            Map<String, Object> parameterMap = new HashMap<>();
            parameterMap.put("productId", productId);
            parameterMap.put("platformId", platformId);
            parameterMap.put("gameKind", gameKind);
            parameterMap.put("loginName", loginName);
            parameterMap.put("beginTime", beginTime);
            parameterMap.put("endTime", endTime);
            parameterMap.put("pageSize", pageSize);
            parameterMap.put("pageNo", pageNo);
            parameterMap.put("startNo", pageSize * (pageNo - 1));
            parameterMap.put("endNo", pageSize * (pageNo));
            String tableName = DataCache.getOrderPlatformCache().get(DataUtil.getPlatform(productId, platformId));
            parameterMap.put("tableName", tableName);
            //返回结果
            log.info("getBetRecord parameter:" + JacksonUtil.toJSon(parameterMap));
            List<BetRecord> betRecordList = orderDao.getBetRecord(parameterMap);
            betRecordList.parallelStream().forEach(bet -> {
                GameTypePlayTypeEntity cache = DataCache.getCacheGameTypeEntity(platformId, bet.getGametype());
                if (Objects.nonNull(cache)) {
                    bet.setGameName(cache.getChineseName());
                }
            });
            betRecordQueryResult.setQueryResultList(betRecordList);
        } catch (Exception e) {
            log.error("getBetRecord failed", e);
            throw e;
        }
        return betRecordQueryResult;
    }

    @Override
    public QueryResult<GameOrder> getGameOrderByPage(String productId, String platformId, String gameKind, String loginName, String gameType, String gameCode, String beginTime, String endTime, Integer pageSize, Integer pageNo, String orderBy, String key) throws Exception {
        String format = "productId=%s,platformId=%s,gameKind=%s,loginName=%s,gameType=%s,gameCode=%s,beginTime=%s,endTime=%s,pageSize=%d,pageNo=%d,orderBy=%s,key=%s";
        log.info(String.format(format, productId, platformId, gameKind, loginName, gameType, gameCode, beginTime, endTime, pageSize, pageNo, orderBy, key));
        QueryResult<GameOrder> queryResult = new QueryResult<>();
        try {
            //参数校验
            Assert.notNull(platformId, "platformId is required!");
            Assert.notNull(beginTime, "beginTime is required!");
            Assert.notNull(endTime, "endTime is required!");
            Assert.notNull(pageSize, "pageSize is required!");
            Assert.notNull(pageNo, "pageNo is required!");
            Assert.notNull(key, "key is required!");
            StringBuilder builder = new StringBuilder();
            builder.append(productId).append(platformId).append(gameKind).append(loginName).append(gameType).append(gameCode)
                    .append(beginTime).append(endTime).append(pageSize).append(pageNo).append(orderBy).append(UtilConstants.SUFFIX);
            ParamCheckUtil.checkKey(Md5Util.MD5Encode(builder.toString()), key);
            //构造请求参数
            Map<String, Object> parameterMap = new HashMap<>();
            parameterMap.put("productId", productId);
            parameterMap.put("platformId", platformId);
            parameterMap.put("gameKind", gameKind);
            parameterMap.put("loginName", loginName);
            parameterMap.put("gameType", gameType);
            parameterMap.put("gameCode", gameCode);
            parameterMap.put("beginTime", beginTime);
            parameterMap.put("endTime", endTime);
            parameterMap.put("pageSize", pageSize);
            parameterMap.put("pageNo", pageNo);
            parameterMap.put("startNo", pageSize * (pageNo - 1));
            parameterMap.put("endNo", pageSize * (pageNo));
            parameterMap.put("orderBy", orderBy == null || orderBy.equals("") ? "billtime desc" : orderBy);
            String tableName = DataCache.getOrderPlatformCache().get(platformId);
            parameterMap.put("tableName", tableName);
            //返回结果
            log.info("getGameOrderByPage parameter:" + JacksonUtil.toJSon(parameterMap));
            List<GameOrder> betRecord = orderDao.getGameOrderByPage(parameterMap);
            GameOrder gameOrder = orderDao.getGameOrderTotal(parameterMap);
            queryResult.setQueryResultList(betRecord);
            queryResult.setTotalResult(gameOrder);
        } catch (Exception e) {
            log.error("getGameOrderByPage failed", e);
            throw e;
        }
        return queryResult;
    }

    @Override
    public QueryResult<OrderSummary> getOrderSummary(Long updateTime, Integer pageSize, Integer pageNo, String key) throws Exception {
        String format = "updateTime=%d,pageSize=%d,pageNo=%d,key=%s";
        log.info(String.format(format, updateTime, pageSize, pageNo, key));
        QueryResult<OrderSummary> queryResult = new QueryResult<>();
        try {
            //参数校验
            Assert.notNull(updateTime, "updateTime is required!");
            Assert.notNull(pageSize, "pageSize is required!");
            Assert.notNull(pageNo, "pageNo is required!");
            Assert.notNull(key, "key is required!");
            StringBuilder builder = new StringBuilder();
            builder.append(updateTime).append(pageSize).append(pageNo).append(UtilConstants.SUFFIX);
            ParamCheckUtil.checkKey(Md5Util.MD5Encode(builder.toString()), key);
            //构造请求参数
            Map<String, Object> parameterMap = new HashMap<>();
            parameterMap.put("updateTime", DateUtil.formatToSecond(new Date(updateTime)));
            parameterMap.put("pageSize", pageSize);
            parameterMap.put("pageNo", pageNo);
            parameterMap.put("startNo", pageSize * (pageNo - 1));
            parameterMap.put("endNo", pageSize * pageNo);
            //返回结果
            log.info("getOrderSummary parameter:" + JacksonUtil.toJSon(parameterMap));
            List<OrderSummary> orders = orderDao.getOrderSummary(parameterMap);
            OrderSummary summary = orderDao.getOrderSummaryTotal(parameterMap);
            summary.setTimestamp(summary.getLastUpdate() == null ? null : summary.getLastUpdate().getTime());
            queryResult.setQueryResultList(orders);
            queryResult.setTotalResult(summary);
        } catch (Exception e) {
            log.error("getOrderSummary failed", e);
            throw e;
        }
        return queryResult;
    }

    @Override
    public QueryResult<Game> getGames() throws Exception {
        QueryResult<Game> queryResult = new QueryResult<>();
        try {
            List<Game> games = orderDao.getGames();
            queryResult.setQueryResultList(games);
            queryResult.setTotalRecords(games.size());
        } catch (Exception e) {
            log.error("getGames failed", e);
            throw e;
        }
        return queryResult;
    }
    @Override
    public List<GameTypePlayTypeEntity> getGameTypeAndPlayType(Map<String, Object> parameterMap) throws Exception {
       List<GameTypePlayTypeEntity> result = new ArrayList<>();
        try {
            result = orderDao.getGameTypeAndPlayType(parameterMap);
        } catch (Exception e) {
            log.error("getGameTypeAndPlayType failed", e);
            throw e;
        }
        return result;
    }

    @Override
    public QueryResult<GameOrder> getOrderByVideo(String productId, String platformId, String[] loginName, String[] videoId, String beginTime, String endTime, String key) throws Exception {
        String loginNames = StringUtils.join(loginName);
        String videoIds = StringUtils.join(videoId);
        String format = "productId=%s,platformId=%s,loginName=%s,videoId=%s,beginTime=%s,endTime=%s,key=%s";
        log.info(String.format(format, productId, platformId, loginNames, videoIds, beginTime, endTime, key));
        QueryResult<GameOrder> queryResult = new QueryResult<>();
        try {
            //参数校验
            Assert.notNull(platformId, "platformId is required!");
            Assert.notNull(videoId, "videoId is required!");
            Assert.notNull(beginTime, "beginTime is required!");
            Assert.notNull(endTime, "endTime is required!");
            Assert.notNull(key, "key is required!");
            StringBuilder builder = new StringBuilder();
            builder.append(productId).append(platformId).append(loginNames).append(videoIds).append(beginTime).append(endTime).append(UtilConstants.SUFFIX);
            ParamCheckUtil.checkKey(Md5Util.MD5Encode(builder.toString()), key);
            //构造请求参数
            Map<String, Object> paramsMap = new HashMap<>();
            paramsMap.put("productId", productId);
            paramsMap.put("platformId", platformId);
            paramsMap.put("loginName", loginName);
            paramsMap.put("videoId", videoId);
            paramsMap.put("beginTime", beginTime);
            paramsMap.put("endTime", endTime);
            String tableName = DataCache.getOrderPlatformCache().get(platformId);
            paramsMap.put("tableName", tableName);
            //返回结果
            log.info("getOrderByVideo parameter:" + JacksonUtil.toJSon(paramsMap));
            List<GameOrder> orders = orderDao.getOrderByVideo(paramsMap);
            queryResult.setQueryResultList(orders);
        } catch (Exception e) {
            log.error("getOrderByVideo failed", e);
            throw e;
        }
        return queryResult;
    }

    @Override
    public QueryResult<AccountTotalEntity> getValidAmountFromStatisticsByType(String productId, String timeZoneId, String loginNameArray, String beginDate, String endDate, Integer gameKind, Integer type, Integer pageNo, Integer pageSize, String key, String orderByField) throws GWPersistenceException, GWKeyErrorException {
        //参数校验
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkBeginTime(beginDate);
        ParamCheckUtil.checkEndTime(endDate);
        //构造请求参数
        Map<String, Object> parameterMap = PageUtil.getParameterMap(pageNo, pageSize);
        StringBuffer sb = new StringBuffer();
        parameterMap.put("productId", productId);
        sb.append(productId);
        if (StringUtils.isNotBlank(loginNameArray)) {
            parameterMap.put("loginNameList", Arrays.asList(loginNameArray.split(UtilConstants.COMMA_SYMBOL)));
            sb.append(loginNameArray);
        }
        parameterMap.put("beginDate", DataUtil.matchTimeZoneTime(beginDate, DateUtil.UnitePattern_second, timeZoneId));
        sb.append(beginDate);
        parameterMap.put("endDate", DataUtil.matchTimeZoneTime(endDate, DateUtil.UnitePattern_second, timeZoneId));
        sb.append(endDate);
        sb.append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(sb.toString()), key);
        type = type != null ? type : 1;
        parameterMap.put("type", type);
        if (gameKind != null) {
            parameterMap.put("gameKind", gameKind);
        }
        StringBuilder orderByStr = putOrderByStr(orderByField, "\\s*(BETTINGTIMES|TOTALACCOUNT|TOTALVALIDACCOUNT|TOTALCUSACCOUNT|TOTALREMAINAMOUNT|TOTALWONTIMES|TOTALLOSETIMES|TOTALTIETIMES)\\s+((?:de|a)sc)\\s*");
        if (StringUtils.isNotBlank(orderByStr.toString())) {
            parameterMap.put("orderByField", orderByStr.toString());
        }
        parameterMap.put("tableList", DataCache.getTableMap(productId, null));
        //返回结果
        log.info("getValidAmountFromStatisticsByType parameter:" + JacksonUtil.toJSon(parameterMap));
        QueryResult<AccountTotalEntity> queryResult = new QueryResult<>();
        queryResult.setQueryResultList(orderDao.getValidAmountFromStatisticsByType(parameterMap));
        queryResult.setTotalRecords(orderDao.countValidAmountFromStatisticsByType(parameterMap));
        return queryResult;
    }

    @Override
    public QueryResult<AccountTotalEntity> getOrderSummaryGroupByPidUsername(String productId, String[] loginNameArray, String[] excludePlatformArray, String beginDate, String endDate, Integer pageNo, Integer pageSize, String key, String currency) throws GWPersistenceException, GWKeyErrorException {
        //参数校验
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkBeginTime(beginDate);
        ParamCheckUtil.checkEndTime(endDate);
        //构造请求参数
        Map<String, Object> parameterMap = PageUtil.getParameterMap(pageNo, pageSize);
        StringBuffer sb = new StringBuffer();
        parameterMap.put("productId", productId);
        sb.append(productId);
        if (ArrayUtils.isNotEmpty(loginNameArray)) {
            List<String> loginNameList = Arrays.asList(loginNameArray);
            parameterMap.put("loginNameList", loginNameList);
            sb.append(StringUtils.join(loginNameArray, ","));
        }
        if (ArrayUtils.isNotEmpty(excludePlatformArray)) {
            List<String> excludePlatformList = Arrays.asList(excludePlatformArray);
            parameterMap.put("excludePlatformList", excludePlatformList);
        }
        parameterMap.put("beginDate", beginDate);
        sb.append(beginDate);
        parameterMap.put("endDate", endDate);
        sb.append(endDate);
        if (StringUtils.isNotBlank(currency)) {
            parameterMap.put("currency", currency);//添加货币类型
        }
        sb.append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(sb.toString()), key);
        //返回结果
        log.info("getOrderSummaryGroupByPidUsername parameter:" + JacksonUtil.toJSon(parameterMap));
        QueryResult<AccountTotalEntity> queryResult = new QueryResult<>();
        queryResult.setQueryResultList(orderDao.getOrderSummaryGroupByPidUsername(parameterMap));
        queryResult.setTotalRecords(orderDao.countOrderSummaryGroupByPidUsername(parameterMap));
        return queryResult;
    }

    @Override
    public QueryResult<AccountTotalEntity> getOrderSummaryGroupByDay(String productId, String[] loginNameList, String beginDate, String endDate) throws GWPersistenceException, GWKeyErrorException {
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkBeginTime(beginDate);
//        ParamCheckUtil.checkEndTime(endDate);
        ParamCheckUtil.checkLoginNameArray(loginNameList);
        if(!StringUtils.isBlank(endDate)) {
            LocalDate startDay =  LocalDate.parse(beginDate);
            LocalDate endDay = LocalDate.parse(endDate);
            if(endDay.isBefore(startDay)) {
                throw new GWPersistenceException("开始时间必须大于结束时间!");
            }
        }

//        if(endDay.toEpochDay()-startDay.toEpochDay()>7){
//            throw new GWPersistenceException("查询天数不能超过7天!");
//        }
        Map<String, Object> parameterMap = new HashMap<>();
        parameterMap.put("productId",productId);
        parameterMap.put("beginDate",beginDate);
        parameterMap.put("endDate",endDate);
        parameterMap.put("loginNameList",loginNameList);
        log.info("getOrderSummaryGroupByDay parameter:" + JacksonUtil.toJSon(parameterMap));
        QueryResult<AccountTotalEntity> queryResult = new QueryResult<>();
        List<AccountTotalEntity> resultList = orderDao.getOrderSummaryGroupByDay(parameterMap);
        queryResult.setQueryResultList(resultList);
        queryResult.setTotalRecords(resultList==null?0:resultList.size());
        return queryResult;
    }

    public static void main(String[] args) {
        LocalDate startDay =  LocalDate.parse("2020-01-11");
        LocalDate endDay = LocalDate.parse("2020-01-07");
        System.out.println(endDay.toEpochDay()-startDay.toEpochDay());
    }

    /**
     * @Description:
     * @Author: Ziv.Y
     * @Date: 2019/9/26 20:35
     */
    @Override
    public QueryResult<AccountTotalEntity> getOrderSummaryGroupByPidUsername4ActivityList(String productId, String[] platformArray, String[] gameKindArray,String[] gameTypeArray, String beginDate, String endDate,
                                                                                          Long minSumAmount, String currency, Integer rank, String fieldsOrder, String key) throws GWPersistenceException, GWKeyErrorException {
        //参数校验
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkBeginDate(beginDate);
        ParamCheckUtil.checkEndTime(endDate);
        ParamCheckUtil.checkRank(rank);
        ParamCheckUtil.checkCurrency(currency);

        //构造请求参数
        Map<String, Object> parameterMap = new HashMap<>();
        StringBuffer sb = new StringBuffer();
        parameterMap.put("productId", productId);
        sb.append(productId);
        parameterMap.put("beginDate", beginDate);
        sb.append(beginDate);
        parameterMap.put("endDate", endDate);
        sb.append(endDate);
        parameterMap.put("rank", rank);
        sb.append(rank);
        parameterMap.put("currency", currency);
        sb.append(currency);

        sb.append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(sb.toString()), key);
        if(StringUtils.isNotBlank(fieldsOrder)){
            parameterMap.put("fieldsOrder", fieldsOrder.toLowerCase());
        }
        if (ArrayUtils.isNotEmpty(platformArray)) {
            List<String> platformIdList = Arrays.asList(platformArray);
            parameterMap.put("platformIdList", platformIdList);
        }
        if (ArrayUtils.isNotEmpty(gameKindArray)) {
            List<String> gameKindList = Arrays.asList(gameKindArray);
            parameterMap.put("gameKindList", gameKindList);
        }
        if (ArrayUtils.isNotEmpty(gameTypeArray)) {
            List<String> gameTypeList = Arrays.asList(gameTypeArray);
            parameterMap.put("gameTypeList", gameTypeList);
        }
        parameterMap.put("minAmount", minSumAmount);

        //校验时间区间
//        ParamCheckUtil.checkDateRange(beginDate + " 00:00:00", endDate + " 23:59:59");

        //返回结果
        log.info("getOrderSummaryGroupByPidUsername4ActivityList parameter:" + JacksonUtil.toJSon(parameterMap));
        QueryResult<AccountTotalEntity> queryResult = new QueryResult<>();
        queryResult.setQueryResultList(orderDao.getOrderSummaryGroupByPidUsername4ActivityList(parameterMap));
        queryResult.setTotalRecords(queryResult.getQueryResultList() == null ? 0 : queryResult.getQueryResultList().size());
        return queryResult;
    }

    @Override
    public QueryResult<AccountTotalEntity> getOrderSummaryGroupByPidPlatIdUn(String productId, String[] platformArray, String[] loginNameArray, String[] gameKindArray, String beginDate, String endDate, Integer pageNo, Integer pageSize, String key, String currency) throws GWPersistenceException, GWKeyErrorException {
        //参数校验
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkBeginDate(beginDate);
        ParamCheckUtil.checkEndDate(endDate);
        if (beginDate.compareTo(endDate) > 0) {
            throw new GWPersistenceException("beginDate can't later than endDate!");
        }
        //构造请求参数
        Map<String, Object> parameterMap = PageUtil.getParameterMap(pageNo, pageSize);
        StringBuffer sb = new StringBuffer();
        parameterMap.put("productId", productId);
        sb.append(productId);
        if (ArrayUtils.isNotEmpty(platformArray)) {
            List<String> platformList = Arrays.asList(platformArray);
            parameterMap.put("platformList", platformList);
            sb.append(StringUtils.join(platformArray, ","));
        }
        if (ArrayUtils.isNotEmpty(loginNameArray)) {
            List<String> loginNameList = Arrays.asList(loginNameArray);
            parameterMap.put("loginNameList", loginNameList);
            sb.append(StringUtils.join(loginNameArray, ","));
        }
        if (ArrayUtils.isNotEmpty(gameKindArray)) {
            List<String> gameKindList = Arrays.asList(gameKindArray);
            parameterMap.put("gameKindList", gameKindList);
        }
        parameterMap.put("beginDate", beginDate);
        sb.append(beginDate);
        parameterMap.put("endDate", endDate);
        sb.append(endDate);
        sb.append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(sb.toString()), key);
        if (StringUtils.isNotBlank(currency)) {
            parameterMap.put("currency", currency);//添加货币类型
        }
        //返回结果
        log.info("getOrderSummaryGroupByPidPlatIdUn parameter:" + JacksonUtil.toJSon(parameterMap));
        QueryResult<AccountTotalEntity> queryResult = new QueryResult<>();
        queryResult.setQueryResultList(orderDao.getOrderSummaryGroupByPidPlatIdUn(parameterMap));
        queryResult.setTotalRecords(orderDao.countOrderSummaryGroupByPidPlatIdUn(parameterMap));
        return queryResult;
    }

    @Override
    public Map<String,Object> getOrderSummaryGroupByPlatGameUn(GetOrderSummaryGroupByPlatGameUnRequest request) throws GWPersistenceException, GWKeyErrorException {
        //参数校验
        ParamCheckUtil.checkProductId(request.getProductId());
        ParamCheckUtil.checkBeginDate(request.getBeginTime());
        ParamCheckUtil.checkEndDate(request.getEndTime());

        //构造请求参数
        Map<String, Object> parameterMap = PageUtil.getParameterMap(request.getPageNo(), request.getPageSize());
        StringBuffer sb = new StringBuffer();
        parameterMap.put("productId", request.getProductId());
        sb.append( request.getProductId() );
        if (StringUtils.isNotEmpty(request.getPlatformId())) {
            parameterMap.put("platform", request.getPlatformId() );
        }
        if (StringUtils.isNotEmpty(request.getGameKind())) {
            parameterMap.put("gameKind", request.getGameKind() );
        }
        if (StringUtils.isNotEmpty(request.getGameType())) {
            parameterMap.put("gameType", request.getGameType() );
        }
        parameterMap.put("beginTime", request.getBeginTime());
        sb.append(request.getBeginTime());
        parameterMap.put("endTime", request.getEndTime());
        sb.append(request.getEndTime());
        sb.append(UtilConstants.SUFFIX);
        //是否校验key
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(sb.toString()), request.getKey());

        //返回结果
        log.info("--getOrderSummaryGroupByPlatGameUn-param--:" + JacksonUtil.toJSon(parameterMap));
        Map<String,Object> response = new HashMap<>();
        List<GetOrderSummaryGroupByPlatGameUnResponse> list = orderDao.getOrderSummaryGroupByPlatGameUn(parameterMap);
        response.put("datas", list==null?new ArrayList<>() : list );
        GetOrderSummaryGroupByPlatGameUnResponse totalData = orderDao.getOrderSummaryGroupByPlatGameUnTotal(parameterMap);
        totalData = totalData==null? new GetOrderSummaryGroupByPlatGameUnResponse() : totalData;
        totalData.setTotalUserNum( orderDao.getOrderSummaryGroupByPlatGameUnTotalUserNum(parameterMap) );
        response.put("summary", totalData );
        return response;
    }

    @Override
    public QueryResult<AccountTotalEntity> getOrdersSumGroupByLoginName(String productId, String[] loginNameArray, String[] platformArray, String[] gameKindArray, String beginTime, String endTime, Integer pageNo, Integer pageSize) throws GWPersistenceException, GWKeyErrorException {
        //参数校验
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkBeginTime(beginTime);
        ParamCheckUtil.checkEndTime(endTime);
        if (beginTime.compareTo(endTime) > 0) {
            throw new GWPersistenceException("the parameter beginTime can't be more than endTime!");
        }
        //构造请求参数
        beginTime = beginTime.substring(0, 10);
        endTime = endTime.substring(0, 10);
        Map<String, Object> parameterMap = PageUtil.getParameterMap(pageNo, pageSize);
        parameterMap.put("platformArr", platformArray);
        parameterMap.put("gameKindArr", gameKindArray);
        parameterMap.put("loginNameArray", loginNameArray);
        parameterMap.put("productId", productId);
        parameterMap.put("startDate", beginTime);
        parameterMap.put("endDate", endTime);
        //返回结果
        log.info("getOrdersSumGroupByLoginName parameter:" + JacksonUtil.toJSon(parameterMap));
        QueryResult<AccountTotalEntity> queryResult = new QueryResult<>();
        queryResult.setQueryResultList(orderDao.getOrdersSumGroupByLoginName(parameterMap));
        queryResult.setTotalRecords(orderDao.countOrdersSumGroupByLoginName(parameterMap));
        return queryResult;
    }

    @Override
    public String testReadConnection() throws GWPersistenceException {
        return orderDao.testReadConnection();
    }

    @Override
    public String testWriteConnection() throws GWPersistenceException {
        return orderDao.testWriteConnection();
    }

    @Override
    public QueryResult<MGAndTTGAbnormalEntity> getMGAndTTGAbnormalData(String loginName, String productId, String beginDate, String endDate, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException {
        //参数校验
        ParamCheckUtil.checkLoginName(loginName);
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkBeginDate(beginDate);
        ParamCheckUtil.checkEndDate(endDate);
        //构造请求参数
        Map<String, Object> parameterMap = PageUtil.getParameterMap(pageNo, pageSize);
        parameterMap.put("loginName", loginName);
        parameterMap.put("productId", productId);
        StringBuffer sb = new StringBuffer();
        sb.append(loginName);
        sb.append(productId);
        if (StringUtils.isNotBlank(beginDate)) {
            if (beginDate.length() == 10) {
                parameterMap.put("beginDate", beginDate + UtilConstants.PREFIX_TIME_STRING);
                sb.append(beginDate);
            } else {
                parameterMap.put("beginDate", beginDate);
                sb.append(beginDate);
            }
        }
        if (StringUtils.isNotBlank(endDate)) {
            if (endDate.length() == 10) {
                parameterMap.put("endDate", endDate + UtilConstants.SUFFIX_TIME_STRING);
                sb.append(endDate);
            } else {
                parameterMap.put("endDate", endDate);
                sb.append(endDate);
            }
        }
        sb.append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(sb.toString()), key);
        //返回结果
        log.info("getMGAndTTGAbnormalData parameter:" + JacksonUtil.toJSon(parameterMap));
        QueryResult<MGAndTTGAbnormalEntity> queryResult = new QueryResult<>();
        queryResult.setQueryResultList(orderDao.getMGAndTTGAbnormalData(parameterMap));
        return queryResult;
    }

    @Override
    public List<AccountTotalEntity> getOrdersRemainGroupList(String productId, String[] loginNameArray, List<PlatformGamekind> platformAndGameKindList, String beginTime, String endTime) throws GWPersistenceException, GWKeyErrorException {
        //参数校验
        log.info("Call OrderDaoImpl.getOrderTypesBonusResult() begin - productId=" + productId + ",loginNameArray=" + loginNameArray + ",beginTime="
                + beginTime + ",endTime=" + endTime + ",platformAndGameKindList=" + platformAndGameKindList);
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkLoginNameArray(loginNameArray);
        if (platformAndGameKindList == null || platformAndGameKindList.size() == 0) {
            throw new GWPersistenceException("the parameter At least one of platformAndGameKindList cannot be empty!");
        }
        ParamCheckUtil.checkBeginTime(beginTime);
        ParamCheckUtil.checkBeginDate(endTime);
        if (DateUtil.parseSecond(beginTime).getTime() > DateUtil.parseSecond(endTime).getTime()) {
            throw new GWPersistenceException("the parameter beginTime can't be more than endTime!");
        }


        List<Map<String, Object>> tableMapList = new ArrayList<>();
        /**
         * queryType=A按照platformid进行分组查询
         */
        Map<String, Object> map = new HashMap<>();
        if (platformAndGameKindList != null && platformAndGameKindList.size() > 0) {
            for (PlatformGamekind platKind : platformAndGameKindList) {
                Map<String, Object> itemMap = new HashMap<>();
                String platformId = DataUtil.getPlatform(productId, platKind.getPlatform());
                String tableName = DataCache.getOrderPlatformCache().get(platformId);
                if (StringUtils.isBlank(tableName)) {
                    throw new GWPersistenceException("platformId can't find table:" + platKind.getPlatform());
                }
                itemMap.put("platformId", platformId);
                itemMap.put("tableName", tableName);
                itemMap.put("gameKindArr", (platKind.getGameKind()).split(","));
                tableMapList.add(itemMap);
            }
        }
        map.put("tableMapList", tableMapList);
        map.put("loginNameArray", loginNameArray);
        map.put("productId", productId);
        map.put("startTime", beginTime);
        map.put("endTime", endTime);
        return orderDao.getOrderRemainGroupList(map);
    }

    @Override
    public List<OrderAGQJExceptionor> getOrdersAGQJExceptionor(String productId, String loginName, String beginTime, String endTime, String key) throws GWPersistenceException, GWKeyErrorException {
        //参数校验
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkLoginName(loginName);
        ParamCheckUtil.checkBeginTime(beginTime);
        ParamCheckUtil.checkEndTime(endTime);
        //构造请求参数
        Map<String, Object> parameterMap = new HashMap<>();
        parameterMap.put("productId", productId);
        parameterMap.put("loginName", loginName);
        parameterMap.put("beginTime", beginTime);
        parameterMap.put("endTime", endTime);
        StringBuffer sb = new StringBuffer();
        sb.append(productId);
        sb.append(loginName);
        sb.append(beginTime);
        sb.append(endTime);
        sb.append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(sb.toString()), key);
        //返回结果
        log.info("getOrdersAGQJExceptionor parameter:" + JacksonUtil.toJSon(parameterMap));
        return orderDao.getOrdersAGQJExceptionor(parameterMap);
    }

    @Override
    public QueryResult<String> getCustomerByPlatformAndGameKind(String productId, PlatformGameKinds[] platform, String beginTime,
                                                                String endTime, String key) throws Exception {
        //参数校验
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkPlatformGameKinds(platform);
        ParamCheckUtil.checkBeginTime(beginTime);
        ParamCheckUtil.checkEndTime(endTime);
        if (beginTime.compareTo(endTime) > 0) {
            throw new GWPersistenceException("the parameter beginTime can't be more than endTime!");
        }

        StringBuffer sb = new StringBuffer();
        sb.append(productId).append(beginTime).append(endTime).append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(sb.toString()), key);

        Map<String, Object> paramsMap = new HashMap<>();
        paramsMap.put("productId", productId);
        paramsMap.put("beginTime", beginTime);
        paramsMap.put("endTime", endTime);
        ConditionMap tabMap = new ConditionMap();
        for (PlatformGameKinds platformGameKinds :platform) {
            String platformId = DataUtil.getPlatform(productId, platformGameKinds.getPlatformId());
            String tableName = DataCache.getOrderPlatformCache().get(platformId);
            tabMap.put(platformId, tableName, platformGameKinds.getGameKinds());
        }
        paramsMap.put("tableList", tabMap);
        log.info("getCustomerByPlatformAndGameKind parameter:" + JacksonUtil.toJSon(paramsMap));

        List<String> customers = orderDao.getCustomerByPlatformAndGameKind(paramsMap);
        QueryResult<String> queryResult = new QueryResult<>();
        queryResult.setQueryResultList(customers);
        queryResult.setTotalRecords(customers.size());
        return queryResult;
    }

    public List<AttendancePromoEntity> getAttendancePromoList(String productId, String platformId, String loginNameArray, String beginTime,
                                                              String endTime, Integer pageNo, Integer pageSize, String key) throws GWPersistenceException, GWKeyErrorException {
        Map<String, Object> parameterMap = PageUtil.getParameterMap(pageNo, pageSize);
        StringBuffer sb = new StringBuffer();
        List<String> loginNameList = new ArrayList<String>();
        if (loginNameArray != null) {
            String[] array = loginNameArray.split(UtilConstants.COMMA_SYMBOL);
            for (String name : array) {
                loginNameList.add(name);
            }
        }
        if (!StringUtils.isBlank(productId)) {
            parameterMap.put("productId", productId);
            sb.append(productId);
        }
        if (!StringUtils.isBlank(platformId)) {
            parameterMap.put("platformId", platformId);
            sb.append(platformId);
        }
        if (!StringUtils.isBlank(loginNameArray)) {
            parameterMap.put("loginNameList", loginNameList);
            sb.append(loginNameArray);
        }
        if (!StringUtils.isBlank(beginTime)) {
            parameterMap.put("beginTime", beginTime);
            sb.append(beginTime);
        }
        if (!StringUtils.isBlank(endTime)) {
            parameterMap.put("endTime", endTime);
            sb.append(endTime);
        }
        sb.append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(sb.toString()), key);

        return this.orderDao.getAttendancePromoList(parameterMap);
    }

    @Override
    public QueryResult<OrderEntity> getHighProfitOrderListByDeviceType(
            String productId,String[] platformId, String[] gameKind, String beginTime,
            String endTime,Integer validAmount, Integer cusAmount, Integer multiple,
            Integer pageNo, Integer pageSize, String key, Integer deviceType) throws GWPersistenceException, GWKeyErrorException {

        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkBeginTime(beginTime);
        ParamCheckUtil.checkEndTime(endTime);
        ParamCheckUtil.checkValidAmount(validAmount);
        ParamCheckUtil.checkCusAmount(cusAmount);
        ParamCheckUtil.checkMultiple(multiple);
        Map<String, Object> parameterMap = PageUtil.getParameterMap(pageNo, pageSize);

        StringBuffer sb = new StringBuffer();
        sb.append(productId).append(beginTime).append(endTime).append(validAmount).append(cusAmount).append(multiple)
                .append(pageNo).append(pageSize).append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(sb.toString()), key);

        parameterMap.put("tableList", DataCache.getTableMapByPlatFormIds(productId, platformId));
        parameterMap.put("beginTime", beginTime);
        parameterMap.put("endTime", endTime);
        parameterMap.put("productId", productId);
        parameterMap.put("validAmount", validAmount);
        parameterMap.put("cusAmount", cusAmount);
        parameterMap.put("gameKind", gameKind);
        parameterMap.put("multiple", multiple);
        parameterMap.put("deviceType", deviceType);
        return orderDao.getHighProfitOrderListByDeviceType(parameterMap);
    }

    @Override
    public List<CustomerDynamicEntity> getCustomerDynamic(String productId, String beginTime, String endTime, BigDecimal betMin, BigDecimal winMin,
                                                          Integer size,String currency,String key) throws GWPersistenceException, GWKeyErrorException {
        //参数校验
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkBeginTime(beginTime);
        ParamCheckUtil.checkEndTime(endTime);
        ParamCheckUtil.checkBetMin(betMin);
        ParamCheckUtil.checkWinMin(winMin);
//        ParamCheckUtil.checkSize(size);
        StringBuffer sb = new StringBuffer();
        sb.append(productId).append(beginTime).append(endTime).append(betMin).append(winMin);
        if (size!=null) {
            sb.append(size);
        }
        sb.append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(sb.toString()), key);

        //构造请求参数
        Map<String, Object> parameterMap = new HashMap<>();
        parameterMap.put("productId", productId);
        parameterMap.put("beginTime", beginTime);
        parameterMap.put("endTime", endTime);
        parameterMap.put("betMin", betMin);
        parameterMap.put("winMin", winMin);
        parameterMap.put("size", size);
        parameterMap.put("currency",currency);
        parameterMap.put("tableList", DataCache.getTableMap(productId, null));
        //返回结果
        log.info("queryCustomerDynamic parameter:" + JacksonUtil.toJSon(parameterMap));
        return orderDao.getCustomerDynamic(parameterMap);
    }

    @Override
    public QueryResult<AccountTotalEntity> getWagerSummary(String productId, String[] platformId, String[] gameKind, String[] loginName, String minBet, String beginTime, String endTime, Integer pageNo, Integer pageSize, String key)
            throws GWPersistenceException,GWKeyErrorException {
        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkBeginTime(beginTime);
        ParamCheckUtil.checkEndTime(endTime);
        Map<String, Object> parameterMap = PageUtil.getParameterMap(pageNo, pageSize);
        StringBuffer sb = new StringBuffer();
        if (!StringUtils.isBlank(productId)) {
            parameterMap.put("productId", productId);
            sb.append(productId);
        }
        if (!StringUtils.isBlank(minBet)) {
            parameterMap.put("validAccount", minBet);
            sb.append(minBet);
        }
        if (null!=loginName) {
            parameterMap.put("loginNameList", loginName);
        }
        if (null!=gameKind) {
            parameterMap.put("gameKindList", gameKind);
        }
        if (!StringUtils.isBlank(beginTime)) {
            parameterMap.put("beginTime", beginTime);
            sb.append(beginTime);
        }
        if (!StringUtils.isBlank(endTime)) {
            parameterMap.put("endTime", endTime);
            sb.append(endTime);
        }

        sb.append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(sb.toString()), key);
        parameterMap.put("tableList", DataCache.getTableMapByPlatFormIds(productId, null));
        boolean isQueryInRange=DataUtil.isInQueryRange(beginTime, endTime);
        if(!isQueryInRange){
            log.error("getWagerSummary not in date range,params:"+parameterMap);
            return null;
        }
        return this.orderDao.getWagerSummary(parameterMap);
    }

    @Override
    public QueryResult<OrderEntity> getEligibilityOrder(String productId, String[] platformId, String[] gameKind, String[] loginNames, Integer minBetAmount, String queryType, String key,String beginTime, String endTime, Integer pageNo, Integer pageSize) throws GWPersistenceException, GWKeyErrorException {

        ParamCheckUtil.checkProductId(productId);
        ParamCheckUtil.checkBeginTime(beginTime);
        ParamCheckUtil.checkEndTime(endTime);
        ParamCheckUtil.checkBetMin(new BigDecimal(minBetAmount));
        ParamCheckUtil.checkQueryType(queryType);
        ParamCheckUtil.checkPageNo(pageNo);
        ParamCheckUtil.checkPageSize(pageSize);

        Map<String, Object> parameterMap = PageUtil.getParameterMap(pageNo, pageSize);

        StringBuffer sb = new StringBuffer();
        sb.append(productId).append(queryType).append(beginTime).append(endTime).append(UtilConstants.SUFFIX);
        ParamCheckUtil.checkKey(Md5Util.MD5Encode(sb.toString()), key);

        if(StringUtils.isNotBlank(productId)){
            parameterMap.put("productId",productId);
        }

        if(platformId != null){
            parameterMap.put("platformId",platformId);
        }

        if(gameKind != null){
            parameterMap.put("gameKind",gameKind);
        }

        if(loginNames != null){
            parameterMap.put("loginNames",loginNames);
        }

        if(minBetAmount != null){
            parameterMap.put("minBetAmount",minBetAmount);
        }

        if(StringUtils.isNotBlank(beginTime)){
            parameterMap.put("beginTime",beginTime);
        }

        if(StringUtils.isNotBlank(endTime)){
            parameterMap.put("endTime",endTime);
        }

        if(queryType.equals("1")){
            parameterMap.put("ruleSql"," regexp_like(BILLNO, '\\d+([8])\\1{2,5}$')");
        }else{
            parameterMap.put("ruleSql"," regexp_like(BILLNO, '\\d{3}(2019){1,}')");
        }

        return this.orderDao.getEligibilityOrder(parameterMap);
    }
}
