package com.gw.datacenter.vo.activity;

import java.math.BigDecimal;
import java.util.Date;

public class ActivityEntity {
	//ID
	private String id;
    //PRODUCT_ID
	private String productId;
    //PLATFORM_ID
	private String platformId;
    //LOGINNAME
	private String loginName;
    //BILLNO
	private String billNo;
    //ACCOUNT
	private BigDecimal betAmount;
    //VALID_ACCOUNT
	private BigDecimal validBetAmount;
    //CUS_ACCOUNT
	private BigDecimal customerProfit;
    //CUS_ACCOUNT_TOTAL
	private BigDecimal customerProfitTotal;
    //WIN_SEQUENCE
	private Integer winSequence;
    //WIN_FLAG
	private Integer winFlag;
    //GMCODE
	private String gameCode;
    //GAMETYPE
	private String gameType;
    //PLAYTYPE
	private String playType;
    //BILLTIME
	private Date billTime;
    //RECKONTIME
	private Date reckonTime;
    //AGCODE
	private String agentCode;
    //TABLECODE
	private String tableCode;
    //CUR_IP
	private String currentIp;
    //PREVIOS_AMOUNT
	private BigDecimal previousAmount;
    //CREATION_TIME
	private Date creationTime;
	
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}
	/**
	 * @param productId the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}
	/**
	 * @return the platformId
	 */
	public String getPlatformId() {
		return platformId;
	}
	/**
	 * @param platformId the platformId to set
	 */
	public void setPlatformId(String platformId) {
		this.platformId = platformId;
	}
	/**
	 * @return the loginName
	 */
	public String getLoginName() {
		return loginName;
	}
	/**
	 * @param loginName the loginName to set
	 */
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	/**
	 * @return the billNo
	 */
	public String getBillNo() {
		return billNo;
	}
	/**
	 * @param billNo the billNo to set
	 */
	public void setBillNo(String billNo) {
		this.billNo = billNo;
	}
	/**
	 * @return the betAmount
	 */
	public BigDecimal getBetAmount() {
		return betAmount;
	}
	/**
	 * @param betAmount the betAmount to set
	 */
	public void setBetAmount(BigDecimal betAmount) {
		this.betAmount = betAmount;
	}
	/**
	 * @return the validBetAmount
	 */
	public BigDecimal getValidBetAmount() {
		return validBetAmount;
	}
	/**
	 * @param validBetAmount the validBetAmount to set
	 */
	public void setValidBetAmount(BigDecimal validBetAmount) {
		this.validBetAmount = validBetAmount;
	}
	/**
	 * @return the customerProfit
	 */
	public BigDecimal getCustomerProfit() {
		return customerProfit;
	}
	/**
	 * @param customerProfit the customerProfit to set
	 */
	public void setCustomerProfit(BigDecimal customerProfit) {
		this.customerProfit = customerProfit;
	}
	/**
	 * @return the customerProfitTotal
	 */
	public BigDecimal getCustomerProfitTotal() {
		return customerProfitTotal;
	}
	/**
	 * @param customerProfitTotal the customerProfitTotal to set
	 */
	public void setCustomerProfitTotal(BigDecimal customerProfitTotal) {
		this.customerProfitTotal = customerProfitTotal;
	}
	/**
	 * @return the winSequence
	 */
	public Integer getWinSequence() {
		return winSequence;
	}
	/**
	 * @param winSequence the winSequence to set
	 */
	public void setWinSequence(Integer winSequence) {
		this.winSequence = winSequence;
	}
	/**
	 * @return the winFlag
	 */
	public Integer getWinFlag() {
		return winFlag;
	}
	/**
	 * @param winFlag the winFlag to set
	 */
	public void setWinFlag(Integer winFlag) {
		this.winFlag = winFlag;
	}
	/**
	 * @return the gameCode
	 */
	public String getGameCode() {
		return gameCode;
	}
	/**
	 * @param gameCode the gameCode to set
	 */
	public void setGameCode(String gameCode) {
		this.gameCode = gameCode;
	}
	/**
	 * @return the gameType
	 */
	public String getGameType() {
		return gameType;
	}
	/**
	 * @param gameType the gameType to set
	 */
	public void setGameType(String gameType) {
		this.gameType = gameType;
	}
	/**
	 * @return the playType
	 */
	public String getPlayType() {
		return playType;
	}
	/**
	 * @param playType the playType to set
	 */
	public void setPlayType(String playType) {
		this.playType = playType;
	}
	/**
	 * @return the billTime
	 */
	public Date getBillTime() {
		return billTime;
	}
	/**
	 * @param billTime the billTime to set
	 */
	public void setBillTime(Date billTime) {
		this.billTime = billTime;
	}
	/**
	 * @return the reckonTime
	 */
	public Date getReckonTime() {
		return reckonTime;
	}
	/**
	 * @param reckonTime the reckonTime to set
	 */
	public void setReckonTime(Date reckonTime) {
		this.reckonTime = reckonTime;
	}
	/**
	 * @return the agentCode
	 */
	public String getAgentCode() {
		return agentCode;
	}
	/**
	 * @param agentCode the agentCode to set
	 */
	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}
	/**
	 * @return the tableCode
	 */
	public String getTableCode() {
		return tableCode;
	}
	/**
	 * @param tableCode the tableCode to set
	 */
	public void setTableCode(String tableCode) {
		this.tableCode = tableCode;
	}
	/**
	 * @return the currentIp
	 */
	public String getCurrentIp() {
		return currentIp;
	}
	/**
	 * @param currentIp the currentIp to set
	 */
	public void setCurrentIp(String currentIp) {
		this.currentIp = currentIp;
	}
	/**
	 * @return the previousAmount
	 */
	public BigDecimal getPreviousAmount() {
		return previousAmount;
	}
	/**
	 * @param previousAmount the previousAmount to set
	 */
	public void setPreviousAmount(BigDecimal previousAmount) {
		this.previousAmount = previousAmount;
	}
	/**
	 * @return the creationTime
	 */
	public Date getCreationTime() {
		return creationTime;
	}
	/**
	 * @param creationTime the creationTime to set
	 */
	public void setCreationTime(Date creationTime) {
		this.creationTime = creationTime;
	}
	
}
