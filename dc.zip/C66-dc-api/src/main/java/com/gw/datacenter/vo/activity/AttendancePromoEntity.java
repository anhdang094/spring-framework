package com.gw.datacenter.vo.activity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class AttendancePromoEntity implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String loginname;
	private Date beginTime;
	private Date endTime;
	private String productId;
	private String platformId;
	private BigDecimal betAmount;
	private BigDecimal validBetamount;
	private BigDecimal netAmount;
	private Date creationTime;
	private String type;
	private String remarks;
	
	public String getLoginname() {
		return loginname;
	}
	public void setLoginname(String loginname) {
		this.loginname = loginname;
	}
	public Date getBeginTime() {
		return beginTime;
	}
	public void setBeginTime(Date beginTime) {
		this.beginTime = beginTime;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getPlatformId() {
		return platformId;
	}
	public void setPlatformId(String platformId) {
		this.platformId = platformId;
	}
	public BigDecimal getBetAmount() {
		return betAmount;
	}
	public void setBetAmount(BigDecimal betAmount) {
		this.betAmount = betAmount;
	}
	public BigDecimal getValidBetamount() {
		return validBetamount;
	}
	public void setValidBetamount(BigDecimal validBetamount) {
		this.validBetamount = validBetamount;
	}
	public BigDecimal getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(BigDecimal netAmount) {
		this.netAmount = netAmount;
	}
	public Date getCreationTime() {
		return creationTime;
	}
	public void setCreationTime(Date creationTime) {
		this.creationTime = creationTime;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
}