package com.gw.datacenter.vo.dictionary;

import lombok.Data;

import java.io.Serializable;

/**
 * 数据字典对象
 * @author Sanco
 * @Date May 28, 2014 10:34:33 AM
 * 
 */
@Data
public class DictionaryEntity implements Serializable {
	
	private int id;
	private Integer dictId=null;
	/**
	 * 数据类型
	 */
	private Integer dictType=null;
	/**
	 * 数据名称
	 */
	private String dictName;
	/**
	 * 数据中文值
	 */
	private String dictValueZH="";
	/**
	 * 数据英文值
	 */
	private String dictValueEN="";
	/**
	 * 数据描述
	 */
	private String dictDesc="";

	@Override
	public String toString() {
		return id+"\t"+dictId+"\t"+dictType+"\t"+dictName+"\t"+dictValueZH+"\t"+ dictValueEN+"\t"+
		dictDesc+"\t";
	}

}
