package com.gw.datacenter.vo.gameresult;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class BaGameEntity implements Serializable {

	/**
	 * @author alex.l
	 *
	 */
	private static final long serialVersionUID = -416914006769689740L;
	//GMCODE
	private String gmCode;
	//TABLECODE
	private String tableCode;
	//BEGINTIME
	private Date beginTime;
	//CLOSETIME
	private Date closeTime;
	//DEALER
	private String dealer;
	//SHOECODE
	private String shoeCode;
	//FLAG
	private Integer flag;
	//BANKERPOINT
	private String bankerPoint;
	//PLAYERPOINT
	private String playerPoint;
	//CARDNUM
	private Integer cardNum;
	//PAIR
	private Integer pair;
	//GAMETYPE
	private String gameType;
	//DRAGONPOINT
	private String dragonPoint;
	//TIGERPOINT
	private String tigerPoint;
	//CARDLIST
	private String cardList;
	//VID
	private String videoId;
	//PLATID
	private String platId;
	//PRODUCT_ID
	private String productId;
	//ORIGNAL_BEGINTIME
	private Date orignalBeginTime;
	//ORIGNAL_CLOSETIME
	private Date orignalCloseTime;
	//CREATION_TIME 记录产生时间
	private Date creationDate;
	//LOGINNAME 登陆名称
	private String loginName;
	//ROULETTE_COLOR
	private Integer rouletteColor;
	
}
