package com.gw.datacenter.vo.gameresult;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;

@Data
public class PokerShoeStatisticEntity implements Serializable {

    private static final long serialVersionUID = 8547008366914327881L;

    //SHOECODE 靴号
    private String shoeCode;
    //VID 视频ID
    private String videoId;
    //beginTime 每靴开始时间
    private Date beginTime;
    //endTime 每靴结束时间
    private Date endTime;
    //CUS_ACCOUNT 每靴客户输赢总额
    private BigDecimal totalCusAccount;
    //ACCOUNT 每靴投注总额
    private BigDecimal totalAccount;
    //VALID_ACCOUNT 每靴有效投注总额
    private BigDecimal totalValidAccount;
    //每靴投注记录数

    private Integer totalBetting;
    //杀率
    private BigDecimal rate;

    //平台
    private String platFormId;

    //For CMS
    private int color;

    //胜率
    private BigDecimal winTimesRate;

    //盈利率
    private BigDecimal winAmountRate;

    /**
     * @return the totalCusAccount
     */
    public BigDecimal getTotalCusAccount() {
        return formatNumberPrecision(totalCusAccount, null, null);
    }

    /**
     * @return the totalAccount
     */
    public BigDecimal getTotalAccount() {
        return formatNumberPrecision(totalAccount, null, null);
    }

    /**
     * @return the totalValidAccount
     */
    public BigDecimal getTotalValidAccount() {
        return formatNumberPrecision(totalValidAccount, null, null);
    }

    /**
     * @return the rate
     */
    public BigDecimal getRate() {
        if (BigDecimal.ZERO.compareTo(totalValidAccount) == 0)
            return totalValidAccount;
        return this.totalCusAccount.divide(this.totalValidAccount, 4, RoundingMode.HALF_UP);
    }

    /**
     * Format number precision
     *
     * @param target
     * @param scale
     * @param roundingMode
     * @return BigDecimal
     */
    private static BigDecimal formatNumberPrecision(BigDecimal target, Integer scale, RoundingMode roundingMode) {
        if (target != null) {
            if (scale == null) {
                scale = Integer.valueOf(6);
            }
            if (roundingMode == null) {
                roundingMode = RoundingMode.DOWN;
            }
            return target.setScale(scale, roundingMode);
        } else {
            return null;
        }
    }
}
