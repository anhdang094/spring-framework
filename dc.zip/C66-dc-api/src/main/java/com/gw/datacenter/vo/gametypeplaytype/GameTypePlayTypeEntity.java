package com.gw.datacenter.vo.gametypeplaytype;

import lombok.Data;
import org.apache.commons.lang3.StringUtils;


import java.io.Serializable;

@Data
public class GameTypePlayTypeEntity implements Serializable {

    private int id;
    private String platformId;
    private String platformName;
    private String gameType;
    private String gameTypeName;
    private String playType;
    private String chineseName;
    private String englishName;
    private String gameKind;
    private String gameKindName;
    private int type;
    private String creationTime;
    private String createBy;
    private String updateTime;
    private String updateBy;

    public GameTypePlayTypeEntity() {
    }

    public GameTypePlayTypeEntity(int id, String platformId, String gameType, String playType, String chineseName, String englishName, int type) {
        this.id = id;
        this.platformId = platformId;
        this.gameType = gameType;
        this.chineseName = chineseName;
        this.playType = playType;
        this.englishName = englishName;
        this.type = type;
    }

    public boolean checkFieldsForInsertUpdate() {
        if (type == 1) {
            return StringUtils.isNotBlank(platformId) && StringUtils.isNotBlank(gameType) && StringUtils.isNotBlank(gameKind);
        } else if (type == 2) {
            return StringUtils.isNotBlank(platformId) && StringUtils.isNotBlank(playType) && StringUtils.isNotBlank(gameKind);
        } else {
            return false;
        }
    }
}
