
package com.gw.datacenter.vo.order;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;

@Data
public class AccountTotalEntity implements Serializable{

	private static final long serialVersionUID = 5995727610801808588L;

	//统计时间 add by ziv 2018-05-10
	private String statDate;
	//LOGINNAME 客户名称
	private String loginName;
	//产品id add by ziv 2018-05-10
	private String productId;
	//CUS_ACCOUNT 客户输赢总额度
	private BigDecimal totalCusAccount;
	//ACCOUNT 投注总额
	private BigDecimal totalAccount;
	//VALID_ACCOUNT  有效投注总额
	private BigDecimal totalValidAccount;
	//REMAIN_AMOUNT  总返水投注额
	private BigDecimal totalRemainAmount;
	private BigDecimal totalBonusAmount;
	//Betting Times  下注次数
	private Integer bettingTimes;
	//平台ID
	private String platformId;
	//游戏种类ID
	private String gameKind;
	private String gameType;
	private BigDecimal totalWonAmount;
	private BigDecimal totalLoseAmount;
	private BigDecimal totalWonTimes;
	private BigDecimal totalLoseTimes;
	private BigDecimal totalTieTimes;
	/** 排名 */
	private Integer rank;
	//返回币种类型
	private String currency;

	//最大投注额
	private BigDecimal maxAccount;
	//最大有效投注额
	private BigDecimal maxValidAccount;
	//最大洗码投注额
	private BigDecimal maxRemainAccount;
	//最大输赢值
	private BigDecimal maxCusAccount;
	//最大赢值
	private BigDecimal maxWinAmount;
	//最大输值
	private BigDecimal maxLostAmount;
	//创建时间（数据中心最早抓到注单的时间） add by ziv 2019-09-26
	private Date createDate;
	private Integer totalBetTimes;

	@Override
	public String toString() {
		return "AccountTotalEntity [statDate=" + statDate + ", loginName=" + loginName + ", productId=" + productId + ", totalCusAccount=" + totalCusAccount
				+ ", totalAccount=" + totalAccount + ", totalValidAccount=" + totalValidAccount + ", bettingTimes=" + bettingTimes
				+ ", totalRemainAmount="+ totalRemainAmount + ", platformId=" + platformId + ", gameKind=" + gameKind + ", totalWonAmount=" + totalWonAmount
				+ ", totalLoseAmount=" + totalLoseAmount + "]";
	}



    public BigDecimal getTotalAccount() {
        return totalAccount  == null?BigDecimal.ZERO.setScale(6, RoundingMode.DOWN):totalAccount.setScale(6, RoundingMode.DOWN);
    }

    public void setTotalAccount(BigDecimal totalAccount) {
        this.totalAccount = totalAccount;
    }

    public BigDecimal getTotalValidAccount() {
        return totalValidAccount == null?BigDecimal.ZERO.setScale(6, RoundingMode.DOWN):totalValidAccount.setScale(6, RoundingMode.DOWN);
    }

    public void setTotalValidAccount(BigDecimal totalValidAccount) {
        this.totalValidAccount = totalValidAccount;
    }
}
