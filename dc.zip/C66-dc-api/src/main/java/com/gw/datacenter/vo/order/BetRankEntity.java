package com.gw.datacenter.vo.order;

import lombok.Data;

@Data
public class BetRankEntity {

    private String loginName;   // 玩家账号
    private Integer winLostCount; // 符合条件的输赢条数
    private String betAmountSum; // 投注总额
    private String validBetAmountSum; // 有效投注总额
    private String remainAmountSum; // 洗码总额
    private String cusAmountSum; // 输赢总额
    private Integer rank; // 请求条件下的玩家排名

}
