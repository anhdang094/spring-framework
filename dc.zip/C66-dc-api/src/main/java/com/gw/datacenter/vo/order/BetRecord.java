package com.gw.datacenter.vo.order;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class BetRecord {
    private Date billTime;
    private String billNo;
    private String gameId;
    private String gameName;
    private BigDecimal betAmount;
    private BigDecimal winAmount;
    private Integer status;
    private String gametype;
    private String playtype;
}
