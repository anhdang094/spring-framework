
package com.gw.datacenter.vo.order;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

@Data
public class BonusEntity implements Serializable{

	private static final long serialVersionUID = 5968387011416581997L;

	//LOGINNAME 登陆名称
	private String loginName;
	//CUS_ACCOUNT 客户输赢额度
	private BigDecimal cusAccount;
	//ACCOUNT 投注额
	private BigDecimal account;
	//VALID_ACCOUNT  有效投注额
	private BigDecimal validAccount;

}
