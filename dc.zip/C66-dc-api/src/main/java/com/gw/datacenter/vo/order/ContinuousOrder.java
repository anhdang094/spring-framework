package com.gw.datacenter.vo.order;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class ContinuousOrder {
	
	private String loginname;
	private int dateCount;
	private int orderTimes;
	private BigDecimal totalAmount; // 投注额
	private BigDecimal totalCusAmount; // 输赢值
	private BigDecimal totalValidAmount; // 有效投注额
	private BigDecimal totalRemainAmount;//洗码投注额
}
