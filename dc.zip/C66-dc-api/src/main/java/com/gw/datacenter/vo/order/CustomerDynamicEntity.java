package com.gw.datacenter.vo.order;

import lombok.Data;

import java.util.Date;

@Data
public class CustomerDynamicEntity {
    private String productId;
    private String loginName;
    private String dynamicType;
    private String dynamicValue;
    private String extendValue;
    private String platformId;
    private String gameKind;
    private String billNo;
    private Date dataDate;
    private Date createDate;
    private String remark;
}
