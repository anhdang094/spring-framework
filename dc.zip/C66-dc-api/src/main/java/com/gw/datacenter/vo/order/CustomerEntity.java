package com.gw.datacenter.vo.order;

import lombok.Data;

import java.util.Date;

@Data
public class CustomerEntity {
    private long id;
    private String productId;
    private String loginName;
    private String currency;
    private String  remark;
    private String relationLoginName;
    private String mainLoginName;
}
