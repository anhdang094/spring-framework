package com.gw.datacenter.vo.order;

import lombok.Data;

@Data
public class Game {
    private String platformId;
    private String platformName;
    private String gameKind;
    private String gameKindName;
    private String gameId;
    private String cnName;
    private String enName;

}
