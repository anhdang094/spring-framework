package com.gw.datacenter.vo.order;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class GameOrder {
    private String productId;
    private String platformId;
    private String loginName;
    private Integer gameKind;
    private String gameType;
    private String billNo;
    private Date billTime;
    private String gameCode;
    private String tableCode;
    private Integer playType;
    private BigDecimal account;
    private BigDecimal validAccount;
    private BigDecimal cusAccount;
    private BigDecimal remainAmount;
    private Integer deviceType;
    private BigDecimal totalValidAccount;
    private BigDecimal totalCusAccount;
    private BigDecimal totalRemainAmount;
    private Integer total;
}
