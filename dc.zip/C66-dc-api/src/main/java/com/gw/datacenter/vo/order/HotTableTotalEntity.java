
package com.gw.datacenter.vo.order;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 热门桌台露珠对象
 *
 */
@Data
public class HotTableTotalEntity implements Serializable{
	//产品id
	private String productId;
	//游戏种类ID
	private String gameKind;
	//游戏局号
	private String gmcode;
	//游戏类型
	private String gametype;
	//ACCOUNT 投注总额 总投注总额
	private BigDecimal account;
	//cusAccount 客户输赢总额度  总输赢
	private BigDecimal cusAccount;
	//validAccount  有效投注总额
	private BigDecimal validAccount;
	//总反水投注总额
	private BigDecimal remainAmount;
	// 游戏总笔数
	private Long totalNum;
	//总人数
	private Long  totalPeople;
}
