/**
 * 
 */
package com.gw.datacenter.vo.order;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Data
public class KashbetTicket implements Serializable {
	private static final long serialVersionUID = -4118031612930406349L;
	private String platformId;
	private String loginName;
	private String billNo;
	private Date billTime;
	private String gameCode;
	private String gameType;
	private Integer betTimes;
	private BigDecimal betAmount;
	private BigDecimal cusAmount;
	private BigDecimal earnComm;
	private BigDecimal netWin;
	private String currency;
	private String status;
	private String gameResult;
}
