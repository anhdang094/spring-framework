package com.gw.datacenter.vo.order;

import lombok.Data;

import java.io.Serializable;

@Data
public class MGAndTTGAbnormalEntity implements Serializable {

    private static final long serialVersionUID = -5995727610801808589L;
    private String transactionId;
    private String gameId;
    private String nextGameId;
    private String pregameId;
    private String diff;
    private String loginName;
    private String platformId;
    private String createdDate;

}
