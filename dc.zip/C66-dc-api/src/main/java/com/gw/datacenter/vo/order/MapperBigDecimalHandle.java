package com.gw.datacenter.vo.order;


import org.apache.ibatis.type.BigDecimalTypeHandler;
import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.MappedTypes;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@MappedTypes({BigDecimal.class,BigDecimal.class})
public class MapperBigDecimalHandle extends BigDecimalTypeHandler {
    @Override
    public void setNonNullParameter(PreparedStatement preparedStatement, int i, BigDecimal s, JdbcType jdbcType) throws SQLException {
    }

    @Override
    public BigDecimal getNullableResult(ResultSet resultSet, int i) throws SQLException {
        return convertDecimalStr(resultSet.getBigDecimal(i));
    }

    @Override
    public BigDecimal getNullableResult(CallableStatement callableStatement, int i) throws SQLException {
        return convertDecimalStr(callableStatement.getBigDecimal(i));
    }


    @Override
    public BigDecimal getResult(ResultSet rs, String columnName) throws SQLException {
        BigDecimal r = super.getResult(rs, columnName) ;
        return StringUtils.isEmpty(r) ? BigDecimal.ZERO.setScale(6) : r.setScale(6,BigDecimal.ROUND_DOWN);
    }
    @Override
    public BigDecimal getResult(ResultSet rs, int columnIndex) throws SQLException {
        BigDecimal r = super.getResult(rs, columnIndex);
        return StringUtils.isEmpty(r) ? BigDecimal.ZERO.setScale(6) : r.setScale(6,BigDecimal.ROUND_DOWN);
    }

    @Override
    public BigDecimal getResult(CallableStatement cs, int columnIndex) throws SQLException {
        BigDecimal r = super.getResult(cs, columnIndex);
        return StringUtils.isEmpty(r) ? BigDecimal.ZERO.setScale(6) : r.setScale(6,BigDecimal.ROUND_DOWN);
    }

    /**
     * 转换big decimal
     *
     * @param val
     * @return
     */
    private BigDecimal convertDecimalStr(BigDecimal val) {
        try {
            return StringUtils.isEmpty(val) ? BigDecimal.ZERO.setScale(6) : val.setScale(6);
        } catch (Exception e) {
            return BigDecimal.ZERO.setScale(6);
        }

    }
}
