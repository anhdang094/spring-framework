/**
 * 
 */
package com.gw.datacenter.vo.order;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class MonthlyWeeklyEffectiveBetAmountEntity {
	private String loginName;
	private BigDecimal validAmountWeek;
	private BigDecimal validAmountMonth;
}
