package com.gw.datacenter.vo.order;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * title: OrderAGQJExceptionor
 * description: TODO
 * author: Jair.H
 * date: 2019/1/7 17:14
 */
@Data
public class OrderAGQJExceptionor implements Serializable {
    //BILLNO 注单号
    private String billNo;
    //用户名
    private String loginName;
    //PRODUCT_ID 产品ID
    private String productId;
    //GMCODE 游戏编号
    private String gmCode;
    private String origPlaytype;//原始玩法
    private String origPlaytypeZh ;//原始玩法中文
    private String recPlaytype;//目标玩法
    private String recPlaytypeZh ;//目标玩法中文
    private String origRemark;//原始子玩法
    private String recRemark;//目标子玩法
    private BigDecimal origAccout;//原始额度
    private BigDecimal recAccount;//修改额度
    private Date joinTime;
    private Integer errcode;//错误码
}
