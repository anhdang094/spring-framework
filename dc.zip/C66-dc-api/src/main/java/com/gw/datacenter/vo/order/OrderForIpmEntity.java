
package com.gw.datacenter.vo.order;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Data
public class OrderForIpmEntity implements Serializable{

	private static final long serialVersionUID = -2911879504132022674L;
	
	public static final String HOME_TEAM_FLAG = "H";
	public static final String AWAY_TEAM_FLAG = "F";

	/** Transaction Id of a bet. */
	private String billNo;
	/** Date Time of a bet. */
	private Date billTime;
	/** Member Code. */
	private String loginName;
	/** Date Time of a match. */
	private Date matchDateTime;
	/** Sports Name */
	private String sportsName;
	/** League Name */
	private String leagueName;
	/** Home Team Name. Return NULL if bet type is “Outright” or “Parlay”. */
	private String homeTeam;
	/** Away Team Name. Return NULL if bet type is “Outright” or “Parlay”. */
	private String awayTeam;
	/** “H” – home team is favourite. “A” – away team is favourite. Return NULL if bet type is “Outright” or “Parlay”. */
	private String favouriteTeamFlag;
	/** Bet Type. Refer Appendix D. */
	private String betType;
	/** Bet Type. Refer betMethod. */
	private String betMethod;
	/** Team selected. Return NULL if bet type is “Parlay”. */
	private String selection;
	/** Handicap of a bet. Return NULL if bet type is “Outright” or “Parlay”. */
	private Double handicap;
	/** Odds Type of a bet. (HK, Malay or Euro) */
	private String oddsType;
	/** Odds of a bet. */
	private Double odds;
	/** Stake amount. */
	private BigDecimal amount;
	/** Return Stake amount. */
	private BigDecimal cusAmount;
	/** Half-time Score for Home Team. */
	private Integer htHomeScore;
	/** Half-time Score for Away Team. */
	private Integer htAwayScore;
	/** Full-time Score for Home Team. */
	private Integer ftHomeScore;
	/** Full-time Score for Away Team. */
	private Integer ftAwayScore;
	/** Score of a Home Team as at a bet is confirmed. */
	private Integer betHomeScore;
	/** Score of a Away Team as at a bet is confirmed. */
	private Integer betAwayScore;
	/** Status of settlement. 0 = Not Settled, 1 = Settled */
	private Boolean settled;
	/** Status of betCancelled. 0 = Not Cancelled, 1 = Cancelled MatchID Match Identifier Number ParlaySign Handicap sign (?+? positive or ?-? negative). ParlayBetType Bet Type of the ticket for the parlay. Refer Appendix D. ParlayBetOn Bet on which team; ?A?- Away, ?H?-Home for the parlay ticket. ParlayHandicap Handicap value for parlay ticket. ParlayOdds Odds value for the parlay ticket. ParlayTeamAway Away Team Name for the parlay ticket. ParlayTeamHome Home Team Name for the parlay ticket. ParlayFavouriteTeamFlag Favourite Team for the parlay ticket; ?H? – Home Team, ?A? – Away Team. ParlayLeagueName League name for the parlay ticket. ParlayBetCancelled Status of betCancelled of the parlay ticket. 0 = Not Cancelled, 1 = Cancelled ParlayBetTime Date Time when the bet placed for the parlay ticket. ParlaySportName Sport Name for the bet in the parlay ticket */
	private Boolean betCancelled;
	/** Whether the bet is a parlay or not */
	private Boolean withParlay;
	/** Product ID */
	private String productId;
	/** Platform ID */
	private String platformId;
	/** Previous amount */
	private BigDecimal previousAmount;
	/** Valid amount */
	private BigDecimal validAmount;
	/** Creation time */
	private Date creationTime;	
	/** Last update time */
	private Date lastUpdateTime;
	/** Match ID (Currently not provided by IPM) */
	private String matchId;
	private Date oriBillTime;
	private Date oriMatchDateTime;	
	private Date oriLastUpdateTime;
	private Date oriCreationTime;
	private Integer currencyType;
	/**
	 * Parlay records
	 */
	private List<ParlayForIpmEntity> parlays;

	
}
