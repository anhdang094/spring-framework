package com.gw.datacenter.vo.order;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class OrderReportEntity {
	private String productId;
	private String productName;//add by ziv 2018-07-04
	private String platformId;
	private String currency;
	private String gameKind;
	private String gameKindName;
	private long playerNum;
	private long betTimes;
	private BigDecimal validAccount;
	private BigDecimal remainAmount;
	private BigDecimal profitability;
	private BigDecimal account;
}
