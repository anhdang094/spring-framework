package com.gw.datacenter.vo.order;

import com.gw.datacenter.common.util.Md5Util;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class OrderSummary {
    private String id;
    private String product;
    private String loginName;
    private String statDate;
    private String platform;
    private String gameKind;
    private String gameType;
    private String deviceType;
    private BigDecimal totalBetAmount;
    private BigDecimal totalValidAmount;
    private Long totalBetTimes;
    private BigDecimal maxBetAmount;
    private Long lastUpdateId;
    private BigDecimal totalRemainAmount;
    private BigDecimal totalBonusAmount;
    private BigDecimal totalWinLostAmount;
    private BigDecimal totalScore;
    private BigDecimal totalCusAmount;
    private Date lastUpdate;
    private Date createDate;
    private Long total;
    private Long timestamp;

    public String getId() {
        StringBuilder builder = new StringBuilder();
        builder.append(platform).append(gameKind).append(product).append(loginName).append(gameType).append(deviceType)
                .append(statDate);
        return Md5Util.MD5Encode(builder.toString());
    }

}
