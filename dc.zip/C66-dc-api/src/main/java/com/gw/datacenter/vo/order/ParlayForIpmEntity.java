/**
 * 
 */
package com.gw.datacenter.vo.order;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * Parlay information for order of IPM
 * 
 * @author kwan.lau
 *
 */
@Data
public class ParlayForIpmEntity implements Serializable {

	private static final long serialVersionUID = 4903357360986844030L;
	/** ID of the vo */
	private String id;
	/** The bet that this parley item belongs to */
	private String parentBillNo;
	/** The bet ID for the parlay itself */
	private String billNo;
	/** Match Identifier Number */
	private String gmCode;
	/** Handicap sign ('+' positive or '-' negative).  */
	private String parlaySign;
	/** Bet Type of the ticket for the parlay. Refer Appendix D.  */
	private String parlayBetType;
	/** Bet on which team; 'A'- Away, 'H'-Home for the parlay ticket.  */
	private String parlayBetOn;
	/** Handicap value for parlay ticket.  */
	private Double parlayHandicap;
	/** Odds value for the parlay ticket.  */
	private Double parlayOdds;
	/** Away Team Name for the parlay ticket. */
	private String parlayTeamAway;
	/** Home Team Name for the parlay ticket. */
	private String parlayTeamHome;
	/** Favourite Team for the parlay ticket; 'H' – Home Team, 'A' – Away Team.  */
	private String parlayFavouriteTeamFlag;
	/** League name for the parlay ticket.  */
	private String parlayLeagueName;
	/** Status of betCancelled of the parlay ticket. 0 = Not Cancelled, 1 = Cancelled  */
	private Boolean parlayBetCancelled;
	/** Date Time when the bet placed for the parlay ticket.  */
	private Date parlayBetTime;
	private Date originalParlayBetTime;
	/** Sport Name for the bet in the parlay ticket */
	private String parlaySportName;
	/** Creation Time */
	private Date creationTime;
	/** Last Update Time */
	private Date lastUpdateTime;
	private Date parlayMatchDateTime;
}
