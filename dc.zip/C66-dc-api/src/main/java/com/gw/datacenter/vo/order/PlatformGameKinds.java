package com.gw.datacenter.vo.order;

/**
 * Created by Angus.Z on 2018/4/21.
 */
public class PlatformGameKinds {
    private String platformId;
    private String[] gameKinds;

    public String getPlatformId() {
        return platformId;
    }

    public void setPlatformId(String platformId) {
        this.platformId = platformId;
    }

    public String[] getGameKinds() {
        return gameKinds;
    }

    public void setGameKinds(String[] gameKinds) {
        this.gameKinds = gameKinds;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder("[");
        builder.append("platformId=").append(platformId).append(",");
        if (gameKinds == null) {
            builder.append("gameKind=").append(gameKinds);
        } else {
            for (int i=0; i< gameKinds.length; i++) {
                builder.append(gameKinds[i]);
                if (i != gameKinds.length-1) {
                    builder.append(",");
                }
            }
        }
        builder.append("]");
        return builder.toString();
    }
}
