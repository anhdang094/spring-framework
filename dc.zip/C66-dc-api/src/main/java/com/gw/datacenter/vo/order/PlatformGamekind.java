package com.gw.datacenter.vo.order;

import lombok.Data;

@Data
public class PlatformGamekind {
    private String platform;
    private String gameKind;
}
