package com.gw.datacenter.vo.order;

import lombok.Data;

@Data
public class PlayerPlatformProfit {

    private String productId;
    private String platformId;
    private String loginName;
    private String gameType;
    private String chineseName;
    private String betAmount;
    private String validBetAmount;
    private String cusAmount;
    private String profitRate;

}
