package com.gw.datacenter.vo.order;

import lombok.Data;

@Data
public class PlayerWinsEntity {

    private String platformId; // 游戏平台
    private String betAmountSum; // 投注总额
    private String validBetAmountSum; // 有效投注总额
    private String remainAmountSum; // 洗码总额
    private String cusAmountSum; // 输赢总额

}
