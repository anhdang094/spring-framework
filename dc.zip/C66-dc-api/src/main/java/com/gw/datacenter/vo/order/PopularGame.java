package com.gw.datacenter.vo.order;

import lombok.Data;

/**
 * 最受欢迎的游戏
 * Created by angus.z on 2017/12/7.
 */
@Data
public class PopularGame {
    private String platformId; //平台ID
    private String platform; //平台名称
    private String gameType; //游戏id
    private String gameName; // 游戏名称
    private Integer playerNum; // 玩家数量
    private String playtype;
    private Integer rank; //排名
}
