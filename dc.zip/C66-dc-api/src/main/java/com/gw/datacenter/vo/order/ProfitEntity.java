package com.gw.datacenter.vo.order;

import lombok.Data;

@Data
public class ProfitEntity {

    private String loginName;   // 玩家账号

    private String cusAmount; // 输赢总额


}