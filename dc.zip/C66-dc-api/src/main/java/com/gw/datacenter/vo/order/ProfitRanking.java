package com.gw.datacenter.vo.order;

import com.gw.datacenter.common.constants.UtilConstants;
import lombok.Data;
import net.sf.json.JSONObject;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;

@Data
public class ProfitRanking implements Serializable  {

	private static final long serialVersionUID = -2911879504132022674L;
    //BILLNO 注单号
	private String billNo;
	//LOGINNAME 登陆名称
	private String loginName;
	//AGCODE 代理编号
	private String agCode;
	//AGCODE 顶级代理编号
	private String topAgCode;	
	//PLATCODE 平台ID
	private String platId;
	//PRODUCT_ID 产品ID
	private String productId;
	//GMCODE 游戏编号
	private String gmCode;
	//CUS_ACCOUNT 客户输赢额度
	private BigDecimal cusAccount;
	//BILLTIME 注单产生北京时间
	private Date billTime;
	//FLAG 结算标识
	private Integer flag;
	//HASHCODE 校验码
	private String hashCode;
	//REMARK 备注
	private String remark;
	//PLAYTYPE 玩法类型
	private Integer playType;
	//CURRENCY 货币
	private String currency;
	//TABLECODE 桌子编号
	private String tableCode;
	//ROUND
	private String round;
	//GAMETYPE 游戏类型
	private String gameType;
	//ACCOUNT 投注额
	private BigDecimal account;
	//VALID_ACCOUNT  有效投注额
	private BigDecimal validAccount;
	// 对赌积分 数据库中AP的有效投注额为积分 20150704
	private BigDecimal score;
	//VALID_ACCOUNT  有效投注额
	private String validAccountStr;	
	//CUR_IP 客户当前IP
	private String curIp;
	//RECKONTIME 北京更新时间
	private Date reckonTime;
	//BASEPOINT 投注前额度
	private BigDecimal previosAmount;
	//投注后额度
	private BigDecimal currentAmount;
	//红利额度
	private BigDecimal bonusAmount;	
	//REMAIN_AMOUNT  返水投注额
	private BigDecimal remainAmount;
	//ORIGNAL_BILLTIME 注单产生时间
	private Date orignalBillTime;
	//ORIGNAL_RECKONTIME 注单产生时间
	private Date orignalReckonTime;
	//CREATION_TIME 注单产生时间
	private Date creationDate;
	//RESULT(only for BB-IN)
	private String result;
	//RESULT(only for BB-IN)
	private String resultType;	
	//CARDLIST(only for BB-IN)
	private String cardList;
	//EXCHANGERATE(only for BB-IN)
	private BigDecimal exchangeRate;
	//GAME_KIND(only for BB-IN)
	private String gameKind;
	//NET_ACCOUNT 纯输纯赢
	private BigDecimal netAccount;
	private Integer currencyType;
	//平台ID号
	private String platformId;
	//终端 0:电脑网页版,1:手机网页版/手机网站APP，101:手机厅方APP
	private String deviceType;
	private String gameId;
	private String gameName;
	// 投注人数
	private String betAccountNum;
	//赔率
	private String odds;
	//盘口
	private String oddsType;
	//ws login终端类型 add by ziv 2018-11-28
	private String termType;

	private BigDecimal multiple;

	//BANKERPOINT 庄点数
	private String bankerPoint;
	//PLAYERPOINT 闲点数
	private String playerPoint;

	public void setCusAccount(BigDecimal cusAccount) {
		this.cusAccount = cusAccount == null?BigDecimal.ZERO.setScale(6, RoundingMode.DOWN):cusAccount.setScale(6, RoundingMode.DOWN);
	}

	public void setMultiple(BigDecimal multiple) {
		this.multiple = multiple == null?BigDecimal.ZERO.setScale(6, RoundingMode.DOWN):multiple.setScale(6, RoundingMode.DOWN);
	}

	/**
	 * @return the validAccount
	 */
	public BigDecimal getValidAccount() {
		// 德州扑克AP为对战有效，积分保存在数据库的有效投注额字段中，故有效投注额使用投注额
		// added by Grant 20150704
		if(UtilConstants.AP.equals(this.platId)){
			if(account==null){
				account= BigDecimal.ZERO;
			}
			if(validAccount != null){
				// AP的有效投注额需等于投注额
				// account == null的情况也许替换
				if(validAccount.compareTo(account) != 0){
					// 实际为积分，先放入积分中
					if(score == null){
						score = validAccount;
					}
					validAccount = account;
				}
			}

		}
		return validAccount == null?BigDecimal.ZERO.setScale(6, RoundingMode.DOWN):validAccount.setScale(6, RoundingMode.DOWN);
	}

	public BigDecimal getCurrentAmount() {
		if(previosAmount!=null) {
			//gameType == evwin 时为连赢记录，现额度=previosAmount+连赢奖金
			if(UtilConstants.AG.equals(this.platId) && "evwin".equals(gameType) && this.bonusAmount!=null){
				return previosAmount.add(this.bonusAmount).setScale(6, RoundingMode.DOWN);
			}
			if(cusAccount==null){
				return previosAmount.setScale(6, RoundingMode.DOWN);
			}
			return previosAmount.add(cusAccount).setScale(6, RoundingMode.DOWN);
		}else{
			return previosAmount;
		}
	}

	@Override
	public boolean equals(Object obj) {
		  if (this == obj)
	            return true;
		  if (obj == null)
            return false;
	        if (getClass() != obj.getClass())
	            return false;
	        ProfitRanking other = (ProfitRanking) obj;
	        if (billNo == null){
	        	if (other.billNo != null)
	        		return false;
	        } else if (!billNo.equals(other.billNo))
	            return false;
	        if (loginName == null){
	        	if (other.loginName != null)
	        		return false;
	        } else if (!loginName.equals(other.loginName))
	        	return false;
	        if (productId == null){
	        	if (other.productId != null)
	        		return false;

	        } else if (!productId.equals(other.productId))
	            return false;
	        return true;
	}


	@Override
	public int hashCode() {
		 int prime = 1;
		 int result = 1;
		 result = prime * result + ((billNo == null) ? 0 : billNo.hashCode());
		 result = prime * result + ((loginName == null) ? 0 : loginName.hashCode());
	     result = prime * result + ((productId == null) ? 0 : productId.hashCode());
        return result;
	}

	public BigDecimal getScore() {
		// 德州扑克AP为对战有效，积分保存在数据库的有效投注额字段中
		// added by Grant 20150704
		if(UtilConstants.AP.equals(this.platId)){
			if(score == null){
				score = validAccount;
			}
		}
		return score == null?BigDecimal.ZERO: score.setScale(6, RoundingMode.DOWN);
	}

	public BigDecimal getRemainAmount() {
		return remainAmount == null ? null : remainAmount.setScale(6, RoundingMode.DOWN);
	}

	@Override
	public String toString(){
		return JSONObject.fromObject(this).toString();
	}

}
