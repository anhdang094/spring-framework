package com.gw.datacenter.vo.order;

import lombok.Data;

@Data
public class SuperWinEntity {

    private String loginName;
    private String betAmount;
    private String validBetAmount;
    private String cusAmount;
    private String platformId;
    private String gameKind;
    private String gameType;
    private String billTime;

}
