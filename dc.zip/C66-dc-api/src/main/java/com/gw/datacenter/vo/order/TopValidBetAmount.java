package com.gw.datacenter.vo.order;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Created by Ricardo.X on 2017/8/29.
 */
public class TopValidBetAmount implements Serializable{

    private static final long serialVersionUID = -6159068412250472458L;
    private String productId;

    private String loginName;

    private String platformId;

    private BigDecimal validBetAmount;

    private long sumTimeStamp;

    public TopValidBetAmount() {
        sumTimeStamp = System.currentTimeMillis();
    }

    public String getProductId() {
        return productId;
    }

    public TopValidBetAmount setProductId(String productId) {
        this.productId = productId;
        return this;
    }

    public String getLoginName() {
        return loginName;
    }

    public TopValidBetAmount setLoginName(String loginName) {
        this.loginName = loginName;
        return this;
    }

    public String getPlatformId() {
        return platformId;
    }

    public TopValidBetAmount setPlatformId(String platformId) {
        this.platformId = platformId;
        return this;
    }

    public BigDecimal getValidBetAmount() {
        return validBetAmount;
    }

    public TopValidBetAmount setValidBetAmount(BigDecimal validBetAmount) {
        this.validBetAmount = validBetAmount;
        return this;
    }

    public long getSumTimeStamp() {
        return sumTimeStamp;
    }

    public TopValidBetAmount setSumTimeStamp(long sumTimeStamp) {
        this.sumTimeStamp = sumTimeStamp;
        return this;
    }
}
