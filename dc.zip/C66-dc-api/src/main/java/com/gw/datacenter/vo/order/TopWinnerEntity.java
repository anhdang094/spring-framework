package com.gw.datacenter.vo.order;

import lombok.Data;

@Data
public class TopWinnerEntity {

    private String loginName; // 玩家用户名
    private String betAmountSum; // 投注总额
    private String validBetAmountSum; // 有效投注总额
    private String remainAmountSum; // 洗码总额
    private String cusAmountSum; // 输赢总额

}
