/**
 * 
 */
package com.gw.datacenter.vo.order;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class UnSettledAmountEntity {
	private String loginName;
	private BigDecimal unSettledAmount;
}
