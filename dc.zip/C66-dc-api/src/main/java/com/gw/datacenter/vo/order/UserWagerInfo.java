package com.gw.datacenter.vo.order;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Data
public class UserWagerInfo implements Serializable {
	private static final long serialVersionUID = -3039667812532362714L;
	private long id;
	//PRODUCT_ID 平台id
	private String productId;
	//PLATFORM_ID 产品id
	private String platId;
	//LOGIN_NAME 登入名称
	private String loginName;
	//BILL_NO 注单号
	private String billNo;
	//BILLTIME 下注时间
	private Date billTime;
	//LAST_UPDATE_TIME 最后一次登入时间
	private Date lastUpdateTime;
	//CREATION_TIME 创建时间（系统时间)
	private Date creationTime;
	//BET_AMOUNT 投注额
    private BigDecimal betAmount;
    //BET_VALID_AMOUNT 投注有效金额
    private BigDecimal betValidAmount;
    //NET_AMOUNT 输赢额度
    private BigDecimal netAmount;
    //GMCODE 游戏编码
    private String gmCode;
    //TYPE 类型标示(1:第一次下注 2:第一次赢钱)
  	private Integer type;
	//REMARK 备注
  	private String remark;
  	//DEVINCE_TYPE 客户端类型
	private String deviceType;
	//CURRENCY 货币
	private String currency;
	//GAME_KIND 游戏种类
  	private Integer gameKind;

}
