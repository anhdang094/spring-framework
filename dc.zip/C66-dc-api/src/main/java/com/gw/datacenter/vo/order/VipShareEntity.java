/**
 * 
 */
package com.gw.datacenter.vo.order;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

@Data
public class VipShareEntity implements Serializable {
	private static final long serialVersionUID = -6195771025023512339L;
	private String gameType;
	private BigDecimal totalAccount;
	private BigDecimal totalValidAccount;
	private BigDecimal totalCusAccount;
}
