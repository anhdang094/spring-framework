
package com.gw.datacenter.vo.order;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

public class WagerInfo extends OrderEntity implements Serializable  {
	private static final long serialVersionUID = -155626272908638827L;
	@Setter
	@Getter
	private BigDecimal totalRecord;
	@Setter
	@Getter
	private BigDecimal betTimes;
	@Setter
	@Getter
	private BigDecimal maxBetAmout;
	@Setter
	@Getter
	private BigDecimal maxCusAmout;

	
}
