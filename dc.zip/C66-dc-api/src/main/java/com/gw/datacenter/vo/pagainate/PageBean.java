package com.gw.datacenter.vo.pagainate;


import com.gw.datacenter.common.constants.UtilConstants;
import lombok.Data;

import java.util.List;

@Data
public class PageBean<T>{
	private int currentPageNumger;
	private int pageSize = UtilConstants.PAGE_SIEZE;
	private int toalRecords;
	private int totalPages;
	private boolean isFirstPage;
	private boolean isLastPage;
	private boolean isHasNextPage;
	private boolean isHasPreviousPage;
	private List<T> listResult;

	public int getTotalPages() {
		if(toalRecords%pageSize == 0){
			this.totalPages = toalRecords/pageSize;
		}else{
			this.totalPages = (toalRecords/pageSize)+UtilConstants.ONE;
		}
		return totalPages;
	}

	public boolean getIsLastPage() {
		boolean flag = false;
		if(this.currentPageNumger == this.totalPages){
			flag = true;
		}
		return flag;
	}

}
