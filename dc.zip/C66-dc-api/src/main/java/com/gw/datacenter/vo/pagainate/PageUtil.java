package com.gw.datacenter.vo.pagainate;


import com.gw.datacenter.common.constants.UtilConstants;

import java.util.HashMap;
import java.util.Map;

public class PageUtil {

	public static Map<String, Object> getParameterMap(Integer currentPageNumger,Integer pageSize) {
		Map<String,Object> parameterMap = new HashMap<>();
		int endRow;
		int startRow;
		if(currentPageNumger == null){
			currentPageNumger = UtilConstants.ONE;
		}
		if(pageSize != null && pageSize >0){
			endRow = currentPageNumger*(pageSize);
			startRow = (currentPageNumger-1)*(pageSize)+1;
		}else{
			endRow = currentPageNumger*(UtilConstants.PAGE_SIEZE);
			startRow = endRow-(UtilConstants.PAGE_SIEZE);
		}
		parameterMap.put(UtilConstants.FROM_ROWNUMBER, startRow);
		parameterMap.put(UtilConstants.TO_ROWNUMBER, endRow);
		return parameterMap;
	}
}
