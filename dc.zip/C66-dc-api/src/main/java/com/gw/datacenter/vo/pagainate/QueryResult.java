package com.gw.datacenter.vo.pagainate;

import lombok.Data;

import java.util.List;

@Data
public class QueryResult<T> {
	
	private Integer totalRecords;
	
	private List<T> queryResultList;

	private T totalResult;

}
