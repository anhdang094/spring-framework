package com.gw.datacenter.vo.pagainate;

import lombok.Data;

@Data
public class QueryResultWrapper<T> {
	private QueryResult<T> queryResult;
	private String[] utilArray;
}
