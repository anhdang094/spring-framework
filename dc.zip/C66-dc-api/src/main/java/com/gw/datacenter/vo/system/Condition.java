package com.gw.datacenter.vo.system;

import lombok.Data;

@Data
public class Condition {
	public String key;
	public String value;
	private String[] gameKinds;

}
