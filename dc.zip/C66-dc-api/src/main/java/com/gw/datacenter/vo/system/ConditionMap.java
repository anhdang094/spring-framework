package com.gw.datacenter.vo.system;

import java.util.ArrayList;
import java.util.List;

public class ConditionMap {
    List<Condition> conditionList = new ArrayList<>();
    List<PlatformCondition> platFormConditionList = new ArrayList<>();

    public void put(String key, String value) {
        Condition con = new Condition();
        con.setKey(key);
        con.setValue(value);
        conditionList.add(con);
    }

    public void put(String key, String value, String[] gameKinds) {
        Condition con = new Condition();
        con.setKey(key);
        con.setValue(value);
        con.setGameKinds(gameKinds);
        conditionList.add(con);
    }

    public void remove(String key, String value) {
        Condition con = new Condition();
        con.setKey(key);
        con.setValue(value);
        conditionList.remove(con);
    }
    
    public List<Condition> getConditionList() {
        return conditionList;
    }
    
    public void setConditionList(List<Condition> conditionList) {
        this.conditionList = conditionList;
    }
    
    public void putPlatForm(PlatformCondition con) {
    	platFormConditionList.add(con);
    }

	public List<PlatformCondition> getPlatFormConditionList() {
		return platFormConditionList;
	}

	public void setPlatFormConditionList(List<PlatformCondition> platFormConditionList) {
		this.platFormConditionList = platFormConditionList;
	}

	@Override
	public String toString() {
		return "ConditionMap [conditionList=" + conditionList + ", platFormConditionList=" + platFormConditionList
				+ "]";
	}
	
	
}
