package com.gw.datacenter.vo.system;

import java.util.List;

public class PlatformCondition extends Condition{
	public List<String> gameKindList;
	public List<String> gameTypeList;
	public List<String> gameOrderStatusList;

	public List<String> getGameKindList() {
		return gameKindList;
	}

	public void setGameKindList(List<String> gameKindList) {
		this.gameKindList = gameKindList;
	}

	public List<String> getGameTypeList() {
		return gameTypeList;
	}

	public void setGameTypeList(List<String> gameTypeList) {
		this.gameTypeList = gameTypeList;
	}

	public List<String> getGameOrderStatusList() {
		return gameOrderStatusList;
	}

	public void setGameOrderStatusList(List<String> gameOrderStatusList) {
		this.gameOrderStatusList = gameOrderStatusList;
	}
}
