package com.gw.datacenter.vo.transfer;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class TransferGroupByType {
    private String transferType;
    private BigDecimal transferAmount;
    private String zhValue;
}
