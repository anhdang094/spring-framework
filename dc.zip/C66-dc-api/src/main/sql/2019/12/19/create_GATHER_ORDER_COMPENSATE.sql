-- Create table
create table GATHER_ORDER_COMPENSATE
(
  platform_type       VARCHAR2(16),
  compensate_begin_id NUMBER(22),
  compensate_end_id   NUMBER(22),
  create_time         DATE,
  is_delete           NUMBER(1) default 0
);
-- Add comments to the table
comment on table GATHER_ORDER_COMPENSATE
  is '事前监控注单推送补偿记录表';
-- Add comments to the columns
comment on column GATHER_ORDER_COMPENSATE.platform_type
  is '平台名';
comment on column GATHER_ORDER_COMPENSATE.compensate_begin_id
  is '补偿起始注单id';
comment on column GATHER_ORDER_COMPENSATE.compensate_end_id
  is '补偿截止注单id';
comment on column GATHER_ORDER_COMPENSATE.create_time
  is '创建时间';
comment on column GATHER_ORDER_COMPENSATE.is_delete
  is '0:未删除，1：已删除';
-- Create/Recreate indexes
create index IDX_CREATE_TIME_GOC on GATHER_ORDER_COMPENSATE (CREATE_TIME);
create index IDX_PLATFORM_TYPE_GOC on GATHER_ORDER_COMPENSATE (PLATFORM_TYPE);
