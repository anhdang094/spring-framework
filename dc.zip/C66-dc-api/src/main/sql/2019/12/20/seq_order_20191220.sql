alter sequence orders_agin_seq order;
alter sequence orders_ysb_seq order;
alter sequence orders_xj_seq order;
alter sequence orders_agstar_seq order;
alter sequence t_consecutive_win_seq order;