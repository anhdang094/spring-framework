-- 增加字段，但是旧数据要默认为1，不推送
alter table ORDERS_CHANGED add risk_flag NUMBER(2) default 1 not null;
-- Add comments to the columns
comment on column ORDERS_CHANGED.risk_flag
  is '事前风控补偿推送状态 0 未推送 1 已推送';

-- 旧数据默认为1赋值后，默认值改为0
ALTER TABLE ORDERS_CHANGED MODIFY risk_flag DEFAULT 0;

create index I_OC_CT_RF on ORDERS_CHANGED (CHANGE_TIME, RISK_FLAG);