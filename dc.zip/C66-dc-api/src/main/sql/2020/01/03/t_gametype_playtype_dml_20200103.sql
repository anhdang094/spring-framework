-- 备份SQL
create table t_gametype_playtype_20200103 as
  select * from t_gametype_playtype;

-- 执行SQL
insert into t_gametype_playtype (ID, PLATFORM_ID, GAME_TYPE, PLAY_TYPE, CHINESE_NAME, ENGLISH_NAME, GAME_KIND, TYPE, CREATION_TIME, CREATE_BY, UPDATE_TIME, UPDATE_BY)
select SEQUENCE_T_GAMETYPE_PLAYTYPE.NEXTVAL,tmp1.platform_id,tmp1.game_type,tmp2.play_type,tmp2.chinese_name,tmp2.english_name,tmp1.game_kind,2,sysdate,'rnddeveloper',sysdate,'rnddeveloper' from
(select t1.* from t_gametype_playtype t1 where t1.type=1 and not exists (
       select t2.* from t_gametype_playtype t2 where t2.type=2 and t2.platform_id=t1.platform_id and t2.game_type=t1.game_type)
) tmp1
inner join
(select t3.* from t_gametype_playtype t3 where t3.type=2 and t3.game_type is null) tmp2
on tmp1.platform_id=tmp2.platform_id;

delete from t_gametype_playtype t where t.type=2 and t.game_type is null;


commit;

-- 回滚SQL
-- delete from t_gametype_playtype;
-- insert into t_gametype_playtype select * from t_gametype_playtype_20200103;