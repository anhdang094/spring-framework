-- 备份SQL
create table orders_shaba_20200113 as
  select t.* from orders_shaba t where t.billtime>=to_date('20200110','YYYYMMDD') and t.platform_id='086' and t.billno in
  (select t2.billno from orders_esp t2 where t2.billtime>=to_date('20200110','YYYYMMDD') and t2.platform_id='090');

-- 执行sql
delete from orders_shaba t where t.billtime>=to_date('20200110','YYYYMMDD') and t.platform_id='086' and t.billno in
(select t2.billno from orders_esp t2 where t2.billtime>=to_date('20200110','YYYYMMDD') and t2.platform_id='090');

commit;
