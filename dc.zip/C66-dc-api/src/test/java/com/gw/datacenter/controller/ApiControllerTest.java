package com.gw.datacenter.controller;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.JacksonUtil;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.controller.request.ApiRequest;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.context.WebApplicationContext;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

/**
 * title: ApiControllerTest
 * description: TODO
 * author: Jair.H
 * date: 2018/11/6 16:36
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@Slf4j
public class ApiControllerTest {
    @Resource
    private WebApplicationContext wac;
    private MockMvc mockMvc;

    @Before
    public void setup() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).build();   //构造MockMvc
    }

    @Test
    public void getValidAmountByType() throws Exception {
        ApiRequest request = new ApiRequest();
        request.setProductId("A04");
        request.setLoginNameArray("mwh004");
        request.setBeginTime("2018-08-10");
        request.setEndTime("2018-10-25");// not null
        StringBuffer sb = new StringBuffer();
        sb.append(request.getProductId());
        sb.append(request.getLoginNameArray());
        sb.append(request.getBeginTime());
        sb.append(request.getEndTime());
        sb.append(UtilConstants.SUFFIX);
        request.setKey(Md5Util.MD5Encode(sb.toString()));
        String responseString = mockMvc.perform(MockMvcRequestBuilders.get("/dcApi/getValidAmountByType")
                .param("productId","A04")
                .param("loginNameArray","mwh004")
                .param("beginTime","2018-08-10")
                .param("endTime","2018-10-25")
                .param("gameKind","3")
                .param("type","1")
                .param("pageNo","1")
                .param("pageSize","1")
                .param("key",Md5Util.MD5Encode(sb.toString())))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk()).andReturn().getResponse().getContentAsString();
        log.info(responseString);
    }

    @Test
    public void getCustomerDynamic() throws Exception {
        MultiValueMap<String,String> map = new LinkedMultiValueMap<>();
        map.add("productId","A04");
        map.add("loginNameArray","mwh004");
        map.add("beginTime","2018-12-01 00:00:00");
        map.add("endTime","2018-12-31 23:59:59");
        map.add("betMin","100");
        map.add("winMin","100");
        map.add("size","3");
        map.add("key","e72ce5c203b743c37da601de5a9dc91f");
        String responseString = mockMvc.perform(MockMvcRequestBuilders.get("/dcApi/getCustomerDynamic").params(map))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk()).andReturn().getResponse().getContentAsString();
        log.info(responseString);
    }
}