package com.gw.datacenter.cxf.client;

import com.gw.datacenter.common.util.JacksonUtil;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.pagainate.QueryResult;
import com.gw.datacenter.vo.pagainate.QueryResultWrapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * title: DataCenterApiUtil
 * description: TODO
 * author: Jair.H
 * date: 2018/11/8 15:36
 */
@Slf4j
public class DataCenterApiUtil {
    public static DataCenterApi init() {
        JaxWsProxyFactoryBean factory = new JaxWsProxyFactoryBean();
        factory.setServiceClass(DataCenterApi.class);
        factory.setAddress("http://localhost:8085/datacenter_api/GWDataCenterService/GWDataCenterService");
//        factory.setAddress("http://10.66.72.57:8081/datacenter/GWDataCenterService/GWDataCenterService");
//        factory.setAddress("http://date.pai9.net/GWDataCenterService/GWDataCenterService");
        Map<String, Object> properties = new HashMap<>();
        properties.put("set-jaxb-validation-event-handler", false);
        factory.setProperties(properties);
        DataCenterApi clientInstance = (DataCenterApi) factory.create();

        // 数据据中心接口，1分钟超时
        Client proxyClient = ClientProxy.getClient(clientInstance);
        HTTPConduit conduit = (HTTPConduit) proxyClient.getConduit();
        HTTPClientPolicy policy = new HTTPClientPolicy();
        policy.setConnectionTimeout(60000);
        policy.setReceiveTimeout(60000);
        conduit.setClient(policy);
        return clientInstance;
    }

    public static void printListResult(List result) {
        log.info("======================result");
        if (CollectionUtils.isNotEmpty(result)) {
            log.info("======================size:" + result.size());
            for (Object entity : result) {
                log.info(entity.toString());
            }
        }
    }

    public static void printQueryResult(QueryResult result) {
        log.info("======================result");
        if (result != null) {
            List<Object> list = result.getQueryResultList();
            if (CollectionUtils.isNotEmpty(list)) {
                log.info("======================size:" + list.size());
                for (Object entity : list) {
                    log.info(entity.toString());
                }
            }
        }
    }

    public static void printQueryResultWrapper(QueryResultWrapper result) {
        log.info("======================result");
        if (result != null) {
            QueryResult<Object> queryResult = result.getQueryResult();
            String[] utilArray = result.getUtilArray();
            if (queryResult != null) {
                List<Object> list = queryResult.getQueryResultList();
                if (CollectionUtils.isNotEmpty(list)) {
                    log.info("======================size:" + list.size());
                    for (Object entity : list) {
                        log.info(entity.toString());
                    }
                }
            }
            if (ArrayUtils.isNotEmpty(utilArray)) {
                log.info("======================utilArray length:" + utilArray.length);
                log.info(JacksonUtil.toJSon(utilArray));
            }
        }
    }

}
