package com.gw.datacenter.cxf.client;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.order.OrderEntity;
import com.gw.datacenter.vo.pagainate.QueryResult;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * title: GetAGQJDeskInfosTest
 * description: TODO
 * author: Jair.H
 * date: 2018/11/20 20:00
 */
@Slf4j
public class GetAGQJDeskInfosTest {

    public static void main(String[] args) {
        try {
            String productId = "A04";
            String beginTime = "2018-01-01 00:00:00";
            String endTime = "2018-11-26 23:59:59";
            String limit = "10";
            String key = getAGQJDeskInfosKey(productId, beginTime, endTime, limit);

            DataCenterApi client = DataCenterApiUtil.init();
            QueryResult<OrderEntity> result = client.getAGQJDeskInfos(productId, beginTime, endTime, limit, key);
            DataCenterApiUtil.printQueryResult(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static String getAGQJDeskInfosKey(String productId, String beginTime, String endTime, String limit) {
        StringBuffer sb = new StringBuffer();
        if (StringUtils.isNotBlank(productId)) {
            sb.append(productId);
        }
        if (StringUtils.isNotBlank(beginTime)) {
            sb.append(beginTime);
        }
        if (StringUtils.isNotBlank(endTime)) {
            sb.append(endTime);
        }
        if (StringUtils.isNotBlank(limit)) {
            sb.append(limit);
        }
        sb.append(UtilConstants.SUFFIX);
        return Md5Util.MD5Encode(sb.toString());
    }

}
