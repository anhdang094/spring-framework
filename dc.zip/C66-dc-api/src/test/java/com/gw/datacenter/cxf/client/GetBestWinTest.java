package com.gw.datacenter.cxf.client;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.order.OrderEntity;
import com.gw.datacenter.vo.pagainate.QueryResult;
import lombok.extern.slf4j.Slf4j;

/**
 * title: GetBestWinTest
 * description: TODO
 * author: Jair.H
 * date: 2018/11/16 13:55
 */
@Slf4j
public class GetBestWinTest {

    public static void main(String[] args) {
        try {
            String productId = "A04";
            String[] platformId = new String[]{"027", "003"};
            String beginTime = "2018-01-01 00:00:00";
            String endTime = "2018-11-30 23:59:59";
            Integer cusAmount = 10;
            Integer count = 150;
            String key = getBestWinKey(productId, beginTime, endTime, cusAmount, count);

            DataCenterApi client = DataCenterApiUtil.init();
            QueryResult<OrderEntity> result = client.getBestWin(productId, platformId, beginTime, endTime, cusAmount, count, key);
            DataCenterApiUtil.printQueryResult(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static String getBestWinKey(String productId, String beginTime, String endTime, Integer cusAmount, Integer count) {
        StringBuffer sb = new StringBuffer();
        sb.append(productId);
        //sb.append(platformId);
        sb.append(beginTime);
        sb.append(endTime);
        sb.append(cusAmount);
        sb.append(count);
        sb.append(UtilConstants.SUFFIX);
        return Md5Util.MD5Encode(sb.toString());
    }

}
