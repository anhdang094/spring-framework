package com.gw.datacenter.cxf.client;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.order.OrderEntity;
import com.gw.datacenter.vo.pagainate.QueryResult;
import lombok.extern.slf4j.Slf4j;

/**
 * title: GetBetHistoryTest
 * description: TODO
 * author: Jair.H
 * date: 2018/11/16 13:19
 */
@Slf4j
public class GetBetHistoryTest {

    public static void main(String[] args) {
        try {
            String platform[] = {"035", "006", "027"};
            String productId = "A04";
            String beginTime = "2016-01-01 00:00:00";
            String endTime = "2018-11-26 23:59:59";
            Integer flag = 1;
            Integer minCusAmount = 100;
            Integer multiple = 10;
            Integer maxRecode = 50;
            String key = getBetHistoryKey(productId, beginTime, endTime, flag, minCusAmount, multiple, maxRecode);

            DataCenterApi client = DataCenterApiUtil.init();
            QueryResult<OrderEntity> result = client.getBetHistory(productId, platform, beginTime, endTime, flag, minCusAmount, multiple, maxRecode, key);
            DataCenterApiUtil.printQueryResult(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static String getBetHistoryKey(String productId, String beginTime, String endTime, Integer flag, Integer minCusAmount, Integer multiple, Integer maxRecode) {
        StringBuffer sb = new StringBuffer();
        sb.append(productId);
        sb.append(beginTime);
        sb.append(endTime);
        sb.append(flag);
        sb.append(minCusAmount);
        sb.append(multiple);
        sb.append(maxRecode);
        sb.append(UtilConstants.SUFFIX);
        return Md5Util.MD5Encode(sb.toString());
    }

}
