package com.gw.datacenter.cxf.client;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.order.BetRecord;
import com.gw.datacenter.vo.pagainate.QueryResult;
import lombok.extern.slf4j.Slf4j;

/**
 * title: GetBetRecordTest
 * description: TODO
 * author: Jair.H
 * date: 2018/11/21 10:51
 */
@Slf4j
public class GetBetRecordTest {

    public static void main(String[] args) {
        try {
            String productId = "C07";
            String platformId = "004";
            String gameKind = "1";
            String loginName = "g8791603";
            String beginTime = "2019-03-06 00:00:00";
            String endTime = "2019-03-12 23:59:59";
            Integer pageNo = 1;
            Integer pageSize = 10;
            StringBuilder builder = new StringBuilder();
            builder.append(productId).append(platformId).append(gameKind).append(loginName).append(beginTime).append(endTime)
                    .append(pageSize).append(pageNo).append(UtilConstants.SUFFIX);
            String key = Md5Util.MD5Encode(builder.toString());

            DataCenterApi client = DataCenterApiUtil.init();
            QueryResult<BetRecord> result = client.getBetRecord(productId, platformId, gameKind, loginName, beginTime, endTime, pageSize, pageNo, key);
            DataCenterApiUtil.printQueryResult(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

}
