package com.gw.datacenter.cxf.client;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.pagainate.QueryResultWrapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * title: GetBoWinListTest
 * description: TODO
 * author: Jair.H
 * date: 2018/11/15 19:23
 */
@Slf4j
public class GetBoWinListTest {

    public static void main(String[] args) {
        try {
            String productId = "A04";
            String loginName = null;
            Integer pageNo = 1;
            Integer pageSize = 30;
            String beginTime = "2018-08-01 00:00:00";
            String endTime = "2018-11-26 23:59:59";
            String key = getBoWinListKey(productId, loginName, beginTime, endTime);

            DataCenterApi client = DataCenterApiUtil.init();
            QueryResultWrapper result = client.getBoWinList(productId, loginName, beginTime, endTime, pageNo, pageSize, key);
            DataCenterApiUtil.printQueryResultWrapper(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static String getBoWinListKey(String productId, String loginName, String beginTime, String endTime) {
        StringBuffer sb = new StringBuffer();
        if (StringUtils.isNotBlank(productId)) {
            sb.append(productId);
        }
        if (StringUtils.isNotBlank(loginName)) {
            sb.append(loginName);
        }
        if (StringUtils.isNotBlank(beginTime)) {
            sb.append(beginTime);
        }
        if (StringUtils.isNotBlank(endTime)) {
            sb.append(endTime);
        }
        sb.append(UtilConstants.SUFFIX);
        return Md5Util.MD5Encode(sb.toString());
    }
}
