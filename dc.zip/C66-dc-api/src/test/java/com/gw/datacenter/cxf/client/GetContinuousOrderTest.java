package com.gw.datacenter.cxf.client;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.order.ContinuousOrder;
import com.gw.datacenter.vo.pagainate.QueryResult;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * title: GetContinuousOrderTest
 * description: TODO
 * author: Jair.H
 * date: 2018/11/16 10:09
 */
@Slf4j
public class GetContinuousOrderTest {
    public static void main(String args[]) {
        try {
            String productId = "A04"; // not null
            String[] platformId = {"026"};// not null
            String beginTime = "2018-02-01 00:00:00";// not null
            String endTime = "2018-02-01 23:59:59";// not null
            Integer times = 1; //can not less than 0
            Integer minOrderAmount = 0;//can not less than 0
            String gameKind = "";
            String key = getContinuousOrderKey(productId, beginTime, endTime, times, minOrderAmount);

            DataCenterApi client = DataCenterApiUtil.init();
            QueryResult<ContinuousOrder> result = client.getContinuousOrder(productId, platformId, beginTime, endTime, gameKind, times, minOrderAmount, key);
            DataCenterApiUtil.printQueryResult(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static String getContinuousOrderKey(String productId, String beginTime, String endTime, Integer times, Integer minOrderAmount) {
        StringBuffer sb = new StringBuffer();
        if (StringUtils.isNotBlank(productId)) {
            sb.append(productId);
        }
        if (StringUtils.isNotBlank(beginTime)) {
            sb.append(beginTime);
        }
        if (StringUtils.isNotBlank(endTime)) {
            sb.append(endTime);
        }
        if (times != null) {
            sb.append(times);
        }
        if (minOrderAmount != null) {
            sb.append(minOrderAmount);
        }
        sb.append(UtilConstants.SUFFIX);
        return Md5Util.MD5Encode(sb.toString());
    }
}
