package com.gw.datacenter.cxf.client;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.order.OrderEntity;
import com.gw.datacenter.vo.pagainate.QueryResult;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * title: GetCustomerBetTimeTest
 * description: TODO
 * author: Jair.H
 * date: 2018/11/16 09:22
 */
@Slf4j
public class GetCustomerBetTimeTest {
    public static void main(String[] args) {
        try {
            String productId = "A04";
            String loginName = "mwh004";
            Integer type = 1;// type=1 get begin bet time type=2 get end bet time
            StringBuffer sb = new StringBuffer();
            String key = getCustomerBetTimeKey(productId, loginName, type, sb);

            DataCenterApi client = DataCenterApiUtil.init();
            QueryResult<OrderEntity> result = client.getCustomerBetTime(productId, loginName, type, key);
            DataCenterApiUtil.printQueryResult(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static String getCustomerBetTimeKey(String productId, String loginName, Integer type, StringBuffer sb) {
        if (StringUtils.isNotBlank(productId)) {
            sb.append(productId);
        }
        if (StringUtils.isNotBlank(loginName)) {
            sb.append(loginName);
        }
        if (type != null) {
            sb.append(type);
        }
        sb.append(UtilConstants.SUFFIX);
        return Md5Util.MD5Encode(sb.toString());
    }
}
