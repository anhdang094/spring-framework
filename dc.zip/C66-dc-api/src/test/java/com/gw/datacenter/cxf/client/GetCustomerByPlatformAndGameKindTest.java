package com.gw.datacenter.cxf.client;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.order.AccountTotalEntity;
import com.gw.datacenter.vo.order.PlatformGameKinds;
import com.gw.datacenter.vo.pagainate.QueryResult;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * @Description: GetCustomerByPlatformAndGameKindTest
 * @Author: Ziv.Y
 * @Date: 2019/1/28 20:14
 */
@Slf4j
public class GetCustomerByPlatformAndGameKindTest {

    public static void main(String[] args) {
        try {
            String productId = "A01";
            PlatformGameKinds[] platform = new PlatformGameKinds[2];
            platform[0] = new PlatformGameKinds();
            platform[0].setPlatformId("003");
            String[] gameKinds = {"5","3"};
            platform[0].setGameKinds(gameKinds);
            platform[1] = new PlatformGameKinds();
            platform[1].setPlatformId("026");
            String[] gameKinds2 = {"5","3"};
            platform[1].setGameKinds(gameKinds2);

            String beginTime = "2019-01-29 00:00:00";
            String endTime = "2019-01-29 23:59:59";
            StringBuffer sb = new StringBuffer();
            if (StringUtils.isNotBlank(productId)) {
                sb.append(productId);
            }
            if (StringUtils.isNotBlank(beginTime)) {
                sb.append(beginTime);
            }
            if (StringUtils.isNotBlank(endTime)) {
                sb.append(endTime);
            }
            sb.append(UtilConstants.SUFFIX);
            String key = Md5Util.MD5Encode(sb.toString());

            DataCenterApi client = DataCenterApiUtil.init();
            QueryResult<String> result = client.getCustomerByPlatformAndGameKind(productId, platform, beginTime, endTime, key);
            DataCenterApiUtil.printQueryResult(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

}
