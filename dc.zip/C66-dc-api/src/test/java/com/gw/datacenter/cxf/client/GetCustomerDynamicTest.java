package com.gw.datacenter.cxf.client;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.order.CustomerDynamicEntity;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.util.List;

/**
 * title: GetOrdersAGQJExceptionorTest
 * description: TODO
 * author: Jair.H
 * date: 2019/1/9 18:46
 */
@Slf4j
public class GetCustomerDynamicTest {

    public static void main(String[] args) {
        try {
            String productId = "A05";
            String beginTime = "2019-03-12 14:36:00";
            String endTime = "2019-03-12 15:06:00";
            String currency = "CNY";
            BigDecimal betMin = new BigDecimal("1000");
            BigDecimal winMin = new BigDecimal("100000");
            Integer size = 100;
            DataCenterApi client = DataCenterApiUtil.init();

            StringBuffer sb = new StringBuffer();
            sb.append(productId).append(beginTime).append(endTime).append(betMin).append(winMin).append(size).append(UtilConstants.SUFFIX);

            List<CustomerDynamicEntity> result = client.getCustomerDynamic(productId, beginTime, endTime, betMin, winMin, size, currency,Md5Util.MD5Encode(sb.toString()));
            DataCenterApiUtil.printListResult(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

}
