package com.gw.datacenter.cxf.client;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.order.UserWagerInfo;
import com.gw.datacenter.vo.pagainate.QueryResult;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * title: GetFirstBetListTest
 * description: TODO
 * author: Jair.H
 * date: 2018/11/20 13:51
 */
@Slf4j
public class GetFirstBetListTest {

    public static void main(String[] args) {
        try {
            String productId = "A04";
            Integer pageNo = 1;
            Integer pageSize = 30;
            String beginTime = "2018-06-01 00:00:00";
            String endTime = "2018-06-26 23:59:59";
            String key = getFirstBetListKey(productId, beginTime, endTime);

            DataCenterApi client = DataCenterApiUtil.init();
            QueryResult<UserWagerInfo> result = client.getFirstBetList(productId, beginTime, endTime, pageNo, pageSize, key);
            DataCenterApiUtil.printQueryResult(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static String getFirstBetListKey(String productId, String beginTime, String endTime) {
        StringBuffer sb = new StringBuffer();
        if (StringUtils.isNotBlank(productId)) {
            sb.append(productId);
        }
        if (StringUtils.isNotBlank(beginTime)) {
            sb.append(beginTime);
        }
        if (StringUtils.isNotBlank(endTime)) {
            sb.append(endTime);
        }
        sb.append(UtilConstants.SUFFIX);
        return Md5Util.MD5Encode(sb.toString());
    }

}
