package com.gw.datacenter.cxf.client;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.order.GameOrder;
import com.gw.datacenter.vo.pagainate.QueryResult;
import lombok.extern.slf4j.Slf4j;

/**
 * title: GetGameOrderByPageTest
 * description: TODO
 * author: Jair.H
 * date: 2018/11/21 13:37
 */
@Slf4j
public class GetGameOrderByPageTest {

    public static void main(String[] args) {
        try {
            String productId = "A04";
            String platformId = "003";
            String gameKind = "3";
            String gameType = null;
            String gameCode = null;
            String loginName = "mwh004";
            String beginTime = "2018-08-14 00:00:00";
            String endTime = "2018-10-31 23:59:59";
            Integer pageNo = 1;
            Integer pageSize = 10;
            String orderBy = null;
            StringBuilder builder = new StringBuilder();
            builder.append(productId).append(platformId).append(gameKind).append(loginName).append(gameType).append(gameCode)
                    .append(beginTime).append(endTime).append(pageSize).append(pageNo).append(orderBy).append(UtilConstants.SUFFIX);
            String key = Md5Util.MD5Encode(builder.toString());

            DataCenterApi client = DataCenterApiUtil.init();
            QueryResult<GameOrder> result = client.getGameOrderByPage(productId, platformId, gameKind, loginName, gameType, gameCode, beginTime, endTime, pageSize, pageNo, orderBy, key);
            DataCenterApiUtil.printQueryResult(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

}
