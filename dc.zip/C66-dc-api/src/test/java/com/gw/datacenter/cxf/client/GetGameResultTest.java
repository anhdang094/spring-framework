package com.gw.datacenter.cxf.client;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.gameresult.BaGameEntity;
import com.gw.datacenter.vo.pagainate.QueryResult;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * title: GetGameResultTest
 * description: TODO
 * author: Jair.H
 * date: 2018/11/20 22:02
 */
@Slf4j
public class GetGameResultTest {

    public static void main(String[] args) {
        try {
            String productId = "A04";
            String platformId = "003";
            String loginName = null;
            String videoId = null;
            String shoeCode = null;
            String beginTime = "2018-01-01 00:00:00";
            String endTime = "2018-11-30 23:59:59";
            String orderBy = null;
            Integer pageNo = 1;
            Integer pageSize = 5;
            String[] gameCode = null;
            String key = getGameResultKey(productId, platformId, loginName, videoId, shoeCode, beginTime, endTime, pageNo, pageSize);

            DataCenterApi client = DataCenterApiUtil.init();
            QueryResult<BaGameEntity> result = client.getGameResult(productId, platformId, loginName, videoId, shoeCode, beginTime, endTime, orderBy, pageNo, pageSize, key, gameCode);
            DataCenterApiUtil.printQueryResult(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static String getGameResultKey(String productId, String platformId, String loginName, String videoId, String shoeCode, String beginTime, String endTime, Integer pageNo, Integer pageSize) {
        StringBuilder sb = new StringBuilder();
        if (StringUtils.isNotBlank(productId)) {
            sb.append(productId);
        }
        sb.append(platformId);
        if (StringUtils.isNotBlank(loginName)) {
            sb.append(loginName);
        }
        if (StringUtils.isNotBlank(videoId)) {
            sb.append(videoId);
        }
        if (StringUtils.isNotBlank(shoeCode)) {
            sb.append(shoeCode);
        }
        if (StringUtils.isNotBlank(beginTime)) {
            sb.append(beginTime);
        }
        if (StringUtils.isNotBlank(endTime)) {
            sb.append(endTime);
        }
        if (pageNo != null) {
            sb.append(pageNo);
        }
        if (pageSize != null) {
            sb.append(pageSize);
        }
        sb.append(UtilConstants.SUFFIX);
        return Md5Util.MD5Encode(sb.toString());
    }

}
