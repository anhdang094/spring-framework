package com.gw.datacenter.cxf.client;

public class GetGameTypeAndPlayType {
}
