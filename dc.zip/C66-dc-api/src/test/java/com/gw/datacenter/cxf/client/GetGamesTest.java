package com.gw.datacenter.cxf.client;

import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.order.Game;
import com.gw.datacenter.vo.pagainate.QueryResult;
import lombok.extern.slf4j.Slf4j;

/**
 * title: GetOrderSummaryTest
 * description: TODO
 * author: Jair.H
 * date: 2018/11/21 13:55
 */
@Slf4j
public class GetGamesTest {

    public static void main(String[] args) {
        try {
            DataCenterApi client = DataCenterApiUtil.init();
            QueryResult<Game> result = client.getGames();
            DataCenterApiUtil.printQueryResult(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

}
