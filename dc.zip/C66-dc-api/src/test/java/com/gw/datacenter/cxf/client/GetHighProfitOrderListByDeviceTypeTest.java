package com.gw.datacenter.cxf.client;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.order.OrderEntity;
import com.gw.datacenter.vo.pagainate.QueryResult;
import lombok.extern.slf4j.Slf4j;

/**
 * @Description: 
 * @Author: Ziv.Y
 * @Date: 2019/2/12 19:01
 */
@Slf4j
public class GetHighProfitOrderListByDeviceTypeTest {

    public static void main(String[] args) {
        try {
            String productId = "A01";
            String[] platformId = new String[]{"026"};//null;//new String[]{"026", "003"};
            String[] gameKind = null;//new String[]{"1", "2", "3", "4", "5", "6", "7", "8", "9", "12", "15"};
            String beginTime = "2019-01-17 00:00:00";
            String endTime = "2019-01-17 23:59:59";
            Integer minBetAmount = 0;
            Integer cusAmount = 0;
            Integer multiple = 0;
            Integer pageNo = 1;
            Integer pageSize = 10;
            Integer deviceType = null;
            StringBuffer sb = new StringBuffer();

            sb.append(productId)
                    .append(beginTime)//2016-08-05 00:00:00
                    .append(endTime)//2016-08-05 14:00:09
                    .append(minBetAmount == null ? "" : String.valueOf(minBetAmount.intValue()))//1
                    .append(cusAmount == null ? "" : String.valueOf(cusAmount.intValue()))//1
                    .append(multiple == null ? "" : String.valueOf(multiple.intValue()))//3
                    .append(pageNo.toString())//1
                    .append(pageSize.toString());//1000
            sb.append(UtilConstants.SUFFIX);//feas!#%
            String key = Md5Util.MD5Encode(sb.toString());

            DataCenterApi client = DataCenterApiUtil.init();
            QueryResult<OrderEntity> result = client.getHighProfitOrderListByDeviceType(productId, platformId, gameKind, beginTime, endTime,
                    minBetAmount, cusAmount, multiple, pageNo, pageSize, key, deviceType);
            DataCenterApiUtil.printQueryResult(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

}
