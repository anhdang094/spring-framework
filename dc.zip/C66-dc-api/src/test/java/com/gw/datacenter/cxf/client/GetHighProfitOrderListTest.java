package com.gw.datacenter.cxf.client;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.order.OrderEntity;
import com.gw.datacenter.vo.pagainate.QueryResult;
import lombok.extern.slf4j.Slf4j;

/**
 * title: GetHighProfitOrderListTest
 * description: TODO
 * author: Jair.H
 * date: 2018/11/16 11:13
 */
@Slf4j
public class GetHighProfitOrderListTest {
    public static void main(String args[]) {
        try {
            String platform[] = {"036", "008", "035", "009", "034", "004", "013", "024", "006", "025", "012", "007", "026", "017", "018", "027", "001", "002", "003", "010", "020", "031"};
            String gameKind[] = {"3", "5"};
            String productId = "A04";
            String beginTime = "2013-01-01 00:00:00";
            String endTime = "2018-12-03 23:59:59";
            Integer cusAmount = 0;
            Integer multiple = 5;
            Integer pageNo = 1;
            Integer pageSize = 5;
            String key = getHighProfitOrderListKey(productId, beginTime, endTime, cusAmount, multiple, pageNo, pageSize);

            DataCenterApi client = DataCenterApiUtil.init();
            QueryResult<OrderEntity> result = client.getHighProfitOrderList(productId, platform, gameKind, beginTime, endTime, cusAmount, multiple, pageNo, pageSize, key);
            DataCenterApiUtil.printQueryResult(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static String getHighProfitOrderListKey(String productId, String beginTime, String endTime, Integer cusAmount, Integer multiple, Integer pageNo, Integer pageSize) {
        StringBuffer sb = new StringBuffer();
        if (productId != null) {
            sb.append(productId);
        }
        if (beginTime != null) {
            sb.append(beginTime);
        }
        if (endTime != null) {
            sb.append(endTime);
        }
        if (cusAmount != null) {
            sb.append(cusAmount);
        }
        if (multiple != null) {
            sb.append(multiple);
        }
        if (pageNo != null) {
            sb.append(pageNo);
        }
        if (pageSize != null) {
            sb.append(pageSize);
        }
        sb.append(UtilConstants.SUFFIX);
        return Md5Util.MD5Encode(sb.toString());
    }
}
