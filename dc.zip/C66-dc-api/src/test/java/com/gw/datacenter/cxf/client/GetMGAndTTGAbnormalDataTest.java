package com.gw.datacenter.cxf.client;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.order.AccountTotalEntity;
import com.gw.datacenter.vo.order.MGAndTTGAbnormalEntity;
import com.gw.datacenter.vo.pagainate.QueryResult;
import lombok.extern.slf4j.Slf4j;

/**
 * title: GetMGAndTTGAbnormalDataTest
 * description: TODO
 * author: Jair.H
 * date: 2018/12/26 15:11
 */
@Slf4j
public class GetMGAndTTGAbnormalDataTest {
    public static void main(String[] args) {
        try {
            String loginName = "fmarko";
            String productId = "A03";
            String beginTime = "2016-11-01 00:00:00";
            String endTime = "2018-11-07 23:59:59";
            String key = getMGAndTTGAbnormalDataKey(loginName, productId, beginTime, endTime);
            DataCenterApi client = DataCenterApiUtil.init();
            QueryResult<MGAndTTGAbnormalEntity> result = client.getMGAndTTGAbnormalData(loginName,productId,beginTime, endTime, 1, 30, key);
            DataCenterApiUtil.printQueryResult(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static String getMGAndTTGAbnormalDataKey(String loginName, String productId, String beginTime, String endTime) {
        StringBuffer sb = new StringBuffer();
        if(loginName != null){
            sb.append(loginName);
        }
        if(productId != null){
            sb.append(productId);
        }
        if(beginTime != null){
            sb.append(beginTime);
        }
        if(endTime != null){
            sb.append(endTime);
        }
        sb.append(UtilConstants.SUFFIX);
        return Md5Util.MD5Encode(sb.toString());
    }
}
