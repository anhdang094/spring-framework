package com.gw.datacenter.cxf.client;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.order.AccountTotalEntity;
import com.gw.datacenter.vo.pagainate.QueryResult;
import lombok.extern.slf4j.Slf4j;

/**
 * title: GetMaxEffectiveBettingTest
 * description: TODO
 * author: Jair.H
 * date: 2018/11/14 17:35
 */
@Slf4j
public class GetMaxEffectiveBettingTest {
    public static void main(String[] args) {
        try {
            String productId = "A04";
            String loginNameArray = null;
            Integer resultType = 3;
            String beginTime = "2018-08-01 00:00:00";
            String endTime = "2018-08-14 23:59:59";
            String key = getMaxEffectiveBettingAmountKey(productId, loginNameArray, resultType, beginTime, endTime);

            DataCenterApi client = DataCenterApiUtil.init();
            QueryResult<AccountTotalEntity> result = client.getMaxEffectiveBettingAmount(productId, loginNameArray, resultType, beginTime, endTime, 1, 1000, key);
            DataCenterApiUtil.printQueryResult(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static String getMaxEffectiveBettingAmountKey(String productId, String loginNameArray, Integer resultType, String beginTime, String endTime) {
        StringBuffer sb = new StringBuffer();
        if (productId != null && productId.trim() != "") {
            sb.append(productId);
        }
        if (loginNameArray != null && loginNameArray != "") {
            sb.append(loginNameArray);
        }
        if (resultType != null) {
            sb.append(resultType);
        }
        if (beginTime != null && beginTime != "") {
            sb.append(beginTime);
        }
        if (endTime != null && endTime != "") {
            sb.append(endTime);
        }
        sb.append(UtilConstants.SUFFIX);
        return Md5Util.MD5Encode(sb.toString());
    }
}
