package com.gw.datacenter.cxf.client;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.gameresult.PokerShoeStatisticEntity;
import com.gw.datacenter.vo.pagainate.QueryResult;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * title: GetMaxValueGroupByShoecodeTest
 * description: TODO
 * author: Jair.H
 * date: 2018/11/20 20:50
 */
@Slf4j
public class GetMaxValueGroupByShoecodeTest {

    public static void main(String[] args) {
        try {
            String productId = "A04";
            String platformId = "003";
            String loginName = null;
            String videoId = null;
            String shoeCode = null;
            String beginTime = "2018-01-01 00:00:00";
            String endTime = "2018-11-30 23:59:59";
            String orderBy = null;
            Integer pageNo = 1;
            Integer pageSize = 30;
            String[] gameType = null;
            String key = getMaxValueGroupByShoecodeKey(productId, platformId, loginName, videoId, shoeCode, beginTime, endTime, pageNo, pageSize);

            DataCenterApi client = DataCenterApiUtil.init();
            QueryResult<PokerShoeStatisticEntity> result = client.getMaxValueGroupByShoecode(productId, platformId, loginName, videoId, shoeCode, beginTime, endTime, orderBy, pageNo, pageSize, null,gameType,null);
            DataCenterApiUtil.printQueryResult(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static String getMaxValueGroupByShoecodeKey(String productId, String platformId, String loginName, String videoId, String shoeCode, String beginTime, String endTime, Integer pageNo, Integer pageSize) {
        StringBuilder sb = new StringBuilder();
        sb.append(productId);
        sb.append(platformId);
        if (StringUtils.isNotBlank(loginName)) {
            sb.append(loginName);
        }
        if (StringUtils.isNotBlank(videoId)) {
            sb.append(videoId);
        }
        if (StringUtils.isNotBlank(shoeCode)) {
            sb.append(shoeCode);
        }
        sb.append(beginTime);
        sb.append(endTime);
        sb.append(pageNo);
        sb.append(pageSize);
        sb.append(UtilConstants.SUFFIX);
        return Md5Util.MD5Encode(sb.toString());
    }

}
