package com.gw.datacenter.cxf.client;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.order.MonthlyWeeklyEffectiveBetAmountEntity;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.util.List;

/**
 * title: GetMonthlyAndWeeklyValidAmountTest
 * description: TODO
 * author: Jair.H
 * date: 2018/11/15 20:42
 */
@Slf4j
public class GetMonthlyAndWeeklyValidAmountTest {
    public static void main(String[] args) {
        try {
            String productId = "A04";
            String loginNameArray = "mwh004";
            BigDecimal amount = BigDecimal.ZERO;
            String weekBeginTime = "2018-08-14 00:00:00";
            String weekEndTime = "2018-08-15 23:59:59";
            String key = getMonthlyAndWeeklyValidAmountKey(productId, loginNameArray, amount);

            DataCenterApi client = DataCenterApiUtil.init();
            List<MonthlyWeeklyEffectiveBetAmountEntity> result = client.getMonthlyAndWeeklyValidAmount(productId, loginNameArray, amount, weekBeginTime, weekEndTime, "", "", key);
            DataCenterApiUtil.printListResult(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static String getMonthlyAndWeeklyValidAmountKey(String productId, String loginNameArray, BigDecimal amount) {
        StringBuffer sb = new StringBuffer();
        if (StringUtils.isNotBlank(productId)) {
            sb.append(productId);
        }
        if (StringUtils.isNotBlank(loginNameArray)) {
            sb.append(loginNameArray);
        }
        if (amount != null) {
            sb.append(amount);
        }
        sb.append(UtilConstants.SUFFIX);
        return Md5Util.MD5Encode(sb.toString());
    }
}
