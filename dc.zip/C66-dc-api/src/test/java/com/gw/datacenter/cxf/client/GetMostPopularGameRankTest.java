package com.gw.datacenter.cxf.client;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.order.PopularGame;
import com.gw.datacenter.vo.pagainate.QueryResult;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * title: GetMostPopularGameRankTest
 * description: TODO
 * author: Jair.H
 * date: 2018/11/20 22:35
 */
@Slf4j
public class GetMostPopularGameRankTest {

    public static void main(String[] args) {
        try {
            String productId = "A04";
            String[] platforms = new String[]{"003"};
            Integer top = 10;
            String gameKind = "3";
            String beginTime = "2017-01-01 00:00:00";
            String endTime = "2018-11-17 00:00:00";
            StringBuilder builder = new StringBuilder();
            builder.append(productId)
                    .append(top)
                    .append(StringUtils.join(platforms, ","))
                    .append(gameKind)
                    .append(beginTime)
                    .append(endTime)
                    .append(UtilConstants.SUFFIX);
            String key = Md5Util.MD5Encode(builder.toString());

            DataCenterApi client = DataCenterApiUtil.init();
            QueryResult<PopularGame> result = client.getMostPopularGameRank(productId, platforms, top, key, gameKind, beginTime, endTime);
            DataCenterApiUtil.printQueryResult(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

    }
}
