package com.gw.datacenter.cxf.client;

import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.order.OrderEntity;
import com.gw.datacenter.vo.pagainate.QueryResult;
import lombok.extern.slf4j.Slf4j;

/**
 * title: GetOrderByMultipleTest
 * description: TODO
 * author: Jair.H
 * date: 2018/11/19 13:42
 */

@Slf4j
public class GetOrderByMultipleTest {

    public static void main(String args[]) {
        try {
            String productId = "A04";// not null
            String[] platformId = "027;035;039;003;".split(";");
            String beginTime = "2018-01-01 00:00:00";
            String endTime = "2018-11-30 23:59:59";

            DataCenterApi client = DataCenterApiUtil.init();
            QueryResult<OrderEntity> result = client.getOrderByMultipleAndValidAccount2(productId, platformId, beginTime, endTime, new OrderEntity(), 0, 1, 20);
            DataCenterApiUtil.printQueryResult(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

}
