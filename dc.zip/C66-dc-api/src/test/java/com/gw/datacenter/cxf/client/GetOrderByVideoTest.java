package com.gw.datacenter.cxf.client;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.order.GameOrder;
import com.gw.datacenter.vo.pagainate.QueryResult;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * title: GetOrderSummaryTest
 * description: TODO
 * author: Jair.H
 * date: 2018/11/21 13:55
 */
@Slf4j
public class GetOrderByVideoTest {

    public static void main(String[] args) {
        try {
            String productId = "A04";
            String platformId = "003";
            String[] loginName = null;
            String[] videoId = {"5342"};
            String beginTime = "2018-08-14 00:00:00";
            String endTime = "2018-10-31 23:59:59";
            StringBuilder builder = new StringBuilder();
            String loginNames = StringUtils.join(loginName);
            String videoIds = StringUtils.join(videoId);
            builder.append(productId).append(platformId).append(loginNames).append(videoIds).append(beginTime).append(endTime).append(UtilConstants.SUFFIX);
            String key = Md5Util.MD5Encode(builder.toString());

            DataCenterApi client = DataCenterApiUtil.init();
            QueryResult<GameOrder> result = client.getOrderByVideo(productId, platformId, loginName, videoId, beginTime, endTime, key);
            DataCenterApiUtil.printQueryResult(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

}
