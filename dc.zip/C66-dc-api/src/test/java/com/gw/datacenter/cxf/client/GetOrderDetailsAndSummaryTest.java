package com.gw.datacenter.cxf.client;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.pagainate.QueryResultWrapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * title: GetOrderDetailsAndSummaryTest
 * author: Jair.H
 * date: 2018/11/15 15:19
 */
@Slf4j
public class GetOrderDetailsAndSummaryTest {

    public static void main(String args[]) {
        try {
            String productId = "A04";
            String loginName = "m201409";
            String gmCode = "GC00616B030AS";
            Integer pageNo = 1;
            Integer pageSize = 30;
            String beginTime = "2016-11-03 00:00:00";
            String endTime = "2016-11-03 23:59:59";
            String key = getOrderDetailsAndSummaryKey(productId, loginName, gmCode, beginTime, endTime);

            DataCenterApi client = DataCenterApiUtil.init();
            QueryResultWrapper result = client.getOrderDetailsAndSummaryByGmCode(productId, loginName, gmCode, beginTime, endTime, pageNo, pageSize, key);
            DataCenterApiUtil.printQueryResultWrapper(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static String getOrderDetailsAndSummaryKey(String productId, String loginName, String gmCode, String beginTime, String endTime) {
        StringBuffer sb = new StringBuffer();
        if (StringUtils.isNotBlank(productId)) {
            sb.append(productId);
        }
        if (StringUtils.isNotBlank(loginName)) {
            sb.append(loginName);
        }
        if (StringUtils.isNotBlank(gmCode)) {
            sb.append(gmCode);
        }
        if (StringUtils.isNotBlank(beginTime)) {
            sb.append(beginTime);
        }
        if (StringUtils.isNotBlank(endTime)) {
            sb.append(endTime);
        }
        sb.append(UtilConstants.SUFFIX);
        return Md5Util.MD5Encode(sb.toString());
    }
}
