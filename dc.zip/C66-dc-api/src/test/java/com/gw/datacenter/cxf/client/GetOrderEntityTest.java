package com.gw.datacenter.cxf.client;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.order.OrderEntity;
import com.gw.datacenter.vo.pagainate.QueryResult;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * title: GetValidAmountByTypeTest
 * description: TODO
 * author: Jair.H
 * date: 2018/11/9 09:01
 */
@Slf4j
public class GetOrderEntityTest {

    public static void main(String args[]) {
        try {
            String productId = "A02";// not null
            String[] platformId = "027;035;039;043;".split(";");
            String validAccount = "0";
            String loginNameArray = "cmmmsun1986";// String loginNameArray = "gh57716";
            String beginTime = "2016-07-05 00:00:00";
            String endTime = "2016-07-13 23:59:59";
            Integer gameKind = 5;
            String key = getOrderEntityKey(productId, validAccount, loginNameArray, beginTime, endTime);

            DataCenterApi client = DataCenterApiUtil.init();
            QueryResult<OrderEntity> result = client.getOrderEntity(productId, platformId, validAccount, null, loginNameArray,
                    beginTime, endTime, gameKind, 1, 20, key);
            DataCenterApiUtil.printQueryResult(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static String getOrderEntityKey(String productId, String validAccount, String loginNameArray, String beginTime, String endTime) {
        StringBuffer sb = new StringBuffer();
        if (productId != null) {
            sb.append(productId);
        }
        if (validAccount != null) {
            sb.append(validAccount);
        }
        if (loginNameArray != null) {
            sb.append(loginNameArray);
        }
        if (beginTime != null) {
            sb.append(beginTime);
        }
        if (endTime != null) {
            sb.append(endTime);
        }
        sb.append(UtilConstants.SUFFIX);
        return Md5Util.MD5Encode(sb.toString());
    }

    private static String getValidAmountKey(String productId, String loginNameArray, String beginTime, String endTime) {
        StringBuffer sb = new StringBuffer();
        if (StringUtils.isNotBlank(productId)) {
            sb.append(productId);
        }
        if (StringUtils.isNotBlank(loginNameArray)) {
            sb.append(loginNameArray);
        }
        if (StringUtils.isNotBlank(beginTime)) {
            sb.append(beginTime);
        }
        if (StringUtils.isNotBlank(endTime)) {
            sb.append(endTime);
        }
        sb.append(UtilConstants.SUFFIX);
        return sb.toString();
    }
}
