package com.gw.datacenter.cxf.client;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.order.OrderEntity;
import com.gw.datacenter.vo.pagainate.QueryResult;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * title: GetOrderListByProfitTest
 * description: TODO
 * author: Jair.H
 * date: 2018/11/16 10:58
 */
@Slf4j
public class GetOrderListByProfitTest {
    public static void main(String args[]) {
        try {
            String platform[] = {"036", "008", "035", "009", "034", "004", "013", "024", "006", "025", "012", "007", "026", "017", "018", "027", "001", "002", "003", "010", "020", "031"};
            String productId = "A02";
            String beginTime = "2013-01-01 00:00:00";
            String endTime = "2014-06-03 23:59:59";
            Integer multiple = 5;
            Integer pageNo = 1;
            Integer pageSize = 5;
            String key = getOrderListByProfitKey(productId, beginTime, endTime, multiple, pageNo, pageSize);

            DataCenterApi client = DataCenterApiUtil.init();
            QueryResult<OrderEntity> result = client.getOrderListByProfit(productId, platform, beginTime, endTime, multiple, pageNo, pageSize, key);
            DataCenterApiUtil.printQueryResult(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static String getOrderListByProfitKey(String productId, String beginTime, String endTime, Integer multiple, Integer pageNo, Integer pageSize) {
        StringBuffer sb = new StringBuffer();
        if (StringUtils.isNotBlank(productId)) {
            sb.append(productId);
        }
        if (StringUtils.isNotBlank(beginTime)) {
            sb.append(beginTime);
        }
        if (StringUtils.isNotBlank(endTime)) {
            sb.append(endTime);
        }
        if (multiple != null) {
            sb.append(multiple);
        }
        if (pageNo != null) {
            sb.append(pageNo);
        }
        if (pageSize != null) {
            sb.append(pageSize);
        }
        sb.append(UtilConstants.SUFFIX);
        return Md5Util.MD5Encode(sb.toString());
    }
}
