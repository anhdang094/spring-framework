package com.gw.datacenter.cxf.client;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.order.AccountTotalEntity;
import com.gw.datacenter.vo.pagainate.QueryResult;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * title: GetOrderSummaryGroupByPidUsernameTest
 * description: TODO
 * author: Jair.H
 * date: 2018/11/21 14:35
 */
@Slf4j
public class GetOrderSummaryGroupByPidPlatIdUnTest {

    public static void main(String[] args) {
        try {
            String productId = "A04";
            String[] platformArray = null;
            String[] loginNameArray = null;
            String[] gameKindArray = null;
            String beginDate = "2018-08-14";
            String endDate = "2018-10-31";
            Integer pageNo = 1;
            Integer pageSize = 10;
            String currency = "CNY";
            StringBuffer sb = new StringBuffer();
            if (StringUtils.isNotBlank(productId)) {
                sb.append(productId);
            }
            if (ArrayUtils.isNotEmpty(loginNameArray)) {
                sb.append(StringUtils.join(loginNameArray, ","));
            }
            if (StringUtils.isNotBlank(beginDate)) {
                sb.append(beginDate);
            }
            if (StringUtils.isNotBlank(endDate)) {
                sb.append(endDate);
            }
            sb.append(UtilConstants.SUFFIX);
            String key = Md5Util.MD5Encode(sb.toString());

            DataCenterApi client = DataCenterApiUtil.init();
            QueryResult<AccountTotalEntity> result = client.getOrderSummaryGroupByPidPlatIdUn(productId, platformArray, loginNameArray, gameKindArray, beginDate, endDate, pageNo, pageSize, key, currency);
            DataCenterApiUtil.printQueryResult(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

}
