package com.gw.datacenter.cxf.client;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.order.AccountTotalEntity;
import com.gw.datacenter.vo.pagainate.QueryResult;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

import javax.jws.WebParam;

/**
 * title: GetOrderSummaryGroupByPidUsernameTest
 * description: TODO
 * author: Jair.H
 * date: 2018/11/21 14:35
 */
@Slf4j
public class GetOrderSummaryGroupByPidUsername4ActivityListTest {

    public static void main(String[] args) {
        try {
            String productId = "B01";
            String[] platformId = null;
            String[] gameKind = null;
            String[] gameType = {"BAC"};
            String beginDate = "2019-10-01";
            String endDate = "2019-10-31";
            Long minAmount = 10l;
            Integer rank = 10;
            String currency = "CNY";
            String fieldsOrder = "totalbettimes";//totalbetamount、totalvalidamount、totalremainamount、totalwinlostamount、totalbettimes

            StringBuffer sb = new StringBuffer();
            if (StringUtils.isNotBlank(productId)) {
                sb.append(productId);
            }
            if (StringUtils.isNotBlank(beginDate)) {
                sb.append(beginDate);
            }
            if (StringUtils.isNotBlank(endDate)) {
                sb.append(endDate);
            }
            if (rank != null) {
                sb.append(rank);
            }
            if (StringUtils.isNotBlank(currency)) {
                sb.append(currency);
            }
            sb.append(UtilConstants.SUFFIX);
            String key = Md5Util.MD5Encode(sb.toString());

            DataCenterApi client = DataCenterApiUtil.init();
            QueryResult<AccountTotalEntity> result = client.getOrderSummaryGroupByPidUsername4ActivityList(productId, platformId, gameKind,gameType, beginDate, endDate, minAmount, currency, rank, fieldsOrder, key);
            DataCenterApiUtil.printQueryResult(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

}
