package com.gw.datacenter.cxf.client;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.DateUtil;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.order.OrderSummary;
import com.gw.datacenter.vo.pagainate.QueryResult;
import lombok.extern.slf4j.Slf4j;

/**
 * title: GetOrderSummaryTest
 * description: TODO
 * author: Jair.H
 * date: 2018/11/21 13:55
 */
@Slf4j
public class GetOrderSummaryTest {

    public static void main(String[] args) {
        try {
            long updateTime = DateUtil.parseSecond("2018-11-03 00:00:00").getTime();
            Integer pageNo = 1;
            Integer pageSize = 10;
            StringBuilder builder = new StringBuilder();
            builder.append(updateTime).append(pageSize).append(pageNo).append(UtilConstants.SUFFIX);
            String key = Md5Util.MD5Encode(builder.toString());

            DataCenterApi client = DataCenterApiUtil.init();
            QueryResult<OrderSummary> result = client.getOrderSummary(updateTime, pageSize, pageNo, key);
            DataCenterApiUtil.printQueryResult(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

}
