package com.gw.datacenter.cxf.client;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.order.OrderAGQJExceptionor;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

/**
 * title: GetOrdersAGQJExceptionorTest
 * description: TODO
 * author: Jair.H
 * date: 2019/1/9 18:46
 */
@Slf4j
public class GetOrdersAGQJExceptionorTest {

    public static void main(String[] args) {
        try {
            String productId = "002";
            String loginName = "002test206";
            String beginTime = "2018-12-01 00:00:00";
            String endTime = "2018-12-31 23:59:59";
            String key = getOrdersAGQJExceptionorKey(productId, loginName, beginTime, endTime);
            DataCenterApi client = DataCenterApiUtil.init();
            List<OrderAGQJExceptionor> result = client.getOrdersAGQJExceptionor(productId, loginName, beginTime, endTime, key);
            DataCenterApiUtil.printListResult(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static String getOrdersAGQJExceptionorKey(String productId, String loginName, String beginTime, String endTime) {
        StringBuffer sb = new StringBuffer();
        sb.append(productId);
        sb.append(loginName);
        sb.append(beginTime);
        sb.append(endTime);
        sb.append(UtilConstants.SUFFIX);
        return Md5Util.MD5Encode(sb.toString());
    }
}
