package com.gw.datacenter.cxf.client;

import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.order.AccountTotalEntity;
import com.gw.datacenter.vo.order.PlatformGamekind;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * title: GetOrdersRemainGroupListTest
 * description: TODO
 * author: Jair.H
 * date: 2018/12/29 10:16
 */
@Slf4j
public class GetOrdersRemainGroupListTest {
    public static void main(String args[]) {
        try {
            String productId = "A02";// not null
            String[] loginNameArray = {"cwh139", "mwh002"};
            List<PlatformGamekind> platformAndGameKindList = new ArrayList<>();
            PlatformGamekind plaf1 = new PlatformGamekind();
            plaf1.setPlatform("006");
            plaf1.setGameKind("1,3,5");
            platformAndGameKindList.add(plaf1);
            PlatformGamekind plaf2 = new PlatformGamekind();
            plaf2.setPlatform("026");
            plaf2.setGameKind("1,3,5");
            platformAndGameKindList.add(plaf2);
            // can be null and one or more loginNames
            String beginTime = "2018-05-10 10:10:10";// not null
            String endTime = "2018-09-10 10:10:10";// not null

            //运营环境
//            String productId = "A05";// not null
//            String[] loginNameArray = {"tcp222", "tpate11"};
//            List<PlatformGamekind> platformAndGameKindList = new ArrayList<>();
//            PlatformGamekind plaf1 = new PlatformGamekind();
//            plaf1.setPlatform("003");
//            plaf1.setGameKind("3,5");
//            platformAndGameKindList.add(plaf1);
//            PlatformGamekind plaf2 = new PlatformGamekind();
//            plaf2.setPlatform("026");
//            plaf2.setGameKind("3,8");
//            platformAndGameKindList.add(plaf2);
//            // can be null and one or more loginNames
//            String beginTime = "2018-12-28 00:00:00";// not null
//            String endTime = "2018-12-28 23:59:59";// not null

            DataCenterApi client = DataCenterApiUtil.init();
            List<AccountTotalEntity> list = client.getOrdersRemainGroupList(productId, loginNameArray, platformAndGameKindList, beginTime, endTime);
            if (CollectionUtils.isNotEmpty(list)) {
                log.info("======================size:" + list.size());
                for (Object entity : list) {
                    log.info(entity.toString());
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
