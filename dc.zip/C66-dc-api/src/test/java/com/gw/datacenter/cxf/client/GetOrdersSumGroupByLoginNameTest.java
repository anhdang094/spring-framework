package com.gw.datacenter.cxf.client;

import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.order.AccountTotalEntity;
import com.gw.datacenter.vo.pagainate.QueryResult;
import lombok.extern.slf4j.Slf4j;

/**
 * title: GetOrdersSumGroupByLoginNameTest
 * description: TODO
 * author: Jair.H
 * date: 2018/11/21 14:49
 */
@Slf4j
public class GetOrdersSumGroupByLoginNameTest {

    public static void main(String[] args) {
        try {
            String productId = "A04";
            String[] platformArray = null;
            String[] loginNameArray = null;
            String[] gameKindArray = null;
            String beginDate = "2018-08-14";
            String endDate = "2018-10-31";
            Integer pageNo = 1;
            Integer pageSize = 10;

            DataCenterApi client = DataCenterApiUtil.init();
            QueryResult<AccountTotalEntity> result = client.getOrdersSumGroupByLoginName(productId, platformArray, loginNameArray, gameKindArray, beginDate, endDate, pageNo, pageSize);
            DataCenterApiUtil.printQueryResult(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

}
