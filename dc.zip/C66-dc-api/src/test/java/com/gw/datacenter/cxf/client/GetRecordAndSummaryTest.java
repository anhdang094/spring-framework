package com.gw.datacenter.cxf.client;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.pagainate.QueryResultWrapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * title: GetRecordTest
 * description: TODO
 * author: Jair.H
 * date: 2018/11/19 15:47
 */
@Slf4j
public class GetRecordAndSummaryTest {

    public static void main(String[] args) {
        try {
            String productId = "A04";
            String platformId[] = {"003"};
            String[] loginName = null;
            String[] gameKind = new String[]{"1", "3"};
            String beginTime = "2018-01-01 00:00:00";
            String endTime = "2018-11-30 23:59:59";
            String[] gameCode = null;
            String settledType = null;
            Integer minBetAmount = null;
            Integer minCusAmount = null;
            Integer minMultiple = null;
            Integer remainAmount = null;
            String fieldsOrder = null;
            String[] gameType = null;
            Integer pageNo = 1;
            Integer pageSize = 300;
            String key = getRecordAndSummaryKey(productId, platformId, loginName, gameKind, beginTime, endTime, settledType, minBetAmount, minCusAmount, minMultiple, fieldsOrder, pageNo, pageSize);

            DataCenterApi client = DataCenterApiUtil.init();
            QueryResultWrapper result = client.getRecordAndSummary(productId, platformId, loginName, gameKind, beginTime, endTime, settledType, minBetAmount, minCusAmount, minMultiple, fieldsOrder, pageNo, pageSize, key, gameType, gameCode,remainAmount,"CNY");
            DataCenterApiUtil.printQueryResultWrapper(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static String getRecordAndSummaryKey(String productId, String[] platformId, String[] loginName, String[] gameKind, String beginTime, String endTime, String settledType, Integer minBetAmount, Integer minCusAmount, Integer minMultiple, String fieldsOrder, Integer pageNo, Integer pageSize) {
        StringBuilder paramStr = new StringBuilder().append(productId).append(StringUtils.join(platformId, ","));
        paramStr.append(loginName == null ? "" : StringUtils.join(loginName, ",")).append(StringUtils.join(gameKind, ",")).append(beginTime);
        paramStr.append(endTime).append(StringUtils.isNotBlank(settledType) ? settledType : "").append(minBetAmount == null ? "" : String.valueOf(minBetAmount.intValue()));
        paramStr.append(minCusAmount == null ? "" : String.valueOf(minCusAmount.intValue())).append(minMultiple == null ? "" : String.valueOf(minMultiple.intValue()));
        paramStr.append(StringUtils.isNotBlank(fieldsOrder) ? fieldsOrder : "").append(pageNo != null ? String.valueOf(pageNo.intValue()) : "").append(pageSize != null ? String.valueOf(pageSize.intValue()) : "");
        paramStr.append(UtilConstants.SUFFIX);
        return Md5Util.MD5Encode(paramStr.toString());
    }
}
