package com.gw.datacenter.cxf.client;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.order.OrderEntity;
import com.gw.datacenter.vo.pagainate.QueryResult;
import lombok.extern.slf4j.Slf4j;

/**
 * title: GetRecordMaxTest
 * description: TODO
 * author: Jair.H
 * date: 2018/11/19 19:35
 */
@Slf4j
public class GetRecordMaxTest {

    public static void main(String[] args) {
        try {
            String productId = "A04";
            String platform[] = {"026", "003", "044", "006", "051", "008", "004", "035", "039", "031", "036", "027", "047"};
            String[] loginNames = null;
            String[] gameKinds = new String[]{"1", "2", "3", "4", "5", "6", "7", "8", "9", "12", "15"};
            String beginTime = "2018-01-01 00:00:00";
            String endTime = "2018-11-30 23:59:59";
            Integer minbet = 0;
            Integer minCusaccount = 0;
            Integer multiple = 0;
            String orderField = "";
            String maxField = "CUS_ACCOUNT";
            String grougField = "loginname";
            Integer pageNo = 1;
            Integer pageSize = 10;
            StringBuffer sb = new StringBuffer();

            sb.append(productId).
                    append(org.apache.commons.lang3.StringUtils.join(platform, ","))//A04
                    .append(loginNames == null ? "" : org.apache.commons.lang3.StringUtils.join(loginNames, ",")) //003,006,026,035,008,043
                    .append(org.apache.commons.lang3.StringUtils.join(gameKinds, ","))//3
                    .append(beginTime)//2016-08-05 00:00:00
                    .append(endTime)//2016-08-05 14:00:09
                    .append(minbet == null ? "" : String.valueOf(minbet.intValue()))//1
                    .append(minCusaccount == null ? "" : String.valueOf(minCusaccount.intValue()))//1
                    .append(multiple == null ? "" : String.valueOf(multiple.intValue()))//3
                    .append(orderField)//
                    .append(maxField)//CUS_ACCOUNT
                    .append(grougField)//loginname
                    .append(pageNo.toString())//1
                    .append(pageSize.toString());//1000
            sb.append(UtilConstants.SUFFIX);//feas!#%  feas!#%
            String key = Md5Util.MD5Encode(sb.toString());

            DataCenterApi client = DataCenterApiUtil.init();
            QueryResult<OrderEntity> result = client.getRecordMaxBy(productId, platform, loginNames, gameKinds, beginTime, endTime, "", minbet, minCusaccount, multiple, orderField, maxField, grougField, pageNo, pageSize, key,"CNY");
            DataCenterApiUtil.printQueryResult(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

}
