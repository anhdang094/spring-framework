package com.gw.datacenter.cxf.client;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.order.AccountTotalEntity;
import com.gw.datacenter.vo.pagainate.QueryResult;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * title: GetValidAmountByTypeTest
 * description: TODO
 * author: Jair.H
 * date: 2018/11/9 09:01
 */
@Slf4j
public class GetValidAmountByTypeAndFlagTest {

    public static void main(String args[]) {
        try {
            String productId = "A04";
            String loginNameArray = "mwh004";
            String beginTime = "2018-08-10";
            String endTime = "2018-10-25";
            String key = getValidAmountKey(productId, loginNameArray, beginTime, endTime);

            DataCenterApi client = DataCenterApiUtil.init();
            QueryResult<AccountTotalEntity> result = client.getValidAmountByTypeAndFlag(productId, null, null, null, loginNameArray, beginTime, endTime, 3, 1, 1, 1, key);
            DataCenterApiUtil.printQueryResult(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static String getValidAmountKey(String productId, String loginNameArray, String beginTime, String endTime) {
        StringBuffer sb = new StringBuffer();
        if (StringUtils.isNotBlank(productId)) {
            sb.append(productId);
        }
        if (StringUtils.isNotBlank(loginNameArray)) {
            sb.append(loginNameArray);
        }
        if (StringUtils.isNotBlank(beginTime)) {
            sb.append(beginTime);
        }
        if (StringUtils.isNotBlank(endTime)) {
            sb.append(endTime);
        }
        sb.append(UtilConstants.SUFFIX);
        return Md5Util.MD5Encode(sb.toString());
    }
}
