package com.gw.datacenter.cxf.client;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.order.AccountTotalEntity;
import com.gw.datacenter.vo.pagainate.QueryResult;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * @author Dominik.X
 * @description
 * @date 2019/5/8 16:40
 */
@Slf4j
public class GetWagerSummaryTest {

    public static void main(String[] args) {
        try {
            String productId = "A04";
            String [] loginNameArray = {"mtedy181"};
            String beginTime = "2019-03-01 00:00:00";
            String endTime = "2019-04-01 23:59:59";
            String key = getValidAmountKey(productId, null, beginTime, endTime);

            DataCenterApi client = DataCenterApiUtil.init();
            QueryResult<AccountTotalEntity> result = client.getWagerSummary(productId,new String[]{"3"},null,loginNameArray,null,null,beginTime,endTime,1,500,key);
            DataCenterApiUtil.printQueryResult(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static String getValidAmountKey(String productId, String minBet, String beginTime, String endTime) {
        StringBuffer sb = new StringBuffer();
        if (!StringUtils.isBlank(productId)) {
            sb.append(productId);
        }
        if (!StringUtils.isBlank(minBet)) {
            sb.append(minBet);
        }

        if (!StringUtils.isBlank(beginTime)) {
            sb.append(beginTime);
        }
        if (!StringUtils.isBlank(endTime)) {
            sb.append(endTime);
        }

        sb.append(UtilConstants.SUFFIX);
        return Md5Util.MD5Encode(sb.toString());
    }
}
