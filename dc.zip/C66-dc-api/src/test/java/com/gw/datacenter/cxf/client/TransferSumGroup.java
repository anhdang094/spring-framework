package com.gw.datacenter.cxf.client;

import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.order.MonthlyWeeklyEffectiveBetAmountEntity;
import com.gw.datacenter.vo.transfer.TransferGroupByType;

import java.math.BigDecimal;
import java.util.List;

public class TransferSumGroup {
    public static void main(String[] args) {
        try {
            String productId = "A04";
            String loginNameArray = "mwh004";
            BigDecimal amount = BigDecimal.ZERO;
            String weekBeginTime = "2018-08-14 00:00:00";
            String weekEndTime = "2018-08-15 23:59:59";

            DataCenterApi client = DataCenterApiUtil.init();
            List<TransferGroupByType> transferSumGroupByType = client.getTransferSumGroupByType(new String[]{"032"},new String[]{"049"}, weekBeginTime, weekEndTime, "A03", "marley");
            DataCenterApiUtil.printListResult(transferSumGroupByType);
        } catch (Exception e) {

        }
    }
}
