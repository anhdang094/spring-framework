package com.gw.datacenter.cxf.impl;

import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.common.util.Md5Util;
import com.gw.datacenter.cxf.DataCenterApi;
import com.gw.datacenter.vo.order.AccountTotalEntity;
import com.gw.datacenter.vo.pagainate.QueryResult;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.List;

/**
 * title: DataCenterApiImplTest
 * description: TODO
 * author: Jair.H
 * date: 2018/11/6 16:37
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@Slf4j
public class DataCenterApiImplTest {

    @Resource
    private DataCenterApi dataCenterApi;
    @Test
    public void getValidAmountByType() {
//        try {
//            String productId = "A04";
//            String loginNameArray = "mwh004";
//            String beginTime = "2018-08-10";
//            String endTime = "2018-10-25";
//            BigDecimal minCustAmount = new BigDecimal("100.99");
//            String key = Md5Util.MD5Encode(getValidAmountKey(productId, loginNameArray, beginTime, endTime));
//            QueryResult<AccountTotalEntity> result = dataCenterApi.getValidAmountByType(productId, null, null, null, loginNameArray, beginTime, endTime, 3, 1, 1, 1, key, null, null, null, null, null,minCustAmount);
//            List<AccountTotalEntity> list = result.getQueryResultList();
//            if(CollectionUtils.isNotEmpty(list)) {
//                log.info(list.size()+"");
//                for (AccountTotalEntity entity : list) {
//                    log.info(entity.toString());
//                }
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
    }

    private static String getValidAmountKey(String productId, String loginNameArray, String beginTime, String endTime) {
        StringBuffer sb = new StringBuffer();
        if (StringUtils.isNotBlank(productId)) {
            sb.append(productId);
        }
        if (StringUtils.isNotBlank(loginNameArray)) {
            sb.append(loginNameArray);
        }
        if (StringUtils.isNotBlank(beginTime)) {
            sb.append(beginTime);
        }
        if (StringUtils.isNotBlank(endTime)) {
            sb.append(endTime);
        }
        sb.append(UtilConstants.SUFFIX);
        return sb.toString();
    }
}