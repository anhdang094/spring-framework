-- Add/modify columns
alter table T_SMS_ACCOUNT add account_type varchar2(1) default 0;
-- Add comments to the columns
comment on column T_SMS_ACCOUNT.account_type
is '账号类型，0发送账号，1接收账号';
commit;

CREATE TABLE T_SMS_CONSTANT (
  id             NUMBER(22)    NOT NULL,
  product_id     VARCHAR2(3)   NOT NULL,
  constant_key   VARCHAR2(100) NOT NULL,
  constant_name  VARCHAR2(100) NOT NULL,
  constant_value VARCHAR2(100) NOT NULL,
  created_date   DATE          NOT NULL,
  lastupt_date   DATE          NOT NULL,
  flag           VARCHAR2(1)   NOT NULL
);
-- Add comments to the table
COMMENT ON TABLE T_SMS_CONSTANT
IS '短信常量表';
COMMENT ON COLUMN T_SMS_CONSTANT.product_id
IS '产品ID';
COMMENT ON COLUMN T_SMS_CONSTANT.constant_key
IS '常量KEY';
COMMENT ON COLUMN T_SMS_CONSTANT.constant_name
IS '常量名';
COMMENT ON COLUMN T_SMS_CONSTANT.constant_value
IS '常量值';
COMMENT ON COLUMN T_SMS_CONSTANT.flag
IS '有效标识位，1有效，0无效';

-- Create sequence 
CREATE SEQUENCE T_SMS_CONSTANT_SEQ
MINVALUE 0
MAXVALUE 999999999999999999999999999
START WITH 0
INCREMENT BY 1
CACHE 20;

CREATE TABLE T_SMS_MQ_SEND_RECORD (
  id                   NUMBER(22)     NOT NULL,
  product_id           VARCHAR2(3)    NOT NULL,
  msg_type             NUMBER(1)      NOT NULL,
  msg_data             VARCHAR2(1000) NOT NULL,
  jms_queue_name       VARCHAR2(100),
  rabbit_exchange_name VARCHAR2(100),
  rabbit_routing_key   VARCHAR2(100),
  flag                 NUMBER(1)      NOT NULL,
  resend_time          NUMBER(3)      NOT NULL,
  remark               VARCHAR2(4000),
  created_date         DATE,
  last_upt_date        DATE
);
-- Add comments to the table
COMMENT ON TABLE T_SMS_MQ_SEND_RECORD
IS '短信MQ消息补偿表';
COMMENT ON COLUMN T_SMS_MQ_SEND_RECORD.product_id
IS '产品ID';
COMMENT ON COLUMN T_SMS_MQ_SEND_RECORD.msg_type
IS '消息类型：1=ActiveMQ;2=RabbitMQ';
COMMENT ON COLUMN T_SMS_MQ_SEND_RECORD.msg_data
IS '消息内容';
COMMENT ON COLUMN T_SMS_MQ_SEND_RECORD.jms_queue_name
IS 'jms队列名';
COMMENT ON COLUMN T_SMS_MQ_SEND_RECORD.rabbit_exchange_name
IS 'rabbit ExchangeName';
COMMENT ON COLUMN T_SMS_MQ_SEND_RECORD.rabbit_routing_key
IS 'rabbit routingKey';
COMMENT ON COLUMN T_SMS_MQ_SEND_RECORD.flag
IS '状态：0=等待重发；1=已重发，发送失败；2=已重发，发送成功';
COMMENT ON COLUMN T_SMS_MQ_SEND_RECORD.resend_time
IS '重发次数';

-- Create sequence
CREATE SEQUENCE T_SMS_MQ_SEND_RECORD_SEQ
MINVALUE 0
MAXVALUE 999999999999999999999999999
START WITH 0
INCREMENT BY 1
CACHE 20;