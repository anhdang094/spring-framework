alter table t_sms_type add pid NUMBER (20);
COMMENT ON COLUMN t_sms_type.pid IS '父类型id';