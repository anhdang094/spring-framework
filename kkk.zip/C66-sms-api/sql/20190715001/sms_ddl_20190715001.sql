alter table t_sms_account add smsmethod NUMBER (1) default 0;
COMMENT ON COLUMN t_sms_account.smsmethod IS '发送方式[0:文本短信;1:语音短信,默认0]';