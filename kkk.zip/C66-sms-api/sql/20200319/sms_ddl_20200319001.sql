create table t_sms_operate_log(
  id                         NUMBER(22)   primary key,
  product_id                 varchar2(3) not null,
  operator                   varchar2(100) not null,
  operate_type              number(2) not null,
  bussiness_type            varchar(30) not null,
  operator_ip                varchar2(50) not null,
  src_content                varchar2(256),
  desc_content               varchar2(256),
  CREATED_DATE               date default sysdate,
  remarks                    varchar2(1024)
);
create sequence t_sms_operate_log_seq minvalue 1 maxvalue 99999999999 start with 1 increment by 1 cache 200;
comment on column t_sms_operate_log.id is '主键';
comment on column t_sms_operate_log.product_id is '产品id';
comment on column t_sms_operate_log.operator is '操作人登录名';
comment on column t_sms_operate_log.operate_type is '操作类型:1新增2修改3删除4启用5禁用';
comment on column t_sms_operate_log.bussiness_type is '业务类型';
comment on column t_sms_operate_log.operator_ip is '操作人ip';
comment on column t_sms_operate_log.src_content is '原始内容';
comment on column t_sms_operate_log.CREATED_DATE is '创建时间';
comment on column t_sms_operate_log.desc_content is '新内容';
comment on column t_sms_operate_log.remarks is '备注';
