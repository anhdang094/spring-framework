alter table t_sms_account add priority NUMBER (2) default 0;
COMMENT ON COLUMN t_sms_account.priority IS '账户优,数字越小优先级越高';





--回滚sql
--alter table t_sms_account drop column priority;