alter table t_sms_account add sms_signature varchar2(32);
COMMENT ON COLUMN t_sms_account.sms_signature IS '短信签名';


--回滚sql
--alter table t_sms_account drop column signature;