alter table T_SMS_TYPE add disable_flag  NUMBER(1) default 0 not null;
COMMENT ON COLUMN T_SMS_TYPE.disable_flag IS '是否禁用 0否 1是';

create table T_SMS_PROVIDER_CONFIG
(
  id               NUMBER(20) not null,
  product_id       VARCHAR2(3),
  config_name      VARCHAR2(50),
  provider_code    VARCHAR2(6),
  type_ids         VARCHAR2(200),
  type_codes       VARCHAR2(200),
  customer_levels  VARCHAR2(200),
  exclusive_flag   NUMBER(1) default 0,
  create_date      DATE,
  create_by        VARCHAR2(20),
  last_update_date DATE,
  last_update_by   VARCHAR2(20)
);
comment on column T_SMS_PROVIDER_CONFIG.id
  is '自增ID，主键';
comment on column T_SMS_PROVIDER_CONFIG.product_id
  is '产品ID';
comment on column T_SMS_PROVIDER_CONFIG.config_name
  is '配置名称';
comment on column T_SMS_PROVIDER_CONFIG.provider_code
  is '供应商代码';
comment on column T_SMS_PROVIDER_CONFIG.type_ids
  is '短信类型ID,多个用,分隔';
comment on column T_SMS_PROVIDER_CONFIG.customer_levels
  is '用户星级，多个用,分隔';
comment on column T_SMS_PROVIDER_CONFIG.exclusive_flag
  is '是否专属供应商 0否 1是';

create index IDX_PID_PCODE_SMSTYPE on T_SMS_PROVIDER_CONFIG (PRODUCT_ID, PROVIDER_CODE, EXCLUSIVE_FLAG);
-- Create/Recreate primary, unique and foreign key constraints
alter table T_SMS_PROVIDER_CONFIG add constraint IDX_ID primary key (ID);

-- Create sequence
create sequence T_PROVIDER_CONFIG_SEQ
minvalue 100000
maxvalue 999999999999999999999999999
start with 101500
increment by 1
cache 20;

-- 修改短信模板中的供应商字段类型为空，可以不设置，后面用不上
alter table T_SMSCONTENT_TEMPLATE modify PROVIDER_ID null;

-- 修改短信内容产品CODE字符长度
alter table T_SMS_CONTENT modify PROVIDER_CODE VARCHAR2(50);
