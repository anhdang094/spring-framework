alter table T_SMS_ACCOUNT add country_code  varchar2(30) ;
COMMENT ON COLUMN T_SMS_ACCOUNT.country_code IS '国家代码';