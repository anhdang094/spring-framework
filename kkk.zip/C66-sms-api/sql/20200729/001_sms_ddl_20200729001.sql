drop sequence T_SMS_GEN_RECORD_SEQ;
create sequence T_SMS_GEN_RECORD_SEQ
minvalue 100000
maxvalue 999999999999999999999999999
start with 100001
increment by 1
cache 20;

drop table T_SMS_GEN_RECORD;
-- Create table
create table T_SMS_GEN_RECORD
(
  id               NUMBER(20) not null,
  product_id       VARCHAR2(5),
  login_name       VARCHAR2(30),
  status           NUMBER(1) not null,
  type_code          NUMBER(20),
  provider_code    VARCHAR2(5),
  customer_level   NUMBER(1),
  origin_content   VARCHAR2(4000) not null,
  create_date      DATE default sysdate not null,
  last_update_date DATE not null,
  req_id           VARCHAR2(50),
  batch_id         VARCHAR2(100),
  CREATED_BY       VARCHAR2(20),
  LAST_UPDATE_BY   VARCHAR2(20),
  remarks          VARCHAR2(2000)
);
-- Add comments to the table
comment on table T_SMS_GEN_RECORD
  is '短信生成记录';
-- Add comments to the columns
comment on column T_SMS_GEN_RECORD.login_name
  is '登录名';
comment on column T_SMS_GEN_RECORD.status
  is '1 待审批 2 已审批 3已拒绝 4数据规则校验失败 5发送短信失败';
comment on column T_SMS_GEN_RECORD.type_code
  is '短信类型ID';
comment on column T_SMS_GEN_RECORD.provider_code
  is '供应商CODE';
comment on column T_SMS_GEN_RECORD.customer_level
  is '用户星级';
comment on column T_SMS_GEN_RECORD.origin_content
  is '短信内容';
comment on column T_SMS_GEN_RECORD.req_id
  is '请求ID';
comment on column T_SMS_GEN_RECORD.batch_id
  is '批量发送ID';
comment on column T_SMS_GEN_RECORD.remarks
  is '备注';
-- Create/Recreate indexes
create index IDX_PID_PCODE_BID_TID on T_SMS_GEN_RECORD (PRODUCT_ID, PROVIDER_CODE, TYPE_code, BATCH_ID);
-- Create/Recreate primary, unique and foreign key constraints
alter table T_SMS_GEN_RECORD
  add constraint IDX_ID_GRECORD primary key (ID);

alter table T_SMS_TYPE add IS_APPROVE  NUMBER(1) default 0 not null;
COMMENT ON COLUMN T_SMS_TYPE.IS_APPROVE IS '是否需要审批 0否 1是';

