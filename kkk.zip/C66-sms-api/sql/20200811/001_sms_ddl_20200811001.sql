-- 修改常量表的值的长度
alter table T_SMS_CONSTANT modify CONSTANT_VALUE VARCHAR2(2000);

insert into T_SMS_CONSTANT values(T_SMS_CONSTANT_SEQ.nextval,'ALL','GSM_PROVIDER_LIST','GSM自建供应商CODE列表，用逗号分隔','S35,S37',sysdate,sysdate,1);

alter table T_SMS_PROVIDER_CONFIG add extra_param  VARCHAR2(200) ;
COMMENT ON COLUMN T_SMS_PROVIDER_CONFIG.extra_param IS '额外参数';