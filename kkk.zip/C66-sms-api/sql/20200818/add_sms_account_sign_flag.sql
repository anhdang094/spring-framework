alter table t_sms_account add sign_flag number(1) default 1 not null;
comment on column T_SMS_ACCOUNT.sign_flag is '是否包含签名：1=包含；0=不包含';