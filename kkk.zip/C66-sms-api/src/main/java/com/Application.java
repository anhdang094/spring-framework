package com;

import com.ctrip.framework.apollo.spring.annotation.EnableApolloConfig;
import com.intech.config.MonitorFilterAutoConfiguration;
import com.intech.tracing.ZipkinServerTracingAutoConfiguration;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@ServletComponentScan(basePackages = "com.intech")
@EnableApolloConfig
@EnableScheduling
@ImportAutoConfiguration(value = {ZipkinServerTracingAutoConfiguration.class, MonitorFilterAutoConfiguration.class})
public class Application extends SpringBootServletInitializer {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }


    /**
        * 需要把web项目打成war包部署到外部tomcat运行时需要改变启动方式
        */
    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(Application.class);
    }

}
