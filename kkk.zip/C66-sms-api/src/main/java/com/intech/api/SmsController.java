package com.intech.api;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.intech.common.enums.ErrorCodeEnum;
import com.intech.common.util.RequestResponseUtils;
import com.intech.common.util.Result;
import com.intech.common.util.ResultUtilOld;
import com.intech.sms.service.SmsProviderService;
import com.intech.sms.service.SmsTypeService;
import com.intech.sms.util.Constants;
import com.ws.*;
import com.intech.common.util.ResultUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Objects;


/**
 * @description: sms-api
 * @author: Condi
 * @create: 2019-03-19 16:54
 **/
@RequestMapping("/rest")
@RestController
@Api(tags = "短信API REST接口", description = "短信API REST接口", value = "SmsController")
public class SmsController {

    protected static final Logger logger = LoggerFactory.getLogger(SmsController.class);
    @Autowired
    private SmsTypeService smsTypeService;
    @Autowired
    private SmsService smsService;

    @Autowired
    private SmsProviderService smsProviderService;

    /**
     * 查询短信子类型[根据主类型]
     *
     * @param: [person]
     * @return: com.condi.api.common.SmsResponse
     * @throws:
     * @Author: "Condi"
     * @Date: 2018/10/12
     */
    @PostMapping("/queryChildTypes")
    @ApiOperation(
            value = "查询短信子类型[根据主类型]",
            notes = "查询短信子类型[根据主类型]",
            response = SmsResponse.class,
            httpMethod = "POST"
    )
    @Deprecated
    public SmsResponse queryChildTypes(@RequestBody SmsChildTypeRequest request) {

        logger.info("查询短信子类型[根据主类型],ip:{},参数:{}", RequestResponseUtils.getIpAddress(), request);

        if (Objects.isNull(request) || StringUtils.isEmpty(request.getProductId()) || StringUtils.isEmpty(request.getTypeCode())) {
            return ResultUtilOld.returnError(ErrorCodeEnum.PARAM_ERROR);
        }
        List<SmsType> list = smsTypeService.queryChildTypes(request);
        return ResultUtilOld.returnSuccess(list);
    }

    /**
     * 查询短信子类型[根据主类型]
     *
     * @param: [person]
     * @return: com.condi.api.common.SmsResponse
     * @throws:
     * @Author: "Condi"
     * @Date: 2018/10/12
     */
    @PostMapping("/queryChildTypeList")
    @ApiOperation(
            value = "查询短信子类型[根据主类型] ",
            notes = "查询短信子类型[根据主类型]",
            response = Result.class,
            httpMethod = "POST"
    )
    public Result queryChildTypeList(@RequestBody SmsChildTypeRequest request) {

        logger.info("查询短信子类型[根据主类型],ip:{},参数:{}", RequestResponseUtils.getIpAddress(), request);

        if (Objects.isNull(request) || StringUtils.isEmpty(request.getProductId()) || StringUtils.isEmpty(request.getTypeCode())) {
            return ResultUtil.returnErrorEnum(ErrorCodeEnum.PARAM_ERROR);
        }
        List<SmsType> list = smsTypeService.queryChildTypes(request);
        return ResultUtil.returnSuccess(list);
    }


    /**
     * 发送短信接口[body==0为发送成功,大于0的字数表示失败的个数]
     *
     * @param: [person]
     * @return: com.condi.api.common.SmsResponse
     * @throws:
     * @Author: "Condi"
     * @Date: 2018/10/12
     */
    @PostMapping("/sendSMS")
    @ApiOperation(
            value = "发送短信接口[body==0为发送成功,大于0的字数表示失败的个数]",
            notes = "发送短信接口[body==0为发送成功,大于0的字数表示失败的个数]",
            response = Result.class,
            httpMethod = "POST"
    )
    public Result<String> sendSms(@RequestBody SmsContentRequest request) {
        logger.info("发送短信接口,ip:{}", RequestResponseUtils.getIpAddress());
        String res = smsService.insert(request);
        if (Integer.valueOf(res) < 0) {
            return ResultUtil.returnErrorEnum(ErrorCodeEnum.PARAM_ERROR);
        }
        return ResultUtil.returnSuccess(res);
    }

    /**
     * 查询短信发送记录数据
     *
     * @param: [person]
     * @return: com.condi.api.common.SmsResponse
     * @throws:
     * @Author: "Condi"
     * @Date: 2018/10/12
     */
    @PostMapping("/querySmsRecord")
    @ApiOperation(
            value = "查询短信发送记录数据",
            notes = "查询短信发送记录数据",
            response = Result.class,
            httpMethod = "POST"
    )
    public Result<Integer> querySmsRecord(@RequestBody SmsRecordQueryRequest request) {
        logger.info("查询短信发送记录数据,ip:{}", RequestResponseUtils.getIpAddress());
        SmsRecordQueryResponse res = smsService.querySmsRecord(request);
        int count = 0;
        if (Constants.EXECUTE_SUCCESS.equals(res.getCode())) {
            count = res.getSmsRecordNumber();
        }
        return ResultUtil.returnSuccess(count);
    }


    /**
     * 查询供应商列表
     *
     * @param: [person]
     * @return: com.condi.api.common.SmsResponse
     * @throws:
     * @Author: "Condi"
     */
    @PostMapping("/querySmsProviders")
    @ApiOperation(
            value = "查询供应商列表[支持群发的供应商]",
            notes = "查询供应商列表[支持群发的供应商]",
            response = Result.class,
            httpMethod = "POST"
    )
    public Result querySmsProvider(@RequestBody SmsProviderQueryRequest request) {

        logger.info("查询短信子类型[根据主类型],ip:{},参数:{}", RequestResponseUtils.getIpAddress(), request);

        if (Objects.isNull(request) || StringUtils.isEmpty(request.getProductId())) {
            return ResultUtil.returnErrorEnum(ErrorCodeEnum.PARAM_ERROR);
        }
        List<SmsProvider> list = smsProviderService.querySmsProvider(request);
        return ResultUtil.returnSuccess(list);
    }

    @PostMapping("/pushSendSmsResult")
    @ApiOperation(
            value = "内部短信供应商推送发送消息结果",
            notes = "内部短信供应商推送发送消息结果",
            response = Result.class,
            httpMethod = "POST"
    )
    public Result saveSmsResult(@RequestBody Map params_) {
        logger.info("接受S35短信发送结果响应信息：" + JSON.toJSONString(params_));

        /*String json="{\"sn\":\"db59-a230-9040-0005\",\"sms_result\":[{\"port\":31,\"user_id\":3064272,\"number\":\"861\",\"time\":\"2020-07-22 10:09:37\",\"status\":\"FAILED\",\"count\":2,\"succ_count\":0,\"ref_id\":0,\"imsi\":\"515025\"}]}";
        JSONObject params = JSON.parseObject(json);*/
        JSONObject params = JSON.parseObject(JSON.toJSONString(params_));
        if (params.containsKey("sms_result") && params.get("sms_result") != null) {

            JSONArray smsResult = params.getJSONArray("sms_result");
            for (Object r : smsResult) {
                JSONObject r_ = (JSONObject) r;
                Integer statusInt = 0;
                String status = r_.getString("status");
                String refId = r_.getString("user_id");
                String port = r_.getString("port");
                if ("SENT_OK".equals(status)) {
                    statusInt = 2;
                } else if ("FAILED".equals(status)) {
                    statusInt = -1;
                }
                if (statusInt != 0) {
                    smsService.saveS35Result(refId, statusInt,port);
                }
            }
        }
        return ResultUtil.returnSuccess(params);
    }

}


    
