package com.intech.common.enums;


public enum ErrorCodeEnum {

    SUCCESS("000000", "interface invoke success","接口调用成功"),
    PARAM_ERROR("000001", "The required parameter is error ","参数不正确"),
    PRODUCTID_ERROR("000002", "产品id不正确","产品id不正确"),
    UNKNOWN_ERROR("999999", "Syetem Error","系统繁忙，请稍后再试....");

    private String code;

    private String desc;

    /**
     * 错误消息（中文）
     */
    private String descCn;

    ErrorCodeEnum(String code, String desc,String descCn ) {
        this.code = code;
        this.desc = desc;
        this.descCn=descCn;
    }

    public String getCode() {
        return this.code;
    }


    public String getDesc() {
        return desc;
    }

    public String getDescCn() {
        return descCn;
    }

    @Override
    public String toString() {
        return "ErrorCodeEnum{" +
                "code='" + code + '\'' +
                ", desc='" + desc + '\'' +
                ", descCn='" + descCn + '\'' +
                '}';
    }
}
