package com.intech.common.util;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.data.redis.serializer.RedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.io.Serializable;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.TimeUnit;

@Component("redisUtil")
public class RedisUtil {

    private static final Logger logger = LoggerFactory.getLogger(RedisUtil.class);
    public static final Integer SLEEP_TIME = 100;

    @Resource
    private RedisTemplate<Serializable, Object> redisTemplate;
    @Value("${server.model.name}")
    private String moduleName;

    @Resource
    public void setRedisTemplate(RedisTemplate<Serializable, Object> redisTemplate) {
        RedisSerializer<String> stringSerializer = new StringRedisSerializer();
        redisTemplate.setKeySerializer(stringSerializer);
        redisTemplate.setValueSerializer(stringSerializer);
        redisTemplate.setHashKeySerializer(stringSerializer);
        redisTemplate.setHashValueSerializer(stringSerializer);
        this.redisTemplate = redisTemplate;
    }

    /**
     * 加锁
     *
     * @param key   唯一标志
     * @param value 当前时间+超时时间 也就是时间戳
     * @return
     */
    public boolean get(String key, String value) {
        ValueOperations<Serializable, Object> operations = redisTemplate.opsForValue();
        if (operations.setIfAbsent(key, value, Duration.ofSeconds(60 * 2)))
            return true;

        Object currentValue = operations.get(key);
        if (currentValue instanceof Long && (Long) currentValue < System.currentTimeMillis()) {
            Object oldValue = operations.getAndSet(key, value);
            return null != oldValue && oldValue.equals(currentValue);
        }

        return false;
    }

    /**
     * 加锁
     *
     * @param key   唯一标志
     * @param value 当前时间+超时时间 也就是时间戳
     * @param value 超时时间（Second）
     * @return
     */
    public boolean lock(String key, String value, Long expireSeconds) {
        boolean result;
        try {
            ValueOperations<Serializable, Object> operations = redisTemplate.opsForValue();
            if (expireSeconds == null)
                result = operations.setIfAbsent(key, value);
            result = operations.setIfAbsent(key, value, Duration.ofSeconds(expireSeconds));
        } catch (Exception e) {
            logger.error("加锁出现异常!", e);
            return false;
        }
        return result;
    }

    /**
     * 解锁
     *
     * @param key 唯一标志
     * @return
     */
    public void unlock(String key) {
        try {
            ValueOperations<Serializable, Object> operations = redisTemplate.opsForValue();
            operations.getOperations().delete(key);
        } catch (Exception e) {
            logger.error("解锁出现异常!", e);
        }
    }

    /**
     * 批量删除对应的value
     */
    public void remove(final String... keys) {
        for (String key : keys) {
            remove(key);
        }
    }

    /**
     * 批量删除key
     */
    public void removePattern(final String pattern) {
        Set<Serializable> keys = redisTemplate.keys(pattern);
        if (CollectionUtils.isNotEmpty(keys)) {
            redisTemplate.delete(keys);
        }
    }

    /**
     * 删除对应的value
     */
    public void remove(final String key) {
        if (exists(key)) {
            redisTemplate.delete(key);
        }
    }

    /**
     * 判断缓存中是否有对应的value
     */
    public boolean exists(final String key) {
        Boolean result = redisTemplate.hasKey(key);
        if (null == result) {
            return false;
        }
        return result;
    }

    /**
     * 读取缓存
     */
    public <V> V get(final String key) {
        ValueOperations operations = redisTemplate.opsForValue();
        //noinspection unchecked
        return (V) operations.get(key);
    }

    /**
     * 读取缓存
     */
    public String getString(final String key) {
        Object obj = redisTemplate.opsForValue().get(key);
        if (Objects.isNull(obj))
            return null;
        else
            return obj.toString();
    }

    /**
     * key模糊查询
     */
    public List<Object> fuzzyGet(final String pattern) {
        Set<Serializable> keys = redisTemplate.keys(pattern);
        List<Object> result = null;
        if (CollectionUtils.isNotEmpty(keys)) {
            result = new ArrayList<>();
            for (Serializable key : keys) {
                result.add(redisTemplate.opsForValue().get(key));
            }
        }
        return result;
    }

    /**
     * 写入缓存
     */
    public boolean set(final String key, Object value) {
        boolean result = false;
        try {
            ValueOperations<Serializable, Object> operations = redisTemplate.opsForValue();
            operations.set(key, value);
            result = true;
        } catch (Exception e) {
            logger.error("Redis写入异常{}", e.getMessage(), e);
        }
        return result;
    }

    /**
     * 写入缓存
     */
    public boolean set(final String key, Object value, Integer expireTime) {
        boolean result = false;
        try {
            ValueOperations<Serializable, Object> operations = redisTemplate.opsForValue();
            operations.set(key, value);
            redisTemplate.expire(key, expireTime, TimeUnit.SECONDS);
            result = true;
        } catch (Exception e) {
            logger.error("Redis设置过期写入异常{}", e.getMessage(), e);
        }
        return result;
    }

    /**
     * 判断hash结构中是否有对应的value
     */
    public boolean hashexist(String hash, String key) {
        boolean flag = false;
        try {
            flag = redisTemplate.opsForHash().hasKey(hash, key);
            return flag;
        } catch (Exception e) {
            logger.error("Redis 模板异常{}", e.getMessage(), e);
        }
        return flag;
    }

    public Object getHash(String hash, String hashKey) {
        Object object = null;
        try {
            HashOperations<Serializable, Object, Object> hashOperations = redisTemplate.opsForHash();
            object = hashOperations.get(hash, hashKey);
        } catch (Exception e) {
            logger.error("Redis hash 取值异常{}", e.getMessage(), e);
        }
        return object;
    }

    public String getHashString(String hash, String hashKey) {
        try {
            HashOperations<Serializable, Object, Object> hashOperations = redisTemplate.opsForHash();
            Object obj = hashOperations.get(hash, hashKey);
            if (Objects.isNull(obj))
                return null;
            else
                obj.toString();
        } catch (Exception e) {
            logger.error("Redis hash 取值异常{}", e.getMessage(), e);
        }
        return null;
    }

    public boolean setHash(String hash, String hashKey, Object hashValue) {
        boolean result = false;
        try {
            HashOperations<Serializable, Object, Object> hashOperations = redisTemplate.opsForHash();
            hashOperations.put(hash, hashKey, hashValue);
            result = true;
        } catch (Exception e) {
            logger.error("Redis hash 写入异常{}", e.getMessage(), e);
        }
        return result;
    }

    public boolean removeHash(String hash, String key) {
        boolean result = false;
        if (hashexist(hash, key)) {
            try {
                HashOperations<Serializable, Object, Object> hashOperations = redisTemplate.opsForHash();
                hashOperations.delete(hash, key);
                result = true;
            } catch (Exception e) {
                logger.error("Redis hash 删除异常{}", e.getMessage(), e);
            }
            return result;
        }
        return true;
    }

    public String getModuleProduct(){
        if(StringUtils.isBlank(moduleName)){
            return "";
        }
        String[] moduleSplit = moduleName.split("-");

        if(moduleSplit==null || moduleSplit.length==0){
            return "";
        }
        return StringUtils.isBlank(moduleSplit[0])?"":moduleSplit[0];
    }


    /**
     *
     * @param portsStr 1,2,3,4
     * @param providerCode S35|S36|S37
     * @return
     */
    public String getS35RedisLockKey(String portsStr,String providerCode){
        if(StringUtils.isBlank(portsStr)||StringUtils.isBlank(providerCode)){
            return null;
        }
        String productId=getModuleProduct();
        return String.format("%s:%s:%s:%s",productId,providerCode,"l",portsStr.replaceAll(",", "."));
    }

    /**
     *
     * @param portsStr 1,2,3,4
     * @param providerCode S35|S36|S37
     * @return
     */
    public String getS35RedisPortBaseKey(String portsStr,String providerCode){
        if(StringUtils.isBlank(portsStr)||StringUtils.isBlank(providerCode)){
            return null;
        }
        String productId=getModuleProduct();
        return String.format("%s:%s:%s:%s",productId,providerCode,"b",portsStr.replaceAll(",", "."));
    }

    /**
     *
     * @param portsStr 1,2,3,4
     * @param providerCode S35|S36|S37
     * @return
     */
    public String getS35RedisPortKey(String portsStr,String providerCode){
        if(StringUtils.isBlank(portsStr)||StringUtils.isBlank(providerCode)){
            return null;
        }
        String productId=getModuleProduct();
        return String.format("%s:%s:%s",productId,providerCode,portsStr.replaceAll(",", "."));
    }
}
