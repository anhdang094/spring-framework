package com.intech.common.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;


/**
 * Created by Judd.Z on 2017/10/31.
 */
public class RequestResponseUtils {


    protected static final Logger logger = LoggerFactory.getLogger(RequestResponseUtils.class);

    // 获取IP地址
    private final static String X_FORWARDED_FOR = "X-Forwarded-For";
    private final static String X_REAL_IP = "X-Real-IP";
    private final static String PROXY_CLIENT_IP = "Proxy-Client-IP";
    private final static String WL_PROXY_CLIENT_IP = "WL-Proxy-Client-IP";
    private final static String UNKNOWN = "unknown";

    /**
     * 获取request
     *
     * @return
     */
    public static HttpServletRequest getRequest() {
        return ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
    }

    /**
     * 获取request
     *
     * @return
     */
    public static String getBasePath() {
        String path = getRequest().getContextPath();
        return getRequest().getScheme() + "://" + getServerName()
                + ":" + getRequest().getServerPort() + path;
    }

    /**
     * 获取request
     *
     * @return
     */
    public static String getServerName() {
        return getRequest() == null ? "" : getRequest().getServerName();
    }

    /**
     * 获取session
     */
    public static HttpSession getSession() {
        return getRequest() == null ? null : getRequest().getSession();
    }

    /**
     * 获取IP
     */
    public static String getIpAddress() {
        HttpServletRequest request = getRequest();
        if (request == null) {
            return "";
        }
        String ipAddress = request.getHeader(X_FORWARDED_FOR);
        if(ipAddress != null && ipAddress.length() > 0 && !UNKNOWN.equalsIgnoreCase(ipAddress)){
            //多次反向代理后会有多个ip值，第一个ip才是真实ip
            int index = ipAddress.indexOf(",");
            if(index != -1){
                ipAddress = ipAddress.substring(0, index);
            }
        }
        if(ipAddress == null || ipAddress.length() == 0 || UNKNOWN.equalsIgnoreCase(ipAddress)){
            ipAddress = request.getHeader(X_REAL_IP);
        }
        if (ipAddress == null || ipAddress.length() == 0 || UNKNOWN.equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getHeader(PROXY_CLIENT_IP);
        }
        if (ipAddress == null || ipAddress.length() == 0 || UNKNOWN.equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getHeader(WL_PROXY_CLIENT_IP);
        }
        if (ipAddress == null || ipAddress.length() == 0 || UNKNOWN.equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getRemoteAddr();
        }
        return ipAddress;
    }



}
