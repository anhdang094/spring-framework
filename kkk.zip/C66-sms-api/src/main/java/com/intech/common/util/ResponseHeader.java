package com.intech.common.util;

import java.io.Serializable;

/**
 * @description: http json 消息头
 * @author: Condi
 * @create: 2018-10-24 15:44
 **/

public class ResponseHeader implements Serializable {

    /**
     * 是否成功
     */
    private boolean success = false;



    /**
     * 耗时  单位ms
     */
    private long cost;

    /**
     * 错误代码
     */
    private String errCode;
    /**
     * 错误代码
     */
    private String errMsg;

    /**
     * 返回信息(中文)
     */
    private String errMsgCN;

    /**
     * 请求id
     */
    private String requestUUID;

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public long getCost() {
        return cost;
    }

    public void setCost(long cost) {
        this.cost = cost;
    }

    public String getErrCode() {
        return errCode;
    }

    public void setErrCode(String errCode) {
        this.errCode = errCode;
    }

    public String getErrMsg() {
        return errMsg;
    }

    public void setErrMsg(String errMsg) {
        this.errMsg = errMsg;
    }

    public String getErrMsgCN() {
        return errMsgCN;
    }

    public void setErrMsgCN(String errMsgCN) {
        this.errMsgCN = errMsgCN;
    }

    public String getRequestUUID() {
        return requestUUID;
    }

    public void setRequestUUID(String requestUUID) {
        this.requestUUID = requestUUID;
    }
    public ResponseHeader() {
    }
    public ResponseHeader(boolean success, String errCode, String errMsg, String errMsgCN) {
        this.success = success;
        this.errCode = errCode;
        this.errMsg = errMsg;
        this.errMsgCN = errMsgCN;
    }
}


    
