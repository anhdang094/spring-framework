package com.intech.common.util;

import com.intech.common.enums.ErrorCodeEnum;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.ThreadContext;

import java.io.Serializable;

/**
 * @description: 统一返回结果
 * @author: Condi
 * @create: 2018-10-17 11:24
 **/

public class Result<T> implements Serializable {

    /**
     * 返回消息头
     */
    private ResponseHeader head;


    /**
     * 消息体  装载返回结果数据
     */
    private T body;

    /**
     * @param code    error code
     * @param message success or error messages
     */
    public Result(boolean success, String code, String message, String messageCn) {
        head = new ResponseHeader(success,code,message,messageCn);
        formatHead();
    }


    /**
     * @param: [success, enumCode]
     * @return:
     * @throws:
     * @Author: "Condi"
     * @Date:
     */
    public Result(boolean success, ErrorCodeEnum enumCode) {
        head = new ResponseHeader(success,enumCode.getCode(),enumCode.getDesc(),enumCode.getDescCn());
        formatHead();
    }

    public ResponseHeader getHead() {
        return head;
    }

    public void setHead(ResponseHeader head) {
        this.head = head;
    }

    public T getBody() {
        return body;
    }

    public void setBody(T body) {
        this.body = body;
    }

    /**
    * 格式化head
     *
    * @param: []
    * @return: void
    * @throws:
    * @Author: "Condi"
    * @Date: 2018/10/24
    */
    private void formatHead(){
        long cost = 0;
        String invokeTime =  ThreadContext.get("invokeTime");
        if(StringUtils.isNotEmpty(invokeTime)){
            long start =Long.valueOf(invokeTime);
            cost = System.currentTimeMillis()-start;
        }
        this.getHead().setRequestUUID(ThreadContext.get("uuid"));
        this.getHead().setCost(cost);
    }
}


    
