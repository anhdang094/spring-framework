package com.intech.common.util;

import com.intech.common.enums.ErrorCodeEnum;
import org.apache.commons.lang3.StringUtils;

/**
 * @description: 统一返回工具封装
 * @author: Condi
 * @create: 2018-10-24 11:35
 **/

public class ResultUtil {


    /**
     * return success
     *
     * @param data
     * @return
     */
    public static <T> Result<T> returnSuccess(T data) {
        Result<T> result = new Result(true, ErrorCodeEnum.SUCCESS);
        result.setBody(data);
        return result;
    }

    /** 
    * 
    * @param: [code, errMsg, errMsgCN]
    * @return: com.rest.common.Result
    * @throws:       
    * @Author: "Condi"
    * @Date: 2018/10/24 
    */
    public static Result returnError(String code, String errMsg, String errMsgCN) {
        Result result = new Result(false,code,errMsg,errMsgCN);
        result.setBody("");
        return result;

    }

    /**
     * 字符串错误码和消息返回
     * 类似  “500000^Parameters cannot be null!^参数不能为空! ”   的格式
     *
     * @param error
     * @return
     */
    public static Result returnError(String error) {
        if(StringUtils.isNotEmpty(error)){
            String[] errorArr =error.split("\\^");
            if(errorArr.length==3){
                return returnError(errorArr[0], errorArr[1],errorArr[2]);
            }
        }
        return returnErrorEnum(ErrorCodeEnum.UNKNOWN_ERROR);
    }
    /**
     * use enum  返回错误消息
     *
     * @param status
     * @return
     */
    public static Result returnErrorEnum(ErrorCodeEnum status) {
        return returnError(status.getCode(), status.getDesc(),status.getDescCn());
    }
}


    
