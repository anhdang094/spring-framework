package com.intech.common.util;

import com.ws.SmsResponse;
import com.intech.common.enums.ErrorCodeEnum;
import org.springframework.validation.ObjectError;

import java.util.List;

/**
 * @description: 统一返回工具封装
 * @author: Condi
 * @create: 2018-10-12 11:35
 **/

public class ResultUtilOld {


    /**
     * return success
     *
     * @param data
     * @return
     */
    public static <T> SmsResponse<T> returnSuccess(T data) {
        SmsResponse<T> result = new SmsResponse();
        result.setCode(ErrorCodeEnum.SUCCESS.getCode());
        result.setSuccess(true);
        result.setData(data);
        result.setMessage(ErrorCodeEnum.SUCCESS.getDesc());
        return result;
    }

    /**
     * return error
     *
     * @param code error code
     * @param msg  error message
     * @return
     */
    public static SmsResponse returnError(String code, String msg) {
        SmsResponse result = new SmsResponse();
        result.setCode(code);
        result.setData("");
        result.setMessage(msg);
        return result;

    }

    /**
     * use enum
     *
     * @param status
     * @return
     */
    public static SmsResponse returnError(ErrorCodeEnum status) {
        return returnError(status.getCode(), status.getDesc());
    }

    /**
    *
    * @param: [allErrors]
    * @return: com.condi.api.common.SmsResponse
    * @throws:
    * @Author: "Condi"
    * @Date: 2018/10/25
    */
    public static SmsResponse returnErrorList(List<ObjectError> allErrors) {
        SmsResponse result = new SmsResponse();
        result.setData("");
        StringBuffer code = new StringBuffer();
        StringBuffer msg = new StringBuffer();
        for(ObjectError error:allErrors){
            code.append(error.getCode()).append(";");
            msg.append(error.getDefaultMessage()).append(";");
        }
        result.setCode(code.toString());
        result.setMessage(msg.toString());
        return result;
    }
}


    
