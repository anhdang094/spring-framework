package com.intech.configuration;

import com.intech.sms.util.PHPDESEncrypt;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.pool.PooledConnectionFactory;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.core.JmsTemplate;

import javax.jms.ConnectionFactory;


/**
 * @description: ActiveMqConfig
 * @author: Condi
 * @create: 2018-12-04 11:08
 **/

@Configuration
public class ActiveMqConfig {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Value("${spring.activemq.user}")
    private String usrName;

    @Value("${spring.activemq.password}")
    private  String password;

    @Value("${spring.activemq.broker-url}")
    private  String brokerUrl;
    @Value("${spring.activemq.password.key}")
    private  String key;
    @Value("${spring.activemq.send-timeout:3000}")
    private  int sendTimeOut;
    @Value("${spring.activemq.pool.max-connections:10}")
    private  int maxConnection;
    @Bean
    public ActiveMQConnectionFactory targetConnectionFactory(){
        if (logger.isInfoEnabled()) {
            logger.info(String.format("ActiveMQ url:%s, key:%s", brokerUrl, key));
        }
        String pass = StringUtils.EMPTY;
        if (StringUtils.isNotBlank(password)) {
            PHPDESEncrypt pe = new PHPDESEncrypt(key, "");
            try {
                pass = pe.decrypt(password);
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
            }
        }
        ActiveMQConnectionFactory mq =  new ActiveMQConnectionFactory(usrName, pass, brokerUrl);
        mq.setSendTimeout(sendTimeOut);
        return mq;
    }

    @Bean
    public ConnectionFactory connectionFactory(){
        PooledConnectionFactory pool =  new PooledConnectionFactory(targetConnectionFactory());
        pool.setMaxConnections(maxConnection);
        return pool;
    }

    @Bean
    public JmsTemplate jmsTemplate(ConnectionFactory connectionFactory){
        return new JmsTemplate(connectionFactory);
    }


}


    
