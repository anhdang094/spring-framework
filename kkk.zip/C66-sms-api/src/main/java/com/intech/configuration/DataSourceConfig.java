package com.intech.configuration;

import com.intech.dbcryptor.Cryptor;
import com.zaxxer.hikari.HikariDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.annotation.Resource;
import javax.sql.DataSource;
import java.util.Properties;

/**
 * @description:
 * @author: Condi
 * @create: 2018-12-07 17:32
 **/

@Configuration
@EnableConfigurationProperties(DataSourceProperties.class)
public class DataSourceConfig {

    @Value("${spring.datasource.url}")
    private String url;
    @Value("${spring.datasource.driver-class-name}")
    private String driverClassName;
    @Value("${spring.datasource.username}")
    private String username;
    @Value("${spring.datasource.password}")
    private String password;
    @Value("${spring.datasource.session.program}")
    private String program;
    @Resource
    DataSourceProperties properties;
    /** 操作日志 */
    protected static final Logger operatorLogger = LoggerFactory.getLogger(DataSourceConfig.class);
    @Bean
    public DataSource dataSource() {
        HikariDataSource dataSource = DataSourceBuilder.create().type(HikariDataSource.class).build();
        dataSource.setJdbcUrl(url);
        dataSource.setDriverClassName(driverClassName);
        try {
            dataSource.setUsername(Cryptor.decryptContent(username));
            dataSource.setPassword(Cryptor.decryptContent(password));
            operatorLogger.info("数据库用户名或者密码解密成功");
        }catch (Exception e){
            operatorLogger.error("数据库用户名或者密码解密失败"+e.getMessage());
            dataSource.setUsername(username);
            dataSource.setPassword(password);
        }
        dataSource.setConnectionTimeout(properties.getConnectionTimeout());
        dataSource.setMaximumPoolSize(properties.getMaximumPoolSize());
        dataSource.setMinimumIdle(properties.getMinimumIdle());
        dataSource.setIdleTimeout(properties.getIdleTimeout());
        dataSource.setAutoCommit(properties.isAutoCommit());
        dataSource.setMaxLifetime(properties.getMaxLifeTime());
        dataSource.setPoolName(properties.getPoolName());
        dataSource.setConnectionTestQuery(properties.getConnectionTestQuery());
        Properties properties  = new Properties();
        properties.setProperty("v$session.program",program);
        dataSource.setDataSourceProperties(properties);
        return dataSource;
    }


}


    
