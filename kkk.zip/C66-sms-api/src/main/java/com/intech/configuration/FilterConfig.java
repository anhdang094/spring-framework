package com.intech.configuration;

import com.intech.filter.LoggerMdcFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @description: 应用过滤器配置类
 * @author: Condi
 * @create: 2018-10-17 09:46
 **/


@Configuration
@SuppressWarnings("unchecked")
public class FilterConfig {

    @Bean(name="loggerMdcFilter")
    public LoggerMdcFilter restLoggingRequestProxyFilter() {
        return  new LoggerMdcFilter();
    }

    @Bean(name="log4jFilter")
    public FilterRegistrationBean certProxy() {
        FilterRegistrationBean registration = new FilterRegistrationBean(restLoggingRequestProxyFilter());
        registration.addUrlPatterns("/*");
        return registration;
    }
}


    
