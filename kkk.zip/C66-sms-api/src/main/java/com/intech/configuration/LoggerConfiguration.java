package com.intech.configuration;

import com.ctrip.framework.apollo.Config;
import com.ctrip.framework.apollo.ConfigService;
import com.ctrip.framework.apollo.model.ConfigChangeEvent;
import com.ctrip.framework.apollo.spring.annotation.ApolloConfigChangeListener;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.logging.LogLevel;
import org.springframework.boot.logging.LoggingSystem;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Set;

/**
 * @description:
 * @author: Condi
 * @create: 2019-02-01 11:40
 **/

@Component
public class LoggerConfiguration {

    private static final Logger logger = LoggerFactory.getLogger(LoggerConfiguration.class);
    private static final String LOGGER_TAG = "log.level";

    @Value("${apollo.bootstrap.namespaces}")
    private String namespaces;
    @Autowired
    private LoggingSystem loggingSystem;

    private Config config;

    private static boolean containsIgnoreCase(String str, String searchStr) {
        if (str == null || searchStr == null) {
            return false;
        }
        int len = searchStr.length();
        int max = str.length() - len;
        for (int i = 0; i <= max; i++) {
            if (str.regionMatches(true, i, searchStr, 0, len)) {
                return true;
            }
        }
        return false;
    }
    @PostConstruct
    private void init() {
        config = ConfigService.getConfig(namespaces);
        config.addChangeListener(this::load);
        load();
    }

    private void load(ConfigChangeEvent configChangeEvent) {
        if (configChangeEvent.changedKeys().contains(LOGGER_TAG)) {
            String strLevel = config.getProperty(LOGGER_TAG, "info");
            LogLevel level = LogLevel.valueOf(strLevel.toUpperCase());
            loggingSystem.setLogLevel(LOGGER_TAG.replace(LOGGER_TAG, ""), level);
            logger.info("{}:{}", LOGGER_TAG, strLevel);
        }
    }

    private void load() {
        Set<String> keyNames = config.getPropertyNames();
        for (String key : keyNames) {
            if (containsIgnoreCase(key, LOGGER_TAG)) {
                String strLevel = config.getProperty(key, "info");
                LogLevel level = LogLevel.valueOf(strLevel.toUpperCase());
                loggingSystem.setLogLevel(key.replace(LOGGER_TAG, ""), level);
                logger.info("{}:{}", key, strLevel);
            }
        }
    }
}


    
