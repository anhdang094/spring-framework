package com.intech.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import javax.annotation.Resource;

/**
 * @description: config
 * @author: Condi
 * @create: 2018-12-04 15:55
 **/

@Configuration
public class PropertiesConfig {

    @Value("${exchange.name.sms}")
    private String smsExchangeName;

    @Value("${jms.queuename}")
    private String jsmQueneName;


    @Value("${allow.reply}")
    private String allowReply;
    @Value("${RESTART.TIME.DELAY}")
    private String restartTimeDelay;
    @Value("${encryption.key}")
    private String encryptionKey;


    @Value("${S04.USERID}")
    private String s04UserId;
    @Value("${S05.USERID}")
    private String s05UserId;




    @Value("${S14.METHOD}")
    private String s14Method;
    @Value("${S14.APP.KEY}")
    private String s14AppKey;
    @Value("${S14.FORMAT}")
    private String s14Format;
    @Value("${S14.V}")
    private String s14Version;
    @Value("${S14.SIGN.METHOD}")
    private String s14SignMethod;
    @Value("${S14.APPSECRET}")
    private String s14AppSecret;
    @Value("${S14.TEMPLATE_CODE}")
    private String s14TemplateCode;

    @Value("${thread.reply.size}")
    private int threadCoreSize;
    @Value("${thread.reply.max.size}")
    private int threadMaxSize;
    @Value("${thread.reply.alive.time}")
    private long keepAliveTime;


    @Value("${max.failed}")
    private int maxFailed;

    @Value("${daily.failed}")
    private int dailyFailed;
    @Value("${continuous.failed}")
    private int continuousFailed;
    @Value("${interval.time}")
    private long intervalTime;
    @Value("${email.to}")
    private String emailTo;
    @Value("${email.subject}")
    private String emailSubject;
    @Value("${email.content}")
    private String emailContent;
    @Value("${email.continuous.to}")
    private String emailContinuousTo;
    @Value("${email.continuous.subject}")
    private String emailContinuousSubject;
    @Value("${email.continuous.content}")
    private String emailContinuousContent;



    @Value("${email.timeout}")
    private String emailTimeout;
    @Value("${email.server}")
    private String emailServer;
    @Value("${email.port}")
    private String emailPort;
    @Value("${email.user.name}")
    private String emailUserName;
    @Value("${email.password}")
    private String emailPassword;
    @Value("${email.from}")
    private String emailFrom;
    @Value("${email.display.name}")
    private String emailDisplayName;
    @Value("${http.max.client.num:}")
    private Integer httpMaxClientNum;
    @Value("${http.max.per.route:}")
    private Integer httpMaxPerRoute;

    @Resource
    private Environment env;

    public String getAllowReply() {
        return allowReply;
    }

    public void setAllowReply(String allowReply) {
        this.allowReply = allowReply;
    }

    public String getSmsExchangeName() {
        return smsExchangeName;
    }

    public void setSmsExchangeName(String smsExchangeName) {
        this.smsExchangeName = smsExchangeName;
    }

    public String getJsmQueneName() {
        return jsmQueneName;
    }

    public void setJsmQueneName(String jsmQueneName) {
        this.jsmQueneName = jsmQueneName;
    }

    public String getRestartTimeDelay() {
        return restartTimeDelay;
    }

    public void setRestartTimeDelay(String restartTimeDelay) {
        this.restartTimeDelay = restartTimeDelay;
    }

    public String getEncryptionKey() {
        return encryptionKey;
    }

    public void setEncryptionKey(String encryptionKey) {
        this.encryptionKey = encryptionKey;
    }

    public String getS04UserId() {
        return s04UserId;
    }

    public void setS04UserId(String s04UserId) {
        this.s04UserId = s04UserId;
    }

    public String getS05UserId() {
        return s05UserId;
    }

    public void setS05UserId(String s05UserId) {
        this.s05UserId = s05UserId;
    }

    public String getS14Method() {
        return s14Method;
    }

    public void setS14Method(String s14Method) {
        this.s14Method = s14Method;
    }

    public String getS14AppKey() {
        return s14AppKey;
    }

    public void setS14AppKey(String s14AppKey) {
        this.s14AppKey = s14AppKey;
    }

    public String getS14Format() {
        return s14Format;
    }

    public void setS14Format(String s14Format) {
        this.s14Format = s14Format;
    }

    public String getS14Version() {
        return s14Version;
    }

    public void setS14Version(String s14Version) {
        this.s14Version = s14Version;
    }

    public String getS14SignMethod() {
        return s14SignMethod;
    }

    public void setS14SignMethod(String s14SignMethod) {
        this.s14SignMethod = s14SignMethod;
    }

    public String getS14AppSecret() {
        return s14AppSecret;
    }

    public void setS14AppSecret(String s14AppSecret) {
        this.s14AppSecret = s14AppSecret;
    }

    public String getS14TemplateCode() {
        return s14TemplateCode;
    }

    public void setS14TemplateCode(String s14TemplateCode) {
        this.s14TemplateCode = s14TemplateCode;
    }

    public int getThreadCoreSize() {
        return threadCoreSize;
    }

    public void setThreadCoreSize(int threadCoreSize) {
        this.threadCoreSize = threadCoreSize;
    }

    public int getThreadMaxSize() {
        return threadMaxSize;
    }

    public void setThreadMaxSize(int threadMaxSize) {
        this.threadMaxSize = threadMaxSize;
    }

    public long getKeepAliveTime() {
        return keepAliveTime;
    }

    public void setKeepAliveTime(long keepAliveTime) {
        this.keepAliveTime = keepAliveTime;
    }

    public int getMaxFailed() {
        return maxFailed;
    }

    public void setMaxFailed(int maxFailed) {
        this.maxFailed = maxFailed;
    }

    public int getDailyFailed() {
        return dailyFailed;
    }

    public void setDailyFailed(int dailyFailed) {
        this.dailyFailed = dailyFailed;
    }

    public int getContinuousFailed() {
        return continuousFailed;
    }

    public void setContinuousFailed(int continuousFailed) {
        this.continuousFailed = continuousFailed;
    }

    public long getIntervalTime() {
        return intervalTime;
    }

    public void setIntervalTime(long intervalTime) {
        this.intervalTime = intervalTime;
    }

    public String getEmailTo() {
        return emailTo;
    }

    public void setEmailTo(String emailTo) {
        this.emailTo = emailTo;
    }

    public String getEmailSubject() {
        return emailSubject;
    }

    public void setEmailSubject(String emailSubject) {
        this.emailSubject = emailSubject;
    }

    public String getEmailContent() {
        return emailContent;
    }

    public void setEmailContent(String emailContent) {
        this.emailContent = emailContent;
    }

    public String getEmailContinuousTo() {
        return emailContinuousTo;
    }

    public void setEmailContinuousTo(String emailContinuousTo) {
        this.emailContinuousTo = emailContinuousTo;
    }

    public String getEmailContinuousSubject() {
        return emailContinuousSubject;
    }

    public void setEmailContinuousSubject(String emailContinuousSubject) {
        this.emailContinuousSubject = emailContinuousSubject;
    }

    public String getEmailContinuousContent() {
        return emailContinuousContent;
    }

    public void setEmailContinuousContent(String emailContinuousContent) {
        this.emailContinuousContent = emailContinuousContent;
    }

    public String getEmailTimeout() {
        return emailTimeout;
    }

    public void setEmailTimeout(String emailTimeout) {
        this.emailTimeout = emailTimeout;
    }

    public String getEmailServer() {
        return emailServer;
    }

    public void setEmailServer(String emailServer) {
        this.emailServer = emailServer;
    }

    public String getEmailPort() {
        return emailPort;
    }

    public void setEmailPort(String emailPort) {
        this.emailPort = emailPort;
    }

    public String getEmailUserName() {
        return emailUserName;
    }

    public void setEmailUserName(String emailUserName) {
        this.emailUserName = emailUserName;
    }

    public String getEmailPassword() {
        return emailPassword;
    }

    public void setEmailPassword(String emailPassword) {
        this.emailPassword = emailPassword;
    }

    public String getEmailFrom() {
        return emailFrom;
    }

    public void setEmailFrom(String emailFrom) {
        this.emailFrom = emailFrom;
    }

    public String getEmailDisplayName() {
        return emailDisplayName;
    }

    public void setEmailDisplayName(String emailDisplayName) {
        this.emailDisplayName = emailDisplayName;
    }

    public String getEncryptPhoneKey(String productId) {
        return env.getProperty(productId + ".03.KEY");
    }

    public Integer getHttpMaxClientNum() {
        return httpMaxClientNum;
    }

    public void setHttpMaxClientNum(Integer httpMaxClientNum) {
        this.httpMaxClientNum = httpMaxClientNum;
    }

    public Integer getHttpMaxPerRoute() {
        return httpMaxPerRoute;
    }

    public void setHttpMaxPerRoute(Integer httpMaxPerRoute) {
        this.httpMaxPerRoute = httpMaxPerRoute;
    }
}


    
