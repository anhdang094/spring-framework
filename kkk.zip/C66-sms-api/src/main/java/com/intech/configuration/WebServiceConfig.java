package com.intech.configuration;
import com.ws.SmsService;
import org.apache.cxf.Bus;
import org.apache.cxf.bus.spring.SpringBus;
import org.apache.cxf.jaxws.EndpointImpl;
import org.apache.cxf.transport.servlet.CXFServlet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.ws.config.annotation.EnableWs;
import org.springframework.ws.config.annotation.WsConfigurerAdapter;
import org.springframework.ws.transport.http.MessageDispatcherServlet;

import javax.xml.ws.Endpoint;

/**
 * @description: SoapConfig
 * @author: Condi
 * @create: 2018-11-29 16:18
 **/

@Configuration
@EnableWs
public class WebServiceConfig extends WsConfigurerAdapter {

        @Autowired
        private SmsService smsService;

        @Bean
        @SuppressWarnings("unchecked")
        public ServletRegistrationBean messageDispatcherServlet(ApplicationContext applicationContext) {
                MessageDispatcherServlet servlet = new MessageDispatcherServlet();
                servlet.setApplicationContext(applicationContext);
                servlet.setTransformWsdlLocations(true);
                //配置对外服务根路径
                ServletRegistrationBean registrationBean =  new ServletRegistrationBean(new CXFServlet(),"/services/*");
                //发布服务名称
                registrationBean.setLoadOnStartup(1);
                return registrationBean;
        }

        @Bean(name = Bus.DEFAULT_BUS_ID)
        public SpringBus springBus()
        {
                return  new SpringBus();
        }
        @Bean
        public Endpoint endpoint() {
                //绑定要发布的服务
                EndpointImpl endpoint = new EndpointImpl(springBus(),smsService);
                //显示要发布的名称
                endpoint.publish("/SmsAPI");
                return endpoint;
        }

}



    
