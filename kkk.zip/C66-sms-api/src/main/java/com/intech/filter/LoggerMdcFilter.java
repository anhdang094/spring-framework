package com.intech.filter;

import org.apache.logging.log4j.ThreadContext;
import org.slf4j.MDC;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.UUID;

/**
 * @author Herman.T
 */
public class LoggerMdcFilter extends OncePerRequestFilter implements Filter {
    @Override
    protected void doFilterInternal(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, FilterChain filterChain) throws ServletException, IOException {
        try {
            ThreadContext.put("invokeTime", String.valueOf(System.currentTimeMillis()));
            MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
            filterChain.doFilter(httpServletRequest, httpServletResponse);
        }finally {
            MDC.remove("uuid");
            MDC.remove("invokeTime");
        }
    }
}
