package com.intech.listener;

import com.alibaba.fastjson.JSON;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.info.GitProperties;
import org.springframework.stereotype.Component;
import javax.annotation.PostConstruct;
/**
 * @description:
 * @author: Condi
 * @create: 2019-02-21 10:17
 **/

@Component
public class StartUpListener {
    private static final Logger logger = LoggerFactory.getLogger(StartUpListener.class);

    @Value("${apollo.bootstrap.namespaces}")
    private String productId;



    @PostConstruct
    private void startUp(){
        printProjectInfo();
    }

    @Autowired
    private GitProperties gitProperties;

    private void printProjectInfo() {
        try {
            logger.info("############################ 当前产品为：" + productId + " ############################");
            logger.info("============================Print project version start.============================");
            logger.info("\n" + JSON.toJSONString(gitProperties,true));
            logger.info("============================Print project version end.==============================");
        } catch (Exception e) {
            logger.error("can't read file git.properties,error msg:{}", e.getMessage(), e);
        }
    }


}


    
