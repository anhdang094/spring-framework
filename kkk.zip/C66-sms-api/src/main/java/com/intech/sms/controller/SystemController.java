package com.intech.sms.controller;
import com.intech.sms.util.RequestIpUtil;
import com.intech.systeminfo.ApplicationInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.actuate.info.InfoEndpoint;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
/**
 * @description: SystemController
 * @author: Condi
 * @create: 2018-11-29 14:55
 **/

@Api(tags = "Health Check Model", description = "健康检查接口模块")
@RestController
public class SystemController {

    @Value("${apollo.bootstrap.namespaces:public}")
    private String productId;

    @Autowired
    private InfoEndpoint infoEndpoint;

    @ApiOperation(
            value = "health ",
            notes = "health",
            response = ApplicationInfo.class,
            httpMethod = "GET"
    )
    @GetMapping("health")
    @ResponseBody
    public String health(HttpServletRequest request) {
        ApplicationInfo applicationInfo = ApplicationInfo.initApplicationInfo(productId);
        String resp = applicationInfo.getHealthInfo(infoEndpoint, RequestIpUtil.getIpAddress(request),100, 10000L);
        return resp;
    }




}


    
