package com.intech.sms.dao;

import com.intech.sms.model.*;
import com.ws.SmsContent;
import com.ws.SmsType;

import java.util.Date;
import java.util.List;


/**
 * @author Gary
 */
public interface SMSOperateDao {

    String getSmsContentTemplate(SmsContent content) throws Exception;

    Sms insertSmsContent(SmsContent content) throws Exception;

    Sms insertMultiSmsContent(List<SmsContent> content) throws Exception;


    Sms insertBulkSmsContent(SmsContent content) throws Exception;

    List<Product> queryProducts();

    List<Configuration> queryAccounts();

    List<Sms> querySmsList(String productId, int tier, String customerLevel);

    Configuration getAccount(String accountId);

    int getFailed(String accountId);

    Product getProductById(String productId);

    boolean batchUpdateSmsStatus(List<Sms> smsList) throws Exception;

    boolean updateSmsStatus(Sms sms) throws Exception;

    boolean updateAccountStats(String accountId, boolean isSent) throws Exception;

    boolean insertMonitorRecord(Date monitorDate, String status, String contentId, Long accountId) throws Exception;

    Configuration queryReplyConfigForProduct(String productId, String providerCode);

    ServerInfo getServerInfoByProductId(String productId);

    List<String> getCustomerLevels(String productId);

    List<Configuration> queryRecentlyModifiedAccounts();

    List<Configuration> getActiveAccounts(String productId, int tier, String customerLevel, boolean isInternational, String providerCode,Integer sendMethod,Integer groupFlag,Integer status,String countryCode);

    boolean hasAccount(String productId, int tier, String customerLevel);

    String querySmsTypeTier(String smsType);

    List<String> queryAllApproveSmsType();

    int countSmsContent(String productId, String phoneHash, String startDate, String endDate, String typeCode, String source,String sender) throws Exception;

    List<SmsConstant> getSmsConstantByKey(String productId, String key);

    void updateSmsStatusClose();

    String getAccountByContentId(String contentId);

    void updateMonitorRecord(String mId,Integer status);

    SmsType querySmsType(String smsType);

    Long insertSmsRecord(SmsGenRecord record);

    void genSmsRecord(String genBatchNo, SmsContent smsContent, Integer status, String remarks);
}
