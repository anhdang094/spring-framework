package com.intech.sms.dao;

import com.ws.SmsType;

import java.util.List;

/**
 * @description:
 * @author: Condi
 * @create: 2019-03-20 11:07
 **/

public interface SmsTypeDao {
    SmsType getSmsTypeByCode(String typeCode);

    List<SmsType> queryChildTypes(Long typeId);
}


    
