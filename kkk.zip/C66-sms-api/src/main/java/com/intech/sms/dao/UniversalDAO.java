package com.intech.sms.dao;

import com.intech.sms.exception.DAOException;
import com.intech.sms.model.MsgMqSendRecord;
import com.intech.sms.model.Reply;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import java.util.List;

/**
 * @author kaiser.dapar
 * @version 1.0, Feb 27, 2015
 */
public interface UniversalDAO {
	
	public final Logger LOGGER = LoggerFactory.getLogger(UniversalDAO.class);
	
	public <T> List<T> list(String sql, ResultSetExtractor resultSetExtractor, Object... parameters) throws DAOException;
	public <T> T object(String sql, RowMapper rowMapper, Object... parameters) throws DAOException;
	public <T> T insert(String sql, String column, Object...parameters) throws DAOException;
	public int update(String sql, Object... parameters) throws DAOException;

	int batchUpdateMsgMqSendRecord(String sql, List<MsgMqSendRecord> list);

	int batchUpdateReplies(String sql, List<Reply> list);
}