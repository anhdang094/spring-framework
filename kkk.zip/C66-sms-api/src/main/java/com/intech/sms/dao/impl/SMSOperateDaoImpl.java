package com.intech.sms.dao.impl;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.inteValue.Crypt;
import com.intech.configuration.PropertiesConfig;
import com.intech.sms.dao.SMSOperateDao;
import com.intech.sms.model.*;
import com.intech.sms.util.*;
import com.ws.SmsContent;
import com.ws.SmsType;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.*;

@Repository("SMSOperateDao")
public class SMSOperateDaoImpl implements SMSOperateDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(SMSOperateDaoImpl.class);

    private static HashMap<String, SmsType> smsTypeMap = new HashMap<>();

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Value("${server.id:}")
    private String serverId;

    @Autowired
    private PropertiesConfig propertiesConfig;

    @Autowired
    private SMSOperateDao smsOperateDao;

    @Override
    public String getSmsContentTemplate(SmsContent content) throws Exception {
        String template = StringUtils.EMPTY;
        SmsType smsType = querySmsType(content.getSmstype());
        if (smsType != null) {
            //查询模板
            try {
                String sql = "SELECT content" +
                        "      FROM t_smscontent_template " +
                        "     WHERE product_id =?" +
                        "       AND type_id = ?";
                List<Object> objects = new ArrayList<>();
                objects.add(content.getProductid());
                objects.add(smsType.getTypeId());
                template = jdbcTemplate.queryForObject(sql, objects.toArray(), String.class);
            } catch (Exception e) {
                LOGGER.error("查询短信模板异常：" + e.getMessage(), e);
                LOGGER.info("开始查询默认短信模板");
                String sql = "SELECT content FROM t_smscontent_template WHERE product_id =? AND type_id = ? AND rownum = 1";
                List<Object> objects = new ArrayList<>();
                objects.add(content.getProductid());
                objects.add(smsType.getTypeId());
                template = jdbcTemplate.queryForObject(sql, objects.toArray(), String.class);
            }

        } else {
            LOGGER.error("不存在的短信类型{}", content.getSmstype());
        }
        return template;
    }


    @Override
    public SmsType querySmsType(String smsType) {
        /*SmsType temp = smsTypeMap.get(smsType);
        if (temp != null) {
            return temp;
        } else {
            synchronized (this) {
                temp = smsTypeMap.get(smsType);
                if (temp != null) {
                    return temp;
                }
                String sql = "SELECT TYPE_ID,TYPE_NAME,TYPE_CODE,TIER,DISABLE_FLAG FROM T_SMS_TYPE where type_code =? ";
                SmsType result = null;
                try {
                    result = jdbcTemplate.queryForObject(sql, (resultSet, i) -> new SmsType(resultSet.getLong("TYPE_ID"),
                            resultSet.getString("TYPE_NAME"), resultSet.getString("TIER"),
                            resultSet.getString("TYPE_CODE"), resultSet.getInt("DISABLE_FLAG")), smsType);
                } catch (Exception e) {
                    LOGGER.error("查询短信类型异常", e);
                }
                if (result != null) {
                    smsTypeMap.put(smsType, result);
                }
                return result;
            }
        }*/


        //更改为直接查询数据库的方式 ,不然更改DISABLE_FLAG字段不会生效
        String sql = "SELECT TYPE_ID,TYPE_NAME,TYPE_CODE,TIER,DISABLE_FLAG FROM T_SMS_TYPE where type_code =? ";
        SmsType result = null;
        try {
            result = jdbcTemplate.queryForObject(sql, (resultSet, i) -> new SmsType(resultSet.getLong("TYPE_ID"),
                    resultSet.getString("TYPE_NAME"), resultSet.getString("TIER"),
                    resultSet.getString("TYPE_CODE"), resultSet.getInt("DISABLE_FLAG")), smsType);
        } catch (Exception e) {
            LOGGER.error("查询短信类型异常", e);
        }
        return result;
    }

    @Override
    public Long insertSmsRecord(SmsGenRecord record) {
        try {
            int result = 0;
            String sql = "INSERT INTO T_SMS_GEN_RECORD (id,PRODUCT_ID,login_name,status,type_code," +
                    "   provider_code,customer_level,origin_content,create_date,last_update_date,req_id,remarks,batch_id,CREATED_BY,LAST_UPDATE_BY) VALUES (" +
                    "      T_SMS_GEN_RECORD_SEQ.NEXTVAL,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            KeyHolder keyHolder = new GeneratedKeyHolder();
            result = jdbcTemplate.update(connection -> {
                PreparedStatement ps = connection.prepareStatement(sql, new String[]{"id"});
                try {
                    ps.setString(1, record.getProductId());
                    ps.setString(2, record.getLoginName());
                    ps.setInt(3, record.getStatus());
                    ps.setString(4, record.getTypeCode());
                    ps.setString(5, record.getProviderCode());
                    ps.setString(6, record.getCustomerLevel());
                    ps.setString(7, record.getOriginContent());
                    ps.setTimestamp(8, record.getCreateDate());
                    ps.setTimestamp(9, record.getLastUpdateDate());
                    ps.setString(10, record.getReqId());
                    ps.setString(11, record.getRemarks());
                    ps.setString(12, record.getBatchId());
                    ps.setString(13, "sms-api");
                    ps.setString(14, "sms-api");
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
                return ps;
            }, keyHolder);
            if (result > 0) {
                return keyHolder.getKey().longValue();
            }
        } catch (Exception e) {
            LOGGER.error("插入短信异常", e);
        }
        return 0L;
    }

    @Override
    public void genSmsRecord(String genBatchNo, SmsContent smsContent, Integer status, String remarks) {
        try {
            Gson gson = new GsonBuilder().create();
            SmsGenRecord genRecord = new SmsGenRecord();
            genRecord.setLoginName(smsContent.getLoginname());
            genRecord.setBatchId(genBatchNo);
            genRecord.setCreateDate(new Timestamp(System.currentTimeMillis()));
            genRecord.setCustomerLevel(smsContent.getCustomerLevel());
            genRecord.setLastUpdateDate(new Timestamp(System.currentTimeMillis()));
            genRecord.setOriginContent(gson.toJson(smsContent));
            genRecord.setProductId(smsContent.getProductid());
            genRecord.setProviderCode(smsContent.getProvidercode());
            genRecord.setReqId(smsContent.getRequestId());
            genRecord.setTypeCode(smsContent.getSmstype());
            genRecord.setStatus(status);
            genRecord.setRemarks(remarks);
            smsOperateDao.insertSmsRecord(genRecord);
        } catch (Exception e) {
            LOGGER.error("生成短信记录失败：{}", e.getMessage(), e);
        }
    }

    @Override
    public Product getProductById(String productId) {
        List<Product> list = new ArrayList<>();
        try {
            String sql = "SELECT * FROM t_product WHERE PRODUCT_ID = ?";
            List<Object> params = new ArrayList<>();
            params.add(productId);
            List<Map<String, Object>> fcuss = jdbcTemplate.queryForList(sql, params.toArray());
            for (Map<String, Object> rs : fcuss) {
                Product temp = setProduct(rs);
                list.add(temp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return CollectionUtils.isNotEmpty(list) ? list.get(0) : null;
    }

    @Override
    public Sms insertSmsContent(SmsContent content) throws Exception {
        Sms sms = null;
        String encryptedPhone = Crypt.encrypt(content.getPhone(), Integer.valueOf(propertiesConfig.getEncryptionKey()), false);
        //String encryptedPhone = content.getPhone();
        String hashedPhone = Convert.MD5Encode(content.getPhone());
        SmsType smsType = querySmsType(content.getSmstype());
        if (smsType != null) {
            try {
                int result = 0;
                String sql = "INSERT INTO T_SMS_CONTENT (CONTENT_ID,PRODUCT_ID,TYPE_ID,CREATED_BY,ENCRYPTED_PHONE," +
                        "   SEND_CONTENT,LOGINNAME,REAL_NAME,PROVIDER_CODE,CUSTOMER_LEVEL,HASHED_PHONE,REQUEST_ID,RESERVED1) VALUES (" +
                        "      T_SMS_CONTENT_SEQ.NEXTVAL,?,?,?,?,?,?,?,?,?,?,?,?)";
                KeyHolder keyHolder = new GeneratedKeyHolder();
                result = jdbcTemplate.update(new PreparedStatementCreator() {
                    @Override
                    public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
                        PreparedStatement ps = connection.prepareStatement(sql, new String[]{"CONTENT_ID"});
                        try {
                            ps.setString(1, content.getProductid());
                            ps.setLong(2, smsType.getTypeId());
                            ps.setString(3, content.getSender());
                            ps.setBytes(4, encryptedPhone.getBytes("UTF-8"));
                            ps.setString(5, content.getSendcontent());
                            ps.setString(6, content.getLoginname());
                            ps.setString(7, content.getRealname());
                            ps.setString(8, content.getProvidercode());
                            ps.setString(9, content.getCustomerLevel());
                            ps.setString(10, hashedPhone);
                            ps.setString(11, content.getRequestId());
                            ps.setString(12, content.getSource());
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                        return ps;
                    }
                }, keyHolder);
                if (result > 0) {
                    sms = new Sms();
                    sms.setContentId(String.valueOf(keyHolder.getKey().longValue()));
                    sms.setPhoneNumber(content.getPhone());
                    sms.setTypeCode(content.getSmstype());
                    sms.setSendContent(StringUtils.formatSmsContent(content.getSendcontent()));
                    sms.setProductId(content.getProductid());
                    sms.setSmsFailTimes(0);
                    sms.setTier(smsType.getTier());
                    sms.setCountryCode(content.getCountryCode());
                    sms.setReserveField(content.getSource());
                    sms.setExtraParam(content.getExtraParam());
                }
            } catch (Exception e) {
                LOGGER.error("插入短信异常", e);
            }
        } else {
            LOGGER.error("不存在的短信类型{}", content.getSmstype());
        }
        return sms;
    }

    @Override
    public Sms insertMultiSmsContent(List<SmsContent> content) throws Exception {
        Sms sms = null;
        String batchId = SmsUtility.shortUUID();
        SmsContent smsContent = content.get(0);
        SmsType smsType = querySmsType(smsContent.getSmstype());
        if (smsType != null) {
            try {
                String sql = "INSERT INTO T_SMS_CONTENT (CONTENT_ID,PRODUCT_ID,TYPE_ID,CREATED_BY,ENCRYPTED_PHONE," +
                        "   SEND_CONTENT,LOGINNAME,REAL_NAME,PROVIDER_CODE,CUSTOMER_LEVEL,HASHED_PHONE,BATCH_ID,REQUEST_ID,RESERVED1) VALUES (" +
                        "      T_SMS_CONTENT_SEQ.NEXTVAL,?,?,?,?,?,?,?,?,?,?,?,?,?)";
                List<Object[]> params = new ArrayList<>();
                for (int i = 0; i < content.size(); i++) {
                    String encryptedPhone = Crypt.encrypt(content.get(i).getPhone(), Integer.valueOf(propertiesConfig.getEncryptionKey()), false);
                    String hashedPhone = Convert.MD5Encode(content.get(i).getPhone());
                    params.add(new Object[]{content.get(i).getProductid(), smsType.getTypeId(), content.get(i).getSender(), encryptedPhone.getBytes("UTF-8"), content.get(i).getSendcontent(), content.get(i).getLoginname(),
                            content.get(i).getRealname(), content.get(i).getProvidercode(), content.get(i).getCustomerLevel(), hashedPhone, batchId, content.get(i).getRequestId(), content.get(i).getSource()
                    });
                }
                int[] res = jdbcTemplate.batchUpdate(sql, params);
                if (res.length == content.size()) {
                    sms = new Sms();
                    sms.setTypeCode(smsContent.getSmstype());
                    sms.setProductId(smsContent.getProductid());
                    sms.setSmsFailTimes(0);
                    sms.setBatchId(batchId);
                    sms.setTier(smsType.getTier());
                    sms.setCountryCode(smsContent.getCountryCode());
                    sms.setReserveField(smsContent.getSource());
                    sms.setExtraParam(smsContent.getExtraParam());
                    List<Sms> batchList = new ArrayList<>();
                    for (SmsContent temp : content) {
                        Sms smstmp = new Sms();
                        smstmp.setPhoneNumber(temp.getPhone());
                        smstmp.setSendContent(StringUtils.formatSmsContent(temp.getSendcontent()));
                        batchList.add(smstmp);
                    }
                    sms.setBatchList(batchList);

                }
            } catch (Exception e) {
                LOGGER.error("插入短信异常", e);
            }
        } else {
            LOGGER.error("不存在的短信类型{}", smsContent.getSmstype());
        }
        return sms;
    }

    @Override
    public Sms insertBulkSmsContent(SmsContent content) throws Exception {
        Sms sms = null;
        String[] phones = content.getPhone().split(",");
        boolean idMultiNames = false;
        String[] loginNames = new String[0];
        if (StringUtils.isNotEmpty(content.getLoginname())) {
            loginNames = content.getLoginname().split(",");
            idMultiNames = loginNames.length > 1;
        }
        String batchId = SmsUtility.shortUUID();
        SmsType smsType = querySmsType(content.getSmstype());
        if (smsType != null) {
            try {
                String sql = "INSERT INTO T_SMS_CONTENT (CONTENT_ID,PRODUCT_ID,TYPE_ID,CREATED_BY,ENCRYPTED_PHONE," +
                        "   SEND_CONTENT,LOGINNAME,REAL_NAME,PROVIDER_CODE,CUSTOMER_LEVEL,HASHED_PHONE,BATCH_ID,REQUEST_ID,RESERVED1) VALUES (" +
                        "      T_SMS_CONTENT_SEQ.NEXTVAL,?,?,?,?,?,?,?,?,?,?,?,?,?)";
                List<Object[]> params = new ArrayList<>();
                if (phones.length > 0) {
                    for (int i = 0; i < phones.length; i++) {
                        String encryptedPhone = Crypt.encrypt(phones[i], Integer.valueOf(propertiesConfig.getEncryptionKey()), false);
                        String hashedPhone = Convert.MD5Encode(phones[i]);
                        params.add(new Object[]{content.getProductid(), smsType.getTypeId(), content.getSender(), encryptedPhone.getBytes("UTF-8"), content.getSendcontent(), idMultiNames ? loginNames[i] : content.getLoginname(),
                                content.getRealname(), content.getProvidercode(), content.getCustomerLevel(), hashedPhone, batchId, content.getRequestId(), content.getSource()
                        });
                    }
                }
                int[] res = jdbcTemplate.batchUpdate(sql, params);
                if (res.length == phones.length) {
                    sms = new Sms();
                    sms.setPhoneNumber(content.getPhone());
                    sms.setTypeCode(content.getSmstype());
                    sms.setSendContent(StringUtils.formatSmsContent(content.getSendcontent()));
                    sms.setProductId(content.getProductid());
                    sms.setSmsFailTimes(0);
                    sms.setBatchId(batchId);
                    sms.setTier(smsType.getTier());
                    sms.setCountryCode(content.getCountryCode());
                    sms.setReserveField(content.getSource());
                    sms.setExtraParam(content.getExtraParam());
                }
            } catch (Exception e) {
                LOGGER.error("插入短信异常", e);
            }
        } else {
            LOGGER.error("不存在的短信类型{}", content.getSmstype());
        }
        return sms;
    }


    @Override
    public List<Product> queryProducts() {
        List<Product> list = new ArrayList<Product>();
        try {
            String sql = "SELECT * FROM t_product ORDER BY product_name";
            List<Object> params = new ArrayList<>();
            List<Map<String, Object>> fcuss = jdbcTemplate.queryForList(sql, params.toArray());
            for (Map<String, Object> rs : fcuss) {
                Product temp = setProduct(rs);
                list.add(temp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    private Product setProduct(Map<String, Object> rs) {
        Product temp = new Product();
        temp.setId(NumberUtils.toLong(rs.get("ID")));
        temp.setProductId(StringUtils.getString(rs.get("PRODUCT_ID")));
        temp.setProductName(StringUtils.getString(rs.get("PRODUCT_NAME")));
        temp.setProductDesc(StringUtils.getString(rs.get("PRODUCT_DESC")));
        temp.setProductPrior(NumberUtils.toInteger(rs.get("PRODUCT_PRIOR")));
        temp.setCreatedDate(DateUtil.stringToDate(rs.get("CREATED_DATE")));
        temp.setLastUpdate(DateUtil.stringToDate(rs.get("LAST_UPDATE")));
        temp.setLastUpdatedBy(StringUtils.getString(rs.get("LAST_UPDATE_BY")));

        return temp;
    }

    @Override
    public List<Configuration> queryAccounts() {
        List<Configuration> configurationList = new ArrayList<>();
        try {
            String sql = "SELECT a.*, b.SEND_GROUP_FLAG FROM T_SMS_ACCOUNT a LEFT JOIN T_SMS_PROVIDER b ON a.provider_code = b.provider_code WHERE a.flag = 0";
            List<Object> params = new ArrayList<>();
            List<Map<String, Object>> list = jdbcTemplate.queryForList(sql, params.toArray());

            for (Map<String, Object> rs : list) {
                Configuration temp = setConfiguration(rs);
                configurationList.add(temp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return configurationList;
    }

    @Override
    public List<Configuration> queryRecentlyModifiedAccounts() {
        List<Configuration> configurationList = new ArrayList<>();
        try {
            String sql = "SELECT a.*, b.SEND_GROUP_FLAG FROM T_SMS_ACCOUNT a LEFT JOIN T_SMS_PROVIDER b ON a.provider_code = b.provider_code WHERE a.LAST_UPDATE >= SYSDATE - (30/(24*60))";
            List<Object> params = new ArrayList<>();
            List<Map<String, Object>> list = jdbcTemplate.queryForList(sql, params.toArray());

            for (Map<String, Object> rs : list) {
                Configuration temp = setConfiguration(rs);
                configurationList.add(temp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return configurationList;
    }

    @Override
    public Configuration queryReplyConfigForProduct(String productId, String providerCode) {
        List<Configuration> configurationList = new ArrayList<>();
        try {
            String sql = "SELECT a.*, b.SEND_GROUP_FLAG FROM T_SMS_ACCOUNT a LEFT JOIN T_SMS_PROVIDER b ON a.provider_code = b.provider_code where a.account_type = 1 and a.provider_code = ? and a.flag = 0 and PRODUCT_ID = ?";
            List<Object> params = new ArrayList<>();
            params.add(providerCode);
            params.add(productId);
            List<Map<String, Object>> list = jdbcTemplate.queryForList(sql, params.toArray());

            for (Map<String, Object> rs : list) {
                Configuration temp = setConfiguration(rs);
                configurationList.add(temp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (!configurationList.isEmpty()) {
            return configurationList.get(0);
        }
        return null;
    }

    @Override
    public List<Sms> querySmsList(String productId, int tier, String customerLevel) {
        List<Sms> smsList = new ArrayList<>();
        try {
            String interval = propertiesConfig.getRestartTimeDelay();
            //OAM-1638

            StringBuilder sql = new StringBuilder();
            sql.append("Select CONTENT_ID, SEND_CONTENT, PHONE, ENCRYPTED_PHONE, SMS_FAIL_TIMES, CUSTOMER_LEVEL FROM T_SMS_CONTENT LEFT JOIN T_SMS_TYPE USING(TYPE_ID) WHERE ((SELECT SERVER FROM T_PRODUCT WHERE PRODUCT_ID = ?) = ?) AND PRODUCT_ID = ? " + "AND TIER = ? ");
            List<Object> params = new ArrayList<>();
            params.add(productId);
            params.add(serverId);
            params.add(productId);
            params.add(tier);
            if (customerLevel == null || StringUtils.isEmpty(customerLevel) || "null".equals(customerLevel)) {
                sql.append(" AND CUSTOMER_LEVEL IS NULL ");
            } else {
                sql.append(" AND CUSTOMER_LEVEL = ? ");
                params.add(customerLevel);
            }
            sql.append(" AND SMS_R_FLAG = '0' AND T_SMS_CONTENT.CREATED_DATE >= (SYSTIMESTAMP - INTERVAL '" + interval + "' HOUR) ORDER BY T_SMS_CONTENT.CREATED_DATE");


            List<Map<String, Object>> list = jdbcTemplate.queryForList(sql.toString(), params.toArray());
            for (Map<String, Object> rs : list) {
                Sms temp = new Sms();
                temp.setSmsFailTimes(NumberUtils.toInteger(rs.get("SMS_FAIL_TIMES")));
                temp.setContentId(StringUtils.getString(rs.get("CONTENT_ID")));
                temp.setProductId(productId);

                String phone;
                try {
                    if (rs.get("ENCRYPTED_PHONE") == null) {
                        phone = StringUtils.getString(rs.get("PHONE"));
                    } else {
                        byte[] encryptedData = (byte[]) rs.get("ENCRYPTED_PHONE");
                        phone = new String(encryptedData, "UTF-8");
                    }
                } catch (UnsupportedEncodingException e) {
                    phone = "Decryption Failed";
                }
                temp.setPhoneNumber(phone);

                temp.setSendContent(StringUtils.getString(rs.get("SEND_CONTENT")));
                smsList.add(temp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return smsList;
    }

    @Override
    public Configuration getAccount(String accountId) {
        Configuration configuration;

        String sql = "SELECT a.*, b.SEND_GROUP_FLAG FROM T_SMS_ACCOUNT a LEFT JOIN T_SMS_PROVIDER b ON a.provider_code = b.provider_code WHERE ACCOUNT_ID = ?";
        List<Object> params = new ArrayList<Object>();
        params.add(accountId);

        try {
            List<Map<String, Object>> list = jdbcTemplate.queryForList(sql, params.toArray());
            Map<String, Object> rs = list.get(0);
            configuration = setConfiguration(rs);
        } catch (Exception e) {
            e.printStackTrace();
            configuration = null;
        }

        return configuration;
    }


    @Override
    public int getFailed(String accountId) {
        int failed = 0;
        try {
            failed = jdbcTemplate.queryForObject("select COUNT(1) result from t_sms_monitor where TRUNC(monitor_date) = TRUNC(CURRENT_DATE) AND account_id = " + accountId, Integer.class);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return failed;
    }

    @Override
    public boolean batchUpdateSmsStatus(List<Sms> smsList) throws Exception {
        boolean isOK = true;
        if (smsList == null || smsList.size() == 0) {
            return true;
        }
        List<String> sqls = new ArrayList<String>();

        for (int i = 0; i < smsList.size(); i++) {
            sqls.add(assembleUpdateSql(smsList.get(i)));
        }
        LOGGER.info("batchUpdateSmsStatus sql:" + sqls);
        if (CollectionUtils.isNotEmpty(sqls)) {
            Connection conn = null;
            Statement stmt = null;
            try {
                conn = jdbcTemplate.getDataSource().getConnection();
                conn.setAutoCommit(false);
                stmt = conn.createStatement();
                for (int i = 0; i < sqls.size(); i++) {
                    String sql = sqls.get(i);
                    stmt.addBatch(sql);
                }
                stmt.executeBatch();
                conn.commit();
            } catch (Exception e) {
                LOGGER.info("batchExecute sql=" + sqls.get(0) + "....");
                isOK = false;
                if (conn != null) {
                    conn.rollback();
                }

            } finally {
                if (conn != null) {
                    conn.setAutoCommit(true);
                }
                if (stmt != null) {
                    stmt.close();
                    stmt = null;
                }
                if (conn != null) {
                    conn.close();
                    conn = null;
                }
            }
        }
        return isOK;
    }

    @Override
    public boolean updateSmsStatus(Sms sms) throws Exception {
        String sql = assembleUpdateSql(sms);
        LOGGER.info("updateSmsStatus sql:" + sql);
        return jdbcTemplate.update(sql) > 0;
    }

    private String assembleUpdateSql(Sms sms) {
        StringBuilder sql = new StringBuilder("update t_sms_content  set ");
        sql.append(" LAST_UPDATE = to_date('").
                append(DateUtil.toString(new Date(), new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"))).
                append("','yyyy-mm-dd hh24:mi:ss') ");

        if (sms.getSmsResponseFlag() != null) {
            sql.append(", sms_r_flag = ").append(sms.getSmsResponseFlag());
        }
        if (sms.getSmsFailTimes() != null) {
            sql.append(", sms_fail_times = ").append(sms.getSmsFailTimes());
        }
        if (sms.getSmsSendDate() != null) {
            sql.append(", sms_send_date = to_date('").
                    append(DateUtil.toString(sms.getSmsSendDate(), new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"))).
                    append("','yyyy-mm-dd hh24:mi:ss') ");
        }
        if (sms.getSmsRemarks() != null) {
            sql.append(", sms_remarks= '").append(sms.getSmsRemarks()).append("'");
        }

        if (sms.getLast_send_by() != null) {
            sql.append(", LAST_SEND_BY= '").append(sms.getLast_send_by()).append("'");
        }
        if (StringUtils.isNotEmpty(sms.getReserveField())) {
            sql.append(", RESERVED1= '").append(sms.getReserveField()).append("'");
        }
        if (StringUtils.isNotEmpty(sms.getProviderCode())) {
            sql.append(", PROVIDER_CODE= '").append(sms.getProviderCode()).append("'");
        }
        if (StringUtils.isNotEmpty(sms.getPort())) {
            sql.append(", PORT= '").append(sms.getPort()).append("'");
        }
        if (sms.isMultipleSend()) {
            sql.append(" where batch_id='").append(sms.getBatchId()).append("'");
        } else {
            sql.append(" where content_id=").append(sms.getContentId());
        }
        if (StringUtils.isNotEmpty(sms.getPhoneNumberMd5())) {
            sql.append(" and HASHED_PHONE= '").append(sms.getPhoneNumberMd5()).append("'");
        }
        return sql.toString();
    }

    @Override
    public boolean updateAccountStats(String accountId, boolean isSent)
            throws Exception {

        StringBuilder sql = new StringBuilder("update t_sms_account set ")
                .append(isSent ? "success = success+1" : "failed = failed+1")
                .append(", success_rate = ((")
                .append(isSent ? "(success+1)" : "success")
                .append("/(success+failed+1))*100)")
                .append(", last_update = to_date('")
                .append(DateUtil.toString(new Date(), new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")))
                .append("','yyyy-mm-dd hh24:mi:ss') where account_id = '")
                .append(accountId)
                .append("'");

        return jdbcTemplate.update(sql.toString()) > 0;
    }

    @Override
    public boolean insertMonitorRecord(Date monitorDate, String status, String contentId, Long accountId) throws Exception {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        StringBuilder sql = new StringBuilder("INSERT INTO T_SMS_MONITOR(MONITORID,MONITOR_DATE,STATUS,CONTENT_ID,ACCOUNT_ID) ");
        sql.append("VALUES(T_SMS_MONITOR_SEQ.NEXTVAL,").append("TO_DATE('").append(sdf.format(monitorDate)).append("','yyyy-mm-dd HH24:MI:SS'").append("),");
        if (status.equals("SUCCESS")) {
            sql.append("2,");
        } else {
            sql.append("-1,");
        }
        sql.append(contentId).append(",").append(accountId).append(") ");
        int result = jdbcTemplate.update(sql.toString());
        LOGGER.info("batchUpdateMonitorId query[" + sql.toString() + "] result[" + result + "]");

        return result > 0;
    }

    @Override
    public ServerInfo getServerInfoByProductId(String productId) {
        List<ServerInfo> list = new ArrayList<ServerInfo>();
        String sql = "SELECT * FROM T_SERVERS WHERE SERVER_ID = (SELECT SERVER FROM T_PRODUCT WHERE PRODUCT_ID = ?)";
        List<Object> params = new ArrayList<Object>();
        params.add(productId);
        List<Map<String, Object>> object;
        try {
            object = this.jdbcTemplate.queryForList(sql, params.toArray());
            for (Map<String, Object> rs : object) {
                ServerInfo info = new ServerInfo();
                info.setFlag(NumberUtils.toInteger(rs.get("FLAG")));
                info.setServerId(NumberUtils.toInteger(rs.get("SERVER_ID")));
                info.setServerUrl(StringUtils.getString(rs.get("SERVER_URL")));
                list.add(info);
            }

            return CollectionUtils.isNotEmpty(list) ? list.get(0) : null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<String> getCustomerLevels(String productId) {
        List<String> list = new ArrayList<String>();
        String sql = "SELECT DISTINCT(CUSTOMER_LEVEL) FROM T_SMS_ACCOUNT WHERE PRODUCT_ID=? ORDER BY CUSTOMER_LEVEL ASC NULLS FIRST";
        List<Map<String, Object>> object;
        try {
            List<Object> params = new ArrayList<Object>();
            params.add(productId);
            object = jdbcTemplate.queryForList(sql, params.toArray());
            for (Map<String, Object> rs : object) {
                String customerLevel = StringUtils.getString(rs.get("CUSTOMER_LEVEL"));
                if (StringUtils.isEmpty(customerLevel)) {
                    list.add("null");
                } else {
                    list.add(customerLevel);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<Configuration> getActiveAccounts(String productId, int tier, String customerLevel,
                                                 boolean isInternational, String providerCode,
                                                 Integer sendMethod, Integer groupFlag, Integer status,
                                                 String countryCode) {
        List<Configuration> accounts = new ArrayList<Configuration>();
        try {
            StringBuilder sql = new StringBuilder("SELECT a.*, b.SEND_GROUP_FLAG, b.PROVIDER_NAME FROM T_SMS_ACCOUNT a LEFT JOIN T_SMS_PROVIDER b ON a.provider_code = b.provider_code WHERE a.account_type = 0  AND a.PRODUCT_ID = ? and a.TIER = ? ");
            List<Object> params = new ArrayList<>();
            params.add(productId);
            params.add(tier);
            if (StringUtils.isNotEmpty(customerLevel) && (!"null".equals(customerLevel))) {
                sql.append(" AND a.CUSTOMER_LEVEL = ? ");
                params.add(customerLevel);
            } else {
                sql.append(" AND a.CUSTOMER_LEVEL IS NULL ");
            }

            if (null != status) {
                sql.append(" and a.FLAG = ? ");
                params.add(status);
            }

            if (isInternational) {
                sql.append(" AND a.INTERNATIONAL = 1");
            } else {
                sql.append(" AND a.INTERNATIONAL != 1 ");
            }

            if (StringUtils.isNotEmpty(providerCode) && !"null".equals(providerCode)) {
                if (providerCode.indexOf(",") >= 0) {
                    String[] providers = providerCode.split(",");
                    sql.append(" AND a.PROVIDER_CODE in ( ");
                    for (String provider : providers) {
                        sql.append("?,");
                        params.add(provider);
                    }
                    sql.append(")");
                } else {
                    sql.append(" AND a.PROVIDER_CODE = ? ");
                    params.add(providerCode);
                }
            }
            if (null != sendMethod) {
                sql.append(" AND a.SMSMETHOD = ? ");
                params.add(sendMethod);
            }
            if (null != groupFlag) {
                sql.append(" AND b.send_group_flag=? ");
                params.add(groupFlag);
            }

            //如果是国际的话，先查询根据国家区号是否能查询到具体的短信账号
            if (isInternational) {
                String tmp = sql.toString();
                List<Object> paramsTmp = ObjectUtils.clone(params);
                tmp += " AND ','||a.country_code||',' like ?";
                paramsTmp.add("%," + countryCode + ",%");
                String count = "select count(1) from (" + tmp + ")";
                Integer retCount = jdbcTemplate.queryForObject(count.replace(",)", ")"), paramsTmp.toArray(), Integer.class);
                if (retCount > 0) {
                    sql.append(" AND ','||a.country_code||',' like ? ");
                    params.add("%," + countryCode + ",%");
                }else{
                    sql.append(" AND a.country_code is null ");
                }
            }

            sql.append(" order by a.priority ASC");

            List<Map<String, Object>> list = jdbcTemplate.queryForList(sql.toString().replace(",)", ")"), params.toArray());
            LOGGER.info("getActiveAccounts query[" + sql.toString().replace(",)", ")") + "] result size[" + list.size() + "],Params:{}", JSON.toJSONString(params));
            for (Map<String, Object> rs : list) {
                Configuration temp = setConfiguration(rs);
                accounts.add(temp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return accounts;
    }

    private Configuration setConfiguration(Map<String, Object> rs) {
        Configuration temp = new Configuration();
        temp.setSendGroupFlag(NumberUtils.toInteger(rs.get("SEND_GROUP_FLAG")));
        temp.setAccountId(StringUtils.getString(rs.get("ACCOUNT_ID")));
        temp.setMainUserId(StringUtils.getString(rs.get("MAIN_USERID")));
        temp.setVcpPort(StringUtils.getString(rs.get("VCP_PORT")));
        temp.setVcpPwd(StringUtils.getString(rs.get("VCP_PWD")));
        temp.setVcpServer(StringUtils.getString(rs.get("VCP_SERVER")));
        temp.setVcpUserId(StringUtils.getString(rs.get("VCP_USERID")));
        temp.setProviderCode(StringUtils.getString(rs.get("PROVIDER_CODE")));
        temp.setFlag(NumberUtils.toInteger(rs.get("FLAG")));
        temp.setSuccess(NumberUtils.toInteger(rs.get("SUCCESS")));
        temp.setFailed(NumberUtils.toInteger(rs.get("FAILED")));
        temp.setTier(NumberUtils.toInteger(rs.get("TIER")));
        temp.setSuccessRate(NumberUtils.toDouble(rs.get("SUCCESS_RATE")));
        temp.setLastUpdatedBy(StringUtils.getString(rs.get("LAST_UPDATED_BY")));
        temp.setRemarks(StringUtils.getString(rs.get("REMARKS")));
        temp.setAccountRemarks(StringUtils.getString(rs.get("ACCOUNT_REMARKS")));
        temp.setProductId(StringUtils.getString(rs.get("PRODUCT_ID")));
        temp.setCreatedDate(DateUtil.objectToTimestamp(rs.get("CREATED_DATE")));
        temp.setLastUpdate(DateUtil.objectToTimestamp(rs.get("LAST_UPDATE")));
        temp.setCustomerLevel(StringUtils.getString(rs.get("CUSTOMER_LEVEL") == null ? "null" : rs.get("CUSTOMER_LEVEL")));
        temp.setInternational(NumberUtils.toInteger(rs.get("INTERNATIONAL")));
        temp.setProviderName(StringUtils.getString(rs.get("PROVIDER_NAME")));
        temp.setAccountType(StringUtils.getString(rs.get("ACCOUNT_TYPE")));
        temp.setSmsSignature(StringUtils.getString(rs.get("SMS_SIGNATURE")));
        temp.setCountyCode(StringUtils.getString(rs.get("country_code")));
        temp.setSignFlag(rs.get("sign_flag")==null?null:((BigDecimal) rs.get("sign_flag")).intValue());
        return temp;
    }

    @Override
    public boolean hasAccount(String productId, int tier, String customerLevel) {
        try {
            StringBuilder sql = new StringBuilder("SELECT COUNT(1) COUNT FROM T_SMS_ACCOUNT a LEFT JOIN T_SMS_PROVIDER b ON a.provider_code = b.provider_code WHERE a.FLAG = 0 AND a.PRODUCT_ID = '" + productId + "' and a.TIER = '" + tier);
            if (StringUtils.isNotEmpty(customerLevel)) {
                sql.append("' AND a.CUSTOMER_LEVEL ='").append(customerLevel).append("'");
            } else {
                sql.append("' AND a.CUSTOMER_LEVEL IS NULL ");
            }
            long count = (jdbcTemplate.queryForObject(sql.toString(), Long.class)).longValue();
            return count > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public String querySmsTypeTier(String smsType) {
        String sql = "SELECT TIER FROM T_SMS_TYPE where type_code ='" + smsType + "'";
        String result = "";
        try {
            result = jdbcTemplate.queryForObject(sql, String.class);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return result;
    }

    @Override
    public List<String> queryAllApproveSmsType() {
        String sql = "SELECT TYPE_code FROM T_SMS_TYPE where is_approve=1";
        try {
            List<String> list = jdbcTemplate.queryForList(sql, String.class);
            return list;
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return Lists.newArrayList();
    }

    @Override
    public int countSmsContent(String productId, String phoneHash, String startDate, String endDate, String typeCode, String source, String sender) throws Exception {
        StringBuilder sql = new StringBuilder("SELECT COUNT(1) COUNT from t_sms_content where product_id ='" + productId + "' and hashed_phone = '" + phoneHash + "' and sms_r_flag = 2");
        if (StringUtils.isNotEmpty(typeCode)) {
            sql.append(" and type_id = (select type_id from t_sms_type where type_code = '" + typeCode + "' ) ");
        }
        if (StringUtils.isNotEmpty(startDate)) {
            sql.append(" and created_date >= to_date('" + startDate + "', 'yyyy-mm-dd hh24:mi:ss') ");
        }
        if (StringUtils.isNotEmpty(endDate)) {
            sql.append(" and created_date <= to_date('" + endDate + "', 'yyyy-mm-dd hh24:mi:ss') ");
        }
        if (StringUtils.isNotEmpty(source)) {
            sql.append(" and reserved1 ='").append(source).append("'");
        }
        if (StringUtils.isNotEmpty(sender)) {
            sql.append(" and CREATED_BY ='").append(sender).append("'");
        }
        LOGGER.info(sql + "###");
        return (jdbcTemplate.queryForObject(sql.toString(), Integer.class)).intValue();
    }

    @Override
    public List<SmsConstant> getSmsConstantByKey(String productId, String key) {
        StringBuilder sql = new StringBuilder("select * from t_sms_constant where flag=1 ");
        List<String> params = new ArrayList<>(2);
        if (StringUtils.isNotEmpty(productId)) {
            sql.append(" and product_id = ?");
            params.add(productId);
        }
        if (StringUtils.isNotEmpty(key)) {
            sql.append(" and constant_key = ?");
            params.add(key);
        }
        List<SmsConstant> result = new ArrayList<>();
        try {
            List<Map<String, Object>> list = jdbcTemplate.queryForList(sql.toString(), params.toArray());
            if (CollectionUtils.isNotEmpty(list)) {
                for (Map<String, Object> rs : list) {
                    SmsConstant smsConstant = new SmsConstant();
                    smsConstant.setId(NumberUtils.toLong(rs.get("ID")));
                    smsConstant.setProductId(StringUtils.getString(rs.get("PRODUCT_ID")));
                    smsConstant.setConstantKey(StringUtils.getString(rs.get("CONSTANT_KEY")));
                    smsConstant.setConstantName(StringUtils.getString(rs.get("CONSTANT_NAME")));
                    smsConstant.setConstantValue(StringUtils.getString(rs.get("CONSTANT_VALUE")));
                    smsConstant.setFlag(StringUtils.getString(rs.get("FLAG")));

                    result.add(smsConstant);
                }
            }
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }

        return result;
    }

    @Override
    public void updateSmsStatusClose() {
        jdbcTemplate.update("update t_sms_content set SMS_R_FLAG=-1" +
                ",sms_remarks='系统重启,更新待发送状态为失败',sms_fail_times=1 " +
                "where sms_r_flag=0 and created_date<sysdate-5/1440");
    }

    @Override
    public String getAccountByContentId(String contentId) {
        try{
            String ids = jdbcTemplate.queryForObject("select account_id||'_'||MONITORID  from t_sms_monitor " +
                    "where TRUNC(monitor_date) = TRUNC(CURRENT_DATE) and  rownum=1  and status=2 " +
                    "AND CONTENT_ID = " + contentId, String.class);
            return ids;
        }catch (Exception e){
            LOGGER.error(e.getMessage(), e);
        }
        return "";
    }

    @Override
    public void updateMonitorRecord(String mId, Integer status) {
        jdbcTemplate.update("update t_sms_monitor set status=" + status + " where MONITORID=" + mId);
    }
}

