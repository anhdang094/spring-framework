package com.intech.sms.dao.impl;

import com.intech.sms.dao.SmsTemplateDao;
import com.intech.sms.model.Account;
import com.ws.SmsChildTypeRequest;
import com.ws.SmsType;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @description:
 * @author: Condi
 * @create: 2019-03-20 11:59
 **/
@Repository
public class SmsTemplateDaoImpl implements SmsTemplateDao {
    @Resource(name="namedParameterJdbcTemplate")
    private NamedParameterJdbcTemplate jdbcN;

    @Override
    public List<SmsType> querySmsTemplatesByType(SmsChildTypeRequest request,List<Long> ids) {
        Map<String, Object> args  = new HashMap<>();
        args.put("ids",ids);
        args.put("productId",request.getProductId());
        String sql = "select t.type_id ,t.content from t_smscontent_template t where t.product_id=:productId and t.type_id in (:ids)";
        List<SmsType> data = jdbcN.query(sql, args, new RowMapper<SmsType>() {
            @Override
            public SmsType mapRow(ResultSet rs, int index) throws SQLException {
                SmsType emp = new SmsType();
                emp.setTypeId(rs.getLong("type_id"));
                emp.setTemplate(rs.getString("content"));
                return emp;
            }
        });
        return data;
    }
}


    
