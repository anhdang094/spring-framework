package com.intech.sms.dao.impl;

import com.intech.sms.dao.SmsTypeDao;
import com.intech.sms.util.NumberUtils;
import com.ws.SmsType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @description:
 * @author: Condi
 * @create: 2019-03-20 11:11
 **/
@Repository
public class SmsTypeDaoImpl implements SmsTypeDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;
    private Logger LOGGER = LoggerFactory.getLogger(SmsTypeDao.class);

    @Override
    public SmsType getSmsTypeByCode(String typeCode) {
        String sql = "SELECT TYPE_ID,TYPE_NAME,TYPE_CODE,TIER,disable_flag FROM T_SMS_TYPE where type_code =?";
        SmsType result = null;
        try {
            result = jdbcTemplate.queryForObject(sql, new RowMapper<SmsType>() {
                @Override
                public SmsType mapRow(ResultSet resultSet, int i) throws SQLException {
                    return new SmsType(resultSet.getLong("TYPE_ID"), resultSet.getString("TYPE_NAME"),
                            resultSet.getString("TIER"), resultSet.getString("TYPE_CODE"),
                            resultSet.getInt("disable_flag"));
                }
            }, typeCode);
        } catch (Exception e) {
            LOGGER.error("查询短信类型异常", e);
        }
        return result;
    }


    @Override
    public List<SmsType> queryChildTypes(Long typeId) {
        List<SmsType> list = new ArrayList<>();
        try {
            String sql = "SELECT TYPE_ID,TYPE_NAME,TYPE_CODE,TIER,disable_flag FROM T_SMS_TYPE where PID =?";
            List<Object> params = new ArrayList<>();
            params.add(typeId);
            List<Map<String, Object>> fcuss = jdbcTemplate.queryForList(sql, params.toArray());
            for (Map<String, Object> rs : fcuss) {
                list.add(new SmsType(NumberUtils.toLong(rs.get("TYPE_ID")),
                        String.valueOf(rs.get("TYPE_NAME")),
                        String.valueOf(rs.get("TIER")),
                        String.valueOf(rs.get("TYPE_CODE")),
                        rs.get("disable_flag") == null ? 0 : Integer.parseInt(rs.get("disable_flag").toString())));
            }
        } catch (Exception e) {
            LOGGER.error("查询短信子类型异常", e);
        }
        return list;
    }
}


    
