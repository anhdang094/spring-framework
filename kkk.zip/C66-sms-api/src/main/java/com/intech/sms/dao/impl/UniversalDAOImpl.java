package com.intech.sms.dao.impl;

import com.intech.sms.dao.UniversalDAO;
import com.intech.sms.exception.DAOException;
import com.intech.sms.model.MsgMqSendRecord;
import com.intech.sms.model.Reply;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

/**
 * @author kaiser.dapar
 * @version 1.0, Feb 27, 2015
 */
@SuppressWarnings("unchecked")
@Repository
public class UniversalDAOImpl implements UniversalDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public <T> List<T> list(String sql, ResultSetExtractor resultSetExtractor, Object... parameters) throws DAOException {
		try {
			List<T> list = (List<T>) jdbcTemplate.query(sql, parameters, resultSetExtractor);
	    	LOGGER.info(String.format("SQL:[%s] PARAMS:%s RESULT:[%s]", sql, Arrays.asList(parameters), list.size()));
			return list;
		} catch (Exception e) {
			throw new DAOException(sql, parameters, e);
		}
	}
	
	@Override
	public <T> T object(String sql, RowMapper rowMapper, Object... parameters) throws DAOException {
		try {
			T object = (T) jdbcTemplate.queryForObject(sql, parameters, rowMapper);
	    	LOGGER.info(String.format("SQL:[%s] PARAMS:%s RESULT:[%s]", sql, Arrays.asList(parameters), object));
			return object;
		} catch (Exception e) {
			throw new DAOException(sql, parameters, e);
		}
	}
	
	@Override
	public int update(String sql, Object... parameters) throws DAOException {
		try {
			int count = jdbcTemplate.update(sql, parameters);
	    	LOGGER.info(String.format("SQL:[%s] PARAMS:%s RESULT:[%s]", sql, Arrays.asList(parameters), count));
			return count;
		} catch (Exception e) {
			throw new DAOException(sql, parameters, e);
		}
	}

	@Override
	public Long insert(String sql, String generatedColumn, Object... parameters) throws DAOException {
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = jdbcTemplate.getDataSource().getConnection().prepareStatement(sql, new String[] { generatedColumn });
			for (int i = 0; i < parameters.length; i++) {
				preparedStatement.setObject(i + 1, parameters[i]);
			}
			preparedStatement.executeUpdate();
			ResultSet resultSet = preparedStatement.getGeneratedKeys();
			Long insertedId = (resultSet != null && resultSet.next()) ? resultSet.getLong(1) : null;
	    	LOGGER.info(String.format("SQL:[%s] PARAMS:%s RESULT:[%s]", sql, Arrays.asList(parameters), insertedId));
			return insertedId;
		} catch (Exception e) {
			throw new DAOException(sql, parameters, e);
		}finally {
			if(preparedStatement != null){
				try {
					preparedStatement.close();
				}catch (Exception e){
					LOGGER.error("入库失败",e);
				}

			}

		}
	}

	@Override
	public int batchUpdateMsgMqSendRecord(String sql, List<MsgMqSendRecord> failedList) {
		  jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				MsgMqSendRecord msg = failedList.get(i);
				ps.setLong(1,msg.getId());
			}
			@Override
			public int getBatchSize() {
				return failedList.size();
			}
		});
		  return failedList.size();
	}

	@Override
	public int batchUpdateReplies(String sql, List<Reply> replies) {
		jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				Reply reply = replies.get(i);
				ps.setString(1,reply.getProductId());
				ps.setString(2, reply.getPhone());
				ps.setString(3, reply.getContent());
				ps.setTimestamp(4, reply.getReceiveDate());
				ps.setString(5, reply.getProviderCode());
				ps.setString(6,  reply.getAccount());
			}

			@Override
			public int getBatchSize() {
				return replies.size();
			}
		});
		return replies.size();
	}
}