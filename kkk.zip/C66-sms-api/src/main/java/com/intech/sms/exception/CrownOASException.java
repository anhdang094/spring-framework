package com.intech.sms.exception;

/**
 * Generic System Error.
 * 
 * @author Marc Heruela
 *
 */
public class CrownOASException extends RuntimeException {

	private static final long serialVersionUID = 6230710265891436813L;
	private String error;
	
	public CrownOASException(String error) {
		this.error = error;
	}

	public String getError() {
		return this.error;
	}
	
	@Override
	public String getMessage() {
		return this.error;
	}
}
