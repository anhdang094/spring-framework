package com.intech.sms.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;


/**
 * @author kaiser.dapar
 * @version 1.0, Mar 5, 2015
 */
public class DAOException extends Exception {
	
	// Constants ----------------------------------------------------------------------------------
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = LoggerFactory.getLogger(DAOException.class);
			
    // Constructors -------------------------------------------------------------------------------
	public DAOException(String message) {
    	this("", null, message);
    }
	
	public DAOException(Throwable cause) {
    	this("", null, "", cause);
    }
	
	public DAOException(String sql, String message) {
    	this(sql, null, message);
    }
    
    public DAOException(String sql, Throwable cause) {
    	this(sql, null, "", cause);
    }

    public DAOException(String sql, String message, Throwable cause) {
    	this(sql, null, message, cause);
    }
    
    public DAOException(String sql, Object[] parameters, String message) {
        super(message);
        logError(sql, parameters);
    }

    public DAOException(String sql, Object[] parameters, Throwable cause) {
        super(cause);
        logError(sql, parameters);
    }

    public DAOException(String sql, Object[] parameters, String message, Throwable cause) {
        super(message, cause);
        logError(sql, parameters);
    }
    
    private void logError(String sql, Object[] parameters) {
    	LOGGER.error(String.format("SQL:[%s] PARAMS:%s", sql, Arrays.asList(parameters)), this);
    }
    
}