package com.intech.sms.exception;



/**
 * @author Herman.T
 */
public class SmsMessageException extends Exception {
    private static final long serialVersionUID = -2365099977391406364L;
    public SmsMessageException(String message) {
        super(message);
    }
}
