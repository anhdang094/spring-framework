package com.intech.sms.facade;

import com.intech.sms.exception.CrownOASException;
import com.intech.sms.exception.DAOException;
import com.intech.sms.model.MsgMqSendRecord;

import java.util.List;


/**
 * MQ消息发送记录表业务层接口类
 *
 * @author wade
 * @date 2018-08-29 09:52:47.
 */
public interface MsgMqFacade {

    /**
     * MQ消息发送记录表查询符合条件的数量
     *
     * @param query 查询条件
     * @return Integer 符合条件的数量
     * @throws CrownOASException
     */
    Integer countMsgMqByCondition(MsgMqSendRecord query) throws CrownOASException;

    /**
     * MQ消息发送记录表查询符合条件的信息分页
     *
     * @param query 查询条件
     * @return List<WSMsgMqSendRecord> MQ消息发送记录表列表
     * @throws CrownOASException
     */
    List<MsgMqSendRecord> queryPageMsgMqByCondition(MsgMqSendRecord query) throws CrownOASException;


    /**
     * MQ消息发送记录表创建信息
     *
     * @param bean 需要创建的信息
     * @return WSMsgMqSendRecord 创建后结果
     * @throws CrownOASException
     */
    MsgMqSendRecord createMsgMq(MsgMqSendRecord bean) throws CrownOASException, DAOException;

    /**
     * MQ消息发送记录表修改信息
     *
     * @param bean 需要修改的信息
     * @return WSMsgMqSendRecord 修改后结果
     * @throws CrownOASException
     */
    MsgMqSendRecord modifyMsgMq(MsgMqSendRecord bean) throws CrownOASException;


    /**
    * 查询出一批发送记录，创建时间升序排序
    * @param: [count]
    * @return: java.util.List<com.intech.sms.model.MsgMqSendRecord>
    * @throws:
    * @Author: "Condi"
    * @Date: 2018/11/23
    */
    List<MsgMqSendRecord> queryMsgMqSendRecord(MsgMqSendRecord query);

    /**
    * 批量删除发送记录
    * @param: [successList]
    * @return: void
    * @throws:
    * @Author: "Condi"
    * @Date: 2018/11/23
    */
    int batchDeleteMsgMqSendRecord(List<MsgMqSendRecord> successList);

    /**
     * 批量更新一批记录
     * @param failedList
     */
    int batchUpdateMsgMqSendRecord(List<MsgMqSendRecord> failedList);
}
