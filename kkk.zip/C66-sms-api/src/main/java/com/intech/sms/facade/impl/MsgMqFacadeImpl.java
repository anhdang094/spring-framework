package com.intech.sms.facade.impl;


import com.google.common.collect.Lists;
import com.intech.sms.dao.UniversalDAO;
import com.intech.sms.exception.CrownOASException;
import com.intech.sms.exception.DAOException;
import com.intech.sms.facade.MsgMqFacade;
import com.intech.sms.model.MsgMqSendRecord;
import com.intech.sms.model.Product;
import com.intech.sms.model.Reply;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * MQ消息发送记录表业务层实现类
 *
 * @author wade
 * @date 2018-08-29 09:52:47.
 */
@Service
public class MsgMqFacadeImpl implements MsgMqFacade {

    @Autowired
    private UniversalDAO universalDAO;

    /**
     * 查询符合条件的数量
     *
     * @param query 查询条件
     * @return Integer 符合条件的数量
     * @throws CrownOASException
     */
    @Override
    public Integer countMsgMqByCondition(MsgMqSendRecord query) throws CrownOASException {
        return null;
    }

    /**
     * 查询符合条件的信息分页
     *
     * @param query 查询条件
     * @return List<MsgMqSendRecord> MQ消息发送记录表列表
     * @throws CrownOASException
     */
    @Override
    public List<MsgMqSendRecord> queryPageMsgMqByCondition(MsgMqSendRecord query) throws CrownOASException {
        return null;
    }


    /**
     * 创建信息
     *
     * @param bean 需要创建的信息
     * @return WSMsgMqSendRecord 创建后结果
     * @throws CrownOASException
     */
    @Override
    public MsgMqSendRecord createMsgMq(MsgMqSendRecord bean) throws CrownOASException, DAOException {

        String sql = "insert into T_SMS_MQ_SEND_RECORD values(T_SMS_MQ_SEND_RECORD_SEQ.Nextval, ?, ?, ?, ?, ?, ?, ?, ?, ?, sysdate, sysdate)";
        Long id = universalDAO.insert(sql, "id", bean.getProductId(),
                bean.getMsgType(), bean.getMsgData(), bean.getJmsQueueName(),
                bean.getRabbitExchangeName(), bean.getRabbitRoutingKey(),
                bean.getFlag(), bean.getReSendTimes(), bean.getRemarks());

        bean.setId(id);
        return bean;
    }

    /**
     * 修改信息
     *
     * @param bean 需要修改的信息
     * @return WSMsgMqSendRecord 修改后结果
     * @throws CrownOASException
     */
    @Override
    public MsgMqSendRecord modifyMsgMq(MsgMqSendRecord bean) throws CrownOASException {
        return null;
    }


    @Override
    public List<MsgMqSendRecord> queryMsgMqSendRecord(MsgMqSendRecord query) {
        try {
            String sql = "SELECT * FROM (SELECT ROWNUM AS rowno,r.* FROM(SELECT * FROM t_sms_mq_send_record t ORDER BY t.created_date ) r where ROWNUM <= ? ) tt WHERE tt.rowno >0";
            return universalDAO.list(sql,new ResultSetExtractor<Object>() {
                @Override
                public Object extractData(ResultSet resultSet) throws SQLException, DataAccessException {
                    List<MsgMqSendRecord> list= new ArrayList<>();
                    while (resultSet.next()) {
                        MsgMqSendRecord product = new MsgMqSendRecord();
                        product.setId(resultSet.getLong("ID"));
                        product.setProductId(resultSet.getString("PRODUCT_ID"));
                        product.setMsgType(resultSet.getInt("MSG_TYPE"));
                        product.setMsgData(resultSet.getString("MSG_DATA"));
                        product.setJmsQueueName(resultSet.getString("JMS_QUEUE_NAME"));
                        product.setRabbitExchangeName(resultSet.getString("RABBIT_EXCHANGE_NAME"));
                        product.setRabbitRoutingKey(resultSet.getString("RABBIT_ROUTING_KEY"));
                        product.setFlag(resultSet.getInt("FLAG"));
                        product.setReSendTimes(resultSet.getInt("RESEND_TIME"));
                        list.add(product);
                    }
                    return list;
                }
            },query.getCount());
        }catch (Exception e){
           throw new RuntimeException(e);
        }
    }

    /**
     * 批量删除发送记录
     * @param: [successList]
     * @return: void
     * @throws:
     * @Author: "Condi"
     * @Date: 2018/11/23
     */
    @Override
    public int batchDeleteMsgMqSendRecord(List<MsgMqSendRecord> successList) {

        String sql = "delete from t_sms_mq_send_record t where t.id=?";
        universalDAO.batchUpdateMsgMqSendRecord(sql,successList);
        return successList.size();

    }
    /**
     * 批量更新一批记录
     * @param failedList
     */
    @Override
    public int batchUpdateMsgMqSendRecord(List<MsgMqSendRecord> failedList) {
        String sql = "update t_sms_mq_send_record t set t.FLAG=1,RESEND_TIME=RESEND_TIME+1,LAST_UPT_DATE=sysdate where t.id=?";
        universalDAO.batchUpdateMsgMqSendRecord(sql,failedList);
        return failedList.size();
    }
}
