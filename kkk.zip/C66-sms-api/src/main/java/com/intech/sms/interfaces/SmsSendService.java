package com.intech.sms.interfaces;

import com.intech.sms.model.Account;
import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.HttpClientUtil;

/***************************************************************************
 * System Name: SMS System Module Name: Author: gary Finish Date: 　Aug 6, 2012
 * Version: 1.0 Funtion Description: 　　 　Modify History:
 *
 * <pre>
 * ###########################################################################
 * 　 Version　 　 Modify Date　　   Modify By        Description  
 * ###########################################################################
 *
 * </pre>
 ****************************************************************************/
public interface SmsSendService {
    // 发送服务接口
    int send(Sms sms);

    boolean hasChanges(Configuration config);


    void setProviderCode(String providerCode);

    void setHttpClientUtil(HttpClientUtil httpClientUtil);
}
