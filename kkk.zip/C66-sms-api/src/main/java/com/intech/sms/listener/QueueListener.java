package com.intech.sms.listener;
import com.intech.sms.dao.SMSOperateDao;
import com.intech.sms.model.Account;
import com.intech.sms.model.Product;
import com.intech.sms.service.AccountService;
import com.intech.sms.service.ProductService;
import com.intech.sms.work.SmsConsumer;
import com.intech.sms.work.SmsConsumerHolder;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.DependsOn;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Component
@DependsOn("applicationContextSingleton")
public class QueueListener{

    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    private static ExecutorService exec = Executors.newCachedThreadPool();

    @Autowired
    private ProductService productService;

    @Autowired
    private AccountService accountService;

    @Autowired
    private SMSOperateDao smsOperateDao;

    @PostConstruct
    private void init(){
        logger.info("QueueListener INITIALIZING...");
        try {

            //缓存所有产品
            Product.setProducts(productService.retrieveAll());
            // CREATE CONSUMERS
            //查询短信账户表创建对应的线程
            List<Account> accounts = accountService.retrieveAll();

            for (Account account : accounts) {
                SmsConsumer consumer = new SmsConsumer(account.getProductId(), Integer.valueOf(account.getTier()), StringUtils.isEmpty(account.getCustomerLevel())?"null":account.getCustomerLevel());
                SmsConsumerHolder.addConsumer(consumer);
                exec.execute(consumer);
            }
            logger.info("QueueListener INITIALIZATION: SUCCESSFUL");
        } catch (Exception e) {
            e.printStackTrace();
            logger.info(e.getMessage());
            logger.info("QueueListener INITIALIZATION: FAILED");
        }

        smsOperateDao.updateSmsStatusClose();
    }


    public static ExecutorService getExecutorService() {
        return exec;
    }

}
