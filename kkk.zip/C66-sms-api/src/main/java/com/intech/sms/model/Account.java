package com.intech.sms.model;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author kaiser.dapar
 * @version 1.0, 2015-04-17
 */
public class Account {
	
	public Account() {
		super();
	}
	
	public Account(String accountId) {
		super();
		this.accountId = Integer.parseInt(accountId);
	}
	
	public Account(String productId, String providerCode, Integer flag) {
		super();
		this.productId = productId;
		this.providerCode = providerCode;
		this.flag = flag;
	}

	private Integer accountId;
	private String providerCode;
	private String vcpUserid;
	private String vcpPwd;
	private Integer vcpPort;
	private String vcpServer;
	private Integer flag;
	private Date createdDate;
	private Date lastUpdate;
	private String lastUpdatedBy;
	private String remarks;
	private String mainUserid;
	private Integer success;
	private Integer failed;
	private Integer successRate;
	private String accountRemarks;
	private String tier;
	private String productId;
	private Integer sendGroupFlag;
	private String customerLevel;
	
	// Setters/Getters ---------------------------------------------------------------------------
	
	public Integer getAccountId() {
		return accountId;
	}

	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}
	
	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}
	
	public String getVcpUserid() {
		return vcpUserid;
	}

	public void setVcpUserid(String vcpUserid) {
		this.vcpUserid = vcpUserid;
	}
	
	public String getVcpPwd() {
		return vcpPwd;
	}

	public void setVcpPwd(String vcpPwd) {
		this.vcpPwd = vcpPwd;
	}
	
	public Integer getVcpPort() {
		return vcpPort;
	}

	public void setVcpPort(Integer vcpPort) {
		this.vcpPort = vcpPort;
	}
	
	public String getVcpServer() {
		return vcpServer;
	}

	public void setVcpServer(String vcpServer) {
		this.vcpServer = vcpServer;
	}
	
	public Integer getFlag() {
		return flag;
	}

	public void setFlag(Integer flag) {
		this.flag = flag;
	}
	
	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	public Date getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}
	
	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	
	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	public String getMainUserid() {
		return mainUserid;
	}

	public void setMainUserid(String mainUserid) {
		this.mainUserid = mainUserid;
	}
	
	public Integer getSuccess() {
		return success;
	}

	public void setSuccess(Integer success) {
		this.success = success;
	}
	
	public Integer getFailed() {
		return failed;
	}

	public void setFailed(Integer failed) {
		this.failed = failed;
	}
	
	public Integer getSuccessRate() {
		return successRate;
	}

	public void setSuccessRate(Integer successRate) {
		this.successRate = successRate;
	}
	
	public String getAccountRemarks() {
		return accountRemarks;
	}

	public void setAccountRemarks(String accountRemarks) {
		this.accountRemarks = accountRemarks;
	}
	
	public String getTier() {
		return tier;
	}

	public void setTier(String tier) {
		this.tier = tier;
	}
	
	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public Integer getSendGroupFlag() {
		return sendGroupFlag;
	}

	public void setSendGroupFlag(Integer sendGroupFlag) {
		this.sendGroupFlag = sendGroupFlag;
	}

	public String getCustomerLevel() {
		return customerLevel;
	}

	public void setCustomerLevel(String customerLevel) {
		this.customerLevel = customerLevel;
	}

	// Object overrides ---------------------------------------------------------------------------

	@Override
	public String toString() {
		return String.format("Account [accountId=%s,providerCode=%s,vcpUserid=%s,vcpPwd=%s,vcpPort=%s,vcpServer=%s,flag=%s,createdDate=%s,lastUpdate=%s,lastUpdatedBy=%s,remarks=%s,mainUserid=%s,success=%s,failed=%s,successRate=%s,accountRemarks=%s,tier=%s,productId=%s]", accountId, providerCode, vcpUserid, vcpPwd, vcpPort, vcpServer, flag, createdDate, lastUpdate, lastUpdatedBy, remarks, mainUserid, success, failed, successRate, accountRemarks, tier, productId);
	}
	
	public static final ResultSetExtractor RESULT_SET_EXTRACTOR = new ResultSetExtractor() {
		
		@Override
		public List<Account> extractData(ResultSet resultSet) throws SQLException, DataAccessException {
			List<Account> accountList = new ArrayList<Account>();
			while (resultSet.next()) {
				Account account = new Account();
				account.setAccountId(resultSet.getInt("ACCOUNT_ID"));
				account.setProviderCode(resultSet.getString("PROVIDER_CODE"));
				account.setVcpUserid(resultSet.getString("VCP_USERID"));
				account.setVcpPwd(resultSet.getString("VCP_PWD"));
				account.setVcpPort(resultSet.getInt("VCP_PORT"));
				account.setVcpServer(resultSet.getString("VCP_SERVER"));
				account.setFlag(resultSet.getInt("FLAG"));
				account.setCreatedDate(resultSet.getTimestamp("CREATED_DATE"));
				account.setLastUpdate(resultSet.getTimestamp("LAST_UPDATE"));
				account.setLastUpdatedBy(resultSet.getString("LAST_UPDATED_BY"));
				account.setRemarks(resultSet.getString("REMARKS"));
				account.setMainUserid(resultSet.getString("MAIN_USERID"));
				account.setSuccess(resultSet.getInt("SUCCESS"));
				account.setFailed(resultSet.getInt("FAILED"));
				account.setSuccessRate(resultSet.getInt("SUCCESS_RATE"));
				account.setAccountRemarks(resultSet.getString("ACCOUNT_REMARKS"));
				account.setTier(resultSet.getString("TIER"));
				account.setProductId(resultSet.getString("PRODUCT_ID"));
				account.setSendGroupFlag(resultSet.getInt("SEND_GROUP_FLAG"));
				accountList.add(account);
			}
			return accountList;
		}
		
	};

	public static final ResultSetExtractor ACC_RESULT_SET_EXTRACTOR = new ResultSetExtractor() {

		@Override
		public List<Account> extractData(ResultSet resultSet) throws SQLException, DataAccessException {
			List<Account> accountList = new ArrayList<Account>();
			while (resultSet.next()) {
				Account account = new Account();
				account.setTier(resultSet.getString("TIER"));
				account.setProductId(resultSet.getString("PRODUCT_ID"));
				account.setCustomerLevel(resultSet.getString("CUSTOMER_LEVEL"));
				accountList.add(account);
			}
			return accountList;
		}

	};
	
	public static final RowMapper ROW_MAPPER = new RowMapper() {
	
		@Override
		public Account mapRow(ResultSet resultSet, int index) throws SQLException, DataAccessException {
			Account account = new Account();
			account.setAccountId(resultSet.getInt("ACCOUNT_ID"));
			account.setProviderCode(resultSet.getString("PROVIDER_CODE"));
			account.setVcpUserid(resultSet.getString("VCP_USERID"));
			account.setVcpPwd(resultSet.getString("VCP_PWD"));
			account.setVcpPort(resultSet.getInt("VCP_PORT"));
			account.setVcpServer(resultSet.getString("VCP_SERVER"));
			account.setFlag(resultSet.getInt("FLAG"));
			account.setCreatedDate(resultSet.getTimestamp("CREATED_DATE"));
			account.setLastUpdate(resultSet.getTimestamp("LAST_UPDATE"));
			account.setLastUpdatedBy(resultSet.getString("LAST_UPDATED_BY"));
			account.setRemarks(resultSet.getString("REMARKS"));
			account.setMainUserid(resultSet.getString("MAIN_USERID"));
			account.setSuccess(resultSet.getInt("SUCCESS"));
			account.setFailed(resultSet.getInt("FAILED"));
			account.setSuccessRate(resultSet.getInt("SUCCESS_RATE"));
			account.setAccountRemarks(resultSet.getString("ACCOUNT_REMARKS"));
			account.setTier(resultSet.getString("TIER"));
			account.setProductId(resultSet.getString("PRODUCT_ID"));
			account.setSendGroupFlag(resultSet.getInt("SEND_GROUP_FLAG"));
			return account;
		}
		
	};
}