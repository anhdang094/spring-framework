package com.intech.sms.model;

/***************************************************************************
 * System Name:   xwy_Office System ,vipstar service
 * Module Name:        
 * Class  Name:   BaseModel.java
 *      Author:   David.z IT GoldenWay
 * Finish Date: 　Feb 14, 20112:49:31 PM
 * Funtion Description: 基本类
 *　 　　
 ****************************************************************************
 *　Modify History:
 *　Modify Content　　 Version　 　　Modify Date　　    　　       Modify By
 * 
 *  　　                   V1.0       Feb 14, 20112:49:31 PM      David.z IT GW
 ****************************************************************************/

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

/**
 * @author Administrator
 * 
 */
public abstract class BaseModel implements Serializable {

	private static final long serialVersionUID = 1L;
	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}
	@Override
	public boolean equals(Object o) {
		return EqualsBuilder.reflectionEquals(this, o);
	}
}
