package com.intech.sms.model;

import java.sql.Timestamp;

public class Configuration extends BaseModel {

	private static final long serialVersionUID = 1L;

	private String accountId, vcpServer, vcpPort, vcpUserId, vcpPwd, mainUserId, providerCode, lastUpdatedBy, remarks, accountRemarks, productId, customerLevel;
	private String providerName,smsSignature,countyCode;
	private Timestamp createdDate, lastUpdate;
	private int sendGroupFlag, flag, success, failed, tier, international;
	private Integer signFlag;
	private String accountType;
	private double successRate;
	private boolean isEmailSent = false;

	public String getSmsSignature() {
		return smsSignature;
	}

	public void setSmsSignature(String smsSignature) {
		this.smsSignature = smsSignature;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getVcpServer() {
		return vcpServer;
	}

	public void setVcpServer(String vcpServer) {
		this.vcpServer = vcpServer;
	}

	public String getVcpPort() {
		return vcpPort;
	}

	public void setVcpPort(String vcpPort) {
		this.vcpPort = vcpPort;
	}

	public String getVcpUserId() {
		return vcpUserId;
	}

	public void setVcpUserId(String vcpUserId) {
		this.vcpUserId = vcpUserId;
	}

	public String getVcpPwd() {
		return vcpPwd;
	}

	public void setVcpPwd(String vcpPwd) {
		this.vcpPwd = vcpPwd;
	}

	public String getMainUserId() {
		return mainUserId;
	}

	public void setMainUserId(String mainUserId) {
		this.mainUserId = mainUserId;
	}

	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

    public String getProviderName() {
        return providerName;
    }

    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }

    public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getAccountRemarks() {
		return accountRemarks;
	}

	public void setAccountRemarks(String accountRemarks) {
		this.accountRemarks = accountRemarks;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public Timestamp getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(Timestamp lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public int getSendGroupFlag() {
		return sendGroupFlag;
	}

	public void setSendGroupFlag(int sendGroupFlag) {
		this.sendGroupFlag = sendGroupFlag;
	}

	public int getFlag() {
		return flag;
	}

	public void setFlag(int flag) {
		this.flag = flag;
	}

	public int getSuccess() {
		return success;
	}

	public void setSuccess(int success) {
		this.success = success;
	}

	public int getFailed() {
		return failed;
	}

	public void setFailed(int failed) {
		this.failed = failed;
	}

	public int getTier() {
		return tier;
	}

	public void setTier(int tier) {
		this.tier = tier;
	}

	public double getSuccessRate() {
		return successRate;
	}

	public void setSuccessRate(double successRate) {
		this.successRate = successRate;
	}

	public boolean isEmailSent() {
		return isEmailSent;
	}

	public void setEmailSent(boolean isEmailSent) {
		this.isEmailSent = isEmailSent;
	}

	public String getCustomerLevel() {
		return customerLevel;
	}

	public void setCustomerLevel(String customerLevel) {
		this.customerLevel = customerLevel;
	}

	public int getInternational() {
		return international;
	}

	public void setInternational(int international) {
		this.international = international;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getCountyCode() {
		return countyCode;
	}

	public void setCountyCode(String countyCode) {
		this.countyCode = countyCode;
	}

	public Integer getSignFlag() {
		return signFlag;
	}

	public void setSignFlag(Integer signFlag) {
		this.signFlag = signFlag;
	}

	@Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((customerLevel == null) ? 0 : customerLevel.hashCode());
        result = prime * result + flag;
        result = prime * result + ((mainUserId == null) ? 0 : mainUserId.hashCode());
        result = prime * result + ((productId == null) ? 0 : productId.hashCode());
        result = prime * result + ((providerCode == null) ? 0 : providerCode.hashCode());
        result = prime * result + tier;
        result = prime * result + ((vcpPwd == null) ? 0 : vcpPwd.hashCode());
        result = prime * result + ((vcpServer == null) ? 0 : vcpServer.hashCode());
        result = prime * result + ((vcpUserId == null) ? 0 : vcpUserId.hashCode());
        return result;
    }


    @Override
    public String toString() {
        return String.format("%s-%s-%s-%s", accountId,tier,customerLevel,providerCode);
    }

    @Override
    public boolean equals(Object o) {
        if(o == null){ return false;}
        if(!(o instanceof Configuration)){ return false;}
        Configuration temp = (Configuration) o;
        return accountId.equals(temp.getAccountId());
    }

}
