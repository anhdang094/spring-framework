package com.intech.sms.model;

import java.util.Date;

public class DetailedSms extends BaseModel {
	private static final long serialVersionUID = -7178681764019697097L;
	
	private Long content_id;
	private String product_id;
	private String provider_code;
	private String vcp_userid;
	private String vcp_pwd;
	private Integer vcp_port;
	private String vcp_server;
	private String phone;
	private String send_content;
	private Integer sms_r_flag;
	private Integer sms_fail_times;
	private Date sms_send_date;
	private String sms_remarks;
	private Integer send_group_flag;
	private String sms_main_user_id;

	public void setSms_main_user_id(String sms_main_user_id) {
		this.sms_main_user_id = sms_main_user_id;
	}

	public String getSms_main_user_id() {
		return sms_main_user_id;
	}

	public Long getContent_id() {
		return content_id;
	}

	public void setContent_id(Long content_id) {
		this.content_id = content_id;
	}

	public String getProvider_code() {
		return provider_code;
	}

	public void setProvider_code(String provider_code) {
		this.provider_code = provider_code;
	}

	public String getVcp_userid() {
		return vcp_userid;
	}

	public void setVcp_userid(String vcp_userid) {
		this.vcp_userid = vcp_userid;
	}

	public String getVcp_pwd() {
		return vcp_pwd;
	}

	public void setVcp_pwd(String vcp_pwd) {
		this.vcp_pwd = vcp_pwd;
	}

	public Integer getVcp_port() {
		return vcp_port;
	}

	public void setVcp_port(Integer vcp_port) {
		this.vcp_port = vcp_port;
	}

	public String getVcp_server() {
		return vcp_server;
	}

	public void setVcp_server(String vcp_server) {
		this.vcp_server = vcp_server;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getSend_content() {
		return send_content;
	}

	public void setSend_content(String send_content) {
		this.send_content = send_content;
	}

	public Integer getSms_r_flag() {
		return sms_r_flag;
	}

	public void setSms_r_flag(Integer sms_r_flag) {
		this.sms_r_flag = sms_r_flag;
	}

	public Integer getSms_fail_times() {
		return sms_fail_times;
	}

	public void setSms_fail_times(Integer sms_fail_times) {
		this.sms_fail_times = sms_fail_times;
	}

	public Date getSms_send_date() {
		return sms_send_date;
	}

	public void setSms_send_date(Date sms_send_date) {
		this.sms_send_date = sms_send_date;
	}

	public String getSms_remarks() {
		return sms_remarks;
	}

	public void setSms_remarks(String sms_remarks) {
		this.sms_remarks = sms_remarks;
	}

	public String getProduct_id() {
		return product_id;
	}

	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}

	public Integer getSend_group_flag() {
		return send_group_flag;
	}

	public void setSend_group_flag(Integer send_group_flag) {
		this.send_group_flag = send_group_flag;
	}

}
