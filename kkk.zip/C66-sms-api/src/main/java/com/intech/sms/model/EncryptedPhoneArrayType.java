package com.intech.sms.model;

import java.util.List;

public class EncryptedPhoneArrayType {
	private List<String> values;
	private String type;
	
	public EncryptedPhoneArrayType() {
		
	}
	
	public EncryptedPhoneArrayType(List<String> values) {
		this.values = values;
	}
	
	public List<String> getValues() {
		return values;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
}
