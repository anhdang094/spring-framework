package com.intech.sms.model;

import java.util.List;

public class GenericArrayType {
	private List<String> values;
	private String type;
	
	public GenericArrayType(Object[] objects, String string) {
		
	}
	
	public GenericArrayType(List<String> values, String type) {
		this.values = values;
	}
	
	public List<String> getValues() {
		return values;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	public Object[] getArray() {
		return values.toArray();
	}
}
