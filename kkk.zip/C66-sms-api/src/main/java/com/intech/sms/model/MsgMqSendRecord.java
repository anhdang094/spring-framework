package com.intech.sms.model;

import java.io.Serializable;
import java.util.Date;

/**
 * @author Herman.T
 */
public class MsgMqSendRecord implements Serializable {

    private static final long serialVersionUID = 1582290200075353003L;
    private Long id;
    /**
     * 创建时间
     */
    private Date createdDate;
    /**
     * 产品ID
     */
    private String productId;
    /**
     * 消息内容
     */
    private String msgData;
    /**
     * 消息类型：1=ActiveMQ;2=RabbitMQ
     */
    private Integer msgType;
    /**
     * jms队列名
     */
    private String jmsQueueName;
    /**
     * rabbit ExchangeName
     */
    private String rabbitExchangeName;
    /**
     * rabbit routingKey
     */
    private String rabbitRoutingKey;
    /**
     * 状态：0=等待重发；1=已重发，发送失败；2=已重发，发送成功
     */
    private Integer flag = 0;
    /**
     * 重发次数
     */
    private Integer reSendTimes = 0;
    /**
     * 最后更新时间
     */
    private Date lastUpdateDate;
    /**
     * 备注
     */
    private String remarks;

    private int count;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getMsgData() {
        return msgData;
    }

    public void setMsgData(String msgData) {
        this.msgData = msgData;
    }

    public Integer getMsgType() {
        return msgType;
    }

    public void setMsgType(Integer msgType) {
        this.msgType = msgType;
    }

    public String getJmsQueueName() {
        return jmsQueueName;
    }

    public void setJmsQueueName(String jmsQueueName) {
        this.jmsQueueName = jmsQueueName;
    }

    public String getRabbitExchangeName() {
        return rabbitExchangeName;
    }

    public void setRabbitExchangeName(String rabbitExchangeName) {
        this.rabbitExchangeName = rabbitExchangeName;
    }

    public String getRabbitRoutingKey() {
        return rabbitRoutingKey;
    }

    public void setRabbitRoutingKey(String rabbitRoutingKey) {
        this.rabbitRoutingKey = rabbitRoutingKey;
    }

    public Integer getFlag() {
        return flag;
    }

    public void setFlag(Integer flag) {
        this.flag = flag;
    }

    public Integer getReSendTimes() {
        return reSendTimes;
    }

    public void setReSendTimes(Integer reSendTimes) {
        this.reSendTimes = reSendTimes;
    }

    public Date getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(Date lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }


    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
