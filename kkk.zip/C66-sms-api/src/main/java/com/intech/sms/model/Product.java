package com.intech.sms.model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;


/**
 * @author kaiser.dapar
 * @version 1.0, Mon Mar 30 14:37:51 CST 2015
 */
public class Product {

	private static Map<String,Product> products = new HashMap<>(30);
	
	public static Map<String,Product> getProducts() {
		return Collections.unmodifiableMap(products);
	}

	public static void setProducts(List<Product> products) {
		for (Product product : products) {
			Product.products.put(product.getProductId(), product);
		}
	}
	
	public Product() {
		super();
	}

	private Long id;
	private String productId;
	private String productName;
	private String productDesc;
	private Integer productPrior;
	private Date createdDate;
	private Date lastUpdate;
	private String lastUpdatedBy;
	private String key;
	private String emailKey;
	private Integer mailProductPrior;
	
	// Setters/Getters ---------------------------------------------------------------------------
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}
	
	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}
	
	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}
	
	public Integer getProductPrior() {
		return productPrior;
	}

	public void setProductPrior(Integer productPrior) {
		this.productPrior = productPrior;
	}
	
	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	public Date getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}
	
	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	
	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}
	
	public String getEmailKey() {
		return emailKey;
	}

	public void setEmailKey(String emailKey) {
		this.emailKey = emailKey;
	}
	
	public Integer getMailProductPrior() {
		return mailProductPrior;
	}

	public void setMailProductPrior(Integer mailProductPrior) {
		this.mailProductPrior = mailProductPrior;
	}
	
	// Object overrides ---------------------------------------------------------------------------

	@Override
	public String toString() {
		return String.format("Product [id=%s,productId=%s,productName=%s,productDesc=%s,productPrior=%s,createdDate=%s,lastUpdate=%s,lastUpdatedBy=%s,key=%s,emailKey=%s,mailProductPrior=%s]", id, productId, productName, productDesc, productPrior, createdDate, lastUpdate, lastUpdatedBy, key, emailKey, mailProductPrior);
	}
	
	public static final ResultSetExtractor RESULT_SET_EXTRACTOR = new ResultSetExtractor() {
		
		@Override
		public List<Product> extractData(ResultSet resultSet) throws SQLException, DataAccessException {
			List<Product> productList = new ArrayList<Product>();
			while (resultSet.next()) {
				Product product = new Product();
				product.setId(resultSet.getLong("ID"));
				product.setProductId(resultSet.getString("PRODUCT_ID"));
				product.setProductName(resultSet.getString("PRODUCT_NAME"));
				product.setProductDesc(resultSet.getString("PRODUCT_DESC"));
				product.setProductPrior(resultSet.getInt("PRODUCT_PRIOR"));
				product.setCreatedDate(resultSet.getTimestamp("CREATED_DATE"));
				product.setLastUpdate(resultSet.getTimestamp("LAST_UPDATE"));
				product.setLastUpdatedBy(resultSet.getString("LAST_UPDATED_BY"));
				product.setKey(resultSet.getString("KEY"));
				product.setEmailKey(resultSet.getString("EMAIL_KEY"));
				product.setMailProductPrior(resultSet.getInt("MAIL_PRODUCT_PRIOR"));
				productList.add(product);
			}
			return productList;
		}
		
	};
	
	public static final RowMapper ROW_MAPPER = new RowMapper() {
	
		@Override
		public Product mapRow(ResultSet resultSet, int index) throws SQLException, DataAccessException {
			Product product = new Product();
			product.setId(resultSet.getLong("ID"));
			product.setProductId(resultSet.getString("PRODUCT_ID"));
			product.setProductName(resultSet.getString("PRODUCT_NAME"));
			product.setProductDesc(resultSet.getString("PRODUCT_DESC"));
			product.setProductPrior(resultSet.getInt("PRODUCT_PRIOR"));
			product.setCreatedDate(resultSet.getTimestamp("CREATED_DATE"));
			product.setLastUpdate(resultSet.getTimestamp("LAST_UPDATE"));
			product.setLastUpdatedBy(resultSet.getString("LAST_UPDATED_BY"));
			product.setKey(resultSet.getString("KEY"));
			product.setEmailKey(resultSet.getString("EMAIL_KEY"));
			product.setMailProductPrior(resultSet.getInt("MAIL_PRODUCT_PRIOR"));
			return product;
		}
		
	};
	
}
