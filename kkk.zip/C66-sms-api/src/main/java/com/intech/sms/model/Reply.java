package com.intech.sms.model;

import com.alibaba.fastjson.annotation.JSONField;

import java.sql.Timestamp;

public class Reply {
	
	private String id;
	private String phone;
	@JSONField(format = "yyyy-MM-dd HH:mm:ss")
	private Timestamp receiveDate;
	private String content;
	private String productId;
	@JSONField(format = "yyyy-MM-dd HH:mm:ss")
	private Timestamp createdDate;
	private String providerCode;
	private String account;
	
	public String getPhone() {
		return phone;
	}
	
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	public Timestamp getReceiveDate() {
		return receiveDate;
	}
	
	public void setReceiveDate(Timestamp receiveDate) {
		this.receiveDate = receiveDate;
	}
	
	public String getContent() {
		return content;
	}
	
	public void setContent(String content) {
		this.content = content;
	}
	
	public String getProductId() {
		return productId;
	}
	
	public void setProductId(String productId) {
		this.productId = productId;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}
}
