package com.intech.sms.model;

public class ServerInfo extends BaseModel{
	private static final long serialVersionUID = 1L;
	
	private int serverId;
	private String serverUrl;
	private int flag;
	
	public int getServerId() {
		return serverId;
	}
	public void setServerId(int serverId) {
		this.serverId = serverId;
	}
	public String getServerUrl() {
		return serverUrl;
	}
	public void setServerUrl(String serverUrl) {
		this.serverUrl = serverUrl;
	}
	public int getFlag() {
		return flag;
	}
	public void setFlag(int flag) {
		this.flag = flag;
	}
}
