package com.intech.sms.model;

import java.util.Date;
import java.util.List;

public class Sms {
	private String contentId;
	private String phoneNumber;
	private String sendContent;
	private String typeCode;
	private Integer smsResponseFlag;
	private Date smsSendDate;
	private Integer smsFailTimes = 0;
	private String smsRemarks;
	private String last_send_by;
	private String productId;
	private boolean decrypted;
	private String customerLevel;
	private String reserveField;

	private String currentSmsAccountId;
	private String phoneNumberMd5;

	/**
     * when sent in batches, sms will have a batch id.
     */
	private String batchId;
	private boolean multipleSend;
	private String countryCode;
	private String providerCode;

	private String tier;
	private Integer sendMethod;
	private String extraParam;
	private String port;
	private List<Sms> batchList;

	public String getExtraParam() {
		return extraParam;
	}

	public void setExtraParam(String extraParam) {
		this.extraParam = extraParam;
	}

	public List<Sms> getBatchList() {
		return batchList;
	}

	public void setBatchList(List<Sms> batchList) {
		this.batchList = batchList;
	}

	public String getContentId() {
		return contentId;
	}

	public void setContentId(String contentId) {
		this.contentId = contentId;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getSendContent() {
		return sendContent;
	}

	public void setSendContent(String sendContent) {
		this.sendContent = sendContent;
	}

	public String getTypeCode() {
		return typeCode;
	}

	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}

	public Integer getSmsResponseFlag() {
		return smsResponseFlag;
	}

	public void setSmsResponseFlag(Integer smsResponseFlag) {
		this.smsResponseFlag = smsResponseFlag;
	}

	public Date getSmsSendDate() {
		return smsSendDate;
	}

	public void setSmsSendDate(Date smsSendDate) {
		this.smsSendDate = smsSendDate;
	}

	public String getSmsRemarks() {
		return smsRemarks;
	}

	public void setSmsRemarks(String smsRemarks) {
		this.smsRemarks = smsRemarks;
	}

	public Integer getSmsFailTimes() {
		return smsFailTimes;
	}

	public void setSmsFailTimes(Integer smsFailTimes) {
		this.smsFailTimes = smsFailTimes;
	}

	public void incrementFailTimes() {
		this.smsFailTimes++;
	}

	public String getLast_send_by() {
		return last_send_by;
	}

	public void setLast_send_by(String last_send_by) {
		this.last_send_by = last_send_by;
	}

	public boolean isDecrypted() {
		return decrypted;
	}

	public void setDecrypted(boolean decrypted) {
		this.decrypted = decrypted;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getCustomerLevel() {
		return customerLevel;
	}

	public void setCustomerLevel(String customerLevel) {
		this.customerLevel = customerLevel;
	}

	public String getReserveField() {
		return reserveField;
	}

	public void setReserveField(String reserveField) {
		this.reserveField = reserveField;
	}

	public String getBatchId() {
		return batchId;
	}

	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}

	public boolean isMultipleSend() {
		return multipleSend;
	}

	public void setMultipleSend(boolean multipleSend) {
		this.multipleSend = multipleSend;
	}

	/**
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return countryCode;
	}

	/**
	 * @param countryCode the countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

    public String getProviderCode() {
        return providerCode;
    }

    public void setProviderCode(String providerCode) {
        this.providerCode = providerCode;
    }


    @Override
    public boolean equals(Object arg0) {
        Sms temp = (Sms) arg0;
        return temp.getContentId().equals(this.contentId);
    }

	public Integer getSendMethod() {
		return sendMethod;
	}

	public void setSendMethod(Integer sendMethod) {
		this.sendMethod = sendMethod;
	}

	public String getTier() {
		return tier;
	}

	public void setTier(String tier) {
		this.tier = tier;
	}

	public String getCurrentSmsAccountId() {
		return currentSmsAccountId;
	}

	public void setCurrentSmsAccountId(String currentSmsAccountId) {
		this.currentSmsAccountId = currentSmsAccountId;
	}

	public String getPhoneNumberMd5() {
		return phoneNumberMd5;
	}

	public void setPhoneNumberMd5(String phoneNumberMd5) {
		this.phoneNumberMd5 = phoneNumberMd5;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	@Override
	public String toString() {
		return "Sms{" +
				"contentId='" + contentId + '\'' +
				", sendContent='" + sendContent + '\'' +
				", typeCode='" + typeCode + '\'' +
				", smsResponseFlag=" + smsResponseFlag +
				", smsSendDate=" + smsSendDate +
				", smsFailTimes=" + smsFailTimes +
				", smsRemarks='" + smsRemarks + '\'' +
				", last_send_by='" + last_send_by + '\'' +
				", productId='" + productId + '\'' +
				", decrypted=" + decrypted +
				", customerLevel='" + customerLevel + '\'' +
				", reserveField='" + reserveField + '\'' +
				", batchId='" + batchId + '\'' +
				", multipleSend=" + multipleSend +
				", countryCode='" + countryCode + '\'' +
				", sendMethod='" + sendMethod + '\'' +
				", providerCode='" + providerCode + '\'' +
				", extraParam='" + extraParam + '\'' +
				", port='" + port + '\'' +
				'}';
	}
}
