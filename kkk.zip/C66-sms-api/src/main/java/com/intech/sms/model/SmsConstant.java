package com.intech.sms.model;

import java.io.Serializable;
import java.util.Date;

/**
 * @author Herman.T
 */
public class SmsConstant implements Serializable {

    private static final long serialVersionUID = 3907403809710896756L;
    private Long id;

    private String productId;

    private String constantKey;

    private String constantName;

    private String constantValue;

    private Date createdDate;

    private Date lastuptDate;

    private String flag;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getConstantKey() {
        return constantKey;
    }

    public void setConstantKey(String constantKey) {
        this.constantKey = constantKey;
    }

    public String getConstantName() {
        return constantName;
    }

    public void setConstantName(String constantName) {
        this.constantName = constantName;
    }

    public String getConstantValue() {
        return constantValue;
    }

    public void setConstantValue(String constantValue) {
        this.constantValue = constantValue;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Date getLastuptDate() {
        return lastuptDate;
    }

    public void setLastuptDate(Date lastuptDate) {
        this.lastuptDate = lastuptDate;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }
}
