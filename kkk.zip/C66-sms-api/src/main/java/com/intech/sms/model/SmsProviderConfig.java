package com.intech.sms.model;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 短信渠道分级配置
 *
 * @author Yaser
 * @date 2020/7/14 19:19
 */
public class SmsProviderConfig {

    private Long id;
    private String productId;
    private String configName;
    private String providerCode;
    private String typeIds;
    private String customerLevels;
    private Integer exclusiveFlag;
    private String createBy;
    private String lastUpdateBy;
    private String extraParam;
    private Date createDate;
    private Date lastUpdateDate;

    public String getExtraParam() {
        return extraParam;
    }

    public void setExtraParam(String extraParam) {
        this.extraParam = extraParam;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getConfigName() {
        return configName;
    }

    public void setConfigName(String configName) {
        this.configName = configName;
    }

    public String getProviderCode() {
        return providerCode;
    }

    public void setProviderCode(String providerCode) {
        this.providerCode = providerCode;
    }

    public String getTypeIds() {
        return typeIds;
    }

    public void setTypeIds(String typeIds) {
        this.typeIds = typeIds;
    }

    public String getCustomerLevels() {
        return customerLevels;
    }

    public void setCustomerLevels(String customerLevels) {
        this.customerLevels = customerLevels;
    }

    public Integer getExclusiveFlag() {
        return exclusiveFlag;
    }

    public void setExclusiveFlag(Integer exclusiveFlag) {
        this.exclusiveFlag = exclusiveFlag;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public String getLastUpdateBy() {
        return lastUpdateBy;
    }

    public void setLastUpdateBy(String lastUpdateBy) {
        this.lastUpdateBy = lastUpdateBy;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(Date lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public static final ResultSetExtractor RESULT_SET_EXTRACTOR = new ResultSetExtractor() {

        @Override
        public List<SmsProviderConfig> extractData(ResultSet resultSet) throws SQLException, DataAccessException {
            List<SmsProviderConfig> configs = new ArrayList<SmsProviderConfig>();
            while (resultSet.next()) {
                SmsProviderConfig config = new SmsProviderConfig();
                config.setId(resultSet.getLong("id"));
                config.setProviderCode(resultSet.getString("PROVIDER_CODE"));
                config.setExclusiveFlag(resultSet.getInt("Exclusive_Flag"));
                config.setCreateDate(resultSet.getTimestamp("CREATE_DATE"));
                config.setLastUpdateDate(resultSet.getTimestamp("LAST_UPDATE_DATE"));
                config.setLastUpdateBy(resultSet.getString("LAST_UPDATE_BY"));
                config.setCreateBy(resultSet.getString("CREATE_BY"));
                config.setProductId(resultSet.getString("PRODUCT_ID"));
                config.setCustomerLevels(resultSet.getString("CUSTOMER_LEVELS"));
                config.setTypeIds(resultSet.getString("TYPE_IDS"));
                config.setConfigName(resultSet.getString("CONFIG_NAME"));
                config.setExtraParam(resultSet.getString("extra_param"));
                configs.add(config);
            }
            return configs;
        }

    };
}
