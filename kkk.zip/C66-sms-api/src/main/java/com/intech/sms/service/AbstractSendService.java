package com.intech.sms.service;

import com.alibaba.fastjson.JSONObject;
import com.intech.configuration.PropertiesConfig;
import com.intech.sms.dao.SMSOperateDao;
import com.intech.sms.interfaces.SmsSendService;
import com.intech.sms.model.Account;
import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.ApplicationContextSingleton;
import com.intech.sms.util.Convert;
import com.intech.sms.util.GenericValidationUtility;
import com.intech.sms.util.HttpClientUtil;
import org.apache.commons.codec.CharEncoding;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

abstract class AbstractSendService implements SmsSendService {
    protected static final String CHARACTER_ENCODING = CharEncoding.UTF_8;
    protected static Logger logger = LoggerFactory.getLogger(SmsSendService.class);

    protected String vcpServer, vcpPort, vcpUserId, vcpPwd, mainUserId, accountId;

    protected PropertiesConfig propertiesConfig = ApplicationContextSingleton.getBean(PropertiesConfig.class);

    protected SMSOperateDao smsOperateDao = ApplicationContextSingleton.getBean(SMSOperateDao.class);

    protected int smsGroupFlag;
    protected int tier;

    protected String providerCode;

    private HttpClientUtil httpClientUtil;

    public AbstractSendService() {
    }

    public AbstractSendService(Configuration config) {
        this.vcpServer = config.getVcpServer();
        this.vcpPort = config.getVcpPort();
        this.vcpUserId = config.getVcpUserId();
        this.vcpPwd = config.getVcpPwd();
        this.mainUserId = config.getMainUserId();
        this.smsGroupFlag = config.getSendGroupFlag();
        this.accountId = config.getAccountId();
        this.tier = config.getTier();
    }

    @Override
    public boolean hasChanges(Configuration config) {
        boolean hasChanges = false;

        if (!this.vcpServer.equals(config.getVcpServer())) {
            this.vcpServer = config.getVcpServer();
            hasChanges = true;
        }

        if (!this.vcpPort.equals(config.getVcpPort())) {
            this.vcpPort = config.getVcpPort();
            hasChanges = true;
        }

        if (!this.vcpUserId.equals(config.getVcpUserId())) {
            this.vcpUserId = config.getVcpUserId();
            hasChanges = true;
        }

        if (!this.vcpPwd.equals(config.getVcpPwd())) {
            this.vcpPwd = config.getVcpPwd();
            hasChanges = true;
        }

        if (!this.mainUserId.equals(config.getMainUserId())) {
            this.mainUserId = config.getMainUserId();
            hasChanges = true;
        }

        if (this.smsGroupFlag != config.getSendGroupFlag()) {
            this.smsGroupFlag = config.getSendGroupFlag();
            hasChanges = true;
        }

        return hasChanges;
    }

    @Override
    public abstract int send(Sms sms);

    @SuppressWarnings("rawtypes")
    protected static String parametersToString(Map map) {
        if ((map == null) || (map.keySet().size() == 0)) {
            return "";
        }
        StringBuilder parameters = new StringBuilder();
        Set keys = map.keySet();

        for (Iterator i = keys.iterator(); i.hasNext(); ) {
            String key = String.valueOf(i.next());
            String value = String.valueOf(map.get(key));

            //put all mobile or phone params here

            if ("mobile".equals(key) ||
                    "to".equals(key) ||
                    "Phones".equals(key) ||
                    "called".equals(key) ||
                    "destination".equals(key) ||
                    "phoneNumber".equals(key) ||
                    "batchlist".equals(key)||
                    "phoneNumberList".equals(key) ||
                    "aimcodes".equals(key) ||
                    "mobiles".equals(key) ||
                    "msisdn".equals(key) || "accPwd".equals(key.toLowerCase()) ||
                    "mobilenumber".equals(key) || "pwd".equals(key.toLowerCase()) || "pswd".equals(key.toLowerCase()) ||
                    "rec_num".equals(key) || "password".equals(key.toLowerCase()) || "passwd".equals(key.toLowerCase())) {
                try {
//                    value = Convert.MD5Encode(value);
                    value = "疑似敏感信息";
                } catch (Exception e) {
                    logger.error("敏感字段加密异常", e);
                }
            }

            parameters.append(key).append(": ").append(value).append(" | ");
        }

        String out = parameters.toString();

        if (out.endsWith(" | ")) {
            out = out.substring(0, (out.length() - 3));
        }

        return out;
    }

    @Override
    public void setProviderCode(String providerCode) {
        this.providerCode = providerCode;
    }

    protected String accountToString(String characterEncoding) {
        return
                String.format("%s: %s | %s: %s | %s: %s | %s: %s | %s: %s | %s: %s",
                        "vcpServer", vcpServer.equals("") ? "null" : vcpServer,
                        "vcpPort", vcpPort != null && vcpPort.equals("") ? "null" : vcpPort,
                        "vcpUserId", vcpUserId.equals("") ? "null" : vcpUserId,
                        "mainUserId", mainUserId != null && mainUserId.equals("") ? "null" : mainUserId,
                        //"vcpPwd",vcpPwd.equals("")?"null":vcpPwd,
                        "smsGroupFlag", smsGroupFlag,
                        "characterEncoding", characterEncoding == null ? "null" : characterEncoding
                );
    }

    protected String evaluateResult(String response, String code) {
        String value = "null";
        if (!GenericValidationUtility.isEmpty(response)) {
            try {
                Document document = DocumentHelper.parseText(response);
                Element root = document.getRootElement();
                Iterator<?> elementIterator = root.elementIterator();

                while (elementIterator.hasNext()) {

                    Element element = (Element) elementIterator.next();
                    String node = element.getName().trim();
                    String nodeValue = element.getText().trim();

                    if (node.equals(code)) {
                        value = nodeValue;
                        break;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return value;
    }

    protected String sendResultString(String providerCode, String productId, String level, String status, String reason, Long cost, String smsId){
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("providerCode", providerCode);
        jsonObject.put("server", vcpServer);
        jsonObject.put("productId", productId);
        jsonObject.put("tier", level);
        jsonObject.put("status", status);
        jsonObject.put("reason", reason);
        jsonObject.put("cost", Objects.isNull(cost)?"":cost);
        jsonObject.put("smsId", smsId);

        return jsonObject.toJSONString();
    }

    public HttpClientUtil getHttpClientUtil() {
        return httpClientUtil;
    }

    @Override
    public void setHttpClientUtil(HttpClientUtil httpClientUtil) {
        this.httpClientUtil = httpClientUtil;
    }


    protected void updateSmsSendFailed(String batchId,String phoneMd5,String accountId)throws Exception{
        Sms smspo = new Sms();
        smspo.setBatchId(batchId);
        smspo.setLast_send_by(accountId);
        smspo.setPhoneNumberMd5(phoneMd5);
        smspo.setSmsFailTimes(1);
        smspo.setSmsResponseFlag(-1);
        smspo.setSmsSendDate(new Date());
        smspo.setSmsRemarks("fail");
        smspo.setProviderCode(this.providerCode);
        smspo.setMultipleSend(true);
        smsOperateDao.updateSmsStatus(smspo);
        smsOperateDao.updateAccountStats(accountId, false);

    }
}
