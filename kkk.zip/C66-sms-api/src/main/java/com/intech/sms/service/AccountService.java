package com.intech.sms.service;

import java.util.List;
import com.intech.sms.model.Account;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author kaiser.dapar
 * @version 1.0, 2015-04-17
 */
public interface AccountService {
	
	public final Logger LOGGER = LoggerFactory.getLogger("AccountService");
	
	public Account retrieve(Account account);
	public List<Account> retrieveAll();
	public int retrieveCountByCriteria(Account account);
	public List<Account> retrieveListByCriteria(Account account);
	public List<Account> retrieveListByCriteria(Account account, String orderBy, boolean isAsc, int offset, int size);
	
	public int create(Account account) throws Exception;
	public int update(Account account) throws Exception;
	public void delete(Account account) throws Exception;

}