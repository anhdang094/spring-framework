package com.intech.sms.service;

import com.intech.sms.model.Reply;

/**
 * Created by Judd.Z on 2018/11/21.
 */
public interface MQCallBack<T extends Reply> {

    void afterSuccessDo(T t);

    void afterFailDo(T t);

}
