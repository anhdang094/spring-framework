package com.intech.sms.service;

import java.util.List;

import com.intech.sms.model.Product;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author kaiser.dapar
 * @version 1.0, Mon Mar 30 14:37:51 CST 2015
 */
public interface ProductService {
	
	public final Logger LOGGER = LoggerFactory.getLogger("ProductService");
	
	public Product retrieve(Product product);
	public List<Product> retrieveAll();
	public int retrieveCountByCriteria(Product product);
	public List<Product> retrieveListByCriteria(Product product);
	public List<Product> retrieveListByCriteria(Product product, String orderBy, boolean isAsc, int offset, int size);
	
	public int create(Product product) throws Exception;
	public int update(Product product) throws Exception;
	public void delete(Product product) throws Exception;
}
