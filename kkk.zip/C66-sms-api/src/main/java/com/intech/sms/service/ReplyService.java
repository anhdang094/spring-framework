package com.intech.sms.service;

import java.util.List;

import com.intech.sms.model.Reply;
import org.springframework.beans.factory.annotation.Value;

public interface ReplyService{


	//int insertReply(String phone, String content, String contentUtf, String postFixNum) throws DAOException;
	int insertReplies(final List<Reply> replies);
	List<Reply> getReplies(String phone, String productId);
	int updateReplyJMSFlag(String id,String srcFlag,String descFlag);
	int updateReplyJMSFlag(String id);
	List<Reply> getUnsentReplies(String productId);
	int getCoolCardMaxId(String accountId);
	int updateCoolCardMaxId(String accountId, String newMaxId);
	String getMaxReceiveDateByAccount(String account);
}
