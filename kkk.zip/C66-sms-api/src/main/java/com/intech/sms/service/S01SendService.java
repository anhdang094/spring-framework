package com.intech.sms.service;

import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.Constants;
import com.intech.sms.util.StringUtils;
import com.todaynic.client.mobile.SMS;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

/**
 * @author kaiser.dapar
 */
@Deprecated
public class S01SendService extends AbstractSendService {


    public S01SendService() {
    }

    public S01SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        logger.info("S01 ACCOUNT INFO: " + accountToString(null));

        int sent = 0;
        String responseCode = null;
        Long cost = null;
        try {
            SMS smsSender = new SMS(getConfiguration());
            Map<String, String> params = new HashMap<String, String>();
            params.put("message", sms.getSendContent());
            params.put("datetime", Constants.TIME);
            params.put("apitype", Constants.TYPE);

            if (smsGroupFlag == 0) {

                params.put("mobile", sms.getPhoneNumber());
                long startTime = System.currentTimeMillis();
                logger.info("S01 PARAMETER REQUEST: " + parametersToString(params));
                smsSender.sendSMS(sms.getPhoneNumber(), sms.getSendContent(), Constants.TIME, Constants.TYPE);
                String response = smsSender.getRecieveXml();
                cost = System.currentTimeMillis() - startTime;
                logger.info("S01 RESPONSE,耗时(ms):{},返回值{}", cost, response);
                responseCode = smsSender.getCode();
                logger.info("S01 RESPONSE CODE: " + responseCode);

                if (responseCode != null && responseCode.equals(Constants.SUCCESS_2000)) {
                    sent = 1;
                }

            } else {

                String[] numbers = sms.getPhoneNumber().split(",");
                for (String number : numbers) {

                    params.put("mobile", number);
                    long startTime = System.currentTimeMillis();
                    logger.info("S01 PARAMETER REQUEST: " + parametersToString(params));
                    smsSender.sendSMS(number, sms.getSendContent(), Constants.TIME, Constants.TYPE);
                    String response = smsSender.getRecieveXml();
                    cost = System.currentTimeMillis() - startTime;
                    logger.info("S01 RESPONSE,耗时(ms):{},返回值{}", cost, response);
                    responseCode = smsSender.getCode();
                    logger.info("S01 RESPONSE CODE: " + responseCode);

                    if (responseCode != null && responseCode.equals(Constants.SUCCESS_2000)) {
                        sent = 1;
                    }
                }
            }

        } catch (Exception e) {
            logger.error("S01 SENDING ERROR: " + e.getMessage(), e);
        }

        logger.info(sendResultString(providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), responseCode, cost, StringUtils.isNotEmpty(sms.getBatchId())?sms.getBatchId():sms.getContentId()));
        return sent;
    }

    private Hashtable<String, String> getConfiguration() {
        Hashtable<String, String> temp = new Hashtable<String, String>();
        temp.put(Constants.TODAY_NIC_KEY_SERVER, vcpServer);
        temp.put(Constants.TODAY_NIC_KEY_PORT, vcpPort);
        temp.put(Constants.TODAY_NIC_KEY_USERID, vcpUserId);
        temp.put(Constants.TODAY_NIC_KEY_PASSWD, vcpPwd);
        return temp;
    }

}