package com.intech.sms.service;

import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.*;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author kaiser.dapar
 */
public class S02SendService extends AbstractSendService {

    public S02SendService() {
    }

    public S02SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        logger.info("S02 ACCOUNT INFO: " + accountToString(null));

        int sent = 0;
        String response = null;
        Long cost = null;
        try {
            Map<String, String> params = new HashMap<String, String>();
            params.put("id", vcpUserId);
            params.put("msg", sms.getSendContent());
            HttpClientUtil httpClientUtil = getHttpClientUtil();
            List<Sms> batchList = sms.getBatchList();
            if (CollectionUtils.isNotEmpty(batchList)) {
                //遍历单发
                logger.info("{}不支持一次性提交多条短信,开始遍历单发", this.providerCode);
                String number = null;

                int index = 1;
                int successCount = 0;
                for (Sms smsTemp : batchList) {
                    int childSendFlag = 0;
                    try {
                        if (sms.getProductId().equalsIgnoreCase("TLB")) {
                            number = "00" + smsTemp.getPhoneNumber();
                        } else {
                            if (ProductConstants.PRODUCT_ID_C07.equalsIgnoreCase(sms.getProductId())) {
                                number = ComposePhone.getPhone(smsTemp.getPhoneNumber(), Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.VIETNAM_2, CountryCode.VIETNAM_2);
                            } else if (ProductConstants.PRODUCT_ID_C31.equalsIgnoreCase(sms.getProductId())) {
                                number = ComposePhone.getPhone(smsTemp.getPhoneNumber(), Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.JAPAN_2, CountryCode.JAPAN_2);
                            } else {
                                number = ComposePhone.getPhone(smsTemp.getPhoneNumber(), Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.CHINA_2, CountryCode.CHINA_2);
                            }
                        }
                        params.put("to", number);
                        params.put("msg", smsTemp.getSendContent());
                        long startTime = System.currentTimeMillis();
                        logger.info("{} REQUEST PARAMETERS{},第{}条", this.providerCode, parametersToString(params), index);
                        if (httpClientUtil != null) {
                            response = httpClientUtil.doPostWithAgent(vcpServer, params);
                        } else {
                            response = HttpUtil.doPostWithAgent(vcpServer, params);
                        }
                        cost = System.currentTimeMillis() - startTime;
                        logger.info("{} RESPONSE,耗时(ms):{},返回值{},第{}条", cost, response, index);
                        if (StringUtils.isNotBlank(response)) {
                            int responseCode = Integer.parseInt(response);
                            childSendFlag = dealResult(responseCode);
                        }

                    } catch (Exception e) {
                        logger.error(String.format("%s遍历单发提交批量短信失败,本次batchId:%s,index:%s将被更新为失败", this.providerCode, sms.getBatchId(), index), e);
                    }
                    if (1 == childSendFlag) {
                        successCount++;
                    } else {
                        //直接更新那一条失败  不再重试
                        updateSmsSendFailed(sms.getBatchId(), Convert.MD5Encode(smsTemp.getPhoneNumber()), sms.getCurrentSmsAccountId());
                    }
                    index++;
                }
                sent = successCount == batchList.size() ? 1 : -2;

            } else {

                if (smsGroupFlag == 0 && !sms.getProductId().equalsIgnoreCase("TLB")) {
                    String to = "";
                    if (ProductConstants.PRODUCT_ID_C07.equalsIgnoreCase(sms.getProductId())) {
                        to = ComposePhone.getPhone(sms.getPhoneNumber(), Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.VIETNAM_2, CountryCode.VIETNAM_2);
                    } else if (ProductConstants.PRODUCT_ID_C31.equalsIgnoreCase(sms.getProductId())) {
                        to = ComposePhone.getPhone(sms.getPhoneNumber(), Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.JAPAN_2, CountryCode.JAPAN_2);
                    } else {
                        if (StringUtils.isNotEmpty(sms.getCountryCode())) {
                            to = ComposePhone.getPhone(sms.getPhoneNumber(), Constants.TEMPLATE_PARAMETER_MARKER, sms.getCountryCode(), sms.getCountryCode());
                        } else {
                            to = ComposePhone.getPhone(sms.getPhoneNumber(), Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.CHINA_2, CountryCode.CHINA_2);
                        }
                    }
                    params.put("to", to);
                    long startTime = System.currentTimeMillis();
                    logger.info("S02 REQUEST PARAMETERS: " + parametersToString(params));
                    if (httpClientUtil != null) {
                        response = httpClientUtil.doPostWithAgent(vcpServer, params);
                    } else {
                        response = HttpUtil.doPostWithAgent(vcpServer, params);
                    }
                    cost = System.currentTimeMillis() - startTime;
                    logger.info("S02 RESPONSE,耗时(ms):{},返回值{}", cost, response);
                    if (StringUtils.isNotBlank(response)) {
                        int responseCode = Integer.parseInt(response);
                        sent = dealResult(responseCode);
                    }
                } else {
                    String[] numbers = sms.getPhoneNumber().split(",");
                    for (String number : numbers) {
                        if (sms.getProductId().equalsIgnoreCase("TLB")) {
                            number = "00" + number;
                        } else {
                            if (ProductConstants.PRODUCT_ID_C07.equalsIgnoreCase(sms.getProductId())) {
                                number = ComposePhone.getPhone(number, Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.VIETNAM_2, CountryCode.VIETNAM_2);
                            } else if (ProductConstants.PRODUCT_ID_C31.equalsIgnoreCase(sms.getProductId())) {
                                number = ComposePhone.getPhone(number, Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.JAPAN_2, CountryCode.JAPAN_2);
                            } else {
                                number = ComposePhone.getPhone(number, Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.CHINA_2, CountryCode.CHINA_2);
                            }
                        }
                        params.put("to", number);
                        long startTime = System.currentTimeMillis();
                        logger.info("S02 REQUEST PARAMETERS: " + parametersToString(params));
                        if (httpClientUtil != null) {
                            response = httpClientUtil.doPostWithAgent(vcpServer, params);
                        } else {
                            response = HttpUtil.doPostWithAgent(vcpServer, params);
                        }
                        cost = System.currentTimeMillis() - startTime;
                        logger.info("S02 RESPONSE,耗时(ms):{},返回值{}", cost, response);
                        if (StringUtils.isNotBlank(response)) {
                            int responseCode = 0;
                            try {
                                responseCode = Integer.parseInt(response);
                            } catch (NumberFormatException e) {
                                responseCode = -1;
                                logger.error("解析报错：{}", e.getMessage(), e);
                            }
                            sent = dealResult(responseCode);
                        }
                    }
                }
            }

        } catch (Exception e) {
            logger.error("S02 SENDING ERROR: " + e.getMessage(), e);
        }

        logger.info(sendResultString(providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), response, cost, com.intech.sms.util.StringUtils.isNotEmpty(sms.getBatchId()) ? sms.getBatchId() : sms.getContentId()));
        return sent;
    }

    private int dealResult(int responseCode) {
        switch (responseCode) {
            case 0:
                logger.info("S02 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!参数不正确!!!!!!!!!!!!!!!!!!!!!!!");
                return -1;
            case 1:
                //成功
                return 1;
            case 2:
                logger.info("S02 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!无此账户!!!!!!!!!!!!!!!!!!!!!!!");
                return -1;
            case 3:
                logger.info("S02 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!账户未激活!!!!!!!!!!!!!!!!!!!!!!!");
                return -1;
            case 4:
                logger.info("S02 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!账户余额不足!!!!!!!!!!!!!!!!!!!!!!!");
                return -1;
            case 5:
                logger.info("S02 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!非法请求!!!!!!!!!!!!!!!!!!!!!!!");
                return -1;
            case 6:
                logger.info("S02 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!号码无效!!!!!!!!!!!!!!!!!!!!!!!");
                return -1;
            case 7:
                logger.info("S02 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!预约超时!!!!!!!!!!!!!!!!!!!!!!!");
                return -1;
            case 8:
                logger.info("S02 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!账户不支持群发!!!!!!!!!!!!!!!!!!!!!!!");
                return -1;
            default:
                logger.info("S02 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!短信接口方异常!!!!!!!!!!!!!!!!!!!!!!!");
                return -1;
        }
    }
}