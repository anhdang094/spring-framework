package com.intech.sms.service;

import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.*;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * @author kaiser.dapar
 */
@Deprecated
public class S03SendService extends AbstractSendService {
    public S03SendService() {
    }

    public S03SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        logger.info("S03 ACCOUNT INFO: " + accountToString(CHARACTER_ENCODING));
        int sent = 0;
        String response = null;
        Long cost = null;
        try {
            Map<String, String> params = new HashMap<String, String>();
            params.put("id", vcpUserId);
            params.put("msg", HttpUtil.encode(sms.getSendContent(), CHARACTER_ENCODING));
            HttpClientUtil httpClientUtil = getHttpClientUtil();
            String to = "";
            if (smsGroupFlag == 0) {
                String batch = null;
                int count = 0;
                String[] numbers = sms.getPhoneNumber().split(",");
                for (String number : numbers) {
                    if (count == 0) {
                        batch = number;
                    } else {
                        batch += "," + number;
                    }
                    count++;
                    if (count >= Constants.BATCH_SIZE) {
                        if (ProductConstants.PRODUCT_ID_C07.equalsIgnoreCase(sms.getProductId())) {
                            to = ComposePhone.getPhone(batch, Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.VIETNAM_2, CountryCode.VIETNAM_2);
                        }else if (ProductConstants.PRODUCT_ID_C31.equalsIgnoreCase(sms.getProductId())) {
                            to = ComposePhone.getPhone(batch, Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.JAPAN_2, CountryCode.JAPAN_2);
                        } else {
                            to = ComposePhone.getPhone(batch, Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.CHINA_2, CountryCode.CHINA_2);
                        }
                        params.put("to", to);
                        long startTime = System.currentTimeMillis();
                        logger.info("S03 REQUEST PARAMETERS: " + parametersToString(params));
                        if (httpClientUtil != null) {
                            response = httpClientUtil.URLGet(vcpServer, params, CHARACTER_ENCODING).get(0).toString();
                        } else {
                            response = HttpUtil.URLGet(vcpServer, params, CHARACTER_ENCODING).get(0).toString();
                        }
                        cost = System.currentTimeMillis() - startTime;
                        logger.info("S03 RESPONSE,耗时(ms):{},返回值{}", cost, response);
                        Integer responseCode = StringUtils.isNotEmpty(response) ? Integer.parseInt(response) : 0;

                        if (responseCode == Constants.SUCCESS_ONE) {
                            sent = 1;
                        }
                        batch = "";
                        count = 0;
                    }
                }
                if (StringUtils.isNotBlank(batch)) {
                    if (ProductConstants.PRODUCT_ID_C07.equalsIgnoreCase(sms.getProductId())) {
                        to = ComposePhone.getPhone(batch, Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.VIETNAM_2, CountryCode.VIETNAM_2);
                    }else if (ProductConstants.PRODUCT_ID_C31.equalsIgnoreCase(sms.getProductId())) {
                        to = ComposePhone.getPhone(batch, Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.JAPAN_2, CountryCode.JAPAN_2);
                    } else {
                        to = ComposePhone.getPhone(batch, Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.CHINA_2, CountryCode.CHINA_2);
                    }
                    params.put("to", to);
                    long startTime = System.currentTimeMillis();
                    logger.info("S03 REQUEST PARAMETERS: " + parametersToString(params));
                    if(httpClientUtil != null){
                        response = httpClientUtil.URLGet(vcpServer, params, Constants.SMS_CHARSET).get(0).toString();
                    }else{
                        response = HttpUtil.URLGet(vcpServer, params, Constants.SMS_CHARSET).get(0).toString();
                    }
                    cost = System.currentTimeMillis() - startTime;
                    logger.info("S03 RESPONSE,耗时(ms):{},返回值{}", cost, response);
                    Integer responseCode = StringUtils.isNotEmpty(response) ? Integer.parseInt(response) : 0;
                    if (responseCode == Constants.SUCCESS_ONE) {
                        sent = 1;
                    }
                }
            } else {
                String[] numbers = sms.getPhoneNumber().split(",");
                for (String number : numbers) {
                    if ((ProductConstants.PRODUCT_ID_C07.equalsIgnoreCase(sms.getProductId())) && !number.substring(0, 4).equals(CountryCode.VIETNAM_2)) {
                        number = CountryCode.VIETNAM_2 + number;
                    }else if ((ProductConstants.PRODUCT_ID_C31.equalsIgnoreCase(sms.getProductId())) && !number.substring(0, 4).equals(CountryCode.JAPAN_2)) {
                        number = CountryCode.JAPAN_2 + number;
                    } else if (!number.substring(0, 4).equals(Constants.AREA_CODE)) {
                        number = Constants.AREA_CODE + number;
                    }
                    params.put("to", number);
                    long startTime = System.currentTimeMillis();
                    logger.info("S03 REQUEST PARAMETERS: " + parametersToString(params));
                    if(httpClientUtil != null){
                        response = httpClientUtil.URLGet(vcpServer, params, Constants.SMS_CHARSET).get(0).toString();
                    }else{
                        response = HttpUtil.URLGet(vcpServer, params, Constants.SMS_CHARSET).get(0).toString();
                    }
                    cost = System.currentTimeMillis() - startTime;
                    logger.info("S03 RESPONSE,耗时(ms):{},返回值{}", cost, response);
                    Integer responseCode = StringUtils.isNotEmpty(response) ? Integer.parseInt(response) : 0;

                    if (responseCode == Constants.SUCCESS_ONE) {
                        sent = 1;
                    }
                }

            }

        } catch (Exception e) {
            logger.error("S03 SENDING ERROR: " + e.getMessage(), e);
        }

        logger.info(sendResultString(providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), response, cost, StringUtils.isNotEmpty(sms.getBatchId())?sms.getBatchId():sms.getContentId()));
        return sent;
    }

}
