package com.intech.sms.service;

import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.*;

import java.util.HashMap;
import java.util.Map;

/**
 * 
 * @author kaiser.dapar
 *
 */
@Deprecated
public class S04SendService extends AbstractSendService {

	public S04SendService() { }
	public S04SendService(Configuration config) {
		super(config);
	}

	@Override
	public int send(Sms sms) {
		logger.info("S04 ACCOUNT INFO: " + accountToString(null));

		int sent = 0;
		String responseCode = null;
		Long cost = null;
		try {
			HttpClientUtil httpClientUtil = getHttpClientUtil();
			Map<String, String> params = new HashMap<>(8);
			params.put("sendtime", StringUtils.EMPTY);
			params.put("postfixnumber", StringUtils.EMPTY);
			params.put("UserID", propertiesConfig.getS04UserId());
			params.put("Account", vcpUserId);
			params.put("Password", vcpPwd);
			params.put("Phones", ComposePhone.getPhone(sms.getPhoneNumber(), Constants.SEPARATOR, "", ""));
			params.put("Content", sms.getSendContent());
			params.put("SendType", "1");
			long startTime=System.currentTimeMillis();
			logger.info("S04 REQUEST PARAMETERS: " + parametersToString(params));
            String response;
            if (httpClientUtil != null) {
                response = httpClientUtil.doPostWithAgent(vcpServer, params);
            } else {
                response = HttpUtil.doPostWithAgent(vcpServer, params);
            }
            cost = System.currentTimeMillis() - startTime;
			logger.info("S04 RESPONSE,耗时(ms):{},返回值{}", cost,response);
			responseCode = evaluateResult(response, Constants.RESPONSE_CODE);
			logger.info("S04 RESPONSE CODE: " + responseCode);

			sent = responseCode.equals(Constants.SUCCESS_S04_S05)?1:0;
			
		} catch (Exception e) {
			logger.error("S04 SENDING ERROR: " + e.getMessage(), e);
		}

		logger.info(sendResultString(providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), responseCode, cost, StringUtils.isNotEmpty(sms.getBatchId())?sms.getBatchId():sms.getContentId()));
		return sent;
	}
	
}