package com.intech.sms.service;

import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.Constants;
import com.intech.sms.util.HttpClientUtil;
import com.intech.sms.util.HttpUtil;
import com.intech.sms.util.StringUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * 
 * @author kaiser.dapar
 *
 */
@Deprecated
public class S05SendService extends AbstractSendService {

	public S05SendService() { }
	public S05SendService(Configuration config) {
		super(config);
	}

	@Override
	public int send(Sms sms) {
		logger.info("S05 ACCOUNT INFO: " + accountToString(null));
		
		int sent = 0;
		String responseCode = null;
		Long cost = null;
		try {
			HttpClientUtil httpClientUtil = getHttpClientUtil();
			Map<String, String> params = new HashMap<>(8);
			params.put("sendtime", StringUtils.EMPTY);
			params.put("postfixnumber", StringUtils.EMPTY);
			params.put("UserID", propertiesConfig.getS05UserId());
			params.put("Account", vcpUserId);
			params.put("Password", vcpPwd);
			params.put("Phones", sms.getPhoneNumber().replaceAll(",",";"));
			params.put("Content", sms.getSendContent());
			params.put("SendType", "1");
			long startTime=System.currentTimeMillis();
			logger.info("S05 REQUEST PARAMETERS: " + parametersToString(params));
			String response;
			if (httpClientUtil != null) {
				response = httpClientUtil.doPostWithAgent(vcpServer, params);
			} else {
				response = HttpUtil.doPostWithAgent(vcpServer, params);
			}
			cost = System.currentTimeMillis() - startTime;
			logger.info("S05 RESPONSE,耗时(ms):{},返回值{}", cost,response);
			responseCode = evaluateResult(response, Constants.RESPONSE_CODE);
			logger.info("S05 RESPONSE CODE: " + responseCode);
			sent = responseCode.equals(Constants.SUCCESS_S04_S05)?1:0;
			
		} catch (Exception e) {
			logger.error("S05 SENDING ERROR: " + e.getMessage(), e);
		}
		logger.info(sendResultString(providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), responseCode, cost, StringUtils.isNotEmpty(sms.getBatchId())?sms.getBatchId():sms.getContentId()));
		return sent;
	}

}