package com.intech.sms.service;

import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.Constants;
import com.intech.sms.util.HttpClientUtil;
import com.intech.sms.util.HttpUtil;
import com.intech.sms.util.StringUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * @author kaiser.dapar
 */
@Deprecated
public class S06SendService extends AbstractSendService {

    public S06SendService() {
    }

    public S06SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        logger.info("S06 ACCOUNT INFO: " + accountToString(null));

        int sent = 0;
        String responseCode = null;
        Long cost = null;
        try {
            HttpClientUtil httpClientUtil = getHttpClientUtil();
            Map<String, String> params = new HashMap<>(8);
            params.put("userid", mainUserId);
            params.put("account", vcpUserId);
            params.put("password", vcpPwd);
            params.put("content", sms.getSendContent());
            params.put("mobile", sms.getPhoneNumber());
            params.put("checkcontent", Constants.CHECK_CONTENTS);
            params.put("action", Constants.ACTION);
            long startTime = System.currentTimeMillis();
            logger.info("S06 REQUEST PARAMETERS: " + parametersToString(params));
            String response;
            if (httpClientUtil != null) {
                response = httpClientUtil.doPostWithAgent(vcpServer, params);
            } else {
                response = HttpUtil.doPostWithAgent(vcpServer, params);
            }
            cost = System.currentTimeMillis() - startTime;
            logger.info("S06 RESPONSE,耗时(ms):{},返回值{}", cost, response);

            responseCode = evaluateResult(response, Constants.RESPONSE_STATUS);
            logger.info("S06 RESPONSE CODE: " + responseCode);

            sent = responseCode.toUpperCase().equals(Constants.SUCCESS) ? 1 : 0;

        } catch (Exception e) {
            logger.error("S06 SENDING ERROR: " + e.getMessage(), e);
        }
        logger.info(sendResultString(providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), responseCode, cost, StringUtils.isNotEmpty(sms.getBatchId())?sms.getBatchId():sms.getContentId()));
        return sent;
    }

}