package com.intech.sms.service;

import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/***
 * SMS System
 *
 * @author kimberly.flores
 * @since November 6, 2013
 * @version 1.0
 *
 */
@Deprecated
public class S07SendService extends AbstractSendService {

    private final String RESPONSE_CODE = "replyCode";
    private final String SUCCESS = "1";

    private final String DATA_TYPE = "xml";

    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");

    public S07SendService() {
    }

    public S07SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        logger.info("S07 ACCOUNT INFO: " + accountToString(null));

        int sent = 0;
        String responseCode = null;
        Long cost = null;
        try {
            HttpClientUtil httpClientUtil = getHttpClientUtil();
            if (!GenericValidationUtility.isNotEmpty(mainUserId)) {
                throw new Exception("Account Id must not be empty");
            } else if (!GenericValidationUtility.isNotEmpty(vcpUserId)) {
                throw new Exception("Account Name must not be empty");
            } else if (!GenericValidationUtility.isNotEmpty(vcpPwd)) {
                throw new Exception("Password must not be empty");
            } else if (!GenericValidationUtility.isNotEmpty(sms.getPhoneNumber())) {
                throw new Exception("Phone number must not be empty");
            } else if (!GenericValidationUtility.isNotEmpty(sms.getSendContent())) {
                throw new Exception("Content must not be empty");
            }

            Map<String, String> params = new HashMap<String, String>();
            params.put("accId", mainUserId);
            params.put("accName", vcpUserId);
            params.put("accPwd", Convert.MD5Encode(vcpPwd).toUpperCase());
            params.put("aimcodes", sms.getPhoneNumber());
            params.put("content", sms.getSendContent());
            params.put("bizId", dateFormat.format(new Date(System.currentTimeMillis())));
            params.put("dataType", DATA_TYPE);
            long startTime = System.currentTimeMillis();
            logger.info("S07 REQUEST PARAMETERS: " + parametersToString(params));
            String response;
            if (httpClientUtil != null) {
                response = httpClientUtil.doPostWithAgent(vcpServer, params);
            } else {
                response = HttpUtil.doPostWithAgent(vcpServer, params);
            }
            cost = System.currentTimeMillis() - startTime;
            logger.info("S07 RESPONSE,耗时(ms):{},返回值{}", cost, response.replaceAll("\n", "").replaceAll("\r", ""));
            responseCode = evaluateResult(response, RESPONSE_CODE);
            logger.info("S07 RESPONSE CODE: " + responseCode);

            sent = responseCode.equals(SUCCESS) ? 1 : 0;

        } catch (Exception e) {
            logger.error("S07 SENDING ERROR: " + e.getMessage(), e);
        }
        logger.info(sendResultString(providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), responseCode, cost, StringUtils.isNotEmpty(sms.getBatchId())?sms.getBatchId():sms.getContentId()));
        return sent;
    }

}
