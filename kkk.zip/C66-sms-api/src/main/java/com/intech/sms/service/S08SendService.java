package com.intech.sms.service;

import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.*;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

/***
 * SMS System
 *
 * @author kimberly.flores
 * @since November 6, 2013
 * @version 1.0
 *
 * SMSTYPE:
 * 	0 - a content corresponds to more than one number
 * 	1 - a number corresponds to a content
 * TIMERFLAG: 
 * 	0 - non-timed transmission
 * 	1 - scheduled to send
 * TIMERTYPE: 
 * 	1 - sent only once
 * 	2 - once a day
 * 	3 - once a week
 * 	4 - once a month
 * 	5 - once a year
 *
 */

@Deprecated
public class S08SendService extends AbstractSendService {

    private final String RESPONSE_CODE = "errorcode";
    private final String SUCCESS = "0";

    private final String FUNC = "sendsms";
    private final String SMSTYPE = "0";
    private final String TIMERFLAG = "1";
    private final String TIMERTYPE = "1";

    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");

    public S08SendService() {
    }

    public S08SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        logger.info("S08 ACCOUNT INFO: " + accountToString(null));

        int sent = 0;
        String responseCode = null;
        Long cost = null;
        try {
            HttpClientUtil httpClientUtil = getHttpClientUtil();
            if (!GenericValidationUtility.isNotEmpty(vcpUserId)) {
                throw new Exception("Username must not be empty");
            } else if (!GenericValidationUtility.isNotEmpty(vcpPwd)) {
                throw new Exception("Password must not be empty");
            } else if (!GenericValidationUtility.isNotEmpty(sms.getPhoneNumber())) {
                throw new Exception("Phone number must not be empty");
            } else if (!GenericValidationUtility.isNotEmpty(sms.getSendContent())) {
                throw new Exception("Message must not be empty");
            }

            Map<String, String> params = new HashMap<String, String>();
            params.put("username", vcpUserId);
            params.put("password", Convert.MD5Encode(vcpPwd));
            params.put("mobiles", sms.getPhoneNumber());
            params.put("message", sms.getSendContent());
            params.put("func", FUNC);
            params.put("smstype", SMSTYPE);
            params.put("timerflag", TIMERFLAG);
            params.put("timertype", TIMERTYPE);
            params.put("timervalue", dateFormat.format(System.currentTimeMillis()));
            long startTime = System.currentTimeMillis();
            logger.info("S08 REQUEST PARAMETERS: " + parametersToString(params));
            String response;
            if (httpClientUtil != null) {
                response = httpClientUtil.doPostWithAgent(vcpServer, params);
            } else {
                response = HttpUtil.doPostWithAgent(vcpServer, params);
            }
            cost = System.currentTimeMillis() - startTime;
            logger.info("S08 RESPONSE,耗时(ms):{},返回值{}", cost, response);
            responseCode = evaluateResult(response, RESPONSE_CODE);
            logger.info("S08 RESPONSE CODE: " + responseCode);
            sent = responseCode.equals(SUCCESS) ? 1 : 0;

        } catch (Exception e) {
            logger.error("S08 SENDING ERROR: " + e.getMessage(), e);
        }
        logger.info(sendResultString(providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), responseCode, cost, StringUtils.isNotEmpty(sms.getBatchId())?sms.getBatchId():sms.getContentId()));
        return sent;
    }

}
