package com.intech.sms.service;

import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.*;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

/***
 * SMS System
 *
 * @author kimberly.flores
 * @since November 6, 2013
 * @version 1.0
 *
 */
@Deprecated
public class S09SendService extends AbstractSendService {

    private final String RESPONSE_CODE = "result";
    private final String SUCCESS = "0";

    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmm");

    public S09SendService() {
    }

    public S09SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        logger.info("S09 ACCOUNT INFO: " + accountToString(null));

        int sent = 0;
        String responseCode = null;
        Long cost = null;
        try {
            HttpClientUtil httpClientUtil = getHttpClientUtil();
            if (!GenericValidationUtility.isNotEmpty(vcpUserId)) {
                throw new Exception("Account name must not be empty");
            } else if (!GenericValidationUtility.isNotEmpty(vcpPwd)) {
                throw new Exception("Password must not be empty");
            } else if (!GenericValidationUtility.isNotEmpty(sms.getPhoneNumber())) {
                throw new Exception("Phone number must not be empty");
            } else if (!GenericValidationUtility.isNotEmpty(sms.getSendContent())) {
                throw new Exception("Content must not be empty");
            }

            String message = "<?xml version='1.0' encoding='UTF-8'?>"
                    + "<message>"
                    + "<account>" + vcpUserId + "</account>"
                    + "<password>" + Convert.MD5Encode(vcpPwd).toLowerCase() + "</password>"
                    + "<msgid></msgid>"
                    + "<phones>" + sms.getPhoneNumber() + "</phones>"
                    + "<content>" + sms.getSendContent() + "</content>"
                    + "<sign></sign>"
                    + "<subcode></subcode>"
                    + "<sendtime>" + dateFormat.format(System.currentTimeMillis()) + "</sendtime>"
                    + "</message>";

            Map<String, String> params = new HashMap<String, String>();
            params.put("message", message);

            String logMessage = "<?xml version='1.0' encoding='UTF-8'?>"
                    + "<message>"
                    + "<account>" + vcpUserId + "</account>"
                    + "<password>" + Convert.MD5Encode(vcpPwd).toLowerCase() + "</password>"
                    + "<msgid></msgid>"
                    + "<phones> xxx </phones>"
                    + "<content>" + sms.getSendContent() + "</content>"
                    + "<sign></sign>"
                    + "<subcode></subcode>"
                    + "<sendtime>" + dateFormat.format(System.currentTimeMillis()) + "</sendtime>"
                    + "</message>";

            logger.info("S09 REQUEST PARAMETERS: " + logMessage);
            long startTime = System.currentTimeMillis();
            String response;
            if (httpClientUtil != null) {
                response = httpClientUtil.doPostWithAgent(vcpServer, params);
            } else {
                response = HttpUtil.doPostWithAgent(vcpServer, params);
            }
            cost = System.currentTimeMillis() - startTime;
            logger.info("S09 RESPONSE,耗时(ms):{},返回值{}", cost, response);
            responseCode = evaluateResult(response, RESPONSE_CODE);
            logger.info("S09 RESPONSE CODE: " + responseCode);

            sent = responseCode.equals(SUCCESS) ? 1 : 0;

        } catch (Exception e) {
            logger.error("S09 SENDING ERROR: " + e.getMessage(), e);
        }
        logger.info(sendResultString(providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), responseCode, cost, StringUtils.isNotEmpty(sms.getBatchId())?sms.getBatchId():sms.getContentId()));
        return sent;
    }

}
