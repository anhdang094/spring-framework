package com.intech.sms.service;

import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.HttpClientUtil;
import com.intech.sms.util.HttpUtil;
import com.intech.sms.util.StringUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * @author kaiser.dapar
 */
@Deprecated
public class S10SendService extends AbstractSendService {

    private final String RESPONSE_CODE = "returnstatus";
    private final String SUCCESS = "Success";

    private final String ACTION = "send";

    public S10SendService() {
    }

    public S10SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        logger.info("S10 ACCOUNT INFO: " + accountToString(null));

        int sent = 0;
        String responseCode = null;
        Long cost = null;
        try {
            HttpClientUtil httpClientUtil = getHttpClientUtil();
            Map<String, String> params = new HashMap<>(8);
            params.put("userid", mainUserId);
            params.put("account", vcpUserId);
            params.put("password", vcpPwd);
            params.put("mobile", sms.getPhoneNumber());
            params.put("content", sms.getSendContent());
            params.put("sendTime", "");
            params.put("action", ACTION);
            params.put("extno", "");
            long startTime = System.currentTimeMillis();
            logger.info("S10 REQUEST PARAMETERS: " + parametersToString(params));
            String response;
            if (httpClientUtil != null) {
                response = httpClientUtil.doPostWithAgent(vcpServer, params);
            } else {
                response = HttpUtil.doPostWithAgent(vcpServer, params);
            }
            cost = System.currentTimeMillis() - startTime;
            logger.info("S10 RESPONSE,耗时(ms):{},返回值{}", cost, response.replaceAll("\n", "").replaceAll("\r", ""));
            responseCode = evaluateResult(response, RESPONSE_CODE);
            logger.info("S10 RESPONSE CODE: " + responseCode);

            sent = responseCode.equals(SUCCESS) ? 1 : 0;

        } catch (Exception e) {
            logger.error("S10 SENDING ERROR: " + e.getMessage(), e);
        }

        logger.info(sendResultString(providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), responseCode, cost, StringUtils.isNotEmpty(sms.getBatchId())?sms.getBatchId():sms.getContentId()));
        return sent;
    }

}