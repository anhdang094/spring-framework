package com.intech.sms.service;

import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.*;
import org.apache.commons.codec.CharEncoding;

import java.util.HashMap;
import java.util.Map;

/**
 * @author kaiser.dapar
 */
@Deprecated
public class S12SendService extends AbstractSendService {

    private final String SUCCESS = "^(OK:)?\\d+$";

    private final String DELIMITER = ",";
    private static final String MTYPE_UNICODE = "OL";
    private static final String DR_YES = "Y";

    public S12SendService() {
    }

    public S12SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        logger.info("S12 ACCOUNT INFO: " + accountToString(CharEncoding.UTF_16));
        int sent = 0;
        String response = null;
        Long cost = null;
        try {
            HttpClientUtil httpClientUtil = getHttpClientUtil();
            String numbers;
            if (ProductConstants.PRODUCT_ID_C07.equalsIgnoreCase(sms.getProductId())) {
                numbers = ComposePhone.getPhone(sms.getPhoneNumber(), DELIMITER, CountryCode.VIETNAM_1, CountryCode.VIETNAM_1);
            }else if (ProductConstants.PRODUCT_ID_C31.equalsIgnoreCase(sms.getProductId())) {
                numbers = ComposePhone.getPhone(sms.getPhoneNumber(), DELIMITER, CountryCode.JAPAN_1, CountryCode.JAPAN_1);
            } else {
                numbers = ComposePhone.getPhone(sms.getPhoneNumber(), DELIMITER, CountryCode.CHINA_1, CountryCode.CHINA_1, CountryCode.MACAU_1, CountryCode.HONG_KONG_1, CountryCode.PHILIPPINES_1, CountryCode.CHINA_TAIWAN_1);
            }

            String content = Convert.stringToHex(sms.getSendContent(), CharEncoding.UTF_16);

            Map<String, String> params = new HashMap<String, String>();
            params.put("User", vcpUserId);
            params.put("passwd", vcpPwd);
            params.put("mobilenumber", numbers);
            params.put("message", content);
            params.put("sid", mainUserId);
            params.put("mtype", MTYPE_UNICODE);
            params.put("DR", DR_YES);
            long startTime = System.currentTimeMillis();
            logger.info("S12 REQUEST PARAMETERS: " + parametersToString(params));
            if (httpClientUtil != null) {
                response = httpClientUtil.doPostWithAgent(vcpServer, params);
            } else {
                response = HttpUtil.doPostWithAgent(vcpServer, params);
            }
            cost = System.currentTimeMillis() - startTime;
            logger.info("S12 RESPONSE,耗时(ms):{},返回值{}", cost, response.replaceAll("\n", "").replaceAll("\r", ""));

            sent = response.matches(SUCCESS) ? 1 : 0;
        } catch (Exception e) {
            logger.error("S12 SENDING ERROR: " + e.getMessage(), e);
        }
        logger.info(sendResultString(providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), response, cost, StringUtils.isNotEmpty(sms.getBatchId())?sms.getBatchId():sms.getContentId()));
        return sent;
    }
}
