package com.intech.sms.service;

import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.*;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class S13SendService extends AbstractSendService {
    private final int SUCCESS = 1;
    private final String DELIMITER = "|";

    public S13SendService() {
    }

    public S13SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        logger.info("S13 ACCOUNT INFO: " + accountToString(null));
        int sent = 0;
        String response = null;
        Long cost = null;
        try {
            HttpClientUtil httpClientUtil = getHttpClientUtil();
            Map<String, String> params = new HashMap<>(3);
            params.put("id", vcpUserId);
            params.put("msg", sms.getSendContent());
            List<Sms> batchList  = sms.getBatchList();
            if(CollectionUtils.isNotEmpty(batchList)){
                //遍历单发
                logger.info("{}不支持一次性提交多条短信,开始遍历单发",this.providerCode);
                String number = null;
                int index = 1;
                int successCount = 0;
                for (Sms smsTemp : batchList) {
                    int childSendFlag = 0;
                    try {
                        if (ProductConstants.PRODUCT_ID_C07.equalsIgnoreCase(sms.getProductId())) {
                            number = ComposePhone.getPhone(smsTemp.getPhoneNumber(), Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.VIETNAM_2, CountryCode.VIETNAM_2);
                        }else if (ProductConstants.PRODUCT_ID_C31.equalsIgnoreCase(sms.getProductId())) {
                            number = ComposePhone.getPhone(smsTemp.getPhoneNumber(), Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.JAPAN_2, CountryCode.JAPAN_2);
                        }else {
                            number = ComposePhone.getPhone(smsTemp.getPhoneNumber(), Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.CHINA_2, CountryCode.CHINA_2);
                        }
                        params.put("to", number);
                        params.put("msg", smsTemp.getSendContent());
                        long startTime = System.currentTimeMillis();
                        logger.info("{} REQUEST PARAMETERS{},第{}条",this.providerCode,parametersToString(params),index);
                        if (httpClientUtil != null) {
                            response = httpClientUtil.get(vcpServer + "?id=" + vcpUserId + "&to=" + number + "&msg=" + smsTemp.getSendContent());
                        } else {
                            response = HttpUtil.get(vcpServer + "?id=" + vcpUserId + "&to=" + number + "&msg=" + smsTemp.getSendContent());
                        }
                        cost = System.currentTimeMillis() - startTime;
                        logger.info("{} RESPONSE,耗时(ms):{},返回值{},第{}条", this.providerCode,cost, response,index);
                        if (StringUtils.isNotBlank(response)) {
                            int responseCode = Integer.parseInt(response);
                            childSendFlag = dealResult(responseCode);
                        }

                    }catch (Exception e){
                        logger.error(String.format("%s遍历单发提交批量短信失败,本次batchId:%s,index:%s将被更新为失败",this.providerCode,sms.getBatchId(),index),e);
                    }
                    if(1==childSendFlag){
                        successCount++;
                    }else{
                        //直接更新那一条失败  不再重试
                        updateSmsSendFailed(sms.getBatchId(),Convert.MD5Encode(smsTemp.getPhoneNumber()),sms.getCurrentSmsAccountId());
                    }
                    index++;
                }
                sent = successCount==batchList.size()?1:-2;

            }else {
                if (smsGroupFlag == 0) {
                    String to;

                    if (StringUtils.isNotEmpty(sms.getCountryCode())) {
                        to = ComposePhone.getPhone(sms.getPhoneNumber(), DELIMITER, sms.getCountryCode(), sms.getCountryCode());
                    } else {
                        to = ComposePhone.getPhone(sms.getPhoneNumber(), DELIMITER, CountryCode.CHINA_2, CountryCode.CHINA_2);
                    }
                    long startTime = System.currentTimeMillis();
                    params.put("to", to);
                    logger.info("S13 REQUEST PARAMETERS: " + parametersToString(params));
                    if (httpClientUtil != null) {
                        response = httpClientUtil.get(vcpServer + "?id=" + vcpUserId + "&to=" + to + "&msg=" + sms.getSendContent());
                    } else {
                        response = HttpUtil.get(vcpServer + "?id=" + vcpUserId + "&to=" + to + "&msg=" + sms.getSendContent());
                    }
                    cost = System.currentTimeMillis() - startTime;
                    logger.info("S13 RESPONSE,耗时(ms):{},返回值{}", cost, response.replaceAll("\n", "").replaceAll("\r", ""));
                    if (StringUtils.isNotBlank(response)) {
                        int responseCode = Integer.parseInt(response);
                        sent = dealResult(responseCode);
                    }
                } else {
                    String[] numbers = sms.getPhoneNumber().split(",");
                    for (String number : numbers) {
                        if (ProductConstants.PRODUCT_ID_C07.equalsIgnoreCase(sms.getProductId())) {
                            number = ComposePhone.getPhone(number, Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.VIETNAM_2, CountryCode.VIETNAM_2);
                        } else if (ProductConstants.PRODUCT_ID_C31.equalsIgnoreCase(sms.getProductId())) {
                            number = ComposePhone.getPhone(number, Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.JAPAN_2, CountryCode.JAPAN_2);
                        } else {
                            number = ComposePhone.getPhone(number, Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.CHINA_2, CountryCode.CHINA_2);
                        }                        params.put("to", number);
                        long startTime = System.currentTimeMillis();
                        logger.info("S13 REQUEST PARAMETERS: " + parametersToString(params));
                        if (httpClientUtil != null) {
                            response = httpClientUtil.get(vcpServer + "?id=" + vcpUserId + "&to=" + number + "&msg=" + sms.getSendContent());
                        } else {
                            response = HttpUtil.get(vcpServer + "?id=" + vcpUserId + "&to=" + number + "&msg=" + sms.getSendContent());
                        }
                        cost = System.currentTimeMillis() - startTime;
                        logger.info("S13 RESPONSE,耗时(ms):{},返回值{}", cost, response.replaceAll("\n", "").replaceAll("\r", ""));
                        if (StringUtils.isNotBlank(response)) {
                            int responseCode = Integer.parseInt(response);
                            sent = dealResult(responseCode);
                        }
                    }

                }
            }
        } catch (Exception e) {
            logger.error("S13 SENDING ERROR: " + e.getMessage(), e);
        }
        logger.info(sendResultString(providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), response, cost, StringUtils.isNotEmpty(sms.getBatchId())?sms.getBatchId():sms.getContentId()));
        return sent;
    }

    private int dealResult(int responseCode) {
        switch (responseCode) {
            case 0:
                logger.info("S13 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!参数不正确!!!!!!!!!!!!!!!!!!!!!!!");
                return -1;
            case 1:
                //成功
                return 1;
            case 2:
                logger.info("S13 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!无此账户!!!!!!!!!!!!!!!!!!!!!!!");
                return -1;
            case 3:
                logger.info("S13 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!账户未激活!!!!!!!!!!!!!!!!!!!!!!!");
                return -1;
            case 4:
                logger.info("S13 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!账户余额不足!!!!!!!!!!!!!!!!!!!!!!!");
                return -1;
            case 5:
                logger.info("S13 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!非法请求!!!!!!!!!!!!!!!!!!!!!!!");
                return -1;
            case 6:
                logger.info("S13 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!号码无效!!!!!!!!!!!!!!!!!!!!!!!");
                return -1;
            case 7:
                logger.info("S13 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!预约超时!!!!!!!!!!!!!!!!!!!!!!!");
                return -1;
            case 8:
                logger.info("S13 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!账户不支持群发!!!!!!!!!!!!!!!!!!!!!!!");
                return -1;
            default:
                logger.info("S13 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!短信接口方异常!!!!!!!!!!!!!!!!!!!!!!!");
                return -1;
        }
    }
}