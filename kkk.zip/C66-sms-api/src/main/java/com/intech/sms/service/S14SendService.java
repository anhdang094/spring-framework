package com.intech.sms.service;

import com.alibaba.fastjson.JSONObject;
import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import org.apache.commons.lang3.StringUtils;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Map.Entry;
import java.util.zip.GZIPInputStream;

/**
 * SMS验证码
 *
 * @author Smile
 */
@Deprecated
public class S14SendService extends AbstractSendService {
    private final int SUCCESS = 0;
    private static final String CHARSET_UTF8 = "utf-8";
    private static final String SMS_TYPE = "normal";
    private static final String CONTENT_ENCODING_GZIP = "gzip";


    public S14SendService() {
    }

    public S14SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        logger.info("S14 ACCOUNT INFO: " + accountToString(null));
        int sent = 0;
        String code = null;
        Long cost = null;
        SimpleDateFormat dategmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        dategmt.setTimeZone(TimeZone.getTimeZone("GMT+8"));
        try {
            Map<String, String> params = new HashMap<>(14);
            //公用参数
            params.put("method", propertiesConfig.getS14Method());
            params.put("app_key", propertiesConfig.getS14AppKey());
            params.put("timestamp", dategmt.format(new Date()));
            params.put("format", propertiesConfig.getS14Format());
            params.put("v", propertiesConfig.getS14Version());
            params.put("simplify", "true");
            params.put("sign_method", propertiesConfig.getS14SignMethod());
            params.put("extend", vcpUserId);
            params.put("sms_type", SMS_TYPE);
            params.put("sms_free_sign_name", "环亚娱乐");
            params.put("sms_param", getJsonParam(sms.getSendContent()));
            params.put("rec_num", sms.getPhoneNumber());
            params.put("sms_template_code", propertiesConfig.getS14TemplateCode());
            params.put("sign", signTopRequest(params, propertiesConfig.getS14AppSecret(), propertiesConfig.getS14SignMethod()));
            String result = null;
            long startTime = System.currentTimeMillis();
            logger.info("S14 REQUEST PARAMETERS: " + parametersToString(params));
            String response = callApi(new URL(vcpServer), params);
            JSONObject baseJsonObject = null;
            if (response.length() != 0) {
                baseJsonObject = JSONObject.parseObject(response);
                result = baseJsonObject.getString("result");
            }
            if (StringUtils.isNotEmpty(result)) {
                code = JSONObject.parseObject(result).getString("err_code");
            }
            cost = System.currentTimeMillis() - startTime;
            logger.info("S14 RESPONSE,耗时(ms):{},返回值{}", cost, response);
            Integer responseCode = StringUtils.isNotEmpty(code) ? Integer.parseInt(code) : 0;
            logger.info("S14 RESPONSE CODE: " + responseCode);
            sent = responseCode.equals(SUCCESS) ? 1 : 0;
        } catch (Exception e) {
            logger.error("S14 SENDING ERROR: " + e.getMessage(), e);
        }
        logger.info(sendResultString(providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), code, cost, StringUtils.isNotEmpty(sms.getBatchId())?sms.getBatchId():sms.getContentId()));
        return sent;
    }

    private static String getJsonParam(String context) {
        StringBuffer s = new StringBuffer();
        s.append("{\"number\":\"");
        s.append(context);
        s.append("\"}");
        return s.toString();
    }

    /**
     * 对TOP请求进行签名。
     */
    private String signTopRequest(Map<String, String> params, String secret, String signMethod) throws IOException {
        // 第一步：检查参数是否已经排序
        String[] keys = params.keySet().toArray(new String[0]);
        Arrays.sort(keys);

        // 第二步：把所有参数名和参数值串在一起
        StringBuilder query = new StringBuilder();
        if (propertiesConfig.getS14SignMethod().equals(signMethod)) {
            query.append(secret);
        }
        for (String key : keys) {
            String value = params.get(key);
            if (isNotEmpty(key) && isNotEmpty(value)) {
                query.append(key).append(value);
            }
        }

        // 第三步：使用MD5加密
        byte[] bytes;
        query.append(secret);
        bytes = encryptMD5(query.toString());


        // 第四步：把二进制转化为大写的十六进制
        return byte2hex(bytes);
    }

    /**
     * 对字符串采用UTF-8编码后，用MD5进行摘要。
     */
    private static byte[] encryptMD5(String data) throws IOException {
        return encryptMD5(data.getBytes(CHARSET_UTF8));
    }

    /**
     * 对字节流进行MD5摘要。
     */
    private static byte[] encryptMD5(byte[] data) throws IOException {
        byte[] bytes = null;
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            bytes = md.digest(data);
        } catch (GeneralSecurityException gse) {
            throw new IOException(gse.toString());
        }
        return bytes;
    }

    /**
     * 把字节流转换为十六进制表示方式。
     */
    private static String byte2hex(byte[] bytes) {
        StringBuilder sign = new StringBuilder();
        for (int i = 0; i < bytes.length; i++) {
            String hex = Integer.toHexString(bytes[i] & 0xFF);
            if (hex.length() == 1) {
                sign.append("0");
            }
            sign.append(hex.toUpperCase());
        }
        return sign.toString();
    }

    private static boolean isNotEmpty(String value) {
        int strLen;
        if (value == null || (strLen = value.length()) == 0) {
            return false;
        }
        for (int i = 0; i < strLen; i++) {
            if ((Character.isWhitespace(value.charAt(i)) == false)) {
                return true;
            }
        }
        return false;
    }

    private static String callApi(URL url, Map<String, String> params) throws IOException {
        String query = buildQuery(params, CHARSET_UTF8);
        byte[] content = {};
        if (query != null) {
            content = query.getBytes(CHARSET_UTF8);
        }

        HttpURLConnection conn = null;
        OutputStream out = null;
        String rsp = null;
        try {
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoInput(true);
            conn.setDoOutput(true);
            conn.setRequestProperty("Host", url.getHost());
            conn.setRequestProperty("Accept", "text/xml,text/javascript");
            conn.setRequestProperty("User-Agent", "top-sdk-java");
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded;charset=" + CHARSET_UTF8);
            out = conn.getOutputStream();
            out.write(content);
            rsp = getResponseAsString(conn);
        } finally {
            if (out != null) {
                out.close();
            }
            if (conn != null) {
                conn.disconnect();
            }
        }

        return rsp;
    }

    private static String buildQuery(Map<String, String> params, String charset) throws IOException {
        if (params == null || params.isEmpty()) {
            return null;
        }

        StringBuilder query = new StringBuilder();
        Set<Entry<String, String>> entries = params.entrySet();
        boolean hasParam = false;

        for (Entry<String, String> entry : entries) {
            String name = entry.getKey();
            String value = entry.getValue();
            // 忽略参数名或参数值为空的参数
            if (isNotEmpty(name) && isNotEmpty(value)) {
                if (hasParam) {
                    query.append("&");
                } else {
                    hasParam = true;
                }

                query.append(name).append("=").append(URLEncoder.encode(value, charset));
            }
        }

        return query.toString();
    }

    private static String getResponseAsString(HttpURLConnection conn) throws IOException {
        String charset = getResponseCharset(conn.getContentType());
        if (conn.getResponseCode() < 400) {
            String contentEncoding = conn.getContentEncoding();
            if (CONTENT_ENCODING_GZIP.equalsIgnoreCase(contentEncoding)) {
                return getStreamAsString(new GZIPInputStream(conn.getInputStream()), charset);
            } else {
                return getStreamAsString(conn.getInputStream(), charset);
            }
        } else {// Client Error 4xx and Server Error 5xx
            throw new IOException(conn.getResponseCode() + " " + conn.getResponseMessage());
        }
    }

    private static String getResponseCharset(String ctype) {
        String charset = CHARSET_UTF8;

        if (isNotEmpty(ctype)) {
            String[] params = ctype.split(";");
            for (String param : params) {
                param = param.trim();
                if (param.startsWith("charset")) {
                    String[] pair = param.split("=", 2);
                    if (pair.length == 2) {
                        if (isNotEmpty(pair[1])) {
                            charset = pair[1].trim();
                        }
                    }
                    break;
                }
            }
        }

        return charset;
    }

    private static String getStreamAsString(InputStream stream, String charset) throws IOException {
        try {
            Reader reader = new InputStreamReader(stream, charset);
            StringBuilder response = new StringBuilder();

            final char[] buff = new char[1024];
            int read = 0;
            while ((read = reader.read(buff)) > 0) {
                response.append(buff, 0, read);
            }

            return response.toString();
        } finally {
            if (stream != null) {
                stream.close();
            }
        }
    }
}