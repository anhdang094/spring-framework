package com.intech.sms.service;

import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.ComposePhone;
import com.intech.sms.util.Convert;
import com.intech.sms.util.HttpClientUtil;
import com.intech.sms.util.HttpUtil;
import org.apache.commons.lang3.StringUtils;

import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

public class S15SendService extends AbstractSendService {
    private final int SUCCESS = 100;
    private final int BATCH_SIZE = 50;
    private final String DELIMITER = ",";

    public S15SendService() {
    }

    public S15SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        logger.info("S15 ACCOUNT INFO: " + accountToString(CHARACTER_ENCODING));
        int sent = 0;
        String response = null;
        Long cost = null;
        try {
            HttpClientUtil httpClientUtil = getHttpClientUtil();
            Map<String, String> params = new HashMap<>(7);
            params.put("ac", "send");
            params.put("uid", vcpUserId);
            params.put("pwd", Convert.MD5Encode(vcpPwd));
            params.put("content", URLEncoder.encode(sms.getSendContent(), CHARACTER_ENCODING));
            params.put("encode", "utf8");
            String to = "";
            if (smsGroupFlag == 0) {
                String batch = null;
                int count = 0;
                String[] numbers = sms.getPhoneNumber().split(",");
                for (String number : numbers) {
                    if (count == 0) {
                        batch = number;
                    } else {
                        batch += "," + number;
                    }
                    count++;
                    if (count >= BATCH_SIZE) {
                        to = ComposePhone.getPhone(batch, DELIMITER, "");
                        params.put("mobile", to);
                        long startTime = System.currentTimeMillis();
                        logger.info("S15 REQUEST PARAMETERS: " + parametersToString(params));
                        if (httpClientUtil != null) {
                            response = httpClientUtil.URLGet(vcpServer, params, CHARACTER_ENCODING).get(0).toString();
                        } else {
                            response = HttpUtil.URLGet(vcpServer, params, CHARACTER_ENCODING).get(0).toString();
                        }
                        cost = System.currentTimeMillis() - startTime;
                        logger.info("S15 RESPONSE,耗时(ms):{},返回值{}", cost, response);
                        Integer responseCode = StringUtils.isNotEmpty(response) ? Integer.parseInt(response) : 0;
                        logger.info("S15 RESPONSE CODE: " + responseCode);

                        if (responseCode == SUCCESS) {
                            sent = 1;
                        }
                        batch = "";
                        count = 0;
                    }
                }
                if (StringUtils.isNotBlank(batch)) {
                    to = ComposePhone.getPhone(batch, DELIMITER, "");
                    params.put("mobile", to);
                    long startTime = System.currentTimeMillis();
                    logger.info("S15 REQUEST PARAMETERS: " + parametersToString(params));
                    if (httpClientUtil != null) {
                        response = httpClientUtil.URLGet(vcpServer, params, CHARACTER_ENCODING).get(0).toString();
                    } else {
                        response = HttpUtil.URLGet(vcpServer, params, CHARACTER_ENCODING).get(0).toString();
                    }
                    cost = System.currentTimeMillis() - startTime;
                    logger.info("S15 RESPONSE,耗时(ms):{},返回值{}", cost, response);
                    Integer responseCode = StringUtils.isNotEmpty(response) ? Integer.parseInt(response) : 0;
                    logger.info("S15 RESPONSE CODE: " + responseCode);
                    if (responseCode == SUCCESS) {
                        sent = 1;
                    }
                }
            } else {
                String[] numbers = sms.getPhoneNumber().split(",");
                for (String number : numbers) {
                    params.put("mobile", number);
                    long startTime = System.currentTimeMillis();
                    logger.info("S15 REQUEST PARAMETERS: " + parametersToString(params));
                    if (httpClientUtil != null) {
                        response = httpClientUtil.URLGet(vcpServer, params, CHARACTER_ENCODING).get(0).toString();
                    } else {
                        response = HttpUtil.URLGet(vcpServer, params, CHARACTER_ENCODING).get(0).toString();
                    }
                    cost = System.currentTimeMillis() - startTime;
                    logger.info("S15 RESPONSE,耗时(ms):{},返回值{}", cost, response);
                    Integer responseCode = StringUtils.isNotEmpty(response) ? Integer.parseInt(response) : 0;
                    logger.info("S15 RESPONSE CODE: " + responseCode);
                    if (responseCode == SUCCESS) {
                        sent = 1;
                    }
                }
            }
        } catch (Exception e) {
            logger.error("S15 SENDING ERROR: " + e.getMessage(), e);
        }
        logger.info(sendResultString(providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), response, cost, StringUtils.isNotEmpty(sms.getBatchId())?sms.getBatchId():sms.getContentId()));
        return sent;
    }

}
