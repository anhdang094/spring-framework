package com.intech.sms.service;

import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.StringUtils;
import com.shcm.bean.SendResultBean;
import com.shcm.send.DataApi;
import com.shcm.send.OpenApi;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Deprecated
public class S16SendService extends AbstractSendService {

    public S16SendService() {
    }

    public S16SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        logger.info("S16 ACCOUNT INFO: " + accountToString(CHARACTER_ENCODING));

        int sent = 0;
        String responseCode = null;
        Long cost = null;
        try {
            OpenApi.initialzeAccount(vcpServer, vcpUserId, vcpPwd, 7225, 0);
            DataApi.initialzeAccount("http://smsapi.c123.cn/DataPlatform/DataApi", vcpUserId, vcpPwd);
            Map<String, String> params = new HashMap<>(5);
            params.put("sAccount", vcpUserId);
            params.put("sAuthKey", vcpPwd);
            params.put("content", sms.getSendContent());
            params.put("cgid", "7225");
            params.put("csid", "0");
            if (smsGroupFlag == 0) {
                String[] numbers = sms.getPhoneNumber().split(",");
                params.put("mobile", sms.getPhoneNumber());
                long startTime = System.currentTimeMillis();
                logger.info("S16 REQUEST PARAMETERS: " + parametersToString(params));
                List<SendResultBean> listItem = OpenApi.sendOnce(numbers, sms.getSendContent(), 7225, 0, null);
                if (CollectionUtils.isNotEmpty(listItem)) {
                    cost = System.currentTimeMillis() - startTime;
                    logger.info("{} RESPONSE,耗时(ms):{},返回值{}", providerCode, cost, ReflectionToStringBuilder.toString(listItem));
                    for (SendResultBean t : listItem) {
                        responseCode = String.valueOf(t.getResult());
                        if (t.getResult() < 1) {
                            logger.info("S16 RESPONSE: FAILED " + t.getErrMsg());
                        } else {
                            sent = 1;
                            logger.info("S16 RESPONSE: SUCCESS " + "发送成功: 消息编号<" + t.getMsgId() + "> 总数<" + t.getTotal() + "> 余额<" + t.getRemain() + ">");
                        }
                    }
                } else {
                    logger.info("{} RESPONSE,耗时(ms):{}, RESPONSE: FAILED WITH EMPTY RESPONSE", providerCode, System.currentTimeMillis() - startTime);
                }
            } else {
                String[] numbers = sms.getPhoneNumber().split(",");
                for (String number : numbers) {
                    params.put("mobile", number);
                    long startTime = System.currentTimeMillis();
                    logger.info("S16 REQUEST PARAMETERS: " + parametersToString(params));
                    List<SendResultBean> listItem = OpenApi.sendOnce(number, sms.getSendContent(), 7225, 0, null);
                    if (CollectionUtils.isNotEmpty(listItem)) {
                        cost = System.currentTimeMillis() - startTime;
                        logger.info("{} RESPONSE,耗时(ms):{},返回值{}", providerCode, cost, ReflectionToStringBuilder.toString(listItem));
                        for (SendResultBean t : listItem) {
                            responseCode = String.valueOf(t.getResult());
                            if (t.getResult() < 1) {
                                logger.info("S16 RESPONSE: FAILED " + t.getErrMsg());
                            } else {
                                sent = 1;
                                logger.info("S16 RESPONSE: SUCCESS " + "发送成功: 消息编号<" + t.getMsgId() + "> 总数<" + t.getTotal() + "> 余额<" + t.getRemain() + ">");
                            }
                        }
                    } else {
                        logger.info("{} RESPONSE,耗时(ms):{}, RESPONSE: FAILED WITH EMPTY RESPONSE", providerCode, System.currentTimeMillis() - startTime);
                    }
                }

            }
        } catch (Exception e) {
            logger.error("S16 SENDING ERROR: " + e.getMessage(), e);
        }
        logger.info(sendResultString(providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), responseCode, cost, StringUtils.isNotEmpty(sms.getBatchId())?sms.getBatchId():sms.getContentId()));
        return sent;
    }
}
