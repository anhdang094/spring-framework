package com.intech.sms.service;

import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.*;
import org.apache.commons.collections.CollectionUtils;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import java.util.List;

//esms vietnam

public class S17SendService extends AbstractSendService {
    private final String SUCCESS = "100";
    private final String AREA_CODE = "+84";

    public S17SendService() {
    }

    public S17SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        logger.info("S17 ACCOUNT INFO: " + accountToString(CHARACTER_ENCODING));
        int sent = 0;
        String responseCode = null;
        Long cost = null;
        try {
            List<Sms> batchList  = sms.getBatchList();
            if(CollectionUtils.isNotEmpty(batchList)){
                //遍历单发
                logger.info("{}不支持一次性提交多条短信,开始遍历单发",this.providerCode);
                int index = 1;
                int successCount = 0;
                for (Sms smsTemp : batchList) {
                    int childSendFlag = 0;
                    try {
                        childSendFlag = send(smsTemp.getPhoneNumber(),sms.getSendContent());
                    }catch (Exception e){
                        logger.error(String.format("%s遍历单发提交批量短信失败,本次batchId:%s,index:%s将被更新为失败",this.providerCode,sms.getBatchId(),index),e);
                    }
                    if(1==childSendFlag){
                        successCount++;
                    }else{
                        //直接更新那一条失败  不再重试
                        updateSmsSendFailed(sms.getBatchId(),Convert.MD5Encode(smsTemp.getPhoneNumber()),sms.getCurrentSmsAccountId());
                    }
                    index++;
                }
                sent = successCount==batchList.size()?1:-2;

            }else {
                sent = send(sms.getPhoneNumber(),sms.getSendContent());
            }
        } catch (Exception e) {
            logger.error("S17 SENDING ERROR: " + e.getMessage(), e);
        }
        logger.info(sendResultString(providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), responseCode, cost, StringUtils.isNotEmpty(sms.getBatchId())?sms.getBatchId():sms.getContentId()));
        return sent;
    }

    private int send(String phones,String content) throws Exception{
        int sent = 0;
        String responseCode = null;
        Long cost = null;
        HttpClientUtil httpClientUtil = getHttpClientUtil();
        String[] numbers = phones.split(",");
        StringBuilder sb = new StringBuilder();
        sb.append("<RQST>");
        //api key
        sb.append("<APIKEY>" + vcpUserId + "</APIKEY>");
        //secretkey
        sb.append("<SECRETKEY>" + vcpPwd + "</SECRETKEY>");
        sb.append("<ISFLASH>0</ISFLASH>");
        if (mainUserId != null) {
            if (mainUserId.equalsIgnoreCase("Verify")) {
                sb.append("<SMSTYPE>" + "8" + "</SMSTYPE>");
            } else if (mainUserId.equalsIgnoreCase("Notify")) {
                sb.append("<SMSTYPE>" + "4" + "</SMSTYPE>");
            }
        } else {
            logger.error("S17 failed. MainUserId not found. (Notify or Verify)");
            return sent;
        }

        sb.append("<CONTENT>" + content + "</CONTENT>");
        sb.append("<CONTACTS>");

        for (String phone : numbers) {
            sb.append("<CUSTOMER><PHONE>" + AREA_CODE + phone);
            sb.append("</PHONE></CUSTOMER>");
        }
        sb.append("</CONTACTS></RQST>");
        long startTime = System.currentTimeMillis();
        String result;
        if (httpClientUtil != null) {
            result = httpClientUtil.postXml(vcpServer, sb.toString());
        } else {
            result = HttpUtil.postXml(vcpServer, sb.toString());
        }
        cost = System.currentTimeMillis() - startTime;
        logger.info("S17 RESPONSE,耗时(ms):{},返回值{}", cost, result);
        Document doc = DocumentHelper.parseText(result);
        Element root = doc.getRootElement();
        if(root != null){
            responseCode = root.element("CodeResult").getText();
        }
        if (SUCCESS.equals(responseCode)) {
            logger.info("S17 发送 成功");
            sent = 1;
        } else {
            logger.info("S17 发送 失败");
            sent = 0;
        }

         return sent;
    }
}