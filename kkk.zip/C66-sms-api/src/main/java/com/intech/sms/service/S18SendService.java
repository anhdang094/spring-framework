package com.intech.sms.service;

import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.HttpClientUtil;
import com.intech.sms.util.HttpUtil;
import org.apache.commons.lang3.StringUtils;

import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;
@Deprecated
public class S18SendService extends AbstractSendService {
    private static final String SUCCESS = "0";

    public S18SendService() {
    }

    public S18SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        logger.info("S18 ACCOUNT INFO: " + accountToString(CHARACTER_ENCODING));
        int sent = 0;
        String response = null;
        Long cost = null;
        try {
            HttpClientUtil httpClientUtil = getHttpClientUtil();
            String[] numbers = sms.getPhoneNumber().split(",");

            for (String phone : numbers) {
                Map<String, String> params = new HashMap<>(2);
                params.put("phone", phone);
                params.put("message", URLEncoder.encode(sms.getSendContent(), "UTF-8"));
                long startTime=System.currentTimeMillis();
                if (httpClientUtil != null) {
                    response = httpClientUtil.post(vcpServer + "/sendSMS.htm", params);
                } else {
                    response = HttpUtil.post(vcpServer + "/sendSMS.htm", params);
                }
                cost = System.currentTimeMillis() - startTime;
                logger.info("S18 RESPONSE,耗时(ms):{},返回值{}", cost,response);
                if(StringUtils.isNotEmpty(response) && response.trim().equalsIgnoreCase(SUCCESS)){
                    sent =1;
                }
            }
            logger.info("S18 发送成功");
        } catch (Exception e) {
            logger.error("S18 SENDING ERROR: " + e.getMessage(), e);
        }
        logger.info(sendResultString(providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), response, cost, StringUtils.isNotEmpty(sms.getBatchId())?sms.getBatchId():sms.getContentId()));
        return sent;
    }
}
