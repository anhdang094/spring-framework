package com.intech.sms.service;

import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.HttpClientUtil;
import com.intech.sms.util.HttpUtil;
import com.intech.sms.util.StringUtils;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

@Deprecated
public class S19SendService extends AbstractSendService {
    public S19SendService() {
    }

    public S19SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        logger.info("S19 ACCOUNT INFO: " + accountToString(CHARACTER_ENCODING));
        int sent = 0;
        String response = null;
        Long cost = null;
        try {
            HttpClientUtil httpClientUtil = getHttpClientUtil();
            String[] numbers = sms.getPhoneNumber().split(",");
            for (String phone : numbers) {
                long startTime = System.currentTimeMillis();
                StringBuilder sb = new StringBuilder();
                sb.append(vcpServer);
                sb.append("username=").append(URLEncoder.encode(vcpUserId, "UTF-8")).append("&");
                sb.append("password=").append(URLEncoder.encode(vcpPwd, "UTF-8")).append("&");
                sb.append("destination=").append(phone).append("&");
                sb.append("text=").append(URLEncoder.encode(sms.getSendContent(), "UTF-8"));

                Map<String, String> params = new HashMap<>(4);
                params.put("username", URLEncoder.encode(vcpUserId, "UTF-8"));
                params.put("password", URLEncoder.encode(vcpPwd, "UTF-8"));
                params.put("destination", phone);
                params.put("text", URLEncoder.encode(sms.getSendContent(), "UTF-8"));

                logger.info("S19 request: " + parametersToString(params));
                if (httpClientUtil != null) {
                    response = httpClientUtil.get(sb.toString());
                } else {
                    response = HttpUtil.get(sb.toString());
                }
                cost = System.currentTimeMillis() - startTime;
                logger.info("S19 RESPONSE,耗时(ms):{},返回值{}", cost, response);
                if (response.startsWith("0")) {
                    logger.info("S19 发送成功");
                    sent = 1;
                } else {
                    logger.info("S19 发送失败");
                }
            }
        } catch (Exception e) {
            logger.error("S19 SENDING ERROR: " + e.getMessage(), e);
        }
        logger.info(sendResultString(providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), response, cost, StringUtils.isNotEmpty(sms.getBatchId())?sms.getBatchId():sms.getContentId()));
        return sent;
    }

    private static String encodeUCS2(String s) {

        byte[] bytes;
        try {
            bytes = s.getBytes("UTF-16LE");
            StringBuilder sb = new StringBuilder();

            for (byte b : bytes) {
                sb.append(String.format("%02X", b));
            }
            return sb.toString();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        return null;

    }
}
