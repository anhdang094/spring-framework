package com.intech.sms.service;

import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.HttpClientUtil;
import com.intech.sms.util.HttpUtil;
import org.apache.commons.lang3.StringUtils;

import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

@Deprecated
public class S20SendService extends AbstractSendService {

    public S20SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        logger.info("S20 ACCOUNT INFO: " + accountToString(CHARACTER_ENCODING));
        int sent = 0;
        String response = null;
        Long cost = null;
        try {
            HttpClientUtil httpClientUtil = getHttpClientUtil();
            String[] numbers = sms.getPhoneNumber().split(",");

            for (String phone : numbers) {

                if (StringUtils.isNotEmpty(sms.getCountryCode())) {
                    phone = sms.getCountryCode().concat(phone);
                }
                long startTime=System.currentTimeMillis();

                StringBuilder sb = new StringBuilder();
                sb.append(vcpServer);
                sb.append("username=" + URLEncoder.encode(vcpUserId, "UTF-8") + "&");
                sb.append("password=" + URLEncoder.encode(vcpPwd, "UTF-8") + "&");
                sb.append("from=" + URLEncoder.encode(mainUserId, "UTF-8") + "&");
                sb.append("to=" + phone + "&");
                sb.append("text=" + URLEncoder.encode(sms.getSendContent(), "UTF-8") + "&");
                sb.append("charset=UTF-8&coding=2");

                Map<String, String> params = new HashMap<>(4);
                params.put("username", URLEncoder.encode(vcpUserId, "UTF-8"));
                params.put("password", URLEncoder.encode(vcpPwd, "UTF-8"));
                params.put("from", URLEncoder.encode(mainUserId, "UTF-8"));
                params.put("to", phone);
                params.put("text", URLEncoder.encode(sms.getSendContent(), "UTF-8"));
                params.put("charset", "UTF-8");
                params.put("coding", "2");

                logger.info("S20 request: " + parametersToString(params));
                if (httpClientUtil != null) {
                    response = httpClientUtil.get(sb.toString());
                } else {
                    response = HttpUtil.get(sb.toString());
                }
                cost = System.currentTimeMillis() - startTime;
                logger.info("S20 RESPONSE,耗时(ms):{},返回值{}", cost,response);

                if (StringUtils.isNotBlank(response)) {
                    logger.info("S20 发送成功");
                    sent = 1;
                } else {
                    logger.info("S20 发送失败: " + response);
                }
            }
        } catch (Exception e) {
            logger.error("S20 SENDING ERROR: " + e.getMessage(), e);
        }
        logger.info(sendResultString(providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), response, cost, StringUtils.isNotEmpty(sms.getBatchId())?sms.getBatchId():sms.getContentId()));
        return sent;
    }


}
