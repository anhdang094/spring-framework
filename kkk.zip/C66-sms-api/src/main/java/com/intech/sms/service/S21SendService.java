package com.intech.sms.service;

import com.alibaba.fastjson.JSON;
import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.*;
import org.apache.commons.collections.CollectionUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class S21SendService extends AbstractSendService {

    public S21SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        logger.info("S21 ACCOUNT INFO: " + accountToString(CHARACTER_ENCODING));
        int sent = 0;
        String response = null;
        Long cost = null;
        try {
            HttpClientUtil httpClientUtil = getHttpClientUtil();
            Map<String, String> params = new HashMap<>(6);
            params.put("account", vcpUserId);
            params.put("pswd", vcpPwd);
            params.put("mobile", sms.getPhoneNumber());
            params.put("msg", sms.getSendContent());
            params.put("needstatus", "true");
            params.put("resptype", "json");
            List<Sms> batchList  = sms.getBatchList();
            if(CollectionUtils.isNotEmpty(batchList)){
                //遍历单发
                logger.info("{}不支持一次性提交多条短信,开始遍历单发",this.providerCode);
                int index = 1;
                int successCount = 0;
                for (Sms smsTemp : batchList) {
                    int childSendFlag = 0;
                    try {
                        params.put("mobile", smsTemp.getPhoneNumber());
                        params.put("msg", smsTemp.getSendContent());
                        long startTime = System.currentTimeMillis();
                        logger.info("{} REQUEST PARAMETERS{},第{}条",this.providerCode,parametersToString(params),index);
                        if (httpClientUtil != null) {
                            response = httpClientUtil.post(vcpServer, params);
                        } else {
                            response = HttpUtil.post(vcpServer, params);
                        }
                        cost = System.currentTimeMillis() - startTime;
                        logger.info("{} RESPONSE,耗时(ms):{},返回值{},第{}条",this.providerCode,cost, response,index);
                        if (org.apache.commons.lang3.StringUtils.isNotBlank(response)) {
                            int result = JSON.parseObject(response).getIntValue("result");
                            childSendFlag = result==0?1:-1;
                        }
                    }catch (Exception e){
                        logger.error(String.format("%s遍历单发提交批量短信失败,本次batchId:%s,index:%s将被更新为失败",this.providerCode,sms.getBatchId(),index),e);
                    }
                    if(1==childSendFlag){
                        successCount++;
                    }else{
                        //直接更新那一条失败  不再重试
                        updateSmsSendFailed(sms.getBatchId(),Convert.MD5Encode(smsTemp.getPhoneNumber()),sms.getCurrentSmsAccountId());
                    }
                    index++;
                }
                sent = successCount==batchList.size()?1:-2;

            }else {
                long startTime=System.currentTimeMillis();
                logger.info("S21 request: " + parametersToString(params));
                if (httpClientUtil != null) {
                    response = httpClientUtil.post(vcpServer, params);
                } else {
                    response = HttpUtil.post(vcpServer, params);
                }
                cost = System.currentTimeMillis() - startTime;
                logger.info("S21 RESPONSE,耗时(ms):{},返回值{}", cost, response);
                if (response != null) {
                    try {
                        int result = JSON.parseObject(response).getIntValue("result");
                        switch (result) {
                            //参数不正确
                            case 0:
                                sent = 1;
                                logger.info("S21 SEND 成功");
                                break;
                            //参数不正确
                            case 101:
                                logger.info("S21 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!无此账户!!!!!!!!!!!!!!!!!!!!!!!");
                                break;
                            //成功
                            case 102:
                                logger.info("S21 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!密码错误!!!!!!!!!!!!!!!!!!!!!!!");
                                break;
                            case 103:
                                logger.info("S21 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!提交过快!!!!!!!!!!!!!!!!!!!!!!!");
                                break;
                            case 104:
                                logger.info("S21 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!系统异常!!!!!!!!!!!!!!!!!!!!!!!");
                                break;
                            case 105:
                                logger.info("S21 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!敏感短信!!!!!!!!!!!!!!!!!!!!!!!");
                                break;
                            case 106:
                                logger.info("S21 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!消息长度错（>700或<=0）!!!!!!!!!!!!!!!!!!!!!!!");
                                break;
                            //号码无效
                            case 107:
                                sent = -1;
                                logger.info("S21 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!包含错误的手机号码!!!!!!!!!!!!!!!!!!!!!!!");
                                break;
                            //手机号码个数错
                            case 108:
                                sent = -1;
                                logger.info("S21 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!手机号码个数错（群发>50000或<=0;单发>200或<=0）!!!!!!!!!!!!!!!!!!!!!!!");
                                break;
                            //额度不足
                            case 109:
                                logger.info("S21 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!账户额度不足!!!!!!!!!!!!!!!!!!!!!!!");
                                break;
                            case 110:
                                logger.info("S21 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!不在发送时间内!!!!!!!!!!!!!!!!!!!!!!!");
                                break;
                            case 111:
                                logger.info("S21 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!超出该账户当月发送额度限制!!!!!!!!!!!!!!!!!!!!!!!");
                                break;
                            case 112:
                                logger.info("S21 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!无此产品，用户没有订购该产品!!!!!!!!!!!!!!!!!!!!!!!");
                                break;
                            case 115:
                                logger.info("S21 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!自动审核驳回!!!!!!!!!!!!!!!!!!!!!!!");
                                break;
                            case 116:
                                logger.info("S21 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!签名不合法，未带签名!!!!!!!!!!!!!!!!!!!!!!!");
                                break;
                            case 117:
                                logger.info("S21 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!IP地址认证错,请求调用的IP地址不是系统登记的IP地址!!!!!!!!!!!!!!!!!!!!!!!");
                                break;
                            case 118:
                                logger.info("S21 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!用户没有相应的发送权限!!!!!!!!!!!!!!!!!!!!!!!");
                                break;
                            case 119:
                                logger.info("S21 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!用户已过期!!!!!!!!!!!!!!!!!!!!!!!");
                                break;
                            case 120:
                                logger.info("S21 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!内容不在白名单模板中!!!!!!!!!!!!!!!!!!!!!!!");
                                break;
                            default:
                                logger.info("S21 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!短信接口方异常!!!!!!!!!!!!!!!!!!!!!!!");
                                break;
                        }
                    } catch (Exception e) {
                        logger.info("S21 SEND FAILED: " + "Invalid response --> " + response);
                    }
                } else {
                    logger.info("S21 SEND FAILED: Empty response");
                }
            }
        } catch (Exception e) {
            logger.error("S21 SENDING ERROR: " + e.getMessage(), e);
        }
        logger.info(sendResultString(providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), response, cost, StringUtils.isNotEmpty(sms.getBatchId())?sms.getBatchId():sms.getContentId()));
        return sent;
    }


}
