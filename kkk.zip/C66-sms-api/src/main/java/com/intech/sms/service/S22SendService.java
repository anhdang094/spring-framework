package com.intech.sms.service;

import com.alibaba.fastjson.JSON;
import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.*;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class S22SendService extends AbstractSendService {

    public S22SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        logger.info("{} ACCOUNT INFO: {}", this.providerCode, accountToString(CHARACTER_ENCODING));
        int sent = 0;
        try {
            if (StringUtils.isEmpty(sms.getCountryCode())) {
                sms.setCountryCode(CountryCode.CHINA_1);
            } else {
                if (CountryCode.CHINA_2.equals(sms.getCountryCode())) {
                    sms.setCountryCode(CountryCode.CHINA_1);
                } else if (CountryCode.CHINA_TAIWAN_2.equals(sms.getCountryCode())) {
                    sms.setCountryCode(CountryCode.CHINA_TAIWAN_1);
                } else if (CountryCode.HONG_KONG_2.equals(sms.getCountryCode())) {
                    sms.setCountryCode(CountryCode.HONG_KONG_1);
                } else if (CountryCode.PHILIPPINES_2.equals(sms.getCountryCode())) {
                    sms.setCountryCode(CountryCode.PHILIPPINES_1);
                } else if (CountryCode.MACAU_2.equals(sms.getCountryCode())) {
                    sms.setCountryCode(CountryCode.MACAU_1);
                } else if (CountryCode.KOREA_2.equals(sms.getCountryCode())) {
                    sms.setCountryCode(CountryCode.KOREA_1);
                }else if(CountryCode.VIETNAM_2.equals(sms.getCountryCode())){
                    sms.setCountryCode(CountryCode.VIETNAM_1);
                }else if(CountryCode.JAPAN_2.equals(sms.getCountryCode())){
                    sms.setCountryCode(CountryCode.JAPAN_1);
                }
            }
            if (ProductConstants.PRODUCT_ID_C07.equalsIgnoreCase(sms.getProductId())) {
                sms.setCountryCode(CountryCode.VIETNAM_1);
            }
            if (ProductConstants.PRODUCT_ID_C31.equalsIgnoreCase(sms.getProductId())) {
                sms.setCountryCode(CountryCode.JAPAN_1);
            }
            List<Sms> batchList  = sms.getBatchList();
            if(CollectionUtils.isNotEmpty(batchList)) {
                //遍历单发
                logger.info("{}不支持一次性提交多条短信,开始遍历单发", this.providerCode);
                int index = 1;
                int successCount = 0;
                for (Sms smsTemp : batchList) {
                    int childSendFlag = 0;
                    try {
                        childSendFlag = send(smsTemp.getSendContent(), sms.getCountryCode().concat(smsTemp.getPhoneNumber()));
                    }catch (Exception e){
                        logger.error(String.format("%s遍历单发提交批量短信失败,本次batchId:%s,index:%s将被更新为失败",this.providerCode,sms.getBatchId(),index),e);
                    }
                    if(1==childSendFlag){
                        successCount++;
                    }else{
                        //直接更新那一条失败  不再重试
                        updateSmsSendFailed(sms.getBatchId(),Convert.MD5Encode(smsTemp.getPhoneNumber()),sms.getCurrentSmsAccountId());
                    }
                    index++;
                }
                sent = successCount==batchList.size()?1:-2;
            }else {
                //20180925 Herman.T 果粒修改接口，可以批量发送短信，手机号码以英文逗号分隔
                String[] phoneArr = sms.getPhoneNumber().split(",");
                StringBuilder phoneNumber = new StringBuilder();
                for (String phone : phoneArr) {
                    phoneNumber.append(sms.getCountryCode().concat(phone)).append(",");
                }
                phoneNumber.replace(phoneNumber.lastIndexOf(","), phoneNumber.length(), "");
                sent = send(sms.getSendContent(), phoneNumber.toString());
            }
            logger.info(sendResultString(this.providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), "", 0L, StringUtils.isNotEmpty(sms.getBatchId())?sms.getBatchId():sms.getContentId()));
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(this.providerCode + " SENDING ERROR: " + e.getMessage(), e);
        }

        return sent;
    }

    private Map<String, String> createParam(String content, String phone) {
        Map<String, String> map = new HashMap<>(5);
        map.put("batchlist", phone);
        map.put("msg", content);
        map.put("name", this.vcpUserId);
        map.put("pwd", this.vcpPwd);
        map.put("checksum", Convert.MD5Encode(this.mainUserId + content));

        return map;
    }

    private int send(String content, String phone) throws IOException {
        int sent = 0;
        HttpClientUtil httpClientUtil = getHttpClientUtil();
        long startTime = System.currentTimeMillis();
        Map<String, String> params = createParam(content, phone);
        logger.info("{} REQUEST PARAMETERS: {}", this.providerCode, parametersToString(params));
        String response;
        if (httpClientUtil != null) {
            response = httpClientUtil.post(this.vcpServer, params);
        } else {
            response = HttpUtil.post(this.vcpServer, params);
        }
        Long cost = System.currentTimeMillis() - startTime;
        logger.info("{} RESPONSE,耗时(ms):{},返回值{}", this.providerCode, cost, response);

        if (response != null) {
            try {
                String result = JSON.parseObject(response).getString("IsSuccess");
                String success = "true";
                if (result.equals(success)) {
                    logger.info("{} SEND 成功", this.providerCode);
                    sent = 1;
                } else {
                    logger.info("{} SEND 失败: {}",this.providerCode, result);
                }
            } catch (Exception e) {
                logger.error(this.providerCode + " SENDING ERROR: " + e.getMessage(), e);
            }
        } else {
            logger.info("{} SEND FAILED: Empty response", this.providerCode);
        }
        return sent;
    }

}
