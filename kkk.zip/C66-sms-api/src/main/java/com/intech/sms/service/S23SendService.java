package com.intech.sms.service;

import com.alibaba.fastjson.JSONObject;
import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.HttpClientUtil;
import com.intech.sms.util.HttpUtil;
import com.intech.sms.util.StringUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Herman.T
 */
@Deprecated
public class S23SendService extends AbstractSendService{

    public S23SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        logger.info("S23 ACCOUNT INFO: " + accountToString(CHARACTER_ENCODING));
        int sent = 0;
        String response = null;
        Long cost = null;
        try {
            HttpClientUtil httpClientUtil = getHttpClientUtil();
            long startTime=System.currentTimeMillis();
            Map<String, String> params = new HashMap<>(7);
            params.put("account",vcpUserId);
            params.put("pswd",vcpPwd);
            params.put("mobile",sms.getPhoneNumber());
            params.put("msg",sms.getSendContent());
            params.put("needstatus","true");
            params.put("resptype","json");

            logger.info("S23 request: " + parametersToString(params));
            if (httpClientUtil != null) {
                response = httpClientUtil.post(vcpServer, params);
            } else {
                response = HttpUtil.post(vcpServer, params);
            }
            cost = System.currentTimeMillis() - startTime;
            logger.info("S23RESPONSE,耗时(ms):{},返回值{}", cost,response);

            if(response != null){
                int result = JSONObject.parseObject(response).getIntValue("result");
                int success = 0;
                if(result == success) {
                    logger.info("S23 SEND 成功");
                    sent = 1;
                }
            } else {
                logger.info("S23 SEND 失败: Empty response");
            }
        }
        catch(Exception e) {
            logger.error("S23 SENDING ERROR: " + e.getMessage(), e);
        }
        logger.info(sendResultString(providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), response, cost, StringUtils.isNotEmpty(sms.getBatchId())?sms.getBatchId():sms.getContentId()));
        return sent;
    }
}
