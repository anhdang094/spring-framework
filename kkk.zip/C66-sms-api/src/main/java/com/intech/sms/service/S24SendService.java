package com.intech.sms.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.*;
import org.apache.commons.collections.CollectionUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Herman.T
 */
public class S24SendService extends AbstractSendService {


    public S24SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        logger.info("S24 ACCOUNT INFO: " + accountToString(CHARACTER_ENCODING));
        int sent = 0;

        try {
            List<Sms> batchList  = sms.getBatchList();
            if(CollectionUtils.isNotEmpty(batchList)) {
                //遍历单发
                logger.info("{}不支持一次性提交多条短信,开始遍历单发", this.providerCode);
                int index = 1;
                int successCount = 0;
                for (Sms smsTemp : batchList) {
                    int childSendFlag = 0;
                    try {
                        childSendFlag = send(smsTemp.getPhoneNumber(), smsTemp.getSendContent());
                    }catch (Exception e){
                        logger.error(String.format("%s遍历单发提交批量短信失败,本次batchId:%s,index:%s将被更新为失败",this.providerCode,sms.getBatchId(),index),e);
                    }
                    if(1==childSendFlag){
                        successCount++;
                    }else{
                        //直接更新那一条失败  不再重试
                        updateSmsSendFailed(sms.getBatchId(),Convert.MD5Encode(smsTemp.getPhoneNumber()),sms.getCurrentSmsAccountId());
                    }
                    index++;
                }
                sent = successCount==batchList.size()?1:-2;
            }else {
                sent = send(sms.getPhoneNumber(), sms.getSendContent());
            }
        } catch (Exception e) {
            logger.error("S24 SENDING 失败: " + e.getMessage(), e);
        }
        logger.info(sendResultString(providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), "", 0L, StringUtils.isNotEmpty(sms.getBatchId())?sms.getBatchId():sms.getContentId()));
        return sent;
    }

    private int send(String phone,String content)throws Exception{
        int sent = 0;
        String response = null;
        Long cost = null;
        HttpClientUtil httpClientUtil = getHttpClientUtil();
        long startTime=System.currentTimeMillis();
        Map<String, String> params = new HashMap<>(6);
        params.put("userid", mainUserId);
        params.put("account", vcpUserId);
        params.put("password", Convert.MD5Encode(vcpPwd).toUpperCase());
        params.put("mobile",phone);
        params.put("content", content);
        params.put("action", "send");

        logger.info("S24 request: " + parametersToString(params));
        if (httpClientUtil != null) {
            response = httpClientUtil.post(vcpServer, params);
        } else {
            response = HttpUtil.post(vcpServer, params);
        }
        cost = System.currentTimeMillis() - startTime;
        logger.info("S24 RESPONSE,耗时(ms):{},返回值{}", cost,response);

        if (response != null) {
            try {
                String result = JSONObject.parseObject(response).getString("returnstatus");
                if (Constants.SUCCESS.equals(result.toUpperCase())) {
                    logger.info("S24 SEND 成功");
                    sent = 1;
                } else {
                    logger.info("S24 SEND 失败: " + result);
                }
            } catch (Exception e) {
                logger.info("S24 SEND 失败: " + "Invalid response --> " + JSON.toJSONString(response));
            }
        } else {
            logger.info("S24 SEND 失败: Empty response");
        }
        return sent;
    }
}
