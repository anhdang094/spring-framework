package com.intech.sms.service;

import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import org.apache.commons.lang3.StringUtils;

/**
 * @author Herman.T
 */
public class S25SendService extends S22SendService {

    public S25SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        logger.info("S25 ACCOUNT INFO: " + accountToString(CHARACTER_ENCODING));
        int sent = 0;
        try {
            sent = super.send(sms);
        } catch (Exception e) {
            logger.error("S25 SENDING ERROR: " + e.getMessage(), e);
        }
        logger.info("S25 productID={} 发送 {}", sms.getProductId(), (sent > 0 ? "成功" : "失败"));
        return sent;
    }
}
