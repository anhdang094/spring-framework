package com.intech.sms.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.*;
import org.apache.commons.collections.CollectionUtils;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Herman.T
 */
public class S26SendService extends AbstractSendService {

    private final String DELIMITER = ",";
    public S26SendService(Configuration config) {
        super(config);
    }
    /**
     * code 短信编码，0或8 ，默认为8，可选
     8是中韩日俄等双字节文字（UNICODE编码） ，0是英文（ASII编码）

     */
    @Override
    public int send(Sms sms) {
        logger.info("S26 ACCOUNT INFO: " + accountToString(CHARACTER_ENCODING));
        int sent = 0;

        try {
            List<Sms> batchList  = sms.getBatchList();
            if(CollectionUtils.isNotEmpty(batchList)) {
                //遍历单发
                logger.info("{}不支持一次性提交多条短信,开始遍历单发", this.providerCode);
                int index = 1;
                int successCount = 0;
                String phone=null;
                for (Sms smsTemp : batchList) {
                    int childSendFlag = 0;
                    try {
                        if(ProductConstants.PRODUCT_ID_C07.equalsIgnoreCase(sms.getProductId())) {
                            phone=ComposePhone.getPhone(smsTemp.getPhoneNumber(), DELIMITER, CountryCode.VIETNAM_1, CountryCode.VIETNAM_1);
                        }else if (ProductConstants.PRODUCT_ID_C31.equalsIgnoreCase(sms.getProductId())) {
                            phone = ComposePhone.getPhone(sms.getPhoneNumber(), DELIMITER, CountryCode.JAPAN_1, CountryCode.JAPAN_1);
                        }else {
                            phone=ComposePhone.getPhone(smsTemp.getPhoneNumber(), DELIMITER, CountryCode.CHINA_1, CountryCode.CHINA_1);
                        }
                        childSendFlag = send(phone, smsTemp.getSendContent());
                    }catch (Exception e){
                        logger.error(String.format("%s遍历单发提交批量短信失败,本次batchId:%s,index:%s将被更新为失败",this.providerCode,sms.getBatchId(),index),e);
                    }
                    if(1==childSendFlag){
                        successCount++;
                    }else{
                        //直接更新那一条失败  不再重试
                        updateSmsSendFailed(sms.getBatchId(),Convert.MD5Encode(smsTemp.getPhoneNumber()),sms.getCurrentSmsAccountId());
                    }
                    index++;
                }
                sent = successCount==batchList.size()?1:-2;
            }else {
                if(ProductConstants.PRODUCT_ID_C07.equalsIgnoreCase(sms.getProductId())) {
                    sms.setPhoneNumber(ComposePhone.getPhone(sms.getPhoneNumber(), DELIMITER, CountryCode.VIETNAM_1, CountryCode.VIETNAM_1));
                }else if (ProductConstants.PRODUCT_ID_C31.equalsIgnoreCase(sms.getProductId())) {
                    sms.setPhoneNumber(ComposePhone.getPhone(sms.getPhoneNumber(), DELIMITER, CountryCode.JAPAN_1, CountryCode.JAPAN_1));
                }else {
                    sms.setPhoneNumber(ComposePhone.getPhone(sms.getPhoneNumber(), DELIMITER, CountryCode.CHINA_1, CountryCode.CHINA_1));
                }
                sent = send(sms.getPhoneNumber(),sms.getSendContent());
            }


        } catch (Exception e) {
            logger.error("S26 SENDING ERROR: " + e.getMessage(), e);
        }
        logger.info(sendResultString(providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), "", 0L, StringUtils.isNotEmpty(sms.getBatchId())?sms.getBatchId():sms.getContentId()));
        return sent;
    }


    private int send(String phone,String content)throws Exception{
        int sent = 0;
        HttpClientUtil httpClientUtil = getHttpClientUtil();
        long startTime=System.currentTimeMillis();
        Map<String, String> params = new HashMap<>();
        params.put("userid", mainUserId);
        params.put("account", vcpUserId);
        params.put("password", Convert.MD5Encode(vcpPwd).toUpperCase());
        params.put("mobile", phone);
        params.put("content", content);
        params.put("action", "send");
        params.put("code", "8");
        Long cost = null;
        String responseCode = null;
        logger.info("S26 request: " + parametersToString(params));
        String response;
        if (httpClientUtil != null) {
            response = httpClientUtil.post(vcpServer, params);
        } else {
            response = HttpUtil.post(vcpServer, params);
        }
        cost = System.currentTimeMillis() - startTime;
        logger.info("S26 RESPONSE,耗时(ms):{},返回值{}", cost,response);

        if (response != null) {
            try {
                logger.info("S26 send result: " + response);

                Document doc = DocumentHelper.parseText(response);
                Element root = doc.getRootElement();
                if(root != null){
                    responseCode = root.element("returnstatus").getText().toUpperCase();
                }
                if(Constants.SUCCESS.equals(responseCode)){
                    logger.info("S26 send 成功");
                    sent = 1;
                }else{
                    logger.info("S26 send 失败");
                }
            } catch (Exception e) {
                logger.info("S26 SEND FAILED: " + "Invalid response --> " + response);
            }
        } else {
            logger.error("S26 SEND FAILED: Empty response");
        }
        return sent;
    }
}
