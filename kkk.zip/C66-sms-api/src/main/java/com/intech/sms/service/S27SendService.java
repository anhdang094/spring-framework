package com.intech.sms.service;

import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;

import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;
@Deprecated
public class S27SendService extends AbstractSendService {
    public S27SendService() {
    }

    public S27SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        logger.info("S27 ACCOUNT INFO: " + accountToString(CHARACTER_ENCODING));

        int sent = 0;
        Long cost = null;
        String responseCode = null;
        try {
            HttpClientUtil httpClientUtil = getHttpClientUtil();
            Map<String, String> params = new HashMap<>(7);
            params.put("from", mainUserId);
            params.put("username", vcpUserId);
            params.put("password", vcpPwd);
            params.put("text", URLEncoder.encode(sms.getSendContent(), CHARACTER_ENCODING));
            params.put("charset", CHARACTER_ENCODING);
            params.put("mclass", "0");
            params.put("coding", "2");

            logger.info("S27不支持群发[遍历开始单发]");
            String numbers;
            if (ProductConstants.PRODUCT_ID_C07.equalsIgnoreCase(sms.getProductId())) {
                numbers = ComposePhone.getPhone(sms.getPhoneNumber(), Constants.NUMBERS_SEPARATOR, CountryCode.VIETNAM_1, CountryCode.VIETNAM_1);
            }else if (ProductConstants.PRODUCT_ID_C31.equalsIgnoreCase(sms.getProductId())) {
                numbers = ComposePhone.getPhone(sms.getPhoneNumber(), Constants.NUMBERS_SEPARATOR, CountryCode.JAPAN_1, CountryCode.JAPAN_1);
            } else {
                numbers = ComposePhone.getPhone(sms.getPhoneNumber(), Constants.NUMBERS_SEPARATOR, CountryCode.CHINA_1, CountryCode.CHINA_1, CountryCode.MACAU_1, CountryCode.HONG_KONG_1, CountryCode.PHILIPPINES_1, CountryCode.CHINA_TAIWAN_1);
            }
            String[] numberArr = StringUtils.split(numbers, Constants.NUMBERS_SEPARATOR);
            for (String number : numberArr) {
                params.put("to", URLEncoder.encode(number, CHARACTER_ENCODING));
                long startTime = System.currentTimeMillis();
                logger.info("S27 REQUEST PARAMETERS: " + parametersToString(params));
                int code;
                if (httpClientUtil != null) {
                    code = httpClientUtil.URLGetResponse(vcpServer, params, CHARACTER_ENCODING);
                } else {
                    code = HttpUtil.URLGetResponse(vcpServer, params, CHARACTER_ENCODING);
                }
                cost = System.currentTimeMillis() - startTime;
                logger.info("S27 RESPONSE,耗时(ms):{},返回值{}", cost, code);
                responseCode = String.valueOf(code);
                switch (code) {
                    //成功
                    case HttpStatus.SC_ACCEPTED:
                        sent = 1;
                        break;
                    case HttpStatus.SC_UNAUTHORIZED:
                        logger.info("S27 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!Account not found/Originator IP address is not authorized/Incorrect password!!!!!!!!!!!!!!!!!!!!!!!");
                        break;
                    case HttpStatus.SC_BAD_REQUEST:
                        logger.info("S27 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!Query missing/Syntax Error/Text Missing/From number missing/Charset not supported!!!!!!!!!!!!!!!!!!!!!!!");
                        break;
                    case HttpStatus.SC_NON_AUTHORITATIVE_INFORMATION:
                        logger.info("S27 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!User/Password parameter missing in the request (basic authorization is NOT used)!!!!!!!!!!!!!!!!!!!!!!!");
                        break;
                    case HttpStatus.SC_FORBIDDEN:
                        logger.info("S27 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!From number blocked/To number blocked!!!!!!!!!!!!!!!!!!!!!!!");
                        break;
                    case HttpStatus.SC_NOT_FOUND:
                        logger.info("S27 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!Unknown request!!!!!!!!!!!!!!!!!!!!!!!");
                        break;
                    case HttpStatus.SC_INTERNAL_SERVER_ERROR:
                        logger.info("S27 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!Sending failed!!!!!!!!!!!!!!!!!!!!!!!");
                        break;
                    case HttpStatus.SC_SERVICE_UNAVAILABLE:
                        logger.info("S27 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!Temporal error, try again later!!!!!!!!!!!!!!!!!!!!!!!");
                        break;
                    default:
                        logger.info("S27 ERROR:{}", "!!!!!!!!!!!!!!!!!!!!!!短信接口方未知异常!!!!!!!!!!!!!!!!!!!!!!!");
                        break;
                }
            }
        } catch (Exception e) {
            logger.error("S27 SENDING ERROR: " + e.getMessage(), e);
        }
        logger.info(sendResultString(providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), responseCode, cost, StringUtils.isNotEmpty(sms.getBatchId())?sms.getBatchId():sms.getContentId()));
        return sent;
    }

}
