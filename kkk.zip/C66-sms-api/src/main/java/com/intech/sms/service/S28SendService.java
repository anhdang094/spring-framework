package com.intech.sms.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.*;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class S28SendService extends AbstractSendService {

    private static final String SUCCESS = "000000";

    public S28SendService() {
    }

    public S28SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        logger.info("{} ACCOUNT INFO: {}", providerCode, accountToString(CHARACTER_ENCODING));
        int sent = 0;
        Long cost = null;
        String responseCode = null;
        try {
            Map<String, Object> params = new HashMap<>(5);
            String timestamp = DateTimeFormatter.ofPattern("yyyyMMddHHmmss").format(LocalDateTime.now());
            params.put("userID", vcpUserId);
            params.put("timestamp", timestamp);
            params.put("token", Convert.SHA256Encode(timestamp.concat(vcpPwd)));
            String numbers;
            String countryCode =CountryCode.CHINA_1;

            if (ProductConstants.PRODUCT_ID_C07.equalsIgnoreCase(sms.getProductId())) {
                countryCode =CountryCode.VIETNAM_1;
            }else if (ProductConstants.PRODUCT_ID_C31.equalsIgnoreCase(sms.getProductId())) {
                countryCode =CountryCode.JAPAN_1;
            } else {
                if(StringUtils.isNotBlank(sms.getCountryCode())){
                    countryCode = sms.getCountryCode().replaceAll("00","");
                }
            }
            String url = StringUtils.trim(this.vcpServer.trim());

            if (url.endsWith("sendBulkSMS")) {
                List<Sms> batchList  = sms.getBatchList();
                if(CollectionUtils.isNotEmpty(batchList)) {
                    for(Sms smstemp:batchList) {
                        String[] numberArr = StringUtils.split(ComposePhone.getPhone(smstemp.getPhoneNumber(), Constants.NUMBERS_SEPARATOR, countryCode, CountryCode.CHINA_1, CountryCode.MACAU_1, CountryCode.HONG_KONG_1, CountryCode.PHILIPPINES_1, CountryCode.CHINA_TAIWAN_1, CountryCode.VIETNAM_1, CountryCode.JAPAN_1), Constants.NUMBERS_SEPARATOR);
                        params.put("phoneNumberList",numberArr);
                        params.put("content", SmsUtility.moveSignToFirst(smstemp.getSendContent()));
                        sent = send(url,params);
                    }
                }else {
                    numbers = ComposePhone.getPhone(sms.getPhoneNumber(), Constants.NUMBERS_SEPARATOR, countryCode, CountryCode.CHINA_1, CountryCode.MACAU_1, CountryCode.HONG_KONG_1, CountryCode.PHILIPPINES_1, CountryCode.CHINA_TAIWAN_1, CountryCode.VIETNAM_1, CountryCode.JAPAN_1);
                    String[] numberArr = StringUtils.split(numbers, Constants.NUMBERS_SEPARATOR);
                    params.put("phoneNumberList",numberArr);
                    params.put("content", SmsUtility.moveSignToFirst(sms.getSendContent()));
                        sent = send(url,params);

                    }
            } else if(url.endsWith("sendBulkSMSAdv")){
                   // 群发：不同号码不同内容批量提交
                List<Sms> batchList  = sms.getBatchList();
                JSONArray array = new JSONArray();
                if(CollectionUtils.isNotEmpty(batchList)) {
                     for(Sms smstemp:batchList){
                         JSONObject object = new JSONObject();
                         object.put("phoneNumber", ComposePhone.getPhone(smstemp.getPhoneNumber(), Constants.NUMBERS_SEPARATOR, countryCode, CountryCode.CHINA_1, CountryCode.MACAU_1, CountryCode.HONG_KONG_1, CountryCode.PHILIPPINES_1, CountryCode.CHINA_TAIWAN_1, CountryCode.VIETNAM_1, CountryCode.JAPAN_1));
                         object.put("content",SmsUtility.moveSignToFirst(smstemp.getSendContent()));
                         array.add(object);
                     }
                }else if(StringUtils.isNotBlank(sms.getPhoneNumber())) {
                    numbers = ComposePhone.getPhone(sms.getPhoneNumber(), Constants.NUMBERS_SEPARATOR, countryCode, CountryCode.CHINA_1, CountryCode.MACAU_1, CountryCode.HONG_KONG_1, CountryCode.PHILIPPINES_1, CountryCode.CHINA_TAIWAN_1,CountryCode.VIETNAM_1, CountryCode.JAPAN_1);
                    String[] numberArr = StringUtils.split(numbers, Constants.NUMBERS_SEPARATOR);
                    String newContent=SmsUtility.moveSignToFirst(sms.getSendContent());
                    if(numberArr.length>1){
                        for (String number : numberArr) {
                            JSONObject object = new JSONObject();
                            object.put("phoneNumber", number);
                            object.put("content", newContent);
                            array.add(object);
                        }
                    }else {
                        JSONObject object = new JSONObject();
                        object.put("phoneNumber", numbers);
                        object.put("content", newContent);
                        array.add(object);
                    }
                }
                params.put("bulkSmsList", array);
                sent = send(url, params);


            }else if(url.endsWith("sendSMS")) {
                numbers = ComposePhone.getPhone(sms.getPhoneNumber(), Constants.NUMBERS_SEPARATOR, countryCode, CountryCode.CHINA_1, CountryCode.MACAU_1, CountryCode.HONG_KONG_1, CountryCode.PHILIPPINES_1, CountryCode.CHINA_TAIWAN_1,CountryCode.VIETNAM_1, CountryCode.JAPAN_1);
                String[] numberArr = StringUtils.split(numbers, Constants.NUMBERS_SEPARATOR);
                logger.info("{} 开始遍历单发:数量{}", providerCode, numberArr.length);
                params.put("content", SmsUtility.moveSignToFirst(sms.getSendContent()));
                for (String number : numberArr) {
                    params.put("phoneNumber", number);
                     sent = send(url,params);
                }
            }

        } catch (Exception e) {
            logger.error(providerCode + " SENDING ERROR: " + e.getMessage(), e);
        }
        logger.info(sendResultString(providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), responseCode, cost, StringUtils.isNotEmpty(sms.getBatchId())?sms.getBatchId():sms.getContentId()));
        return sent;
    }



    private int send(String url,Map<String, Object> params) throws Exception{
        HttpClientUtil httpClientUtil = getHttpClientUtil();
        int sent = 0;
        Long cost = null;
        String responseCode = null;
        long startTime = System.currentTimeMillis();
        logger.info("{} REQUEST PARAMETERS: {}", providerCode, parametersToString(params));
        String res;
        if (httpClientUtil != null) {
            res = httpClientUtil.post(url, JSON.toJSONString(params));
        } else {
            res = HttpUtil.post(url, JSON.toJSONString(params));
        }
        cost = System.currentTimeMillis() - startTime;
        logger.info("{} RESPONSE,耗时(ms):{},返回值{}", providerCode, cost, res);
        if (StringUtils.isNotEmpty(res)) {
            responseCode = JSON.parseObject(res).getString("error");
            if (SUCCESS.equals(responseCode)) {
                sent = 1;
            }
        }
        return  sent;
    }

}
