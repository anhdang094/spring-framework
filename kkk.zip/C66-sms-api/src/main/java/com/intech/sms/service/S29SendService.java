package com.intech.sms.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.Convert;
import com.intech.sms.util.HttpClientUtil;
import com.intech.sms.util.HttpUtil;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Condi 企信通  语音通道
 */
public class S29SendService extends AbstractSendService {


    public S29SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        logger.info("S29 ACCOUNT INFO: " + accountToString(CHARACTER_ENCODING));
        int sent = 0;
        Long cost = null;
        String responseCode = null;
        try {
            HttpClientUtil httpClientUtil = getHttpClientUtil();
            long startTime=System.currentTimeMillis();
            Map<String, String> params = new HashMap<>(6);
            params.put("cusNo", vcpUserId);
            params.put("called", sms.getPhoneNumber());
            params.put("vfcode", sms.getSendContent());
            params.put("timestamp", String.valueOf(System.currentTimeMillis()));
            params.put("sign",Convert.MD5Encode(params.get("cusNo").concat(params.get("called").concat(params.get("timestamp")).concat(vcpPwd))));
            params.put("taskId",sms.getContentId());

            logger.info("S29 request: " + parametersToString(params));
            String response;
            if (httpClientUtil != null) {
                response = httpClientUtil.post(vcpServer, params);
            } else {
                response = HttpUtil.post(vcpServer, params);
            }
            cost = System.currentTimeMillis() - startTime;
            logger.info("S29 RESPONSE,耗时(ms):{},返回值{}", cost,response);

            if (response != null) {
                try {
                    responseCode = JSONObject.parseObject(response).getString("retcode");
                    if (StringUtils.equals("0",responseCode)) {
                        logger.info("S29 SEND 成功");
                        sent = 1;
                    } else {
                        logger.info("S29 SEND 失败: " + responseCode);
                    }
                } catch (Exception e) {
                    logger.info("S29 SEND 失败: " + "Invalid response --> " + JSON.toJSONString(response));
                }
            } else {
                logger.info("S29 SEND 失败: Empty response");
            }
        } catch (Exception e) {
            logger.error("S29 SENDING 失败: " + e.getMessage(), e);
        }
        logger.info(sendResultString(providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), responseCode, cost, StringUtils.isNotEmpty(sms.getBatchId())?sms.getBatchId():sms.getContentId()));
        return sent;
    }
}
