package com.intech.sms.service;

import com.alibaba.fastjson.JSON;
import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.*;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

/**
 * OLYMPIC 语言短信
 */

public class S30SendService extends AbstractSendService {

    private static final String SUCCESS = "000000";

    public S30SendService() {
    }

    public S30SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        logger.info("{} ACCOUNT INFO: {}", providerCode, accountToString(CHARACTER_ENCODING));

        int sent = 0;

        try {
            Map<String, Object> params = new HashMap<>(5);
            String timestamp = DateTimeFormatter.ofPattern("yyyyMMddHHmmss").format(LocalDateTime.now());
            params.put("userID", vcpUserId);
            params.put("timestamp", timestamp);
            params.put("token", Convert.SHA256Encode(timestamp.concat(vcpPwd)));
            params.put("otpContent", sms.getSendContent());


            String numbers;
            if (ProductConstants.PRODUCT_ID_C07.equalsIgnoreCase(sms.getProductId())) {
                numbers = ComposePhone.getPhone(sms.getPhoneNumber(), Constants.NUMBERS_SEPARATOR, CountryCode.VIETNAM_1, CountryCode.VIETNAM_1);
            }else if (ProductConstants.PRODUCT_ID_C31.equalsIgnoreCase(sms.getProductId())) {
                numbers = ComposePhone.getPhone(sms.getPhoneNumber(), Constants.NUMBERS_SEPARATOR, CountryCode.JAPAN_1, CountryCode.JAPAN_1);
            } else {
                numbers = ComposePhone.getPhone(sms.getPhoneNumber(), Constants.NUMBERS_SEPARATOR, CountryCode.CHINA_1, CountryCode.CHINA_1, CountryCode.MACAU_1, CountryCode.HONG_KONG_1, CountryCode.PHILIPPINES_1, CountryCode.CHINA_TAIWAN_1);
            }
            if (smsGroupFlag == 0){
                logger.info("{} 开始群发短信", providerCode);
                params.put("phoneNumberList", "["+numbers+"]");
                long startTime = System.currentTimeMillis();
                logger.info("{} REQUEST PARAMETERS: {}", providerCode, parametersToString(params));
                String res = HttpUtil.post(vcpServer, JSON.toJSONString(params));
                logger.info("{} RESPONSE,耗时(ms):{},返回值{}", providerCode, System.currentTimeMillis() - startTime, res);
                if (StringUtils.isNotEmpty(res)) {
                    if (SUCCESS.equals(JSON.parseObject(res).getString("error"))) {
                        sent = 1;
                    }
                }
            }else{
                String[] numberArr = StringUtils.split(numbers, Constants.NUMBERS_SEPARATOR);
                logger.info("{} 开始遍历单发:数量{}", providerCode, numberArr.length);
                for (String number : numberArr) {
                    params.put("phoneNumber", number);
                    long startTime = System.currentTimeMillis();
                    logger.info("{} REQUEST PARAMETERS: {}", providerCode, parametersToString(params));
                    String res = HttpUtil.post(vcpServer, JSON.toJSONString(params));
                    logger.info("{} RESPONSE,耗时(ms):{},返回值{}", providerCode, System.currentTimeMillis() - startTime, res);
                    if (StringUtils.isNotEmpty(res)) {
                        if (SUCCESS.equals(JSON.parseObject(res).getString("error"))) {
                            sent = 1;
                        }
                    }
                }
            }

        } catch (Exception e) {
            logger.error(providerCode + " SENDING ERROR: " + e.getMessage(), e);
        }
        logger.info("{} productID={} 发送 {}", providerCode, sms.getProductId(), (sent > 0 ? "成功" : "失败"));
        return sent;
    }


}
