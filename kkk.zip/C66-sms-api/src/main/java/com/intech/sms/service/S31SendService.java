package com.intech.sms.service;

import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;

public class S31SendService extends S28SendService {

    public S31SendService() {
    }

    public S31SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        return super.send(sms);
    }
}
