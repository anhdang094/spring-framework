package com.intech.sms.service;

import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.*;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class S32SendService extends AbstractSendService {

    private static final String SUCCESS = "SUCCESS";

    public S32SendService() {
    }

    public S32SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        logger.info("{} ACCOUNT INFO: {}", providerCode, accountToString(CHARACTER_ENCODING));
        String countryCode=CountryCode.CHINA_1;

        if (ProductConstants.PRODUCT_ID_C07.equalsIgnoreCase(sms.getProductId())) {
            countryCode =CountryCode.VIETNAM_1;
        }else if (ProductConstants.PRODUCT_ID_C31.equalsIgnoreCase(sms.getProductId())) {
            countryCode =CountryCode.JAPAN_1;
        }
        if(StringUtils.isNotBlank(sms.getCountryCode())){
            countryCode = sms.getCountryCode().replaceAll("00","");
        }


        int sent = 0;
        Long cost = null;
        String responseCode = null;
        try {
            List<Sms> batchList  = sms.getBatchList();
            if(CollectionUtils.isNotEmpty(batchList)) {
                //遍历单发
                logger.info("{}不支持一次性提交多条短信,开始遍历单发", this.providerCode);
                int index = 1;
                int total = 1;
                int successCount = 0;
                for (Sms smsTemp : batchList) {
                    int childSendFlag = 0;
                    String numbers = ComposePhone.getPhone(sms.getPhoneNumber(), Constants.NUMBERS_SEPARATOR, countryCode, CountryCode.CHINA_1, CountryCode.MACAU_1, CountryCode.HONG_KONG_1, CountryCode.PHILIPPINES_1, CountryCode.CHINA_TAIWAN_1, CountryCode.VIETNAM_1, CountryCode.JAPAN_1);
                    String[] numberArr = StringUtils.split(numbers, Constants.NUMBERS_SEPARATOR);

                    for (String number : numberArr) {
                        total++;
                        try {
                            childSendFlag = send(number, smsTemp.getSendContent());
                        }catch (Exception e){
                            logger.error(String.format("%s遍历单发提交批量短信失败,本次batchId:%s,index:%s将被更新为失败",this.providerCode,sms.getBatchId(),index),e);
                        }
                        if(1==childSendFlag){
                            successCount++;
                        }else{
                            //直接更新那一条失败  不再重试
                            updateSmsSendFailed(sms.getBatchId(),Convert.MD5Encode(number),sms.getCurrentSmsAccountId());
                        }
                    }
                    index++;
                }
                sent = successCount==total?1:-2;
            }else {
                String numbers = ComposePhone.getPhone(sms.getPhoneNumber(), Constants.NUMBERS_SEPARATOR, countryCode, CountryCode.CHINA_1, CountryCode.MACAU_1, CountryCode.HONG_KONG_1, CountryCode.PHILIPPINES_1, CountryCode.CHINA_TAIWAN_1, CountryCode.VIETNAM_1, CountryCode.JAPAN_1);
                String[] numberArr = StringUtils.split(numbers, Constants.NUMBERS_SEPARATOR);
                logger.info("{} 开始遍历单发:数量{}", providerCode, numberArr.length);
                for (String number : numberArr) {
                    sent = send(number, sms.getSendContent());
                }
            }
        } catch (Exception e) {
            logger.error(providerCode + " SENDING ERROR: " + e.getMessage(), e);
        }
        logger.info(sendResultString(providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), responseCode, cost, StringUtils.isNotEmpty(sms.getBatchId())?sms.getBatchId():sms.getContentId()));
        return sent;
    }


    private int send(String phone,String content) throws Exception{
        int sent = 0;
        Long cost = null;
        String responseCode = null;
        HttpClientUtil httpClientUtil = getHttpClientUtil();
        Map<String, String> params = new HashMap<>(6);
        params.put("username", vcpUserId);
        params.put("password", vcpPwd);
        params.put("from", mainUserId);
        params.put("coding", "8");
        params.put("hex-content", HexUtil.encode(content.getBytes("utf-16BE")));
        params.put("to", phone);
//        params.put("content", URLEncoder.encode(content));

        long startTime = System.currentTimeMillis();
        logger.info("{} REQUEST PARAMETERS: {}", providerCode, parametersToString(params));
        if (httpClientUtil != null) {
            responseCode = httpClientUtil.get(vcpServer, params);
        } else {
            responseCode = HttpUtil.get(vcpServer, params);
        }
        cost = System.currentTimeMillis() - startTime;
        logger.info("{} RESPONSE,耗时(ms):{},返回值{}", providerCode, cost, responseCode);
        if (StringUtils.isNotEmpty(responseCode) && responseCode.toUpperCase().startsWith(SUCCESS)){
            sent = 1;
        }
        return sent;
    }

}
