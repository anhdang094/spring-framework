package com.intech.sms.service;

import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;

/**
 * S28 特殊群发接口   支持不同内容批量提交
 */
public class S33SendService extends S28SendService {

    public S33SendService() {
    }

    public S33SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        return super.send(sms);
    }
}
