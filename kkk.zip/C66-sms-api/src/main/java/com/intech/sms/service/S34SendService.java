package com.intech.sms.service;

import com.alibaba.fastjson.JSON;
import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.*;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.net.URLEncoder;
import java.util.List;

public class S34SendService extends AbstractSendService {

    public S34SendService() {
    }

    public S34SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        logger.info("S34 ACCOUNT INFO: " + accountToString(null));
        int sent = 0;
        String response = null;
        Long cost = null;
        try {
            HttpClientUtil httpClientUtil = getHttpClientUtil();
            List<Sms> batchList  = sms.getBatchList();
            if(CollectionUtils.isNotEmpty(batchList)){
                //遍历单发
                logger.info("{}不支持一次性提交多条短信,开始遍历单发",this.providerCode);
                String number = null;
                int index = 1;
                int successCount = 0;
                for (Sms smsTemp : batchList) {
                    int childSendFlag = 0;
                    try {
                        if (ProductConstants.PRODUCT_ID_C07.equalsIgnoreCase(sms.getProductId())) {
                            number = ComposePhone.getPhone(smsTemp.getPhoneNumber(), Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.VIETNAM_1, CountryCode.VIETNAM_1);
                        }else if (ProductConstants.PRODUCT_ID_C31.equalsIgnoreCase(sms.getProductId())) {
                            number = ComposePhone.getPhone(smsTemp.getPhoneNumber(), Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.JAPAN_1, CountryCode.JAPAN_1);
                        }else {
                            number = ComposePhone.getPhone(smsTemp.getPhoneNumber(), Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.CHINA_1, CountryCode.CHINA_1);
                        }
                        String checksum = Convert.MD5Encode(smsTemp.getSendContent()+number+this.mainUserId);
                        String getParams= this.vcpServer + "?name=" + this.vcpUserId + "&pwd=" +this.vcpPwd+
                                "&receiver=" + number + "&msg=" + URLEncoder.encode(smsTemp.getSendContent(), "UTF-8")+ "&checksum=" + checksum;
                        long startTime = System.currentTimeMillis();
                        if (httpClientUtil != null) {
                            response = httpClientUtil.get(getParams);
                        } else {
                            response = HttpUtil.get(getParams);
                        }
                        cost = System.currentTimeMillis() - startTime;
                        logger.info("{} RESPONSE,耗时(ms):{},返回值{},第{}条", this.providerCode,cost, response,index);
                        if (StringUtils.isNotBlank(response)) {
                            childSendFlag = dealResult(response);
                        }

                    }catch (Exception e){
                        logger.error(String.format("%s遍历单发提交批量短信失败,本次batchId:%s,index:%s将被更新为失败",this.providerCode,sms.getBatchId(),index),e);
                    }
                    if(1==childSendFlag){
                        successCount++;
                    }else{
                        //直接更新那一条失败  不再重试
                        updateSmsSendFailed(sms.getBatchId(),Convert.MD5Encode(smsTemp.getPhoneNumber()),sms.getCurrentSmsAccountId());
                    }
                    index++;
                }
                sent = successCount==batchList.size()?1:-2;

            }else {
                if (smsGroupFlag == 0) {
                    String to;
                    if (ProductConstants.PRODUCT_ID_C07.equalsIgnoreCase(sms.getProductId())) {
                        to = ComposePhone.getPhone(sms.getPhoneNumber(), Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.VIETNAM_1, CountryCode.VIETNAM_1);
                    }else if (ProductConstants.PRODUCT_ID_C31.equalsIgnoreCase(sms.getProductId())) {
                        to = ComposePhone.getPhone(sms.getPhoneNumber(), Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.JAPAN_1, CountryCode.JAPAN_1);
                    }else {
                        to = ComposePhone.getPhone(sms.getPhoneNumber(), Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.CHINA_1, CountryCode.CHINA_1);
                    }
                    String checksum = Convert.MD5Encode(sms.getSendContent()+to+this.mainUserId);
                    String getParams= this.vcpServer + "?name=" + this.vcpUserId + "&pwd=" +this.vcpPwd+
                            "&receiver=" + to + "&msg=" + URLEncoder.encode(sms.getSendContent(), "UTF-8")+ "&checksum=" + checksum;
                    long startTime = System.currentTimeMillis();
                    if (httpClientUtil != null) {
                        response = httpClientUtil.get(getParams);
                    } else {
                        response = HttpUtil.get(getParams);
                    }
                    cost = System.currentTimeMillis() - startTime;
                    logger.info("S34 RESPONSE,耗时(ms):{},返回值{}", cost, response);
                    if (StringUtils.isNotBlank(response)) {
                        sent = dealResult(response);
                    }
                } else {
                    String[] numbers = sms.getPhoneNumber().split(",");
                    for (String number : numbers) {
                        if (ProductConstants.PRODUCT_ID_C07.equalsIgnoreCase(sms.getProductId())) {
                            number = ComposePhone.getPhone(number, Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.VIETNAM_1, CountryCode.VIETNAM_1);
                        }else if (ProductConstants.PRODUCT_ID_C31.equalsIgnoreCase(sms.getProductId())) {
                            number = ComposePhone.getPhone(number, Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.JAPAN_1, CountryCode.JAPAN_1);
                        }else {
                            number = ComposePhone.getPhone(number, Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.CHINA_1, CountryCode.CHINA_1);
                        }
                        String checksum = Convert.MD5Encode(sms.getSendContent()+number+this.mainUserId);
                        String getParams= this.vcpServer + "?name=" + this.vcpUserId + "&pwd=" +this.vcpPwd+
                                "&receiver=" + number + "&msg=" + URLEncoder.encode(sms.getSendContent(), "UTF-8")+ "&checksum=" + checksum;
                        long startTime = System.currentTimeMillis();
                        if (httpClientUtil != null) {
                            response = httpClientUtil.get(getParams);
                        } else {
                            response = HttpUtil.get(getParams);
                        }
                        cost = System.currentTimeMillis() - startTime;
                        logger.info("S34 RESPONSE,耗时(ms):{},返回值{}", cost, response);
                        if (StringUtils.isNotBlank(response)) {
                            sent = dealResult(response);
                        }
                    }

                }
            }
        } catch (Exception e) {
            logger.error("S34 SENDING ERROR: ", e);
        }
        logger.info(sendResultString(providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), response, cost, StringUtils.isNotEmpty(sms.getBatchId())?sms.getBatchId():sms.getContentId()));
        return sent;
    }

    private int dealResult(String response) {
        int sent = 0;
        try {
            boolean result = JSON.parseObject(response).getBooleanValue("IsSuccess");
            if (result) {
                logger.info("{} SEND 成功", this.providerCode);
                sent = 1;
            } else {
                logger.info("{} SEND 失败: {}",this.providerCode, result);
            }
        } catch (Exception e) {
            logger.error(this.providerCode + " SENDING ERROR: " + e.getMessage(), e);
        }
        return sent;
    }
}