package com.intech.sms.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.intech.common.util.RedisUtil;
import com.intech.common.util.SpringContextUtil;
import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.*;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.*;

public class S35SendService extends AbstractSendService {

    public S35SendService() {
    }
    public static final String[] SUPPORT_COUNTRY_CODES = {CountryCode.CHINA_1,CountryCode.PHILIPPINES_1};

    public S35SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        logger.info("{} ACCOUNT INFO: {}",this.providerCode, accountToString(null));
        logger.info("{} Msg Info: {}", this.providerCode, JSON.toJSONString(sms));
        int sent = 0;
        String response = null;
        Long cost = null;
        try {
            HttpClientUtil httpClientUtil = getHttpClientUtil();
            List<Sms> batchList = sms.getBatchList();
            if (CollectionUtils.isNotEmpty(batchList)) {
                //遍历单发
                logger.info("{}不支持一次性提交多条短信,开始遍历单发.", this.providerCode);
                int index = 1;
                int successCount = 0;
                for (Sms smsTemp : batchList) {
                    int childSendFlag = 0;
                    try {
                        Map params = getPostParams(sms,smsTemp.getPhoneNumber(),smsTemp);
                        long startTime = System.currentTimeMillis();
                        //logger.info("{}内容不同发送请求参数:{},第{}条,发送端口：{}",this.providerCode, JSON.toJSONString(params), index, params.get("port"));

                        if (httpClientUtil != null) {
                            response = httpClientUtil.post(this.vcpServer, JSON.toJSONString(params), this.vcpUserId, this.vcpPwd);
                        } else {
                            response = HttpUtil.post(this.vcpServer, JSON.toJSONString(params), this.vcpUserId, this.vcpPwd);
                        }
                        cost = System.currentTimeMillis() - startTime;
                        logger.info("{} RESPONSE,耗时(ms):{},返回值{},第{}条,发送端口：{}", this.providerCode, cost, response, index, params.get("port"));
                        if (StringUtils.isNotBlank(response)) {
                            childSendFlag = dealResult(response);
                        }
                    } catch (Exception e) {
                        logger.error("{}遍历单发提交批量短信失败,本次batchId:{},index:{}将被更新为失败", this.providerCode, sms.getBatchId(), index, e);
                    }
                    if (1 == childSendFlag) {
                        successCount++;
                    } else {
                        //直接更新那一条失败  不再重试
                        updateSmsSendFailed(sms.getBatchId(), Convert.MD5Encode(smsTemp.getPhoneNumber()), sms.getCurrentSmsAccountId());
                    }
                    index++;
                }
                sent = successCount == batchList.size() ? 1 : -2;
            } else {
                String[] numbers = sms.getPhoneNumber().split(",");
                int index=0;
                for (String number : numbers) {
                    Map params = getPostParams(sms,number,null);
                    long startTime = System.currentTimeMillis();
                    index++;
                    //logger.info("{}内容一样发送请求参数:{},第{}条,发送端口：{}",this.providerCode, JSON.toJSONString(params), index, params.get("port"));
                    if (httpClientUtil != null) {
                        response = httpClientUtil.post(this.vcpServer, JSON.toJSONString(params), this.vcpUserId, this.vcpPwd);
                    } else {
                        response = HttpUtil.post(this.vcpServer, JSON.toJSONString(params), this.vcpUserId, this.vcpPwd);
                    }
                    cost = System.currentTimeMillis() - startTime;
                    logger.info(this.providerCode + " RESPONSE,耗时(ms):{},index:{},返回值{},发送端口：{}", cost,index,response,params.get("port"));
                    if (StringUtils.isNotBlank(response)) {
                        sent = dealResult(response);
                    }
                }
            }
        } catch (Exception e) {
            logger.error(this.providerCode + " SENDING ERROR: ", e);
        }
        logger.info(sendResultString(providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), response, cost, StringUtils.isNotBlank(sms.getBatchId()) ? sms.getBatchId() : sms.getContentId()));
        return sent;
    }

    private int dealResult(String response) {
        int sent = 0;
        try {
            Integer result = JSON.parseObject(response).getIntValue("error_code");
            if (result.intValue() == 202) {
                logger.info("{} SEND 成功", this.providerCode);
                sent = 1;
            } else {
                logger.info("{} SEND 失败: {}", this.providerCode, result);
            }
        } catch (Exception e) {
            logger.error(this.providerCode + " SENDING ERROR: " + e.getMessage(), e);
        }
        return sent;
    }

    private List<Map> getParamList(Sms smsTemp, String numberStr) throws Exception {
        // 单个号码获取参数
        String splitNumber=numberStr;
        if (StringUtils.isNotBlank(splitNumber)) {
            splitNumber=numberStr;
        }else {
            splitNumber= smsTemp.getPhoneNumber();
        }
        List<Map> paramsList = Lists.newArrayList();
        String number = "";
        if (ProductConstants.PRODUCT_ID_C07.equalsIgnoreCase(smsTemp.getProductId())) {
            number = ComposePhone.getPhone(splitNumber, Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.VIETNAM_1, CountryCode.VIETNAM_1);
        } else if (ProductConstants.PRODUCT_ID_C31.equalsIgnoreCase(smsTemp.getProductId())) {
            number = ComposePhone.getPhone(splitNumber, Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.JAPAN_1, CountryCode.JAPAN_1);
        } else {
            String defaultCountryCode=CountryCode.CHINA_1;
            if(StringUtils.isNotBlank(smsTemp.getCountryCode())){
                defaultCountryCode = smsTemp.getCountryCode().replaceAll("00","");
            }
            number = ComposePhone.getPhone(splitNumber, Constants.TEMPLATE_PARAMETER_MARKER, defaultCountryCode, SUPPORT_COUNTRY_CODES);
            //number = ComposePhone.getPhone(smsTemp.getPhoneNumber(), Constants.TEMPLATE_PARAMETER_MARKER, CountryCode.PHILIPPINES_1, CountryCode.PHILIPPINES_1);
        }
        String[] numbers = number.split("[|]");
        if(numbers==null || numbers.length<=0){
            throw new Exception("发送号码不能为空！");
        }

        long user_id=0;
        if(StringUtils.isNumeric(smsTemp.getContentId())){
            try{
                user_id=Long.valueOf(smsTemp.getContentId());
            }catch (Exception e){}

        }

        Map subParam = Maps.newHashMap();
        subParam.put("number", "+"+numbers[0]);
        subParam.put("user_id", user_id);

//        List<String> tempContentList = new ArrayList<>();
//        tempContentList.add(smsTemp.getSendContent());
//        subParam.put("text_param",tempContentList);
        paramsList.add(subParam);
        return paramsList;
    }

    private List<Integer> getPortList(Sms smsTemp) throws Exception {
        String extraParam = smsTemp.getExtraParam();
        List<Integer> portList = Lists.newArrayList();
        if (StringUtils.isBlank(extraParam) || StringUtils.isBlank(smsTemp.getProviderCode())) {
            return portList;
        }
        JSONObject extraJson = JSON.parseObject(extraParam);
        String portListStr = extraJson.getString(smsTemp.getProviderCode());
        if(StringUtils.isBlank(portListStr)){
            return portList;
        }
        portListStr=portListStr.replaceAll(" ", "");
        if(StringUtils.isBlank(portListStr)){
            return portList;
        }
        RedisUtil redisUtil = SpringContextUtil.getBean("redisUtil");
        if(redisUtil==null){
            return portList;
        }

        String lockPortKey = redisUtil.getS35RedisLockKey(portListStr,providerCode);
        String currPortKey = redisUtil.getS35RedisPortKey(portListStr,providerCode);
        String basePortKey = redisUtil.getS35RedisPortBaseKey(portListStr,providerCode);
        long endTime = System.currentTimeMillis() + 10 * 1000;//至多等待10秒
        Integer port=null;
        boolean flag = false;

        try{
            while (true) {
                if(System.currentTimeMillis() > endTime){
                    throw new Exception("获取自建短信网关redis线程锁超时！lockKey:"+lockPortKey);
                }
                //分布式并发锁
                boolean locked = StringUtils.isEmpty(lockPortKey) ? true : redisUtil.lock(lockPortKey, "1", 60 * 2L);
                if (locked) {
                    String basePortStr = redisUtil.get(basePortKey);
                    String currPortStr = redisUtil.get(currPortKey);
                    if(StringUtils.isBlank(basePortStr) || !StringUtils.equals(portListStr,basePortStr) || StringUtils.isBlank(currPortStr)){
                        redisUtil.set(basePortKey,portListStr);
                        redisUtil.set(currPortKey,portListStr);
                    }
                    currPortStr=redisUtil.get(currPortKey);

                    String[] arr = currPortStr.split(",");
                    if(arr==null||arr.length<=0){
                        return portList;
                    }
                    for (String s : arr) {
                        try {
                            portList.add(Integer.valueOf(s));
                        }catch (Exception e){
                            logger.error("provider:{},端口号配置存在非数字，跳过此端口！{}.",providerCode,s);
                        }
                    }

                    List<String> tempArrList = new ArrayList<>();
                    if(CollectionUtils.isNotEmpty(portList)){
                        if(portList.size()>1){
                            for (int i = 1; i < portList.size(); i++) {
                                tempArrList.add(String.valueOf(portList.get(i)));
                            }
                        }
                        tempArrList.add(String.valueOf(portList.get(0)));
                        redisUtil.set(currPortKey,StringUtils.join(tempArrList, ","));
                    }
                    port = CollectionUtils.isNotEmpty(portList)?portList.get(0):null;
                    logger.info("provider:{},自建网关获取端口配置:{}，当前轮询后端口顺序:{},当前使用的端口:{}.",providerCode,portListStr,redisUtil.get(currPortKey),port);
                    break;
                } else {
                    //休眠100ms
                    Thread.sleep(RedisUtil.SLEEP_TIME);
                }
            }
        }catch (Exception e){
            logger.info("provider:{},自建网关平均分配端口失败.",providerCode,e);
            throw e;
        }finally {
            if (StringUtils.isNotEmpty(lockPortKey)){
                redisUtil.unlock(lockPortKey);//解锁
            }
        }
        if(port!=null){
            portList.clear();
            portList.add(port);
        }

        return portList;
    }

    private Map getPostParams(Sms smsObj,String phone,Sms currentObj) throws Exception{
        Map resultParams = Maps.newHashMap();

        if(currentObj==null){
            resultParams.put("text", smsObj.getSendContent());
            resultParams.put("param", getParamList(smsObj, phone));
        }else{
            resultParams.put("text", currentObj.getSendContent());
            resultParams.put("param", getParamList(currentObj, phone));
        }

        List<Integer> portList = getPortList(smsObj);
        if(CollectionUtils.isNotEmpty(portList)){
            resultParams.put("port", portList);
        }
        return resultParams;
    }
}