package com.intech.sms.service;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.*;
import com.twilio.Twilio;
import com.twilio.http.NetworkHttpClient;
import com.twilio.http.TwilioRestClient;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.impl.client.HttpClientBuilder;

import javax.xml.bind.DatatypeConverter;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * twilio供应商
 */
public class S80SendService extends AbstractSendService {

    private static final String FROM = "+12013808451";
    public static final Charset US_ASCII = Charset.forName("US-ASCII");

    public S80SendService() {
    }

    public S80SendService(Configuration config) {
        super(config);
    }

    private static final String[] sendScope = {
            CountryCode.CHINA_1,
            CountryCode.MACAU_1,
            CountryCode.HONG_KONG_1,
            CountryCode.PHILIPPINES_1,
            CountryCode.CHINA_TAIWAN_1,
            CountryCode.VIETNAM_1,
            CountryCode.JAPAN_1,
            CountryCode.THAI_1
    };

    @Override
    public int send(Sms sms) {
        logger.info("{} ACCOUNT INFO: {}.", providerCode, accountToString(CHARACTER_ENCODING));
        // 获取手机国际区域号
        String countryCode=ProductConstants.getDefaultCountryCode(sms.getCountryCode(),sms.getProductId());

        int sent = 0;
        Long cost = null;
        String responseCode = null;
        try {
            List<Sms> batchList  = sms.getBatchList();
            if(CollectionUtils.isNotEmpty(batchList)) {
                //遍历单发
                logger.info("{}不支持一次性提交多条短信,开始遍历单发", this.providerCode);
                int index = 1;
                int total = 1;
                int successCount = 0;
                for (Sms smsTemp : batchList) {
                    int childSendFlag = 0;
                    String numbers = ComposePhone.getPhone(sms.getPhoneNumber(), Constants.NUMBERS_SEPARATOR, countryCode, sendScope);
                    String[] numberArr = StringUtils.split(numbers, Constants.NUMBERS_SEPARATOR);

                    for (String number : numberArr) {
                        total++;
                        try {
                            childSendFlag = sendNew(number, smsTemp.getSendContent());
                        }catch (Exception e){
                            logger.error(String.format("%s遍历单发提交批量短信失败,本次batchId:%s,index:%s将被更新为失败",this.providerCode,sms.getBatchId(),index),e);
                        }
                        if(1==childSendFlag){
                            successCount++;
                        }else{
                            //直接更新那一条失败  不再重试
                            updateSmsSendFailed(sms.getBatchId(),Convert.MD5Encode(number),sms.getCurrentSmsAccountId());
                        }
                    }
                    index++;
                }
                sent = successCount==total?1:-2;
            }else {
                String numbers = ComposePhone.getPhone(sms.getPhoneNumber(), Constants.NUMBERS_SEPARATOR, countryCode, sendScope);
                String[] numberArr = StringUtils.split(numbers, Constants.NUMBERS_SEPARATOR);
                logger.info("{} 开始遍历单发:数量{}", providerCode, numberArr.length);
                for (String number : numberArr) {
                    sent = sendNew(number, sms.getSendContent());
                }
            }
        } catch (Exception e) {
            logger.error(providerCode + " SENDING ERROR: " + e.getMessage(), e);
        }
        logger.info(sendResultString(providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), responseCode, cost, StringUtils.isNotEmpty(sms.getBatchId())?sms.getBatchId():sms.getContentId()));
        return sent;
    }

    private int sendNew(String phone,String content) throws Exception{
        int sent = 0;
        try {
            long startTime = System.currentTimeMillis();
            Map<String, String> params = new HashMap<>();
            params.put("From", StringUtils.isBlank(mainUserId)?FROM:mainUserId);
            params.put("To", "+" + phone);
            params.put("Body", content);
            String paramStr = HttpUtil.formatParamsUTF8(params);
            String url = vcpServer + "/2010-04-01/Accounts/" + vcpUserId + "/Messages.json";
            String authorStr = vcpUserId + ":" + vcpPwd;
            String authorBasic = DatatypeConverter.printBase64Binary(authorStr.getBytes(US_ASCII));
            Map<String, String> header = Maps.newHashMap();
            header.put("Authorization", "Basic " + authorBasic);
            HttpClientUtil httpClientUtil = getHttpClientUtil();
            String ret;
            if (httpClientUtil != null) {
                ret = httpClientUtil.post(url, paramStr, header);
            } else {
                ret = HttpUtil.post(url, paramStr, header);
            }

            long cost = System.currentTimeMillis() - startTime;
            if (StringUtils.isBlank(ret)) {
                logger.info("{} the request responses null result!", providerCode);
                return sent;
            }

            JSONObject retObj = JSONObject.parseObject(ret);
            logger.info("{} RESPONSE,耗时(ms):{},返回值:{},返回错误代号:{},返回错误信息:{},sid:{}.", providerCode, cost, retObj.getString("status"), retObj.getString("errorCode"), retObj.getString("errorMessage"), retObj.getString("sid"));
            if ("queued".equals(retObj.getString("status"))) {
                sent = 1;
            }
        }catch (Exception e){
            logger.info("{} RESPONSE Exception！.", providerCode, e);
        }

        return sent;
    }


    private int sendForSdk(String phone,String content) throws Exception{
        int sent = 0;
        long startTime = System.currentTimeMillis();
        Twilio.init(vcpUserId, vcpPwd);
        HttpClientBuilder httpClientBuilder = HttpUtil.createHttpClientBuilder();
        TwilioRestClient restClient = Twilio.getRestClient();
        NetworkHttpClient client  = new NetworkHttpClient(httpClientBuilder);
        TwilioRestClient.Builder twilioBuilder= new TwilioRestClient.Builder(vcpUserId, vcpPwd);
        twilioBuilder.accountSid(restClient.getAccountSid())
                .edge(restClient.getEdge())
                .httpClient(client)
                .region(restClient.getRegion());
        Twilio.setRestClient(twilioBuilder.build());
        logger.info("{} request sending sms start.", providerCode);
        Message ms = Message.creator(new PhoneNumber("+"+phone),new PhoneNumber(StringUtils.isBlank(mainUserId)?FROM:mainUserId),content).create();
        long cost = System.currentTimeMillis() - startTime;
        if(ms==null){
            logger.info("{} the request responses null result!", providerCode);
            return sent;
        }

        logger.info("{} RESPONSE,耗时(ms):{},返回值:{},返回错误代号:{},返回错误信息:{},sid:{}.", providerCode, cost, ms.getStatus(),ms.getErrorCode(),ms.getErrorMessage(),ms.getSid());
        /*QUEUED("queued"),
        SENDING("sending"),
        SENT("sent"),
        FAILED("failed"),
        DELIVERED("delivered"),
        UNDELIVERED("undelivered"),
        RECEIVING("receiving"),
        RECEIVED("received"),
        ACCEPTED("accepted"),
        SCHEDULED("scheduled"),
        READ("read"),
        PARTIALLY_DELIVERED("partially_delivered");*/
        if (ms.getStatus()!=null&&ms.getStatus()!=Message.Status.FAILED){
            sent = 1;
        }
        return sent;
    }
}
