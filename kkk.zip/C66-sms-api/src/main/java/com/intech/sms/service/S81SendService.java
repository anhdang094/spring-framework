package com.intech.sms.service;

import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;

public class S81SendService extends S36SendService {

    public S81SendService() {
    }

    public S81SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        return super.send(sms);
    }
}