package com.intech.sms.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import com.google.common.net.MediaType;
import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.*;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.List;
import java.util.Map;

public class S82SendService extends AbstractSendService {

    private static final String[] sendScope = {
            CountryCode.CHINA_1
    };

    private String tokenURl = "https://auth.sms.to/oauth/token";

    public static String authToken = "";

    public S82SendService() {
    }

    public S82SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        logger.info(this.providerCode + " ACCOUNT INFO: " + accountToString(null));
        String countryCode = ProductConstants.getDefaultCountryCode(sms.getCountryCode(), sms.getProductId());
        int sent = 0;
        String response = null;
        Long cost = null;
        try {
            HttpClientUtil httpClientUtil = getHttpClientUtil();
            List<Sms> batchList = sms.getBatchList();
            if (CollectionUtils.isNotEmpty(batchList)) {
                //遍历单发
                logger.info("{}不支持一次性提交多条短信,开始遍历单发", this.providerCode);
                int index = 1;
                int successCount = 0;
                int total = 1;
                for (Sms smsTemp : batchList) {
                    int childSendFlag = 0;
                    String numbers = ComposePhone.getPhone(sms.getPhoneNumber(), Constants.NUMBERS_SEPARATOR, countryCode, sendScope);
                    String[] numberArr = StringUtils.split(numbers, Constants.NUMBERS_SEPARATOR);
                    for (String number_ : numberArr) {
                        total++;
                        try {
                            childSendFlag = send(number_, smsTemp.getSendContent());
                        } catch (Exception e) {
                            logger.error(String.format("%s遍历单发提交批量短信失败,本次batchId:%s,index:%s将被更新为失败", this.providerCode, sms.getBatchId(), index), e);
                        }
                        if (1 == childSendFlag) {
                            successCount++;
                        } else {
                            //直接更新那一条失败  不再重试
                            updateSmsSendFailed(sms.getBatchId(), Convert.MD5Encode(number_), sms.getCurrentSmsAccountId());
                        }
                    }
                    index++;
                }
                sent = successCount == total ? 1 : -2;
            } else {
                if (smsGroupFlag == 0) {
                    String numbers = ComposePhone.getPhone(sms.getPhoneNumber(), Constants.NUMBERS_SEPARATOR, countryCode, sendScope);
                    String[] numberArr = StringUtils.split(numbers, Constants.NUMBERS_SEPARATOR);
                    long startTime = System.currentTimeMillis();
                    sent = send(numberArr, sms.getSendContent());
                    cost = System.currentTimeMillis() - startTime;
                    logger.info("{} RESPONSE,耗时(ms):{},返回值{}", this.providerCode, cost, response);
                } else {
                    String numbers = ComposePhone.getPhone(sms.getPhoneNumber(), Constants.NUMBERS_SEPARATOR, countryCode, sendScope);
                    String[] numberArr = StringUtils.split(numbers, Constants.NUMBERS_SEPARATOR);
                    for (String number : numberArr) {
                        sent = send(number, sms.getSendContent());
                    }
                }
            }
        } catch (Exception e) {
            logger.error("{} SENDING ERROR: ", this.providerCode, e);
        }
        logger.info(sendResultString(providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), response, cost, StringUtils.isNotEmpty(sms.getBatchId()) ? sms.getBatchId() : sms.getContentId()));
        return sent;
    }

    private int send(Object to, String msg) {
        try {
            JSONObject param = new JSONObject();
            param.put("to", to);
            param.put("message", msg);
            Map<String, String> header = Maps.newHashMap();
            header.put("Authorization", getToken());
            HttpClientUtil httpClientUtil = getHttpClientUtil();
            String ret;
            if (httpClientUtil != null) {
                ret = httpClientUtil.post(vcpServer, param.toJSONString(), header);
            } else {
                ret = HttpUtil.post(vcpServer, param.toJSONString(), header);
            }
            JSONObject retObj = JSONObject.parseObject(ret);
            if (retObj.getBoolean("success")) {
                return 1;
            } else {
                logger.info("{} send message return :{}", providerCode, ret);
            }
        } catch (IOException e) {
            logger.error("{} send message error,msg:{}", providerCode, e.getMessage(), e);
            S82SendService.authToken = "";
        }
        return 0;
    }

    private String getToken() {
        if (StringUtils.isNotEmpty(S82SendService.authToken)) {
            return S82SendService.authToken;
        }
        JSONObject param = new JSONObject();
        param.put("client_id", this.vcpUserId);
        param.put("secret", this.vcpPwd);
        String ret = "";
        try {
            ret = HttpUtil.post(tokenURl, param.toJSONString());
            JSONObject tokenObj = JSONObject.parseObject(ret);
            S82SendService.authToken = "Bearer " + tokenObj.getString("jwt");
            return S82SendService.authToken;
        } catch (Exception e) {
            logger.error("{} get tol token error,return content:{},error msg:{}", providerCode, ret, e.getMessage(), e);
        }
        return null;
    }
}