package com.intech.sms.service;

import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;

public class S83SendService extends S28SendService {

    public S83SendService() {
    }

    public S83SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        return super.send(sms);
    }
}
