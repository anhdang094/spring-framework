package com.intech.sms.service;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.*;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class S84SendService extends AbstractSendService {

    private static final String[] sendScope = {
            CountryCode.CHINA_1,
            CountryCode.MACAU_1,
            CountryCode.HONG_KONG_1,
            CountryCode.PHILIPPINES_1,
            CountryCode.CHINA_TAIWAN_1,
            CountryCode.VIETNAM_1,
            CountryCode.JAPAN_1,
            CountryCode.THAI_1
    };
    private static final Map<Integer,String> SEND_TYPE_MAP = new HashMap(){
        {
            put(1,"ARN");
            put(3,"OTP");
            put(4,"MKT");
        }
    };

    private static final Base64 base64 = new Base64();


    public S84SendService() {
    }

    public S84SendService(Configuration config) {
        super(config);
    }

    @Override
    public int send(Sms sms) {
        logger.info("{} ACCOUNT INFO: {}",this.providerCode, accountToString(null));
        String countryCode = ProductConstants.getDefaultCountryCode(sms.getCountryCode(), sms.getProductId());
        int sent = 0;
        String response = null;
        Long cost = null;
        try {
            List<Sms> batchList = sms.getBatchList();
            if (CollectionUtils.isNotEmpty(batchList)) {
                //遍历单发
                logger.info("{}一次性提交多条短信,开始遍历单发", this.providerCode);
                int index = 1;
                int successCount = 0;
                int total = 1;
                for (Sms smsTemp : batchList) {
                    int childSendFlag = 0;
                    String numbers = ComposePhone.getPhone(sms.getPhoneNumber(), Constants.NUMBERS_SEPARATOR, countryCode, sendScope);
                    String[] numberArr = StringUtils.split(numbers, Constants.NUMBERS_SEPARATOR);
                    for (String number_ : numberArr) {
                        total++;
                        try {
                            childSendFlag = send(number_, smsTemp.getSendContent());
                        } catch (Exception e) {
                            logger.error(String.format("%s遍历单发提交批量短信失败,本次batchId:%s,index:%s将被更新为失败", this.providerCode, sms.getBatchId(), index), e);
                        }
                        if (1 == childSendFlag) {
                            successCount++;
                        } else {
                            //直接更新那一条失败  不再重试
                            updateSmsSendFailed(sms.getBatchId(), Convert.MD5Encode(number_), sms.getCurrentSmsAccountId());
                        }
                    }
                    index++;
                }
                sent = successCount == total ? 1 : -2;
            } else {
                logger.info("{},开始遍历单发", this.providerCode);
                String numbers = ComposePhone.getPhone(sms.getPhoneNumber(), Constants.NUMBERS_SEPARATOR, countryCode, sendScope);
                String[] numberArr = StringUtils.split(numbers, Constants.NUMBERS_SEPARATOR);
                long startTime = System.currentTimeMillis();
                int succCount = 0;
                for (int i = 0; i < numberArr.length; i++) {
                    succCount +=send(numberArr[i], sms.getSendContent());
                }
                cost = System.currentTimeMillis() - startTime;
                logger.info("{} RESPONSE,耗时(ms):{},返回值{}", this.providerCode, cost, succCount);
                sent = numberArr.length==succCount?1:0;
            }
        } catch (Exception e) {
            logger.error("{} SENDING ERROR: {}", this.providerCode,e.getMessage(), e);
        }
        logger.info(sendResultString(providerCode, sms.getProductId(), sms.getTier(), String.valueOf(sent), response, cost, StringUtils.isNotEmpty(sms.getBatchId()) ? sms.getBatchId() : sms.getContentId()));
        return sent;
    }

    private int send(String to, String msg) {
        try {
            String message_type = SEND_TYPE_MAP.get(tier);
            message_type=StringUtils.isBlank(message_type)?"OTP":message_type;
            logger.info("{}-{} message param message_type is:{}", providerCode,tier, message_type);
            String paramStr = "phone_number="+to+"&message="+msg+"&message_type="+message_type;
            String authorStr = vcpUserId+":"+vcpPwd;
            String authorBasic = base64.encodeAsString(authorStr.getBytes("UTF-8"));
            Map<String, String> header = Maps.newHashMap();
            header.put("Authorization", "Basic "+authorBasic);
            HttpClientUtil httpClientUtil = getHttpClientUtil();
            String ret;
            if (httpClientUtil != null) {
                ret = httpClientUtil.post(vcpServer, paramStr, header);
            } else {
                ret = HttpUtil.post(vcpServer, paramStr, header);
            }
            logger.info("{} send message return :{}", providerCode, ret);
            JSONObject retObj = JSONObject.parseObject(ret);
            String errCode = "";
            if(retObj.getJSONObject("status")!=null){
                errCode=retObj.getJSONObject("status").getString("code");
            }
            if ("290".equals(errCode)) {
                return 1;
            } else {
                logger.info("{} send message error return :{}", providerCode, ret);
            }
        } catch (IOException e) {
            logger.error("{} send message error,msg:{}", providerCode, e.getMessage(), e);
        }
        return 0;
    }

}