package com.intech.sms.service;

import com.google.common.collect.Lists;
import com.intech.sms.interfaces.SmsSendService;
import com.intech.sms.model.Configuration;
import com.intech.sms.util.ConstantUtil;
import com.intech.sms.util.Constants;
import com.intech.sms.util.StringUtils;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

public class SMSCreatorFactory {

    private static HashMap<String, SmsSendService> smsSenderServiceList = new HashMap<>();
    public static ConcurrentHashMap<String, String> port_maps = new ConcurrentHashMap<>();

    public static SmsSendService getSmsProvider(Configuration config) {
        try {
            String providerCode = config.getProviderCode();
            String accountId = config.getAccountId();
            String key = providerCode + "_" + accountId;
            SmsSendService service = smsSenderServiceList.get(key);
            String gmsProviderListStr = ConstantUtil.SMS_CONSTANT_MAP.get(config.getProductId() + "_GSM_PROVIDER_LIST");
            if (StringUtils.isEmpty(gmsProviderListStr)) {
                gmsProviderListStr = ConstantUtil.SMS_CONSTANT_MAP.get("ALL_GSM_PROVIDER_LIST");
            }
            List<String> gmsProvides = Lists.newArrayList();
            if (StringUtils.isNotEmpty(gmsProviderListStr)) {
                String[] providerArr = gmsProviderListStr.split(",");
                gmsProvides.addAll(Arrays.asList(providerArr));
            }
            if (service == null) {
                if (Constants.SMS_TODAYNIC.equalsIgnoreCase(providerCode)) {
                    service = new S01SendService(config);
                } else if (Constants.SMS_SYSIO.equalsIgnoreCase(providerCode)) {
                    service = new S02SendService(config);
                } else if (Constants.SMS_S03.equalsIgnoreCase(providerCode)) {
                    service = new S03SendService(config);
                } else if (Constants.SMS_S04.equalsIgnoreCase(providerCode)) {
                    service = new S04SendService(config);
                } else if (Constants.SMS_S05.equalsIgnoreCase(providerCode)) {
                    service = new S05SendService(config);
                } else if (Constants.SMS_S06.equalsIgnoreCase(providerCode)) {
                    service = new S06SendService(config);
                } else if (Constants.SMS_S07.equalsIgnoreCase(providerCode)) {
                    service = new S07SendService(config);
                } else if (Constants.SMS_S08.equalsIgnoreCase(providerCode)) {
                    service = new S08SendService(config);
                } else if (Constants.SMS_S09.equalsIgnoreCase(providerCode)) {
                    service = new S09SendService(config);
                } else if (Constants.SMS_S10.equalsIgnoreCase(providerCode)) {
                    service = new S10SendService(config);
                } else if (Constants.SMS_S11.equalsIgnoreCase(providerCode)) {
                    service = new S11SendService(config);
                } else if (Constants.SMS_S12.equalsIgnoreCase(providerCode)) {
                    service = new S12SendService(config);
                } else if (Constants.SMS_S13.equalsIgnoreCase(providerCode)) {
                    service = new S13SendService(config);
                } else if (Constants.SMS_S14.equalsIgnoreCase(providerCode)) {
                    service = new S14SendService(config);
                } else if (Constants.SMS_S15.equalsIgnoreCase(providerCode)) {
                    service = new S15SendService(config);
                } else if (Constants.SMS_S16.equalsIgnoreCase(providerCode)) {
                    service = new S16SendService(config);
                } else if (Constants.SMS_S17.equalsIgnoreCase(providerCode)) {
                    service = new S17SendService(config);
                } else if (Constants.SMS_S18.equalsIgnoreCase(providerCode)) {
                    service = new S18SendService(config);
                } else if (Constants.SMS_S19.equalsIgnoreCase(providerCode)) {
                    service = new S19SendService(config);
                } else if (Constants.SMS_S20.equalsIgnoreCase(providerCode)) {
                    service = new S20SendService(config);
                } else if (Constants.SMS_S21.equalsIgnoreCase(providerCode)) {
                    service = new S21SendService(config);
                } else if (Constants.SMS_S22.equalsIgnoreCase(providerCode)) {
                    service = new S22SendService(config);
                } else if (Constants.SMS_S23.equalsIgnoreCase(providerCode)) {
                    service = new S23SendService(config);
                } else if (Constants.SMS_S24.equalsIgnoreCase(providerCode)) {
                    service = new S24SendService(config);
                } else if (Constants.SMS_S25.equalsIgnoreCase(providerCode)) {
                    service = new S25SendService(config);
                } else if (Constants.SMS_S26.equalsIgnoreCase(providerCode)) {
                    service = new S26SendService(config);
                } else if (Constants.SMS_S27.equalsIgnoreCase(providerCode)) {
                    service = new S27SendService(config);
                } else if (Constants.SMS_S28.equalsIgnoreCase(providerCode)) {
                    service = new S28SendService(config);
                } else if (Constants.SMS_S29.equalsIgnoreCase(providerCode)) {
                    service = new S29SendService(config);
                } else if (Constants.SMS_S30.equalsIgnoreCase(providerCode)) {
                    service = new S30SendService(config);
                } else if (Constants.SMS_S31.equalsIgnoreCase(providerCode)) {
                    service = new S31SendService(config);
                } else if (Constants.SMS_S32.equalsIgnoreCase(providerCode)) {
                    service = new S32SendService(config);
                } else if (Constants.SMS_S33.equalsIgnoreCase(providerCode)) {
                    service = new S33SendService(config);
                } else if (Constants.SMS_S34.equalsIgnoreCase(providerCode)) {
                    service = new S34SendService(config);
                } else if (gmsProvides.contains(providerCode)) {
                    service = new S35SendService(config);
                } else if (Constants.SMS_S36.equalsIgnoreCase(providerCode)) {
                    service = new S36SendService(config);
                } else if (Constants.SMS_S80.equalsIgnoreCase(providerCode)) {
                    service = new S80SendService(config);
                } else if (Constants.SMS_S81.equalsIgnoreCase(providerCode)) {
                    service = new S81SendService(config);
                } else if (Constants.SMS_S82.equalsIgnoreCase(providerCode)) {
                    service = new S82SendService(config);
                } else if (Constants.SMS_S83.equalsIgnoreCase(providerCode)) {
                    service = new S83SendService(config);
                } else if (Constants.SMS_S84.equalsIgnoreCase(providerCode)) {
                    service = new S84SendService(config);
                }else if (Constants.SMS_S85.equalsIgnoreCase(providerCode)) {
                    service = new S85SendService(config);
                }else if (Constants.SMS_S86.equalsIgnoreCase(providerCode)) {
                    service = new S86SendService(config);
                } else {
                    throw new RuntimeException("exception providerCode:" + providerCode);
                }
                service.setProviderCode(providerCode);
                smsSenderServiceList.put(key, service);
            } else {
                service.hasChanges(config);
            }

            return service;
        } catch (Exception e) {
            throw e;
        }
    }

}
