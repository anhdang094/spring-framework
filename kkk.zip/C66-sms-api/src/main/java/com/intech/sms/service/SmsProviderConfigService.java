package com.intech.sms.service;

import com.intech.sms.model.SmsProviderConfig;

import java.util.List;

/**
 * TODO
 *
 * @author Yaser
 * @date 2020/7/14 19:46
 */
public interface SmsProviderConfigService {

    /***
     * description: 获取渠道分级配置
     * @param productId
     * @param providerCode
     * @param exclusiveFlag
     * @return java.util.List<com.intech.sms.model.SmsProviderConfig>
     */
    List<SmsProviderConfig> getProviderConfigs(String productId, String providerCode, String exclusiveFlag,String smsType);
}
