package com.intech.sms.service;

import com.ws.SmsProvider;
import com.ws.SmsProviderQueryRequest;

import java.util.List;

public interface SmsProviderService {
    /**
     * 查询短信供应商
     * @param request
     * @return
     */
    List<SmsProvider> querySmsProvider(SmsProviderQueryRequest request);
}
