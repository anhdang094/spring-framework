package com.intech.sms.service;

import com.ws.SmsChildTypeRequest;
import com.ws.SmsType;

import java.util.List;

/**
 * @description:
 * @author: Condi
 * @create: 2019-03-20 09:52
 **/

public interface SmsTypeService {
    /**
     * 查询子类型
     * @param request
     * @return
     */
    List<SmsType> queryChildTypes(SmsChildTypeRequest request);
}


    
