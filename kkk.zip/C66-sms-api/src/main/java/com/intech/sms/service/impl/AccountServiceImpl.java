package com.intech.sms.service.impl;

import com.intech.sms.dao.UniversalDAO;
import com.intech.sms.model.Account;
import com.intech.sms.service.AccountService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author kaiser.dapar
 * @version 1.0, 2015-04-17
 */
@Service
public class AccountServiceImpl implements AccountService {
	
	@Override
	public Account retrieve(Account account) {
		try {
			return universalDAO.object("SELECT T_SMS_ACCOUNT.*, T_SMS_PROVIDER.SEND_GROUP_FLAG FROM T_SMS_ACCOUNT JOIN T_SMS_PROVIDER ON T_SMS_ACCOUNT.PROVIDER_CODE = T_SMS_PROVIDER.PROVIDER_CODE WHERE ACCOUNT_ID = ?", Account.ROW_MAPPER, account.getAccountId());
		} catch(Exception e) {
			LOGGER.error(e.getMessage(), e);
			e.printStackTrace();
			return null;
		}
	}
	
	@Override
	public List<Account> retrieveAll() {
		List<Account> accountList = new ArrayList<Account>();
		try {
			String sql = "SELECT DISTINCT(product_id||TIER||CUSTOMER_LEVEL),product_id,TIER,CUSTOMER_LEVEL FROM T_SMS_ACCOUNT where FLAG=0";
			accountList = universalDAO.list(sql, Account.ACC_RESULT_SET_EXTRACTOR);
		} catch(Exception e) {
			LOGGER.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return accountList;
	}
	
	@Override
	public List<Account> retrieveListByCriteria(Account account) {
		if (account == null) {
			account = new Account();
		}
		List<Account> accountList = new ArrayList<Account>();
		try {
			StringBuilder sql = new StringBuilder();
			List<Object> parameters = new ArrayList<Object>();
			
			if (account.getAccountId() != null) {
				sql.append(" AND T_SMS_ACCOUNT.ACCOUNT_ID = ?");
				parameters.add(account.getAccountId());
			}
			
			if ( ! StringUtils.isBlank(account.getProviderCode())) {
				sql.append(" AND T_SMS_ACCOUNT.PROVIDER_CODE = ?");
				parameters.add(account.getProviderCode());
			}
			
			if ( ! StringUtils.isBlank(account.getVcpUserid())) {
				sql.append(" AND T_SMS_ACCOUNT.VCP_USERID = ?");
				parameters.add(account.getVcpUserid());
			}
			
			if ( ! StringUtils.isBlank(account.getVcpPwd())) {
				sql.append(" AND T_SMS_ACCOUNT.VCP_PWD = ?");
				parameters.add(account.getVcpPwd());
			}
			
			if (account.getVcpPort() != null) {
				sql.append(" AND T_SMS_ACCOUNT.VCP_PORT = ?");
				parameters.add(account.getVcpPort());
			}
			
			if ( ! StringUtils.isBlank(account.getVcpServer())) {
				sql.append(" AND T_SMS_ACCOUNT.VCP_SERVER = ?");
				parameters.add(account.getVcpServer());
			}
			
			if (account.getFlag() != null) {
				sql.append(" AND T_SMS_ACCOUNT.FLAG = ?");
				parameters.add(account.getFlag());
			}
			
			if (account.getCreatedDate() != null) {
				sql.append(" AND T_SMS_ACCOUNT.CREATED_DATE = ?");
				parameters.add(account.getCreatedDate());
			}
			
			if (account.getLastUpdate() != null) {
				sql.append(" AND T_SMS_ACCOUNT.LAST_UPDATE = ?");
				parameters.add(account.getLastUpdate());
			}
			
			if ( ! StringUtils.isBlank(account.getLastUpdatedBy())) {
				sql.append(" AND T_SMS_ACCOUNT.LAST_UPDATED_BY = ?");
				parameters.add(account.getLastUpdatedBy());
			}
			
			if ( ! StringUtils.isBlank(account.getRemarks())) {
				sql.append(" AND T_SMS_ACCOUNT.REMARKS = ?");
				parameters.add(account.getRemarks());
			}
			
			if ( ! StringUtils.isBlank(account.getMainUserid())) {
				sql.append(" AND T_SMS_ACCOUNT.MAIN_USERID = ?");
				parameters.add(account.getMainUserid());
			}
			
			if (account.getSuccess() != null) {
				sql.append(" AND T_SMS_ACCOUNT.SUCCESS = ?");
				parameters.add(account.getSuccess());
			}
			
			if (account.getFailed() != null) {
				sql.append(" AND T_SMS_ACCOUNT.FAILED = ?");
				parameters.add(account.getFailed());
			}
			
			if (account.getSuccessRate() != null) {
				sql.append(" AND T_SMS_ACCOUNT.SUCCESS_RATE = ?");
				parameters.add(account.getSuccessRate());
			}
			
			if ( ! StringUtils.isBlank(account.getAccountRemarks())) {
				sql.append(" AND T_SMS_ACCOUNT.ACCOUNT_REMARKS = ?");
				parameters.add(account.getAccountRemarks());
			}
			
			if ( ! StringUtils.isBlank(account.getTier())) {
				sql.append(" AND T_SMS_ACCOUNT.TIER = ?");
				parameters.add(account.getTier());
			}
			
			if ( ! StringUtils.isBlank(account.getProductId())) {
				sql.append(" AND T_SMS_ACCOUNT.PRODUCT_ID = ?");
				parameters.add(account.getProductId());
			}
			
			sql.insert(0, "SELECT T_SMS_ACCOUNT.*, T_SMS_PROVIDER.SEND_GROUP_FLAG FROM T_SMS_ACCOUNT JOIN T_SMS_PROVIDER ON T_SMS_ACCOUNT.PROVIDER_CODE = T_SMS_PROVIDER.PROVIDER_CODE WHERE 1 = 1").append(" ORDER BY ACCOUNT_ID DESC");
			
			accountList = universalDAO.list(sql.toString(), Account.RESULT_SET_EXTRACTOR, parameters.toArray());
		} catch(Exception e) {
			LOGGER.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return accountList;
	}
	
	@Override
	public List<Account> retrieveListByCriteria(Account account, String orderBy, boolean isAsc, int offset, int size) {
		if (account == null) {
			account = new Account();
		}
		List<Account> accountList = new ArrayList<Account>();
		try {
			StringBuilder sql = new StringBuilder();
			List<Object> parameters = new ArrayList<Object>();
			
			if (account.getAccountId() != null) {
				sql.append(" AND T_SMS_ACCOUNT.ACCOUNT_ID = ?");
				parameters.add(account.getAccountId());
			}
			
			if ( ! StringUtils.isBlank(account.getProviderCode())) {
				sql.append(" AND T_SMS_ACCOUNT.PROVIDER_CODE = ?");
				parameters.add(account.getProviderCode());
			}
			
			if ( ! StringUtils.isBlank(account.getVcpUserid())) {
				sql.append(" AND T_SMS_ACCOUNT.VCP_USERID = ?");
				parameters.add(account.getVcpUserid());
			}
			
			if ( ! StringUtils.isBlank(account.getVcpPwd())) {
				sql.append(" AND T_SMS_ACCOUNT.VCP_PWD = ?");
				parameters.add(account.getVcpPwd());
			}
			
			if (account.getVcpPort() != null) {
				sql.append(" AND T_SMS_ACCOUNT.VCP_PORT = ?");
				parameters.add(account.getVcpPort());
			}
			
			if ( ! StringUtils.isBlank(account.getVcpServer())) {
				sql.append(" AND T_SMS_ACCOUNT.VCP_SERVER = ?");
				parameters.add(account.getVcpServer());
			}
			
			if (account.getFlag() != null) {
				sql.append(" AND T_SMS_ACCOUNT.FLAG = ?");
				parameters.add(account.getFlag());
			}
			
			if (account.getCreatedDate() != null) {
				sql.append(" AND T_SMS_ACCOUNT.CREATED_DATE = ?");
				parameters.add(account.getCreatedDate());
			}
			
			if (account.getLastUpdate() != null) {
				sql.append(" AND T_SMS_ACCOUNT.LAST_UPDATE = ?");
				parameters.add(account.getLastUpdate());
			}
			
			if ( ! StringUtils.isBlank(account.getLastUpdatedBy())) {
				sql.append(" AND T_SMS_ACCOUNT.LAST_UPDATED_BY = ?");
				parameters.add(account.getLastUpdatedBy());
			}
			
			if ( ! StringUtils.isBlank(account.getRemarks())) {
				sql.append(" AND T_SMS_ACCOUNT.REMARKS = ?");
				parameters.add(account.getRemarks());
			}
			
			if ( ! StringUtils.isBlank(account.getMainUserid())) {
				sql.append(" AND T_SMS_ACCOUNT.MAIN_USERID = ?");
				parameters.add(account.getMainUserid());
			}
			
			if (account.getSuccess() != null) {
				sql.append(" AND T_SMS_ACCOUNT.SUCCESS = ?");
				parameters.add(account.getSuccess());
			}
			
			if (account.getFailed() != null) {
				sql.append(" AND T_SMS_ACCOUNT.FAILED = ?");
				parameters.add(account.getFailed());
			}
			
			if (account.getSuccessRate() != null) {
				sql.append(" AND T_SMS_ACCOUNT.SUCCESS_RATE = ?");
				parameters.add(account.getSuccessRate());
			}
			
			if ( ! StringUtils.isBlank(account.getAccountRemarks())) {
				sql.append(" AND T_SMS_ACCOUNT.ACCOUNT_REMARKS = ?");
				parameters.add(account.getAccountRemarks());
			}
			
			if ( ! StringUtils.isBlank(account.getTier())) {
				sql.append(" AND T_SMS_ACCOUNT.TIER = ?");
				parameters.add(account.getTier());
			}
			
			if ( ! StringUtils.isBlank(account.getProductId())) {
				sql.append(" AND T_SMS_ACCOUNT.PRODUCT_ID = ?");
				parameters.add(account.getProductId());
			}
			
			// Inner Query
			sql.insert(0, "SELECT T_SMS_ACCOUNT.*, T_SMS_PROVIDER.SEND_GROUP_FLAG FROM T_SMS_ACCOUNT JOIN T_SMS_PROVIDER ON T_SMS_ACCOUNT.PROVIDER_CODE = T_SMS_PROVIDER.PROVIDER_CODE WHERE 1 = 1").append(" ORDER BY ").append(orderBy).append(isAsc ? " ASC" : " DESC");		
			
			// Outer Query
			sql.insert(0, "SELECT * FROM ( SELECT ROWNUM rnum, innerSql.* FROM (").append(") innerSql ) WHERE rnum BETWEEN ? AND ?");
			parameters.add(offset);
			parameters.add(size);
			
			accountList = universalDAO.list(sql.toString(), Account.RESULT_SET_EXTRACTOR, parameters.toArray());
		} catch(Exception e) {
			LOGGER.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return accountList;
	}
	
	@Override
	public int retrieveCountByCriteria(Account account) {
		Integer count = 0;
		if (account == null) {
			account = new Account();
		}
		try {
			StringBuilder sql = new StringBuilder();
			List<Object> parameters = new ArrayList<Object>();
			
			if (account.getAccountId() != null) {
				sql.append(" AND T_SMS_ACCOUNT.ACCOUNT_ID = ?");
				parameters.add(account.getAccountId());
			}
			
			if ( ! StringUtils.isBlank(account.getProviderCode())) {
				sql.append(" AND T_SMS_ACCOUNT.PROVIDER_CODE = ?");
				parameters.add(account.getProviderCode());
			}
			
			if ( ! StringUtils.isBlank(account.getVcpUserid())) {
				sql.append(" AND T_SMS_ACCOUNT.VCP_USERID = ?");
				parameters.add(account.getVcpUserid());
			}
			
			if ( ! StringUtils.isBlank(account.getVcpPwd())) {
				sql.append(" AND T_SMS_ACCOUNT.VCP_PWD = ?");
				parameters.add(account.getVcpPwd());
			}
			
			if (account.getVcpPort() != null) {
				sql.append(" AND T_SMS_ACCOUNT.VCP_PORT = ?");
				parameters.add(account.getVcpPort());
			}
			
			if ( ! StringUtils.isBlank(account.getVcpServer())) {
				sql.append(" AND T_SMS_ACCOUNT.VCP_SERVER = ?");
				parameters.add(account.getVcpServer());
			}
			
			if (account.getFlag() != null) {
				sql.append(" AND T_SMS_ACCOUNT.FLAG = ?");
				parameters.add(account.getFlag());
			}
			
			if (account.getCreatedDate() != null) {
				sql.append(" AND T_SMS_ACCOUNT.CREATED_DATE = ?");
				parameters.add(account.getCreatedDate());
			}
			
			if (account.getLastUpdate() != null) {
				sql.append(" AND T_SMS_ACCOUNT.LAST_UPDATE = ?");
				parameters.add(account.getLastUpdate());
			}
			
			if ( ! StringUtils.isBlank(account.getLastUpdatedBy())) {
				sql.append(" AND T_SMS_ACCOUNT.LAST_UPDATED_BY = ?");
				parameters.add(account.getLastUpdatedBy());
			}
			
			if ( ! StringUtils.isBlank(account.getRemarks())) {
				sql.append(" AND T_SMS_ACCOUNT.REMARKS = ?");
				parameters.add(account.getRemarks());
			}
			
			if ( ! StringUtils.isBlank(account.getMainUserid())) {
				sql.append(" AND T_SMS_ACCOUNT.MAIN_USERID = ?");
				parameters.add(account.getMainUserid());
			}
			
			if (account.getSuccess() != null) {
				sql.append(" AND T_SMS_ACCOUNT.SUCCESS = ?");
				parameters.add(account.getSuccess());
			}
			
			if (account.getFailed() != null) {
				sql.append(" AND T_SMS_ACCOUNT.FAILED = ?");
				parameters.add(account.getFailed());
			}
			
			if (account.getSuccessRate() != null) {
				sql.append(" AND T_SMS_ACCOUNT.SUCCESS_RATE = ?");
				parameters.add(account.getSuccessRate());
			}
			
			if ( ! StringUtils.isBlank(account.getAccountRemarks())) {
				sql.append(" AND T_SMS_ACCOUNT.ACCOUNT_REMARKS = ?");
				parameters.add(account.getAccountRemarks());
			}
			
			if ( ! StringUtils.isBlank(account.getTier())) {
				sql.append(" AND T_SMS_ACCOUNT.TIER = ?");
				parameters.add(account.getTier());
			}
			
			if ( ! StringUtils.isBlank(account.getProductId())) {
				sql.append(" AND T_SMS_ACCOUNT.PRODUCT_ID = ?");
				parameters.add(account.getProductId());
			}
			
			sql.insert(0, "SELECT COUNT(1) FROM T_SMS_ACCOUNT WHERE 1 = 1");
			
			count = universalDAO.object(sql.toString(), new RowMapper() {
				
				@Override
				public Object mapRow(ResultSet resultSet, int index) throws SQLException {
					return resultSet.getInt(1);
				}
				
			}, parameters.toArray());
			
		} catch(Exception e) {
			LOGGER.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return count;
	}
	
	@Override
	public int create(Account account) throws Exception {
		StringBuilder sql = new StringBuilder();
		List<Object> parameters = new ArrayList<Object>();
		
		sql.append(",").append("LAST_UPDATED_BY");
		parameters.add(account.getLastUpdatedBy());
		
		if ( ! StringUtils.isBlank(account.getProviderCode())) {
			sql.append(",").append("PROVIDER_CODE");
			parameters.add(account.getProviderCode());
		}
		
		if ( ! StringUtils.isBlank(account.getVcpUserid())) {
			sql.append(",").append("VCP_USERID");
			parameters.add(account.getVcpUserid());
		}
		
		if ( ! StringUtils.isBlank(account.getVcpPwd())) {
			sql.append(",").append("VCP_PWD");
			parameters.add(account.getVcpPwd());
		}
		
		if (account.getVcpPort() != null) {
			sql.append(",").append("VCP_PORT");
			parameters.add(account.getVcpPort());
		}
		
		if ( ! StringUtils.isBlank(account.getVcpServer())) {
			sql.append(",").append("VCP_SERVER");
			parameters.add(account.getVcpServer());
		}
		
		if (account.getFlag() != null) {
			sql.append(",").append("FLAG");
			parameters.add(account.getFlag());
		}
		
		if ( ! StringUtils.isBlank(account.getRemarks())) {
			sql.append(",").append("REMARKS");
			parameters.add(account.getRemarks());
		}
		
		if ( ! StringUtils.isBlank(account.getMainUserid())) {
			sql.append(",").append("MAIN_USERID");
			parameters.add(account.getMainUserid());
		}
		
		if (account.getSuccess() != null) {
			sql.append(",").append("SUCCESS");
			parameters.add(account.getSuccess());
		}
		
		if (account.getFailed() != null) {
			sql.append(",").append("FAILED");
			parameters.add(account.getFailed());
		}
		
		if (account.getSuccessRate() != null) {
			sql.append(",").append("SUCCESS_RATE");
			parameters.add(account.getSuccessRate());
		}
		
		if ( ! StringUtils.isBlank(account.getAccountRemarks())) {
			sql.append(",").append("ACCOUNT_REMARKS");
			parameters.add(account.getAccountRemarks());
		}
		
		if ( ! StringUtils.isBlank(account.getTier())) {
			sql.append(",").append("TIER");
			parameters.add(account.getTier());
		}
		
		if ( ! StringUtils.isBlank(account.getProductId())) {
			sql.append(",").append("PRODUCT_ID");
			parameters.add(account.getProductId());
		}
		
		sql.insert(0,"INSERT INTO T_SMS_ACCOUNT(ACCOUNT_ID,CREATED_DATE,").append(") VALUES (T_SMS_ACCOUNT_SEQ.NEXTVAL,CURRENT_TIMESTAMP,").append(StringUtils.repeat("?", ",", parameters.size())).append(")");
		
		return universalDAO.update(sql.toString(), parameters.toArray());
	}
	
	@Override
	public int update(Account account) throws Exception {
		StringBuilder sql = new StringBuilder();
		List<Object> parameters = new ArrayList<Object>();
		
		sql.append(",").append("LAST_UPDATED_BY = ?");
		parameters.add(account.getLastUpdatedBy());
		
		if (account.getProviderCode() != null) {
			sql.append(",").append("PROVIDER_CODE = ?");
			parameters.add(account.getProviderCode());
		}
		
		if (account.getVcpUserid() != null) {
			sql.append(",").append("VCP_USERID = ?");
			parameters.add(account.getVcpUserid());
		}
		
		if (account.getVcpPwd() != null) {
			sql.append(",").append("VCP_PWD = ?");
			parameters.add(account.getVcpPwd());
		}
		
		if (account.getVcpPort() != null) {
			sql.append(",").append("VCP_PORT = ?");
			parameters.add(account.getVcpPort());
		}
		
		if (account.getVcpServer() != null) {
			sql.append(",").append("VCP_SERVER = ?");
			parameters.add(account.getVcpServer());
		}
		
		if (account.getFlag() != null) {
			sql.append(",").append("FLAG = ?");
			parameters.add(account.getFlag());
		}
		
		if (account.getRemarks() != null) {
			sql.append(",").append("REMARKS = ?");
			parameters.add(account.getRemarks());
		}
		
		if (account.getMainUserid() != null) {
			sql.append(",").append("MAIN_USERID = ?");
			parameters.add(account.getMainUserid());
		}
		
		if (account.getSuccess() != null) {
			sql.append(",").append("SUCCESS = ?");
			parameters.add(account.getSuccess());
		}
		
		if (account.getFailed() != null) {
			sql.append(",").append("FAILED = ?");
			parameters.add(account.getFailed());
		}
		
		if (account.getSuccessRate() != null) {
			sql.append(",").append("SUCCESS_RATE = ?");
			parameters.add(account.getSuccessRate());
		}
		
		if (account.getAccountRemarks() != null) {
			sql.append(",").append("ACCOUNT_REMARKS = ?");
			parameters.add(account.getAccountRemarks());
		}
		
		if (account.getTier() != null) {
			sql.append(",").append("TIER = ?");
			parameters.add(account.getTier());
		}
		
		if (account.getProductId() != null) {
			sql.append(",").append("PRODUCT_ID = ?");
			parameters.add(account.getProductId());
		}
		
		sql.insert(0,"UPDATE T_SMS_ACCOUNT SET LAST_UPDATE = CURRENT_TIMESTAMP,").append(" WHERE ACCOUNT_ID = ?");
		parameters.add(account.getAccountId());
		
		return universalDAO.update(sql.toString(), parameters.toArray());
	}
	
	@Override
	public void delete(Account account) throws Exception {
		universalDAO.update("DELETE FROM T_SMS_ACCOUNT WHERE ACCOUNT_ID = ?", account.getAccountId());
	}

	@Autowired
	private UniversalDAO universalDAO;

}