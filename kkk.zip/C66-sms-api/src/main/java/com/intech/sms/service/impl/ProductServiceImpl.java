package com.intech.sms.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.intech.sms.dao.UniversalDAO;
import com.intech.sms.model.Product;
import com.intech.sms.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author kaiser.dapar
 * @version 1.0, Mon Mar 30 14:37:51 CST 2015
 */
@Service("ProductService")
public class ProductServiceImpl implements ProductService {
	
	@Override
	public Product retrieve(Product product) {
		try {
			return universalDAO.object("SELECT * FROM T_PRODUCT WHERE ID = ?", Product.ROW_MAPPER, product.getId());
		} catch(Exception e) {
			LOGGER.error(e.getMessage(), e);
			e.printStackTrace();
			return null;
		}
	}
	
	@Override
	public List<Product> retrieveAll() {
		List<Product> productList = new ArrayList<Product>();
		try {
			String sql = "SELECT * FROM T_PRODUCT";
			productList = universalDAO.list(sql, Product.RESULT_SET_EXTRACTOR);
		} catch(Exception e) {
			LOGGER.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return productList;
	}
	
	@Override
	public List<Product> retrieveListByCriteria(Product product) {
		if (product == null) {
			product = new Product();
		}
		List<Product> productList = new ArrayList<Product>();
		try {
			StringBuilder sql = new StringBuilder();
			List<Object> parameters = new ArrayList<Object>();
			
			if (product.getId() != null) {
				sql.append(" AND ID = ?");
				parameters.add(product.getId());
			}
			
			if ( ! StringUtils.isBlank(product.getProductId())) {
				sql.append(" AND PRODUCT_ID = ?");
				parameters.add(product.getProductId());
			}
			
			if ( ! StringUtils.isBlank(product.getProductName())) {
				sql.append(" AND PRODUCT_NAME = ?");
				parameters.add(product.getProductName());
			}
			
			if ( ! StringUtils.isBlank(product.getProductDesc())) {
				sql.append(" AND PRODUCT_DESC = ?");
				parameters.add(product.getProductDesc());
			}
			
			if (product.getProductPrior() != null) {
				sql.append(" AND PRODUCT_PRIOR = ?");
				parameters.add(product.getProductPrior());
			}
			
			if (product.getCreatedDate() != null) {
				sql.append(" AND CREATED_DATE = ?");
				parameters.add(product.getCreatedDate());
			}
			
			if (product.getLastUpdate() != null) {
				sql.append(" AND LAST_UPDATE = ?");
				parameters.add(product.getLastUpdate());
			}
			
			if ( ! StringUtils.isBlank(product.getLastUpdatedBy())) {
				sql.append(" AND LAST_UPDATED_BY = ?");
				parameters.add(product.getLastUpdatedBy());
			}
			
			if ( ! StringUtils.isBlank(product.getKey())) {
				sql.append(" AND KEY = ?");
				parameters.add(product.getKey());
			}
			
			if ( ! StringUtils.isBlank(product.getEmailKey())) {
				sql.append(" AND EMAIL_KEY = ?");
				parameters.add(product.getEmailKey());
			}
			
			if (product.getMailProductPrior() != null) {
				sql.append(" AND MAIL_PRODUCT_PRIOR = ?");
				parameters.add(product.getMailProductPrior());
			}
			
			sql.insert(0, "SELECT * FROM T_PRODUCT WHERE 1 = 1").append(" ORDER BY ID DESC");
			
			productList = universalDAO.list(sql.toString(), Product.RESULT_SET_EXTRACTOR, parameters.toArray());
		} catch(Exception e) {
			LOGGER.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return productList;
	}
	
	@Override
	public List<Product> retrieveListByCriteria(Product product, String orderBy, boolean isAsc, int offset, int size) {
		if (product == null) {
			product = new Product();
		}
		List<Product> productList = new ArrayList<Product>();
		try {
			StringBuilder sql = new StringBuilder();
			List<Object> parameters = new ArrayList<Object>();
			
			if (product.getId() != null) {
				sql.append(" AND ID = ?");
				parameters.add(product.getId());
			}
			
			if ( ! StringUtils.isBlank(product.getProductId())) {
				sql.append(" AND PRODUCT_ID = ?");
				parameters.add(product.getProductId());
			}
			
			if ( ! StringUtils.isBlank(product.getProductName())) {
				sql.append(" AND PRODUCT_NAME = ?");
				parameters.add(product.getProductName());
			}
			
			if ( ! StringUtils.isBlank(product.getProductDesc())) {
				sql.append(" AND PRODUCT_DESC = ?");
				parameters.add(product.getProductDesc());
			}
			
			if (product.getProductPrior() != null) {
				sql.append(" AND PRODUCT_PRIOR = ?");
				parameters.add(product.getProductPrior());
			}
			
			if (product.getCreatedDate() != null) {
				sql.append(" AND CREATED_DATE = ?");
				parameters.add(product.getCreatedDate());
			}
			
			if (product.getLastUpdate() != null) {
				sql.append(" AND LAST_UPDATE = ?");
				parameters.add(product.getLastUpdate());
			}
			
			if ( ! StringUtils.isBlank(product.getLastUpdatedBy())) {
				sql.append(" AND LAST_UPDATED_BY = ?");
				parameters.add(product.getLastUpdatedBy());
			}
			
			if ( ! StringUtils.isBlank(product.getKey())) {
				sql.append(" AND KEY = ?");
				parameters.add(product.getKey());
			}
			
			if ( ! StringUtils.isBlank(product.getEmailKey())) {
				sql.append(" AND EMAIL_KEY = ?");
				parameters.add(product.getEmailKey());
			}
			
			if (product.getMailProductPrior() != null) {
				sql.append(" AND MAIL_PRODUCT_PRIOR = ?");
				parameters.add(product.getMailProductPrior());
			}
			
			// Inner Query
			sql.insert(0, "SELECT * FROM T_PRODUCT WHERE 1 = 1").append(" ORDER BY ").append(orderBy).append(isAsc ? " ASC" : " DESC");		
			
			// Outer Query
			sql.insert(0, "SELECT * FROM ( SELECT ROWNUM rnum, innerSql.* FROM (").append(") innerSql ) WHERE rnum BETWEEN ? AND ?");
			parameters.add(offset);
			parameters.add(size);
			
			productList = universalDAO.list(sql.toString(), Product.RESULT_SET_EXTRACTOR, parameters.toArray());
		} catch(Exception e) {
			LOGGER.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return productList;
	}
	
	@Override
	public int retrieveCountByCriteria(Product product) {
		Integer count = 0;
		if (product == null) {
			product = new Product();
		}
		try {
			StringBuilder sql = new StringBuilder();
			List<Object> parameters = new ArrayList<Object>();
			
			if (product.getId() != null) {
				sql.append(" AND ID = ?");
				parameters.add(product.getId());
			}
			
			if ( ! StringUtils.isBlank(product.getProductId())) {
				sql.append(" AND PRODUCT_ID = ?");
				parameters.add(product.getProductId());
			}
			
			if ( ! StringUtils.isBlank(product.getProductName())) {
				sql.append(" AND PRODUCT_NAME = ?");
				parameters.add(product.getProductName());
			}
			
			if ( ! StringUtils.isBlank(product.getProductDesc())) {
				sql.append(" AND PRODUCT_DESC = ?");
				parameters.add(product.getProductDesc());
			}
			
			if (product.getProductPrior() != null) {
				sql.append(" AND PRODUCT_PRIOR = ?");
				parameters.add(product.getProductPrior());
			}
			
			if (product.getCreatedDate() != null) {
				sql.append(" AND CREATED_DATE = ?");
				parameters.add(product.getCreatedDate());
			}
			
			if (product.getLastUpdate() != null) {
				sql.append(" AND LAST_UPDATE = ?");
				parameters.add(product.getLastUpdate());
			}
			
			if ( ! StringUtils.isBlank(product.getLastUpdatedBy())) {
				sql.append(" AND LAST_UPDATED_BY = ?");
				parameters.add(product.getLastUpdatedBy());
			}
			
			if ( ! StringUtils.isBlank(product.getKey())) {
				sql.append(" AND KEY = ?");
				parameters.add(product.getKey());
			}
			
			if ( ! StringUtils.isBlank(product.getEmailKey())) {
				sql.append(" AND EMAIL_KEY = ?");
				parameters.add(product.getEmailKey());
			}
			
			if (product.getMailProductPrior() != null) {
				sql.append(" AND MAIL_PRODUCT_PRIOR = ?");
				parameters.add(product.getMailProductPrior());
			}
			
			sql.insert(0, "SELECT COUNT(1) FROM T_PRODUCT WHERE 1 = 1");
			
			count = universalDAO.object(sql.toString(), (resultSet, index) -> resultSet.getInt(1), parameters.toArray());
			
		} catch(Exception e) {
			LOGGER.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return count;
	}
	
	
	@Override
	public int create(Product product) throws Exception {
		StringBuilder sql = new StringBuilder();
		List<Object> parameters = new ArrayList<Object>();
		
		sql.append(",").append("LAST_UPDATED_BY");
		parameters.add(product.getLastUpdatedBy());
		
		if ( ! StringUtils.isBlank(product.getProductId())) {
			sql.append(",").append("PRODUCT_ID");
			parameters.add(product.getProductId());
		}
		
		if ( ! StringUtils.isBlank(product.getProductName())) {
			sql.append(",").append("PRODUCT_NAME");
			parameters.add(product.getProductName());
		}
		
		if ( ! StringUtils.isBlank(product.getProductDesc())) {
			sql.append(",").append("PRODUCT_DESC");
			parameters.add(product.getProductDesc());
		}
		
		if (product.getProductPrior() != null) {
			sql.append(",").append("PRODUCT_PRIOR");
			parameters.add(product.getProductPrior());
		}
		
		if ( ! StringUtils.isBlank(product.getKey())) {
			sql.append(",").append("KEY");
			parameters.add(product.getKey());
		}
		
		if ( ! StringUtils.isBlank(product.getEmailKey())) {
			sql.append(",").append("EMAIL_KEY");
			parameters.add(product.getEmailKey());
		}
		
		if (product.getMailProductPrior() != null) {
			sql.append(",").append("MAIL_PRODUCT_PRIOR");
			parameters.add(product.getMailProductPrior());
		}
		
		sql.insert(0,"INSERT INTO T_PRODUCT(ID,CREATED_DATE,").append(") VALUES (T_PRODUCT_SEQ.NEXTVAL,CURRENT_TIMESTAMP,").append(StringUtils.repeat("?", ",", parameters.size())).append(")");
		
		return universalDAO.update(sql.toString(), parameters.toArray());
	}
	
	@Override
	public int update(Product product) throws Exception {
		StringBuilder sql = new StringBuilder();
		List<Object> parameters = new ArrayList<Object>();
		
		sql.append(",").append("LAST_UPDATED_BY = ?");
		parameters.add(product.getLastUpdatedBy());
		
		if (product.getProductId() != null) {
			sql.append(",").append("PRODUCT_ID = ?");
			parameters.add(product.getProductId());
		}
		
		if (product.getProductName() != null) {
			sql.append(",").append("PRODUCT_NAME = ?");
			parameters.add(product.getProductName());
		}
		
		if (product.getProductDesc() != null) {
			sql.append(",").append("PRODUCT_DESC = ?");
			parameters.add(product.getProductDesc());
		}
		
		if (product.getProductPrior() != null) {
			sql.append(",").append("PRODUCT_PRIOR = ?");
			parameters.add(product.getProductPrior());
		}
		
		if (product.getKey() != null) {
			sql.append(",").append("KEY = ?");
			parameters.add(product.getKey());
		}
		
		if (product.getEmailKey() != null) {
			sql.append(",").append("EMAIL_KEY = ?");
			parameters.add(product.getEmailKey());
		}
		
		if (product.getMailProductPrior() != null) {
			sql.append(",").append("MAIL_PRODUCT_PRIOR = ?");
			parameters.add(product.getMailProductPrior());
		}
		
		sql.insert(0,"UPDATE T_PRODUCT SET LAST_UPDATE = CURRENT_TIMESTAMP,").append(" WHERE ID = ?");
		parameters.add(product.getId());
		
		return universalDAO.update(sql.toString(), parameters.toArray());
	}
	
	@Override
	public void delete(Product product) throws Exception {
		universalDAO.update("DELETE FROM T_PRODUCT WHERE ID = ?", product.getId());
	}

	@Autowired
	private UniversalDAO universalDAO;

}
