package com.intech.sms.service.impl;

import com.intech.sms.dao.UniversalDAO;
import com.intech.sms.exception.DAOException;
import com.intech.sms.model.Reply;
import com.intech.sms.service.ReplyService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service
@SuppressWarnings("unchecked")
public class ReplyServiceImpl implements ReplyService {

	Logger logger = LoggerFactory.getLogger(ReplyServiceImpl.class);
	@Autowired
	private UniversalDAO universalDAO;
	@Override
	public int insertReplies(final List<Reply> replies){
		String sql = "INSERT INTO T_SMS_REPLIES (ID,PRODUCT_ID,PHONE,CONTENT,RECEIVE_DATE,CREATED_DATE, PROVIDER_CODE, ACCOUNT) VALUES (T_SMS_REPLIES_SEQ.NEXTVAL,?,?,?,?,SYSDATE,?,?)";
		return universalDAO.batchUpdateReplies(sql,replies);
	}
	
	@Override
	public List<Reply> getReplies(String phone, String productId){
		
		String sql = "SELECT * FROM T_SMS_REPLIES WHERE PHONE = ? and PRODUCT_ID= ? ORDER BY CREATED_DATE DESC";
		

		if(StringUtils.isEmpty(phone)){
			sql = "SELECT * FROM T_SMS_REPLIES WHERE PRODUCT_ID= ? ORDER BY CREATED_DATE DESC";
			
			try {
				List<Reply> replies = universalDAO.list(sql, new ResultSetExtractor() {
					
					@Override
					public List<Reply> extractData(ResultSet rs) throws SQLException,
							DataAccessException {
						
						List<Reply> replies = new ArrayList<Reply>();
						while(rs.next()){
							Reply reply = new Reply();
							reply.setId(rs.getString("ID"));
							reply.setContent(rs.getString("CONTENT"));
							reply.setPhone(rs.getString("PHONE"));
							reply.setProductId(rs.getString("PRODUCT_ID"));
							reply.setReceiveDate(rs.getTimestamp("RECEIVE_DATE"));
							reply.setCreatedDate(rs.getTimestamp("CREATED_DATE"));
							reply.setProviderCode(rs.getString("PROVIDER_CODE"));
							
							replies.add(reply);
						}
						
						return replies;
					}
				}, productId);
				
				return replies;
				
			} catch (DAOException e) {
				logger.info("Dao Exception caught when acquiring replies for " + phone + ".");
				return null;
			}
		}
		
		try {
			List<Reply> replies = universalDAO.list(sql, new ResultSetExtractor() {
				
				@Override
				public List<Reply> extractData(ResultSet rs) throws SQLException,
						DataAccessException {
					
					List<Reply> replies = new ArrayList<Reply>();
					while(rs.next()){
						Reply reply = new Reply();
						reply.setId(rs.getString("ID"));
						reply.setContent(rs.getString("CONTENT"));
						reply.setPhone(rs.getString("PHONE"));
						reply.setProductId(rs.getString("PRODUCT_ID"));
						reply.setReceiveDate(rs.getTimestamp("RECEIVE_DATE"));
						reply.setCreatedDate(rs.getTimestamp("CREATED_DATE"));
						
						replies.add(reply);
					}
					
					return replies;
				}
			}, phone, productId);
			
			return replies;
			
		} catch (DAOException e) {
			logger.info("Dao Exception caught when acquiring replies for " + phone + ".");
			return null;
		}
	}


	@Override
	public int updateReplyJMSFlag(String id,String srcFlag,String descFlag){
		String sql = "UPDATE T_SMS_REPLIES SET JMS_FLAG ="+descFlag+"  WHERE ID = ? AND JMS_FLAG="+srcFlag;
		try {
			return universalDAO.update(sql.toString(), new Object[]{id});
		} catch (DAOException e) {
			logger.info("Dao Exception caught when updating JMS Flag of reply with ID " + id + ".");
			return 0;
		}
	}
	@Override
	public int updateReplyJMSFlag(String id){
		String sql = "UPDATE T_SMS_REPLIES SET JMS_FLAG =1  WHERE ID = ?";
		try {
			return universalDAO.update(sql.toString(), new Object[]{id});
		} catch (DAOException e) {
			logger.info("Dao Exception caught when updating JMS Flag of reply with ID " + id + ".");
			return 0;
		}
	}
	
	@Override
	public List<Reply> getUnsentReplies(String productId){
		String sql = "SELECT * FROM T_SMS_REPLIES WHERE JMS_FLAG = 0 AND PRODUCT_ID = ?";
		
		try {
			return universalDAO.list(sql, rs -> {
                List<Reply> replies = new ArrayList<>();
                while(rs.next()){
                    Reply reply = new Reply();
                    reply.setId(rs.getString("ID"));
                    reply.setContent(rs.getString("CONTENT"));
                    reply.setPhone(rs.getString("PHONE"));
                    reply.setProductId(rs.getString("PRODUCT_ID"));
                    reply.setReceiveDate(rs.getTimestamp("RECEIVE_DATE"));
                    reply.setCreatedDate(rs.getTimestamp("CREATED_DATE"));

                    replies.add(reply);
                }
                return replies;
            }, productId);
		} catch (DAOException e) {
			logger.info("Dao Exception caught when acquiring unsent replies.");
			return Collections.EMPTY_LIST;
		}
	}

	@Override
	public int getCoolCardMaxId(String accountId) {
		String sql = "SELECT MAX_ID FROM T_COOLCARD_MAXID WHERE ACCOUNT_ID = ?";
		
		try {
			List<String> maxIds = universalDAO.list(sql, new ResultSetExtractor() {
				
				@Override
				public List<String> extractData(ResultSet rs) throws SQLException, DataAccessException {
					List<String> maxIds = new ArrayList<String>();
					
					while(rs.next()) {
						maxIds.add(rs.getString("MAX_ID"));
					}
					return maxIds;
				}
			}, accountId);
			
			if(maxIds == null || maxIds.isEmpty()) {
				String insertSQL = "INSERT INTO T_COOLCARD_MAXID (ACCOUNT_ID) VALUES (?)";
				universalDAO.update(insertSQL, accountId);
				return 0;
			}
			else {
				return Integer.parseInt(maxIds.get(0));
			}
		} catch (DAOException e) {
			logger.info("Dao Exception caught when getting max coolcard id." + accountId + ".");
			return -1;
		}
	}

	@Override
	public int updateCoolCardMaxId(String accountId, String maxId) {
		String sql = "UPDATE T_COOLCARD_MAXID set MAX_ID = ? WHERE account_id = ?";
		
		try {
		return universalDAO.update(sql, maxId, accountId);
		}
		catch (DAOException e) {
			logger.info("Dao Exception caught when updating coolcard MAX ID. " + accountId);
			return -1;
		}
	}
	
	@Override
	public String getMaxReceiveDateByAccount(String account) {
		String sql = "SELECT MAX(RECEIVE_DATE) MAX_RECEIVE_DATE FROM T_SMS_REPLIES WHERE ACCOUNT = ?";
		
		try {
			List<String> maxDateList = universalDAO.list(sql, new ResultSetExtractor() {
				
				@Override
				public List<String> extractData(ResultSet rs) throws SQLException, DataAccessException {
					List<String> maxIds = new ArrayList<String>();
					
					while(rs.next()) {
						maxIds.add(rs.getString("MAX_RECEIVE_DATE"));
					}
					return maxIds;
				}
			}, account);
			
			if(maxDateList == null || maxDateList.isEmpty()) {
				return null;
			}
			else {
				return maxDateList.get(0);
			}
		} catch (DAOException e) {
			logger.info("Dao Exception caught when getting max receive date." + account + ".");
			return null;
		}
	}

}
