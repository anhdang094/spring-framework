package com.intech.sms.service.impl;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.intech.sms.dao.UniversalDAO;
import com.intech.sms.model.SmsProviderConfig;
import com.intech.sms.service.SmsProviderConfigService;
import com.intech.sms.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * TODO
 *
 * @author Yaser
 * @date 2020/7/14 19:49
 */
@Service
public class SmsProviderConfigServiceImpl implements SmsProviderConfigService {

    private final Logger logger = LoggerFactory.getLogger(SmsProviderConfigServiceImpl.class);
    @Autowired
    private UniversalDAO universalDAO;

    @Override
    public List<SmsProviderConfig> getProviderConfigs(String productId, String providerCode, String exclusiveFlag, String smsType) {
        List<SmsProviderConfig> configs = Lists.newArrayList();
        try {
            StringBuffer sql = new StringBuffer("SELECT * FROM T_SMS_PROVIDER_CONFIG g where 1=1");
            List<Object> params = Lists.newArrayList();
            if (StringUtils.isNotEmpty(productId)) {
                sql.append(" and g.product_id=?");
                params.add(productId);
            }
            if (StringUtils.isNotEmpty(providerCode)) {
                sql.append(" and g.provider_Code=?");
                params.add(providerCode);
            }
            if (StringUtils.isNotEmpty(exclusiveFlag)) {
                sql.append(" and g.exclusive_Flag=?");
                params.add(exclusiveFlag);
            }else{
                sql.append(" and g.exclusive_Flag=0");
            }
            if (StringUtils.isNotEmpty(smsType)) {
                sql.append(" and type_codes like ?");
                params.add("%" + smsType + "%");
            }
            configs = universalDAO.list(sql.toString(), SmsProviderConfig.RESULT_SET_EXTRACTOR, params.toArray());
            logger.info("配置规则查询SQL:{}，返回条数：{}，参数：{}", sql.toString(), configs.size(), JSON.toJSONString(params));
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return configs;
    }


}
