package com.intech.sms.service.impl;

import com.google.common.collect.Maps;
import com.intech.sms.dao.SMSOperateDao;
import com.intech.sms.dao.SmsTypeDao;
import com.intech.sms.model.Configuration;
import com.intech.sms.service.SmsProviderService;
import com.intech.sms.util.Constants;
import com.intech.sms.util.CountryCode;
import com.ws.SmsAccount;
import com.ws.SmsProvider;
import com.ws.SmsProviderQueryRequest;
import com.ws.SmsType;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * @description:
 * @author: Condi
 * @create: 2020-02-25 15:30
 **/
@Service
public class SmsProviderServiceImpl implements SmsProviderService {

    @Autowired
    private SmsTypeDao smsTypeDao;
    @Autowired
    private SMSOperateDao smsOperateDao;

    @Override
    public List<SmsProvider> querySmsProvider(SmsProviderQueryRequest request) {
        List<SmsProvider> res = new ArrayList<>();
        //默认查等级4的供应商 营销短信
        int defaultTier=4;
        if(StringUtils.isNotBlank(request.getTypeCode())) {
            SmsType type = smsTypeDao.getSmsTypeByCode(request.getTypeCode());
            if (Objects.nonNull(type)) {
                defaultTier = Integer.valueOf(type.getTier());
            }
        }
        List<Configuration> activeAccounts = smsOperateDao.getActiveAccounts(request.getProductId(), defaultTier, null, StringUtils.isNotEmpty(request.getCountryCode()) && !CountryCode.CHINA_2.equals(request.getCountryCode()), null, 0,0,request.getStatus(),request.getCountryCode());
        if (CollectionUtils.isEmpty(activeAccounts)) {
            return res;
        }
        for (Configuration configuration : activeAccounts) {
            SmsProvider smsProvider = new SmsProvider();
            smsProvider.setProviderCode(configuration.getProviderCode());
            smsProvider.setStatus(configuration.getFlag()+"");
            res.add(smsProvider);
        }
        return res;
    }
}


    
