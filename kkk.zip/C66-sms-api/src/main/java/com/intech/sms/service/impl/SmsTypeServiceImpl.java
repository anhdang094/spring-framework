package com.intech.sms.service.impl;

import com.intech.sms.dao.SmsTemplateDao;
import com.intech.sms.dao.SmsTypeDao;
import com.intech.sms.service.SmsTypeService;
import com.intech.sms.util.StringUtils;
import com.ws.SmsChildTypeRequest;
import com.ws.SmsType;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**短信类型service
 * @description:
 * @author: Condi
 * @create: 2019-03-20 09:52
 **/


@Service
public class SmsTypeServiceImpl implements SmsTypeService {

    @Autowired
    private SmsTypeDao smsTypeDao;
    @Autowired
    private SmsTemplateDao smsTemplateDao;
    /**
     * 查询子类型
     * @param request
     * @return
     */
    @Override
    public List<SmsType> queryChildTypes(SmsChildTypeRequest request) {
        List<SmsType> res = new ArrayList<>();
        SmsType type  =  smsTypeDao.getSmsTypeByCode(request.getTypeCode());
        if(Objects.nonNull(type)){
            res.add(type);
            List<SmsType> childTypes= smsTypeDao.queryChildTypes(type.getTypeId());
            if(CollectionUtils.isNotEmpty(childTypes)){
                res.addAll(childTypes);
                List<Long> ids = childTypes.stream().map(SmsType::getTypeId).collect(Collectors.toList());
                ids.add(type.getTypeId());

               List<SmsType> templates = smsTemplateDao.querySmsTemplatesByType(request,ids);
               if(CollectionUtils.isNotEmpty(templates)){
                   for(SmsType temp:res){
                       for(SmsType t:templates){
                          if(temp.getTypeId().equals(t.getTypeId())){
                              temp.setTemplate(t.getTemplate());
                              break;
                          }
                       }
                   }

               }
                res = res.stream().filter((t)-> StringUtils.isNotEmpty(t.getTemplate())).collect(Collectors.toList());
            }

        }
        return res;
    }





}


    
