package com.intech.sms.task;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Maps;
import com.intech.sms.constants.MqTypeEnum;
import com.intech.sms.dao.SMSOperateDao;
import com.intech.sms.facade.MsgMqFacade;
import com.intech.sms.model.MsgMqSendRecord;
import com.intech.sms.model.Product;
import com.intech.sms.model.Reply;
import com.intech.sms.model.SmsConstant;
import com.intech.sms.service.ProductService;
import com.intech.sms.service.ReplyService;
import com.intech.sms.util.*;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * @description: 短信系统配置相关自动刷新任务
 * @author: Condi
 * @create: 2019-05-16 13:32
 **/

@Component
public class SmsRefreshTask {

    private static final Logger logger = LoggerFactory.getLogger(SmsRefreshTask.class);

    @Autowired
    private ProductService productService;

    @Autowired
    private SMSOperateDao smsOperateDao;

    @Scheduled(cron = "0 0/5 * * * ?")
    public void scheduledForRefresh() {
        logger.info("定时刷新产品列表:" + new Date());
        Product.setProducts(productService.retrieveAll());
        //执行MQ补偿发送
//        mq_resend_exce();
    }

    @Scheduled(cron = "0 0/3 * * * ?")
    public void refreshDict() {
        logger.info("定时刷新字典表数据");
        List<SmsConstant> constants = smsOperateDao.getSmsConstantByKey(null, null);
        Map<String, String> tmp = Maps.newHashMap();
        for (SmsConstant constant : constants) {
            tmp.put(constant.getProductId() + "_" + constant.getConstantKey(), constant.getConstantValue());
        }
        ConstantUtil.SMS_CONSTANT_MAP.clear();
        ConstantUtil.SMS_CONSTANT_MAP.putAll(tmp);
    }

    private void mq_resend_exce() {
        logger.info("start to resend mq message...");
        try {
            int count = 500;
            MsgMqFacade msgMqFacade = ApplicationContextSingleton.getBean(MsgMqFacade.class);
            ReplyService replyService = ApplicationContextSingleton.getBean(ReplyService.class);
            MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
            logger.info("(MqResend) Start fetching mq record should be resend.");
            if (DbLockUtil.lock()) {
                try {
                    MsgMqSendRecord query = new MsgMqSendRecord();
                    query.setFlag(0);
                    query.setCount(count);
                    List<MsgMqSendRecord> msgList = msgMqFacade.queryMsgMqSendRecord(query);
                    boolean flag = false;
                    if (CollectionUtils.isNotEmpty(msgList)) {
                        logger.info("(MqResend) fetched mq record for resend ,total:" + msgList.size());
                        List<MsgMqSendRecord> successList = new ArrayList<>();
                        List<MsgMqSendRecord> failedList = new ArrayList<>();
                        for (MsgMqSendRecord record : msgList) {
                            if (String.valueOf(record.getMsgType()).equals(MqTypeEnum.ACTIVE_MQ.getCode())) {
                                flag = ActiveMqUtils.normalSend(record.getJmsQueueName(), record.getMsgData());
                            } else if (String.valueOf(record.getMsgType()).equals(MqTypeEnum.RABBIT_MQ.getCode())) {
                                flag = RabbitMqUtils.normalSend(record.getRabbitExchangeName(), record.getMsgData(), record.getRabbitRoutingKey());
                            }
                            if (flag) {
                                //补偿发送成功
                                successList.add(record);
                                Reply reply = JSON.parseObject(record.getMsgData(), Reply.class);
                                replyService.updateReplyJMSFlag(reply.getId());
                            } else {
                                //补偿发送失败
                                failedList.add(record);
                            }
                        }
                        if (CollectionUtils.isNotEmpty(successList)) {
                            msgMqFacade.batchDeleteMsgMqSendRecord(successList);
                            logger.info("(MqResend) fetched mq record for resend, successful total :" + successList.size());
                            //for GC
                            successList = null;
                        }
                        if (CollectionUtils.isNotEmpty(failedList)) {
                            msgMqFacade.batchUpdateMsgMqSendRecord(failedList);
                            logger.info("(MqResend) fetched mq record for resend, failed total :" + failedList.size());
                            //for GC
                            failedList = null;
                        }
                        //for GC
                        msgList = null;
                    } else {
                        logger.info("(MqResend) fetched mq record for resend, total :0");
                    }
                } catch (Exception e) {
                    logger.error("(MqResend)  Exception when acquiring mq records: " + e.getLocalizedMessage(), e);
                } finally {
                    DbLockUtil.unLock(false);
                }
            }
            logger.info("(MqResend) End fetching mq record.");
            MDC.remove("uuid");
        } catch (Exception e) {
            logger.error("(MqResend) resend error.: " + e.getLocalizedMessage(), e);
        }
        logger.info("end to resend mq message this time...");

    }


}


    
