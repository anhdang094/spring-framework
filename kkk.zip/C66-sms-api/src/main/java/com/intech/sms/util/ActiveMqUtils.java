package com.intech.sms.util;

import com.intech.sms.constants.MqTypeEnum;
import com.intech.sms.constants.ValidEnum;
import com.intech.sms.facade.MsgMqFacade;
import com.intech.sms.model.MsgMqSendRecord;
import com.intech.sms.model.Reply;
import com.intech.sms.model.SmsConstant;
import com.intech.sms.service.MQCallBack;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.scheduling.concurrent.ThreadPoolExecutorFactoryBean;

import java.util.concurrent.*;

/**
 * @author Herman.T
 */
@SuppressWarnings("unchecked")
public class ActiveMqUtils {

    private static final Logger logger = LoggerFactory.getLogger(ActiveMqUtils.class);

    private static final ThreadPoolExecutor execuctor = new ThreadPoolExecutor(
            5, 10, 5000, TimeUnit.MILLISECONDS, new ArrayBlockingQueue<>(50), new ThreadPoolExecutorFactoryBean(), new ThreadPoolExecutor.AbortPolicy());


    public static void send(String productId, String message, String queueName, final MQCallBack callBack,final Reply reply) {
        execuctor.execute(() -> {
                    try {
                        if(normalSend(queueName,message)){
                            callBack.afterSuccessDo(reply);
                        }
                    } catch (Exception e) {
                        logger.error(String.format("消息队列名: %s,内容: %s, 消息发送失败！", queueName, message), e);

                        SmsConstant recordConstant = ConstantUtil.getSmsConstantByKey(productId, "MQ_SEND_FAIL_FLAG");
                        if (recordConstant != null && ValidEnum.ENABLE.getCode().equals(recordConstant.getConstantValue())) {
                            // 发送失败添加jms消息发送数据库记录
                            try {
                                MsgMqFacade msgMqFacade = ApplicationContextSingleton.getBean(MsgMqFacade.class);
                                MsgMqSendRecord bean = new MsgMqSendRecord();
                                bean.setProductId(productId);
                                bean.setJmsQueueName(queueName);
                                bean.setMsgData(message);
                                bean.setMsgType(Integer.valueOf(MqTypeEnum.ACTIVE_MQ.getCode()));
                                msgMqFacade.createMsgMq(bean);
                            } catch (Exception ex) {
                                logger.error(String.format("消息发送失败时，保存发送记录至数据库失败！队列名：%s， 消息内容：%s", queueName, message), e);
                            }
                        }

                        callBack.afterFailDo(reply);
                    }
                }
        );
    }

    /**
     * 补偿发送
     * @param: [productId, exchange, message, routingKey]
     * @return: void
     * @throws:
     * @Author: "Condi"
     * @Date: 2018/11/23
     */
    public static boolean normalSend(String queueName, String message) {
        boolean res = false;
        try {
            logger.info("queueName:" + queueName + ", message:" + message);
            JmsTemplate jmsTemplate = ApplicationContextSingleton.getBean(JmsTemplate.class);
            jmsTemplate.send(queueName, session -> session.createTextMessage(message));
            res =true;
            logger.info("发送ActiveMq消息成功！消息队列名: {},内容: {} ", queueName, message);
        } catch (Exception e) {
            logger.error("发送ActiveMq消息失败！消息队列名:{},消息内容：{}。", queueName, message, e);
            throw  new RuntimeException(e);
        }
        return res;
    }

}
