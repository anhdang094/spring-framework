package com.intech.sms.util;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

/**
 * 单例模式得到spring ApplicationContext 线程安全，并且效率高 能有多个线程访问
 * @author gary.l
 */
@Component("applicationContextSingleton")
public class ApplicationContextSingleton implements ApplicationContextAware {

	private static ApplicationContext instance;
	private ApplicationContextSingleton(){}
	
	public static ApplicationContext getInstance() {
		return instance;
	}
	
	@SuppressWarnings("unchecked")
	/**
	 * 通过name获取Bean.
	 * @param clazz
	 * @param <T>
	 * @return
	 */
	public static <T> T getBean(String beanName) {
		return (T) getInstance().getBean(beanName);
	}

	/**
	 * 通过class获取Bean.
	 * @param clazz
	 * @param <T>
	 * @return
	 */
	public static <T> T getBean(Class<T> clazz){
		return instance.getBean(clazz);
	}
	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		instance = applicationContext;
	}
}