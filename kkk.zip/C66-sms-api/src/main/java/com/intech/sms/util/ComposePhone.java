package com.intech.sms.util;

import java.util.Arrays;
import java.util.HashSet;

import org.apache.commons.lang3.StringUtils;

/**
 * 
 * @author kaiser.dapar
 *
 */
public class ComposePhone {
	public static String getPhone(String phone, String writeSeparator, String defaultCountryCode, String...checkCountryCode) {
		StringBuilder strBuilder = new StringBuilder();
		String[] list = StringUtils.split(phone,Constants.NUMBERS_SEPARATOR);
		for (String item : list) {
			item = StringUtils.trim(item);
			if ( ! StringUtils.isBlank(item)) {
				if(strBuilder.length()>0){
					strBuilder.append(Constants.NUMBERS_SEPARATOR);
				}
				// 一般电话号码不包含国际区号都<=10位
				boolean notContainsCountryCode = item.length()<11;
				if(notContainsCountryCode){
					strBuilder.append(defaultCountryCode);
				}else{
					if (!StringUtils.isBlank(defaultCountryCode) && !StringUtils.startsWithAny(item, checkCountryCode)) {
						strBuilder.append(defaultCountryCode);
					}
				}

				strBuilder.append(item);
			}
		}
		return StringUtils.join(new HashSet<>(Arrays.asList(StringUtils.split(strBuilder.toString(),Constants.NUMBERS_SEPARATOR))).toArray(),writeSeparator);
	}

}
