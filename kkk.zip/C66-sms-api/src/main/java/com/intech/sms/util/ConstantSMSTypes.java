package com.intech.sms.util;

/**
 * @Overview: Class containing system constants,include sms's type constants
 * @author: gary
 * @History: 9:57 PM 9/4/2012
 * 
 */
public class ConstantSMSTypes {
	public static final String OPEN_REAL_ACCOUNT="60001";//真钱会员开户
	public static final String OPEN_PARTNER_ACCOUNT="60002";//合作伙伴开户
	public static final String OPEN_AGENT_ACCOUNT="60003";//代理开户
	public static final String MODIFY_PWD="60004";//修改密码
	public static final String MODIFY_REAL_NAME="60005";//修改真实姓名
	public static final String MODIFY_PHONE="60006";//修改电话
	public static final String MOIDFY_BANK_INFO="60007";//修改银行资料
	public static final String DEPOSIT="60008";//存款
	public static final String WITHDRAW="60009";//取款
	public static final String Activity_PROMOTION="60010";//活动类优惠
	public static final String NOT_Activity_PROMOTION="60011";//非活动类优惠
	public static final String LOGIN_SMS="60012";//登陆短信
	public static final String DOMAIN_CHANGE="60013";//域名变更
	public static final String EMERGENCY_NOTICE="60014";//紧急通知
	public static final String WEBSITE_CHANGE_BANKACCOUNTNO="60015";//网站更改收款帐号
	public static final String WEBSITE_REGARDS="60016";//网站问候
	public static final String ESPECIAL_HOLIDAY_SMS="60017";//特殊节日短信
	public static final String ESPECIAL_SMS="60018";//特殊短信
	public static final String MODIFY_PERSONAL_INFO="60019";//修改基本资料
	public static final String VERIFY_CODE="60026";//发送验证码
	public static final String MEMBER_INITIATED_CODE="700001";//会员发起出码
	public static final String AGENCY_INITIATED_CODE="700002";//代理发起出码
	public static final String MEMBER_SETTLEMENT="700003";//会员发起结算
	public static final String PROXY_SETTLEMENT="700004";//代理发起结算


    
}