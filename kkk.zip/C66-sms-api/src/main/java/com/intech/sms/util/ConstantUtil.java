package com.intech.sms.util;

import com.google.common.collect.Maps;
import com.intech.sms.dao.SMSOperateDao;
import com.intech.sms.model.SmsConstant;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;

/**
 * @author Herman.T
 */
public class ConstantUtil {

    public static Map<String,String> SMS_CONSTANT_MAP = Maps.newConcurrentMap();

    private static final Logger logger = LoggerFactory.getLogger(ConstantUtil.class);
    /**
     * 获取常量配置
     * @param productId
     * @param key
     * @return
     */
    public static SmsConstant getSmsConstantByKey(String productId, String key){
        if(StringUtils.isAnyEmpty(productId, key)){
            return null;
        }
        SMSOperateDao smsOperateDao = ApplicationContextSingleton.getBean(SMSOperateDao.class);
        List<SmsConstant> list = smsOperateDao.getSmsConstantByKey(productId, key);
        if(CollectionUtils.isEmpty(list)){
            return null;
        }

        return list.get(0);
    }
}
