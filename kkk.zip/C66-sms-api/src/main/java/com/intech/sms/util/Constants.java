package com.intech.sms.util;

/**
 * @Overview: Class containing system constants
 * @author: iver.mariano
 * @History: 9:57 PM 6/16/2012
 * 9:57 AM 6/16/2012  iver  AOFFICE-410  changed account and password for SMS SYSIO
 * 2015-03-28 kaiser
 */
public class Constants {
    public static final String AREA_CODE = "0086";

    public static final String TIME = "0";
    public static final String TYPE = "3";


    /**
     * Settings for Today Nic
     **/

    public static final String TODAY_NIC_KEY_SERVER = "VCPSERVER";
    public static final String TODAY_NIC_KEY_PORT = "VCPSVPORT";
    public static final String TODAY_NIC_KEY_USERID = "VCPUSERID";
    public static final String TODAY_NIC_KEY_PASSWD = "VCPPASSWD";

    public static final String ERROR = "-100";


    public static final String SMS_CHARSET = "gb2312";

    public static final String SMS_TODAYNIC = "S01";

    public static final String SMS_SYSIO = "S02";

    public static final String SMS_S03 = "S03";

    public static final String SMS_S04 = "S04";

    public static final String SMS_S05 = "S05";

    public static final String SMS_S06 = "S06";

    public static final String SMS_S07 = "S07";

    public static final String SMS_S08 = "S08";

    public static final String SMS_S09 = "S09";

    public static final String SMS_S10 = "S10";

    public static final String SMS_S11 = "S11";

    public static final String SMS_S12 = "S12";

    public static final String SMS_S13 = "S13";

    public static final String SMS_S14 = "S14";

    public static final String SMS_S15 = "S15";

    public static final String SMS_S16 = "S16";

    public static final String SMS_S17 = "S17";

    public static final String SMS_S18 = "S18";

    public static final String SMS_S19 = "S19";

    public static final String SMS_S20 = "S20";

    public static final String SMS_S21 = "S21";

    public static final String SMS_S22 = "S22";

    public static final String SMS_S23 = "S23";

    public static final String SMS_S24 = "S24";

    public static final String SMS_S25 = "S25";

    public static final String SMS_S26 = "S26";

    public static final String SMS_S27 = "S27";

    public static final String SMS_S28 = "S28";

    public static final String SMS_S29 = "S29";

    public static final String SMS_S30 = "S30";

    public static final String SMS_S31 = "S31";

    public static final String SMS_S32 = "S32";

    public static final String SMS_S33 = "S33";

    public static final String SMS_S34= "S34";

    public static final String SMS_S35= "S35";

    public static final String SMS_S36= "S36";

    public static final String SMS_S37= "S37";
    public static final String SMS_S80= "S80";
    public static final String SMS_S81= "S81";
    public static final String SMS_S82= "S82";
    public static final String SMS_S83= "S83";
    public static final String SMS_S84= "S84";
    public static final String SMS_S85= "S85";
    public static final String SMS_S86= "S86";

    public static final String TEMPLATE_FLAG_ENABLE = "0";

    public static final String ACTION = "send";

    public static final int SUCCESS_ONE = 1;

    public static final int BATCH_SIZE = 20;

    public static final int MAX_TEMPLATE_PARAMETER_COUNT = 10;

    public static final String RESPONSE_CODE = "RetCode";

    public static final String SUCCESS_S04_S05 = "Sucess";
    /**
     * SEPARATORS
     */

    public static final String TEMPLATE_PARAMETER_MARKER = "|";
    public static final String NUMBERS_SEPARATOR = ",";
    public static final String SEPARATOR = ";";

    /**
     * VALIDATION MESSAGE FORMAT
     */

    public static final String VALIDATE_REQUIRED = "The field under validation is required:[%s]";
    public static final Object SUCCESS = "SUCCESS";

    public static final String RESPONSE_STATUS = "returnstatus";
    public static final String EXECUTE_SUCCESS = "1";
    public static final String EXECUTE_ERROR = "0";

    public static final String CHECK_CONTENTS = "1";

    public static final String EXECUTE_EXCEPTION = "-1";
    public static final String PARAMETERS_CAN_NOT_BE_NULL = "000001";

    public static final Integer SYSTEM_INFO_COUNT_LIMIT = 30;
    public static final Integer HEALTH_COUNT_LIMIT = 100;

    public static final String SUCCESS_2000 = "2000";
}