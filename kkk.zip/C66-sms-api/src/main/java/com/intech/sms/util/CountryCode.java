package com.intech.sms.util;

/**
 * 
 * @author kaiser.dapar
 *
 */
public class CountryCode {
	public static final String CHINA_1 = "86";
	public static final String CHINA_2 = "0086";

	public static final String CHINA_TAIWAN_1="886";
	public static final String CHINA_TAIWAN_2="00886";
	
	public static final String MACAU_1 = "853";
	public static final String MACAU_2 = "00853";
	
	public static final String KOREA_1 = "82";
	public static final String KOREA_2 = "0082";
	
	public static final String HONG_KONG_1 = "852";
	public static final String HONG_KONG_2 = "00852";

	public static final String PHILIPPINES_1 = "63";
	public static final String PHILIPPINES_2 = "0063";
	
	public static final String VIETNAM_1 = "84";
	public static final String VIETNAM_2 = "0084";

	public static final String JAPAN_1 = "81";
	public static final String JAPAN_2 = "0081";

	public static final String THAI_1 = "66";
	public static final String THAI_2 = "0066";
	
}
