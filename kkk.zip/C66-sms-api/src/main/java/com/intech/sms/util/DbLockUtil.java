package com.intech.sms.util;

import com.intech.sms.dao.UniversalDAO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;
import java.util.UUID;

/**
 * @author Condi
 */
public class DbLockUtil {

    private static final Logger logger = LoggerFactory.getLogger(DbLockUtil.class);
    /**
     * 加锁
     * @return
     */
    public static boolean lock(){
        MDC.put("uuid", UUID.randomUUID().toString());
        boolean res = false;
        try {
            UniversalDAO smsOperateDao = ApplicationContextSingleton.getBean(UniversalDAO.class);
            res = smsOperateDao.update("update t_sms_constant set CONSTANT_VALUE='1',LASTUPT_DATE=sysdate where PRODUCT_ID='ALL' and CONSTANT_KEY='MQ_RESEND_LOCK' and CONSTANT_VALUE='0'")==1;
            if(!res){
                logger.info("["+Thread.currentThread().getName()+"]get the lock failed!");
                //没有获取到锁
                //判断是否长时间(30min)被锁住了，导致所有人都无法获取到锁
                try{
                    int count = smsOperateDao.object("SELECT count(1) FROM t_sms_constant WHERE PRODUCT_ID='ALL' and CONSTANT_KEY='MQ_RESEND_LOCK' and CONSTANT_VALUE='1' and LASTUPT_DATE<sysdate-(30/1440)", new RowMapper() {
                        @Override
                        public Object mapRow(ResultSet resultSet, int index) throws SQLException {
                            return resultSet.getInt(1);
                        }
                    });
                    if(count>0){
                        logger.info("the MQ_RESEND_LOCK is locked for a long time ,["+Thread.currentThread().getName()+"]try to unlock !!!!!!!!!!!!");
                        unLock(true);
                    }
                }catch (Exception e){
                    logger.error(e.getMessage(),e);
                }
            }else{
                logger.info("["+Thread.currentThread().getName()+"]get the lock success!");
            }
        }catch (Exception e){
            logger.error(e.getMessage(),e);
        }
        return res;
    }
    /**
    * 解锁
    * @param: [isTimeOut]
    * @return: boolean
    * @throws:
    * @Author: "Condi"
    * @Date: 2018/11/26
    */
    public static boolean unLock(boolean isTimeOut){
        boolean res = false;
        try {
            String sql="update t_sms_constant set CONSTANT_VALUE='0',LASTUPT_DATE=sysdate where PRODUCT_ID='ALL' and CONSTANT_KEY='MQ_RESEND_LOCK' and CONSTANT_VALUE='1'";
            if(isTimeOut){
                sql+=" and LASTUPT_DATE<sysdate-(30/1440)";
            }
            UniversalDAO smsOperateDao = ApplicationContextSingleton.getBean(UniversalDAO.class);
            res = smsOperateDao.update(sql)==1;
        }catch (Exception e){
            logger.error(e.getMessage(),e);
        }
        if(res){
            logger.info("["+Thread.currentThread().getName()+"]unlock the lock success!");
        }else {
            logger.info("["+Thread.currentThread().getName()+"]unlock the lock failed!");
        }
        return res;
    }
}
