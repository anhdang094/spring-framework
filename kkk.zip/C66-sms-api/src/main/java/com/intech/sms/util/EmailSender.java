package com.intech.sms.util;

import java.util.Properties;

import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.intech.configuration.PropertiesConfig;
import org.apache.commons.codec.CharEncoding;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

@Component
public class EmailSender {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private PropertiesConfig propertiesConfig;


	public boolean send(String emailTo,String emailSubject,String emailContent) {
		boolean sent = false;
		try {
			Properties properties = new Properties();
			properties.setProperty("mail.smtp.auth", "true");
			properties.setProperty("mail.smtp.timeout", propertiesConfig.getEmailTimeout());
			properties.setProperty("mail.smtp.starttls.enable", "true");
			
			JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
			mailSender.setHost(propertiesConfig.getEmailServer());
			mailSender.setPort(Integer.parseInt(propertiesConfig.getEmailPort()));
			mailSender.setUsername(propertiesConfig.getEmailUserName());
			mailSender.setPassword(propertiesConfig.getEmailPassword());
			mailSender.setDefaultEncoding(CharEncoding.UTF_8);
			mailSender.setJavaMailProperties(properties);
			
			MimeMessage mailMessage = new MimeMessage(Session.getDefaultInstance(new Properties()));
		    MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mailMessage, true, CharEncoding.UTF_8);
			mimeMessageHelper.setTo(emailTo.split(", ?"));
			mimeMessageHelper.setSubject(emailSubject);
			mimeMessageHelper.setFrom(new InternetAddress(propertiesConfig.getEmailFrom(), propertiesConfig.getEmailDisplayName(), CharEncoding.UTF_8));
			mimeMessageHelper.setValidateAddresses(false);
			mimeMessageHelper.setText(emailContent, false);
		    MimeMessage mm = mimeMessageHelper.getMimeMessage();
		    
			mailSender.send(mm);
			sent = true;
			
		} catch (Exception e) {
			logger.error("发送邮件失败",e);
		}
		
		return sent;
	}
}