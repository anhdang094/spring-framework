package com.intech.sms.util;


/***************************************************************************
 * Module Name:        
 *      Author:   gary.l
 * Finish Date: 　Sept.20, 2012
 *     Version:   1.0
 * Funtion Description: 
 *　　发送短信服务的service
 *　Modify History:
 *<pre>
 *###########################################################################
 *　 Version　 　 Modify Date　　   Modify By        Description  
 *###########################################################################
 * v1.0        2012-09-20       gary            错误码常量
 *</pre>
 ****************************************************************************/
public class ErrorCodeConstants {
	public static final String ERROR_PRODUCT_ID_NULL="70001";//传送参数产品ID为空
	public static final String ERROR_SMS_TYPE_CODE_NULL="70002";//传送参数短信类型代号为空
	public static final String ERROR_SMS_PHONE_NULL="70003";//传送参数电话号码为空
	public static final String ERROR_SMS_KEY_NULL="70004";//传送参数密钥为空
	public static final String ERROR_TEMPLATE_FLAG_NULL="70008";//传送参数模板标志为空
	public static final String ERROR_CONTENT_NULL="79996";//发送内容为空
	public static final String ERROR_TEMPLATE_NULL="70007";//该类型没有模板
	public static final String ERROR_INSERT_ERROR="79999";//发送失败，参数传入不对
	public static final String ERROR_PARAM_ERROR  = "500%02d"; // 参数不能为空
	public static final String ERROR_SUCCESS_INSERT="80000";//发送成功
	public static final String ERROR_INSERT_LIST_NULL="79998";//批量插入内容为空
	public static final String ERROR_OVER_PHONE_LENGTH="70020";//传送参数电话号码为空

}