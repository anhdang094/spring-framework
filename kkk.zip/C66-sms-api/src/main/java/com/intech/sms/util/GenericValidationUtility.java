package com.intech.sms.util;

import java.util.Collection;

import org.apache.commons.lang3.StringUtils;


/***************************************************************************
 * System Name:   SMS System
 * Module Name:        
 *      Author:   Gary.l
 * Finish Date: 　Oct. 6, 2012
 *     Version:   1.0
 * Funtion Description: 
 *　　
 *　Modify History:
 *<pre>
 *###########################################################################
 *　 Version　 　 Modify Date　　   Modify By        Description  
 *###########################################################################
 *
 *</pre>        2012-10-6                 Validation String/Object Empty Tools
 ****************************************************************************/
public class GenericValidationUtility {

	/**
	 * Accepts a vargarg and check if 
	 * on member is null (or empty in case of String). 
	 */
	public static boolean hasEmpty(Object... obj) {	    
        for(Object o : obj) {    
            if(isHallow(o)){
				return true;
			}

        } 
        
        return false;
	}
	
	public static boolean hasNoEmpty(Object... obj) {
	    return !hasEmpty(obj);
	}
		
	public static boolean isEmpty(Object... obj) {
		for(Object o : obj) {
			if(!isHallow(o)){
				return false;
			}

		}
		
		return true;
	}
	
	public static boolean isNotEmpty(Object... obj) {
		return !isEmpty(obj);
	}
	
	@SuppressWarnings("rawtypes")
	public static boolean isHallow(Object o) {
        if(o instanceof String && StringUtils.isBlank((String) o)) {
            return true;
        }
        else if (o instanceof Collection && ((Collection) o).isEmpty()) {
        	return true;        	
        }
        else if(isNull(o)) {
            return true;
        }
        
        return false;
	}
	
	public static boolean isNotHallow(Object o) {
		return !isHallow(o);
	}
	
	
	
	/**
	 * Checks if the given object is null
	 * @param obj
	 * @return
	 */
	public static boolean isNull(Object obj) {
	    return (obj == null);
	}
}