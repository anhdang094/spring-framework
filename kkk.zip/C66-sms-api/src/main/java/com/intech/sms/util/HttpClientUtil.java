package com.intech.sms.util;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.*;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpRequestRetryHandler;
import org.apache.http.client.config.AuthSchemes;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.config.RequestConfig.Builder;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLException;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.*;
import java.net.*;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.*;

public class HttpClientUtil {
    protected final static Logger logger = LoggerFactory.getLogger(HttpClientUtil.class);
    // 默认请求编码
    private static final String DEFAULT_CHARSET = "UTF-8";
    // 默认等待响应时间(毫秒)
    private static final int DEFAULT_SOCKET_TIMEOUT = 10000;
    // 默认执行重试的次数
    private static final int DEFAULT_RETRY_TIMES = 0;
    private static final int DEFAULT_CONNECT_TIMEOUT = 5000;
    private static final int DEFAULT_CONNECT_REQUEST_TIMEOUT = 1000;

    private SSLConnectionSocketFactory socketFactory;

    private PoolingHttpClientConnectionManager connectionManager;

    private Integer httpMaxClientNum;

    private Integer httpMaxPerRoute;

    public void init() {
        // 开启HTTPS支持
        try {
            SSLContext context = SSLContext.getInstance("TLS");
            context.init(null, new TrustManager[]{manager}, null);
            socketFactory = new SSLConnectionSocketFactory(context, NoopHostnameVerifier.INSTANCE);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        // 创建可用Scheme
        Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder.<ConnectionSocketFactory>create().register("http", PlainConnectionSocketFactory.INSTANCE).register("https", socketFactory).build();
        // 创建ConnectionManager，添加Connection配置信息
        connectionManager = new PoolingHttpClientConnectionManager(socketFactoryRegistry);
        if (httpMaxClientNum != null) {
            // 设置最大的连接数
            connectionManager.setMaxTotal(httpMaxClientNum);
        }
        if (httpMaxPerRoute != null) {
            // 设置每个路由的基础连接数【默认，每个路由基础上的连接不超过2个，总连接数不能超过20】
            connectionManager.setDefaultMaxPerRoute(httpMaxPerRoute);
        }
    }

    /**
     * HTTPS网站一般情况下使用了安全系数较低的SHA-1签名，因此首先我们在调用SSL之前需要重写验证方法，取消检测SSL。
     */
    private TrustManager manager = new X509TrustManager() {

        @Override
        public X509Certificate[] getAcceptedIssuers() {
            return null;
        }

        @Override
        public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
            //

        }

        @Override
        public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
            //

        }
    };

    /**
     * 创建一个默认的可关闭的HttpClient
     *
     * @return
     */
    public CloseableHttpClient createHttpClient() {
        return createHttpClient(DEFAULT_RETRY_TIMES, DEFAULT_SOCKET_TIMEOUT);
    }

    /**
     * 创建一个可关闭的HttpClient
     *
     * @param socketTimeout 请求获取数据的超时时间
     * @return
     */
    public CloseableHttpClient createHttpClient(int socketTimeout) {
        return createHttpClient(DEFAULT_RETRY_TIMES, socketTimeout);
    }

    /**
     * 创建一个可关闭的HttpClient
     *
     * @param socketTimeout 请求获取数据的超时时间
     * @param retryTimes    重试次数，小于等于0表示不重试
     * @return
     */
    private CloseableHttpClient createHttpClient(int retryTimes, int socketTimeout) {
        Builder builder = RequestConfig.custom();
        builder.setConnectTimeout(DEFAULT_CONNECT_TIMEOUT);
        builder.setConnectionRequestTimeout(DEFAULT_CONNECT_REQUEST_TIMEOUT);
        if (socketTimeout >= 0) {
            builder.setSocketTimeout(socketTimeout);
        }
        RequestConfig defaultRequestConfig = builder.setCookieSpec(CookieSpecs.STANDARD_STRICT).setExpectContinueEnabled(true).setTargetPreferredAuthSchemes(Arrays.asList(AuthSchemes.NTLM, AuthSchemes.DIGEST)).setProxyPreferredAuthSchemes(Arrays.asList(AuthSchemes.BASIC)).build();

        HttpClientBuilder httpClientBuilder = HttpClients.custom();
        if (retryTimes > 0) {
            setRetryHandler(httpClientBuilder, retryTimes);
        }

        CloseableHttpClient httpClient = httpClientBuilder.setConnectionManager(connectionManager).setDefaultRequestConfig(defaultRequestConfig).build();
        return httpClient;
    }

    public String get(String url) {
        CloseableHttpClient httpClient = createHttpClient();
        try {
            return executeGet(httpClient, url, null, null, DEFAULT_CHARSET, true, null);
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
        }
        return null;
    }

    public String get(String url, Map<String, String> params, int socketTimeout) throws IOException {
        CloseableHttpClient httpClient = createHttpClient(0, socketTimeout);
        String finalUrl = handleParams(url, params);
        logger.info("发送http请求url：{}", finalUrl);
        return executeGet(httpClient, finalUrl, null, null, DEFAULT_CHARSET, true, null);
    }

    private String handleParams(String url, Map<String, String> params) {
        StringBuffer sb = new StringBuffer(url);
        if (!url.contains("?")) {
            sb.append("?");
        }
        params.forEach((k, v) -> {
            sb.append(k).append("=").append(v).append("&");
        });
        sb.delete(sb.length() - 1, sb.length());
        return sb.toString();
    }

    public String get(String url, Map<String, String> params) throws IOException {
        CloseableHttpClient httpClient = createHttpClient();
        try {
            String finalUrl = handleParams(url, params);
            logger.info("发送http请求url：{}", finalUrl);
            return executeGet(httpClient, finalUrl, null, null, DEFAULT_CHARSET, true, null);
        } catch (IOException e) {
            throw e;
        }
    }

    public String get(String url, Map<String, String> params, String authCode) throws IOException {
        CloseableHttpClient httpClient = createHttpClient();
        try {
            String finalUrl = handleParams(url, params);
            logger.info("发送http请求url：{}", finalUrl);
            return executeGet(httpClient, finalUrl, null, null, DEFAULT_CHARSET, true, authCode);
        } catch (IOException e) {
            throw e;
        }
    }

    public int URLGetResponse(String url, Map<String, String> params, String charset) {
        CloseableHttpClient httpClient = createHttpClient();
        try {
            String finalUrl = handleParams(url, params);
            logger.info("发送http请求url：{}", finalUrl);
            CloseableHttpResponse httpResponse = null;
            try {
                charset = getCharset(charset);
                httpResponse = executeGetResponse(httpClient, url, null, null, null);
                int code = httpResponse.getStatusLine().getStatusCode();

                logger.info("http 返回内容：{}", getResult(httpResponse, charset));
                return code;
            } finally {
                if (httpResponse != null) {
                    try {
                        httpResponse.close();
                    } catch (Exception e) {
                        logger.error(e.getMessage(), e);
                    }
                }
                if (httpClient != null) {
                    try {
                        httpClient.close();
                    } catch (Exception e) {
                        logger.error(e.getMessage(), e);
                    }
                }
            }
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
        }
        return HttpStatus.SC_INTERNAL_SERVER_ERROR;
    }

    public List URLGet(String strUrl, Map map, String charset) throws IOException {
        if (map != null && !StringUtils.isBlank(strUrl)) {
            List result = new ArrayList();
            URL url = new URL(strUrl + "?" + formatParams(map));
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setUseCaches(false);
            HttpURLConnection.setFollowRedirects(true);
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));

            String l;
            while (StringUtils.isNotBlank(l = in.readLine())) {
                result.add(l);
            }

            in.close();
            return result;
        } else {
            return null;
        }
    }

    private String formatParams(Map map) {
        if (map != null && map.keySet().size() != 0) {
            StringBuffer url = new StringBuffer();
            Set keys = map.keySet();
            Iterator i = keys.iterator();

            while (i.hasNext()) {
                String key = String.valueOf(i.next());
                if (map.containsKey(key)) {
                    url.append(key).append("=").append(String.valueOf(map.get(key))).append("&");
                }
            }

            String strURL = "";
            strURL = url.toString();
            if ("&".equals("" + strURL.charAt(strURL.length() - 1))) {
                strURL = strURL.substring(0, strURL.length() - 1);
            }

            return strURL;
        } else {
            return "";
        }
    }

    /**
     * 执行HttpGet请求
     *
     * @param httpClient      HttpClient客户端实例，传入null会自动创建一个
     * @param url             请求的远程地址
     * @param referer         referer信息，可传null
     * @param cookie          cookies信息，可传null
     * @param charset         请求编码，默认UTF8
     * @param closeHttpClient 执行请求结束后是否关闭HttpClient客户端实例
     * @return HttpResult
     * @throws ClientProtocolException
     * @throws IOException
     */
    private String executeGet(CloseableHttpClient httpClient, String url, String referer, String cookie, String charset, boolean closeHttpClient, String authCode) throws IOException {
        CloseableHttpResponse httpResponse = null;
        try {
            charset = getCharset(charset);
            httpResponse = executeGetResponse(httpClient, url, referer, cookie, authCode);
            return getResult(httpResponse, charset);
        } finally {
            if (httpResponse != null) {
                try {
                    httpResponse.close();
                } catch (Exception e) {
                    logger.error(e.getMessage(), e);
                }
            }
            if (closeHttpClient && httpClient != null) {
                try {
                    httpClient.close();
                } catch (Exception e) {
                    logger.error(e.getMessage(), e);
                }
            }
        }
    }

    /**
     * @param httpClient httpclient对象
     * @param url        执行GET的URL地址
     * @param referer    referer地址
     * @param cookie     cookie信息
     * @return CloseableHttpResponse
     * @throws IOException
     */
    public CloseableHttpResponse executeGetResponse(CloseableHttpClient httpClient, String url, String referer, String cookie, String authCode) throws IOException {
        if (httpClient == null) {
            httpClient = createHttpClient();
        }
        HttpGet get = new HttpGet(url);
        if (cookie != null && !"".equals(cookie)) {
            get.setHeader("Cookie", cookie);
        }
        if (referer != null && !"".equals(referer)) {
            get.setHeader("referer", referer);
        }
        if (authCode != null && !"".equals(authCode)) {
            get.setHeader("auth_code", authCode);
        }
        return httpClient.execute(get);
    }

    public String post(String url, Map<String, String> params, int timeout) throws IOException {
        CloseableHttpClient httpClient = createHttpClient(timeout);
        return executePost(httpClient, url, params, null, null, DEFAULT_CHARSET, true);
    }

    public String post(String url, Map<String, String> params) throws IOException {
        CloseableHttpClient httpClient = createHttpClient();
        return executePost(httpClient, url, params, null, null, DEFAULT_CHARSET, true);
    }

    public String post(String url, Map<String, String> header, Map<String, String> params) throws IOException {
        //默认10秒查询超时设置
        int timeout = 10000;
        CloseableHttpClient httpClient = createHttpClient(timeout);
        return executePost(httpClient, url, header, params, null, null, DEFAULT_CHARSET, true);
    }

    public String post(String url, String params) throws IOException {
        CloseableHttpClient httpClient = createHttpClient();
        return executePost(httpClient, url, params, null, null, DEFAULT_CHARSET, true);
    }

    public String post(String url, String params, String userName, String pwd) throws IOException {
        CloseableHttpClient httpClient = createHttpClient();
        return executePost(httpClient, url, params, null, null, DEFAULT_CHARSET, true, userName, pwd);
    }

    public String post(String url, String params, Map<String, String> header) throws IOException {
        CloseableHttpClient httpClient = createHttpClient();
        return executePost(httpClient, url, header, params, null, null, DEFAULT_CHARSET, true);
    }

    public String post(String url, String params, int timeout) throws IOException {
        CloseableHttpClient httpClient = createHttpClient(timeout);
        return executePost(httpClient, url, params, null, null, DEFAULT_CHARSET, true);
    }

    public String doPostWithAgent(String url, Map<String, String> params) throws IOException {
        Map<String, String> header = new HashMap<>(1);
        header.put("User-Agent", "LinkGIuiowe@520*&ldjiwuek");
        return post(url, header, params);
    }

    /**
     * 执行HttpPost请求
     *
     * @param httpClient      HttpClient客户端实例，传入null会自动创建一个
     * @param url             请求的远程地址
     * @param paramsObj       提交的参数信息，目前支持Map,和String(JSON\xml)
     * @param referer         referer信息，可传null
     * @param cookie          cookies信息，可传null
     * @param charset         请求编码，默认UTF8
     * @param closeHttpClient 执行请求结束后是否关闭HttpClient客户端实例
     * @return
     * @throws IOException
     * @throws ClientProtocolException
     */
    private String executePost(CloseableHttpClient httpClient, String url, Object paramsObj, String referer, String cookie, String charset, boolean closeHttpClient) throws IOException {
        CloseableHttpResponse httpResponse = null;
        try {
            charset = getCharset(charset);
            httpResponse = executePostResponse(httpClient, url, paramsObj, referer, cookie, charset);
            return getResult(httpResponse, charset);
        } finally {
            if (httpResponse != null) {
                try {
                    httpResponse.close();
                } catch (Exception e2) {
                    logger.error(e2.getMessage(), e2);
                }
            }
            if (closeHttpClient && httpClient != null) {
                try {
                    httpClient.close();
                } catch (Exception e2) {
                    logger.error(e2.getMessage(), e2);
                }
            }
        }
    }

    private String executePost(CloseableHttpClient httpClient, String url, Object paramsObj, String referer, String cookie, String charset, boolean closeHttpClient, String username, String pwd) throws IOException {
        CloseableHttpResponse httpResponse = null;
        try {
            charset = getCharset(charset);
            httpResponse = executePostResponse(httpClient, url, paramsObj, referer, cookie, charset, username, pwd);
            return getResult(httpResponse, charset);
        } finally {
            if (httpResponse != null) {
                try {
                    httpResponse.close();
                } catch (Exception e2) {
                    logger.error(e2.getMessage(), e2);
                }
            }
            if (closeHttpClient && httpClient != null) {
                try {
                    httpClient.close();
                } catch (Exception e2) {
                    logger.error(e2.getMessage(), e2);
                }
            }
        }
    }

    /**
     * 执行HttpPost请求
     *
     * @param httpClient      HttpClient客户端实例，传入null会自动创建一个
     * @param url             请求的远程地址
     * @param paramsObj       提交的参数信息，目前支持Map,和String(JSON\xml)
     * @param referer         referer信息，可传null
     * @param cookie          cookies信息，可传null
     * @param charset         请求编码，默认UTF8
     * @param closeHttpClient 执行请求结束后是否关闭HttpClient客户端实例
     * @return
     * @throws IOException
     * @throws ClientProtocolException
     */
    private String executePost(CloseableHttpClient httpClient, String url, Map<String, String> header, Object paramsObj, String referer, String cookie, String charset, boolean closeHttpClient) throws IOException {
        CloseableHttpResponse httpResponse = null;
        try {
            charset = getCharset(charset);
            httpResponse = executePostResponse(httpClient, header, url, paramsObj, referer, cookie, charset);
            return getResult(httpResponse, charset);
        } finally {
            if (httpResponse != null) {
                try {
                    httpResponse.close();
                } catch (Exception e2) {
                    logger.error(e2.getMessage(), e2);
                }
            }
            if (closeHttpClient && httpClient != null) {
                try {
                    httpClient.close();
                } catch (Exception e2) {
                    logger.error(e2.getMessage(), e2);
                }
            }
        }
    }

    /**
     * @param httpClient HttpClient对象
     * @param url        请求的网络地址
     * @param paramsObj  参数信息
     * @param referer    来源地址
     * @param cookie     cookie信息
     * @param charset    通信编码
     * @return CloseableHttpResponse
     * @throws IOException
     */
    private CloseableHttpResponse executePostResponse(CloseableHttpClient httpClient, String url, Object paramsObj, String referer, String cookie, String charset) throws IOException {
        if (httpClient == null) {
            httpClient = createHttpClient();
        }
        HttpPost post = new HttpPost(url);
        if (cookie != null && !"".equals(cookie)) {
            post.setHeader("Cookie", cookie);
        }
        if (referer != null && !"".equals(referer)) {
            post.setHeader("referer", referer);
        }
        // 设置参数
        HttpEntity httpEntity = getEntity(paramsObj, charset);
        if (httpEntity != null) {
            post.setEntity(httpEntity);
        }
        return httpClient.execute(post);
    }

    private CloseableHttpResponse executePostResponse(CloseableHttpClient httpClient, String url, Object paramsObj, String referer, String cookie, String charset, String userName, String pwd) throws IOException {
        if (httpClient == null) {
            httpClient = createHttpClient();
        }
        HttpPost post = new HttpPost(url);
        if (cookie != null && !"".equals(cookie)) {
            post.setHeader("Cookie", cookie);
        }
        if (referer != null && !"".equals(referer)) {
            post.setHeader("referer", referer);
        }
        HttpClientContext context = new HttpClientContext();
        if (StringUtils.isNotEmpty(userName) && StringUtils.isNotEmpty(pwd)) {
            CredentialsProvider provider = new BasicCredentialsProvider();
            provider.setCredentials(AuthScope.ANY, new UsernamePasswordCredentials(userName, pwd));
            context.setCredentialsProvider(provider);
        }
        // 设置参数
        HttpEntity httpEntity = getEntity(paramsObj, charset);
        if (httpEntity != null) {
            post.setEntity(httpEntity);
        }
        if (StringUtils.isNotEmpty(userName) && StringUtils.isNotEmpty(pwd)) {
            return httpClient.execute(post, context);
        }
        return httpClient.execute(post);
    }

    /**
     * @param httpClient HttpClient对象
     * @param url        请求的网络地址
     * @param paramsObj  参数信息
     * @param referer    来源地址
     * @param cookie     cookie信息
     * @param charset    通信编码
     * @return CloseableHttpResponse
     * @throws IOException
     */
    private CloseableHttpResponse executePostResponse(CloseableHttpClient httpClient, Map<String, String> header, String url, Object paramsObj, String referer, String cookie, String charset) throws IOException {
        if (httpClient == null) {
            httpClient = createHttpClient();
        }
        HttpPost post = new HttpPost(url);

        //设置header
        header.forEach((k, v) -> post.setHeader(k, v));

        // 设置参数
        HttpEntity httpEntity = getEntity(paramsObj, charset);
        if (httpEntity != null) {
            post.setEntity(httpEntity);
        }
        return httpClient.execute(post);
    }

    /**
     * 根据参数获取请求的Entity
     *
     * @param paramsObj
     * @param charset
     * @return
     * @throws UnsupportedEncodingException
     */
    private HttpEntity getEntity(Object paramsObj, String charset) throws UnsupportedEncodingException {
        if (paramsObj == null) {
            return null;
        }
        if (Map.class.isInstance(paramsObj)) {// 当前是map数据

            Map<String, String> paramsMap = (Map<String, String>) paramsObj;
            List<NameValuePair> list = getNameValuePairs(paramsMap);
            UrlEncodedFormEntity httpEntity = new UrlEncodedFormEntity(list, charset);
            httpEntity.setContentType(ContentType.APPLICATION_FORM_URLENCODED.getMimeType());
            return httpEntity;
        } else if (String.class.isInstance(paramsObj)) {// 当前是string对象，可能是
            String paramsStr = (String) paramsObj;
            StringEntity httpEntity = new StringEntity(paramsStr, charset);
            if (paramsStr.startsWith("{") || paramsStr.startsWith("[{")) {
                httpEntity.setContentType(ContentType.APPLICATION_JSON.getMimeType());
            } else if (paramsStr.startsWith("<")) {
                httpEntity.setContentType(ContentType.APPLICATION_XML.getMimeType());
            } else {
                httpEntity.setContentType(ContentType.APPLICATION_FORM_URLENCODED.getMimeType());
            }
            return httpEntity;
        } else {
        }
        return null;
    }

    /**
     * 从结果中获取出String数据
     *
     * @param httpResponse http结果对象
     * @param charset      编码信息
     * @return String
     * @throws ParseException
     * @throws IOException
     */
    private String getResult(CloseableHttpResponse httpResponse, String charset) throws ParseException, IOException {
        String result = null;
        if (httpResponse == null) {
            return result;
        }
        HttpEntity entity = httpResponse.getEntity();
        if (entity == null) {
            return result;
        }
        result = EntityUtils.toString(entity, charset);
        EntityUtils.consume(entity);// 关闭应该关闭的资源，适当的释放资源 ;也可以把底层的流给关闭了
        return result;
    }

    /**
     * 转化请求编码
     *
     * @param charset 编码信息
     * @return String
     */
    private String getCharset(String charset) {
        return charset == null ? DEFAULT_CHARSET : charset;
    }

    /**
     * 将map类型参数转化为NameValuePair集合方式
     *
     * @param paramsMap
     * @return
     */
    private List<NameValuePair> getNameValuePairs(Map<String, String> paramsMap) {
        List<NameValuePair> list = new ArrayList<>();
        if (paramsMap == null || paramsMap.isEmpty()) {
            return list;
        }
        for (Map.Entry<String, String> entry : paramsMap.entrySet()) {
            list.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
        }
        return list;
    }


    public String postXml(String urlString, String xml) {
        StringBuffer response = new StringBuffer("");
        BufferedReader br = null;
        try {
            URL url = new URL(urlString);
            URLConnection uc = url.openConnection();
            HttpURLConnection connection = (HttpURLConnection) uc;
            connection.setDoOutput(true);
            connection.setDoInput(true);
            connection.setRequestMethod("POST");

            OutputStream out = connection.getOutputStream();
            Writer wout = new OutputStreamWriter(out);

            wout.write(xml);
            wout.flush();
            wout.close();

            InputStream in = connection.getInputStream();

            br = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            String tempStr = "";

            while ((tempStr = br.readLine()) != null) {
                response.append(tempStr);
            }

            connection.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (Exception e) {

                }

            }
        }

        return response.toString();
    }

    /**
     * 为httpclient设置重试信息
     *
     * @param httpClientBuilder
     * @param retryTimes
     */
    private void setRetryHandler(HttpClientBuilder httpClientBuilder, final int retryTimes) {
        HttpRequestRetryHandler myRetryHandler = new HttpRequestRetryHandler() {
            @Override
            public boolean retryRequest(IOException exception, int executionCount, HttpContext context) {
                if (executionCount >= retryTimes) {
                    // Do not retry if over max retry count
                    return false;
                }
                if (exception instanceof InterruptedIOException) {
                    // Timeout
                    return false;
                }
                if (exception instanceof UnknownHostException) {
                    // Unknown host
                    return false;
                }
                if (exception instanceof ConnectTimeoutException) {
                    // Connection refused
                    return false;
                }
                if (exception instanceof SSLException) {
                    // SSL handshake exception
                    return false;
                }
                HttpClientContext clientContext = HttpClientContext.adapt(context);
                HttpRequest request = clientContext.getRequest();
                boolean idempotent = !(request instanceof HttpEntityEnclosingRequest);
                return idempotent;
            }
        };
        httpClientBuilder.setRetryHandler(myRetryHandler);
    }


    public final String encode(String message, String encoding) {
        if (StringUtils.isNotBlank(message) && StringUtils.isNotBlank(encoding)) {
            try {
                return URLEncoder.encode(message, encoding);
            } catch (UnsupportedEncodingException var3) {
                return "";
            }
        } else {
            return "";
        }
    }

    public void setHttpMaxClientNum(Integer httpMaxClientNum) {
        this.httpMaxClientNum = httpMaxClientNum;
    }

    public void setHttpMaxPerRoute(Integer httpMaxPerRoute) {
        this.httpMaxPerRoute = httpMaxPerRoute;
    }
}