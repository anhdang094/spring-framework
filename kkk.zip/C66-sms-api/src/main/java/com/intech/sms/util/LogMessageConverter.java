package com.intech.sms.util;


import ch.qos.logback.classic.pattern.MessageConverter;
import ch.qos.logback.classic.spi.ILoggingEvent;

/**
 * @description:
 * @author: Condi
 * @create: 2019-02-01 15:49
 **/

public class LogMessageConverter extends MessageConverter {

    @Override
    public String convert(ILoggingEvent event) {
        if (event.getLoggerName().equalsIgnoreCase(com.intech.tracing.TraceLogger.class.getName())
                || event.getLoggerName().equalsIgnoreCase("c.i.t.TraceLogger")) {
            return event.getMessage();
        }
        String message = event.getFormattedMessage();
        message = message.replaceAll("(\\w)+(\\.\\w+)*@(\\w)+((\\.\\w+)+)", "***");
        message = message.replaceAll("(\\d{3})(\\d{10,13})(\\d{3}\\\\*)", "***");
        message = message.replaceAll("\\d{11}", "***");
        message = message.replaceAll("(\\d{3})(\\d{11,14})(\\w{1})", "***");
        return message;
    }
}


    
