/*
 *
 */
package com.intech.sms.util;




/**
 * @author david.z
 * 
 * 
 */
public class NumberUtils {

	
	public static Integer toInteger(Object o) {

		if (o == null) {
			return Integer.valueOf(0);
		}
		try {
			String str = o.toString();
			str = str.replaceAll(",", "");
			return Integer.valueOf(Math.round(toDouble(str.trim()).floatValue()));
		} catch (NumberFormatException e) {
			return Integer.valueOf(0);
		}
	}


	
	public static Double toDouble(Object o) {

		if (o == null) {
			return Double.valueOf(0);
		}
		try {
			String str = o.toString();
			str = str.replaceAll(",", "");
			Double i = Double.valueOf(str.trim());
			return i;
		} catch (NumberFormatException e) {
			return Double.valueOf(0);
		}
	}
	
	public static Long toLong(Object o) {

		if (o == null) {
			return Long.valueOf(0);
		}
		try {
			String str = o.toString();
			str = str.replaceAll(",", "");
			Long i = Long.valueOf(str.trim());
			return i;
		} catch (NumberFormatException e) {
			return Long.valueOf(0);
		}
	}



}
