package com.intech.sms.util;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author david.z
 *
 */
public class ObjectUtil<T> {

	
	

    /**
     * 
     * @param listObject
     * @param threadNo
     * @return
     */
	public  List<List<T>> parseObjectGroups(List<T> listObject, int threadNo) {
		if(listObject==null){
			return null;
		}

		List<List<T>> dd = new ArrayList<List<T>>();
        if(listObject.size()==0){
        	return dd;
        }
		if (threadNo <= 0) {
			List<T>  listt=new ArrayList<T>();
			for (int i = 0; i < listObject.size(); i++) {
				listt.add(listObject.get(i));
			}
			dd.add(listt);
			return dd;
		}
		if (listObject.size() < threadNo) {
			List<T>  listt=new ArrayList<T>();
			for (int i = 0; i < listObject.size(); i++) {
				listt.add(listObject.get(i));
			}
			dd.add(listt);
			return dd;
		} else {
			int thread = listObject.size() % threadNo == 0 ? threadNo
					: threadNo + 1;
			int my = listObject.size() / threadNo;
			for (int i = 0; i < thread; i++) {
				List<T> ss = new ArrayList<T>();
				if (i * my < listObject.size()) {
					if ((i + 1) * my > listObject.size()) {
						for (int k = i * my; k < listObject.size(); k++) {
							ss.add(listObject.get(k));
						}
						dd.add(ss);
					} else {
						if (i == thread - 1) {
							for (int k = i * my; k < listObject.size(); k++) {
								ss.add(listObject.get(k));
							}
							dd.add(ss);
						} else {
							for (int k = i * my; k < (i + 1) * my; k++) {
							
								ss.add(listObject.get(k));
							}
							dd.add(ss);
						}
					}

				} else {
					List<T> cc = new ArrayList<T>();
					for (i = (i - 1) * my; i < listObject.size(); i++) {
						cc.add(listObject.get(i));
					}
					dd.add(cc);
				}
			}
			return dd;
		}
	}
	
}
