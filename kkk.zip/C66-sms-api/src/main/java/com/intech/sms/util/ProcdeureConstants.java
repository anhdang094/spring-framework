package com.intech.sms.util;


/***************************************************************************
 * Module Name:        
 *      Author:   gary.l
 * Finish Date: 　Sept.20, 2012
 *     Version:   1.0
 * Funtion Description: 
 *　　发送短信服务的service
 *　Modify History:
 *<pre>
 *###########################################################################
 *　 Version　 　 Modify Date　　   Modify By        Description  
 *###########################################################################
 * v1.0        2012-09-20       gary            存储过程名称及常量
 *</pre>
 ****************************************************************************/
public class ProcdeureConstants {
	public static final String PROCEDURE_TEMPLATE_CONFIG="PACK_SENDSMS_HANDLE.getContentTemplateConfig";//模板配置存储过程
	public static final String PROCEDURE_CREATE_SMS="PACK_SENDSMS_HANDLE.create_sms_content";//创建短信内容存储过程
	public static final String PROCEDURE_CREATE_BATCH_SMS="PACK_SENDSMS_HANDLE.create_batch_sms_content";//创建短信内容存储过程

}