package com.intech.sms.util;

import org.apache.commons.lang3.StringUtils;

public class ProductConstants {
	
	public static final String PRODUCT_ID_C07 = "C07";
	public static final String PRODUCT_ID_C31 = "C31";
	public static final String PRODUCT_ID_V84 = "V84";
	public static final String PRODUCT_ID_V66 = "V66";

	public static String getDefaultCountryCode(String paramCountryCode,String productId){
		if(StringUtils.isNotBlank(paramCountryCode)){
			return paramCountryCode.replaceAll("00","");
		}

		String returnStr = CountryCode.CHINA_1;

		if (PRODUCT_ID_C07.equalsIgnoreCase(productId)||PRODUCT_ID_V84.equalsIgnoreCase(productId)) {
			returnStr =CountryCode.VIETNAM_1;
		}else if (ProductConstants.PRODUCT_ID_C31.equalsIgnoreCase(productId)) {
			returnStr =CountryCode.JAPAN_1;
		}else if (ProductConstants.PRODUCT_ID_V66.equalsIgnoreCase(productId)) {
			returnStr =CountryCode.THAI_1;
		}
		return returnStr;

	}


}
