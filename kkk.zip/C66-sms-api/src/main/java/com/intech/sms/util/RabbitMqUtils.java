package com.intech.sms.util;

import com.alibaba.fastjson.JSONObject;
import com.intech.sms.constants.MqTypeEnum;
import com.intech.sms.constants.ValidEnum;
import com.intech.sms.facade.MsgMqFacade;
import com.intech.sms.model.MsgMqSendRecord;
import com.intech.sms.model.Reply;
import com.intech.sms.model.SmsConstant;
import com.intech.sms.service.MQCallBack;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

/**
 * @author Herman.T
 */
@SuppressWarnings("unchecked")
public class RabbitMqUtils {

    private static final Logger logger = LoggerFactory.getLogger(RabbitMqUtils.class);

    public static void send(String productId, String exchange, String message, String routingKey, MQCallBack callBack, Reply reply) {
        try {
            if(normalSend(exchange,message,routingKey)){
                callBack.afterSuccessDo(reply);
            }
        } catch (Exception e) {
            logger.error(String.format("发送Rabbit消息失败！routingKey:%s,消息内容：%s。", routingKey, message), e);
            SmsConstant recordConstant = ConstantUtil.getSmsConstantByKey(productId, "MQ_SEND_FAIL_FLAG");
            if (recordConstant != null && ValidEnum.ENABLE.getCode().equals(recordConstant.getConstantValue())) {
                // 发送失败添加jms消息发送数据库记录
                try {
                    MsgMqFacade msgMqFacade = ApplicationContextSingleton.getBean(MsgMqFacade.class);
                    MsgMqSendRecord bean = new MsgMqSendRecord();
                    bean.setProductId(productId);
                    bean.setRabbitExchangeName(exchange);
                    bean.setRabbitRoutingKey(routingKey);
                    bean.setMsgData(message);
                    bean.setMsgType(Integer.valueOf(MqTypeEnum.RABBIT_MQ.getCode()));
                    msgMqFacade.createMsgMq(bean);
                } catch (Exception ex) {
                    logger.error(String.format("Rabbit消息发送失败，保存发送记录至数据库失败！exchange：%s， 消息内容：%s", exchange, message), e);
                }
            }
            callBack.afterFailDo(reply);
        }
    }

    /**
    * 补偿发送
    * @param: [productId, exchange, message, routingKey]
    * @return: void
    * @throws:
    * @Author: "Condi"
    * @Date: 2018/11/23
    */
    public static boolean normalSend(String exchange, String message, String routingKey) {
        boolean res = false;
        try {
            RabbitTemplate amqpTemplate = ApplicationContextSingleton.getBean(RabbitTemplate.class);
            JSONObject object = new JSONObject();
            object.put("routingKey", routingKey);
            object.put("msgContent", JSONObject.parse(message));
            amqpTemplate.convertAndSend(exchange, routingKey, object.toString());
            res=true;
            logger.info("发送Rabbit消息成功！routingKey:{},消息内容：{}。", routingKey, object.toString());
        } catch (Exception e) {
            logger.error("发送Rabbit消息失败！routingKey:{},消息内容：{}。", routingKey, message, e);
            throw  new RuntimeException(e);
        }
        return res;
    }

}