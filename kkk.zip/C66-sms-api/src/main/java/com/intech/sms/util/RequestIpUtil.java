package com.intech.sms.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;

/**
 * @description:
 * @author: Condi
 * @create: 2018-12-15 16:53
 **/

public class RequestIpUtil {

    /**
     * 获取IP地址相关常量
     */
    private final static String X_FORWARDED_FOR = "X-Forwarded-For";
    private final static String X_REAL_IP = "X-Real-IP";
    private final static String PROXY_CLIENT_IP = "Proxy-Client-IP";
    private final static String WL_PROXY_CLIENT_IP = "WL-Proxy-Client-IP";
    private final static String UNKNOWN = "unknown";
    public final static String localHost = "0:0:0:0:0:0:0:1";
    public final static String localIp = "127.0.0.1";

    private static final Logger logger = LoggerFactory.getLogger(RequestIpUtil.class);
    /**
     * 获取IP
     */
    public static String getIpAddress(HttpServletRequest request) {
        if (request == null) {
            return "";
        }
        String ipAddress = request.getHeader(X_FORWARDED_FOR);
        if(ipAddress != null && ipAddress.length() > 0 && !UNKNOWN.equalsIgnoreCase(ipAddress)){
            //多次反向代理后会有多个ip值，第一个ip才是真实ip
            int index = ipAddress.indexOf(",");
            if(index != -1){
                ipAddress = ipAddress.substring(0, index);
            }
        }
        if(ipAddress == null || ipAddress.length() == 0 || UNKNOWN.equalsIgnoreCase(ipAddress)){
            ipAddress = request.getHeader(X_REAL_IP);
        }
        if (ipAddress == null || ipAddress.length() == 0 || UNKNOWN.equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getHeader(PROXY_CLIENT_IP);
        }
        if (ipAddress == null || ipAddress.length() == 0 || UNKNOWN.equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getHeader(WL_PROXY_CLIENT_IP);
        }
        if (ipAddress == null || ipAddress.length() == 0 || UNKNOWN.equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getRemoteAddr();
        }
        return ipAddress;
    }

    //是否本机IP
    public static boolean isLocalIpAddress(HttpServletRequest request) {
        boolean accessFlag = false;
        try {
            String ip =   getIp();
            String requestIp =getIpAddress(request);
            if(requestIp.equals(ip)||RequestIpUtil.localHost.equals(requestIp)||RequestIpUtil.localIp.equals(requestIp)){
                accessFlag=true;
            }
        } catch (Exception e) {
            logger.error("获取本地IP失败",e);
        }
        return accessFlag;
    }

    public static String getIp() {
        Enumeration<NetworkInterface> netInterfaces;
        try {
            netInterfaces = NetworkInterface.getNetworkInterfaces();
        } catch (final SocketException ex) {
            return  null;
        }
        String localIpAddress = null;
        while (netInterfaces.hasMoreElements()) {
            NetworkInterface netInterface = netInterfaces.nextElement();
            Enumeration<InetAddress> ipAddresses = netInterface.getInetAddresses();
            while (ipAddresses.hasMoreElements()) {
                InetAddress ipAddress = ipAddresses.nextElement();
                if (isPublicIpAddress(ipAddress)) {
                    return ipAddress.getHostAddress();
                }
                if (isLocalIpAddress(ipAddress)) {
                    localIpAddress = ipAddress.getHostAddress();
                }
            }
        }
        return  localIpAddress;
    }

    private static boolean isLocalIpAddress(final InetAddress ipAddress) {
        return ipAddress.isSiteLocalAddress() && !ipAddress.isLoopbackAddress() && !isV6IpAddress(ipAddress);
    }
    private static boolean isPublicIpAddress(final InetAddress ipAddress) {
        return !ipAddress.isSiteLocalAddress() && !ipAddress.isLoopbackAddress() && !isV6IpAddress(ipAddress);
    }
    private static boolean isV6IpAddress(final InetAddress ipAddress) {
        return ipAddress.getHostAddress().contains(":");
    }
}


    
