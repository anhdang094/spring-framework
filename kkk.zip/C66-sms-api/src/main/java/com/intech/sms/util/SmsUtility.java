package com.intech.sms.util;

import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

import com.ws.SmsContent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author kaiser.dapar
 * @version 1.0, Mar 28, 2015
 */
public class SmsUtility {
	private static final Logger logger = LoggerFactory.getLogger(SmsUtility.class);

	public static String ipRegex = "【[\\u4e00-\\u9fa5_a-zA-Z0-9]+】";

	public static Pattern pattern=  Pattern.compile(ipRegex);

	public static String compose(String smsContentTemplate, SmsContent smsContent) throws Exception {
		
		if (StringUtils.isBlank(smsContentTemplate)) {
			throw new Exception(ErrorCodeConstants.ERROR_TEMPLATE_NULL);
		}
		
		int parameterCount = StringUtils.countMatches(smsContentTemplate, Constants.TEMPLATE_PARAMETER_MARKER);
		
		if (parameterCount > Constants.MAX_TEMPLATE_PARAMETER_COUNT) {
			throw new Exception(String.format(ErrorCodeConstants.ERROR_PARAM_ERROR, parameterCount));
		}

		String[] keys = StringUtils.splitPreserveAllTokens(smsContentTemplate, Constants.TEMPLATE_PARAMETER_MARKER);
		
		String[] values	= new String[] {
			smsContent.getParam1(),
			smsContent.getParam2(),
			smsContent.getParam3(),
			smsContent.getParam4(),
			smsContent.getParam5(),
			smsContent.getParam6(),
			smsContent.getParam7(),
			smsContent.getParam8(),
			smsContent.getParam9(),
			smsContent.getParam10()
		};

		StringBuilder response = new StringBuilder();
		
		for (int i = 0; i < keys.length; i++) {
			// 参数有可能是空字符串
			if (keys.length > 1 && keys.length-1 > i && values[i] == null) {
				throw new Exception(String.format(ErrorCodeConstants.ERROR_PARAM_ERROR, i+1));
			}
			
			response.append(keys[i]);
			
			if (keys.length-1 > i) {
				response.append(values[i]);
			}
			
		}
		
		return response.toString().trim();
	}
	

	public static String shortUUID() {
		return UUID.randomUUID().toString().replace("-", "");
	}
	public static String getNewContent(String content,String sign,Integer signFlag) {
		// 判断如果不需要增加签名，则直接从短信内容中去掉签名信息
		String signTemp = sign;
		if(signFlag!=null&&signFlag==0){
			signTemp="";
		}else{
			// 如果需要替换签名，但是账号里签名配置为空，则不替换
			if(StringUtils.isBlank(sign)){
				return content;
			}
		}
		Matcher matcher = pattern.matcher(content);
		logger.info("替换当前发送的短信签名成功:{}",signTemp);
		if(matcher.find()){
			return content.replaceAll(ipRegex,signTemp);
		}else{
			return content+signTemp;
		}

	}


	public static String moveSignToFirst(String content) {
		Matcher matcher = pattern.matcher(content);
		if(matcher.find()){
			String sign = matcher.group();
			logger.info("开始移动签名到最前面:{}",sign);
			if(content.startsWith(sign)){
				return content;
			}
			return sign+content.replaceAll(ipRegex,"");
		}
		return content;
	}

}