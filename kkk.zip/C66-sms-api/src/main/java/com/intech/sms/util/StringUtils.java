package com.intech.sms.util;

import org.apache.commons.lang3.RandomStringUtils;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

/***************************************************************************
 * System Name:   Keno8 System
 * Module Name:        
 *      Author:   david.z
 * Finish Date: 　Apr 1, 2011
 *     Version:   1.0
 * Funtion Description: 工具类
 *　　
 *　Modify History:
 *<pre>
 *###########################################################################
 *　 Version　 　 Modify Date　　   Modify By        Description  
 *###########################################################################
 *
 *</pre>
 ****************************************************************************/

public class StringUtils {
	public static final String EMPTY = "";
	public static boolean isAnyEmpty(String...value){
	    return org.apache.commons.lang3.StringUtils.isAnyBlank(value);
    }
	
	public static boolean isEmpty(String value){
		boolean isTrue=false;
		if(org.apache.commons.lang3.StringUtils.isBlank(value)||!(value != null && !"".equals(value))){
			isTrue=true;
		}
		return isTrue;
	}
	
	
	public static boolean isEmpty(Object value){
	        return !(value != null && !"".equals(value));
	        
	}
	public static boolean isNotEmpty(String value){
		return value != null && !"".equals(value.trim());
	}

	public static String getString(String value){
		if(StringUtils.isEmpty(value)){
			return "";
		}
		return value.trim();
	}

	public static String getString(Object value){
		if(value == null){
			return "";
		}
		return getString(value.toString());
	}

	/**
	 * 格式化短信内容 防止手动输入空格
	 * @param content
	 * @return
	 */
	public static String formatSmsContent(String content){
		if(isNotEmpty(content)){
			String res = content.trim();
			if(res.indexOf("【")>-1){
				String[] str = res.split("【");
				res = str[0].trim().concat("【").concat(str[1]);
			}
			return res;
		}else {
			return EMPTY;
		}

	}
	public static String toShortDateString(String value){
		String returnValue = value;
		try {
			Timestamp t = Timestamp.valueOf(value);
			returnValue = (new SimpleDateFormat("yyyyMMdd")).format(t);
		} catch (Exception e) {
		}
		return returnValue;
	}
	
	public static String formatDateString(String formatStr, Date value){
		
		try {
			return (new SimpleDateFormat(formatStr)).format(value);
		} catch (Exception e) {
		}
		return "";
	}
	
	//yyyyMMdd to yyyy-MM-dd
	public static String toStdDateString(String formatDate){
		
		try {
			String str = formatDate;
			if(formatDate != null && formatDate.length() == 8){
				str = formatDate.substring(0,4) + "-" + formatDate.substring(4,6) + "-" + formatDate.substring(6,8);
			}
			
			return str;
		} catch (Exception e) {
		}
		return "";
	}
	
	public static Integer toInteger(String value){
		
		try {
			return Integer.valueOf(value);
		} catch (NumberFormatException e) {
			return Integer.valueOf(0);
		}
		
	}
	/**
	 * 多种位数值转换
	 * 六位时 ，num需要传6 例如：1->0000001
	 * 三位时 ，num需要传3 例如：1->0001
	 * @param num
	 * @param nn
	 * @return
	 */
	public static String format(int num,int nn){
			   String aa = String.valueOf(nn);
			   int i = aa.length();
			   StringBuffer ss = new StringBuffer();
			   int identifier = num-i;
			   for(int j=0;j<identifier;j++){
				   ss.append("0");
			   }
		   ss.append(aa);
		   return ss.toString();

	}
	
	public static String formatStr(String str){
		int i = str.indexOf("-");
		if(i>-1){
			if(i+1>=str.length()){
				str = str.substring(0,i);
			} else{
				str = str.substring(0,i) + formatStr(str.substring(i+1));
			}

		}
		return str; 
	}
	
	public static String formatDateStr(String str){
		int i = str.indexOf("-");
		String year="";
		String month="";
		String day="";
		if(i>-1){
			year = str.substring(0,i);
			str = str.substring(i+1, str.length());
			i = str.indexOf("-");
			if(i>-1){
				month = str.substring(0,i);
				if(month.length() == 1){
					month = "0" + month;
				}
				day = str.substring(i+1, str.length());
				if(day.length() == 1){
					day = "0" + day;
				}
			}
		}
		return year + month + day; 
	}
	
	/**
	 * 字符串左被位,
	 * @param input
	 * @param padding
	 * @param len
	 * @return
	 */
	public static String lpad(String input, String padding, int len) {
		
		StringBuffer sb = new StringBuffer(len);
		if (input == null || input.length() > len) {
			return input;
		}
		sb.append(input);
		while (sb.toString().length() < len) {
			sb.insert(0, padding);
//			input = padding + input;
		}
		return sb.toString();
	}
	public static void main(String args[]) throws InterruptedException{
//		String s = "2009. 9. 9";
		
//		System.out.println(StringUtils.formatDateString("yyyyMMdd", new Date()));
		System.out.println(RandomStringUtils.randomNumeric(8));
		
		System.out.println(formatSmsContent("  年后  【BTT】"));
	}
}
