package com.intech.sms.work;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.intech.configuration.PropertiesConfig;
import com.intech.sms.dao.SMSOperateDao;
import com.intech.sms.service.ReplyService;
import com.intech.sms.util.ApplicationContextSingleton;
import org.slf4j.Logger;

import java.util.concurrent.*;

/**
 * @author Herman.T
 */
@Deprecated
public class AbstractReplyHandler {

    private ExecutorService exec;
    private ReplyService replyService;
    private SMSOperateDao smsOperateDao;
    private PropertiesConfig propertiesConfig;

    AbstractReplyHandler(String providerCode, Logger logger) {
        replyService = ApplicationContextSingleton.getBean(ReplyService.class);
        smsOperateDao = ApplicationContextSingleton.getBean(SMSOperateDao.class);
        propertiesConfig = ApplicationContextSingleton.getBean(PropertiesConfig.class);
        this.exec = createExecutor(providerCode, logger);
    }

    /**
     * 手动创建线程池
     * 目前只有B06有短信回复，有用的账号只有5个
     * @param providerCode
     * @return
     */
    private ExecutorService createExecutor(String providerCode, Logger logger){
        ThreadFactory factory = new ThreadFactoryBuilder().setNameFormat(providerCode+"ReplyHandler").build();
        ExecutorService service = new ThreadPoolExecutor(propertiesConfig.getThreadCoreSize(), propertiesConfig.getThreadMaxSize(), propertiesConfig.getKeepAliveTime(), TimeUnit.MILLISECONDS, new LinkedBlockingQueue<>(30), factory, new ThreadPoolExecutor.AbortPolicy());

        shutdownExecutor(this.exec, logger);

        return service;
    }

    /**
     * 注册线程池关闭
     * 当jvm关闭时先关闭线程池
     * @param exec
     * @param logger
     */
    private void shutdownExecutor(ExecutorService exec, Logger logger){
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            exec.shutdown();
            try {
                if(!exec.awaitTermination(5000L, TimeUnit.MILLISECONDS)){
                    exec.shutdownNow();
                }
            } catch (InterruptedException e) {
                logger.error(e.getMessage(), e);
            }
        }));
    }

    public ExecutorService getExec() {
        return exec;
    }

    public ReplyService getReplyService() {
        return replyService;
    }

    public SMSOperateDao getSmsOperateDao() {
        return smsOperateDao;
    }

    public PropertiesConfig getPropertiesConfig() {
        return propertiesConfig;
    }
}
