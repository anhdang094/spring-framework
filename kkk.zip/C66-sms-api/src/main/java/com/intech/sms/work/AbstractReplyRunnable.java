package com.intech.sms.work;

import com.alibaba.fastjson.JSON;
import com.intech.sms.constants.ValidEnum;
import com.intech.sms.dao.SMSOperateDao;
import com.intech.sms.model.Reply;
import com.intech.sms.model.SmsConstant;
import com.intech.sms.service.MQCallBack;
import com.intech.sms.service.ReplyService;
import com.intech.sms.util.ApplicationContextSingleton;
import com.intech.sms.util.ConstantUtil;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * @author Herman.T
 */
@Deprecated
public class AbstractReplyRunnable {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    protected ReplyService replyService;
    protected SMSOperateDao smsOperateDao;


    public void sendMqMessage(String productId, String providerCode) {
        logger.info("(" + providerCode + ") Start sending JMS for " + productId + ".");

        SmsConstant activeMqConstant = ConstantUtil.getSmsConstantByKey(productId, "REPLY_JMS_SWITCHER");
        if (activeMqConstant != null && ValidEnum.DISABLE.getCode().equals(activeMqConstant.getConstantValue())) {
            logger.info("(" + providerCode + ") JMS switcher for " + productId + " is off. DON'T SEND JMS");
            return;
        }
        List<Reply> repliesForJMS = replyService.getUnsentReplies(productId);
        if (CollectionUtils.isNotEmpty(repliesForJMS)) {
            MessageSender messageSender = ApplicationContextSingleton.getBean(MessageSender.class);
            String queueName = productId + "." + messageSender.getConfig().getJsmQueneName();
            SmsConstant queueNameConstant = ConstantUtil.getSmsConstantByKey(productId, "REPLY_JMS_QUEUE_NAME");
            if(queueNameConstant != null){
                queueName = queueNameConstant.getConstantValue();
            }
            for (Reply reply : repliesForJMS) {
                String jsonString = JSON.toJSONString(reply);
                logger.info("(" + providerCode + ") Sending JMS: " + jsonString);
                if (replyService.updateReplyJMSFlag(reply.getId(), "0", "2") > 0) {
                    messageSender.send(productId, jsonString, queueName, new MQCallBack() {
                        @Override
                        public void afterSuccessDo(Reply reply) {
                            replyService.updateReplyJMSFlag(reply.getId(), "2", "1");
                            logger.info("(" + providerCode + ") Send JMS SUCCESS: " + jsonString);
                        }

                        @Override
                        public void afterFailDo(Reply reply) {
                            logger.error("(" + providerCode + ") Send JMS Failed: " + jsonString);
                        }
                    }, reply);
                }
            }
        }
        logger.info("(" + providerCode + ") End sending JMS for " + productId + ". Count: " + (repliesForJMS == null ? 0 : repliesForJMS.size()));
    }

    public void setReplyService(ReplyService replyService) {
        this.replyService = replyService;
    }

    public void setSmsOperateDao(SMSOperateDao smsOperateDao) {
        this.smsOperateDao = smsOperateDao;
    }
}
