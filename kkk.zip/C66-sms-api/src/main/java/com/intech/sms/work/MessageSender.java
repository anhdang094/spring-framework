package com.intech.sms.work;

import com.intech.configuration.PropertiesConfig;
import com.intech.sms.constants.MqTypeEnum;
import com.intech.sms.model.Reply;
import com.intech.sms.model.SmsConstant;
import com.intech.sms.service.MQCallBack;
import com.intech.sms.util.ActiveMqUtils;
import com.intech.sms.util.ConstantUtil;
import com.intech.sms.util.RabbitMqUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Herman.T
 */
@Component
public class MessageSender {
    static Logger logger = LoggerFactory.getLogger(MessageSender.class);

    @Autowired
    private PropertiesConfig config;

    public void send(String productId, String message, String queueName, MQCallBack callBack, Reply reply) {
        SmsConstant mqTypeConstant = ConstantUtil.getSmsConstantByKey(productId, "JMS_MQ_TYPE");
        if (mqTypeConstant != null && MqTypeEnum.RABBIT_MQ.getCode().equals(mqTypeConstant.getConstantValue())) {
            RabbitMqUtils.send(productId, config.getSmsExchangeName(), message, queueName, callBack, reply);
        } else {
            ActiveMqUtils.send(productId, message, queueName, callBack, reply);
        }
    }

    public PropertiesConfig getConfig() {
        return config;
    }

    public void setConfig(PropertiesConfig config) {
        this.config = config;
    }
}
