package com.intech.sms.work;


import com.google.gson.Gson;
import com.intech.sms.model.Configuration;
import com.intech.sms.model.Reply;
import com.intech.sms.util.HttpUtil;
import com.intech.sms.util.PHPDESEncrypt;
import org.apache.commons.codec.CharEncoding;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import java.net.URLEncoder;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;
@Deprecated
public class S02ReplyRunnable extends AbstractReplyRunnable implements Runnable {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private String productId;
    

    public S02ReplyRunnable(String productId) {
        this.productId = productId;
    }

    @Override
    public void run() {
        PHPDESEncrypt crypt = new PHPDESEncrypt(productId, "03");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Gson gson = new Gson();

        while (true) {
            MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
            logger.info("(S02) Start fetching replies.");
            try {
                Configuration account = smsOperateDao.queryReplyConfigForProduct(this.productId, "S02");
                if (account != null) {
                    String replyUrl = account.getVcpServer();
                    if (StringUtils.isEmpty(replyUrl)) {
                        logger.info("(S02) Reply URL not set for " + productId + ". Thread exits.");
                        return;
                    }
                    logger.info("(S02) Acquiring replies for account " + account.getAccountId() + " of " + productId + ".");

                    String startDate = replyService.getMaxReceiveDateByAccount(account.getVcpUserId());
                    //this update happened on this date: 2017-05-11. the code below ensures that only replies after
                    //12pm of this day will be processed. if i do not do this, all replies before this date will be processed.
                    if (StringUtils.isEmpty(startDate)) {
                        startDate = "2017-05-11 00:00:00";
                    }
                    String endDate = sdf.format(new Date());

                    StringBuffer httpGetUrlConstructor = new StringBuffer(replyUrl);
                    httpGetUrlConstructor.append(account.getVcpUserId() + "?");
                    httpGetUrlConstructor.append("sdt=" + URLEncoder.encode(startDate, CharEncoding.UTF_8));
                    httpGetUrlConstructor.append("&");
                    httpGetUrlConstructor.append("edt=" + URLEncoder.encode(endDate, CharEncoding.UTF_8));

                    logger.info("(S02) Acquiring replies: " + httpGetUrlConstructor.toString());

                    String jsonResponse = HttpUtil.get(httpGetUrlConstructor.toString());

                    if (jsonResponse == null || jsonResponse.isEmpty()) {
                        logger.info("(S02) No response was acquired at this time for " + productId + ".");
                    } else {
                        S02Reply[] s02Replies = gson.fromJson(jsonResponse, S02Reply[].class);
                        if (s02Replies.length == 0) {
                            logger.info("(S02) No replies were acquired at this time for " + productId + ".");
                        } else {
                            List<Reply> replies = new ArrayList<>();
                            logger.info("(S02) Replies acquired. Count: " + s02Replies.length);

                            for (S02Reply s02Reply : s02Replies) {
                                Reply reply = new Reply();
                                reply.setContent(s02Reply.getMsg());
                                reply.setPhone(s02Reply.getCaller());

                                try {
                                    reply.setReceiveDate(new Timestamp(sdf.parse(s02Reply.getDeliverdate()).getTime()));
                                } catch (Exception ex) {
                                    logger.error("Unable to parse receive date: " + " for " + s02Reply.getCaller() + ". Using current time instead. ");
                                    reply.setReceiveDate(new Timestamp(System.currentTimeMillis()));
                                }

                                try {
                                    reply.setPhone(crypt.encrypt(reply.getPhone()));
                                } catch (Exception ex3) {
                                    logger.error("Failed to encrypt phone before saving to db for " + reply.getPhone() + ".");
                                    ex3.printStackTrace();
                                }

                                reply.setProductId(productId);
                                reply.setProviderCode(account.getProviderCode());
                                reply.setAccount(account.getVcpUserId());

                                logger.info(reply.getContent() + " Reply_status:SUCCESS (S02)");

                                replies.add(reply);
                            }

                            int count = replyService.insertReplies(replies);

                            logger.info("Replies successfully acquired for " + productId + ". Count: " + count);
                            
                            super.sendMqMessage(productId, "S02");
                        }
                    }
                } else {
                    logger.error("(S02) Acquiring replies for " + productId + " has no account.");
                }
            } catch (Exception e) {
                logger.error("(S02)  Exception when acquiring replies: " + e.getLocalizedMessage(), e);
                e.printStackTrace();
            }
            try {
                logger.error("(S02) Sleeping for one minute.");
                Thread.sleep(60000L);
                logger.error("(S02) Sleep seems fine");
            } catch (InterruptedException e) {
                logger.error("(S02) Thread was interrupted unexpectedly.");
            }
            logger.info("(S02) End fetching replies.");
            MDC.remove("uuid");
        }
    }

    private class S02Reply {
        private String caller;
        private String msg;
        private String deliverdate;

        public S02Reply() {

        }

        public S02Reply(String caller, String msg, String deliverdate) {
            this.caller = caller;
            this.msg = msg;
            this.deliverdate = deliverdate;
        }

        public String getCaller() {
            return caller;
        }

        public void setCaller(String caller) {
            this.caller = caller;
        }

        public String getMsg() {
            return msg;
        }

        public void setMsg(String msg) {
            this.msg = msg;
        }

        public String getDeliverdate() {
            return deliverdate;
        }

        public void setDeliverdate(String deliverdate) {
            this.deliverdate = deliverdate;
        }
    }

}