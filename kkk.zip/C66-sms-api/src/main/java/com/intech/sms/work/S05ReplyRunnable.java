package com.intech.sms.work;


import com.intech.configuration.PropertiesConfig;
import com.intech.sms.model.Configuration;
import com.intech.sms.model.Reply;
import com.intech.sms.util.ApplicationContextSingleton;
import com.intech.sms.util.HttpUtil;
import com.intech.sms.util.PHPDESEncrypt;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;
@Deprecated
public class S05ReplyRunnable extends AbstractReplyRunnable implements Runnable {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private String productId;

    public S05ReplyRunnable(String productId) {
        this.productId = productId;
    }

    @Override
    public void run() {
        PHPDESEncrypt crypt = new PHPDESEncrypt(productId, "03");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        PropertiesConfig config = ApplicationContextSingleton.getBean(PropertiesConfig.class);
        while (true) {
            MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
            logger.info("(S05) Start fetching replies.");
            try {
                Configuration account = smsOperateDao.queryReplyConfigForProduct(this.productId, "S05");
                if (account != null) {
                    Map<String, String> params = new HashMap<>(3);

                    params.put("UserID", config.getS05UserId());
                    params.put("Account", account.getVcpUserId());
                    params.put("Password", account.getVcpPwd());
                    logger.info("(S05) Acquiring replies for account " + account.getAccountId() + " of " + productId + ".");

                    String xml = HttpUtil.doPostWithAgent(account.getVcpServer(), params);
                    Document doc = DocumentHelper.parseText(xml);

                    Element root = doc.getRootElement();

                    String retCode = root.element("RetCode").getText();

                    if (retCode.equalsIgnoreCase("Sucess")) {
                        logger.info("(S05) Replies acquired. Count: " + root.element("Count").getText());

                        List<Reply> replies = new ArrayList<Reply>();

                        @SuppressWarnings("rawtypes")
                        List smsReplies = root.element("Nodes").elements();

                        if (smsReplies != null && !smsReplies.isEmpty()) {
                            for (Object o : smsReplies) {
                                Reply reply = new Reply();

                                Element e = (Element) o;
                                reply.setContent(e.getText());
                                reply.setPhone(e.attributeValue("Phone"));

                                try {
                                    reply.setReceiveDate(new Timestamp(sdf.parse(e.attributeValue("RecDateTime")).getTime()));
                                } catch (Exception ex) {
                                    logger.error("Unable to parse receive date: " + e.attributeValue("RecDateTime") + " for " + e.getText() + ". Using current time instead. ");
                                    reply.setReceiveDate(new Timestamp(System.currentTimeMillis()));
                                }

                                try {
                                    reply.setPhone(crypt.encrypt(reply.getPhone()));
                                } catch (Exception ex3) {
                                    logger.error("Failed to encrypt phone before saving to db for " + reply.getPhone() + ".");
                                    ex3.printStackTrace();
                                }

                                reply.setProductId(productId);
                                reply.setProviderCode(account.getProviderCode());
                                reply.setAccount(account.getVcpUserId());
                                logger.info(reply.getContent() + " Reply_status:SUCCESS (S05)");

                                replies.add(reply);
                            }

                            int count = replyService.insertReplies(replies);

                            logger.info("Replies successfully acquired for " + productId + ". Count: " + count);

                            super.sendMqMessage(productId, "S05");
                        }
                    } else {
                        logger.info("No replies were acquired at this time for " + productId + ".");
                    }
                } else {
                    logger.error("(S05) Acquiring replies for " + productId + " has no account.");
                }
            } catch (Exception e) {
                logger.error("(S05)  Exception when acquiring replies: " + e.getLocalizedMessage(), e);
                e.printStackTrace();
            }
            try {
                logger.error("(S05) Sleeping for one minute.");
                Thread.sleep(60000L);
                logger.error("(S05) Sleep seems fine");
            } catch (InterruptedException e) {
                logger.error("(S05) Thread was interrupted unexpectedly.");
            }

            logger.info("(S05) End fetching replies.");
            MDC.remove("uuid");
        }
    }
}