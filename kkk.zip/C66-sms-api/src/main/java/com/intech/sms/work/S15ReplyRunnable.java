package com.intech.sms.work;

import com.intech.sms.model.Configuration;
import com.intech.sms.model.Reply;
import com.intech.sms.util.Convert;
import com.intech.sms.util.HttpUtil;
import com.intech.sms.util.PHPDESEncrypt;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;
@Deprecated
public class S15ReplyRunnable extends AbstractReplyRunnable implements Runnable {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private String productId;

    public S15ReplyRunnable(String productId) {
        this.productId = productId;
    }

    @Override
    public void run() {
        PHPDESEncrypt crypt = new PHPDESEncrypt(productId, "03");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        while (true) {
            MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
            logger.info("(S15) Start fetching replies.");
            try {
                Configuration account = smsOperateDao.queryReplyConfigForProduct(this.productId, "S15");
                if (account != null) {
                    Map<String, String> params = new HashMap<String, String>();

                    params.put("ac", "gr");
                    params.put("uid", account.getVcpUserId());
                    params.put("pwd", Convert.MD5Encode(account.getVcpPwd()));
                    logger.info("(S15) Acquiring replies for account " + account.getAccountId() + " of " + productId + ".");

                    String result = HttpUtil.doPostWithAgent(account.getVcpServer(), params);

                    //String xml="<ROOT><RetCode>Sucess</RetCode><Count>3</Count><Nodes><SMSGroup Phone=\"18124005319\" RecDateTime=\"2016-9-20 10:57:00\" PostFixNumber=\"\">ok</SMSGroup><SMSGroup Phone=\"18124005320\" RecDateTime=\"2016-9-20 10:57:00\" PostFixNumber=\"\">ok</SMSGroup><SMSGroup Phone=\"18124005321\" RecDateTime=\"2016-9-20 10:57:00\" PostFixNumber=\"\">ok</SMSGroup></Nodes></ROOT>";

                    if (StringUtils.isNotBlank(result)) {

                        String[] response = result.split("\\{\\&\\}");

                        if (response.length > 1) {
                            logger.info("(S15) Replies acquired. Count: " + (response.length - 1));

                            List<Reply> replies = new ArrayList<Reply>();

                            for (String replyString : response) {
                                String[] replyParts = replyString.split("\\|\\|");

                                if (replyParts.length < 3) {
                                    continue;
                                }

                                Reply reply = new Reply();
                                reply.setPhone(replyParts[0]);
                                reply.setContent(replyParts[1]);
                                try {
                                    reply.setReceiveDate(new Timestamp(sdf.parse(replyParts[2]).getTime()));
                                } catch (Exception ex) {
                                    logger.error("Unable to parse receive date: " + replyParts[2] + " for " + reply.getPhone() + ". Using current time instead. ");
                                    reply.setReceiveDate(new Timestamp(System.currentTimeMillis()));
                                }
                                reply.setProductId(productId);
                                reply.setProviderCode(account.getProviderCode());
                                reply.setAccount(account.getVcpUserId());
                                try {
                                    reply.setPhone(crypt.encrypt(reply.getPhone()));
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }

                                logger.info(reply.getContent() + " Reply_status:SUCCESS (S15)");

                                replies.add(reply);
                            }

                            int count = replyService.insertReplies(replies);

                            logger.info("Replies successfully acquired for " + productId + ". Count: " + count);

                            super.sendMqMessage(productId, "S15");
                        } else {
                            logger.info("No replies were acquired at this time for " + productId + ".");
                        }
                    }
                } else {
                    logger.error("(S15) Acquiring replies for " + productId + " has no account.");
                }
            } catch (Exception e) {
                logger.error("(S15) Exception when acquiring replies: " + e.getLocalizedMessage(), e);
                e.printStackTrace();
            }
            try {
                Thread.sleep(60000L);
            } catch (InterruptedException e) {
                logger.error("Thread was interrupted unexpectedly.");
            }

            logger.info("(S15) End fetching replies.");
            MDC.remove("uuid");
        }
    }

    public static void main(String[] args) {
        String s = "100{&}15161590103||FgkQ||2016-10-10 15:34:29||0";
        String[] ss = s.split("\\{\\&\\}");

        for (String sss : ss) {
            String[] ssss = sss.split("\\|\\|");
            for (String sssss : ssss) {
                if (ssss.length < 3) {
                    continue;
                }
                System.out.println(sssss);
            }
        }
    }
}