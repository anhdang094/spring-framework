package com.intech.sms.work;


import com.shcm.bean.ReplyBean;
import com.shcm.send.DataApi;
import com.shcm.send.OpenApi;
import com.intech.sms.model.Configuration;
import com.intech.sms.model.Reply;
import com.intech.sms.util.PHPDESEncrypt;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
@Deprecated
public class S16ReplyRunnable extends AbstractReplyRunnable implements Runnable {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private String productId;
    public S16ReplyRunnable(String productId) {
        this.productId = productId;
    }

    @Override
    public void run() {
        PHPDESEncrypt crypt = new PHPDESEncrypt(productId, "03");
        while (true) {
            MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
            logger.info("(S16) Start fetching replies.");
            try {
                Configuration account = smsOperateDao.queryReplyConfigForProduct(this.productId,"S16");
                if (account != null) {
                    logger.info("(S16) Acquiring replies for account " + account.getAccountId() + " of " + productId + ".");
                    OpenApi.initialzeAccount(account.getVcpServer(), account.getVcpUserId(), account.getVcpPwd(), 7225, 0);
                    // S16 第三方服务器的地址是写死的
                    // DataApi.initialzeAccount("http://smsapi.c123.cn/DataPlatform/DataApi", account.getVcpUserId(), account.getVcpPwd());
                    DataApi.initialzeAccount(account.getVcpServer(), account.getVcpUserId(), account.getVcpPwd());
                    List<ReplyBean> listReply = DataApi.getReply();

                    if (listReply != null && listReply.size() > 0) {
                        logger.info("Replies acquired. Count: " + listReply.size());

                        List<Reply> replies = new ArrayList<Reply>();

                        for (ReplyBean t : listReply) {
                            Reply reply = new Reply();
                            reply.setContent(t.getContent());
                            reply.setPhone(t.getMobile());
                            reply.setProductId(productId);
                            // S16供应商提供的时间是秒，因此要乘以1000，转成毫秒
                            reply.setReceiveDate(new Timestamp(t.getReplyTime().getTime() * 1000L));
                            reply.setProviderCode(account.getProviderCode());
                            reply.setAccount(account.getVcpUserId());
                            try {
                                reply.setPhone(crypt.encrypt(reply.getPhone()));
                            } catch (Exception e) {
                                logger.error("Failed to encrypt phone before saving to db " + reply.getPhone() + ".", e);
                                e.printStackTrace();
                            }

                            logger.info(reply.getContent() + " Reply_status:SUCCESS (S16)");

                            replies.add(reply);
                            logger.info("回复信息 => 序号<" + t.getId() + "> 消息编号<" + t.getMsgId() + "> 回复时间<" + t.getReplyTime() + "> 转换后的时间<" + reply.getReceiveDate() + ">");
                        }

                        int count = replyService.insertReplies(replies);

                        logger.info("Replies successfully acquired for " + productId + ". Count: " + count);

                        super.sendMqMessage(productId, "S16");
                    } else {
                        logger.info("No replies were acquired at this time for " + productId + ".");
                    }
                } else {
                    logger.error("(S16) Acquiring replies for " + productId + " has no account.");
                }
            } catch (Exception e) {
                logger.info("(S16) Exception when acquiring replies: " + e.getLocalizedMessage(), e);
                e.printStackTrace();
            }
            try {
                Thread.sleep(60000L);
            } catch (InterruptedException e) {
                logger.error("Thread was interrupted unexpectedly.");
            }

            logger.info("(S16) End fetching replies.");
            MDC.remove("uuid");
        }
    }
}