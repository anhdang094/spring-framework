package com.intech.sms.work;

import com.intech.configuration.PropertiesConfig;
import com.intech.sms.util.ApplicationContextSingleton;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.ExecutorService;

/**
 * @Author peter.munsayac
 */
@Deprecated
public class S18ReplyHandler extends AbstractReplyHandler {
	private static final Logger logger = LoggerFactory.getLogger(S18ReplyHandler.class);

	public S18ReplyHandler() {
		super("S18", logger);
	}

	public void execute(){
		logger.info("INITIALIZING S18 REPLY SUPPORT...");
		ExecutorService exec = getExec();
		try {
			PropertiesConfig propertiesConfig = ApplicationContextSingleton.getBean(PropertiesConfig.class);
			String allowReply = propertiesConfig.getAllowReply();
			if(allowReply == null || allowReply.isEmpty()){
				logger.info("No settings for reply. Reply feature will not be supported.");
				return;
			}
			String[] products = allowReply.split(",");
			for(String product : products){
				S18ReplyRunnable runnable = new S18ReplyRunnable(product);
				runnable.setReplyService(getReplyService());
				runnable.setSmsOperateDao(getSmsOperateDao());
				exec.execute(runnable);
				logger.info("Added [" + product + "]");
			}
			logger.info("INITIALIZATION FOR S18 REPLY SUPPORT: SUCCESSFUL");
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
			logger.info("INITIALIZATION FOR S18 REPLY SUPPORT:");
		}
	}
}