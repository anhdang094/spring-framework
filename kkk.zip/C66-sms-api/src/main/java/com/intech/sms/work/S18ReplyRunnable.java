package com.intech.sms.work;


import com.intech.sms.model.Configuration;
import com.intech.sms.model.Reply;
import com.intech.sms.util.HttpUtil;
import com.intech.sms.util.PHPDESEncrypt;
import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import java.net.URLDecoder;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;
@Deprecated
public class S18ReplyRunnable extends AbstractReplyRunnable implements Runnable {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private String productId;

    public S18ReplyRunnable(String productId) {
        this.productId = productId;
    }

    @Override
    public void run() {
        PHPDESEncrypt crypt = new PHPDESEncrypt(productId, "03");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        while (true) {
            MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
            logger.info("(S18) Start fetching replies.");
            try {
                Configuration account = smsOperateDao.queryReplyConfigForProduct(this.productId, "S18");
                if (account != null) {
                    logger.info("(S18) Acquiring replies for account " + account.getAccountId() + " of " + productId + ".");

                    int maxId = replyService.getCoolCardMaxId(account.getAccountId());

                    //error
                    if (maxId == -1) {
                        logger.error("(S18) DAO Error. Please contact developers immediately!");
                    } else {
                        Map<String, String> params = new HashMap<String, String>();
                        params.put("maxId", String.valueOf(maxId));

                        String response = HttpUtil.post(account.getVcpServer() + "/getReplies.htm", params);
                        List<Reply> replies = new ArrayList<Reply>();

                        if (StringUtils.isEmpty(response)) {
                            logger.info("(S18) No replies acquired for " + productId + ". No response.");
                        } else {

                            Document doc = DocumentHelper.parseText(response);

                            Element root = doc.getRootElement();

                            if (root.element("status").getText().equals("0")) {
                                String newMaxId = root.element("maxid").getText();

                                replyService.updateCoolCardMaxId(account.getAccountId(), newMaxId);

                                String messageCount = root.element("count").getText();

                                if (Integer.parseInt(messageCount) > 0) {
                                    List<?> smsRepliesList = root.element("messages").elements();

                                    for (Object o : smsRepliesList) {
                                        Element e = (Element) o;

                                        Reply reply = new Reply();

                                        reply.setContent(URLDecoder.decode(e.element("content").getText(), "UTF-8"));
                                        reply.setPhone(e.element("phone").getText());

                                        try {
                                            reply.setReceiveDate(new Timestamp(sdf.parse(e.element("receivetime").getText()).getTime()));
                                        } catch (Exception ex) {
                                            logger.error("Unable to parse receive date: " + e.element("receivetime").getText() + " for " + e.element("content").getText() + ". Using current time instead. ");
                                            reply.setReceiveDate(new Timestamp(System.currentTimeMillis()));
                                        }

                                        try {
                                            reply.setPhone(crypt.encrypt(reply.getPhone()));
                                        } catch (Exception ex3) {
                                            logger.error("Failed to encrypt phone before saving to db for " + reply.getPhone() + ".");
                                            ex3.printStackTrace();
                                        }

                                        reply.setProductId(productId);
                                        reply.setProviderCode(account.getProviderCode());
                                        reply.setAccount(account.getVcpUserId());

                                        logger.info(reply.getContent() + " Reply_status:SUCCESS (S18)");

                                        replies.add(reply);
                                    }

                                    int count = replyService.insertReplies(replies);

                                    logger.info("Replies successfully acquired for " + productId + ". Count: " + count);

                                    super.sendMqMessage(productId, "S18");
                                } else {
                                    logger.info("(S18) No replies acquired for " + productId + ". No new replies.");
                                }
                            } else {
                                logger.info("(S18) Failed to get replies for " + productId + "." + root.element("statusMessage").getText());
                            }
                        }
                    }
                } else {
                    logger.error("(S18) Acquiring replies for " + productId + " has no account.");
                }
            } catch (Exception e) {
                logger.error("(S18)  Exception when acquiring replies: " + e.getLocalizedMessage(), e);
                e.printStackTrace();
            }
            try {
                logger.info("(S18) Sleeping for one minute.");
                Thread.sleep(60000L);
                logger.info("(S18) Sleep seems fine");
            } catch (InterruptedException e) {
                logger.error("(S18) Thread was interrupted unexpectedly.");
            }
            logger.info("(S18) End fetching replies.");
            MDC.remove("uuid");
        }
    }
}