package com.intech.sms.work;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.intech.sms.model.Configuration;
import com.intech.sms.model.Reply;
import com.intech.sms.util.HttpUtil;
import com.intech.sms.util.PHPDESEncrypt;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * @author Herman.T
 */
public class S21ReplyRunnable extends AbstractReplyRunnable implements Runnable {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private String productId;

    public S21ReplyRunnable(String productId) {
        this.productId = productId;
    }

    @Override
    public void run() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyMMddHHmm");
        PHPDESEncrypt crypt = new PHPDESEncrypt(productId, "03");
        while (true) {
            MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
            logger.info("(S21) Start fetching replies.");
            try {
                Configuration account = smsOperateDao.queryReplyConfigForProduct(this.productId,"S21");
                if(account != null){
                    logger.info("(S21) Acquiring replies for account " + account.getAccountId() + " of " + productId + ".");
                    String url = account.getVcpServer();
                    String accountId = account.getVcpUserId();
                    String password = account.getVcpPwd();

                    String jsonResponse = HttpUtil.get(url + "?account=" + accountId + "&pswd=" + password);
                    if(jsonResponse == null || jsonResponse.isEmpty()){
                        logger.error("(S21) No response was acquired at this time for " + productId + ".");
                    } else {
                        JSONObject response = JSONObject.parseObject(jsonResponse);
                        String result = response.getString("result");
                        logger.info("(S21) Acquiring result is "+result+" at this time for " + productId + ".");

                        if(StringUtils.equals("0", result)){
                            JSONArray mo = response.getJSONArray("mo");
                            List<Reply> replies = new ArrayList<>(mo.size());
                            for(int i=0; i<mo.size(); i++){
                                JSONObject object = mo.getJSONObject(i);
                                String moTime = object.getString("moTime");
                                String mobile = object.getString("mobile");
                                String content = object.getString("msg");

                                Reply reply = new Reply();
                                reply.setProductId(productId);
                                reply.setContent(content);
                                reply.setReceiveDate(new Timestamp(sdf.parse(moTime).getTime()));
                                try {
                                    reply.setPhone(crypt.encrypt(mobile));
                                } catch (Exception e) {
                                    logger.error("Failed to encrypt phone before saving to db " + reply.getPhone() + ".", e);
                                    e.printStackTrace();
                                }

                                reply.setProviderCode(account.getProviderCode());
                                reply.setAccount(account.getVcpUserId());

                                replies.add(reply);
                            }
                            if(CollectionUtils.isNotEmpty(replies)){
                                int count = replyService.insertReplies(replies);

                                logger.info("Replies successfully acquired for " + productId + ". Count: " + count);
                            }

                            super.sendMqMessage(productId, "S21");
                        }

                        JSONArray report = response.getJSONArray("report");
                        logger.info("(S21) Acquiring report is "+report.toString());
                    }
                }else {
                    logger.error("(S21) Acquiring replies for " + productId + " has no account.");
                }
            } catch (Exception e) {
                logger.error("(S21)  Exception when acquiring replies: " + e.getLocalizedMessage(), e);
                e.printStackTrace();
            }
            try {
                logger.info("(S21) Sleeping for one minute.");
                Thread.sleep(60000L);
                logger.info("(S21) Sleep seems fine");
            } catch (InterruptedException e) {
                logger.error("(S21) Thread was interrupted unexpectedly.");
            }
            logger.info("(S21) End fetching replies.");
            MDC.remove("uuid");
        }
    }
}