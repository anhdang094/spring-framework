package com.intech.sms.work;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.intech.sms.model.Configuration;
import com.intech.sms.model.Reply;
import com.intech.sms.util.Convert;
import com.intech.sms.util.HttpUtil;
import com.intech.sms.util.PHPDESEncrypt;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author Herman.T
 */
@Deprecated
public class S24ReplyRunnable extends AbstractReplyRunnable implements Runnable {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private String productId;

    public S24ReplyRunnable(String productId) {
        this.productId = productId;
    }

    @Override
    public void run() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        PHPDESEncrypt crypt = new PHPDESEncrypt(productId, "03");
        while (true) {
            MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
            logger.info("(S24) Start fetching replies.");
            try {
                Configuration account = smsOperateDao.queryReplyConfigForProduct(this.productId,"S24");
                if(account != null){
                    logger.info("(S24) Acquiring replies for account " + account.getAccountId() + " of " + productId + ".");
                    Map<String, String> params = new HashMap<>();
                    params.put("userid", account.getMainUserId());
                    params.put("account", account.getVcpUserId());
                    params.put("password", Convert.MD5Encode(account.getVcpPwd()).toUpperCase());
                    params.put("action", "query");
                    logger.info("S24 request: " + params.toString());

                    String jsonResponse = HttpUtil.post(account.getVcpServer(), params);
                    if(jsonResponse == null || jsonResponse.isEmpty()){
                        logger.error("(S24) No response was acquired at this time for " + productId + ".");
                    } else {
                        JSONObject response = JSONObject.parseObject(jsonResponse);
                        String result = response.getString("error");
                        logger.info("(S24) Acquiring result is "+result+" at this time for " + productId + ".");

                        if(StringUtils.equals("1", result)){
                            logger.info("GET S24 Replies 成功,返回值：{}",result);
                            JSONArray mo = response.getJSONArray("callbox");
                            List<Reply> replies = new ArrayList<>(mo.size());
                            for(int i=0; i<mo.size(); i++){
                                JSONObject object = mo.getJSONObject(i);
                                String receivetime = object.getString("receivetime");
                                String mobile = object.getString("mobile");
                                String content = object.getString("content");

                                Reply reply = new Reply();
                                reply.setProductId(productId);
                                reply.setContent(content);

                                try {
                                    reply.setReceiveDate(new Timestamp(sdf.parse(receivetime).getTime()));
                                } catch (Exception ex) {
                                    logger.error("Unable to parse receive date: " + " for " + receivetime + ". Using current time instead. ");
                                    reply.setReceiveDate(new Timestamp(System.currentTimeMillis()));
                                }
                                try {
                                    reply.setPhone(crypt.encrypt(mobile));
                                } catch (Exception e) {
                                    logger.error("Failed to encrypt phone before saving to db " + reply.getPhone() + ".", e);
                                    e.printStackTrace();
                                }

                                reply.setProviderCode(account.getProviderCode());
                                reply.setAccount(account.getVcpUserId());

                                replies.add(reply);
                            }
                            if(CollectionUtils.isNotEmpty(replies)){
                                int count = replyService.insertReplies(replies);

                                logger.info("Replies successfully acquired for " + productId + ". Count: " + count);
                            }

                            super.sendMqMessage(productId, "S24");
                        }else{
                            logger.info("GET S24 Replies 失败,返回值：{}",jsonResponse);
                        }
                    }
                }else {
                    logger.error("(S24) Acquiring replies for " + productId + " has no account.");
                }
            } catch (Exception e) {
                logger.error("(S24)  Exception when acquiring replies: " + e.getLocalizedMessage(), e);
                e.printStackTrace();
            }
            try {
                logger.info("(S24) Sleeping for one minute.");
                Thread.sleep(60000L);
                logger.info("(S24) Sleep seems fine");
            } catch (InterruptedException e) {
                logger.error("(S24) Thread was interrupted unexpectedly.");
            }
            logger.info("(S24) End fetching replies.");
            MDC.remove("uuid");
        }
    }
}