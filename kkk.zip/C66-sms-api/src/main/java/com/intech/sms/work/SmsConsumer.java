package com.intech.sms.work;

import com.intech.configuration.PropertiesConfig;
import com.intech.sms.dao.SMSOperateDao;
import com.intech.sms.exception.SmsMessageException;
import com.intech.sms.interfaces.SmsSendService;
import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.model.SmsGenRecord;
import com.intech.sms.service.SMSCreatorFactory;
import com.intech.sms.util.*;
import com.ws.SmsContent;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.regex.Pattern;

/**
 * @Author kaiser.dapar
 */
public class SmsConsumer implements Runnable {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private LinkedBlockingQueue<Sms> queue = new LinkedBlockingQueue<>();
    private SMSOperateDao smsOperateDao;
    private PropertiesConfig propertiesConfig;
    private String productId;
    private int tier;
    private String customerLevel;

    /**
     * 连续失败次数
     */
    private int continuousFailTimes;
    /**
     * 上次邮件发送时间
     */
    private Long emailSendTime = 0L;

    private volatile boolean shutdown = false;

    private volatile boolean isRunning = false;

    private HttpClientUtil httpClientUtil;

    /***************
     * CONSTRUCTOR *
     ***************/
    public SmsConsumer(String productId, int tier, String customerLevel) {
        smsOperateDao = ApplicationContextSingleton.getBean(SMSOperateDao.class);
        propertiesConfig = ApplicationContextSingleton.getBean(PropertiesConfig.class);

        httpClientUtil = new HttpClientUtil();
        httpClientUtil.setHttpMaxClientNum(propertiesConfig.getHttpMaxClientNum());
        httpClientUtil.setHttpMaxPerRoute(propertiesConfig.getHttpMaxPerRoute());
        httpClientUtil.init();

        this.productId = productId;
        this.tier = tier;
        this.customerLevel = customerLevel;
    }

    /********
     * MAIN *
     ********/

    public void shutdown() {
        this.shutdown = true;
    }

    @Override
    public void run() {
        isRunning = true;
        // PROPERTIES
        Sms sms = null;
        // PROCESS QUEUE
        while (!shutdown) {
            try {
                MDC.put("uuid", UUID.randomUUID().toString().replace("-", ""));
                logger.info("[" + this.toString() + "] Sms Queue:[" + this.queue.size() + "]");
                if (this.queue.size() == 0) {
                    logger.info("[" + this.toString() + "] Waiting for SMS:[" + this.queue.size() + "]");
                }
                sms = this.queue.take();
                logger.info("[" + this.toString() + "] Sending sms :" + sms);
                String providerCode = sms.getProviderCode();
                // GET ACCOUNT
                List<Configuration> activeAccounts = smsOperateDao.getActiveAccounts(productId, tier, sms.getTypeCode(), StringUtils.isNotEmpty(sms.getCountryCode()) && !CountryCode.CHINA_2.equals(sms.getCountryCode()), providerCode, sms.getSendMethod(), null, 0,sms.getCountryCode());
                int queryTimes = 0;
                while ((activeAccounts == null || activeAccounts.isEmpty()) && queryTimes < propertiesConfig.getMaxFailed()) {
                    activeAccounts = smsOperateDao.getActiveAccounts(productId, tier, customerLevel, StringUtils.isNotEmpty(sms.getCountryCode()) && !CountryCode.CHINA_2.equals(sms.getCountryCode()), providerCode, sms.getSendMethod(), null, 0,sms.getCountryCode());
                    if (activeAccounts == null || activeAccounts.isEmpty()) {
                        logger.info("[" + this.toString() + "] " + " IS WAITING FOR AN ACTIVE ACCOUNT ");
                        queryTimes++;
                        Thread.sleep(10000);
                    }
                }
                //当没有可用账号时直接将短信置为发送失败
                if (activeAccounts == null || activeAccounts.isEmpty()) {
                    logger.info("[" + this.toString() + "] " + " THESE IS NO ACTIVE ACCOUNT ");
                    try {
                        sms.setSmsSendDate(new Date());
                        sms.setLast_send_by("0");
                        sms.incrementFailTimes();
                        sms.setSmsResponseFlag(-1);
                        smsOperateDao.updateSmsStatus(sms);
                        smsOperateDao.insertMonitorRecord(new Date(), "FAILED", sms.getContentId(), 0L);
                        smsOperateDao.genSmsRecord(sms.getContentId(),genSmsContent(sms), SmsGenRecord.Status.SEND_FAILED.getStatus(),"[" + this.toString() + "] " + " THESE IS NO ACTIVE ACCOUNT ");
                    } catch (Exception e) {
                        logger.error("[" + this.toString() + "] " + e.getMessage(), e);
                    }
                } else {
                    logger.info("Sms:[{}]:has {} accounts to send", sms.getContentId(), activeAccounts.size());
                    boolean resend = false;
                    int accountCount = activeAccounts.size();
                    while (sms.getSmsFailTimes() < propertiesConfig.getMaxFailed()) {
                        for (Configuration account : activeAccounts) {
                            //更新签名
                            if (CollectionUtils.isNotEmpty(sms.getBatchList())) {
                                List<Sms> batchList = new ArrayList<>();
                                for (Sms smstemp : sms.getBatchList()) {
                                    smstemp.setSendContent(SmsUtility.getNewContent(smstemp.getSendContent(), account.getSmsSignature(),account.getSignFlag()));
                                    batchList.add(smstemp);
                                }
                                sms.setBatchList(batchList);
                            } else {
                                sms.setSendContent(SmsUtility.getNewContent(sms.getSendContent(), account.getSmsSignature(),account.getSignFlag()));
                            }
                            resend = sendSms(sms, account, resend, accountCount);
                        }//end looping through all accounts
                    }
                }
            } catch (SmsMessageException e) {
                logger.info(e.getMessage());
            } catch (InterruptedException e) {
                isRunning = false;
                logger.error("[Interrupted" + this.toString() + "] " + e.getMessage(), e);
            } catch (Exception e) {
                e.printStackTrace();
                logger.error("[" + this.toString() + "] " + e.getMessage(), e);
            } finally {
                MDC.remove("uuid");
            }
        }

        logger.info("[" + this.toString() + "] has exited gracefully.");
        isRunning = false;
    }

    private SmsContent genSmsContent(Sms sms){
        SmsContent record= new SmsContent();
        record.setProvidercode(sms.getProviderCode());
        record.setProductid(sms.getProductId());
        record.setSendcontent(sms.getSendContent());
        record.setSmstype(sms.getTypeCode());
        record.setCustomerLevel(sms.getCustomerLevel());
        return record;
    }

    private boolean sendSms(Sms sms, Configuration account, boolean resend, int accountCount) throws Exception {
        // GET SMS
        if (resend) {
            logger.info("[" + this.toString() + "] Resending SMS:[" + sms.getContentId() + "][" + (sms.getSmsFailTimes() + 1) + "] | Account:[" + account + "]");
        } else {
            logger.info("[" + this.toString() + "] Sending SMS:[" + sms.getContentId() + "][" + (sms.getSmsFailTimes() + 1) + "] | Account:[" + account + "]");
        }
        // SEND
        boolean sent = false;
        int flag = 0;
        try {
            SmsSendService smsSendService = SMSCreatorFactory.getSmsProvider(account);
            if (propertiesConfig.getHttpMaxClientNum() != null) {
                smsSendService.setHttpClientUtil(httpClientUtil);
            }
            sms.setProviderCode(account.getProviderCode());
            sms.setCurrentSmsAccountId(account.getAccountId());
            flag = smsSendService.send(sms);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("[" + this.toString() + "] " + e.getMessage(), e);
            logger.info("[" + this.toString() + "] " + (resend ? "Resending" : "Sending") + " SMS:[" + sms.getContentId() + "][" + (sms.getSmsFailTimes() + 1) + "] | Account:[" + account + "] [ERROR]");
        }

        // 发送成功（1）或者格式不正确（-1） 提前更新失败(-2)  不再补偿发送
        if (flag != 0) {
            sent = flag > 0;
            logger.info("[" + this.toString() + "] " + (resend ? "Resending" : "Sending") + " SMS:[" + sms.getContentId() + "][" + (sms.getSmsFailTimes() + 1) + "] | Account:[" + account + "] [" + (sent ? "success" : "fail") + "]");
            sms.setSmsSendDate(new Date());
            sms.setLast_send_by(account.getAccountId());
            //1 发送成功 -1 格式不正确
            sms.setSmsRemarks(sent ? Constants.SMS_S35.equals(sms.getProviderCode()) ? "sending" : "success" : "fail");

            //如果供应商为S35短信状态先是发送中，供应商对结果推送后进行状态更新
            sms.setSmsResponseFlag(sent ? Constants.SMS_S35.equals(sms.getProviderCode()) ? 1 : 2 : -1);
            if (sent) {
                // 每次发送成功后，清除发送失败记录
                continuousFailTimes = 0;
                emailSendTime = 0L;
            } else {
                sms.incrementFailTimes();
            }
            resend = false;

        } else {
            //其他未知情况导致未成功，继续补偿发送
            logger.info("[" + this.toString() + "] " + (resend ? "Resending" : "Sending") + " SMS:[" + sms.getContentId() + "][" + (sms.getSmsFailTimes() + 1) + "] | Account:[" + account + "] [FAILED]");

            sms.setSmsSendDate(new Date());
            sms.setLast_send_by(account.getAccountId());
            sms.incrementFailTimes();
            sms.setSmsRemarks("fail");
            resend = sms.getSmsFailTimes() < propertiesConfig.getMaxFailed() && accountCount > 1;
            sms.setSmsResponseFlag(resend ? 0 : -1);

            //** 邮件通知  暂时注释 从来没有发送成功过
           /* EmailSender emailSender = ApplicationContextSingleton.getBean(EmailSender.class);

            // EMAIL WHEN DAILY FAILED REACHED
            int failed = smsOperateDao.getFailed(account.getAccountId());
            if (failed < propertiesConfig.getDailyFailed() && account.isEmailSent()) {
                account.setEmailSent(false);
            } else if (failed >= propertiesConfig.getDailyFailed()) {
                if (account.isEmailSent()) {
                    logger.info("[" + this.toString() + "] Account:[" + account.getAccountId() + "] | Failed:[" + failed + "] [EMAIL ALREADY SENT]");
                } else {
                    String emailTo = propertiesConfig.getEmailTo();
                    String subject = propertiesConfig.getEmailSubject();
                    String emailContent = propertiesConfig.getEmailContent().replaceFirst("\\|", account.getAccountId()).replaceFirst("\\|", String.valueOf(failed));
                    boolean emailSent = emailSender.send(emailTo, subject, emailContent);
                    logger.info("[" + this.toString() + "] Account:[" + account.getAccountId() + "] | Failed:[" + failed + "] [EMAIL SENT " + (emailSent ? "SUCCESS]" : "FAILED]"));
                    account.setEmailSent(emailSent);
                }
            } else {
                logger.info("[" + this.toString() + "] Account:[" + account.getAccountId() + "] | Failed:[" + failed + "]");
            }

            if (!resend) {
                continuousFailTimes++;
                long currentTimeMillis = System.currentTimeMillis();
                long distance = emailSendTime - currentTimeMillis;
                logger.info("[" + this.toString() + "] Sms Continuous Failed continuousFailTimes:[" + continuousFailTimes + "] | distance:[" + distance + "]");
                //当连续失败次数超过限定值，且距离上次发送提醒邮件超过5分钟
                if (continuousFailTimes >= propertiesConfig.getContinuousFailed() && distance >= propertiesConfig.getIntervalTime()) {

                    String emailTo = propertiesConfig.getEmailContinuousTo();
                    String subject = propertiesConfig.getEmailContinuousSubject();
                    String emailContent = propertiesConfig.getEmailContinuousContent();
                    if (StringUtils.isAnyBlank(emailTo, subject)) {
                        logger.error("[" + this.toString() + "] Sms Continuous Failed Notification send failed, because configs miss");
                    } else {
                        emailContent = emailContent.replaceFirst("\\|", String.valueOf(continuousFailTimes)).replaceFirst("\\|", String.valueOf(productId)).replaceFirst("\\|", String.valueOf(tier));
                        boolean emailSent = emailSender.send(emailTo, subject, emailContent);
                        logger.info("[" + this.toString() + "] Continuous Failed:[" + continuousFailTimes + "] [EMAIL SENT " + (emailSent ? "SUCCESS]" : "FAILED]"));
                        if (emailSent) {
                            emailSendTime = currentTimeMillis;
                        }
                    }
                }
            }*/
        }
        // UPDATE DATABASE
        try {
            //提前更新失败不再更新状态
            if (-2 != flag) {
                smsOperateDao.updateSmsStatus(sms);
                if (!Constants.SMS_S35.equals(sms.getProviderCode())) {
                    smsOperateDao.updateAccountStats(account.getAccountId(), sent);
                }
                smsOperateDao.insertMonitorRecord(new Date(), (sent ? "SUCCESS" : "FAILED"), sms.getContentId(), Long.valueOf(account.getAccountId()));
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("[" + this.toString() + "] " + e.getMessage(), e);
        }

        if (!resend) {
            throw new SmsMessageException("发送结束！[" + this.toString() + "] Account:[" + account.getAccountId() + "] SMS:[" + sms.getContentId() + "] result:[" + sent + "]");
        }

        return true;
    }

    /******************************
     * PUBLIC AND PRIVATE METHODS *
     ******************************/
    public void addSms(Sms sms) {
        try {
            //if this is the default product consumer (no customer level)
            if (StringUtils.isEmpty(this.customerLevel) || "null".equals(this.customerLevel)) {
                this.queue.put(sms);
                logger.info("[" + this.toString() + "] SMS Inserted:[" + sms.getContentId() + "] | SMS Queue:[" + this.queue.size() + "]");
            } else {
                boolean hasAccount = smsOperateDao.hasAccount(productId, tier, customerLevel);
                if (!hasAccount) {
                    SmsConsumer defaultConsumer = SmsConsumerHolder.getConsumer(productId, tier, null);
                    defaultConsumer.addSms(sms);
                } else {
                    this.queue.put(sms);
                    logger.info("[" + this.toString() + "] SMS Inserted:[" + sms.getContentId() + "] | SMS Queue:[" + this.queue.size() + "]");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("[" + this.toString() + "] " + e.getMessage(), e);
        }
    }


    /*********************
     * OVERRIDEN METHODS *
     *********************/
    @Override
    public String toString() {
        return productId + "-" + tier + "-" + customerLevel;
    }

    public boolean isRunning() {
        return isRunning;
    }

    public String getCustomerLevel() {
        return customerLevel;
    }

    public void setCustomerLevel(String customerLevel) {
        this.customerLevel = customerLevel;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public int getTier() {
        return tier;
    }

    public void setTier(int tier) {
        this.tier = tier;
    }
}