package com.intech.sms.work;

import com.intech.sms.listener.QueueListener;
import com.ws.SmsServiceImpl;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @description:
 * @author: Condi
 * @create: 2019-01-26 17:47
 **/

public class SmsConsumerHolder {
    private static final Logger LOGGER = LoggerFactory.getLogger(SmsServiceImpl.class);
    private static ConcurrentHashMap<String, SmsConsumer> consumers = new ConcurrentHashMap<>();

    public static synchronized void addConsumer(SmsConsumer consumer) {
            consumers.put(consumer.toString(), consumer);
    }

    public static synchronized SmsConsumer getConsumer(String productId, int tier, String customerLevel) {
        customerLevel = (StringUtils.isEmpty(customerLevel) ? null : customerLevel);
        String key =productId + "-" + tier + "-" + customerLevel;
        SmsConsumer consumer = consumers.get(key);
        if (consumer == null) {
            LOGGER.info("没有对应的消费者线程，创建对应的消费者线程{}",key);
            SmsConsumer newConsumer = new SmsConsumer(productId, tier, customerLevel);
            consumers.put(key,newConsumer);
            QueueListener.getExecutorService().execute(newConsumer);
        }
        return consumers.get(key);
    }
}


    
