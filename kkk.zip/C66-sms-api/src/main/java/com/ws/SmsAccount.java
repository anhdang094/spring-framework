package com.ws;

import java.io.Serializable;

/**
 * @author Herman.T
 */
public class SmsAccount implements Serializable {

    private String providerCode;

    private String providerName;

    public String getProviderCode() {
        return providerCode;
    }

    public void setProviderCode(String providerCode) {
        this.providerCode = providerCode;
    }

    public String getProviderName() {
        return providerName;
    }

    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }

    @Override
    public String toString() {
        return "SmsAccount{" +
                ", providerCode='" + providerCode + '\'' +
                ", providerName='" + providerName + '\'' +
                '}';
    }
}
