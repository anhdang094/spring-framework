package com.ws;

import java.io.Serializable;

/**
 * @author Herman.T
 */
public class SmsAccountQueryRequest implements Serializable {

    private String smsType;

    private String customerLevel;

    private String productId;

    private String countryCode;

    public String getSmsType() {
        return smsType;
    }

    public void setSmsType(String smsType) {
        this.smsType = smsType;
    }

    public String getCustomerLevel() {
        return customerLevel;
    }

    public void setCustomerLevel(String customerLevel) {
        this.customerLevel = customerLevel;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    @Override
    public String toString() {
        return "SmsAccountQueryRequest{" +
                "smsType='" + smsType + '\'' +
                ", customerLevel='" + customerLevel + '\'' +
                ", productId='" + productId + '\'' +
                ", countryCode='" + countryCode + '\'' +
                '}';
    }
}
