package com.ws;

import java.io.Serializable;
import java.util.List;

/**
 * @author Herman.T
 */
public class SmsAccountQueryResponse implements Serializable {

    private String code;

    private String message;

    private List<SmsAccount> smsAccountList;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<SmsAccount> getSmsAccountList() {
        return smsAccountList;
    }

    public void setSmsAccountList(List<SmsAccount> smsAccountList) {
        this.smsAccountList = smsAccountList;
    }

    @Override
    public String toString() {
        return "SmsAccountQueryResponse{" +
                "code='" + code + '\'' +
                ", message='" + message + '\'' +
                ", smsAccountList=" + smsAccountList +
                '}';
    }
}
