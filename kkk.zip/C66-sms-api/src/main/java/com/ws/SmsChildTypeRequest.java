package com.ws;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * @description:
 * @author: Condi
 * @create: 2019-03-20 09:36
 **/
@ApiModel
public class SmsChildTypeRequest implements Serializable{


    @ApiModelProperty(value = "产品id", example = "A01",required = true)
    private String productId;

    @ApiModelProperty(value = "短信类型", example = "60002",required = true)
    private String typeCode;


    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getTypeCode() {
        return typeCode;
    }

    public void setTypeCode(String typeCode) {
        this.typeCode = typeCode;
    }

    @Override
    public String toString() {
        return "SmsChildTypeRequest{" +
                "productId='" + productId + '\'' +
                ", typeCode='" + typeCode + '\'' +
                '}';
    }
}


    
