package com.ws;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.xml.bind.annotation.*;
import java.io.Serializable;



@ApiModel(value="SmsContent", description="短信请求参数明细")
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "smscontent", propOrder = {"productid","providercode","smstype","phone","exclusiveFlag","loginname","realname","param1","param2","param3","param4","param5","param6","param7","param8","param9","param10","sendcontent","useTemplateFlag","key","customerLevel","countryCode", "source","sender","requestId","sendMethod","approveStatus","extraParam"})
public class SmsContent implements Serializable {

	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = " 产品id",required = true,example = "A01")
	@XmlElement(required = true)
	private String productid;
	@ApiModelProperty(value = " 短信类型",required = true,example = "60003")
	@XmlElement(required = true)
	private String smstype;
	@ApiModelProperty(value = " 明文电话[群发的短信内容一致时,多个电话英文逗号隔开]",required = true,example = "13031313130")
	@XmlElement(required = true)
	@JSONField(serialize = false)
	private String phone;
	@ApiModelProperty(value = " 是否使用模板:0使用，1不使用",required = true,example = "0")
	@XmlElement(required = true)
	private String useTemplateFlag;
	@ApiModelProperty(value = " 加密key:加密规则MD5(loginName+productId+productKey+phone+smstype)",required = true,example = "6cadb812fbfbfeb96a44a7a4d14653")
	@XmlElement(required = true)
	private String key;
	@ApiModelProperty(value = " 登录名",required = false,example = "jack ma")
	private String loginname;
	@ApiModelProperty(value = " 真实姓名",required = false,example = "马云爸爸")
	private String realname;
	@ApiModelProperty(value = " 短信内容[不使用模板情况下，必填]",required = false,example = "尊敬的客户:游戏账号2015已成功登录,请查询确认【BTT】")
	private String sendcontent;
	@ApiModelProperty(value = " 供应商",required = false,example = "S02")
	private String providercode;
	@ApiModelProperty(value = " 客户星级",required = false,example = "1")
	private String customerLevel;
	@ApiModelProperty(value = " 国家区号[发送中国大陆地区不用填，其他地区需要填，例如0063]",required = false,example = "0063")
	private String countryCode;
	@ApiModelProperty(value = " 短信发送来源",required = false,example = "TM")
	private String source;
	@ApiModelProperty(value = " 发送人",required = false,example = "tina")
	private String sender;
	@ApiModelProperty(value = " 业务请求ID",required = false,example = "1254685236877")
	private String requestId;
	@ApiModelProperty(value = " 发送方式[0:文本短信;1:语音短信,默认0]",example = "1")
	private String sendMethod;
	@ApiModelProperty(value = " 是否专属会员[0:否;1:是,默认0]",example = "0",required = false)
	private String exclusiveFlag;
	@ApiModelProperty(value = " 短信审批状态[2:为审批通过;]",example = "0",required = false)
	private String approveStatus;
	@ApiModelProperty(value = " 模板参数1",required = false,example = "param1")
	private String param1;
	@ApiModelProperty(value = " 模板参数2",required = false,example = "param2")
	private String param2;
	@ApiModelProperty(value = " 模板参数3",required = false,example = "param3")
	private String param3;
	@ApiModelProperty(value = " 模板参数4",required = false,example = "param4")
	private String param4;
	@ApiModelProperty(value = " 模板参数5",required = false,example = "param5")
	private String param5;
	@ApiModelProperty(value = " 模板参数6",required = false,example = "param6")
	private String param6;
	@ApiModelProperty(value = " 模板参数7",required = false,example = "param7")
	private String param7;
	@ApiModelProperty(value = " 模板参数8",required = false,example = "param8")
	private String param8;
	private String param9;
	private String param10;
	private String extraParam;


	public String getExtraParam() {
		return extraParam;
	}

	public void setExtraParam(String extraParam) {
		this.extraParam = extraParam;
	}

	public String getProductid() {
		return productid;
	}

	public String getSmstype() {
		return smstype;
	}

	public String getPhone() {
		return phone;
	}

	public String getUseTemplateFlag() {
		return useTemplateFlag;
	}

	public String getKey() {
		return key;
	}

	public String getLoginname() {
		return loginname;
	}

	public String getRealname() {
		return realname;
	}

	public String getSendcontent() {
		return sendcontent;
	}

	public String getParam1() {
		return param1;
	}

	public String getParam2() {
		return param2;
	}

	public String getParam3() {
		return param3;
	}

	public String getParam4() {
		return param4;
	}

	public String getParam5() {
		return param5;
	}

	public String getParam6() {
		return param6;
	}

	public String getParam7() {
		return param7;
	}

	public String getParam8() {
		return param8;
	}

	public String getParam9() {
		return param9;
	}

	public String getParam10() {
		return param10;
	}

	public String getProvidercode() {
		return providercode;
	}

	public void setProductid(String productid) {
		this.productid = productid;
	}

	public void setSmstype(String smstype) {
		this.smstype = smstype;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public void setUseTemplateFlag(String useTemplateFlag) {
		this.useTemplateFlag = useTemplateFlag;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public void setLoginname(String loginname) {
		this.loginname = loginname;
	}

	public void setRealname(String realname) {
		this.realname = realname;
	}

	public void setSendcontent(String sendcontent) {
		this.sendcontent = sendcontent;
	}

	public void setParam1(String param1) {
		this.param1 = param1;
	}

	public void setParam2(String param2) {
		this.param2 = param2;
	}

	public void setParam3(String param3) {
		this.param3 = param3;
	}

	public void setParam4(String param4) {
		this.param4 = param4;
	}

	public void setParam5(String param5) {
		this.param5 = param5;
	}

	public void setParam6(String param6) {
		this.param6 = param6;
	}

	public void setParam7(String param7) {
		this.param7 = param7;
	}

	public void setParam8(String param8) {
		this.param8 = param8;
	}

	public void setParam9(String param9) {
		this.param9 = param9;
	}

	public void setParam10(String param10) {
		this.param10 = param10;
	}

	public void setProvidercode(String providercode) {
		this.providercode = providercode;
	}

	public String getCustomerLevel() {
		return customerLevel;
	}

	public void setCustomerLevel(String customerLevel) {
		this.customerLevel = customerLevel;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getSender() {
		return sender;
	}

	public void setSender(String sender) {
		this.sender = sender;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getSendMethod() {
		return sendMethod;
	}

	public void setSendMethod(String sendMethod) {
		this.sendMethod = sendMethod;
	}

	public String getExclusiveFlag() {
		return exclusiveFlag;
	}

	public void setExclusiveFlag(String exclusiveFlag) {
		this.exclusiveFlag = exclusiveFlag;
	}

	public String getApproveStatus() {
		return approveStatus;
	}

	public void setApproveStatus(String approveStatus) {
		this.approveStatus = approveStatus;
	}

	@Override
	public String toString() {
		return JSON.toJSONString(this);
	}
}
