package com.ws;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
/**
* <p>Java class for listObject complex type.
* 
* <p>The following schema fragment specifies the expected content contained within this class.
* 
* <pre>
* <complexType name="listObject">
*   <complexContent>
*     <restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
*       <sequence>
*         <element name="content" type="{http://www.w3.org/2001/XMLSchema}anyType" maxOccurs="unbounded" minOccurs="0"/>
*       </sequence>
*     </restriction>
*   </complexContent>
* </complexType>
* </pre>
* 
* 
*/
@XmlRootElement(name="datas")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "listObject", propOrder = { "content" })
@ApiModel(value="SmsContentRequest", description="短信请求参数")
public class SmsContentRequest implements Serializable{
    private static final long serialVersionUID = -7178681764019697097L;

    public SmsContentRequest(){
    	
    }
	@ApiModelProperty(value = "请求参数列表",name = "content",required = true)
    @XmlElement(name="content", nillable = true)
    protected List<SmsContent> content;

	public SmsContentRequest(List<SmsContent> content) {
		super();
		this.content = content;
	}
	public List<SmsContent> getSmsContents() {
		if(content==null){
			content=new ArrayList<SmsContent>();
		}
		return content;
	}
	public void setSmsContents(List<SmsContent> content) {
		this.content = content;
	}
   

}
