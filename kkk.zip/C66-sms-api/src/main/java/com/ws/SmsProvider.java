package com.ws;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * @description:
 * @author: Condi
 * @create: 2020-02-25 15:28
 **/
@ApiModel
public class SmsProvider implements Serializable {


    @ApiModelProperty(value = "供应商代号")
    private String providerCode;

    @ApiModelProperty(value = "状态")
    private String status;


    public String getProviderCode() {
        return providerCode;
    }

    public void setProviderCode(String providerCode) {
        this.providerCode = providerCode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "SmsProvider{" +
                "providerCode='" + providerCode + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}


    
