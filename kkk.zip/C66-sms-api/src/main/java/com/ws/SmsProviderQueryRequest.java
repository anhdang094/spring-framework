package com.ws;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * @description:
 * @author: Condi
 * @create: 2019-03-20 09:36
 **/
@ApiModel
public class SmsProviderQueryRequest implements Serializable{


    @ApiModelProperty(value = "产品id", example = "A01",required = true)
    private String productId;

    @ApiModelProperty(value = "短信类型[不传默认查等级4的营销短信]", example = "60002")
    private String typeCode;

    @ApiModelProperty(value = "账户状态[0:启用,1禁用,默认查所有状态]", example = "0")
    private Integer status;

    @ApiModelProperty(value = "国际码[不传或者传0086，默认查非国际短信，其他值查国际短信账户]", example = "0086")
    private String countryCode;


    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getTypeCode() {
        return typeCode;
    }

    public void setTypeCode(String typeCode) {
        this.typeCode = typeCode;
    }

    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    @Override
    public String toString() {
        return "SmsProviderQueryRequest{" +
                "productId='" + productId + '\'' +
                ", typeCode='" + typeCode + '\'' +
                ", status=" + status +
                ", countryCode='" + countryCode + '\'' +
                '}';
    }
}


    
