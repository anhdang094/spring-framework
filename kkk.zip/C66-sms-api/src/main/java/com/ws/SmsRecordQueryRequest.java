package com.ws;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;

/**
 * @author Herman.T
 */
@ApiModel(value="SmsRecordQueryRequest", description="短信查询请求参数")

public class SmsRecordQueryRequest implements Serializable {

    private static final long serialVersionUID = -1324149868637502602L;

    private String requestId;
    @ApiModelProperty(value = " 产品id",required = true,example = "A01")
    private String productId;
    /**
     * 短信类型code
     */
    @ApiModelProperty(value = " 短信类型code",required = false,example = "60014")
    private String typeCode;
    /**
     * 加密的手机号码
     */
    @ApiModelProperty(value = " 加密的手机号码",required = true,example = "fsdvcdsDgdfdfr")
    private String mobileNo;

    /**
     * 起始时间，格式为"YYYY-MM-DD HH24:MI:SS"
     */

    @ApiModelProperty(value = "起始时间，格式为YYYY-MM-DD HH24:MI:SS",required = false,example = "fsdvcdsDgdfdfr")
    private String startDate;
    /**
     * 结束时间，格式为"YYYY-MM-DD HH24:MI:SS"
     */
    @ApiModelProperty(value = " 结束时间，格式为YYYY-MM-DD HH24:MI:SS",required = false,example = "fsdvcdsDgdfdfr")
    private String endDate;
    /**
     * 短信来源
     */
    @ApiModelProperty(value = " 短信来源，格式为YYYY-MM-DD HH24:MI:SS",required = false,example = "fsdvcdsDgdfdfr")
    private String source;

    /**
     * 发送人
     */
    @ApiModelProperty(value = "发送人，格式为YYYY-MM-DD HH24:MI:SS",required = false,example = "fsdvcdsDgdfdfr")

    private String sender;

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getTypeCode() {
        return typeCode;
    }

    public void setTypeCode(String typeCode) {
        this.typeCode = typeCode;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    @Override
    public String toString() {
        return "SmsRecordQueryRequest{" +
                "requestId='" + requestId + '\'' +
                ", productId='" + productId + '\'' +
                ", typeCode='" + typeCode + '\'' +
                ", mobileNo='" + mobileNo + '\'' +
                ", startDate='" + startDate + '\'' +
                ", endDate='" + endDate + '\'' +
                ", source='" + source + '\'' +
                ", sender='" + sender + '\'' +
                '}';
    }
}
