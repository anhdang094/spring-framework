package com.ws;
import java.io.Serializable;

/**
 * @author Herman.T
 */
public class SmsRecordQueryResponse implements Serializable {

    private static final long serialVersionUID = 7731920600896083339L;
    private String code;

    private String message;

    private String requestId;
    /**
     * 短信发送记录数
     */
    private Integer smsRecordNumber;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public Integer getSmsRecordNumber() {
        return smsRecordNumber;
    }

    public void setSmsRecordNumber(Integer smsRecordNumber) {
        this.smsRecordNumber = smsRecordNumber;
    }

    @Override
    public String toString() {
        return "SmsRecordQueryResponse{" +
                "code='" + code + '\'' +
                ", message='" + message + '\'' +
                ", requestId='" + requestId + '\'' +
                ", smsRecordNumber=" + smsRecordNumber +
                '}';
    }
}
