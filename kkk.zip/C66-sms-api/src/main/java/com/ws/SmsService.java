package com.ws;

import com.alibaba.fastjson.JSONObject;

import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

/**
 * @author Herman.T
 */
@WebService
public interface SmsService {

    @WebResult(name="result")
    String insert(@WebParam(name = "datas") SmsContentRequest request);

    @WebResult
    SmsAccountQueryResponse querySmsAccount(SmsAccountQueryRequest request);

    @WebResult
    SmsRecordQueryResponse querySmsRecord(SmsRecordQueryRequest request);

    void saveS35Result(String contentId,Integer status,String port);
}
