package com.ws;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.intech.sms.dao.SMSOperateDao;
import com.intech.sms.model.*;
import com.intech.sms.service.SmsProviderConfigService;
import com.intech.sms.util.*;
import com.intech.sms.work.SmsConsumer;
import com.intech.sms.work.SmsConsumerHolder;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.jws.WebService;
import java.sql.Date;
import java.util.*;

/**
 * @author kaiser.dapar
 * @version 2.0, Mar 28, 2015
 */
@WebService(endpointInterface = "com.ws.SmsService")
@Service
public class SmsServiceImpl implements SmsService {

    private static final Logger LOGGER = LoggerFactory.getLogger(SmsServiceImpl.class);
    @Autowired
    private SMSOperateDao smsOperateDao;

    @Autowired
    private SmsProviderConfigService configService;

    @Override
    public String insert(SmsContentRequest request) {
        Long executionTime = System.currentTimeMillis();
        String returnMsg = "";
        int failed = -1;
        LOGGER.info("SmsService.insert start");
        String genBatchNo = SmsUtility.shortUUID();
        try {
            //获取需要审批的短信类型数据
            List<String> approveSmsTypes = smsOperateDao.queryAllApproveSmsType();
            List<SmsContent> smsContents = request.getSmsContents();
            int total = smsContents.size();
            if (total > 0) {
                failed = total;
                LOGGER.info("请求发送短信,参数:" + JSON.toJSONString(request));
                //参数过滤
                List<SmsContent> newSmsContents = new ArrayList<>(total);
                for (SmsContent smsContent : smsContents) {
                    //短信类型需要审批，则需要生成审批流程
                    if (approveSmsTypes.contains(smsContent.getSmstype()) &&
                            !String.valueOf(SmsGenRecord.Status.APPROVED.getStatus()).equals(smsContent.getApproveStatus())) {
                        smsOperateDao.genSmsRecord(genBatchNo, smsContent, 1, "Wait admin approve");
                        continue;
                    }
                    //校验参数
                    if (!checkAndFormatSmsContent(smsContent, genBatchNo)) {
                        continue;
                    }
                    //Yaser 2020.7.15 校验新增星级和专属供应商规则
                    if (!checkNewRule(smsContent, genBatchNo)) {
                        LOGGER.info("新规则匹配没通过,匹配内容:{}", JSON.toJSONString(smsContent));
                        continue;
                    }
                    newSmsContents.add(smsContent);
                }
                int index = 1;
                Sms sms = null;
                boolean multipleSend = false;
                int sendMethod = 0;
                String customerLevel = null;
                String productId = null;
                String providerCode = null;
                if (newSmsContents.size() == 1) {
                    SmsContent smsContent = newSmsContents.get(0);
                    productId = smsContent.getProductid();
                    providerCode = smsContent.getProvidercode();
                    sendMethod = StringUtils.isEmpty(smsContent.getSendMethod()) ? 0 : Integer.parseInt(smsContent.getSendMethod());
                    customerLevel = StringUtils.isEmpty(smsContent.getCustomerLevel()) ? null : smsContent.getCustomerLevel();
                    if (StringUtils.split(smsContent.getPhone(), Constants.NUMBERS_SEPARATOR).length > 1) {
                        //批量发送---相同内容 不同手机号
                        sms = smsOperateDao.insertBulkSmsContent(smsContent);
                        multipleSend = true;
                    } else {
                        //单个发送
                        sms = smsOperateDao.insertSmsContent(smsContent);
                    }
                    if (sms != null) {
                        sms.setSendMethod(sendMethod);
                        sms.setMultipleSend(multipleSend);
                        sms.setCustomerLevel(customerLevel);
                        if (StringUtils.isNotBlank(providerCode)) {
                            sms.setProviderCode(providerCode);
                        }
                        SmsConsumer smsConsumer = SmsConsumerHolder.getConsumer(productId, Integer.parseInt(sms.getTier()), customerLevel);
                        smsConsumer.addSms(sms);
                        failed--;
                        LOGGER.info(String.format("success [%s of %s]", index, total));
                    } else {
                        LOGGER.warn("短信类型不存在或没启用，短信类型：{}，产品ID：{}", smsContent.getSmstype(), smsContent.getProductid());
                    }
                }
                if (newSmsContents.size() > 1) {
                    //批量发送
                    SmsContent smsContent = newSmsContents.get(0);

                    if (StringUtils.split(smsContent.getPhone(), Constants.NUMBERS_SEPARATOR).length > 1) {
                        //批量发送---相同内容 不同手机号
                        for (SmsContent smsContentTemp : newSmsContents) {
                            productId = smsContentTemp.getProductid();
                            sendMethod = StringUtils.isEmpty(smsContentTemp.getSendMethod()) ? 0 : Integer.parseInt(smsContentTemp.getSendMethod());
                            customerLevel = StringUtils.isEmpty(smsContentTemp.getCustomerLevel()) ? null : smsContentTemp.getCustomerLevel();
                            providerCode = smsContent.getProvidercode();
                            sms = smsOperateDao.insertBulkSmsContent(smsContentTemp);
                            multipleSend = true;
                            if (sms != null) {
                                sms.setSendMethod(sendMethod);
                                sms.setMultipleSend(multipleSend);
                                sms.setCustomerLevel(customerLevel);
                                if (StringUtils.isNotBlank(providerCode)) {
                                    sms.setProviderCode(providerCode);
                                }
                                SmsConsumer smsConsumer = SmsConsumerHolder.getConsumer(productId, Integer.parseInt(sms.getTier()), customerLevel);
                                smsConsumer.addSms(sms);
                                failed--;
                                LOGGER.info(String.format("success [%s of %s]", index, total));
                            }
                        }
                    } else {
                        productId = smsContent.getProductid();
                        providerCode = smsContent.getProvidercode();
                        sendMethod = StringUtils.isEmpty(smsContent.getSendMethod()) ? 0 : Integer.parseInt(smsContent.getSendMethod());
                        customerLevel = StringUtils.isEmpty(smsContent.getCustomerLevel()) ? null : smsContent.getCustomerLevel();
                        sms = smsOperateDao.insertMultiSmsContent(newSmsContents);
                        multipleSend = true;
                        if (sms != null) {
                            sms.setSendMethod(sendMethod);
                            sms.setMultipleSend(multipleSend);
                            sms.setCustomerLevel(customerLevel);
                            if (StringUtils.isNotBlank(providerCode)) {
                                sms.setProviderCode(providerCode);
                            }
                            SmsConsumer smsConsumer = SmsConsumerHolder.getConsumer(productId, Integer.parseInt(sms.getTier()), customerLevel);
                            smsConsumer.addSms(sms);
                            failed = failed - sms.getBatchList().size();
                            LOGGER.info(String.format("success [%s of %s]", index, total));
                        }
                    }
                }

            } else {
                LOGGER.info("发送短信参数格式不正确:{}", JSON.toJSONString(request));
            }
            returnMsg = String.valueOf(failed);
        } catch (Exception e) {
            LOGGER.error("短信发送异常:" + e.getMessage(), e);
        } finally {
            LOGGER.info(String.format("SmsService.insert end [%s] (%s ms)", returnMsg, (System.currentTimeMillis() - executionTime)));
        }
        return returnMsg;
    }

    private boolean checkNewRule(SmsContent smsContent, String genBatchNo) {
        boolean isVerified = true;
        //Yaser 2020.7.15 校验新增星级和专属供应商规则
        List<SmsConstant> newRuleSwitches = smsOperateDao.getSmsConstantByKey(smsContent.getProductid(), "NEW_RULE_SWITCH");
        if (CollectionUtils.isEmpty(newRuleSwitches)) {
            newRuleSwitches = smsOperateDao.getSmsConstantByKey("ALL", "NEW_RULE_SWITCH");
        }
        if (!CollectionUtils.isEmpty(newRuleSwitches)) {
            SmsConstant smsConstant = newRuleSwitches.get(0);
            //是否开启新规则过滤，上线用
            LOGGER.info("产品ID：{}，当前开关是否开启：{}", smsContent.getProductid(), smsConstant.getConstantValue());
            if ("true".equals(smsConstant.getConstantValue())) {
                List<SmsProviderConfig> providerConfigs = configService.getProviderConfigs(smsContent.getProductid(), smsContent.getProvidercode(), smsContent.getExclusiveFlag(), smsContent.getSmstype());
                Set<String> providers = Sets.newHashSet();
                Map<String, String> extraMap = Maps.newHashMap();
                for (SmsProviderConfig config : providerConfigs) {
                    String customerLevels = config.getCustomerLevels();
                    LOGGER.info("规则ID：{}，星级规则：{}，当前用户星级：{}", config.getId(), customerLevels, smsContent.getCustomerLevel());
                    if (StringUtils.isEmpty(customerLevels)) {
                        providers.add(config.getProviderCode());
                        if (StringUtils.isNotEmpty(config.getExtraParam())) {
                            extraMap.put(config.getProviderCode(), config.getExtraParam());
                        }
                    } else {
                        List<String> customerLevelList = Arrays.asList(customerLevels.split(","));
                        if (customerLevelList.contains(smsContent.getCustomerLevel())) {
                            providers.add(config.getProviderCode());
                            if (StringUtils.isNotEmpty(config.getExtraParam())) {
                                extraMap.put(config.getProviderCode(), config.getExtraParam());
                            }
                        }
                    }
                }
                if (!CollectionUtils.isEmpty(providers)) {
                    isVerified = true;
                    smsContent.setProvidercode(StringUtils.join(providers, ","));
                    smsContent.setExtraParam(JSON.toJSONString(extraMap));
                    LOGGER.info("星级分级规则配置选择的供应商为：{}", smsContent.getProvidercode());
                } else {
                    isVerified = false;
                    String desc = String.format("规则配置没有匹配到对应的供应商，过滤的规则配置为：{}", JSON.toJSONString(providerConfigs));
                    smsOperateDao.genSmsRecord(genBatchNo, smsContent, SmsGenRecord.Status.CHECK_FAILED.getStatus(), desc);
                }
            }
        }
        return isVerified;
    }

    private boolean validPhoneAndLoginName(String originalPhone, String orginLoginName) {
        String[] phones = StringUtils.split(originalPhone, Constants.NUMBERS_SEPARATOR);
        String[] loginNames = StringUtils.split(orginLoginName, Constants.NUMBERS_SEPARATOR);
        if (phones.length != loginNames.length) {
            return false;
        }
        for (String loginName : loginNames) {
            if (StringUtils.isBlank(StringUtils.trim(loginName))) {
                return false;
            }
        }
        return true;
    }

    @Override
    public SmsAccountQueryResponse querySmsAccount(SmsAccountQueryRequest request) {
        SmsAccountQueryResponse response = new SmsAccountQueryResponse();
        response.setCode(Constants.EXECUTE_SUCCESS);
        try {
            String productId = request.getProductId();
            String smsType = request.getSmsType();
            String customerLevel = request.getCustomerLevel();
            //校验参数非空
            Validate.notBlank(productId, Constants.VALIDATE_REQUIRED, "productId");
            Validate.notBlank(smsType, Constants.VALIDATE_REQUIRED, "smsType");
            Validate.notBlank(customerLevel, Constants.VALIDATE_REQUIRED, "customerLevel");

            String tier = smsOperateDao.querySmsTypeTier(smsType);
            if (StringUtils.isBlank(tier)) {
                response.setCode(Constants.EXECUTE_ERROR);
                response.setMessage("For smsType there is no tier in db");
                return response;
            }

            String countryCode = request.getCountryCode();
            List<Configuration> activeAccounts = smsOperateDao.getActiveAccounts(productId, Integer.valueOf(tier), customerLevel, StringUtils.isNotEmpty(countryCode) && !CountryCode.CHINA_2.equals(countryCode), null, null, null, 0, countryCode);
            if (CollectionUtils.isEmpty(activeAccounts)) {
                response.setCode(Constants.EXECUTE_ERROR);
                response.setMessage("there is no any account in db for your sms type");
                return response;
            }
            List<SmsAccount> list = new ArrayList<>(activeAccounts.size());
            for (Configuration configuration : activeAccounts) {
                SmsAccount smsAccount = new SmsAccount();
                smsAccount.setProviderCode(configuration.getProviderCode());
                smsAccount.setProviderName(configuration.getProviderName());

                list.add(smsAccount);
            }
            response.setSmsAccountList(list);
        } catch (IllegalArgumentException e) {
            response.setCode(Constants.PARAMETERS_CAN_NOT_BE_NULL);
            response.setMessage("there is null in parameters");
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            response.setCode(Constants.EXECUTE_EXCEPTION);
            response.setMessage(e.getMessage());
        }

        return response;
    }

    @Override
    public SmsRecordQueryResponse querySmsRecord(SmsRecordQueryRequest request) {
        LOGGER.info(String.format("smsRecordQuery start %s", request.toString()));
        SmsRecordQueryResponse response = new SmsRecordQueryResponse();
        response.setRequestId(request.getRequestId());

        String productId = request.getProductId();
        String mobileNo = request.getMobileNo();
        if (StringUtils.isAnyBlank(productId, mobileNo)) {
            response.setCode(Constants.EXECUTE_EXCEPTION);
            response.setMessage("产品id和手机号码都不可以为空！");
            return response;
        }
        String typeCode = request.getTypeCode();
        String startDate = request.getStartDate();
        String endDate = request.getEndDate();
        String source = request.getSource();
        try {
            int count = smsOperateDao.countSmsContent(productId, mobileNo, startDate, endDate, typeCode, source, request.getSender());
            response.setSmsRecordNumber(count);
            response.setCode(Constants.EXECUTE_SUCCESS);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            response.setCode(Constants.EXECUTE_EXCEPTION);
            response.setMessage(e.getMessage());
        }
        LOGGER.info(String.format("smsRecordQuery end %s", response.toString()));
        return response;
    }

    private boolean checkAndFormatSmsContent(SmsContent content, String genBatchNo) {
        Integer failStatus = SmsGenRecord.Status.CHECK_FAILED.getStatus();
        String desc = "";
        if (null == content) {
            desc = "短信内容不能为空(SmsContent this field cannot be empty)";
            LOGGER.error(desc);
            smsOperateDao.genSmsRecord(genBatchNo, content, failStatus, desc);
            return false;
        }
        if (StringUtils.isBlank(content.getProductid())) {
            desc = "productid不能为空(productid cannot be empty)";
            LOGGER.error("{},params:{}", desc, content);
            smsOperateDao.genSmsRecord(genBatchNo, content, failStatus, desc);
            return false;
        }
        if (StringUtils.isBlank(content.getSmstype())) {
            desc = "smstype不能为空(smstype cannot be empty)";
            LOGGER.error("{},params:{}", desc, content);
            smsOperateDao.genSmsRecord(genBatchNo, content, failStatus, desc);
            return false;
        }
        if (StringUtils.isBlank(content.getUseTemplateFlag())) {
            desc = "useTemplateFlag不能为空(useTemplateFlag cannot be empty)";
            LOGGER.error("{},params:{}", desc, content);
            smsOperateDao.genSmsRecord(genBatchNo, content, failStatus, desc);
            return false;
        }
        if (StringUtils.isBlank(content.getKey())) {
            desc = "key不能为空(key cannot be empty)";
            LOGGER.error("{},params:{}", desc, content);
            smsOperateDao.genSmsRecord(genBatchNo, content, failStatus, desc);
            return false;
        }

        //判断非空或者手机号码长度<8（国际上没有小于8位的手机号），
        if (StringUtils.isBlank(content.getPhone()) || StringUtils.length(content.getPhone()) < 8) {
            desc = "phone格式不正确(Phone number format is not correct)";
            LOGGER.error("{},params:{}", desc, content);
            smsOperateDao.genSmsRecord(genBatchNo, content, failStatus, desc);
            return false;
        }

        String[] temp = StringUtils.split(content.getPhone(), Constants.NUMBERS_SEPARATOR);
        // VALIDATE PHONE NUMBER COUNT
        int smsCount = temp.length;
        if (smsCount < 1 || smsCount > 100) {
            desc = String.format("电话数量必须是1-100之间(phone counts must bwtween 1 and 100),数量：%d，参数:%s", temp.length, content);
            LOGGER.error(desc);
            smsOperateDao.genSmsRecord(genBatchNo, content, failStatus, desc);
            return false;
        }
        // VALIDATE KEY
        Product product = Product.getProducts().get(content.getProductid());
        String key = Convert.MD5Encode((content.getLoginname() + content.getProductid() + product.getKey() + content.getPhone() + content.getSmstype()));
        if (!StringUtils.equals(content.getKey(), key)) {
            desc = "key值不正确(key is Incorrect)";
            LOGGER.error("{},params:{},本地key:{}", desc, content, key);
            smsOperateDao.genSmsRecord(genBatchNo, content, failStatus, desc);
            return false;
        }
        //去重 去空格
        content.setPhone(StringUtils.join(temp, Constants.NUMBERS_SEPARATOR));
        //批量发送
        if (smsCount > 1) {
            String originalLoginName = content.getLoginname();
            if (StringUtils.split(content.getLoginname(), Constants.NUMBERS_SEPARATOR).length > 1 && (!validPhoneAndLoginName(content.getPhone(), originalLoginName))) {
                desc = "电话数量和登录名数量不一致(phones counts must equals loginNames count)";
                LOGGER.error("电话数量和登录名数量不一致(phones counts must equals loginNames count)", temp.length, content);
                smsOperateDao.genSmsRecord(genBatchNo, content, failStatus, desc);
                return false;
            }
        } else {
            //区域码非空
            if (StringUtils.isNotBlank(content.getCountryCode())) {
                //发往中国大陆 校验是否是普通的11位手机号数字
                if (content.getCountryCode().equals(CountryCode.CHINA_1) || content.getCountryCode().equals(CountryCode.CHINA_2)) {
                    if (StringUtils.length(content.getPhone()) != 11 && !(StringUtils.startsWithAny(content.getPhone(), CountryCode.CHINA_1, CountryCode.CHINA_2))) {
                        desc = "phone格式不正确,中国大陆手机号应为11位数(Phone number format is not correct)";
                        LOGGER.error("{},params:{}", desc, content);
                        smsOperateDao.genSmsRecord(genBatchNo, content, failStatus, desc);
                        return false;
                    }
                }
            }
        }
        SmsType smsType = smsOperateDao.querySmsType(content.getSmstype());
        if (ObjectUtils.isEmpty(smsType)) {
            desc = String.format("短信类型不存在,%s", content.getSmstype());
            LOGGER.error(desc);
            smsOperateDao.genSmsRecord(genBatchNo, content, failStatus, desc);
            return false;
        }
        //文本短信需要去匹配模板
        if (!StringUtils.equals("1", content.getSendMethod())) {
            //该类型只能通过模板发送 0否 1是
            Integer disableFlag = smsType.getDisableFlag();
            if (disableFlag == 1 && !Constants.TEMPLATE_FLAG_ENABLE.equals(content.getUseTemplateFlag())) {
                desc = String.format("该类型只能通过模板发送,当前是否使用模板发送：%s，数据库值：%d", content.getUseTemplateFlag() + ",0是 1否", disableFlag);
                LOGGER.error(desc);
                smsOperateDao.genSmsRecord(genBatchNo, content, failStatus, desc);
                return false;
            }

            //模板匹配必须是只有一个用户
            if ((Constants.TEMPLATE_FLAG_ENABLE).equals(content.getUseTemplateFlag())) {
                try {
                    String smsContentTemplate = smsOperateDao.getSmsContentTemplate(content);
                    if (StringUtils.isNotEmpty(smsContentTemplate)) {
                        String result = SmsUtility.compose(smsContentTemplate, content);
                        content.setSendcontent(result);
                    } else {
                        desc = "未查到对应的短信模板：" + content.getSmstype();
                        LOGGER.error(desc);
                        smsOperateDao.genSmsRecord(genBatchNo, content, failStatus, desc);
                        return false;
                    }
                } catch (Exception e) {
                    LOGGER.error("短信模板内容组装异常,", e);
                    smsOperateDao.genSmsRecord(genBatchNo, content, failStatus, "短信模板内容组装异常," + e.getMessage());
                    return false;
                }

            }
        }
        //短信内容不能为空
        if (StringUtils.isBlank(content.getSendcontent())) {
            desc = "短信内容不能为空(SmsContent this field cannot be empty)";
            LOGGER.error(desc);
            smsOperateDao.genSmsRecord(genBatchNo, content, failStatus, desc);
            return false;
        }
        return true;
    }

    @Override
    public void saveS35Result(String contentId, Integer status,String port) {
        try {
            boolean sent = true;
            Sms sms = new Sms();
            sms.setContentId(contentId);
            sms.setSmsResponseFlag(status);
            sms.setPort(port);
            //1 发送中 2 发送成功 -1 格式不正确
            sms.setSmsRemarks(status == 2 ? "success" : "fail");
            if (status == -1) {
                sms.incrementFailTimes();
                sent = false;
            }
            smsOperateDao.updateSmsStatus(sms);
            String splitStr = smsOperateDao.getAccountByContentId(contentId);
            if (StringUtils.isNotBlank(splitStr)){
                String[] arr = splitStr.split("[_]");
                smsOperateDao.updateAccountStats(arr[0], sent);
                smsOperateDao.updateMonitorRecord(arr[1], status);
            }
        } catch (Exception e) {
            LOGGER.error("S35推送结果更新失败：{}", e.getMessage(), e);
        }

    }
}