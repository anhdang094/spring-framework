package com.ws;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * @description:
 * @author: Condi
 * @create: 2019-01-07 11:13
 **/
@ApiModel
public class SmsType implements Serializable{

    @ApiModelProperty(value = "类型id")
    private Long typeId;
    @ApiModelProperty(value = "类型名称")
    private String typeName;
    @ApiModelProperty(value = "类型优先级")
    private String tier;
    @ApiModelProperty(value = "类型CODE")
    private String typeCode;

    @ApiModelProperty(value = "短信模板")
    private String template;

    /*该类型只能通过模板发送 0否 1是*/
    private Integer disableFlag;

    public Integer getDisableFlag() {
        return disableFlag;
    }

    public void setDisableFlag(Integer disableFlag) {
        this.disableFlag = disableFlag;
    }

    public Long getTypeId() {
        return typeId;
    }

    public void setTypeId(Long typeId) {
        this.typeId = typeId;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public String getTier() {
        return tier;
    }

    public void setTier(String tier) {
        this.tier = tier;
    }

    public String getTypeCode() {
        return typeCode;
    }

    public void setTypeCode(String typeCode) {
        this.typeCode = typeCode;
    }

    public String getTemplate() {
        return template;
    }

    public void setTemplate(String template) {
        this.template = template;
    }

    public SmsType(Long typeId, String typeName, String tier, String typeCode,Integer disableFlag) {
        this.typeId = typeId;
        this.typeName = typeName;
        this.tier = tier;
        this.typeCode = typeCode;
        this.disableFlag=disableFlag;
    }

    public SmsType(Long typeId, String typeName, String tier, String typeCode, String template) {
        this.typeId = typeId;
        this.typeName = typeName;
        this.tier = tier;
        this.typeCode = typeCode;
        this.template = template;
    }

    public SmsType() {
    }
}


    
