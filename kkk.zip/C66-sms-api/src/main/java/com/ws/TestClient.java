package com.ws;

import java.util.List;

import com.intech.sms.util.CountryCode;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;

import com.intech.sms.util.Convert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TestClient {

	/**
	 * @param args
	 */
	@SuppressWarnings({ "unused", "rawtypes", "unchecked" })
	public static void main(String[] args) {
		// ApplicationContext context=new ClassPathXmlApplicationContext(new
		// String[]{"applicationContext-webservice.xml"});

		// SayHello client=(SayHello)context.getBean("client");
		// System.out.println("Server id:"+client.say("china"));
		final Logger smslogger = LoggerFactory.getLogger("smsLog");
		try {
			JaxWsProxyFactoryBean factory = new JaxWsProxyFactoryBean();
			// just for log printing
			/*factory.getInInterceptors().add(new LoggingInInterceptor());
			factory.getOutInterceptors().add(new LoggingOutInterceptor());*/
			// must set service class
			factory.setServiceClass(SmsService.class);
			// must set wsdl address
			// http://SMS.DICE8.WS:8080/services/SmsAPI
			factory.setAddress("http://localhost:80/services/SmsAPI");
			// factory.setAddress("http://localhost:9080/SmsSender/services/SmsAPI");
			// factory.setAddress("http://sms.dice8.ws:8080/services/SmsAPI");//地址换成真实调用接口
			// construct key with MD5
			String keyString = null;
			// keyString = MD5(keyString)
			SmsService client = (SmsService) factory.create();
			// 超时设置
			Client proxyClient = ClientProxy.getClient(client);
			HTTPConduit conduit = (HTTPConduit) proxyClient.getConduit();
			HTTPClientPolicy policy = new HTTPClientPolicy();
			policy.setConnectionTimeout(60000);
			policy.setReceiveTimeout(60000);
			conduit.setClient(policy);

			SmsContentRequest request = new SmsContentRequest();
			// 以创富为例WS客户端测试
			List list = request.getSmsContents();
			String loginname = "conditest";
			String productid = "A01";
//			 String phone="9617664405";
			String typecode = "60010";
			String productKey = "%$A0(1)##";
			String providerid = "S86";
			
			// String productKey="ABC456abc";
			// String amount="500";
//			 for(int i=0;i<9;i++){
			SmsContent content = new SmsContent();
			content.setLoginname(loginname);// 必须，需要加密用到
			content.setProductid(productid);
			content.setProvidercode(providerid);
			content.setSmstype(typecode);
			content.setParam1(loginname);
			content.setParam2(loginname);
			String phone = "9617664405,";
			content.setPhone(phone);
			content.setUseTemplateFlag("0");
			String key = content.getLoginname() + productid + productKey + phone + typecode;// 加密方法
			String enkey = Convert.MD5Encode(key);
			System.out.println("enkey===" + enkey);
			content.setKey(enkey);
			content.setSender("system");
			content.setRequestId("10000001");
			content.setSendcontent("测试发送短信");
			content.setCustomerLevel("1");
			content.setCountryCode(CountryCode.PHILIPPINES_2);
			list.add(content);

//			}
			request.setSmsContents(list);
			Long time = System.currentTimeMillis();
//			for(int i = 0; i < 50; i++)
				System.out.println("==========================================return code:" + client.insert(request));
			smslogger.info("insert sms record size:" + list.size()
					+ " task using time=" + (System.currentTimeMillis() - time)
					+ "<<<<<<<");
			/*
			 * java.net.URL url=new
			 * java.net.URL("http://localhost:8080/SmsSender/services/SmsAPI?wsdl"
			 * ); java.net.HttpURLConnection
			 * con=(java.net.HttpURLConnection)url.openConnection(); //
			 * con.setRequestMethod("post"); con.connect();
			 * System.out.print(con.getInputStream());
			 */
		} catch (Exception ex) {
			ex.printStackTrace();
			smslogger.info(ex.getMessage());
		}

	}

}
