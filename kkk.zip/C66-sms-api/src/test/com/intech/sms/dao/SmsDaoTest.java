package com.intech.sms.dao;

import com.intech.sms.util.DateUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.test.context.junit4.SpringRunner;

import java.sql.ResultSet;
import java.sql.SQLException;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SmsDaoTest {

    @Autowired
    private SMSOperateDao sMSOperateDao;
    @Autowired
    private UniversalDAO universalDAO;
    @Test
    public void getUnsentReplies() throws Exception {

        System.out.println(sMSOperateDao.getSmsConstantByKey("A02","dd"));
        System.out.println(sMSOperateDao.countSmsContent("B06","", DateUtil.getCurrentDateString(),DateUtil.getCurrentDateString(),"60030",null,"cc"));
    }
}
