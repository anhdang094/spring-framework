package com.intech.sms.facade.impl;


import com.intech.sms.constants.MqTypeEnum;
import com.intech.sms.facade.MsgMqFacade;
import com.intech.sms.model.MsgMqSendRecord;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class MsgMqFacadeImplTest {

    @Autowired
    private MsgMqFacade msgMqFacade;

    @Test
    public void createMsgMq() throws Exception {
        MsgMqSendRecord bean = new MsgMqSendRecord();
        bean.setProductId("A02");
        bean.setJmsQueueName("1111");
        bean.setMsgData("fdshh");
        bean.setMsgType(Integer.valueOf(MqTypeEnum.ACTIVE_MQ.getCode()));
        msgMqFacade.createMsgMq(bean);
    }


}
