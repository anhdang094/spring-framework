package com.intech.sms.service;

import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import org.junit.Test;

public class S22SendServiceTest {

    @Test
    public void send() throws Exception {
        Configuration config = new Configuration();
        config.setVcpPort("8080");
        config.setVcpPwd("000000");
        config.setVcpServer("10.66.72.136");
        config.setVcpUserId("hahahahaha");
        config.setMainUserId("abcdefg");
        Sms sms = new Sms();
        sms.setSendContent("12312321312");
        sms.setPhoneNumber("13012345678");

        S22SendService service = new S22SendService(config);
        service.send(sms);
    }

}
