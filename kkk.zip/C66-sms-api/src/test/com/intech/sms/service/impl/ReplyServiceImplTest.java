package com.intech.sms.service.impl;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.test.context.junit4.SpringRunner;

import java.sql.ResultSet;
import java.sql.SQLException;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ReplyServiceImplTest {

    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Test
    public void getUnsentReplies() throws Exception {
        String sql = "SELECT * FROM T_SMS_REPLIES WHERE JMS_FLAG = 0 AND PRODUCT_ID = ?";
        jdbcTemplate.query(sql, new String[]{"B06"}, new ResultSetExtractor<Object>() {
            @Override
            public Object extractData(ResultSet resultSet) throws SQLException, DataAccessException {
                System.out.println(111);
                System.out.println(resultSet.getRow());
                return null;
            }
        });
    }
}
