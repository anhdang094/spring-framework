package com.intech.sms.util;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.intech.dbcryptor.Cryptor;
import com.intech.sms.model.Configuration;
import com.intech.sms.model.Reply;
import com.intech.sms.model.Sms;
import com.ws.SmsServiceImplTest;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URLEncoder;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;


/**
 * @description: Cryptor
 * @author: Condi
 * @create: 2019-01-04 14:47
 **/

public class CryptorTest {
    public class S02Reply {
        private String caller;
        private String msg;
        private String deliverdate;

        public S02Reply() {

        }

        public S02Reply(String caller, String msg, String deliverdate) {
            this.caller = caller;
            this.msg = msg;
            this.deliverdate = deliverdate;
        }

        public String getCaller() {
            return caller;
        }

        public void setCaller(String caller) {
            this.caller = caller;
        }

        public String getMsg() {
            return msg;
        }

        public void setMsg(String msg) {
            this.msg = msg;
        }

        public String getDeliverdate() {
            return deliverdate;
        }

        public void setDeliverdate(String deliverdate) {
            this.deliverdate = deliverdate;
        }

    }

    @Test
    public void testLog(){
        try {
            System.out.println("UTF-16BE:"+ URLEncoder.encode("【乐天堂】谢谢您的支持！您的验证码：123456，此验证码将在为5分钟后失效", "UTF-16BE"));

        }catch (Exception e){

        }
        System.out.println(DateTimeFormatter.ofPattern("yyyyMMddHHmmss").format(LocalDateTime.now()));
        System.out.println("SHA256加密:"+ Convert.SHA256Encode("20190305103912XXXXYYYYZZZZ"));
        System.out.println("加密:"+ Cryptor.encryptContent("123qwe"));
        System.out.println("加密:"+ Convert.MD5Encode("乐*橙老*虎*机100％首*存礼，视讯霸气送25％首*存礼，外还有高额返水。快过来试试吧9158点fun【乐*橙】"));
        System.out.println("加密:"+ Convert.MD5Encode("13062532553,13062532554"));
        System.out.println("加密:"+ Convert.MD5Encode("13062532553"));
        String str=",13062532553,13062532554,";
        System.out.println(JSON.toJSON(str.split(",")));
        System.out.println(JSON.toJSON(StringUtils.split(str.toString(), ",")));
        System.out.println(Arrays.asList(StringUtils.split(str.toString(),",")));
        System.out.println(JSON.toJSON(new HashSet<>(Arrays.asList(StringUtils.split(str.toString(),","))).toArray()));
        System.out.println("加密:"+ ComposePhone.getPhone(",13062532553,13062532554,", ",", CountryCode.CHINA_1, CountryCode.CHINA_1));
    }

    @Test
    public void jsonTest() {
        Reply reply = new Reply();
        reply.setReceiveDate(new Timestamp(System.currentTimeMillis()));
        reply.setCreatedDate(new Timestamp(System.currentTimeMillis()));
        reply.setPhone("111");
        String fastString = JSON.toJSONString(reply);
        System.out.println("json:" + JSON.toJSONStringWithDateFormat(reply, "yyyy-MM-dd HH:mm:ss"));
        System.out.println("json:" + fastString);
        Reply replynew2 = JSON.parseObject(fastString, Reply.class);
        String replyJSon = "[{\"id\":32129,\"caller\":\"15680630627\",\"msg\":\"2208\",\"deliverdate\":\"2019-01-08 08:47:12\"},{\"id\":32130,\"caller\":\"15180941275\",\"msg\":\"2845\",\"deliverdate\":\"2019-01-08 09:21:10\"},{\"id\":32131,\"caller\":\"18853389769\",\"msg\":\"9003\",\"deliverdate\":\"2019-01-08 10:16:15\"},{\"id\":32132,\"caller\":\"19953379144\",\"msg\":\"8743\",\"deliverdate\":\"2019-01-08 10:33:22\"},{\"id\":32133,\"caller\":\"15736224306\",\"msg\":\"8862\",\"deliverdate\":\"2019-01-08 10:39:07\"},{\"id\":32134,\"caller\":\"17786035523\",\"msg\":\"1110\",\"deliverdate\":\"2019-01-08 11:09:17\"},{\"id\":32135,\"caller\":\"18580531754\",\"msg\":\"9259\",\"deliverdate\":\"2019-01-08 11:11:17\"},{\"id\":32136,\"caller\":\"15571666308\",\"msg\":\"1302\",\"deliverdate\":\"2019-01-08 12:32:20\"},{\"id\":32137,\"caller\":\"15623009310\",\"msg\":\"6267\",\"deliverdate\":\"2019-01-08 14:14:25\"},{\"id\":32138,\"caller\":\"17886318670\",\"msg\":\"5416\",\"deliverdate\":\"2019-01-08 14:56:26\"},{\"id\":32139,\"caller\":\"13931559053\",\"msg\":\"8741\",\"deliverdate\":\"2019-01-08 15:21:20\"},{\"id\":32140,\"caller\":\"18279869321\",\"msg\":\"2595\",\"deliverdate\":\"2019-01-08 15:22:47\"},{\"id\":32141,\"caller\":\"13345019840\",\"msg\":\"9433\",\"deliverdate\":\"2019-01-08 15:35:41\"},{\"id\":32142,\"caller\":\"13524969364\",\"msg\":\"9341\",\"deliverdate\":\"2019-01-08 15:44:15\"},{\"id\":32143,\"caller\":\"13524969364\",\"msg\":\"9642\",\"deliverdate\":\"2019-01-08 15:45:49\"},{\"id\":32144,\"caller\":\"18510661292\",\"msg\":\"6607\",\"deliverdate\":\"2019-01-08 15:47:29\"},{\"id\":32145,\"caller\":\"18510661292\",\"msg\":\"6607\",\"deliverdate\":\"2019-01-08 15:49:26\"},{\"id\":32146,\"caller\":\"13341953873\",\"msg\":\"9613\",\"deliverdate\":\"2019-01-08 16:21:31\"},{\"id\":32147,\"caller\":\"13341953873\",\"msg\":\"8613\",\"deliverdate\":\"2019-01-08 16:23:01\"},{\"id\":32148,\"caller\":\"15812147167\",\"msg\":\"6713\",\"deliverdate\":\"2019-01-08 16:45:51\"},{\"id\":32149,\"caller\":\"18913986592\",\"msg\":\"5183\",\"deliverdate\":\"2019-01-08 17:18:16\"},{\"id\":32150,\"caller\":\"17776399509\",\"msg\":\"9373\",\"deliverdate\":\"2019-01-08 17:34:15\"},{\"id\":32151,\"caller\":\"17766964035\",\"msg\":\"7069\",\"deliverdate\":\"2019-01-08 17:59:25\"},{\"id\":32152,\"caller\":\"17333106603\",\"msg\":\"6496\",\"deliverdate\":\"2019-01-08 18:28:54\"},{\"id\":32153,\"caller\":\"18077385611\",\"msg\":\"3907\",\"deliverdate\":\"2019-01-08 18:49:41\"},{\"id\":32154,\"caller\":\"18477194546\",\"msg\":\"7816\",\"deliverdate\":\"2019-01-08 21:32:30\"},{\"id\":32155,\"caller\":\"18008645920\",\"msg\":\"5103\",\"deliverdate\":\"2019-01-08 22:06:06\"},{\"id\":32156,\"caller\":\"18508383536\",\"msg\":\"1033\",\"deliverdate\":\"2019-01-08 23:00:47\"},{\"id\":32157,\"caller\":\"13437136798\",\"msg\":\"4508\",\"deliverdate\":\"2019-01-08 23:30:52\"},{\"id\":32158,\"caller\":\"13437136798\",\"msg\":\"4508\",\"deliverdate\":\"2019-01-08 23:31:55\"},{\"id\":32159,\"caller\":\"18883799242\",\"msg\":\"0418\",\"deliverdate\":\"2019-01-09 00:16:59\"},{\"id\":32160,\"caller\":\"18223431936\",\"msg\":\"9547\",\"deliverdate\":\"2019-01-09 00:46:31\"},{\"id\":32161,\"caller\":\"17602370503\",\"msg\":\"8213\",\"deliverdate\":\"2019-01-09 01:47:59\"},{\"id\":32162,\"caller\":\"17623744088\",\"msg\":\"2753\",\"deliverdate\":\"2019-01-09 01:56:20\"},{\"id\":32163,\"caller\":\"13356612310\",\"msg\":\"3974\",\"deliverdate\":\"2019-01-09 02:04:20\"},{\"id\":32164,\"caller\":\"18627750338\",\"msg\":\"0970\",\"deliverdate\":\"2019-01-09 02:31:14\"},{\"id\":32165,\"caller\":\"18297891234\",\"msg\":\"4392\",\"deliverdate\":\"2019-01-09 02:38:24\"},{\"id\":32166,\"caller\":\"15907177742\",\"msg\":\"2768\",\"deliverdate\":\"2019-01-09 03:26:26\"},{\"id\":32167,\"caller\":\"15357423911\",\"msg\":\"6814\",\"deliverdate\":\"2019-01-09 03:33:26\"},{\"id\":32168,\"caller\":\"15173376473\",\"msg\":\"2485\",\"deliverdate\":\"2019-01-09 06:31:14\"},{\"id\":32169,\"caller\":\"15173598070\",\"msg\":\"2605\",\"deliverdate\":\"2019-01-09 06:53:06\"},{\"id\":32170,\"caller\":\"18778276002\",\"msg\":\"1338\",\"deliverdate\":\"2019-01-09 07:12:25\"},{\"id\":32171,\"caller\":\"17678096222\",\"msg\":\"1636\",\"deliverdate\":\"2019-01-09 07:49:20\"},{\"id\":32172,\"caller\":\"17678096222\",\"msg\":\"\\u786e\\u5b9a1636\",\"deliverdate\":\"2019-01-09 07:50:15\"},{\"id\":32173,\"caller\":\"17772431566\",\"msg\":\"1377\",\"deliverdate\":\"2019-01-09 08:27:51\"},{\"id\":32174,\"caller\":\"18874315429\",\"msg\":\"4269\",\"deliverdate\":\"2019-01-09 08:40:45\"},{\"id\":32175,\"caller\":\"15576944531\",\"msg\":\"5910\",\"deliverdate\":\"2019-01-09 09:30:29\"},{\"id\":32176,\"caller\":\"18676594049\",\"msg\":\"1806\",\"deliverdate\":\"2019-01-09 09:36:30\"},{\"id\":32177,\"caller\":\"13079206010\",\"msg\":\"1486\",\"deliverdate\":\"2019-01-09 09:54:41\"},{\"id\":32178,\"caller\":\"18331365241\",\"msg\":\"0687\",\"deliverdate\":\"2019-01-09 10:47:53\"}]";
        replyJSon="[]";

        System.out.println(replynew2);
        JSONArray s02Replies = JSONArray.parseArray(replyJSon);
        if (s02Replies.size() == 0) {
            System.out.println("(S02) No replies were acquired at this time for " + ".");
        } else {
            System.out.println("(S02) Replies acquired. Count: " + s02Replies.size());

            for (int i = 0; i < s02Replies.size(); i++) {
                JSONObject obj = (JSONObject) s02Replies.get(i);
                System.out.println(obj.getString("caller"));
                System.out.println(obj.getString("msg"));
                System.out.println(obj.getString("deliverdate"));
                System.out.println(obj.getString("id"));
            }
        }
         String response="4";
        int sent =0;
        if(StringUtils.isNotBlank(response)){
            int responseCode = Integer.parseInt(response);
            switch (responseCode) {
                //参数不正确
                case 0:
                    sent = -1;
                    break;
                //成功
                case 1:
                    sent = 1;
                    break;
                case 2:
                    System.out.println("S02 ERROR:{}!!!!!!!!!!!!!!!!!!!!!!无此账户!!!!!!!!!!!!!!!!!!!!!!!");
                    break;
                case 3:
                    System.out.println("S02 ERROR:{}!!!!!!!!!!!!!!!!!!!!!!账户未激活!!!!!!!!!!!!!!!!!!!!!!!");
                    break;
                case 4:
                    System.out.println("S02 ERROR:{}!!!!!!!!!!!!!!!!!!!!!!账户余额不足!!!!!!!!!!!!!!!!!!!!!!!");
                    break;
                case 5:
                    System.out.println("S02 ERROR:{}!!!!!!!!!!!!!!!!!!!!!!非法请求!!!!!!!!!!!!!!!!!!!!!!!");
                    break;
                //号码无效
                case 6:
                    sent = -1;
                    break;
                //号码无效
                case 7:
                    System.out.println("S02 ERROR:{}!!!!!!!!!!!!!!!!!!!!!!预约超时!!!!!!!!!!!!!!!!!!!!!!!");
                    break;
                //号码无效
                case 8:
                    System.out.println("S02 ERROR:{}!!!!!!!!!!!!!!!!!!!!!!账户不支持群发!!!!!!!!!!!!!!!!!!!!!!!");
                    break;
                default:
                    System.out.println("S02 ERROR:{}!!!!!!!!!!!!!!!!!!!!!!短信接口方异常!!!!!!!!!!!!!!!!!!!!!!!");
                    break;
            }
        }
    }

    @Test
    public void testmath(){
        try {
            Random random = new Random(); // 初始化随机数产生器
            System.out.println(Math.abs(random.nextInt())%32);
            System.out.println(Math.abs(random.nextInt())%32);
            System.out.println(Math.abs(random.nextInt())%32);
            System.out.println(Math.abs(random.nextInt())%32);
            System.out.println(random.nextInt(32));
            System.out.println(random.nextInt(32));
            System.out.println(random.nextInt(32));
            System.out.println(random.nextInt(32));
        }catch (Exception e){

        }

    }
}


    
