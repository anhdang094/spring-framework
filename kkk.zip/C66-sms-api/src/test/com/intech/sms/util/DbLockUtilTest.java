package com.intech.sms.util;


import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DbLockUtilTest {
    private static final Logger logger = LoggerFactory.getLogger(DbLockUtil.class);

    @Test
    public void testLock() throws Exception {
        MqRunnable runnable = new MqRunnable();
        for(int i=10;i>0;i--){
           new Thread(runnable,"线程["+i+"]").start();
        }

        System.in.read();
    }

    class MqRunnable implements Runnable{
        public  int sum = 1000;
        @Override
        public void run() {
            while(sum>0){
                if(DbLockUtil.lock()){
                    System.out.println(Thread.currentThread().getName()+"现在卖掉了第"+(sum--)+"张票");
                    DbLockUtil.unLock(false);
                }
            }
        }
    }

}
