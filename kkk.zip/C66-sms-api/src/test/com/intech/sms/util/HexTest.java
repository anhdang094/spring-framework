package com.intech.sms.util;

import com.intech.sms.model.Sms;
import org.apache.commons.lang3.StringUtils;

import java.nio.charset.Charset;

public class HexTest {

    public static void main(String[] args) {
        /*String str = "测试";
        System.out.println("test string : "+str);

        String hexEncode = HexUtil.encode(str.getBytes());
        System.out.println("HexUtil.encode Result : "+hexEncode);

        byte[] bytes = HexUtil.decode(hexEncode);
        System.out.println("HexUtil.decode Result : "+new String(bytes));*/



        /*String phone = "0551685211";
        Pattern pattern = Pattern.compile("(((03|3)[2-9])|((05|5)[6,8,9])|((07|7)[0,6-9])|((08|8)[1-5]))\\d{7}");
        System.out.println(pattern.matcher(phone).find());*/

        String str = "测试";
        byte[] bytes = str.getBytes(Charset.forName("utf-16be"));

        System.out.println("http://47.91.159.120:1401/send?username=ivihk&password=NzKh9Eh&to=13266071512&from=85260890555&hex-content="+HexUtil.encode(bytes)+"&coding=8");

        Sms sms = new Sms();
        sms.setProductId("A01");
        sms.setCountryCode("0064");
        sms.setPhoneNumber("85692548,8665283648");

        String numbers;
        String countryCode =CountryCode.CHINA_1;
            /*if (ProductConstants.PRODUCT_ID_C07.equalsIgnoreCase(sms.getProductId())) {
                numbers = ComposePhone.getPhone(sms.getPhoneNumber(), Constants.NUMBERS_SEPARATOR, CountryCode.VIETNAM_1, CountryCode.VIETNAM_1);
            } else {
                numbers = ComposePhone.getPhone(sms.getPhoneNumber(), Constants.NUMBERS_SEPARATOR, CountryCode.CHINA_1, CountryCode.CHINA_1, CountryCode.MACAU_1, CountryCode.HONG_KONG_1, CountryCode.PHILIPPINES_1, CountryCode.CHINA_TAIWAN_1);
            }*/
        if (ProductConstants.PRODUCT_ID_C07.equalsIgnoreCase(sms.getProductId())) {
            countryCode =CountryCode.VIETNAM_1;
        } else {
            if(StringUtils.isNotBlank(sms.getCountryCode())){
                countryCode = sms.getCountryCode().replaceAll("00","");
            }
        }
        numbers = ComposePhone.getPhone(sms.getPhoneNumber(), Constants.NUMBERS_SEPARATOR, countryCode, CountryCode.CHINA_1, CountryCode.MACAU_1, CountryCode.HONG_KONG_1, CountryCode.PHILIPPINES_1, CountryCode.CHINA_TAIWAN_1);

        System.out.println(sms.getCountryCode().replaceAll("00",""));
        System.out.println(numbers);

    }


}
