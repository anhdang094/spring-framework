package com.intech.sms.work;

import com.intech.configuration.PropertiesConfig;
import com.intech.sms.service.ReplyService;
import com.intech.sms.util.PHPDESEncrypt;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;


@RunWith(SpringRunner.class)
@SpringBootTest
public class MessageSenderTest {
    @Autowired
    private ReplyService replyService;
    @Autowired
    private PropertiesConfig propertiesConfig;
   /* @Test
    public void send() throws Exception {
        String productId = "A04";

        List<Reply> repliesForJMS = replyService.getUnsentReplies(productId);
        if (repliesForJMS != null) {
            for (Reply reply : repliesForJMS) {
                String jsonString = JSON.toJSONString(reply);
                RabbitMqUtils.send(productId, "exchange_sms_reply", jsonString, propertiesConfig.getJsmQueneName(), new MQCallBack() {
                    @Override
                    public void afterSuccessDo(Reply reply) {
                        System.out.println(jsonString);
                    }

                    @Override
                    public void afterFailDo(Reply reply) {
                        System.out.println(jsonString);
                    }
                },reply);
            }
        }
        System.in.read();
    }*/

    @Test
    public void setPropertiesConfig() throws Exception {
        String productId = "B06";

        PHPDESEncrypt ph =   new PHPDESEncrypt(productId,"03");
       System.out.println(ph.encrypt("123123"));



    }

}
