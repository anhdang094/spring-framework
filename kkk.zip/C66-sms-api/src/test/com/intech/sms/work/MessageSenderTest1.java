package com.intech.sms.work;

import com.alibaba.fastjson.JSON;
import com.intech.configuration.PropertiesConfig;
import com.intech.sms.model.Reply;
import com.intech.sms.service.MQCallBack;
import com.intech.sms.service.ReplyService;
import com.intech.sms.util.ActiveMqUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
public class MessageSenderTest1 {
    @Autowired
    private ReplyService replyService;
    @Autowired
    private PropertiesConfig propertiesConfig;
    @Test
    public void send() throws Exception {
        String productId = "B06";

        List<Reply> repliesForJMS = replyService.getUnsentReplies(productId);

        if (repliesForJMS != null) {
            for (Reply reply : repliesForJMS) {
                String jsonString = JSON.toJSONString(reply);
                ActiveMqUtils.send(productId, jsonString, propertiesConfig.getJsmQueneName(), new MQCallBack() {
                    @Override
                    public void afterSuccessDo(Reply reply) {
                        System.out.println(jsonString);
                    }

                    @Override
                    public void afterFailDo(Reply reply) {
                        System.out.println(jsonString);
                    }
                }, reply);
            }
        }

        System.in.read();
    }

}
