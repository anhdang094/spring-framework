package com.ws;


import com.alibaba.fastjson.JSON;
import com.intech.configuration.PropertiesConfig;
import com.intech.sms.model.Configuration;
import com.intech.sms.model.Sms;
import com.intech.sms.util.ApplicationContextSingleton;
import com.intech.sms.util.Convert;
import com.intech.sms.util.EmailSender;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.net.InetAddress;

@SpringBootTest
@RunWith(SpringRunner.class)
public class EmailSendTest {

    private static final Logger logger = LoggerFactory.getLogger(EmailSendTest.class);
    @Test
    public void testEmailSend(){
        EmailSender emailSender = ApplicationContextSingleton.getBean(EmailSender.class);
        PropertiesConfig propertiesConfig = ApplicationContextSingleton.getBean(PropertiesConfig.class);
        String emailTo = propertiesConfig.getEmailTo();
        String subject = propertiesConfig.getEmailSubject();
        String emailContent = propertiesConfig.getEmailContent().replaceFirst("\\|", "111").replaceFirst("\\|", "10");
        boolean emailSent = emailSender.send(emailTo,subject,emailContent);
        logger.info("send:{}",emailSent);
    }
}
