package com.ws;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.intech.sms.model.Configuration;
import com.intech.sms.model.Reply;
import com.intech.sms.model.Sms;
import com.intech.sms.util.HttpUtil;
import com.intech.sms.util.SmsUtility;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import com.intech.sms.util.Convert;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.net.InetAddress;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

//@SpringBootTest
//@RunWith(SpringRunner.class)
public class SmsServiceImplTest {

    private static final Logger logger = LoggerFactory.getLogger(SmsServiceImplTest.class);
    String ipRegex = "\\d+\\.\\d+\\.\\d+\\.\\d+";
    String domainRegex = "([\\w-]+\\.)+(com.cn|net.cn|gov.cn|org\\.nz|org.cn|com|net|org|gov|cc|biz|info|cn|co)\\b()*";
    @Test
    public void testMD5()throws Exception{

        String key = Convert.MD5Encode("abc123");
        String dataSourceUrl="10.180.132.73;jdbc\\:oracle\\:thin\\:@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=10.180.17.106)(PORT=27022))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=r06)));failover://(tcp://jms4.bawinx.com:61616,tcp://jms5.bawinx.com:61616,tcp://jms6.bawinx.com:61616)?initialReconnectDelay=1000";
        System.out.println(dataSourceUrl.replaceAll(ipRegex,"***").replaceAll(domainRegex,"***"));
        System.out.println(InetAddress.getLocalHost().getHostAddress());
        System.out.println(key);
        System.out.println(SmsUtility.getNewContent("验证码***有效期3分钟。如非本人操作，建议立即更改账户密码【亚美4ab】", "【INFO】"));
        System.out.println(SmsUtility.getNewContent("验证码***有效期3分钟。如非本人操作，建议立即更改账户密码【亚美】", "【INFO】"));
        System.out.println(SmsUtility.getNewContent("验证码***有效期3分钟。如非本人操作，建议立即更改账户密码【av21】", "【INFO】"));
        System.out.println(SmsUtility.getNewContent("验证码***有效期3分钟。如非本人操作，建议立即更改账户密码【1234】", "【INFO】"));
        System.out.println(SmsUtility.getNewContent("验证码***有效期3分钟。如非本人操作，建议立即更改账户密码", "【INFO】"));



    }

    @Test
    public void testLog(){

        Configuration config = new Configuration();
        config.setVcpPort("8080");
        config.setVcpPwd("000000");
        config.setVcpServer("10.66.72.136");
        config.setVcpUserId("hahahahaha");
        config.setMainUserId("abcdefg");
        Sms sms = new Sms();
        sms.setSendContent("12312321312");
        sms.setPhoneNumber("13012345678");
        sms.setCustomerLevel("aa@qq.com");
        logger.info(JSON.toJSONString(config));
        logger.info(JSON.toJSONString(sms));
        logger.info(sms.toString());
        logger.info("dddddddddddddddphone:{},fsdfsdfffffffffffffffffffffsc",18577076183l);
        logger.info("deweeeeeeeeeeeephone:{},loginName:{}",18577076183l,"condieeeeeeeeeeeeeeee");
    }



    @Test
    public void S24Reply(){

        String jsonResponse = "{\"error\":\"1\",\n" +
                "\"remark\":\"成功\",\n" +
                "\"callbox\":[\n" +
                "  {\"mobile\":\"15510331875\",\n" +
                "   \"content\":\"a\",\n" +
                "  \"receivetime\":\"2019-01-01 10:53:05\",\n" +
                "  \"extno\":\"123\"\n" +
                "  },{\n" +
                "  \"mobile\":\"13483728958\",\n" +
                "    \"content\":\"b\",\n" +
                "  \"receivetime\":\"2018-01-11 15:20:42\",\n" +
                "  \"extno\":\"456\"\n" +
                "  }\n" +
                " ]\n" +
                "}\n";
        if(jsonResponse == null || jsonResponse.isEmpty()){
        } else {
            JSONObject response = JSONObject.parseObject(jsonResponse);
            String result = response.getString("error");

            if(StringUtils.equals("1", result)){
                JSONArray mo = response.getJSONArray("callbox");
                List<Reply> replies = new ArrayList<>(mo.size());
                for(int i=0; i<mo.size(); i++){
                    JSONObject object = mo.getJSONObject(i);
                    String moTime = object.getString("receivetime");
                    String mobile = object.getString("mobile");
                    String content = object.getString("content");

                    Reply reply = new Reply();
                    reply.setProductId("B06");
                    reply.setContent(content);
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    try {
                        reply.setReceiveDate(new Timestamp(sdf.parse(moTime).getTime()));
                        reply.setPhone(mobile);
                    } catch (Exception e) {
                        logger.error("Failed to encrypt phone before saving to db " + reply.getPhone() + ".", e);
                        e.printStackTrace();
                    }
                    replies.add(reply);
                }
                if(CollectionUtils.isNotEmpty(replies)){
                    logger.info("GET S24 Replies 成功,返回值：{}",replies);
                }

            }else{
                logger.info("GET S24 Replies 失败,返回值：{}",jsonResponse);
            }
        }
    }
}
